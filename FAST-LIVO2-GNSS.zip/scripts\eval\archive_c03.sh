#!/bin/bash
OUT=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/c03_rtk_trial
mkdir -p "$OUT/trajectories" "$OUT/logs" "$OUT/metrics" "$OUT/configs" "$OUT/raw"

cp /home/slxc9426/catkin_ws/src/fast_livo/Log/result/phase5_c03_rtk_tight.txt \
   "$OUT/trajectories/c03_rtk_tight.tum"
cp /home/slxc9426/seg_phase5_c03_rtk_tight.log \
   "$OUT/logs/phase5_c03_rtk_tight.log"
cp /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c03_dd_gps_bds.csv \
   "$OUT/raw/c03_dd_gps_bds.csv"
cp /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c03_dd_gps_bds.bag \
   "$OUT/raw/c03_dd_gps_bds.bag"
cp /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c03_dd_meta.json \
   "$OUT/raw/c03_dd_meta.json"
cp /home/slxc9426/catkin_ws/src/fast_livo/config/great_campus03_rtk_tight.yaml \
   "$OUT/configs/great_campus03_rtk_tight.yaml"

if [ -f /home/slxc9426/catkin_ws/src/fast_livo/Log/result/phase5_c03_livo.txt ]; then
  cp /home/slxc9426/catkin_ws/src/fast_livo/Log/result/phase5_c03_livo.txt \
     "$OUT/trajectories/c03_livo.tum"
fi
if [ -f /home/slxc9426/seg_phase5_c03_livo.log ]; then
  cp /home/slxc9426/seg_phase5_c03_livo.log "$OUT/logs/phase5_c03_livo.log"
fi
cp /home/slxc9426/catkin_ws/src/fast_livo/config/great_campus03.yaml \
   "$OUT/configs/great_campus03_livo.yaml"

echo "archived c03 trial to $OUT"
ls "$OUT/trajectories" "$OUT/logs" "$OUT/raw"
