#!/usr/bin/env python3
"""A0-A4 evaluation: aligned ATE, unaligned ENU error, RPE, segment errors.

The project's EVAL_PROTOCOL notes that a full-trajectory SE(3)/Umeyama fit only
compares shape, not absolute ENU placement. This script reports both:

  - ATE after rigid Umeyama alignment (comparable to WP2 / earlier reports);
  - absolute ENU error against the reference, no alignment;
  - RPE over 1 s and 10 s pairs (local consistency, no alignment);
  - per-segment absolute 2D RMSE for the plan's screening windows.

Usage:
  python3 eval_ate.py --ref .../campus02_reference.tum \
      --arm A0=.../c02_A0.tum --arm A1=.../c02_A1.tum \
      --segments "0-115,150-270,270-420" --out report.md
"""
from __future__ import annotations

import argparse
import math
from pathlib import Path

import numpy as np


def load_tum(path: Path):
    t, p = [], []
    for line in path.open(errors="ignore"):
        s = line.split()
        if len(s) < 4:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
        except ValueError:
            continue
    t = np.asarray(t)
    p = np.asarray(p)
    order = np.argsort(t)
    return t[order], p[order]


def match(ta, tb, tol=0.1):
    """Nearest timestamp match. Returns index arrays into (ta, tb)."""
    ia, ib = [], []
    for i, t in enumerate(ta):
        j = int(np.argmin(np.abs(tb - t)))
        if abs(tb[j] - t) <= tol:
            ia.append(i)
            ib.append(j)
    return np.asarray(ia, dtype=int), np.asarray(ib, dtype=int)


def umeyama(src, dst):
    """Rigid Umeyama: dst ~= R src + t."""
    mu_s = src.mean(axis=0)
    mu_d = dst.mean(axis=0)
    H = (dst - mu_d).T @ (src - mu_s)
    U, _, Vt = np.linalg.svd(H)
    R = Vt.T @ np.diag([1.0, 1.0, np.sign(np.linalg.det(Vt.T @ U.T))]) @ U.T
    return R, mu_d - R @ mu_s


def stats(v):
    v = np.asarray(v, dtype=float)
    if v.size == 0:
        return dict(n=0, med=float("nan"), p95=float("nan"), rmse=float("nan"))
    return dict(n=int(v.size), med=float(np.median(v)),
                p95=float(np.percentile(v, 95)),
                rmse=float(np.sqrt(np.mean(v ** 2))))


def rpe_error(t, p, tr, pr, delta, tol=0.2):
    """Relative displacement error over arm samples separated by `delta`."""
    ia, ib = match(t, tr, tol=0.1)
    t_m, p_m, r_m = t[ia], p[ia], pr[ib]
    errs = []
    for i, t0 in enumerate(t_m):
        j = int(np.argmin(np.abs(t_m - (t0 + delta))))
        if abs(t_m[j] - (t0 + delta)) > tol or j <= i:
            continue
        errs.append(np.linalg.norm((p_m[j] - p_m[i]) - (r_m[j] - r_m[i])))
    return np.asarray(errs)


def evaluate(name, t, p, tr, pr, segments):
    ia, ib = match(t, tr, tol=0.1)
    pos = p[ia]
    ref = pr[ib]
    tm = t[ia]
    out = {"arm": name, "rows": int(len(t)), "matched": int(len(ia))}
    if len(ia) < 3:
        return out

    R, shift = umeyama(pos, ref)
    aligned = (R @ pos.T).T + shift
    e3 = np.linalg.norm(aligned - ref, axis=1)
    out["ate"] = stats(e3)

    d = pos - ref
    dn = np.linalg.norm(d, axis=1)
    d2 = np.linalg.norm(d[:, :2], axis=1)
    # One constant ENU offset removed over the whole run. This separates a
    # global placement bias (A3's target on campus-02) from shape error; it is
    # not an alignment, only a translation.
    bias = np.median(d, axis=0)
    db = d - bias
    out["abs"] = dict(
        e_rmse=float(np.sqrt(np.mean(d[:, 0] ** 2))),
        n_rmse=float(np.sqrt(np.mean(d[:, 1] ** 2))),
        u_rmse=float(np.sqrt(np.mean(d[:, 2] ** 2))),
        rmse2d=float(np.sqrt(np.mean(d2 ** 2))),
        rmse3d=float(np.sqrt(np.mean(dn ** 2))),
        p95_3d=float(np.percentile(dn, 95)),
        rmse2d_bc=float(np.sqrt(np.mean((db[:, :2] ** 2).sum(axis=1)))),
        rmse3d_bc=float(np.sqrt(np.mean((db ** 2).sum(axis=1)))),
        bias_enu=[float(bias[0]), float(bias[1]), float(bias[2])],
    )
    out["_db"] = db
    out["_tm"] = tm
    out["rpe1"] = stats(rpe_error(t, p, tr, pr, 1.0))
    out["rpe10"] = stats(rpe_error(t, p, tr, pr, 10.0))

    seg_rows = []
    t0 = tr[0]
    for seg in segments:
        a, b = seg
        sel = (tm - t0 >= a) & (tm - t0 <= b)
        if sel.sum() < 3:
            continue
        seg_rows.append((a, b, int(sel.sum()),
                         float(np.sqrt(np.mean(d2[sel] ** 2))),
                         float(np.sqrt(np.mean(dn[sel] ** 2))),
                         float(np.sqrt(np.mean(
                             (out["_db"][sel, :2] ** 2).sum(axis=1))))))
    out["segments"] = seg_rows
    return out


def fmt_stats(s):
    return f"{s['med']:.3f} / {s['p95']:.3f} / {s['rmse']:.3f}"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--ref", required=True)
    ap.add_argument("--arm", action="append", required=True,
                    help="name=path (repeatable)")
    ap.add_argument("--segments", default="",
                    help="comma-separated a-b windows relative to the reference")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    tr, pr = load_tum(Path(args.ref))
    segments = []
    if args.segments:
        for chunk in args.segments.split(","):
            a, b = chunk.split("-")
            segments.append((float(a), float(b)))

    rows = []
    for spec in args.arm:
        name, path = spec.split("=", 1)
        pth = Path(path)
        if not pth.is_file():
            print(f"MISSING {name}: {pth}")
            continue
        t, p = load_tum(pth)
        rows.append(evaluate(name, t, p, tr, pr, segments))

    lines = ["# A0/A1 evaluation", "",
             f"reference: `{args.ref}`", "",
             "| arm | rows | matched | ATE med/p95/RMSE (m) | abs 2D RMSE | "
             "abs 3D RMSE | abs p95 | 2D RMSE after constant-bias removal | "
             "RPE1 RMSE | RPE10 RMSE |",
             "|---|---:|---:|---|---:|---:|---:|---:|---:|---:|"]
    for r in rows:
        if "ate" not in r:
            lines.append(f"| {r['arm']} | {r['rows']} | {r['matched']} | "
                         "not enough matches | | | | | | |")
            continue
        a = r["abs"]
        lines.append(
            f"| {r['arm']} | {r['rows']} | {r['matched']} | "
            f"{fmt_stats(r['ate'])} | {a['rmse2d']:.3f} | {a['rmse3d']:.3f} | "
            f"{a['p95_3d']:.3f} | {a['rmse2d_bc']:.3f} | "
            f"{r['rpe1']['rmse']:.3f} | "
            f"{r['rpe10']['rmse']:.3f} |")

    first_segments = next((r["segments"] for r in rows if r.get("segments")), [])
    if segments and first_segments:
        lines += ["", "## Segment absolute 2D / 3D / bias-removed 2D RMSE (m)", ""]
        head = "| arm | " + " | ".join(f"{s[0]:g}-{s[1]:g}s"
                                       for s in first_segments) + " |"
        lines.append(head)
        lines.append("|---|" + "---|" * len(first_segments))
        for r in rows:
            if not r.get("segments"):
                continue
            cells = " | ".join(f"{x[3]:.3f} / {x[4]:.3f} / {x[5]:.3f}"
                               for x in r["segments"])
            lines.append(f"| {r['arm']} | {cells} |")

    for r in rows:
        if "abs" in r:
            b = r["abs"]["bias_enu"]
            lines += ["", f"- {r['arm']} median ENU bias: "
                          f"E {b[0]:.3f}, N {b[1]:.3f}, U {b[2]:.3f} m"]

    text = "\n".join(lines) + "\n"
    print(text)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
