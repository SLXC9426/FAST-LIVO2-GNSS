#!/bin/bash
OUT=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval
for f in /home/slxc9426/seg_phase4_c01_*.log; do
  b=$(basename "$f")
  cp "$f" "$OUT/logs/${b#seg_}"
done
for t in phase4_c01_livo_r1 phase4_c01_livo_r2 phase4_c01_livo_r3 \
         phase4_c01_tight_r1 phase4_c01_tight_r2 phase4_c01_tight_r3 \
         phase4_c01_robust_r2 phase4_c01_robust_r3; do
  cp "/home/slxc9426/catkin_ws/src/fast_livo/Log/result/$t.txt" "$OUT/trajectories/"
done
cp /home/slxc9426/catkin_ws/src/fast_livo/config/great_campus01.yaml "$OUT/configs/great_campus01_livo.yaml"
echo "logs: $(ls "$OUT"/logs/phase4_c01_*.log | wc -l)"
echo "tum:  $(ls "$OUT"/trajectories/ | wc -l)"
