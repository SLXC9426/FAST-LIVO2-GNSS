#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline global position graph v1 (no loop closure).

Purpose
-------
Combine a pure-LIVO relative-motion chain with 1 Hz RTK absolute positions and
solve for a globally consistent trajectory. This is the first milestone of the
R6 plan: it is deliberately POSITION-ONLY (orientations are taken from LIVO) so
that the value of the global absolute factors can be measured without touching
the front-end or the dense 25-frame FactorGraph.

Why position-only?
  * The prototype (`.tmp_check/pg/position_graph_proto.py`) showed the big win
    is translational: c01 full 2D 1.47 -> 0.77 m, c02 8.23 -> 2.61 m.
  * A full SE(3) graph is the next step; this tool is the cheap, auditable
    lower bound and the control for that step.

Key design choices (R6_STATE §4.2)
  * LIVO relative factors are frame-invariant; RTK factors are absolute ENU.
  * RTK is split into horizontal (strong) and vertical (weak) factors. A single
    3D Huber norm lets vertical spikes suppress valid horizontal corrections.
  * Each keyframe uses at most one nearest fix; no fix is reused.
  * Static handling is optional and OFF by default. The prototype showed a
    rigid zero-displacement prior can *hurt* (c02 2.61 -> 4.91 m); use
    --static-prior-sigma only for experiments.
  * No per-dataset constants: all weights are CLI arguments with global
    defaults; sweep on c01, validate on c02.

Usage
-----
  global_position_graph.py --livo <livo.tum> --rtk <rtk.tum|bag> \
      [--ref <reference.tum>] [--out <graph.tum>] [--tag TAG] \
      [--rtk-topic /gnss_rtk] [--keyframe-dt 1.0] \
      [--sig-odom 0.05] [--sig-rtk-xy 1.0] [--sig-rtk-z 10.0] \
      [--huber-xy 0.0] [--static-prior-sigma 0.0] \
      [--lever -0.05 -0.325 0.165] [--yaw-deg NAN]

Outputs the same scopes as eval_unified.py (full / steady / movfit /
stat@movfit / static-loc) for the input LIVO, RTK-only, and graph arms.
"""
import argparse
import math
import os
import subprocess
import sys
import tempfile
import time

import numpy as np

try:
    from scipy.sparse import coo_matrix
    from scipy.sparse.linalg import lsqr
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eval_unified as eu  # noqa: E402  (load_tum, score, static_segments, fit_eval)


# --------------------------------------------------------------------------- io


def load_tum_q(path):
    t, p, q = [], [], []
    for line in open(path, encoding="utf-8", errors="ignore"):
        s = line.split()
        if len(s) < 8:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
            q.append([float(s[4]), float(s[5]), float(s[6]), float(s[7])])
        except ValueError:
            pass
    return np.array(t), np.array(p), np.array(q)


def quat_to_R(q):
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def interp_xyz(t_src, p_src, t_dst):
    out = np.empty((len(t_dst), 3))
    for k in range(3):
        out[:, k] = np.interp(t_dst, t_src, p_src[:, k])
    return out


def ensure_rtk_tum(path, topic, start, dur):
    """Accept a TUM or a rosbag and return a TUM path."""
    if not path.endswith(".bag"):
        return path
    out = os.path.join(tempfile.gettempdir(),
                       "rtk_%d_%s.tum" % (os.getpid(), os.path.basename(path)))
    conv = os.path.join(HERE, "gnss_bag_to_tum.py")
    cmd = [sys.executable, conv, path, topic, out]
    if start:
        cmd += ["--start", str(start)]
    if dur:
        cmd += ["--dur", str(dur)]
    subprocess.run(cmd, check=True)
    return out


# ------------------------------------------------------------------- alignment


def yaw_fit_robust(p_livo, p_rtk, iters=3):
    """2D rigid yaw+translation, with MAD-based outlier rejection."""
    a = p_livo[:, :2].copy()
    b = p_rtk[:, :2].copy()
    keep = np.ones(len(a), bool)
    yaw, t = 0.0, np.zeros(2)
    for _ in range(iters):
        ac = a[keep] - a[keep].mean(0)
        bc = b[keep] - b[keep].mean(0)
        dot = (ac * bc).sum()
        cross = (ac[:, 0] * bc[:, 1] - ac[:, 1] * bc[:, 0]).sum()
        yaw = math.atan2(cross, dot)
        R = np.array([[math.cos(yaw), -math.sin(yaw)],
                      [math.sin(yaw), math.cos(yaw)]])
        t = b[keep].mean(0) - R @ a[keep].mean(0)
        pred = (R @ a.T).T + t
        r = np.linalg.norm(pred - b, axis=1)
        med = np.median(r[keep])
        mad = np.median(np.abs(r[keep] - med)) + 1e-6
        new_keep = r < med + 3.0 * 1.4826 * mad
        if new_keep.sum() < max(20, 0.5 * keep.sum()):
            break
        if np.array_equal(new_keep, keep):
            break
        keep = new_keep
    pred = (np.array([[math.cos(yaw), -math.sin(yaw)],
                      [math.sin(yaw), math.cos(yaw)]]) @ a.T).T + t
    rms = float(np.sqrt(((pred - b) ** 2).sum(1).mean()))
    return yaw, t, rms, int(keep.sum())


# ------------------------------------------------------------------- graph core


def select_keyframes(t, dt):
    if dt <= 0:
        return np.arange(len(t))
    idx = [0]
    last = t[0]
    for i in range(1, len(t)):
        if t[i] - last >= dt:
            idx.append(i)
            last = t[i]
    return np.array(idx)


def static_mask_keyframes(t, p, thresh=0.10, win=2):
    dt = np.diff(t)
    dt[dt <= 0] = np.inf
    v = np.concatenate([[0.0], np.linalg.norm(np.diff(p, axis=0), axis=1) / dt])
    vm = np.array([np.median(v[max(0, i - win):min(len(v), i + win + 1)])
                   for i in range(len(v))])
    return vm < thresh


def select_oracle_loops(t, ref_t, ref_p, yaw_ref, args):
    """Select oracle loop pairs from a reference trajectory.

    Evaluation only: the loop measurement is the reference displacement between
    two keyframes. It estimates the upper bound of loop-closure benefit and is
    never a production measurement. Only x/y are constrained because the c01/c02
    reference files carry position but no orientation.
    """
    pref = interp_xyz(ref_t, ref_p, t)
    inside = (t >= ref_t[0]) & (t <= ref_t[-1])
    smask = static_mask_keyframes(t, pref, thresh=args.loop_static_v, win=3)
    moving = (~smask) & inside
    R = np.array([[math.cos(yaw_ref), -math.sin(yaw_ref)],
                  [math.sin(yaw_ref), math.cos(yaw_ref)]])
    loops = []
    seen = set()
    n_with_prev = 0
    n_near = 0
    for i in range(len(t)):
        if not moving[i]:
            continue
        # Last keyframe strictly older than loop_min_gap.
        jmax = int(np.searchsorted(t, t[i] - args.loop_min_gap,
                                   side="left")) - 1
        if jmax < 0:
            continue
        js = np.where(moving[:jmax + 1])[0]
        if js.size == 0:
            continue
        n_with_prev += 1
        d = np.linalg.norm(pref[js, :2] - pref[i, :2], axis=1)
        k = int(np.argmin(d))
        if d[k] > args.loop_max_dist:
            continue
        n_near += 1
        j = int(js[k])
        pair = (min(i, j), max(i, j))
        if pair in seen:
            continue
        seen.add(pair)
        dd = R @ (pref[i, :2] - pref[j, :2])
        loops.append((i, j, float(dd[0]), float(dd[1]), float(d[k])))
    diag = {
        "n": len(loops),
        "n_with_prev": n_with_prev,
        "n_near": n_near,
        "moving_frac": float(moving.mean()),
        "static_frac": float(smask.mean()),
        "inside_frac": float(inside.mean()),
    }
    return loops, diag


def loop_residual_rms(p, loops):
    if not loops:
        return 0.0
    e = np.array([p[i, :2] - p[j, :2] - np.array([dx, dy])
                  for i, j, dx, dy, _ in loops])
    return float(np.sqrt((e ** 2).sum(1).mean()))


def write_loop_report(path, t, loops, residual_rms=None, extra=""):
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("# oracle loops %s\n" % extra)
        f.write("i\tj\tt_i\tt_j\tgap_s\tdist_ref_m\tdx_m\tdy_m\n")
        for i, j, dx, dy, dist in loops:
            f.write("%d\t%d\t%.6f\t%.6f\t%.3f\t%.4f\t%.4f\t%.4f\n" %
                    (i, j, t[i], t[j], t[i] - t[j], dist, dx, dy))
        if residual_rms is not None:
            f.write("# loop residual RMS = %.4f m, n=%d\n" %
                    (residual_rms, len(loops)))


def consistency_sigma(t, p, rtk_t, rtk_p_at_kf, yaw, args):
    """Per-keyframe RTK sigma from the LIO-vs-RTK relative-motion agreement.

    c01: LIO is locally accurate, the 60 s relative motion agrees with RTK ->
         weak absolute RTK (do not let a slow RTK bias distort the LIO shape).
    c02: LIO drifts, the relative motion disagrees -> strong absolute RTK.
    This is a global rule (same window/thresholds for every dataset).
    """
    n = len(t)
    Rz = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                   [math.sin(yaw), math.cos(yaw), 0],
                   [0, 0, 1.0]])
    p_enu = (Rz @ p.T).T
    W = max(args.consistency_window, 1.0)
    # Static keyframes must not enter the consistency statistics: their RTK
    # scatter is small but meaningless for the "is LIO drifting?" question.
    dtk = np.diff(t)
    dtk[dtk <= 0] = np.inf
    v = np.concatenate([[0.0], np.linalg.norm(np.diff(p_enu, axis=0), axis=1) / dtk])
    vm = np.array([np.median(v[max(0, i - 2):min(n, i + 3)]) for i in range(n)])
    moving = vm > 0.15
    e = np.zeros(n)
    for i in range(n):
        if not moving[i]:
            e[i] = args.e_low
            continue
        j = int(np.searchsorted(t, t[i] - W))
        j = max(0, min(j, i - 1))
        dt = t[i] - t[j]
        if dt < 0.5 * W:
            e[i] = args.e_low
            continue
        d_lio = p_enu[i] - p_enu[j]
        d_rtk = rtk_p_at_kf[i] - rtk_p_at_kf[j]
        e[i] = np.linalg.norm((d_lio - d_rtk)[:2]) / dt
    # median filter over moving neighbours only (+/-3 keyframes)
    em = np.empty(n)
    for i in range(n):
        sl = slice(max(0, i - 3), min(n, i + 4))
        vals = e[sl][moving[sl]]
        em[i] = np.median(vals) if vals.size else args.e_low
    sig = np.empty(n)
    for i, v in enumerate(em):
        if v <= args.e_low:
            sig[i] = args.sigma_rtk_weak
        elif v >= args.e_high:
            sig[i] = args.sigma_rtk_strong
        else:
            f = (v - args.e_low) / max(args.e_high - args.e_low, 1e-9)
            sig[i] = args.sigma_rtk_weak + f * (args.sigma_rtk_strong -
                                                args.sigma_rtk_weak)
    n_weak = int(np.sum(sig >= 0.5 * (args.sigma_rtk_weak +
                                      args.sigma_rtk_strong)))
    mv = em[moving] if np.any(moving) else em
    print("  adaptive rtk: moving e p10/p50/p90 = %.4f/%.4f/%.4f m/s; "
          "weak-side keyframes %.1f%%; sigma range %.2f..%.2f m" %
          (np.percentile(mv, 10), np.percentile(mv, 50), np.percentile(mv, 90),
           100.0 * n_weak / n, sig.min(), sig.max()))
    return sig


def solve_graph(t, p, q, rtk_t, rtk_p, yaw, tr_xy, args, sig_rtk_vec=None,
                loops=None):
    n = len(t)
    Rz = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                   [math.sin(yaw), math.cos(yaw), 0],
                   [0, 0, 1.0]])
    p0 = (Rz @ p.T).T + np.array([tr_xy[0], tr_xy[1], 0.0])

    # unique nearest fix per keyframe
    ir = np.array([int(np.argmin(np.abs(rtk_t - x))) for x in t])
    ok_raw = np.abs(rtk_t[ir] - t) < args.fix_max_dt
    ok = ok_raw.copy()
    if args.rtk_subsample > 1:
        # Decimate the absolute factors: correlated RTK bias should not be
        # counted as N independent observations. This is a global rate, not a
        # per-dataset constant.
        ok &= (ir % args.rtk_subsample == 0)
    used = {}
    for i in np.where(ok)[0]:
        j = int(ir[i])
        if j not in used:
            used[j] = i
        else:
            ok[i] = False
    n_fix = int(ok.sum())

    Rbody = [quat_to_R(qq) for qq in q]
    lever = np.array(args.lever)
    rigid = bool(args.static_rigid_sigma > 0)
    if rigid:
        smask = static_mask_keyframes(t, p, thresh=args.static_detect_thresh,
                                      win=args.static_detect_win)
    elif args.static_prior_sigma > 0:
        smask = static_mask_keyframes(t, p)
    else:
        smask = None
    # Static-run RTK downweighting (independent of the zero-displacement prior):
    # let the LIO odom chain define the static shape, so RTK jitter/bias cannot
    # drag the adjacent moving segment through the odometry coupling.
    dw_mask = (static_mask_keyframes(t, p, thresh=0.20, win=3)
               if args.static_downweight else None)
    dw_w = max(args.static_rtk_weight, 1e-6) if dw_mask is not None else 1.0
    # P1a: one robust median RTK anchor per static run. The factor added to the
    # graph constrains the MEAN of the run's positions to this anchor, while the
    # zero-displacement rows keep the run rigid. This is the graph equivalent of
    # apply_static_hold(), but it moves the static segment inside the solve and
    # lets the odometry factors carry the boundary continuously.
    rigid_runs = []
    anchor_of = np.full((n, 3), np.nan)
    rigid_member = np.zeros(n, bool)
    if rigid and smask is not None:
        # merge 1-2 frame gaps so a single noisy frame cannot split a stop
        runs = []
        i = 0
        while i < n:
            if not smask[i]:
                i += 1
                continue
            j = i
            while j + 1 < n and smask[j + 1]:
                j += 1
            if runs and i - runs[-1][1] <= 2:
                runs[-1] = (runs[-1][0], j)
            else:
                runs.append((i, j))
            i = j + 1
        for a0, b0 in runs:
            run = np.arange(a0, b0 + 1)
            rigid_member[run] = True
            valid = np.array([i for i in run if ok[i]], dtype=int)
            if valid.size > 0:
                z = np.median(np.array([rtk_p[ir[i]] - Rz @ Rbody[i] @ lever
                                        for i in valid]), axis=0)
                rigid_runs.append((run, z))
                anchor_of[run] = z
            else:
                rigid_runs.append((run, None))
        n_anchor = sum(1 for _r, z in rigid_runs if z is not None)
        print("  static rigid: %d run(s), %d anchored, sigma_stat=%.3f m, "
              "sigma_anchor=%.3f m, detect=%.2f m/s win=%d, keep_rtk=%s" %
              (len(rigid_runs), n_anchor, args.static_rigid_sigma,
               args.static_anchor_sigma, args.static_detect_thresh,
               args.static_detect_win, "on" if args.static_keep_rtk else "off"))
        for run, z in rigid_runs:
            tt = t[run]
            print("    static run %.1f-%.1f s (%d kf)%s" %
                  (tt[0] - t[0], tt[-1] - t[0], len(run),
                   "" if z is None else " anchor=(%.2f,%.2f,%.2f)" %
                   (z[0], z[1], z[2])))
    n_fix_eff = n_fix
    if rigid and not args.static_keep_rtk:
        n_fix_eff = int((ok & ~rigid_member).sum()) + sum(
            1 for _r, z in rigid_runs if z is not None)
    # P1b: local RTK-relative transition factors over the first N keyframes
    # after each static->moving boundary. They anchor the early motion scale
    # without trusting an absolute RTK bias; the lever-arm difference is kept.
    trans_factors = []
    if rigid and args.static_transition_sigma > 0:
        for run, _z in rigid_runs:
            b = int(run[-1])
            for j in range(1, args.static_transition_kf + 1):
                i0, i1 = b + j - 1, b + j
                if i1 >= n or rigid_member[i1]:
                    break
                if not (ok[i0] and ok[i1]) or ir[i0] == ir[i1]:
                    continue
                lw0 = Rz @ Rbody[i0] @ lever
                lw1 = Rz @ Rbody[i1] @ lever
                d = (rtk_p[ir[i1]] - lw1) - (rtk_p[ir[i0]] - lw0)
                trans_factors.append((i0, i1, d))
        print("  static transition: %d local RTK-relative factor(s), kf=%d, "
              "sigma_xy=%.3f m, sigma_z=%.3f m" %
              (len(trans_factors), args.static_transition_kf,
               args.static_transition_sigma, args.static_transition_z_sigma))
    static_anchor = None
    if smask is not None and not rigid:
        # Keep one absolute anchor per static run; per-epoch RTK factors inside
        # a static run fight the zero-displacement prior and inject jitter.
        static_anchor = np.zeros(n, bool)
        for i in range(n):
            if smask[i] and (i == 0 or not smask[i - 1]):
                static_anchor[i] = True
    w_odom = 1.0 / max(args.sig_odom, 1e-9)
    w_odom_z = 1.0 / max(
        args.sig_odom_z if args.sig_odom_z > 0 else args.sig_odom, 1e-9)
    wp = 1.0 / 0.01
    if rigid:
        w_st = 1.0 / max(args.static_rigid_sigma, 1e-9)
    elif smask is not None:
        w_st = 1.0 / max(args.static_prior_sigma, 1e-9)
    else:
        w_st = 0.0

    # Local RTK gate: a short-window LIO-vs-RTK relative-motion disagreement
    # flags a transient RTK outlier (e.g. c02 600-620 s). Expand the flag by
    # one window so the interior of the outlier also loses authority.
    gate_mask = None
    if args.rtk_consistency_gate:
        W = max(args.rtk_gate_window, 1.0)
        raw = np.zeros(n, bool)
        Rz_g = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                         [math.sin(yaw), math.cos(yaw), 0],
                         [0, 0, 1.0]])
        p_enu_g = (Rz_g @ p.T).T
        rtk_kf = np.array([rtk_p[int(np.argmin(np.abs(rtk_t - x)))]
                           for x in t])
        for i in range(n):
            j = int(np.searchsorted(t, t[i] - W))
            j = max(0, min(j, i - 1))
            if t[i] - t[j] < 0.5 * W:
                continue
            d = np.linalg.norm(((p_enu_g[i] - p_enu_g[j]) -
                                (rtk_kf[i] - rtk_kf[j]))[:2])
            if d > args.rtk_gate_thresh:
                raw[i] = True
        gate_mask = np.zeros(n, bool)
        for i in np.where(raw)[0]:
            a = int(np.searchsorted(t, t[i] - W))
            b = int(np.searchsorted(t, t[i] + W, side="right"))
            gate_mask[max(0, a):min(n, b)] = True
        if np.any(gate_mask):
            tt = t[gate_mask] - t[0]
            print("  rtk consistency gate: %d/%d keyframes (%.1f-%.1f s)" %
                  (int(gate_mask.sum()), n, tt.min(), tt.max()))
        else:
            print("  rtk consistency gate: no keyframes flagged")

    # P3: per-block LIO odometry scale with a random-walk prior. The scale is a
    # free variable in the same linear system (column 3*n+kb); block 0 is tied
    # to 1 with a weak prior so the scale/position gauge is fixed.
    scale_on = bool(args.odom_scale_walk_sigma > 0)
    block_kf = max(1, int(args.odom_scale_block_kf))
    nb = int(np.ceil(n / float(block_kf))) if scale_on else 0
    w_scale_walk = 1.0 / max(args.odom_scale_walk_sigma, 1e-9) if scale_on else 0.0
    w_scale_prior = 1.0 / max(args.odom_scale_prior_sigma, 1e-9) if scale_on else 0.0
    ncol = 3 * n + (nb if scale_on else 0)
    if scale_on:
        print("  odom scale: %d block(s), block_kf=%d, walk_sigma=%.4f, "
              "prior_sigma=%.3f" % (nb, block_kf, args.odom_scale_walk_sigma,
                                    args.odom_scale_prior_sigma))

    def build(weights_xy, weights_z):
        rows, cols, vals, rhs = [], [], [], []

        def add_row(terms, b):
            for c, v in terms:
                rows.append(len(rhs))
                cols.append(c)
                vals.append(v)
            rhs.append(b)

        r = 0
        for i in range(n - 1):
            d = Rz @ (p[i + 1] - p[i])
            if scale_on:
                kb = i // block_kf
                col_s = 3 * n + kb
                for k in range(3):
                    wa = w_odom_z if k == 2 else w_odom
                    add_row([(3 * i + k, -wa),
                             (3 * (i + 1) + k, wa),
                             (col_s, -wa * d[k])], 0.0)
            else:
                for k in range(3):
                    wa = w_odom_z if k == 2 else w_odom
                    add_row([(3 * i + k, -wa), (3 * (i + 1) + k, wa)],
                            wa * d[k])
            in_static = ((rigid and rigid_member[i] and rigid_member[i + 1])
                         or (not rigid and smask is not None
                             and smask[i] and smask[i + 1]))
            if in_static:
                for k in range(3):
                    add_row([(3 * i + k, -w_st), (3 * (i + 1) + k, w_st)], 0.0)
        if scale_on:
            add_row([(3 * n, w_scale_prior)], w_scale_prior)
            for kb in range(nb - 1):
                add_row([(3 * n + kb, -w_scale_walk),
                         (3 * n + kb + 1, w_scale_walk)], 0.0)
        if args.rtk_mode != "relative":
            for i in range(n):
                if not ok[i]:
                    continue
                w_scale = dw_w if (dw_mask is not None and dw_mask[i]) else 1.0
                if gate_mask is not None and gate_mask[i]:
                    w_scale *= max(args.rtk_gate_weight, 1e-6)
                if (static_anchor is not None and smask[i]
                        and not static_anchor[i]):
                    w_scale *= max(args.static_rtk_weight, 1e-6)
                if rigid and rigid_member[i]:
                    if not args.static_keep_rtk:
                        continue
                    w_scale *= max(args.static_rtk_weight, 1e-6)
                lever_w = Rz @ Rbody[i] @ lever
                base = rtk_p[ir[i]] - lever_w
                wx = weights_xy[i] * w_scale
                wz = weights_z[i] * w_scale
                add_row([(3 * i + 0, wx)], wx * base[0])
                add_row([(3 * i + 1, wx)], wx * base[1])
                add_row([(3 * i + 2, wz)], wz * base[2])
        if rigid:
            # One robust anchor per static run, applied to the run MEAN. Together
            # with the zero-displacement rows above this is the eliminated form
            # of  x_i = q_k (sigma_stat)  +  q_k = median(RTK) (sigma_anchor).
            w_a = 1.0 / max(args.static_anchor_sigma, 1e-9)
            for run, z in rigid_runs:
                if z is None:
                    continue
                nr = float(len(run))
                for k in range(3):
                    add_row([(3 * ii + k, w_a / nr) for ii in run],
                            w_a * z[k])
        if trans_factors:
            wx = 1.0 / max(args.static_transition_sigma, 1e-9)
            wz = 1.0 / max(args.static_transition_z_sigma, 1e-9)
            for i0, i1, d in trans_factors:
                for k in range(2):
                    add_row([(3 * i0 + k, -wx), (3 * i1 + k, wx)], wx * d[k])
                add_row([(3 * i0 + 2, -wz), (3 * i1 + 2, wz)], wz * d[2])
        if args.rtk_mode != "absolute":
            # Relative RTK factors: immune to a slow absolute bias, which is
            # exactly what makes c01 prefer a weak absolute weight while c02
            # needs a strong one. The lever-arm difference is kept.
            wx = 1.0 / max(args.sig_rtk_rel_xy, 1e-9)
            wz = 1.0 / max(args.sig_rtk_rel_z, 1e-9)
            for i in range(n - 1):
                if not (ok_raw[i] and ok_raw[i + 1]):
                    continue
                if ir[i] == ir[i + 1]:
                    continue
                if abs(rtk_t[ir[i + 1]] - rtk_t[ir[i]]) > 2.0 * args.fix_max_dt:
                    continue
                lw_i = Rz @ Rbody[i] @ lever
                lw_j = Rz @ Rbody[i + 1] @ lever
                d = (rtk_p[ir[i + 1]] - lw_j) - (rtk_p[ir[i]] - lw_i)
                add_row([(3 * i + 0, -wx), (3 * (i + 1) + 0, wx)], wx * d[0])
                add_row([(3 * i + 1, -wx), (3 * (i + 1) + 1, wx)], wx * d[1])
                add_row([(3 * i + 2, -wz), (3 * (i + 1) + 2, wz)], wz * d[2])
        if loops:
            # Oracle loop factors: p_i - p_j = reference displacement (x/y only).
            # These are evaluation-only; production loops must come from a
            # verified detector and use GICP covariance.
            wl = 1.0 / max(args.loop_sigma_xy, 1e-9)
            for (i, j, dx, dy, _dist) in loops:
                add_row([(3 * i + 0, wl), (3 * j + 0, -wl)], wl * dx)
                add_row([(3 * i + 1, wl), (3 * j + 1, -wl)], wl * dy)
        # Gauge: when the first keyframe is inside an anchored static run, the
        # segment anchor already fixes the absolute frame. A strong x[0]=p0[0]
        # prior would pin the whole stop to the LIO start and defeat the anchor.
        keep_gauge = not (rigid and rigid_member[0]
                          and np.isfinite(anchor_of[0, 0]))
        if keep_gauge:
            for k in range(3):
                add_row([(3 * 0 + k, wp)], wp * p0[0, k])
        A = coo_matrix((vals, (rows, cols)), shape=(len(rhs), ncol)).tocsr()
        return A, np.array(rhs)

    if sig_rtk_vec is None:
        base_w = np.full(n, 1.0 / max(args.sig_rtk_xy, 1e-9))
    else:
        base_w = 1.0 / np.maximum(sig_rtk_vec, 1e-9)
    base_w_z = 1.0 / max(args.sig_rtk_z, 1e-9)
    weights = base_w.copy()
    weights_z = np.full(n, base_w_z)
    robust_on = (args.huber_xy > 0 or args.cauchy_xy > 0 or args.cauchy_z > 0)
    x = p0.reshape(-1).copy()
    if scale_on:
        x = np.concatenate([x, np.ones(nb)])

    def finalize(x):
        if scale_on:
            sc = x[3 * n:]
            print("  odom scale: " + " ".join("%.5f" % v for v in sc))
        return x[:3 * n].reshape(n, 3), n_fix_eff, ok

    def robust_weights(res):
        """Per-axis IRLS weights (Huber/Cauchy) for one Gauss-Newton step."""
        wx = base_w.copy()
        wz = np.full(n, base_w_z)
        for i in range(n):
            if not ok[i]:
                continue
            if (static_anchor is not None and smask[i]
                    and not static_anchor[i]):
                continue
            if rigid and rigid_member[i]:
                continue
            lever_w = Rz @ Rbody[i] @ lever
            base = rtk_p[ir[i]] - lever_w
            rn = math.hypot(res[i, 0] - base[0], res[i, 1] - base[1])
            rz = abs(res[i, 2] - base[2])
            if args.cauchy_xy > 0:
                wx[i] = base_w[i] / (1.0 + (rn / args.cauchy_xy) ** 2)
            elif args.huber_xy > 0 and rn > args.huber_xy:
                wx[i] = base_w[i] * args.huber_xy / rn
            if args.cauchy_z > 0:
                wz[i] = base_w_z / (1.0 + (rz / args.cauchy_z) ** 2)
        return wx, wz

    for it in range(args.iters if robust_on else 1):
        A, b = build(weights, weights_z)
        if HAVE_SCIPY:
            x = lsqr(A, b, atol=1e-10, btol=1e-10, iter_lim=4000)[0]
        else:
            x = np.linalg.lstsq(A.toarray(), b, rcond=None)[0]
        if (not robust_on or args.rtk_mode == "relative"
                or it == args.iters - 1):
            break
        res = x[:3 * n].reshape(n, 3)
        weights, weights_z = robust_weights(res)
    return finalize(x)


# --------------------------------------------------------------------- metrics


def eval_arms(tag, t, p, rt, rp, ref_t, ref_p, wins=()):
    """Print full/steady/movfit/stat@movfit/static-loc for one arm."""
    m_full, _ = eu.score(t, p, rt, rp, 0.0)
    m_steady, _ = eu.score(t, p, rt, rp, 150.0)
    irall = np.array([int(np.argmin(np.abs(rt - x))) for x in t])
    okall = np.abs(rt[irall] - t) < 0.25
    rpm = rp[irall]
    segs = eu.static_segments(rt, rp, 0.10, 2, 5.0, 2.0)
    stat_ref = np.zeros(len(rt), bool)
    for a0, b0 in segs:
        stat_ref |= (rt >= a0) & (rt <= b0)
    statm = stat_ref[irall] & okall
    movm = ~stat_ref[irall] & okall
    line = ["== %s ==" % tag]
    if m_full:
        line.append("  full   : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f 3D_mean=%.4f 3D_max=%.4f"
                    % (m_full["n"], m_full["r3"], m_full["r2"],
                       m_full["mean3"], m_full["mx"]))
    if m_steady:
        line.append("  steady : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                    % (m_steady["n"], m_steady["r3"], m_steady["r2"]))
    if movm.sum() >= 20:
        m, _, _ = eu.fit_eval(p, rpm, movm, movm)
        if m:
            line.append("  movfit : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (m["n"], m["r3"], m["r2"]))
        m, _, _ = eu.fit_eval(p, rpm, movm, statm)
        if m:
            line.append("  stat@movfit: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (m["n"], m["r3"], m["r2"]))
    pool = []
    for a0, b0 in segs:
        mseg = okall & (rt[irall] >= a0) & (rt[irall] <= b0)
        m, _, e2 = eu.fit_eval(p, rpm, mseg, mseg)
        if m:
            pool.append(e2)
    if pool:
        e2 = np.concatenate(pool)
        line.append("  static-loc pooled: n=%d 2D_RMSE=%.4f"
                    % (e2.size, float(np.sqrt((e2 ** 2).mean()))))
    for a, b in wins:
        mwin = okall & ((t - t[0]) >= a) & ((t - t[0]) <= b)
        m, _, _ = eu.fit_eval(p, rpm, mwin, mwin)
        if m:
            line.append("  win %.0f:%.0f: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (a, b, m["n"], m["r3"], m["r2"]))
    print("\n".join(line))
    return {
        "full2": m_full["r2"] if m_full else None,
        "steady2": m_steady["r2"] if m_steady else None,
    }


def apply_static_hold(pg, pk, smask, t, blend_s, rtk_kf=None,
                      expand_s=5.0, anchor="rtk"):
    """Keep the graph's moving solution, but replace detected static runs with
    the LIVO static segment rigidly placed by the RTK mean of that run.

    Shape comes from LIO (cm-level static self-motion); absolute placement comes
    from the robust RTK mean (not from one noisy fix and not from the graph's
    distorted static segment). A short blend removes the boundary jump.
    """
    out = pg.copy()
    n = len(pg)
    if n < 3:
        return out
    dt = np.diff(t)
    dt = dt[dt > 0]
    step = float(np.median(dt)) if dt.size else 1.0
    blend_n = max(1, int(round(blend_s / max(step, 1e-6))))
    expand_n = max(0, int(round(expand_s / max(step, 1e-6))))
    i = 0
    runs = 0
    while i < n:
        if not smask[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and smask[j + 1]:
            j += 1
        # Expand the held run so the full reference stop (whose edges move
        # slowly) is covered; the offset still comes from the detected core.
        a = max(0, i - expand_n)
        b = min(n - 1, j + expand_n)
        print("  static hold run: core %.1f-%.1f s, applied %.1f-%.1f s" %
              (t[i] - t[0], t[j] - t[0], t[a] - t[0], t[b] - t[0]))
        if anchor == "boundary":
            # Keep the held segment continuous with the adjacent moving part.
            # A trajectory-start stop anchors on its end boundary; a final stop
            # anchors on its start boundary; a middle stop averages both.
            has_prev = a > 0
            has_next = b < n - 1
            if has_prev and has_next:
                off = 0.5 * ((pg[a] - pk[a]) + (pg[b] - pk[b]))
            elif has_next:
                off = pg[b] - pk[b]
            elif has_prev:
                off = pg[a] - pk[a]
            else:
                off = pg[i] - pk[i]
        elif rtk_kf is not None:
            # robust absolute placement of this static run
            off = np.median(rtk_kf[i:j + 1] - pk[i:j + 1], axis=0)
        else:
            off = pg[i] - pk[i]
        for k in range(a, b + 1):
            seg_k = pk[k] + off
            if a > 0 and k - a < blend_n:
                w = (k - a + 1.0) / (blend_n + 1.0)
            elif b < n - 1 and b - k < blend_n:
                w = (b - k + 1.0) / (blend_n + 1.0)
            else:
                w = 1.0
            out[k] = (1.0 - w) * pg[k] + w * seg_k
        runs += 1
        i = j + 1
    print("  static hold: %d run(s), no factor changes" % runs)
    return out


def write_tum(path, t, p, q):
    with open(path, "w") as f:
        for i in range(len(t)):
            f.write("%.6f %.6f %.6f %.6f %.9f %.9f %.9f %.9f\n" %
                    (t[i], p[i, 0], p[i, 1], p[i, 2],
                     q[i, 0], q[i, 1], q[i, 2], q[i, 3]))


# ------------------------------------------------------------------------ main


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--livo", required=True)
    ap.add_argument("--rtk", required=True)
    ap.add_argument("--ref", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--tag", default="global_position_graph")
    ap.add_argument("--rtk-topic", default="/gnss_rtk")
    ap.add_argument("--rtk-start", type=float, default=0.0)
    ap.add_argument("--rtk-dur", type=float, default=None)
    ap.add_argument("--keyframe-dt", type=float, default=1.0)
    ap.add_argument("--sig-odom", type=float, default=0.05)
    ap.add_argument("--sig-odom-z", type=float, default=0.0,
                    help="P4: vertical LIO odometry sigma (0 = use --sig-odom)")
    ap.add_argument("--sig-rtk-xy", type=float, default=1.0)
    ap.add_argument("--sig-rtk-z", type=float, default=10.0)
    ap.add_argument("--rtk-mode", choices=["absolute", "relative", "both"],
                    default="absolute",
                    help="absolute factors are sensitive to slow RTK bias; "
                         "relative factors cancel it but need an absolute gauge")
    ap.add_argument("--sig-rtk-rel-xy", type=float, default=0.2)
    ap.add_argument("--sig-rtk-rel-z", type=float, default=1.0)
    ap.add_argument("--rtk-subsample", type=int, default=1,
                    help="keep every Nth absolute fix (1 = all); correlated "
                         "RTK bias should not count as independent observations")
    ap.add_argument("--adaptive-rtk", action="store_true",
                    help="per-keyframe RTK weight from LIO-vs-RTK relative "
                         "consistency (one global rule for all datasets)")
    ap.add_argument("--consistency-window", type=float, default=60.0)
    ap.add_argument("--e-low", type=float, default=0.045,
                    help="m/s; below this LIO is locally consistent -> weak RTK")
    ap.add_argument("--e-high", type=float, default=0.10,
                    help="m/s; above this LIO is drifting -> strong RTK")
    ap.add_argument("--sigma-rtk-weak", type=float, default=5.0)
    ap.add_argument("--sigma-rtk-strong", type=float, default=1.0)
    ap.add_argument("--auto-odom", action="store_true",
                    help="set the odom sigma from the same initial fit residual: "
                         "larger LIO drift -> looser odom (one global formula)")
    ap.add_argument("--odom-a", type=float, default=0.05)
    ap.add_argument("--odom-b", type=float, default=0.06)
    ap.add_argument("--odom-fit-ref", type=float, default=2.0)
    ap.add_argument("--odom-max", type=float, default=0.5)
    ap.add_argument("--auto-sigma-rtk", action="store_true",
                    help="set one global RTK sigma from the initial LIO-RTK fit "
                         "residual: larger residual -> trust RTK more. This is "
                         "a single global formula, not a per-dataset constant.")
    ap.add_argument("--fit-a", type=float, default=6.0)
    ap.add_argument("--fit-b", type=float, default=0.6)
    ap.add_argument("--huber-xy", type=float, default=0.0,
                    help="Huber delta on HORIZONTAL RTK residual (0 = off)")
    ap.add_argument("--cauchy-xy", type=float, default=0.0,
                    help="P2: Cauchy delta (m) on HORIZONTAL RTK residual (0 = off)")
    ap.add_argument("--cauchy-z", type=float, default=0.0,
                    help="P2: Cauchy delta (m) on VERTICAL RTK residual (0 = off)")
    ap.add_argument("--static-prior-sigma", type=float, default=0.0,
                    help="m, zero-displacement prior in detected static segments (0 = off)")
    ap.add_argument("--static-rigid-sigma", type=float, default=0.0,
                    help="m, P1a: rigid zero-displacement factor inside detected "
                         "static runs plus one robust segment-mean anchor "
                         "(0 = off). Replaces the post-hoc --static-hold.")
    ap.add_argument("--static-anchor-sigma", type=float, default=0.3,
                    help="m, P1a: sigma of the per-run robust median RTK anchor")
    ap.add_argument("--static-detect-thresh", type=float, default=0.20,
                    help="m/s, P1a: LIO speed below which a keyframe is static")
    ap.add_argument("--static-detect-win", type=int, default=3,
                    help="frames, P1a: median window for static detection")
    ap.add_argument("--static-keep-rtk", action="store_true",
                    help="P1a: keep per-epoch RTK factors inside static runs "
                         "(default: skip them, the segment anchor replaces them)")
    ap.add_argument("--static-transition-sigma", type=float, default=0.0,
                    help="m, P1b: local RTK-relative factor over the first "
                         "N keyframes after a static->moving boundary (0 = off)")
    ap.add_argument("--static-transition-z-sigma", type=float, default=1.0,
                    help="m, P1b: vertical sigma of the local transition factor")
    ap.add_argument("--static-transition-kf", type=int, default=3,
                    help="keyframes after the boundary covered by the P1b factor")
    ap.add_argument("--odom-scale-walk-sigma", type=float, default=0.0,
                    help="P3: per-block LIO odometry scale random-walk sigma "
                         "(0 = off; try 0.001-0.003)")
    ap.add_argument("--odom-scale-block-kf", type=int, default=60,
                    help="P3: keyframes per scale block")
    ap.add_argument("--odom-scale-prior-sigma", type=float, default=0.01,
                    help="P3: prior sigma of the first scale block around 1")
    ap.add_argument("--static-rtk-weight", type=float, default=0.1,
                    help="scale of non-anchor RTK factors inside a static run "
                         "when the static prior is on; keeps the segment rigid "
                         "while averaging (instead of trusting one fix)")
    ap.add_argument("--rtk-consistency-gate", action="store_true",
                    help="downweight RTK factors in short windows where the "
                         "LIO-vs-RTK relative motion disagrees strongly "
                         "(transient RTK outliers, e.g. c02 600-620 s)")
    ap.add_argument("--rtk-gate-window", type=float, default=10.0)
    ap.add_argument("--rtk-gate-thresh", type=float, default=2.0)
    ap.add_argument("--rtk-gate-weight", type=float, default=0.05)
    ap.add_argument("--static-downweight", action="store_true",
                    help="downweight absolute RTK factors inside static runs "
                         "(no zero-displacement prior); the LIO odom chain then "
                         "defines the static shape and the adjacent moving segment "
                         "is not dragged by RTK static jitter")
    ap.add_argument("--static-hold", action="store_true",
                    help="post-process: keep the graph for moving parts, use "
                         "the LIVO static segment (rigidly shifted) for static "
                         "runs, with a short boundary blend")
    ap.add_argument("--static-hold-blend", type=float, default=3.0)
    ap.add_argument("--static-hold-expand", type=float, default=5.0,
                    help="s; extend each detected static run to cover slow edges")
    ap.add_argument("--static-hold-anchor", choices=["rtk", "boundary"],
                    default="rtk",
                    help="constant offset for a static run: its RTK median, or "
                         "the graph offset at the adjacent moving boundary")
    ap.add_argument("--oracle-loops", default=None,
                    help="reference TUM used to build oracle loop factors "
                         "(evaluation only; never a production measurement)")
    ap.add_argument("--loop-sigma-xy", type=float, default=0.1,
                    help="m, horizontal sigma of oracle loop factors")
    ap.add_argument("--loop-min-gap", type=float, default=60.0,
                    help="s, minimum time separation for a loop pair")
    ap.add_argument("--loop-max-dist", type=float, default=5.0,
                    help="m, maximum horizontal reference distance for a loop pair")
    ap.add_argument("--loop-static-v", type=float, default=0.10,
                    help="m/s, reference speed below which a keyframe is static")
    ap.add_argument("--loop-report", default=None,
                    help="TSV path for the selected oracle loops")
    ap.add_argument("--shuffle-loops", action="store_true",
                    help="permute loop measurements across the same pairs "
                         "(mechanism control)")
    ap.add_argument("--loop-shuffle-seed", type=int, default=0)
    ap.add_argument("--lever", nargs=3, type=float,
                    default=[-0.05, -0.325, 0.165])
    ap.add_argument("--yaw-deg", type=float, default=None)
    ap.add_argument("--yaw-robust", action="store_true",
                    help="MAD-refit the 2D yaw; default uses all 2D samples "
                         "(excluding moving samples biases yaw on c01)")
    ap.add_argument("--fix-max-dt", type=float, default=0.6)
    ap.add_argument("--iters", type=int, default=5)
    ap.add_argument("--win", action="append", default=[],
                    help="A:B local-fit window (repeatable), e.g. 150:300")
    args = ap.parse_args()
    wins = []
    for w in args.win:
        a, b = w.split(":")
        wins.append((float(a or 0.0), float(b or 1e9)))

    rtk_path = ensure_rtk_tum(args.rtk, args.rtk_topic,
                              args.rtk_start, args.rtk_dur)
    t, p, q = load_tum_q(args.livo)
    rt, rp, _ = load_tum_q(rtk_path)
    if len(t) < 20 or len(rt) < 2:
        print("!! not enough poses (livo=%d rtk=%d)" % (len(t), len(rt)))
        return 1

    kf = select_keyframes(t, args.keyframe_dt)
    tk, pk, qk = t[kf], p[kf], q[kf]
    rt_interp = interp_xyz(rt, rp, tk)
    inb = (tk >= rt[0]) & (tk <= rt[-1])
    if inb.sum() < 20:
        print("!! too little time overlap between LIVO and RTK")
        return 1

    if args.yaw_deg is None:
        yaw, tr, fit_rms, nfit = yaw_fit_robust(
            pk[inb], rt_interp[inb], iters=3 if args.yaw_robust else 1)
    else:
        yaw = math.radians(args.yaw_deg)
        # fit only the translation with the given yaw
        R2 = np.array([[math.cos(yaw), -math.sin(yaw)],
                       [math.sin(yaw), math.cos(yaw)]])
        tr = rt_interp[inb].mean(0) - R2 @ pk[inb].mean(0)
        pred = (R2 @ pk[inb, :2].T).T + tr
        fit_rms = float(np.sqrt(((pred - rt_interp[inb, :2]) ** 2).sum(1).mean()))
        nfit = int(inb.sum())

    if args.auto_sigma_rtk:
        auto = args.fit_a - args.fit_b * fit_rms
        auto = min(args.sigma_rtk_weak, max(args.sigma_rtk_strong, auto))
        print("  auto sigma_rtk_xy=%.3f m from fit_rms=%.2f m "
              "(a=%.2f b=%.2f, clip %.2f..%.2f)" %
              (auto, fit_rms, args.fit_a, args.fit_b,
               args.sigma_rtk_strong, args.sigma_rtk_weak))
        args.sig_rtk_xy = auto

    if args.auto_odom:
        odom = args.odom_a + args.odom_b * (fit_rms - args.odom_fit_ref)
        odom = min(args.odom_max, max(args.odom_a, odom))
        print("  auto sigma_odom=%.3f m from fit_rms=%.2f m "
              "(a=%.2f b=%.2f ref=%.2f, clip %.2f..%.2f)" %
              (odom, fit_rms, args.odom_a, args.odom_b,
               args.odom_fit_ref, args.odom_a, args.odom_max))
        args.sig_odom = odom

    print("== %s ==" % args.tag)
    loops = []
    if args.oracle_loops:
        reft, refp, _ = load_tum_q(args.oracle_loops)
        inb_ref = (rt >= reft[0]) & (rt <= reft[-1])
        if inb_ref.sum() < 20:
            print("!! not enough reference/RTK overlap for oracle loops")
            return 1
        ref_at_rt = interp_xyz(reft, refp, rt[inb_ref])
        yaw_ref, _, rms_ref, n_ref = yaw_fit_robust(
            ref_at_rt[:, :2], rp[inb_ref, :2], iters=3)
        print("  oracle reference: %s, ref->rtk yaw=%.2f deg, "
              "fit_rms=%.2f m (n=%d)" %
              (os.path.basename(args.oracle_loops), math.degrees(yaw_ref),
               rms_ref, n_ref))
        loops, loop_diag = select_oracle_loops(tk, reft, refp, yaw_ref, args)
        if args.shuffle_loops and loops:
            rng = np.random.default_rng(args.loop_shuffle_seed)
            orig = list(loops)
            perm = rng.permutation(len(orig))
            loops = [(i, j, orig[p][2], orig[p][3], dist)
                     for (i, j, _, _, dist), p in zip(orig, perm)]
            print("  oracle loops: SHUFFLED measurements (seed=%d)" %
                  args.loop_shuffle_seed)
        dvals = np.array([x[4] for x in loops])
        print("  oracle loops: n=%d (%.1f%% of keyframes), near=%d/%d, "
              "moving=%.1f%%, static=%.1f%%, ref dist p50/p90=%.2f/%.2f m, "
              "sigma=%.2f m" %
              (loop_diag["n"], 100.0 * loop_diag["n"] / max(len(tk), 1),
               loop_diag["n_near"], loop_diag["n_with_prev"],
               100.0 * loop_diag["moving_frac"],
               100.0 * loop_diag["static_frac"],
               np.percentile(dvals, 50) if dvals.size else float("nan"),
               np.percentile(dvals, 90) if dvals.size else float("nan"),
               args.loop_sigma_xy))
        if not loops:
            print("  !! oracle loops requested but none selected")
    print("  livo=%s (%d poses) rtk=%s (%d fixes)" %
          (os.path.basename(args.livo), len(t), os.path.basename(rtk_path), len(rt)))
    print("  keyframes=%d (dt>=%.2fs) yaw=%.2f deg fit_rms=%.2f m (n=%d)" %
          (len(tk), args.keyframe_dt, math.degrees(yaw), fit_rms, nfit))
    print("  weights: odom=%.3f m, rtk_mode=%s, rtk_xy=%.3f m, rtk_z=%.3f m, "
          "rtk_rel_xy=%.3f m, rtk_subsample=%d, adaptive_rtk=%s, huber_xy=%s, "
          "static=%s, static_dw=%s, static_rtk_w=%.2f" %
          (args.sig_odom, args.rtk_mode, args.sig_rtk_xy, args.sig_rtk_z,
           args.sig_rtk_rel_xy, args.rtk_subsample,
           "on" if args.adaptive_rtk else "off",
           "off" if args.huber_xy <= 0 else "%.2f m" % args.huber_xy,
           "off" if args.static_prior_sigma <= 0 else "%.2f m" % args.static_prior_sigma,
           "on" if args.static_downweight else "off",
           args.static_rtk_weight))
    if args.static_rigid_sigma > 0:
        print("  static rigid: sigma=%.3f m, anchor=%.3f m, detect=%.2f m/s "
              "win=%d, keep_rtk=%s (post-hoc static-hold should be OFF)" %
              (args.static_rigid_sigma, args.static_anchor_sigma,
               args.static_detect_thresh, args.static_detect_win,
               "on" if args.static_keep_rtk else "off"))
    if args.static_transition_sigma > 0:
        print("  static transition: sigma_xy=%.3f m, sigma_z=%.3f m, kf=%d" %
              (args.static_transition_sigma, args.static_transition_z_sigma,
               args.static_transition_kf))
    if args.odom_scale_walk_sigma > 0:
        print("  odom scale: walk_sigma=%.4f, block_kf=%d, prior_sigma=%.3f" %
              (args.odom_scale_walk_sigma, args.odom_scale_block_kf,
               args.odom_scale_prior_sigma))
    if args.cauchy_xy > 0 or args.cauchy_z > 0:
        print("  robust RTK: cauchy_xy=%.2f m, cauchy_z=%.2f m" %
              (args.cauchy_xy, args.cauchy_z))
    if args.sig_odom_z > 0:
        print("  odom z sigma: %.3f m (xy %.3f m)" %
              (args.sig_odom_z, args.sig_odom))

    sig_vec = None
    if args.adaptive_rtk:
        sig_vec = consistency_sigma(tk, pk, rt, rt_interp, yaw, args)
    if loops:
        print("  loop factors: %d x 2D, sigma=%.3f m, source=%s" %
              (len(loops), args.loop_sigma_xy,
               os.path.basename(args.oracle_loops or "")))
    t_solve = time.perf_counter()
    pg, n_fix, used = solve_graph(tk, pk, qk, rt, rp, yaw, tr, args,
                                  sig_rtk_vec=sig_vec, loops=loops)
    print("  graph solve: %.1f ms" % ((time.perf_counter() - t_solve) * 1000.0))
    print("  rtk factors used: %d/%d (unique)" % (n_fix, len(tk)))
    if loops:
        loop_rms = loop_residual_rms(pg, loops)
        print("  loop residual RMS: %.4f m (n=%d)" % (loop_rms, len(loops)))
        if args.loop_report:
            write_loop_report(args.loop_report, tk, loops, loop_rms,
                              extra="tag=%s sigma=%.3f" %
                                    (args.tag, args.loop_sigma_xy))
    elif args.loop_report:
        print("  !! --loop-report given but no loops")
    if args.static_hold:
        # Wider than the graph's static-prior mask: the hold must cover the
        # full reference stop, including the slow edges.
        smask = static_mask_keyframes(tk, pk, thresh=0.20, win=3)
        pg = apply_static_hold(pg, pk, smask, tk, args.static_hold_blend,
                               rtk_kf=rt_interp,
                               expand_s=args.static_hold_expand,
                               anchor=args.static_hold_anchor)
    out = args.out or ("%s_graph.tum" % args.tag)
    write_tum(out, tk, pg, qk)
    print("  wrote %s" % out)

    if args.ref:
        reft, refp = eu.load_tum(args.ref)
        print("")
        eval_arms("LIVO (keyframes)", tk, pk, reft, refp, reft, refp, wins)
        eval_arms("RTK-only (interp)", tk, rt_interp, reft, refp, reft, refp, wins)
        eval_arms("GRAPH", tk, pg, reft, refp, reft, refp, wins)
    return 0


if __name__ == "__main__":
    sys.exit(main())
