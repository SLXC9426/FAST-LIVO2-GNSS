#!/usr/bin/env python3
"""
eval_dynamic.py - Improvement 3 analysis (dynamic-object removal).

Parses the <seq>_dyn.csv written by the C++ side:
  stamp, total_points, matched_points, dyn_points
and reports the dynamic-point ratio over time (a proxy for how many ghost /
dynamic measurements were rejected by the occlusion test + robust kernel) and
the matched-inlier ratio (registration quality).

Usage:
  python3 scripts/eval/eval_dynamic.py --dyn dyn.csv --out Log/eval/<seq>
"""

import argparse
import os
import sys

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MPL = True
except Exception:
    HAS_MPL = False


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dyn", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    d = np.loadtxt(args.dyn, delimiter=",", skiprows=1)
    if d.ndim == 1:
        d = d.reshape(1, -1)
    t = d[:, 0] - d[0, 0]
    total = d[:, 1]
    matched = d[:, 2]
    dyn = d[:, 3]

    dyn_ratio = dyn / np.maximum(total, 1)
    match_ratio = matched / np.maximum(total, 1)

    print(f"frames: {len(t)}")
    print(f"dynamic/occluded point ratio: mean {np.mean(dyn_ratio) * 100:.2f}% "
          f"p95 {np.percentile(dyn_ratio, 95) * 100:.2f}% max {np.max(dyn_ratio) * 100:.2f}%")
    print(f"matched inlier ratio:         mean {np.mean(match_ratio) * 100:.2f}% "
          f"p05 {np.percentile(match_ratio, 5) * 100:.2f}%")

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "dynamic_stats.txt"), "w") as f:
        f.write(f"frames {len(t)}\n")
        f.write(f"dyn_ratio_mean {np.mean(dyn_ratio):.4f}\n")
        f.write(f"dyn_ratio_p95 {np.percentile(dyn_ratio, 95):.4f}\n")
        f.write(f"match_ratio_mean {np.mean(match_ratio):.4f}\n")
        f.write(f"total_dyn_points {int(np.sum(dyn))}\n")

    if HAS_MPL:
        fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
        ax[0].plot(t, dyn_ratio * 100, "r-", lw=1)
        ax[0].set_title("dynamic/occluded points per frame (%)")
        ax[0].set_xlabel("time (s)")
        ax[1].plot(t, match_ratio * 100, "g-", lw=1)
        ax[1].set_title("matched inlier ratio (%)")
        ax[1].set_xlabel("time (s)")
        fig.tight_layout()
        fig.savefig(os.path.join(args.out, "dynamic_stats.png"), dpi=150)
        print("plot ->", os.path.join(args.out, "dynamic_stats.png"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
