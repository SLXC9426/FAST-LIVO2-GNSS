#include "graph_fit_mask.h"
#include "graph_fit.h"
#include <cstdio>
int main() {
  using fast_livo::acceptedFitSample;
  int failed=0;
  auto check=[&](bool ok,const char *s){ std::printf("%s %s\n",ok?"PASS":"FAIL",s); if(!ok) ++failed; };
  const std::vector<double> t{0,1,2};
  check(!acceptedFitSample(t,{1,0,1},.5),"rejected 30m endpoint cannot contaminate interpolated sample");
  check(!acceptedFitSample(t,{1,0,1},1.5),"both intervals touching rejected epoch are excluded");
  check(acceptedFitSample(t,{1,0,1},0) && acceptedFitSample(t,{1,0,1},2),"exact accepted endpoints survive rejected neighbour");
  check(!acceptedFitSample(t,{1,0,1},1),"exact rejected endpoint stays rejected");
  check(acceptedFitSample(t,{1,1,0},.5),"two accepted epochs allow interpolation");
  check(!acceptedFitSample(t,{0,0,0},.5),"unevaluated epochs do not default to accepted");
  check(!acceptedFitSample(t,{1,1,1},-1) && !acceptedFitSample(t,{1,1,1},3),"no extrapolation in pass2");
  check(!acceptedFitSample({0,0,1},{1,1,1},0),"duplicate epoch time is invalid evidence");
  // The real fitter must be able to improve when a rejected spike is removed.
  std::vector<Eigen::Vector3d> a,b;
  std::vector<double> weights;
  for(int i=0;i<40;++i) {
    a.emplace_back(i,std::sin(i*.3),0); b.push_back(a.back()+Eigen::Vector3d(3,-2,0));
    if(i==20) b.back().y()+=30;
    weights.push_back(i==20?0.:1.);
  }
  fast_livo::SimilarityFitOptions opt;
  auto first=fast_livo::fitSimilarity2D(a,b,{},opt);
  auto second=fast_livo::fitSimilarity2D(a,b,weights,opt);
  check(first.valid && second.valid && second.rms<1e-9 && first.rms>1.,"real second fit improves with screened observations");
  return failed?1:0;
}
