#!/usr/bin/env python3
import rosbag, numpy as np
import sensor_msgs.point_cloud2 as pc2

b = rosbag.Bag("/home/slxc9426/campus-01.bag")
print("duration:", b.get_start_time(), b.get_end_time())
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    f = {x.name: x.datatype for x in msg.fields}
    pts = list(pc2.read_points(msg, field_names=("time", "ring"), skip_nans=True))
    a = np.array(pts[:8000], dtype=float)
    print("fields:", f)
    print("stamp:", msg.header.stamp.to_sec(), "npts:", len(pts))
    print("time: %.4f ~ %.4f" % (a[:, 0].min(), a[:, 0].max()))
    print("ring unique(int):", np.unique(a[:, 1].astype(int)).tolist()[:20])
    print("ring raw sample:", a[:5, 1].tolist())
    break
b.close()
