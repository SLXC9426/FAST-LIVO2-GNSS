#!/usr/bin/env python3
"""A2.5: summarize the last fit diagnostics of one or more node logs."""
import argparse
import math
import re
from pathlib import Path


def last_line(path: Path) -> str:
    line = ""
    for l in path.open(errors="ignore"):
        if "ONLINE GRAPH" in l:
            line = l
    return line


def f(line: str, key: str) -> float:
    m = re.search(rf"\b{key}=([-\d.eE+]+)", line)
    return float(m.group(1)) if m else float("nan")


def s(line: str, key: str) -> str:
    m = re.search(rf"\b{key}=([A-Za-z_]+)", line)
    return m.group(1) if m else "?"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("logs", nargs="+")
    args = ap.parse_args()
    print("| arm | pass | n | acc | scale1 | scale2 | dscale | yaw1 | yaw2 "
          "| dyaw_deg | rms1 | rms1_acc | rms2 | fallback |")
    print("|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---|")
    for p in args.logs:
        line = last_line(Path(p))
        arm = Path(p).name.replace("_node.log", "")
        y1, y2 = f(line, "fit_y1"), f(line, "fit_y2")
        dy = math.degrees(math.remainder(y2 - y1, 2 * math.pi)) \
            if math.isfinite(y1) and math.isfinite(y2) else float("nan")
        print(f"| {arm} | {f(line,'fit_pass'):.0f} | {f(line,'fit_n'):.0f} | "
              f"{f(line,'fit_acc'):.0f} | {f(line,'fit_s1'):.5f} | "
              f"{f(line,'fit_s2'):.5f} | {f(line,'fit_s2')-f(line,'fit_s1'):+.5f} | "
              f"{y1:+.4f} | {y2:+.4f} | {dy:+.3f} | "
              f"{f(line,'fit_r1'):.3f} | {f(line,'fit_ra1'):.3f} | "
              f"{f(line,'fit_r2'):.3f} | {s(line,'fit_fb')} |")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
