"""Geometry and independent-IMU checks for diagnostics; no factor decisions."""
import numpy as np
def lever_diagnostic(antenna,body_rotations,lever,world_to_enu=None):
    p=np.asarray(antenna,dtype=float);r=np.asarray(body_rotations,dtype=float);l=np.asarray(lever,dtype=float)
    if p.ndim!=2 or p.shape[1]!=3 or not len(p) or r.shape!=(len(p),3,3) or l.shape!=(3,) or not all(np.isfinite(x).all() for x in [p,r,l]):raise ValueError('invalid geometry')
    if not all(np.allclose(x.T@x,np.eye(3),atol=1e-7) and abs(np.linalg.det(x)-1)<1e-7 for x in r):raise ValueError('invalid body rotation')
    arms=r@l;bound=float(np.linalg.norm(p-p[0],axis=1).max()+np.linalg.norm(arms-arms[0],axis=1).max())
    out=dict(reference_excursion_upper_bound_m=bound,scope='sampled poses only; not absolute accuracy',candidate_q=None)
    if world_to_enu is not None:
        rz=np.asarray(world_to_enu,dtype=float)
        if rz.shape!=(3,3) or not np.isfinite(rz).all() or not np.allclose(rz.T@rz,np.eye(3),atol=1e-7) or abs(np.linalg.det(rz)-1)>1e-7:raise ValueError('invalid alignment rotation')
        out['candidate_q']=(p-arms@rz.T).tolist()
    return out

def imu_evidence(samples,now,window_sec=20.,max_age=.05,max_gap=.02,gyro_p95_limit=None,acc_norm_std_limit=None):
    if not np.isfinite([now,window_sec,max_age,max_gap]).all() or min(window_sec,max_age,max_gap)<=0:raise ValueError('invalid IMU timing')
    a=np.asarray(samples,dtype=float)
    if a.ndim!=2 or a.shape[1]!=7 or not np.isfinite(a).all() or np.any(np.diff(a[:,0])<=0):raise ValueError('invalid IMU input')
    a=a[a[:,0]<=now]
    if len(a)<2 or now-a[-1,0]>max_age:return {'state':'UNAVAILABLE','reason':'missing_or_stale_imu'}
    a=a[max(0,int(np.searchsorted(a[:,0],now-window_sec,side='right'))-1):]
    if a[-1,0]-a[0,0]<window_sec-max_gap or np.diff(a[:,0]).max()>max_gap:return {'state':'UNAVAILABLE','reason':'insufficient_imu_support'}
    gyro=float(np.percentile(np.linalg.norm(a[:,1:4],axis=1),95));acc=float(np.std(np.linalg.norm(a[:,4:7],axis=1)))
    if gyro_p95_limit is None or acc_norm_std_limit is None:return dict(state='WEAK',reason='motion_thresholds_unvalidated',gyro_p95_rad_s=gyro,acc_norm_std_m_s2=acc)
    limits=np.array([gyro_p95_limit,acc_norm_std_limit,max_age,max_gap,window_sec])
    if not np.isfinite(limits).all() or np.any(limits<=0):raise ValueError('invalid IMU thresholds')
    return dict(state='MOTION' if gyro>gyro_p95_limit or acc>acc_norm_std_limit else 'QUIET_DIAGNOSTIC',
        gyro_p95_rad_s=gyro,acc_norm_std_m_s2=acc,scope='quiet does not prove zero velocity')
