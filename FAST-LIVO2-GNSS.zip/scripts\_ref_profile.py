#!/usr/bin/env python3
"""Check reference trajectory: distance vs time profile for urban-01."""
import io
import numpy as np

p = r"D:\BaiduNetdiskDownload\Urban-01\urban01_reference.tum"
lines = io.open(p, encoding="utf-8", errors="replace").read().strip().splitlines()
t = []
xy = []
for l in lines:
    v = l.split()
    t.append(float(v[0]))
    xy.append([float(v[1]), float(v[2])])
t = np.array(t)
xy = np.array(xy)
d = np.concatenate([[0.0], np.linalg.norm(np.diff(xy, axis=0), axis=1)])
cum = np.cumsum(d)

T0 = t[0]
print(f"start={T0:.2f} end={t[-1]:.2f} dur={t[-1]-T0:.1f}s total_len={cum[-1]:.1f}m")
print("t_rel(s)  pos(x,y)  dist_from_start  cum_len")
for dt in [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100, 120, 150, 180, 220, 260, 300, 400, 500, 600, 700, 767]:
    idx = np.argmin(np.abs(t - (T0 + dt)))
    print(f"{dt:6d}  ({xy[idx,0]:9.2f},{xy[idx,1]:9.2f})  {np.linalg.norm(xy[idx]-xy[0]):8.2f}  {cum[idx]:8.2f}")
