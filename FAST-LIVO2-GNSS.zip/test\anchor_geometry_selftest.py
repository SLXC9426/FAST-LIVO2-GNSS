import importlib.util,unittest
from pathlib import Path
import numpy as np
p=Path(__file__).resolve().parents[1]/'scripts/eval/anchor_geometry_diagnostic.py'
s=importlib.util.spec_from_file_location('geometry',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class Geometry(unittest.TestCase):
 def test_rotation_lever_and_unknown_frame(self):
  angles=np.linspace(0,np.pi/2,30);r=np.array([[[np.cos(t),-np.sin(t),0],[np.sin(t),np.cos(t),0],[0,0,1]] for t in angles]);l=np.array([.4,0,0]);antenna=r@l+[3,2,1]
  v=m.lever_diagnostic(antenna,r,l,np.eye(3));np.testing.assert_allclose(v['candidate_q'],np.tile([3,2,1],(30,1)),atol=1e-12)
  self.assertIsNone(m.lever_diagnostic(antenna,r,l)['candidate_q'])
  np.testing.assert_allclose(m.lever_diagnostic(antenna,r,[0,0,0],np.eye(3))['candidate_q'],antenna)
 def test_imu_independent_and_missing(self):
  t=np.arange(0,20.005,.005);a=np.zeros((len(t),7));a[:,0]=t;a[:,6]=9.81
  self.assertEqual(m.imu_evidence(a,20)['state'],'WEAK')
  a[:,3]=.2
  self.assertEqual(m.imu_evidence(a,20,gyro_p95_limit=.01,acc_norm_std_limit=.3)['state'],'MOTION')
  self.assertEqual(m.imu_evidence(a[:100],20)['state'],'UNAVAILABLE')
 def test_invalid_alignment(self):
  with self.assertRaises(ValueError):m.lever_diagnostic([[0,0,0]],[np.eye(3)],[0,0,0],np.zeros((3,3)))
 def test_constant_velocity_is_not_observable_from_quiet_imu(self):
  t=np.arange(0,20.005,.005);a=np.zeros((len(t),7));a[:,0]=t;a[:,6]=9.81
  # Stationary and constant-velocity translation have identical ideal IMU.
  stationary=np.zeros((len(t),3));moving=np.column_stack([t,np.zeros((len(t),2))])
  np.testing.assert_allclose(np.diff(stationary,n=2,axis=0),np.diff(moving,n=2,axis=0),atol=1e-12)
  v=m.imu_evidence(a,20,gyro_p95_limit=.01,acc_norm_std_limit=.3)
  self.assertEqual(v['state'],'QUIET_DIAGNOSTIC');self.assertIn('does not prove zero velocity',v['scope'])
  self.assertEqual(m.imu_evidence(a,20)['state'],'WEAK')
 def test_slow_rotation_constant_norm_and_bias_are_weak(self):
  t=np.arange(0,20.005,.005);a=np.zeros((len(t),7));a[:,0]=t;a[:,2]=.001
  a[:,4]=9.81*np.sin(.001*t);a[:,6]=9.81*np.cos(.001*t)
  self.assertLess(np.std(np.linalg.norm(a[:,4:7],axis=1)),1e-10)
  self.assertEqual(m.imu_evidence(a,20)['state'],'WEAK')
  a[:,1:4]+=[.01,-.02,.03];a[:,4:7]+=[.2,-.1,.3]
  self.assertEqual(m.imu_evidence(a,20)['state'],'WEAK')
 def test_recovery_and_future_samples(self):
  t=np.arange(0,61.005,.005);a=np.zeros((len(t),7));a[:,0]=t;a[:,6]=9.81
  a=a[(a[:,0]<=10)|(a[:,0]>=30)]
  self.assertEqual(m.imu_evidence(a,31)['state'],'UNAVAILABLE')
  self.assertEqual(m.imu_evidence(a,51)['state'],'WEAK')
  self.assertEqual(m.imu_evidence(a,51),m.imu_evidence(a[a[:,0]<=51],51))
if __name__=='__main__':unittest.main(verbosity=2)
