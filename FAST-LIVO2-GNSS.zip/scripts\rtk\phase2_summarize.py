#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarize the Phase-2 RTK tight-coupling run against the Phase-0 baseline."""
import csv
import os
import re
import statistics

REG = "/home/slxc9426/catkin_ws/src/fast_livo/Log/result/registry.csv"
LOG = "/home/slxc9426/seg_phase2_c01_rtk_full1.log"
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/metrics"
BASE_TAGS = ["phase0_c01_livo", "phase0_c01_livo_r2", "phase0_c01_livo_r3"]

FIELDS = [
    ("r3_full", "full_3D"), ("r2_full", "full_2D"),
    ("r3_steady", "steady_3D"), ("r2_steady", "steady_2D"),
    ("rpe1", "RPE_1s"), ("rpe10", "RPE_10s"),
    ("rpe60", "RPE_60s"), ("rpe120", "RPE_120s"),
    ("r2_statloc", "static_loc_2D"),
]


def load_registry():
    with open(REG, newline="") as f:
        return list(csv.DictReader(f))


def main():
    rows = load_registry()
    by_tag = {r["tag"]: r for r in rows}
    base = [by_tag[t] for t in BASE_TAGS if t in by_tag]
    rtk = by_tag.get("phase2_c01_rtk_full1")
    smoke = by_tag.get("phase2_c01_rtk_smoke9")
    pure90 = by_tag.get("pure90")
    if not base or rtk is None:
        raise SystemExit("missing baseline or RTK registry rows")

    out_rows = [("metric", "baseline_median", "baseline_min", "baseline_max",
                 "rtk_full1", "delta_vs_median")]
    print("metric                 base_med   base_min   base_max   rtk_full1   delta")
    for key, label in FIELDS:
        vals = [float(r[key]) for r in base if r.get(key)]
        rv = float(rtk[key])
        med, lo, hi = statistics.median(vals), min(vals), max(vals)
        out_rows.append((label, f"{med:.4f}", f"{lo:.4f}", f"{hi:.4f}",
                         f"{rv:.4f}", f"{rv - med:+.4f}"))
        print(f"{label:22s} {med:8.4f} {lo:9.4f} {hi:9.4f} {rv:10.4f} {rv-med:+8.4f}")

    with open(os.path.join(OUT, "phase2_rtk_summary.csv"), "w", newline="", encoding="utf-8") as f:
        csv.writer(f).writerows(out_rows)

    # 90 s smoke vs pure LIVO first 90 s
    lines = []
    if smoke is not None and pure90 is not None:
        for key, label in [("r3_full", "3D"), ("r2_full", "2D"), ("rpe1", "RPE1")]:
            s = float(smoke[key]); p = float(pure90[key])
            lines.append(f"90s {label}: pureLIVO={p:.4f} RTK={s:.4f} delta={s-p:+.4f}")
            print(lines[-1])

    # Health from the full log
    acc_re = re.compile(r"\[RTK\] accept t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+)/([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+) "
                        r"\|dx_pos\|=([\d.]+) P_pos=([\d.]+)")
    rej_re = re.compile(r"\[RTK\] reject t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+) gate=([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+)")
    acc, rej = [], []
    with open(LOG, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = acc_re.search(line)
            if m:
                acc.append(dict(t=float(m.group(1)), pairs=int(m.group(2)),
                                amb=int(m.group(3)), slips=int(m.group(4)),
                                gamma=float(m.group(5)), gate=float(m.group(6)),
                                code=float(m.group(7)), phase=float(m.group(8)),
                                dx=float(m.group(9)), ppos=float(m.group(10))))
                continue
            m = rej_re.search(line)
            if m:
                rej.append(dict(t=float(m.group(1)), pairs=int(m.group(2)),
                                amb=int(m.group(3)), slips=int(m.group(4)),
                                gamma=float(m.group(5)), gate=float(m.group(6)),
                                code=float(m.group(7)), phase=float(m.group(8))))
    n = len(acc) + len(rej)
    health = [
        f"updates evaluated={n} accepted={len(acc)} rejected={len(rej)} "
        f"acceptance={100.0*len(acc)/max(n,1):.1f}%",
        f"last accepted: t={acc[-1]['t']:.1f} pairs={acc[-1]['pairs']} amb={acc[-1]['amb']} "
        f"gamma={acc[-1]['gamma']:.1f}/{acc[-1]['gate']:.1f} "
        f"|r_code|={acc[-1]['code']:.2f} |r_phase|={acc[-1]['phase']:.2f} "
        f"|dx_pos|={acc[-1]['dx']:.3f} P_pos={acc[-1]['ppos']:.3f}",
        f"median accepted |dx_pos|={statistics.median([a['dx'] for a in acc]):.3f} m, "
        f"max={max(a['dx'] for a in acc):.3f} m",
        f"median accepted gamma={statistics.median([a['gamma'] for a in acc]):.2f}, "
        f"final n_amb={acc[-1]['amb']}, total slips reset={sum(a['slips'] for a in acc)}",
    ]
    with open(os.path.join(OUT, "phase2_rtk_health.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(health + lines) + "\n")
    print("\n".join(health))


if __name__ == "__main__":
    main()
