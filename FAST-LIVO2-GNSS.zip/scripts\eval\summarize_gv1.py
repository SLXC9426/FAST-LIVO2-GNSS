#!/usr/bin/env python3
"""Summarize the N=3 GV1 graph batch (graph_summary.txt) without a registry.

Parses the blocks printed by global_position_graph.py and reports per-dataset
medians for the LIVO / RTK-only / GRAPH arms.
"""
import re
import statistics
import sys
from collections import defaultdict

MET = re.compile(r"2D_RMSE=([0-9.]+)")
RUN = re.compile(r"==\s+(gv1_\w+)\s+==")
ARM = re.compile(r"==\s+(LIVO \(keyframes\)|RTK-only \(interp\)|GRAPH)\s+==")


def main(path):
    rows = []
    cur_run = cur_arm = None
    for line in open(path, encoding="utf-8", errors="replace"):
        m = RUN.search(line)
        if m:
            cur_run = m.group(1)
            cur_arm = None
            continue
        m = ARM.search(line)
        if m and cur_run:
            cur_arm = m.group(1)
            continue
        if not (cur_run and cur_arm):
            continue
        s = line.strip()
        key = None
        if s.startswith("full"):
            key = "full"
        elif s.startswith("steady"):
            key = "steady"
        elif s.startswith("movfit"):
            key = "movfit"
        elif s.startswith("static-loc pooled"):
            key = "static"
        elif s.startswith("win "):
            parts = s.split()
            if len(parts) >= 2:
                key = "win " + parts[1].rstrip(":")
        if key:
            m = MET.search(s)
            if m:
                rows.append((cur_run, cur_arm, key, float(m.group(1))))

    by = defaultdict(lambda: defaultdict(list))
    for run, arm, key, val in rows:
        seq = "c01" if "campus01" in run else "c02"
        by[(seq, arm)][key].append(val)

    print("%-4s %-18s %8s %8s %8s %8s %5s" %
          ("seq", "arm", "full", "steady", "movfit", "static", "n"))
    for (seq, arm) in sorted(by):
        d = by[(seq, arm)]
        n = len(d.get("full", []))
        def med(k):
            v = d.get(k, [])
            return statistics.median(v) if v else float("nan")
        def spread(k):
            v = d.get(k, [])
            return (max(v) - min(v)) if len(v) >= 2 else float("nan")
        def cell(k):
            v = d.get(k, [])
            return "%.4f(%.4f)" % (med(k), spread(k)) if v else "n/a"
        print("%-4s %-18s %8s %8s %8s %8s %5d" %
              (seq, arm, cell("full"), cell("steady"), cell("movfit"),
               cell("static"), n))

    print("\nT0-2 verdicts (|d_median| vs max within-group spread; n=3)")
    for seq in ("c01", "c02"):
        for metric in ("full", "steady", "movfit", "static"):
            g = by[(seq, "GRAPH")][metric]
            for arm in ("LIVO (keyframes)", "RTK-only (interp)"):
                b = by[(seq, arm)][metric]
                if not (g and b):
                    continue
                d = abs(statistics.median(g) - statistics.median(b))
                floor = max(max(g) - min(g), max(b) - min(b))
                v = "REAL" if d > floor else "NOT RESOLVABLE"
                print("  %s %-7s GRAPH vs %-18s |d|=%.4f floor=%.4f -> %s" %
                      (seq, metric, arm, d, floor, v))

    wins = sorted({k for (seq, arm) in by for k in by[(seq, arm)]
                   if k.startswith("win ")})
    if wins:
        print("\nWindow medians (2D, n=3) and GRAPH vs LIVO")
        for seq in ("c01", "c02"):
            for w in wins:
                g = by[(seq, "GRAPH")].get(w, [])
                l = by[(seq, "LIVO (keyframes)")].get(w, [])
                if not (g and l):
                    continue
                d = abs(statistics.median(g) - statistics.median(l))
                floor = max(max(g) - min(g), max(l) - min(l))
                v = "REAL" if d > floor else "NOT RESOLVABLE"
                print("  %s %-12s GRAPH %.4f  LIVO %.4f  |d|=%.4f floor=%.4f -> %s" %
                      (seq, w, statistics.median(g), statistics.median(l),
                       d, floor, v))


if __name__ == "__main__":
    main(sys.argv[1] if len(sys.argv) > 1 else
         "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/gv1/graph/graph_summary.txt")
