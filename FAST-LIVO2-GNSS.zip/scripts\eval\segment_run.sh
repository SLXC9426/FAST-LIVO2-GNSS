#!/bin/bash
# Fast, deterministic-input segment run for iteration (A1).
#
# Why segments: the estimator is chaotically sensitive to tiny numerical
# differences, so two runs of the SAME configuration diverge by ~0.12 m over
# 60 s, ~0.5 m over 120 s, ~2.5 m over 607 s (measured, see
# docs/EVAL_PROTOCOL.md). A 60-120 s segment therefore buys a 5-10x faster
# iteration loop with a much tighter noise band, and full-length runs are only
# needed for milestone numbers.
#
# The run waits until the output stops growing before killing the node, so the
# input stream is consumed in full and no frame is dropped (drops were the
# source of the earlier "different line count" between runs).
#
# Usage:
#   segment_run.sh <campus01|campus02|campus03> <livo|gnss> <start_s> <dur_s> <tag> [rtk_bag] [topic_override] [cfg_name]
# (no `set -u` here: the ROS setup scripts reference unset variables)
export LANG=C.UTF-8
set -o pipefail
SEQ=$1; MODE=$2; START=$3; DUR=$4; TAG=$5; RTKBAG=${6:-}; TOPICOV=${7:-}; CFGOV=${8:-}
# Long c03 runs can lag behind the bag; 40*4s may kill before the node drains.
DRAIN_ITERS=${DRAIN_ITERS:-40}
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
# cfg_name defaults to the sequence's main config. The 8th argument is needed for
# the factor-graph line, which runs the *_graph / *_improved_gnss configs rather
# than great_<seq>.yaml (R3 stage 2 / WP4 evaluation).
CFGNAME=${CFGOV:-great_${SEQ}}
CFG=config/${CFGNAME}.yaml
REF=~/eval_great/${SEQ}_reference.tum
if [ ! -f "$CFG" ]; then
  echo "[segment_run] config not found: $CFG"; exit 1
fi
# The run scripts rewrite gnss_en / gnss_topic / seq_name in place. Back the
# config up and restore it on exit so a failed run cannot leave the workspace
# in a batch-specific state.
CFG_BAK=$(mktemp)
cp "$CFG" "$CFG_BAK"
trap 'cp "$CFG_BAK" "$CFG" 2>/dev/null; rm -f "$CFG_BAK"' EXIT

case "$SEQ" in
  campus01) BAG=~/datasets/GREAT/campus-01-full.bag ;;
  campus02) BAG=~/datasets/GREAT/campus-02.bag ;;
  campus03) BAG=~/datasets/GREAT/campus-03.bag ;;
  *) echo "unknown sequence $SEQ"; exit 1 ;;
esac

if [ "$MODE" = "livo" ]; then
  sed -i 's/^  gnss_en: .*/  gnss_en: false/' $CFG
else
  sed -i 's/^  gnss_en: .*/  gnss_en: true/' $CFG
fi
case "$SEQ" in
  campus01) sed -i 's|^  gnss_topic: .*|  gnss_topic: "/gnss_rtk"|' $CFG ;;
  *)        sed -i 's|^  gnss_topic: .*|  gnss_topic: "/gnss"|' $CFG ;;
esac
# Optional GNSS topic override (7th arg): used when a sequence is re-run against
# a newly solved observation stream, e.g. campus-02 with a 1 Hz RTK solution.
if [ -n "$TOPICOV" ]; then
  sed -i "s|^  gnss_topic: .*|  gnss_topic: \"$TOPICOV\"|" $CFG
fi
sed -i "s/^  seq_name: .*/  seq_name: \"$TAG\"/" $CFG
RES=Log/result/${TAG}.txt
LOG=$HOME/seg_${TAG}.log
if { [ -e "$RES" ] || [ -e "$LOG" ]; } && [ "${FORCE:-0}" != "1" ]; then
  echo "[segment_run] refusing to overwrite TAG=$TAG ($RES / $LOG exists)."
  echo "[segment_run]   use a unique tag, or set FORCE=1 to overwrite deliberately."
  exit 2
fi
: > "$RES"

# clean leftovers before starting (patterns live in kill_ros.sh, NOT in this
# command line: pkill -f matching its own caller was killing the run itself)
bash "$(dirname "$0")/kill_ros.sh"
rm -f "$RES"; : > "$RES"

roslaunch fast_livo mapping_great.launch rviz:=false seq_name:=$TAG cfg:=$CFGNAME > "$LOG" 2>&1 &
MP=$!
sleep 8
if [ "$MODE" = "gnss" ] && [ -n "$RTKBAG" ]; then
  rosbag play -q --queue 5000 -s $START -u $DUR "$BAG" "$RTKBAG" > /dev/null 2>&1 &
else
  rosbag play -q --queue 5000 -s $START -u $DUR "$BAG" > /dev/null 2>&1 &
fi
PP=$!
wait $PP 2>/dev/null || true

# drain: wait until the output stops growing (guarantees the full input is used)
last=-1; stable=0
for i in $(seq 1 "$DRAIN_ITERS"); do
  sleep 4
  n=$(wc -l < "$RES" 2>/dev/null || echo 0)
  if [ "$n" = "$last" ]; then stable=$((stable+1)); else stable=0; fi
  last=$n
  [ "$stable" -ge 3 ] && break
done
kill -9 $MP 2>/dev/null || true
bash "$(dirname "$0")/kill_ros.sh"
echo "[segment_run] $TAG: $(wc -l < "$RES") lines"

python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main/scripts/eval/eval_unified.py \
    "$RES" "$REF" "$TAG" --config "$CFG"
EVAL_RC=$?
# T0-3: fusion health block from the node log (visible in the iteration loop,
# not only in milestone batches). Diagnostic only: a livo arm has no GNSS block.
python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main/scripts/eval/fusion_health.py \
    "$LOG"
exit $EVAL_RC
