#!/usr/bin/env python3
"""
check_params.py - verify that every config key read by the C++ code exists in
the YAML configs (and vice versa). A missing key silently falls back to the
C++ default, so this catches typos that would otherwise disable a feature.

Usage: python3 scripts/check_params.py
"""

import io
import os
import re

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

# ---- keys read by the C++ code (nh.param calls) ----
CPP_FILES = [
    "src/voxel_map.cpp",
    "src/LIVMapper.cpp",
    "src/vio.cpp",
    "src/IMU_Processing.cpp",
    "src/preprocess.cpp",
]
read_keys = set()
for f in CPP_FILES:
    p = os.path.join(ROOT, f)
    if not os.path.exists(p):
        continue
    src = io.open(p, encoding="utf-8-sig").read()
    for m in re.finditer(r'nh\.param[^("]*\(\s*"([^"]+)"', src):
        read_keys.add(m.group(1))

# ---- keys present in the YAML configs ----
YAML_FILES = [
    "config/avia.yaml",
    "config/avia_improved.yaml",
    "config/great_campus01.yaml",
    "config/great_campus01_improved.yaml",
    "config/NTU_VIRAL.yaml",
    "config/NTU_VIRAL_improved.yaml",
    "config/great_urban01_baseline.yaml",
    "config/great_urban01_occlusion.yaml",
    "config/great_urban01_dynamic.yaml",
    "config/great_urban01_graph.yaml",
    "config/great_urban01_improved.yaml",
    "config/great_urban01_improved_gnss.yaml",
]
yaml_keys = set()
for f in YAML_FILES:
    p = os.path.join(ROOT, f)
    if not os.path.exists(p):
        continue
    for line in io.open(p, encoding="utf-8-sig"):
        line = line.split("#")[0].rstrip()
        if not line or line[0] in " \t":
            continue
        m = re.match(r"^([A-Za-z0-9_]+):", line)
        if m:
            yaml_keys.add(m.group(1))

print("keys read by C++ but missing from EVERY yaml (would use defaults):")
missing = sorted(k for k in read_keys if k.split("/")[0] not in yaml_keys)
# note: yaml keys are top-level sections; a read key "lio/x" needs section "lio"
for k in sorted(read_keys):
    section = k.split("/")[0]
    if section not in yaml_keys:
        missing.append(k)
missing = sorted(set(missing))
if missing:
    for k in missing:
        print(f"  [WARN] {k}")
else:
    print("  none")

print("\nnew-feature keys present in *_improved.yaml:")
for f in YAML_FILES:
    if "improved" not in f:
        continue
    present = []
    for line in io.open(os.path.join(ROOT, f), encoding="utf-8-sig"):
        m = re.match(r"^([A-Za-z0-9_]+):", line)
        if m and m.group(1) in ("occlusion", "dynamic_remove", "factor_graph"):
            present.append(m.group(1))
        if re.match(r"^  (latency_en|robust_kernel_type|robust_delta|reject_gate_scale):", line):
            present.append(line.split(":")[0].strip())
    print(f"  {os.path.basename(f)}: {sorted(set(present))}")
