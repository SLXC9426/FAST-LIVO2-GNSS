#ifndef GNSS_ALIGNMENT_STATE_H
#define GNSS_ALIGNMENT_STATE_H

#include <Eigen/Dense>
#include <cmath>

// T1-4: slow-varying ENU->world alignment state (docs/T1_4_DESIGN.md).
//
// The alignment transform (enu_R_world / enu_t_world) is normally fitted once
// at lock and never touched again, so the LIO drift that accumulated inside
// the fit window biases every later update (the c01 constant-pull mechanism,
// EVAL_PROTOCOL 0.2/16.6). This filter owns the COVARIANCE of the alignment
// correction state x_a = [dpsi, dte, dtn] (yaw about the world-Z axis +
// horizontal translation, INTERNAL frame) as a slow random walk, updated from
// the same GNSS innovation the trajectory uses. The caller (LIVMapper) folds
// each returned correction into the transform itself, so the state mean stays
// zero here and only P carries information between epochs.
//
// Design contracts (review-fixed semantics, T1_4_DESIGN 2.4/10.1):
//  * FROZEN (report-hold active) means BOTH no process noise AND no measurement
//    update: during a hold the translation is perfectly observable from a
//    single static fix and would chase the internal walk + GNSS scatter, which
//    is harmful, not uninformative. A frozen epoch must leave P bitwise
//    unchanged (asserted in gnss_processing_selftest).
//  * The update takes the JOINT innovation covariance S (which already
//    contains H_a P H_a^T) so trajectory and alignment share one consistent
//    gain split. The caller passes P_xa = 0 (parallel-prior approximation,
//    T1_4_DESIGN 5): the discarded posterior cross term is the documented
//    cost, logged by the caller.
//  * Every correction is clamped per epoch (|dpsi|, |dt|) so one outlier fix
//    cannot drag the transform.

struct GnssAlignState
{
  bool initialised = false;
  Eigen::Matrix3d P = Eigen::Matrix3d::Zero(); // covariance of [dpsi, dte, dtn]
  double last_t = -1.0;                        // time bookkeeping for the walk

  void initAtLock(double sigma_yaw_rad, double sigma_t, double t_now)
  {
    P = Eigen::Matrix3d::Zero();
    P(0, 0) = sigma_yaw_rad * sigma_yaw_rad;
    P(1, 1) = sigma_t * sigma_t;
    P(2, 2) = sigma_t * sigma_t;
    last_t = t_now;
    initialised = true;
  }

  // Random-walk accrual. dt is measured against the previous EVALUATED epoch
  // (last_t advances even when frozen, so frozen time never contributes noise
  // after release and dt never spans a hold).
  void propagate(double t_now, double q_yaw_rad2_per_s, double q_pos_m2_per_s,
                 bool frozen)
  {
    const double dt = t_now - last_t;
    last_t = t_now;
    if (!initialised || frozen || dt <= 0.0)
      return;
    P(0, 0) += q_yaw_rad2_per_s * dt;
    P(1, 1) += q_pos_m2_per_s * dt;
    P(2, 2) += q_pos_m2_per_s * dt;
  }

  // Authority cap (redesign (b'), EVAL_PROTOCOL 26.3): limit the alignment
  // state's share of every future innovation to K_max by capping P against the
  // CURRENT update noise scale: P_ii <= K_max/(1-K_max) * r_eff. Applied every
  // epoch, this makes K_a = P/(P+R) <= K_max a structural invariant - the
  // "worse data must not get more authority" monotonicity rule holds for all
  // epochs, not just the lock (this is where the review's raw residual^2
  // initialization failed on c03: 8 m^2 of prior against 0.09 m^2 of R).
  // r_eff is the horizontal measurement variance in use at this epoch.
  void capAuthority(double kmax_over_1mk, double r_eff)
  {
    if (!initialised || kmax_over_1mk <= 0.0 || r_eff <= 0.0)
      return;
    const double cap = kmax_over_1mk * r_eff;
    for (int k = 0; k < 3; k++)
      if (P(k, k) > cap)
        P(k, k) = cap;
  }

  // H_a (n_obs x 3): position rows [ -v_y, 1, 0 ; v_x, 0, 1 ; 0, 0, 0 ] with
  // v = R * enu_meas (the yaw lever about world-Z); velocity rows get only the
  // yaw coupling with w = R * enu_vel; the vertical row is always zero
  // (the vertical channel stays adaptive-only). In anchored (relative) mode
  // the anchor cancels the translation identically, so the caller passes
  // translation_observable = false and the translation columns stay zero.
  static Eigen::Matrix<double, Eigen::Dynamic, 3>
  haMatrix(const Eigen::Vector3d &v_pos, bool has_vel,
           const Eigen::Vector3d &v_vel, bool translation_observable)
  {
    const int n_obs = has_vel ? 6 : 3;
    Eigen::Matrix<double, Eigen::Dynamic, 3> H_a =
        Eigen::Matrix<double, Eigen::Dynamic, 3>::Zero(n_obs, 3);
    H_a(0, 0) = -v_pos(1);
    H_a(1, 0) = v_pos(0);
    if (translation_observable)
    {
      H_a(0, 1) = 1.0;
      H_a(1, 2) = 1.0;
    }
    if (has_vel)
    {
      H_a(3, 0) = -v_vel(1);
      H_a(4, 0) = v_vel(0);
    }
    return H_a;
  }

  // One alignment update. Returns the clamped correction [dpsi, dte, dtn];
  // a frozen (or uninitialised) epoch returns zero and leaves P bitwise
  // unchanged. Two clamp families, both applied as ROW SCALES of K_a so the
  // posterior stays consistent with the correction actually applied:
  //   * absolute per-epoch step caps (max_dyaw_step, max_dt_step);
  //   * physical rate caps (redesign (c)): max_dt_rate is the LIO drift rate
  //     b, so |dt_fold| <= b*dt - the transform can never be dragged faster
  //     than the LIO physically drifts (kills the "swallow 25 m of
  //     disagreement" path at the mechanism level). Applied to the
  //     TRANSLATION only: the c01 evidence (EVAL_PROTOCOL 26.5) shows the yaw
  //     channel's useful action includes large initial corrections that a
  //     b/span rate cap would suffocate; pass max_dyaw_rate = 0 to disable.
  //     dt is the fix interval (rate caps are skipped when dt <= 0).
  Eigen::Vector3d update(const Eigen::Matrix<double, Eigen::Dynamic, 3> &H_a,
                         const Eigen::MatrixXd &S, const Eigen::VectorXd &res,
                         double max_dyaw_step, double max_dt_step,
                         double max_dyaw_rate, double max_dt_rate, double dt,
                         bool frozen)
  {
    if (!initialised || frozen)
      return Eigen::Vector3d::Zero();
    // K_a = P H_a^T S^{-1}; computed as (S^{-1} H_a P)^T - one LLT solve with
    // the symmetric S and P (solve(S, H_a*P) is n_obs x 3, transposed to 3 x n).
    const Eigen::MatrixXd Ka =
        S.llt().solve(Eigen::MatrixXd(H_a * P)).transpose();
    const Eigen::Vector3d da_raw = Ka * res;
    double lim_yaw = max_dyaw_step;
    if (max_dyaw_rate > 0.0 && dt > 0.0)
      lim_yaw = std::min(lim_yaw, max_dyaw_rate * dt);
    double lim_t = max_dt_step;
    if (max_dt_rate > 0.0 && dt > 0.0)
      lim_t = std::min(lim_t, max_dt_rate * dt);
    double s0 = 1.0, sT = 1.0;
    if (lim_yaw > 0.0 && std::fabs(da_raw(0)) > lim_yaw)
      s0 = lim_yaw / std::fabs(da_raw(0));
    const double nt = std::sqrt(da_raw(1) * da_raw(1) + da_raw(2) * da_raw(2));
    if (lim_t > 0.0 && nt > lim_t)
      sT = lim_t / nt;
    const Eigen::Matrix3d Scl =
        (Eigen::Vector3d(s0, sT, sT)).asDiagonal();
    const Eigen::MatrixXd Ka_s = Scl * Ka;
    P = (Eigen::Matrix3d::Identity() - Ka_s * H_a) * P;
    P = 0.5 * (P + P.transpose().eval()); // keep the 3x3 symmetric
    return Ka_s * res;
  }
};

#endif // GNSS_ALIGNMENT_STATE_H
