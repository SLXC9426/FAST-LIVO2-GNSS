#!/usr/bin/env python3
"""Inspect campus gnss.pos span; write corrected TUM reference (lat/lon -> ENU)."""
import math
import os

SRC = "/home/slxc9426/datasets/GREAT/GNSS/gnss.pos"
OUT = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/campus01_reference.tum"

OFFSET = 604800 * 2129 + 315964800 - 18  # GPS -> UNIX
A = 6378137.0
F = 1.0 / 298.257223563
E2 = F * (2.0 - F)


def lla2ecef(lat, lon, h):
    lat, lon = math.radians(lat), math.radians(lon)
    N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
    x = (N + h) * math.cos(lat) * math.cos(lon)
    y = (N + h) * math.cos(lat) * math.sin(lon)
    z = (N * (1 - E2) + h) * math.sin(lat)
    return x, y, z


rows = []
with open(SRC) as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        v = line.split()
        rows.append((float(v[0]), float(v[1]), float(v[2]), float(v[3])))

print("rows:", len(rows), "t:", rows[0][0], "~", rows[-1][0], "span:", rows[-1][0] - rows[0][0], "s")
lats = [r[1] for r in rows]
lons = [r[2] for r in rows]
print("lat: %.8f ~ %.8f, lon: %.8f ~ %.8f" % (min(lats), max(lats), min(lons), max(lons)))

# ENU origin = first row
x0, y0, z0 = lla2ecef(lats[0], lons[0], rows[0][3])
lat0, lon0 = math.radians(lats[0]), math.radians(lons[0])
lines = []
for t, la, lo, h in rows:
    x, y, z = lla2ecef(la, lo, h)
    dx, dy, dz = x - x0, y - y0, z - z0
    e = -math.sin(lon0) * dx + math.cos(lon0) * dy
    n = -math.sin(lat0) * math.cos(lon0) * dx - math.sin(lat0) * math.sin(lon0) * dy + math.cos(lat0) * dz
    u = math.cos(lat0) * math.cos(lon0) * dx + math.cos(lat0) * math.sin(lon0) * dy + math.sin(lat0) * dz
    lines.append("%.9f %.4f %.4f %.4f 0.0 0.0 0.0 1.0" % (t + OFFSET, e, n, u))

with open(OUT, "w") as f:
    f.write("\n".join(lines) + "\n")
# span check
import numpy as np

es = np.array([float(l.split()[1]) for l in lines])
ns = np.array([float(l.split()[2]) for l in lines])
d = np.sqrt((es - es[0]) ** 2 + (ns - ns[0]) ** 2)
cum = np.sum(np.sqrt(np.diff(es) ** 2 + np.diff(ns) ** 2))
print("ENU: e %.1f~%.1f n %.1f~%.1f, max dist %.1f m, cum %.1f m" % (es.min(), es.max(), ns.min(), ns.max(), d.max(), cum))
print("wrote", OUT, len(lines), "lines")
