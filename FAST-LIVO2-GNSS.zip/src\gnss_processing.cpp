/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with RTK/GNSS tight-coupling support.

GNSS Processing Module Implementation
*/

#include "gnss_processing.h"
#include <cmath>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

GnssProcess::GnssProcess()
  : origin_set_(false),
    gnss_offset_(V3D::Zero())
{
}

GnssProcess::~GnssProcess()
{
}

void GnssProcess::setOrigin(double lat0, double lon0, double alt0)
{
  lat0_rad_ = lat0 * M_PI / 180.0;
  lon0_rad_ = lon0 * M_PI / 180.0;
  alt0_ = alt0;

  sin_lat0_ = sin(lat0_rad_);
  cos_lat0_ = cos(lat0_rad_);
  sin_lon0_ = sin(lon0_rad_);
  cos_lon0_ = cos(lon0_rad_);

  // Compute ECEF of origin
  wgs84ToEcef(lat0, lon0, alt0, ecef_origin_);
  origin_set_ = true;
}

void GnssProcess::wgs84ToEcef(double lat, double lon, double alt, V3D &ecef)
{
  double lat_rad = lat * M_PI / 180.0;
  double lon_rad = lon * M_PI / 180.0;

  double sin_lat = sin(lat_rad);
  double cos_lat = cos(lat_rad);
  double sin_lon = sin(lon_rad);
  double cos_lon = cos(lon_rad);

  double N = WGS84_A / sqrt(1.0 - WGS84_E2 * sin_lat * sin_lat);

  ecef(0) = (N + alt) * cos_lat * cos_lon;
  ecef(1) = (N + alt) * cos_lat * sin_lon;
  ecef(2) = (N * (1.0 - WGS84_E2) + alt) * sin_lat;
}

void GnssProcess::wgs84ToEnu(double lat, double lon, double alt,
                             double &e, double &n, double &u)
{
  if (!origin_set_)
  {
    e = 0.0;
    n = 0.0;
    u = 0.0;
    return;
  }

  V3D ecef_point;
  wgs84ToEcef(lat, lon, alt, ecef_point);

  V3D ecef_diff = ecef_point - ecef_origin_;

  // ECEF to ENU rotation matrix
  // ENU = R * (ECEF - ECEF_origin)
  // where R = [ -sin_lon  cos_lon  0;
  //             -sin_lat*cos_lon  -sin_lat*sin_lon  cos_lat;
  //              cos_lat*cos_lon   cos_lat*sin_lon  sin_lat ]
  e = -sin_lon0_ * ecef_diff(0) + cos_lon0_ * ecef_diff(1);
  n = -sin_lat0_ * cos_lon0_ * ecef_diff(0) 
      - sin_lat0_ * sin_lon0_ * ecef_diff(1) 
      + cos_lat0_ * ecef_diff(2);
  u = cos_lat0_ * cos_lon0_ * ecef_diff(0) 
      + cos_lat0_ * sin_lon0_ * ecef_diff(1) 
      + sin_lat0_ * ecef_diff(2);
}

// R3 stage 4 (L2): ECEF velocity -> local ENU velocity. Same rotation as
// wgs84ToEnu applies to the ECEF difference, but without the origin subtraction:
// a velocity is a free vector. Keeping this here (rather than having the bag
// converter bake an ENU frame in) means the velocity and the positions are always
// expressed in the SAME local frame, whichever origin the node chose.
void GnssProcess::ecefToEnuVector(double x, double y, double z,
                                  double &e, double &n, double &u)
{
  if (!origin_set_)
  {
    e = 0.0;
    n = 0.0;
    u = 0.0;
    return;
  }

  e = -sin_lon0_ * x + cos_lon0_ * y;
  n = -sin_lat0_ * cos_lon0_ * x - sin_lat0_ * sin_lon0_ * y + cos_lat0_ * z;
  u = cos_lat0_ * cos_lon0_ * x + cos_lat0_ * sin_lon0_ * y + sin_lat0_ * z;
}

void GnssProcess::enuToWgs84(double e, double n, double u,
                             double &lat, double &lon, double &alt)
{
  if (!origin_set_)
  {
    lat = 0.0;
    lon = 0.0;
    alt = 0.0;
    return;
  }

  // ENU to ECEF rotation (transpose of ECEF-to-ENU)
  double dx = -sin_lon0_ * e - sin_lat0_ * cos_lon0_ * n + cos_lat0_ * cos_lon0_ * u;
  double dy = cos_lon0_ * e - sin_lat0_ * sin_lon0_ * n + cos_lat0_ * sin_lon0_ * u;
  double dz = cos_lat0_ * n + sin_lat0_ * u;

  V3D ecef_point = ecef_origin_ + V3D(dx, dy, dz);

  // ECEF to WGS84 (Bowring's closed-form solution)
  double x = ecef_point(0);
  double y = ecef_point(1);
  double z = ecef_point(2);

  double p = sqrt(x * x + y * y);
  // WP6: the denominator must be p * b (b = a(1-f) ~= 6356752.314). It used to be
  // p * (1 - e2*a) ~= -42696 - negative and orders of magnitude off, which put the
  // atan2 in the wrong quadrant and made the whole inverse wrong.
  double theta = atan2(z * WGS84_A, p * WGS84_B);

  double sin_theta = sin(theta);
  double cos_theta = cos(theta);

  // WP6: the numerator needs the SECOND eccentricity (ep2*b ~= 42842); the old
  // e2*a ~= 42697 was numerically close but not the same quantity.
  lat = atan2(z + WGS84_EP2 * WGS84_B * sin_theta * sin_theta * sin_theta,
              p - WGS84_E2 * WGS84_A * cos_theta * cos_theta * cos_theta);
  lon = atan2(y, x);

  double sin_lat = sin(lat);
  double cos_lat = cos(lat);
  double N = WGS84_A / sqrt(1.0 - WGS84_E2 * sin_lat * sin_lat);
  // WP6: standard altitude form. p / cos(lat) degenerates near the poles, where
  // cos(lat) -> 0 (the old expression lost precision and could divide by ~0).
  // From p = (N+h)cos(lat), z = (N(1-e2)+h)sin(lat) and N(1-e2 sin^2) = a^2/N:
  alt = p * cos_lat + z * sin_lat - WGS84_A * WGS84_A / N;

  lat = lat * 180.0 / M_PI;
  lon = lon * 180.0 / M_PI;
}

double GnssProcess::getHorizontalCov(int fix_type)
{
  // yaml-calibrated override wins over the fix-type table
  if (horiz_sigma_override_ > 0.0) return horiz_sigma_override_;

  // Position noise standard deviation (meters).
  // Calibrated against GREAT campus-02: the raw RTK epochs in the dataset bag
  // carry ~1-2 m horizontal error vs the post-processed reference (30 s
  // sampling, mixture of Fixed/Float). cm-level assumptions cause the
  // chi-square gate to reject nearly every update, so the fusion degrades to
  // pure LIVO. These values keep the gate consistent with the real data.
  switch (fix_type)
  {
  case GNSS_RTK_FIXED:
  case GNSS_PHASE_FIX:
    return sig_fixed_;   // 1.2 m - RTK fixed (dataset-calibrated)
  case GNSS_PHASE_FLOAT:
    return sig_float_;   // 2.5 m - RTK float
  case GNSS_DGPS:
    return sig_dgps_;    // 3 m - DGPS
  case GNSS_SINGLE:
    return sig_single_;  // 5 m - single point
  default:
    return 100.0;        // invalid
  }
}

double GnssProcess::getVerticalCov(int fix_type)
{
  if (vert_sigma_override_ > 0.0) return vert_sigma_override_;

  // Vertical is typically ~1.5-2x worse than horizontal
  return getHorizontalCov(fix_type) * 1.8;
}

bool GnssProcess::isFixValid(int fix_type)
{
  // Accept single-point and better (0=single, 2=float, 4/5=RTK fixed)
  return fix_type >= GNSS_SINGLE;
}

bool GnssProcess::isFixGoodEnoughForInit(int fix_type)
{
  // Single-point and better is enough to set the ENU origin
  return fix_type >= GNSS_SINGLE;
}

void GnssProcess::setGnssExtrinsic(const V3D &transl)
{
  gnss_offset_ = transl;
}
