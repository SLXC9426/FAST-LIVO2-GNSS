import hashlib
import os

a = r"D:\BaiduNetdiskDownload\Urban-01\Sensor_Params\Sensor_Parameters\2020-10-27\extrinsic_parameters.xml"
b = r"D:\BaiduNetdiskDownload\Sensor_Parameters\Sensor_Parameters\2020-10-27\extrinsic_parameters.xml"
print("urban file exists:", os.path.exists(a))
print("campus file exists:", os.path.exists(b))
if os.path.exists(a) and os.path.exists(b):
    ha = hashlib.md5(open(a, "rb").read()).hexdigest()
    hb = hashlib.md5(open(b, "rb").read()).hexdigest()
    print("urban md5 :", ha)
    print("campus md5:", hb)
    print("IDENTICAL" if ha == hb else "DIFFERENT")
    if ha != hb:
        ta = open(a, encoding="utf-8", errors="ignore").read()
        tb = open(b, encoding="utf-8", errors="ignore").read()
        print("urban LIDAR_T_IMU:", ta.split("<LIDAR_T_IMU>")[1].split("</LIDAR_T_IMU>")[0].strip()[:160])
        print("campus LIDAR_T_IMU:", tb.split("<LIDAR_T_IMU>")[1].split("</LIDAR_T_IMU>")[0].strip()[:160])
        print("urban IMU_T_cam0:", ta.split("<IMU_T_cam0>")[1].split("</IMU_T_cam0>")[0].strip()[:160])
        print("campus IMU_T_cam0:", tb.split("<IMU_T_cam0>")[1].split("</IMU_T_cam0>")[0].strip()[:160])
