import pandas as pd
import numpy as np

p = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
d = pd.read_csv(p)
print("rows", len(d), "epochs", d.t_gps.nunique())
print("slip counts", d.slip.value_counts().to_dict())
print("ref_change counts", d.ref_change.value_counts().to_dict())
print(d.groupby(["sys", "freq"]).size())
st = d[(d.t_gps >= 1603764590) & (d.t_gps <= 1603764616)]
print("static rows", len(st), "epochs", st.t_gps.nunique())
print(st.groupby(["sys", "freq", "slip"]).size())
print(st[["t_gps", "sys", "freq", "ref_sat", "sat", "dd_code", "dd_phase",
         "slip", "ref_change", "gf_jump", "doppler_res"]].head(20).to_string())

s = st[st.slip == 1]
print("\nslip=1 diagnostics:")
print(s[["gf_jump", "doppler_res"]].describe().to_string())
print("gf>0.05:", int((s.gf_jump.abs() > 0.05).sum()),
      "dop>0.10:", int((s.doppler_res.abs() > 0.10).sum()),
      "n:", len(s))
print(s[["t_gps", "sys", "freq", "sat", "gf_jump", "doppler_res"]].head(30).to_string())

all_t = set(range(1603764590, 1603765197))
have_t = set(int(x) for x in d.t_gps.unique())
missing = sorted(all_t - have_t)
print("\nmissing epochs:", len(missing), missing[:30], "..." if len(missing) > 30 else "")
