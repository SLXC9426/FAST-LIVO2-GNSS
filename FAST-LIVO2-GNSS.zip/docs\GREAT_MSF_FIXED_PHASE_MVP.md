# GREAT-MSF 固定相位紧组合 MVP

## 目标

把 GREAT-MSF TCRTK 的**固定解**以双差相位的形式接入 FAST-LIVO2 的 ESIKF，验证“观测级融合”的最小闭环：

- FAST-LIVO2 仍是唯一估计器（19 维 ESKF + LiDAR/camera/IMU）；
- GREAT-MSF 不直接参与滤波，只提供**逐对卫星的固定相位** `dd_phase_fixed` 和有效性 `fix_valid`；
- `RtkTight` 对 `fix_valid=1` 的卫星对不再维护浮点模糊度，而是把固定相位当作高精度距离观测；
- 其余卫星对仍走原有浮点双差路径。

这是方案 B 的第一步，不引入完整的整数模糊度状态和 LAMBDA 固定。

## 数据流

```
GREAT-MSF .ins (TCRTK 固定解)
        │  固定历元、ECEF、姿态
        ▼
scripts/rtk/great_msf_fix.py
        │  逐星偏差标定 → N_int → dd_phase_fixed/fix_valid
        ▼
c01_dd_greatmsf.csv ──> dd_csv_to_bag.py ──> /rtk/dd (RtkDD)
                                                  │
IMU/LiDAR/camera ──> FAST-LIVO2 ESKF <────────────┘
```

### 整数恢复方法

1. 用 GREAT-MSF `.ins` 的 IMU 位置和姿态，加上天线杆臂，得到天线 ECEF；
2. 对每个双差对计算几何距离 `dd_geom`，得到 `N_float = (dd_phase - dd_geom)/lambda`；
3. 在 GREAT-MSF 为 `Fixed` 的历元上，按 `(sys, freq, ref_sat, sat)` 统计 `N_float` 的小数偏差，取圆中位数作为该卫星对的固定偏差；
4. `N_int = round(N_float - bias)`，`dd_phase_fixed = dd_phase - lambda*(N_int + bias)`；
5. 只有同时满足以下条件才置 `fix_valid=1`：
   - GREAT-MSF 状态为 `Fixed`；
   - 无周跳/参考星切换；
   - `|dd_phase_fixed - dd_geom| <= gate`（默认 0.10 m）。

这样得到的固定相位是“去掉整数和逐星偏差后的距离观测”，其精度由逐星偏差的稳定性决定。

## 代码改动

### 消息

`msg/RtkDD.msg` 新增：

```
float64[] dd_phase_fixed   # phase - lambda*N_int (m)，fix_valid=1 时有效
uint8[] fix_valid          # 1 = 该对可用固定相位
```

旧 bag 没有这两个字段时，`RtkTight` 自动回退到原有浮点路径。

### RtkTight

`include/rtk_tight.h` / `src/rtk_tight.cpp`：

- 新增 `fixed_phase_en`、`sigma_fixed_phase`、`fixed_phase_gate`；
- 新增两段式参数：
  - `fixed_warmup_epochs`：前 N 个成功更新使用松 σ/大门限；
  - `sigma_fixed_phase_tight`、`fixed_phase_gate_tight`、`prior_sigma_pos_tight`：预热后收紧；
- `use_fixed` 为真时：
  - 不创建/不更新浮点模糊度；
  - 残差 `r = dd_phase_fixed - dd_geom`；
  - `R = sigma_fixed^2`，超过门限的对置 `R=1e12` 丢弃；
- 日志新增 `fixed=` 和 `rej_phase`，便于确认固定对是否真正参与。

### 逐对 σ 与固定对监督

`great_msf_fix.py` 现在按卫星对计算偏差 MAD，并输出：

```
bias_mad           # cycles
sigma_phase_fixed  # max(sigma_floor, min(sigma_ceil, mad_k * MAD * lambda))
```

默认 `mad_k=3`、`max_mad=0.15` 周、`sigma_floor=0.03 m`、`sigma_ceil=1.0 m`。
MAD 超过 `max_mad` 的卫星对不参与固定相位。

`RtkTight` 新增：

```yaml
rtk:
  per_pair_sigma: true
  sigma_fixed_floor: 0.03
  sigma_fixed_ceiling: 1.0
  min_fixed_pairs: 5
  fixed_min_streak: 2
```

- 只有当前历元 `fix_valid=1` 的对数 ≥ `min_fixed_pairs`，且连续满足
  `fixed_min_streak` 个历元，才启用固定相位；
- 预热后逐对使用 `sigma_phase_fixed`，不再用全局常数。

### 状态协方差感知的鲁棒权重

固定相位的硬 0.5 m 门限在状态偏离 1–1.5 m 时会把所有固定对拒绝。最终实现改为：

1. 先用基础 σ 构建 `S0 = H P Hᵀ + R`；
2. 对每个固定相位行计算归一化新息 `u = |r| / sqrt(S0_ii)`；
3. 用 IGG3：`u<=3` 权重 1，`3<u<=6` 权重 `3/u`，`u>6` 置零；
4. 重算 `S` 后做正常更新。

这样状态协方差大时允许固定相位拉动，状态收紧后自动降权/拒绝。配置：

```yaml
rtk:
  fixed_robust_en: true
  fixed_robust_k0: 3.0
  fixed_robust_k1: 6.0
```

### 位置粗对齐 + 双差精对齐

逐对 σ 要求 FAST-LIVO2 状态已经在 0.5 m 内，否则固定相位会被门限拒绝。
最后的 180 s 实验同时打开：

```yaml
gnss:
  position_update_en: true
```

- NavSatFix 位置更新负责把状态拉到 ~0.5 m（粗对齐）；
- 固定相位在预热后提供 cm 级约束（精对齐）；
- 两者来自同一 GNSS 源，存在相关性；当前只用于验证闭环，后续应使用
  协方差交叉/膨胀，或只在粗对齐阶段短时启用位置更新。

### LIVMapper

`src/LIVMapper.cpp` 读取：

```yaml
rtk:
  fixed_phase_en: true
  sigma_fixed_phase: 0.5          # 预热 σ
  fixed_phase_gate: 5.0           # 预热门限
  fixed_warmup_epochs: 30
  sigma_fixed_phase_tight: 0.05   # 预热后 σ（默认预设，对应 full2）
  fixed_phase_gate_tight: 0.5
  prior_sigma_pos_tight: 0.5
  per_pair_sigma: false           # true 时使用逐对 σ（实验开关）
  sigma_fixed_floor: 0.03
  sigma_fixed_ceiling: 1.0
  min_fixed_pairs: 5
  fixed_min_streak: 2
```

实验开关：

- 逐对 σ：`per_pair_sigma: true`，`sigma_fixed_phase_tight: 0.3`；
- 位置粗对齐：`gnss.position_update_en: true`（仅短窗口有效，全量会退化）。

### 工具

- `scripts/rtk/great_msf_fix.py`：GREAT-MSF `.ins` + DD CSV → 扩展 CSV；
- `scripts/rtk/dd_csv_to_bag.py`：扩展 CSV → `/rtk/dd` bag（兼容旧 CSV）。

## 复现命令

```bash
# 1. 生成固定相位 CSV
python3 scripts/rtk/great_msf_fix.py \
  --dd-csv 02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv \
  --ins    /path/to/CAMP-MSF.ins \
  --out-csv 02_评估结果/rtk_tight_eval/raw/c01_dd_greatmsf.csv \
  --summary 02_评估结果/rtk_tight_eval/raw/c01_dd_greatmsf_summary.json

# 2. 转 ROS bag
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
python3 scripts/rtk/dd_csv_to_bag.py \
  --csv 02_评估结果/rtk_tight_eval/raw/c01_dd_greatmsf.csv \
  --bag 02_评估结果/rtk_tight_eval/raw/c01_dd_greatmsf.bag

# 3. 运行（607 s）
bash scripts/eval/segment_run_rtk.sh campus01 rtk 0 607 <TAG> \
  ~/datasets/GREAT/campus01_rtk1hz.bag \
  02_评估结果/rtk_tight_eval/raw/c01_dd_greatmsf.bag \
  '' great_campus01_greatmsf
```

## 首轮结果（campus-01）

| 运行 | 时长 | full 3D | full 2D | steady 3D | steady 2D |
|---|---:|---:|---:|---:|---:|
| LIVO 基线（Phase 4, N=3） | 607 s | 2.55 | 1.48 | 1.64 | 0.91 |
| RTK tight 浮点（Phase 4, N=3） | 607 s | 2.59 | 1.57 | 1.68 | 0.89 |
| 固定相位，无两段式（0.5 m 全程） | 607 s | 3.43 | 2.12 | 1.98 | 1.01 |
| 固定相位，两段式（tight σ=0.05 m） | 607 s | **2.31** | 1.89 | **1.65** | 1.31 |
| 固定相位，两段式（tight σ=0.30 m） | 607 s | 2.45 | **1.83** | 1.83 | **1.25** |
| 固定相位，两段式（tight σ=0.05 m） | 180 s | 1.10 | 0.82 | **0.25** | 0.25 |
| 固定相位，两段式（tight σ=0.30 m） | 180 s | **1.08** | **0.79** | **0.23** | **0.23** |
| 固定相位 + 逐对 σ/监督 | 180 s | 1.20 | 0.88 | 0.24 | 0.24 |
| 固定相位 + 逐对 σ/监督 + 位置粗对齐 | 180 s | **1.00** | **0.69** | 0.26 | 0.26 |
| 固定相位 + 鲁棒权重 | 180 s | 1.08 | 0.69 | 0.24 | 0.24 |
| 固定相位 + 鲁棒权重 | 607 s | 2.48 | **1.72** | **1.51** | **1.05** |
| 固定相位 + 逐对 σ + 鲁棒 + 放宽 MAD | 180 s | 1.10 | 0.82 | 0.25 | 0.25 |
| 固定相位 + 逐对 σ/监督 | 607 s | 未完成（固定相位被 0.5 m 门限大量拒绝） | — | — | — |
| 固定相位 + 逐对 σ/监督 + 位置粗对齐 | 607 s | 2.88 | 1.90 | 1.83 | 1.17 |

观察：

- 两段式是必要的：全程松约束会与 LiDAR 拉扯，3D 反而变差（3.43 m）；
- 短窗口（180 s）固定相位收敛后可达 0.23–0.25 m（3D/2D），说明机制有效；
- 607 s 全量上，tight σ=0.05 的 3D 最好（2.31 m），tight σ=0.30 的 2D 略好（1.83 m），
  但两者 2D 仍差于 LIVO（1.48 m）和 RTK tight（1.57 m）；终点静态定位很好
  （0.02–0.03 m），说明固定相位主要修正了高程/终点，横向仍受逐星偏差和
  GREAT-MSF 水平精度（约 0.5 m）限制；
- 当前固定相位的 σ 是全局常数，没有与逐星偏差的实际 MAD、固定对数量、
  连续固定历元数绑定，导致横向被过度拉向 GREAT-MSF 的 0.5 m 级轨迹；
- 逐对 σ + 监督在 180 s 上与全局 σ 接近，但全量运行时固定相位仍被 0.5 m
  门限大量拒绝：FAST-LIVO2 的 LIO 协方差过于自信，状态实际偏离 1–1.5 m，
  而滤波器认为只有 0.1–0.2 m；
- 打开 NavSatFix 位置更新做粗对齐，180 s 显著改善（3D 1.00 / 2D 0.69），
  但 607 s 全量退化到 3D 2.88 / 2D 1.90：位置更新在全量上接受率只有 38%、
  残差中位数约 7 m，说明它不能作为长期粗对齐源；
- 目前全量最佳仍是固定相位 + 两段式：3D 2.31 m（略优于 LIVO 2.55 /
  RTK tight 2.59），但 2D 1.83–1.89 m 仍差于 LIVO 1.48 m。固定相位主要
  改善高程和终点，横向受 GREAT-MSF `.ins` 水平精度和 LIO 协方差一致性限制。
- **鲁棒权重是当前最佳固定相位变体**：full 3D 2.48 m（略差于 full2 的 2.31 m），
  但 full 2D 1.72 m、steady 3D 1.51 m、steady 2D 1.05 m 均为固定相位方案最佳，
  终点静态 1.6 cm。与 LIVO 相比，steady 3D 1.51 < 1.64（更好），
  steady 2D 1.05 > 0.91（仍差），full 2D 1.72 > 1.48（仍差）。
- 鲁棒权重的价值在于：状态协方差大时允许固定相位拉动，状态收紧后自动降权，
  不再需要手工调 0.5 m 硬门限；当前默认配置即启用该权重。
- 对照：把 `max_mad` 从 0.15 放宽到 0.5 周，固定历元覆盖从 389/583 增到
  423/583，但 180 s 结果略差（1.10/0.82 vs 1.08/0.69）。逐对 σ 的中位数
  0.055 m 与全局 0.05 m 接近，增加的低质量固定对没有带来收益；因此默认
  仍用“全局 σ=0.05 + 鲁棒权重 + max_mad=0.15”。

## campus-03 验证

campus-03 使用同一套流程，但换用战术 IMU 杆臂和 campus-03 的 `.ins`：

- DD CSV：939 个历元、12,153 行，`02:40:00–02:59:59 GPST`；
- GREAT-MSF `.ins`：SOW `182512–183600`，Fixed 857/2177 行；
- 固定相位生成：30/46 个卫星对有偏差估计，2893 个固定行，
  256/939 个历元有 ≥5 个固定对；
- 杆臂：`X=-0.05, Y=-0.325, Z=0.165`（RFU）；
- 配置：`config/great_campus03_greatmsf.yaml`（鲁棒权重 + 全局 σ=0.05）。

300 s 段（START=0）：

| 方案 | full 3D | full 2D | steady 3D | steady 2D | 初始静态 |
|---|---:|---:|---:|---:|---:|
| 浮点 RTK 同段基线 | 8.04 | 8.00 | 1.24 | 1.06 | 0.018 m |
| 固定相位 + 鲁棒权重 | **4.81** | **4.74** | 1.28 | 1.06 | 0.018 m |

固定相位把 full 3D/2D 从 8.04/8.00 降到 4.81/4.74，moving-fit 从 2.82/2.70
降到 1.97/1.80；steady 窗口两者基本一致（1.24–1.28 / 1.06），说明收益主要在
早期/全局段，局部稳态精度仍由 LIO 决定。两轮的 ENU→world 对齐解不同
（yaw 1.8° vs -7.3°，fit residual 4.72 vs 3.52 m），因此该对照不是严格受控，
但 full/moving 的改善幅度明显大于对齐差异。

注意：从 120 s 切入时，LIO 只走了 2.5 m 而 GNSS 走了 50 m，对齐被 5 m 门限
拒绝（`alignment WITHHELD`）；从 0 s 开始可正常对齐（fit residual 4.72 m，
yaw 1.8°）。campus-03 的 full 指标被前 106 s 未融合的静态段拉高，steady 指标
更能反映融合效果。



## P1 验收尝试（GNSS/IMU-only）

为补 P1，新增了两个配置开关：

```yaml
common:
  lio_update_en: true      # false = 关闭 LiDAR/相机量测更新
  lio_off_after_s: 60.0    # >0 = 前 N 秒保留 LIO，之后关闭量测更新
```

并在 `runGnssInertial()` 中补了 `handleRTK()` 调用，使纯 GNSS/IMU 模式也能走固定相位 DD。

测试了三种配置（campus-01，180 s）：

| 配置 | 结果 |
|---|---|
| `lidar_en=0, img_en=0, position_update=0` | IMU 递推发散，DD 残差 60–100 m，全部被卡方门限拒绝 |
| 同上 + `position_update=1` | 仍发散，DD 残差 60–100 m，位置更新未能拉回 |
| 完整管线 + `lio_off_after_s=60`（位置更新开/关） | 60 s 后关闭 LIO，IMU 继续漂移，DD 残差 100–200 m，全部拒绝 |

根因：低成本的 MEMS IMU 在关闭 LiDAR 后，姿态/零偏不可观测，状态迅速漂到几十米；
GNSS 位置更新的协方差/卡方门限无法把 100 m 级误差拉回，固定相位 DD 的新息也随之
被拒绝。这不是固定相位公式的问题，而是**孤立 GNSS/IMU 估计器的初始化/可观测性**问题。

因此 P1 的严格验收（纯 GNSS/IMU-only 轨迹与 GREAT-MSFs TCRTK 水平差 <3 cm）
**未通过**。固定相位观测本身在完整管线中已验证：`fixed=...`、`rej_phase=0`，
campus-01 full6 与 campus-03 300 s 都能正常更新。

要继续关闭 P1，可选：

1. 实现 GNSS 辅助的粗对准（位置/速度/航向初始化 + 协方差膨胀），再关闭 LIO；
2. 直接用 GREAT-MSFs TCRTK 的 `.ins` 作为 GNSS/IMU 参考，P1 只验收固定相位残差
   （<0.1 m）和 DD 接受率，不要求 FAST-LIVO2 的纯 IMU 轨迹；
3. 先完成 P2/P3（LIO 始终在线），P1 的纯 IMU 验收作为后续独立任务。

## 内部固定整数导出尝试

为替代 `.ins` 反算 N，在 GREAT-MSF 的 `t_gambiguity::_addFixConstraint` 中加了两个
调试导出（`src/LibGREAT/gambfix/gambiguity.cpp`）：

- `great_amb_fix.csv`：`sow, site, sat1, sat2, ambtype, iwl, inl, factor, isWlFixed, isNlFixed, ratio`；
- `great_amb_int.csv`：`sow, site, sat1, sat2, ambtype, integer, factor`，其中
  `integer` 是 `_addFixConstraint` 实际使用的固定模糊度（米）。

campus-01 结果：17,716 / 17,135 行，全部为 `AMB_L1`。关键发现：

- `integer / factor = inl`，即导出的是 WL/NL 参数化下的窄巷整数，不是原始
  L1/L2/B2I/B3I 的 DD 相位整数；
- 与 `.ins` 反算的 `N_ins` 比较，差值不是整数：例如 `t=180634, G13-G02`
  的 `N_ins=17.218`、`inl=-12`，差值 29.218 周；差值还包含非零小数，
  说明 GREAT-MSF 的 DD 参数化/单差改正/UPD 与 FAST-LIVO2 的原始 DD
  不一致；
- 因此**不能直接把 `inl`/`integer` 当作 `N_int`**。要真正替换，需要把
  GREAT-MSF 的 `ambtype`、`Lx_cor`、SD/UPD 组合映射完整移植到桥接层，
  工作量明显大于当前 MVP。

当前仍采用 `.ins` 固定解反算 N + 逐星偏差标定 + 鲁棒权重；导出文件保留在
`sample_data/MSF_20201027/great_amb_fix.csv` 和 `great_amb_int.csv`，供后续
移植时做逐对校验。

## 已知限制

1. `N_int` 由 GREAT-MSF `.ins` 固定解反算，不是 GREAT-MSF 内部保存的整数模糊度；
   逐星偏差标定可吸收大部分系统差，但横向仍受 `.ins` 精度限制。
2. 目前只处理 campus-01；campus-02/03 需要各自的 DD CSV 和 `.ins`。
3. 未实现完整的整数模糊度状态、LAMBDA 固定和部分固定。
4. 监督器仍是“固定相位门限 + 两段式 σ”，尚未使用 ratio、连续固定历元数、
   LIVO 健康度等联合判决。
