#!/bin/bash
# Full-length run + evaluation for the three campus sequences, both modes.
#
# One process at a time (ROS single master), sequential, each result appended to
# Log/result/registry.csv by eval_unified.py and echoed to a summary file so the
# whole batch can run unattended in the background.
#
# Why full length here: the segment workflow (segment_run.sh) is for iteration;
# this batch produces the milestone numbers for the report, where only
# differences above the full-length noise band (~0.4 m APE) are meaningful.
#
# Usage: run_full_eval.sh [out_summary]
export LANG=C.UTF-8
OUT=${1:-/home/slxc9426/full_eval_summary.txt}
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo

F_GREAT="/mnt/f/GREAT数据集"
: > "$OUT"

# SEQ DUR MAIN_BAG GNSS_TOPIC EXTRA_BAG
run_one () {
  local SEQ=$1 MODE=$2 TAG=$3
  local CFG=config/great_${SEQ}.yaml
  local REF=$HOME/eval_great/${SEQ}_reference.tum
  local BAG EXTRA DUR TOPIC
  case "$SEQ" in
    campus01) DUR=607;  BAG=$HOME/datasets/GREAT/campus-01-full.bag; TOPIC=/gnss_rtk
              EXTRA=$HOME/datasets/GREAT/campus01_rtk1hz.bag ;;
    campus02) DUR=806;  BAG=$HOME/datasets/GREAT/campus-02.bag;      TOPIC=/gnss
              EXTRA=$HOME/datasets/GREAT/gnss_c02_trim.bag ;;
    campus03) DUR=1255; BAG=$HOME/datasets/GREAT/campus-03.bag;       TOPIC=/gnss
              EXTRA=$HOME/datasets/GREAT/gnss_c03.bag ;;
    *) echo "unknown $SEQ" | tee -a "$OUT"; return 1 ;;
  esac

  if [ "$MODE" = "livo" ]; then
    sed -i 's/^  gnss_en: .*/  gnss_en: false/' $CFG
  else
    sed -i 's/^  gnss_en: .*/  gnss_en: true/' $CFG
    sed -i "s|^  gnss_topic: .*|  gnss_topic: \"$TOPIC\"|" $CFG
  fi
  sed -i "s/^  seq_name: .*/  seq_name: \"$TAG\"/" $CFG
  # strip any previous run's line so the file only holds this run
  for f in $HOME/catkin_ws/src/fast_livo/Log/result/${TAG}.txt; do : > "$f"; done

  echo "=== $TAG (start $(date +%H:%M:%S)) ===" | tee -a "$OUT"
  bash "$(dirname "$0")/kill_ros.sh"
  roslaunch fast_livo mapping_great.launch rviz:=false seq_name:=$TAG cfg:=great_${SEQ} \
      > $HOME/full_${TAG}.log 2>&1 &
  local MP=$!
  sleep 10
  if [ "$MODE" = "gnss" ] && [ -n "$EXTRA" ]; then
    rosbag play -q --queue 5000 -s 0 -u $DUR "$BAG" "$EXTRA" > /dev/null 2>&1 &
  else
    rosbag play -q --queue 5000 -s 0 -u $DUR "$BAG" > /dev/null 2>&1 &
  fi
  local PP=$!
  wait $PP 2>/dev/null || true

  local RES=$HOME/catkin_ws/src/fast_livo/Log/result/${TAG}.txt
  local last=-1 stable=0
  for i in $(seq 1 60); do
    sleep 4
    local n=$(wc -l < "$RES" 2>/dev/null || echo 0)
    if [ "$n" = "$last" ]; then stable=$((stable+1)); else stable=0; fi
    last=$n
    [ "$stable" -ge 3 ] && break
  done
  kill -9 $MP 2>/dev/null || true
  bash "$(dirname "$0")/kill_ros.sh"
  echo "[$TAG] $(wc -l < "$RES") lines" | tee -a "$OUT"

  python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval/eval_unified.py \
      "$RES" "$REF" "$TAG" --config "$CFG" 2>&1 | tee -a "$OUT"
  # T0-3: fusion health block from the node log (alignment LOCKED/WITHHELD,
  # accepted/rejected, gate, effective gain) straight into the summary.
  python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval/fusion_health.py \
      "$HOME/full_${TAG}.log" 2>&1 | tee -a "$OUT"
  echo "" >> "$OUT"
  cp "$RES" "$HOME/eval_great/final_${TAG}.txt" 2>/dev/null || true
}

# Optional second argument selects a subset. Accepts c03 / campus03 / 03 forms.
ONLY=${2:-all}
RUN() {
  local seq=$1 short=${1#campus}
  if [ "$ONLY" = "all" ] || [ "$ONLY" = "$seq" ] || [ "$ONLY" = "c$short" ] || [ "$ONLY" = "$short" ]; then
    run_one "$1" "$2" "$3"
  fi
}
RUN campus01 livo c01_final_livo
RUN campus01 gnss c01_final_gnss
RUN campus02 livo c02_final_livo
RUN campus02 gnss c02_final_gnss
RUN campus03 livo c03_final_livo
RUN campus03 gnss c03_final_gnss

# T0-2: verdict lines against the accumulated registry (N>=3 per arm required,
# otherwise INVALID). Full-scope numbers only; the per-segment scopes live in
# the registry columns and can be judged with verdict.py --field afterwards.
EVALDIR=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval
REG=$HOME/catkin_ws/src/fast_livo/Log/result/registry.csv
VSEQ() {
  local seq=$1 short=${1#campus}
  if [ "$ONLY" = "all" ] || [ "$ONLY" = "$seq" ] || [ "$ONLY" = "c$short" ] || [ "$ONLY" = "$short" ]; then
    python3 "$EVALDIR/verdict.py" --registry "$REG" "c${short}_final_livo" "c${short}_final_gnss" 2>&1 | tee -a "$OUT"
  fi
}
VSEQ campus01
VSEQ campus02
VSEQ campus03
echo "ALL_DONE" | tee -a "$OUT"
