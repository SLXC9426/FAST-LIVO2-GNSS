#!/usr/bin/env python3
import rosbag
import collections

b = rosbag.Bag("/home/slxc9426/datasets/GREAT/GREAT.bag")
print("start:", b.get_start_time(), "end:", b.get_end_time(), "dur:", b.get_end_time() - b.get_start_time())
per_topic = collections.defaultdict(list)
for topic, msg, t in b.read_messages():
    per_topic[topic].append(t.to_sec())
for t in per_topic:
    ts = per_topic[t]
    print(t, len(ts), "%.2f ~ %.2f" % (min(ts), max(ts)))
b.close()
