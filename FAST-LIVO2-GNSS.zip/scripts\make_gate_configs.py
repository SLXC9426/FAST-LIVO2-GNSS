#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive gate-sigma A/B configs for campus-01 (R3 P1-2).

P1-2 asks whether the c01 fusion benefit lost to the WP7 gate (65% of epochs
rejected, 84% of them RTK-fixed epochs gated at the 1.2 m table value that was
calibrated on campus-02) comes back when the FIXED-epoch gate sigma is raised to
the level of the measured anchor-relative innovation median (~2.5 m). WP10a
already parameterised the table, so the whole experiment is a config value:

    gnss/sigma_fixed: 1.2 (default) -> 2.0 / 2.5

One knob per arm, everything else byte-identical to great_campus01.yaml, so each
arm carries its own cfg_hash in the registry. The gain K is untouched (it uses
the adaptive sigma); only the chi-square gate's absolute scale moves.

Usage:  make_gate_configs.py [2.0 2.5 ...]
Writes  config/great_campus01_gate<20>.yaml etc. (dot removed from the value).
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, os.pardir, "config", "great_campus01.yaml")


def derive(sigma_fixed):
    with open(BASE, encoding="utf-8") as fh:
        lines = fh.readlines()

    out = []
    inserted = False
    key_re = re.compile(r"^(\s*)relative_update:")
    for ln in lines:
        m = key_re.match(ln)
        if m and not inserted:
            indent = m.group(1)
            out.append("%s# R3 P1-2: gate-only calibration for campus-01. The fixed-epoch\n" % indent)
            out.append("%s# chi-square gate uses this table value (the gain keeps the adaptive\n" % indent)
            out.append("%s# sigma); 1.2 m was calibrated on campus-02, while c01's innovation\n" % indent)
            out.append("%s# median is ~2.5 m, which is what rejects 65%% of the epochs there.\n" % indent)
            out.append("%ssigma_fixed: %s\n" % (indent, sigma_fixed))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor line 'relative_update:' not found in %s" % BASE)

    tag = sigma_fixed.replace(".", "")
    dst = os.path.join(HERE, os.pardir, "config", "great_campus01_gate%s.yaml" % tag)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s (sigma_fixed=%s)" % (os.path.normpath(dst), sigma_fixed))


if __name__ == "__main__":
    for s in (sys.argv[1:] or ["2.0", "2.5"]):
        derive(s)
