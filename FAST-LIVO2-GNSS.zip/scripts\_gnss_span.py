#!/usr/bin/env python3
import rosbag
import numpy as np

b = rosbag.Bag("/home/slxc9426/campus-01.bag")
lats, lons = [], []
ts = []
for topic, msg, t in b.read_messages(topics=["/gnss"]):
    lats.append(msg.latitude)
    lons.append(msg.longitude)
    ts.append(t.to_sec())
lats, lons, ts = np.array(lats), np.array(lons), np.array(ts)
print("n:", len(lats), "t:", ts.min(), "~", ts.max())
print("lat:", lats.min(), lats.max())
print("lon:", lons.min(), lons.max())
# ENU from first fix
R = 6371000.0
lat0, lon0 = np.radians(lats[0]), np.radians(lons[0])
e = R * (np.radians(lons) - lon0) * np.cos(lat0)
n = R * (np.radians(lats) - lat0)
dist = np.sqrt((e - e[0]) ** 2 + (n - n[0]) ** 2)
cum = np.sum(np.sqrt(np.diff(e) ** 2 + np.diff(n) ** 2))
print("ENU span: east %.1f ~ %.1f, north %.1f ~ %.1f" % (e.min(), e.max(), n.min(), n.max()))
print("max dist from first: %.1f m, total length: %.1f m" % (dist.max(), cum))
b.close()
