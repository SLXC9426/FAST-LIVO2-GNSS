#!/bin/bash
# T1-4 Q A/B extension: the decisive pair (base vs q3) +3 runs each.
#
# Why: the first batch (t14_base/q1/q3/q10 x3) came out direction-consistent
# everywhere (steady: base 1.2099 -> q1 1.0328 / q3 0.9240 / q10 0.9686) but
# NOT RESOLVABLE under the pre-registered max-spread floor. q3's own spread
# collapsed (steady 0.0196 vs base 0.4704), so q3 is the arm worth resolving
# and base is the distribution worth characterising (is 0.7616 a mode or an
# outlier?). N=6 per arm is the cheapest honest escalation.
#
# Usage: run_t14_qab_ext.sh [summary]
export LANG=C.UTF-8
SUM=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/t1_4_qab/ab_ext_summary.txt}
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
SEG=$REPO/scripts/eval/segment_run.sh
EVALDIR=$REPO/scripts/eval
REG=$HOME/catkin_ws/src/fast_livo/Log/result/registry.csv
RTK=$HOME/datasets/GREAT/campus01_rtk1hz.bag

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

: > "$SUM"
echo "=== T1-4 Q A/B extension: base vs q3, r4-r6 | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum $HOME/catkin_ws/devel/lib/liblaser_mapping.so | cut -c1-8)" | tee -a "$SUM"

RUN() { local PFX=$1 CFG=$2 k
  for k in 4 5 6; do
    echo "--- $PFX r$k start $(date +%T)" | tee -a "$SUM"
    bash "$SEG" campus01 gnss 0 607 "${PFX}_r$k" "$RTK" "" "$CFG" 2>&1 | tee -a "$SUM"
  done
}
RUN t14_base great_campus01
RUN t14_q3   great_campus01_alignstate_q3

{
  echo ""
  echo "=== pooled verdicts (N=6 per arm) ==="
  python3 "$EVALDIR/verdict.py" --registry "$REG" t14_base t14_q3_ --field r2_steady --field r2_stat_gf --field r2_full 2>&1
  echo ""
  echo "acceptance read-out: r2_steady REAL(down) = plan 0.2 claim;"
  echo "r2_stat_gf REAL(down) = frame-scatter absorption (primary evidence)."
} | tee -a "$SUM"
echo "T14_QAB_EXT_DONE $(date +%T)" | tee -a "$SUM"
