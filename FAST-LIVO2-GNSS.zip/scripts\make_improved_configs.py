#!/usr/bin/env python3
"""
Generate the "*_improved.yaml" configs used for the before/after comparison
of the three FAST-LIVO2 improvements (occlusion, factor-graph backend,
dynamic-object removal).

It reads the base dataset config, enables every improvement and writes a new
file next to it. Pure text processing (no PyYAML dependency).

Usage:  python3 scripts/make_improved_configs.py
"""

import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config")

# new top-level sections appended to every improved config
NEW_SECTIONS = """
# ============================================================
# Improvement 1: occlusion-aware matching & robust kernels
# ============================================================
occlusion:
  en: true                  # reject ray-blocked (ghost) points in LIO matching
  margin: 0.3               # block must be at least this far before the point (m)
  behind_eps: 0.05          # point must be at least this far behind the plane (m)
  vio_en: true              # depth-consistency occlusion check in VIO tracking
  vio_depth_ratio: 0.5      # (m) map point must be this much farther than LiDAR depth

# ============================================================
# Improvement 3: dynamic object removal (geometric + temporal consistency)
# ============================================================
dynamic_remove:
  en: true
  conflict_thresh: 0.5      # |dist to plane| above this counts as a conflict (m)
  dynamic_ratio: 0.6        # conflict/obs ratio above this flags the plane dynamic
  obs_min: 20               # min observations before the ratio is trusted
  max_idle_frames: 100      # voxel idle for N frames -> forgotten (ghost removal)
  check_interval: 50        # forgetting sweep every N frames
  pub_dyn_en: true          # publish /dyn_obj, /dyn_obj_removed, /dyn_obj_dbg_hist

# ============================================================
# Improvement 2: sliding-window factor-graph backend
# ============================================================
factor_graph:
  en: true
  window_size: 25           # keyframe poses in the sliding window
  kf_dist: 1.0              # keyframe distance threshold (m)
  kf_rot_deg: 10.0          # keyframe rotation threshold (deg)
  kf_min_frames: 10         # force a keyframe every N frames
  odom_rot_sigma: 0.01      # rad
  odom_pos_sigma: 0.05      # m
  imu_gyr_sigma: 0.02       # rad/s / sqrt(Hz)
  imu_acc_sigma: 0.5        # m/s^2 / sqrt(Hz)
  imu_bg_sigma: 0.0001
  imu_ba_sigma: 0.0005
  marginalize: true         # Schur-complement marginalization of the oldest keyframe
  gnss_en: true             # attach GNSS position factors (LIVO_GNSS mode)
  gnss_pos_sigma: 0.5       # m
  robust_en: true           # Huber re-weighting of factor residuals
  robust_delta: 1.5
  thread_en: true           # optimizer on a separate thread (frontend latency unchanged)
  max_gn_iter: 8
"""

# lio-section keys enabled in the improved config
LIO_PATCH = (
    "lio:\n"
    "  robust_kernel_type: 1    # 0 none, 1 huber, 2 cauchy (IRLS on point-to-plane residuals)\n"
    "  robust_delta: 1.5        # kernel scale in units of residual sigma\n"
    "  reject_gate_scale: 2.0   # accept up to 2*sigma_num*sigma, kernel down-weights beyond\n"
)


def patch(base_name, out_name, seq_name_keep=False):
    base = os.path.join(ROOT, base_name)
    out = os.path.join(ROOT, out_name)
    with open(base, "r", encoding="utf-8") as f:
        txt = f.read()

    # enable the IRLS robust kernel in the lio section
    if "lio:\n" in txt and "robust_kernel_type" not in txt:
        txt = txt.replace("lio:\n", LIO_PATCH, 1)

    # make sure trajectory output + latency logging are on
    if "pose_output_en:" in txt:
        if "pose_output_en: false" in txt:
            txt = txt.replace("pose_output_en: false", "pose_output_en: true")
    if "latency_en:" not in txt:
        if "  pose_output_en: true" in txt:
            txt = txt.replace("  pose_output_en: true", "  pose_output_en: true\n  latency_en: true", 1)
        else:
            txt += "\nevo:\n  pose_output_en: true\n  latency_en: true\n"

    txt += NEW_SECTIONS

    with open(out, "w", encoding="utf-8") as f:
        f.write(txt)
    print("wrote", out)


if __name__ == "__main__":
    patch("avia.yaml", "avia_improved.yaml")
    patch("great_campus01.yaml", "great_campus01_improved.yaml")
    patch("NTU_VIRAL.yaml", "NTU_VIRAL_improved.yaml")
    print("done. (remember to set evo/seq_name per sequence via the launch arg)")
