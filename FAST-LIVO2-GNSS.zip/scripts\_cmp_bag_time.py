#!/usr/bin/env python3
"""Compare pointcloud 'time' field units: campus (self-converted) vs urban (official)."""
import rosbag, genpy, numpy as np
import sensor_msgs.point_cloud2 as pc2

for tag, bagpath, topic in [
    ("campus GREAT.bag", "/home/slxc9426/datasets/GREAT/GREAT.bag", "/points_raw"),
    ("campus GREAT_fixed.bag", "/home/slxc9426/datasets/GREAT/GREAT_fixed.bag", "/points_raw"),
    ("urban official", "/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag", "/points_raw"),
]:
    try:
        b = rosbag.Bag(bagpath)
        n = 0
        for topic, msg, t in b.read_messages(topics=[topic]):
            n += 1
            if n > 2:
                break
            f = {x.name: x.datatype for x in msg.fields}
            pts = list(pc2.read_points(msg, field_names=("time", "ring"), skip_nans=True))
            a = np.array(pts[:5000], dtype=float)
            print(f"[{tag}] fields={f}")
            print(f"   stamp={msg.header.stamp.to_sec():.3f} npts={len(pts)} "
                  f"time: {a[:,0].min():.4f} ~ {a[:,0].max():.4f}  rings={np.unique(a[:,1]).tolist()}")
            # first non-zero time -> infer unit
            nz = a[a[:, 0] > 0]
            if len(nz):
                print(f"   first nonzero time: {nz[0,0]:.4f} (µs if ~5e4..1e5, ms if ~50..100)")
        b.close()
    except Exception as e:
        print(f"[{tag}] ERROR: {e}")
