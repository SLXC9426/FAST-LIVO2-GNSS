#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1-4 method-default validation configs: c02 = adaptive gate + align state.

The c02 constraint chain (EVAL_PROTOCOL 23) needs BOTH the adaptive gate (the
table sigma blocks every epoch on the 8-21 m vertical disagreement) and the
alignment state (the only channel with enough gain once sigma is honest).
This derives that combined config from the main c02 config; single-purpose,
everything else byte-identical.

Usage: make_alignstate_c02_combo.py -> config/great_campus02_gate_adaptive_alignstate.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

BLOCK = """\
{i}# T1-4 method-default validation on c02: adaptive gate (WP7 decoupling) +
{i}# alignment state. The gate must be adaptive or the c02 vertical disagreement
{i}# (8-21 m vs the 1.2/2.16 m table) rejects every epoch; with the gate open
{i}# the alignment state is the only channel that still has gain (EVAL_PROTOCOL 23).
{i}gate_sigma_mode: adaptive
{i}align_state_en: true
"""


def main():
    base = os.path.join(HERE, os.pardir, "config", "great_campus02.yaml")
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()
    out, inserted = [], False
    for ln in lines:
        m = re.match(r"^(\s*)outlier_rejection:", ln)
        if m and not inserted:
            out.append(BLOCK.format(i=m.group(1)))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor 'outlier_rejection:' not found")
    dst = os.path.join(HERE, os.pardir, "config",
                       "great_campus02_gate_adaptive_alignstate.yaml")
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s" % os.path.normpath(dst))


if __name__ == "__main__":
    main()
