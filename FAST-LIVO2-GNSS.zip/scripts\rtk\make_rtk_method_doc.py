#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the RTK tight-coupling implementation note (Markdown + DOCX + figure).

Outputs under 01_文档/03_RTK紧组合/:
  RTK紧组合_观测级实现说明.md
  RTK紧组合_观测级实现说明.docx
  figs/rtk_tight_architecture.{pdf,png}
"""
import os

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

ROOT = r"C:\Users\张浩\Desktop\FAST-LIVO2-main"
DOCDIR = os.path.join(ROOT, "01_文档", "03_RTK紧组合")
FIGD = os.path.join(DOCDIR, "figs")
MD = os.path.join(DOCDIR, "RTK紧组合_观测级实现说明.md")
DOCX = os.path.join(DOCDIR, "RTK紧组合_观测级实现说明.docx")

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "pdf.fonttype": 42,
    "font.size": 7,
})


# ---------------------------------------------------------------------------
# architecture figure
# ---------------------------------------------------------------------------
def box(ax, x, y, w, h, text, fc, ec="#333333", fs=6.8):
    p = FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.03,rounding_size=0.08",
                       linewidth=0.8, edgecolor=ec, facecolor=fc)
    ax.add_patch(p)
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs)


def arrow(ax, p0, p1, style="-|>", ls="-", color="#333333", lw=0.9):
    a = FancyArrowPatch(p0, p1, arrowstyle=style, mutation_scale=7,
                        linewidth=lw, color=color, linestyle=ls,
                        shrinkA=1, shrinkB=1)
    ax.add_patch(a)


def make_figure():
    os.makedirs(FIGD, exist_ok=True)
    fig, ax = plt.subplots(figsize=(7.0, 3.8))
    ax.set_xlim(0, 10.2)
    ax.set_ylim(0, 5.2)
    ax.axis("off")

    src = "#DCE9F5"
    proc = "#FCE8C8"
    filt = "#D8F0E4"
    out = "#E8E8E8"

    box(ax, 0.15, 3.95, 2.2, 0.7, "Rover RINEX 1 Hz\n(GPS L1/L2, BDS B2I/B3I)", src)
    box(ax, 2.55, 3.95, 2.0, 0.7, "Base RINEX 1 Hz\n+ broadcast ephemeris", src)
    box(ax, 4.85, 3.80, 2.35, 1.0, "DD preprocessing\nsatellite orbit/clock,\nDD code/phase", proc)
    box(ax, 7.50, 3.95, 2.2, 0.7, "/rtk/dd\nfast_livo/RtkDD", src)

    box(ax, 0.15, 1.85, 2.2, 0.75, "LiDAR / camera / IMU\nraw measurements", src)
    box(ax, 2.75, 1.70, 2.35, 1.05, "FAST-LIVO2\nfront-end ESIKF\n19-dim state", filt, fs=6.4)
    box(ax, 5.55, 1.70, 2.35, 1.05, "RtkTight\nDD observation update\n+ float amb.", filt, fs=6.4)
    box(ax, 8.35, 1.85, 1.65, 0.75, "Front-end\ntrajectory", out)

    box(ax, 0.15, 0.35, 2.2, 0.65, "NavSatFix 1 Hz\n(alignment only)", src)
    box(ax, 2.75, 0.30, 2.35, 0.75, "tryAlignGnssYaw()\nENU -> world\n(2D Procrustes)", proc)

    arrow(ax, (2.35, 4.30), (2.55, 4.30))
    arrow(ax, (4.55, 4.30), (4.85, 4.30))
    arrow(ax, (7.20, 4.30), (7.50, 4.30))
    arrow(ax, (7.50, 3.95), (7.00, 2.75))
    arrow(ax, (2.35, 2.23), (2.75, 2.23))
    arrow(ax, (5.10, 2.23), (5.55, 2.23))
    arrow(ax, (5.55, 2.63), (5.10, 2.63), ls="--")
    arrow(ax, (7.90, 2.23), (8.35, 2.23))
    arrow(ax, (2.35, 0.68), (2.75, 0.68))
    arrow(ax, (4.80, 1.05), (4.80, 1.70), ls="--")

    ax.text(5.32, 2.82, "H, r, R", fontsize=6, color="#555555", ha="center")
    ax.text(5.32, 2.44, "dx, P", fontsize=6, color="#555555", ha="center")
    ax.text(7.30, 3.30, "DD observation", fontsize=6, color="#555555", ha="left")
    ax.text(4.90, 1.20, "ENU->world", fontsize=6, color="#555555", ha="left")
    ax.text(0.15, 5.02, "a  Data and estimation flow", fontsize=8, fontweight="bold")

    for ext in ("pdf", "png"):
        fig.savefig(os.path.join(FIGD, f"rtk_tight_architecture.{ext}"),
                    dpi=600, bbox_inches="tight")
    plt.close(fig)
    print("wrote architecture figure")


# ---------------------------------------------------------------------------
# docx helpers
# ---------------------------------------------------------------------------
def add_page_number(paragraph):
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), " PAGE ")
    run = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "1"
    run.append(t)
    fld.append(run)
    paragraph._p.append(fld)


def set_run(run, size=10.5, bold=False, east="SimSun", ascii_="Times New Roman"):
    run.font.name = ascii_
    run.font.size = Pt(size)
    run.bold = bold
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east)


def body(doc, text, indent=True, size=10.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(4)
    if indent:
        p.paragraph_format.first_line_indent = Pt(21)
    set_run(p.add_run(text), size=size)
    return p


def heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    set_run(p.add_run(text), size=14 if level == 1 else 12, bold=True, east="SimHei")
    return p


def equation(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(4)
    set_run(p.add_run(text), size=9.5, ascii_="Cambria Math", east="Cambria Math")


def caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    set_run(r, size=9)
    r.italic = True


def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color)
    tcPr.append(shd)


def table(doc, header, rows, widths=None, font_size=8.5):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_run(p.add_run(h), size=font_size, bold=True, east="SimHei")
        shade(c, "E7E6E6")
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
            set_run(p.add_run(str(v)), size=font_size)
    if widths:
        for i, w in enumerate(widths):
            for row in t.rows:
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def figure(doc, path, cap, width=15.5):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.add_run().add_picture(path, width=Cm(width))
    caption(doc, cap)


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------
def build_md():
    L = []
    L.append("# RTK 观测级紧组合实现说明\n")
    L.append("> 项目：FAST-LIVO2 + 双差 RTK 前端紧组合  \n"
             "> 数据：GREAT campus-01，GPS/BDS 双频，1 Hz 流动站/基站  \n"
             "> 日期：2026-10-18")
    L.append("\n## 1. 文档目的\n")
    L.append("本文说明本项目如何在 FAST-LIVO2 前端 ESIKF 中实现**观测级双差 RTK 紧组合**："
             "数据如何从 RINEX 变成 `/rtk/dd`，双差码/相位如何进入 19 维滤波器，"
             "浮点模糊度如何维护，以及时间对齐、门控和抗差如何处理。"
             "本文是方法/实现说明；三方案 N=3 结果见 `02_评估结果/rtk_tight_eval/REPORT.docx`。\n")
    L.append("## 2. 总体架构\n")
    L.append("紧组合的定义：不先由 RTK 引擎解算位置，而是把**双差伪距、双差载波相位**"
             "作为观测直接进入 ESIKF；滤波器同时估计 19 维导航状态和每个双差对的浮点模糊度。\n")
    L.append("![架构图](figs/rtk_tight_architecture.png)\n")
    L.append("数据流：1 Hz 流动站/基站 RINEX + 广播星历 → 双差预处理 → `/rtk/dd` → "
             "`RtkTight` 观测更新 → 前端 ESIKF 轨迹。1 Hz NavSatFix 只用于 ENU→world 对齐，"
             "不做位置更新。因子图关闭。\n")
    L.append("## 3. 状态与坐标\n")
    L.append("### 3.1 19 维基础状态\n")
    L.append("| 索引 | 含义 |\n|---|---|\n| 0–2 | 姿态误差（SO(3) 右扰动） |\n"
             "| 3–5 | 世界系位置 |\n| 6 | 曝光时间倒数 |\n| 7–9 | 世界系速度 |\n"
             "| 10–12 | 陀螺零偏 |\n| 13–15 | 加速度计零偏 |\n| 16–18 | 重力 |\n")
    L.append("双差更新主要作用于姿态（0–2）和位置（3–5），其余状态通过协方差耦合。\n")
    L.append("### 3.2 三个坐标框架\n")
    L.append("| 框架 | 定义 | 用途 |\n|---|---|---|\n"
             "| World | FAST-LIVO2 世界系，重力对齐、Z 向下、yaw 任意 | 滤波器状态 |\n"
             "| GNSS ENU（U 取反） | 第一条 NavSatFix 为原点，(E,N,-U) | ENU→world 对齐 |\n"
             "| 基站中心 ENU | 基站 ECEF 为原点，卫星 ECEF 转入 | 双差几何 |\n")
    L.append("### 3.3 天线相位中心与基站偏移\n")
    L.append("天线世界位置与基站中心 ENU 位置：\n")
    L.append("```text\np_ant_world = p_world + R_world * l_ant\n"
             "p_ant_base  = R_enu_world^T (p_ant_world - t_enu_world) - b_enu\n```\n")
    L.append("`l_ant = gnss_extT = [-0.05, -0.325, 0.165] m`；`b_enu` 是基站在第一条 fix ENU 中的位置，"
             "U 取反，由基站 ECEF 和第一条 fix 经纬高算出。\n")
    L.append("## 4. 双差观测模型\n")
    L.append("对每个双差对 `i`（系统/频率/非参考星/参考星）：\n")
    L.append("```text\nh_i = (||s_i - p_ant_base|| - ||s_i||) - (||r_i - p_ant_base|| - ||r_i||)\n"
             "r_code,i  = z_code,i  - h_i\n"
             "r_phase,i = z_phase,i - h_i - a_i\n```\n")
    L.append("`s_i`、`r_i` 是卫星/参考星在基站中心 ENU 的位置；`a_i` 是浮点双差模糊度（米）；"
             "`z_phase` 已乘波长。基站/流动站钟差、卫星钟差、电离层/对流层大部分在双差中抵消。\n")
    L.append("雅可比：\n")
    L.append("```text\nd(h_i)/d(p_ant_base) = u_ref - u_sat\n"
             "H_pos,i = (u_ref - u_sat)^T * R_enu_world^T\n"
             "H_att,i = -H_pos,i * [R_world * l_ant]_x\n"
             "H_i     = [H_att,i, H_pos,i, 0, ..., 0]   (1x19)\n```\n")
    L.append("注意符号是 `u_ref - u_sat`；反过来会让更新朝错误方向走。\n")
    L.append("## 5. ESIKF 更新\n")
    L.append("滤波器维护 `P_xx`（19×19）与 `P_amb`（n×n），采用块对角近似 `P_xa = 0`。"
             "每个历元 `n` 个双差对，码/相位共 `2n` 行：\n")
    L.append("```text\nR_eff(code,i)  = sigma_code,i^2\n"
             "R_eff(phase,i) = sigma_phase,i^2 + P_amb(i,i)\n"
             "S = H_meas P_xx H_meas^T + R_eff\n"
             "K_x = P_xx H_meas^T S^-1\n"
             "K_a = P_amb H_a^T S^-1\n"
             "dx = K_x r,   da = K_a r\n"
             "amb += da\n"
             "P_xx^+ = (I - K_x H_meas) P_xx (I - K_x H_meas)^T + K_x R_eff K_x^T\n"
             "P_amb^+ = P_amb - K_a S K_a^T\n```\n")
    L.append("`H_a` 只在相位行对应模糊度列为 1，码行为 0。`P_xx^+` 用 Joseph 形式，`P_amb^+` "
             "做对称化和特征值截断。卡方门：`gamma = r^T S^-1 r`，DOF=2n，95% 阈值；"
             "超门拒绝整个历元。\n")
    L.append("## 6. 模糊度管理\n")
    L.append("- 键：`(sys, freq, sat, ref_sat)`；\n"
             "- 新键初始化：`a = dd_phase - h(state_prop)`，`P_amb = 4 m^2`；\n"
             "- `slip=1`、`ref_change=1` 时重置；\n"
             "- `|r_phase| > 0.5 m` 时做残差型周跳修复（捕获基准站周跳），重置该对模糊度并把该相位行残差置 0；\n"
             "- 模糊度按常数处理，不加过程噪声。\n")
    L.append("## 7. 权重、门控与抗差\n")
    L.append("| 参数 | 值 | 说明 |\n|---|---:|---|\n"
             "| `sigma_code_min` | 20 m | 码多路径/系统偏差约 3 m，码只做弱绝对锚定 |\n"
             "| `sigma_phase_min` | 0.03 m | Phase 1 相位 MAD 0.017 m |\n"
             "| `prior_sigma_pos` | 0.5 m | 仅水平位置先验下限 |\n"
             "| `max_corr` | 0.5 m | 单历元位置修正限幅 |\n"
             "| `init_amb_var` | 4 m² | 新模糊度 2 m sigma |\n"
             "| `phase_slip_thresh` | 0.5 m | 残差型周跳阈值 |\n")
    L.append("robust 分支：IGG3 相对权（码 2.5 m、k0=1.5/k1=3；相位 0.05 m、k0=3/k1=6）；"
             "IMU/LiDAR 先验绝对码门限 `|r_code| > 3*2.5=7.5 m` 时该码行权重 0；"
             "权重通过 `R_eff(i,i)=sigma_i^2/w_i` 进入更新。\n")
    L.append("## 8. 时间对齐与主循环\n")
    L.append("主循环顺序：`sync_packages → handleFirstFrame → processImu → "
             "stateEstimationAndMapping → handleGNSS → handleRTK`。\n")
    L.append("`handleRTK` 只处理 `t <= last_lio_update_time + 0.5 s` 的消息，丢弃早于 "
             "`last_lio_update_time - 1 s` 的旧消息（对齐锁定前积压）。"
             "`updateStateWithRTK` 把状态复制并 `propagateStateToTime(t_rtk)`，"
             "在传播状态上算新息/雅可比，但修正量施加到当前 `_state`，避免区间双重积分。\n")
    L.append("ENU→world 对齐由 `tryAlignGnssYaw()` 完成：累积 `(GNSS ENU, LIO world)` 对，"
             "2D Procrustes + 鲁棒剔除，连续 10 次 yaw 变化 <0.35° 才锁定；campus-01 约 63 s 锁定，"
             "yaw≈22.3°，拟合残差≈0.5 m。\n")
    L.append("## 9. 预处理与数据约定\n")
    L.append("- 流动站/基站：1 Hz RINEX；GPS L1 `C1C/L1C`、L2 `C2W/L2W`；BDS B2I `C7I/L7I`、B3I `C6I/L6I`；高度截止 10°；\n"
             "- RINEX 是 GPS 时，bag/参考是 UTC，2020 年差 18 s；BDS 导航是 BDT，解析时 +14 s；\n"
             "- 基站坐标用 `GREAT_RTK_campus01_fixbase.xml` 的固定值；\n"
             "- 输出 583 条 `/rtk/dd`、9,200 行双差；\n"
             "- Phase 1 验证：码双差 RMS 2.52 m（MAD 1.93 m），相位双差 MAD 0.0166 m，静态浮点相位 RMS 0.010 m。\n")
    L.append("## 10. 代码位置\n")
    L.append("| 内容 | 文件 |\n|---|---|\n"
             "| 双差预处理 | `scripts/rtk/rtk_preprocess.py` |\n"
             "| DD 消息 | `msg/RtkDD.msg` |\n"
             "| 紧组合类 | `include/rtk_tight.h`、`src/rtk_tight.cpp` |\n"
             "| 订阅/主循环/时间传播 | `src/LIVMapper.cpp`：`rtk_cbk`、`handleRTK`、`updateStateWithRTK`、`run` |\n"
             "| ENU→world 对齐 | `src/LIVMapper.cpp`：`tryAlignGnssYaw` |\n"
             "| 配置 | `config/great_campus01_rtk_tight.yaml`、`great_campus01_rtk_robust.yaml` |\n"
             "| 三包同播 | `scripts/eval/segment_run_rtk.sh` |\n")
    L.append("## 11. 边界与已知问题\n")
    L.append("- 浮点 RTK，未做整数模糊度固定；\n"
             "- `P_xa=0` 块对角近似，不是完整 19+n 增广协方差；\n"
             "- 码 sigma 20 m 是针对本数据 3 m 级码偏差的保守设置，不应直接照搬到其他数据；\n"
             "- 对齐前约 63 s 为纯 LIVO；\n"
             "- 未建模 PCO/PCV、相位缠绕、接收机通道偏差；\n"
             "- N=3 三方案没有一致占优，详见 `REPORT.docx`。\n")
    L.append("## 12. 关于整数模糊度固定\n")
    L.append("技术上可以做，但不应直接在当前浮点解上加 LAMBDA。Phase 1 静态浮点双差模糊度的"
             "到最近整数残差多在 0.1–0.48 周，说明存在稳定的相位偏差/未建模项；"
             "直接取整或 LAMBDA 容易错误固定（`.flt` 在 `sow=181080` 就有一次约 10 m 的错误固定）。"
             "若要做，建议先做 Phase 5A 诊断：记录浮点模糊度/协方差，检查宽巷/窄巷、连续弧段、ratio 潜力，"
             "并补 PCO/PCV、相位缠绕、接收机偏差；通过后再做 LAMBDA/部分固定/ratio 检验/软约束和浮点回退。\n")
    L.append("## 13. 复现\n")
    L.append("```bash\n"
             "# 双差预处理\n"
             "python3 scripts/rtk/rtk_preprocess.py --run\n"
             "python3 scripts/rtk/dd_csv_to_bag.py --csv ... --bag ...\n"
             "# 三方案同播\n"
             "bash scripts/eval/segment_run_rtk.sh campus01 rtk 0 607 <tag> \\\n"
             "  ~/datasets/GREAT/campus01_rtk1hz.bag <dd.bag> '' great_campus01_rtk_tight\n"
             "```\n")
    return "\n".join(L)


# ---------------------------------------------------------------------------
# DOCX
# ---------------------------------------------------------------------------
def build_docx():
    os.makedirs(FIGD, exist_ok=True)
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
    sec.left_margin = Cm(2.4); sec.right_margin = Cm(2.2)

    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    set_run(p.add_run("RTK 观测级紧组合实现说明"), size=20, bold=True, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run(p.add_run("FAST-LIVO2 + 双差 RTK 前端 ESIKF"), size=12, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run(p.add_run("GREAT campus-01 · 2026-10-18"), size=9.5)
    doc.add_paragraph()

    heading(doc, "1 文档目的", 1)
    body(doc, "本文说明本项目如何在 FAST-LIVO2 前端 ESIKF 中实现观测级双差 RTK 紧组合："
              "数据如何从 RINEX 变成 /rtk/dd，双差码/相位如何进入 19 维滤波器，"
              "浮点模糊度如何维护，以及时间对齐、门控和抗差如何处理。"
              "本文是方法/实现说明；三方案 N=3 结果见 02_评估结果/rtk_tight_eval/REPORT.docx。")

    heading(doc, "2 总体架构", 1)
    body(doc, "紧组合的定义：不先由 RTK 引擎解算位置，而是把双差伪距、双差载波相位作为观测"
              "直接进入 ESIKF；滤波器同时估计 19 维导航状态和每个双差对的浮点模糊度。")
    figure(doc, os.path.join(FIGD, "rtk_tight_architecture.png"),
           "图 1 数据与估计流程。1 Hz NavSatFix 只用于 ENU→world 对齐，位置更新由 /rtk/dd 完成。")
    body(doc, "数据流：1 Hz 流动站/基站 RINEX + 广播星历 → 双差预处理 → /rtk/dd → RtkTight "
              "观测更新 → 前端 ESIKF 轨迹。因子图关闭；NavSatFix 不做位置更新。")

    doc.add_page_break()
    heading(doc, "3 状态与坐标", 1)
    heading(doc, "3.1 19 维基础状态", 2)
    table(doc, ["索引", "含义"], [
        ["0–2", "姿态误差（SO(3) 右扰动）"], ["3–5", "世界系位置"],
        ["6", "曝光时间倒数"], ["7–9", "世界系速度"],
        ["10–12", "陀螺零偏"], ["13–15", "加速度计零偏"], ["16–18", "重力"],
    ], widths=[3.0, 10.0])
    body(doc, "双差更新主要作用于姿态（0–2）和位置（3–5），其余状态通过协方差耦合。")
    heading(doc, "3.2 三个坐标框架", 2)
    table(doc, ["框架", "定义", "用途"], [
        ["World", "重力对齐、Z 向下、yaw 任意", "滤波器状态"],
        ["GNSS ENU（U 取反）", "第一条 NavSatFix 为原点，(E,N,-U)", "ENU→world 对齐"],
        ["基站中心 ENU", "基站 ECEF 为原点，卫星 ECEF 转入", "双差几何"],
    ], widths=[3.5, 7.5, 4.0])
    heading(doc, "3.3 天线与基站偏移", 2)
    equation(doc, "p_ant_world = p_world + R_world * l_ant")
    equation(doc, "p_ant_base = R_enu_world^T (p_ant_world - t_enu_world) - b_enu")
    body(doc, "l_ant = gnss_extT = [-0.05, -0.325, 0.165] m；b_enu 是基站在第一条 fix ENU 中的位置"
              "（U 取反），由基站 ECEF 和第一条 fix 经纬高算出。")

    heading(doc, "4 双差观测模型", 1)
    body(doc, "对每个双差对 i（系统/频率/非参考星/参考星）：")
    equation(doc, "h_i = (||s_i - p_ant_base|| - ||s_i||) - (||r_i - p_ant_base|| - ||r_i||)")
    equation(doc, "r_code,i = z_code,i - h_i")
    equation(doc, "r_phase,i = z_phase,i - h_i - a_i")
    body(doc, "s_i、r_i 是卫星/参考星在基站中心 ENU 的位置；a_i 是浮点双差模糊度（米）；"
              "z_phase 已乘波长。基站/流动站钟差、卫星钟差、电离层/对流层大部分在双差中抵消。"
              "雅可比：")
    equation(doc, "d(h_i)/d(p_ant_base) = u_ref - u_sat")
    equation(doc, "H_pos,i = (u_ref - u_sat)^T * R_enu_world^T")
    equation(doc, "H_att,i = -H_pos,i * [R_world * l_ant]_x")
    equation(doc, "H_i = [H_att,i, H_pos,i, 0, ..., 0]   (1x19)")
    body(doc, "注意符号是 u_ref - u_sat；反过来会让更新朝错误方向走。")

    heading(doc, "5 ESIKF 更新", 1)
    body(doc, "滤波器维护 P_xx（19×19）与 P_amb（n×n），采用块对角近似 P_xa = 0。"
              "每个历元 n 个双差对，码/相位共 2n 行：")
    equation(doc, "R_eff(code,i) = sigma_code,i^2")
    equation(doc, "R_eff(phase,i) = sigma_phase,i^2 + P_amb(i,i)")
    equation(doc, "S = H_meas P_xx H_meas^T + R_eff")
    equation(doc, "K_x = P_xx H_meas^T S^-1,   K_a = P_amb H_a^T S^-1")
    equation(doc, "dx = K_x r,   da = K_a r,   amb += da")
    equation(doc, "P_xx^+ = (I - K_x H_meas) P_xx (I - K_x H_meas)^T + K_x R_eff K_x^T")
    equation(doc, "P_amb^+ = P_amb - K_a S K_a^T")
    body(doc, "H_a 只在相位行对应模糊度列为 1，码行为 0。P_xx^+ 用 Joseph 形式；P_amb^+ "
              "做对称化和特征值截断。卡方门 gamma = r^T S^-1 r，DOF=2n，95% 阈值；"
              "超门拒绝整个历元。")

    heading(doc, "6 模糊度管理", 1)
    body(doc, "键为 (sys, freq, sat, ref_sat)；新键初始化 a = dd_phase - h(state_prop)，"
              "P_amb = 4 m²；slip=1、ref_change=1 时重置；|r_phase| > 0.5 m 时做残差型周跳修复"
              "（捕获基准站周跳），重置该对模糊度并把该相位行残差置 0；模糊度按常数处理，不加过程噪声。")

    heading(doc, "7 权重、门控与抗差", 1)
    table(doc, ["参数", "值", "说明"], [
        ["sigma_code_min", "20 m", "码多路径/系统偏差约 3 m；码只做弱绝对锚定"],
        ["sigma_phase_min", "0.03 m", "Phase 1 相位 MAD 0.017 m"],
        ["prior_sigma_pos", "0.5 m", "仅水平位置先验下限"],
        ["max_corr", "0.5 m", "单历元位置修正限幅"],
        ["init_amb_var", "4 m²", "新模糊度 2 m sigma"],
        ["phase_slip_thresh", "0.5 m", "残差型周跳阈值"],
    ], widths=[3.6, 3.0, 8.4])
    body(doc, "robust 分支：IGG3 相对权（码 2.5 m、k0=1.5/k1=3；相位 0.05 m、k0=3/k1=6）；"
              "IMU/LiDAR 先验绝对码门限 |r_code| > 3*2.5 = 7.5 m 时该码行权重 0；"
              "权重通过 R_eff(i,i) = sigma_i^2 / w_i 进入更新。")

    heading(doc, "8 时间对齐与主循环", 1)
    body(doc, "主循环顺序：sync_packages → handleFirstFrame → processImu → "
              "stateEstimationAndMapping → handleGNSS → handleRTK。handleRTK 只处理 "
              "t <= last_lio_update_time + 0.5 s 的消息，丢弃早于 last_lio_update_time - 1 s "
              "的旧消息（对齐锁定前积压）。updateStateWithRTK 把状态复制并 propagateStateToTime(t_rtk)，"
              "在传播状态上算新息/雅可比，但修正量施加到当前 _state，避免区间双重积分。")
    body(doc, "ENU→world 对齐由 tryAlignGnssYaw() 完成：累积 (GNSS ENU, LIO world) 对，"
              "2D Procrustes + 鲁棒剔除，连续 10 次 yaw 变化 <0.35° 才锁定；campus-01 约 63 s "
              "锁定，yaw≈22.3°，拟合残差≈0.5 m。")

    heading(doc, "9 预处理与数据约定", 1)
    body(doc, "流动站/基站：1 Hz RINEX；GPS L1 C1C/L1C、L2 C2W/L2W；BDS B2I C7I/L7I、"
              "B3I C6I/L6I；高度截止 10°。RINEX 是 GPS 时，bag/参考是 UTC，2020 年差 18 s；"
              "BDS 导航是 BDT，解析时 +14 s。基站坐标用 GREAT_RTK_campus01_fixbase.xml "
              "的固定值。输出 583 条 /rtk/dd、9,200 行双差。Phase 1 验证：码双差 RMS 2.52 m"
              "（MAD 1.93 m），相位双差 MAD 0.0166 m，静态浮点相位 RMS 0.010 m。")

    heading(doc, "10 代码位置", 1)
    table(doc, ["内容", "文件"], [
        ["双差预处理", "scripts/rtk/rtk_preprocess.py"],
        ["DD 消息", "msg/RtkDD.msg"],
        ["紧组合类", "include/rtk_tight.h、src/rtk_tight.cpp"],
        ["订阅/主循环/时间传播", "src/LIVMapper.cpp：rtk_cbk、handleRTK、updateStateWithRTK、run"],
        ["ENU→world 对齐", "src/LIVMapper.cpp：tryAlignGnssYaw"],
        ["配置", "config/great_campus01_rtk_tight.yaml、great_campus01_rtk_robust.yaml"],
        ["三包同播", "scripts/eval/segment_run_rtk.sh"],
    ], widths=[4.0, 11.0], font_size=8)

    heading(doc, "11 边界与已知问题", 1)
    body(doc, "浮点 RTK，未做整数模糊度固定；P_xa=0 块对角近似，不是完整 19+n 增广协方差；"
              "码 sigma 20 m 是针对本数据 3 m 级码偏差的保守设置，不应直接照搬；"
              "对齐前约 63 s 为纯 LIVO；未建模 PCO/PCV、相位缠绕、接收机通道偏差；"
              "N=3 三方案没有一致占优，详见 REPORT.docx。")

    heading(doc, "12 关于整数模糊度固定", 1)
    body(doc, "技术上可以做，但不应直接在当前浮点解上加 LAMBDA。Phase 1 静态浮点双差模糊度的"
              "到最近整数残差多在 0.1–0.48 周，说明存在稳定的相位偏差/未建模项；直接取整或 "
              "LAMBDA 容易错误固定（.flt 在 sow=181080 就有一次约 10 m 的错误固定）。"
              "若要做，建议先做 Phase 5A 诊断：记录浮点模糊度/协方差，检查宽巷/窄巷、连续弧段、"
              "ratio 潜力，并补 PCO/PCV、相位缠绕、接收机偏差；通过后再做 LAMBDA/部分固定/"
              "ratio 检验/软约束和浮点回退。")

    heading(doc, "13 复现", 1)
    body(doc, "双差预处理：python3 scripts/rtk/rtk_preprocess.py --run；"
              "CSV 转 bag：python3 scripts/rtk/dd_csv_to_bag.py；"
              "三方案同播：bash scripts/eval/segment_run_rtk.sh campus01 rtk 0 607 <tag> "
              "~/datasets/GREAT/campus01_rtk1hz.bag <dd.bag> '' great_campus01_rtk_tight。")

    footer = sec.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_page_number(p)

    doc.save(DOCX)
    print("wrote", DOCX)


def main():
    os.makedirs(DOCDIR, exist_ok=True)
    make_figure()
    md = build_md()
    with open(MD, "w", encoding="utf-8") as f:
        f.write(md)
    print("wrote", MD)
    build_docx()


if __name__ == "__main__":
    main()
