# A2.1：GNSS 质量数据通道

分支：`fix/a2-quality-channel`（从 A1 提交 `b7ba7cc` 起）
目标：把每历元的真实质量字段从 PVT 源头无损送到后端 trace，**不改变任何
因子、sigma、门控或 A1 的时间关联**。定位精度提升不是本阶段目标。

## 1. 数据链路

```
gnss_comm/GnssPVTSolnMsg
  ├── /gnss/fix_enhanced   sensor_msgs/NavSatFix      （原有）
  └── /gnss/quality        fast_livo/GnssQuality      （A2.1 新增，同一 stamp）
        │
        └── LIVMapper::gnss_quality_cbk
              └── 精确纳秒缓存（gnss_quality_cache.h）
                    └── gnss_cbk 按原始 header.stamp 取用一次
                          └── OnlineGraphFix（新增质量字段）
                                └── online_graph_node
                                      └── GlobalPoseGraph::Fix（只携带）
                                            └── assoc trace 逐历元列
```

## 2. 消息与单位

`msg/GnssQuality.msg`：

| 字段 | 含义 | 单位/取值 |
|---|---|---|
| `num_sv` | 参与导航解的卫星数 | 0–255 |
| `p_dop` | 位置 DOP | 无量纲 |
| `carr_soln` | 载波相位解 | 0=none, 1=float, 2=fixed |
| `fix_type` | UBX 解类型 | 0–5 |
| `h_acc_mm` / `v_acc_mm` | 接收机精度估计 | 毫米（源消息 `h_acc` 为米） |
| `valid` | PVT 有效标志 | bool |
| `has_p_dop` / `has_h_acc` / `has_v_acc` | 字段是否存在 | bool |

`h_acc/v_acc` 是精度估计，不是 1σ；A2.1 只传输，不进入协方差。

`OnlineGraphFix.msg` 追加同名字段 + `quality_source`（`ublox` / `rtklib`），
原有 `nsat/pdop` 现在填真实值；没有质量通道时仍是 0 / false，行为与 A1 相同。

## 3. 匹配契约

- 键是 **原始 ROS 纳秒时间戳**（`header.stamp.toNSec()`），不是
  `toSec()` 往返的 double（1.6e9 s 时 double 分辨率约 0.5 µs）；
- relay 在同一 PVT 回调里用同一 `now` 发布两条消息，因此 stamp 相同；
- `take()` 命中即删除：一条质量消息只能服务一个 fix；
- 相邻历元不替代；迟到/缺失只计 `unmatched`；重复发布计 `duplicates`；
- 5 s 过期清理（`prune`）；
- 计数器：`matched / unmatched / duplicates / expired`。

## 4. 离线同输入通道

`feed_online_graph.py --quality-csv <RTKLIB quality.csv>`：

- 按整数 Unix 秒查表，填 `nsat/pdop/sigma0/carr_soln/fix_type/quality_valid`；
- `quality_source="rtklib"`；
- RTKLIB 表没有接收机 `hAcc/vAcc`，因此 `has_h_acc/has_v_acc=false`，
  不用 `x_rms/y_rms` 冒充；
- 在线和离线最终进入同一个 `Fix`/trace 结构，A2.2 的分类器接口可以复用。

## 5. 测试

- `gnss_quality_selftest`（新增，18 项）：精确匹配、相邻不匹配、重复、缺失、
  乱序、迟到、过期、未知字段保持 has_*=false、计数不重复。
- 既有 9 个自测全部 PASS。
- Python：`fast_livo.msg.GnssQuality` 可导入并赋值；relay/feed 通过 `py_compile`。

## 6. A2.1d 回归

要求：质量字段存在但门控关闭时，轨迹与 A1 完全一致。

| 数据 | A1 TUM SHA256 | A1+quality TUM SHA256 | 结果 |
|---|---|---|---|
| c01 | `07dbf599…` | `07dbf599…` | **逐文件相同** |
| c02 | `8055e1a9…` | `8055e1a9…` | **逐文件相同** |

trace 质量列覆盖（RTKLIB 表与 fix 历元按整数秒匹配）：

| 数据 | trace 行 | `q_source=rtklib` | 覆盖率 | 平均 nsat | 平均 pdop | has_h/v_acc |
|---|---:|---:|---:|---:|---:|---:|
| c01 | 604 | 559 | 92.5% | 12.8 | 3.59 | 0（表里没有） |
| c02 | 802 | 729 | 90.9% | 13.6 | 3.00 | 0（表里没有） |

未覆盖的历元保持 `q_source="" / has_*=0`，不是伪造的 0 值。质量字段进入
trace 但 TUM 完全不变，满足 A2.1 的“只传输、不改算法”验收条件。

## 7. 明确未改

- `InterpolatedAbsPosFactor`、RTK 因子 sigma、Cauchy 参数；
- 静态规则、A1 时间关联；
- 现有质量门控结果（`quality_ok` 仍只读 status/sigma，不读新字段）；
- `addFix` 跳变门限。

## 8. 限制

- relay 只在代码层验证，未在真实 ublox 流上跑；`p_dop` 的无量纲约定依赖
  `GnssPVTSolnMsg` 生产端已经做过 0.01 缩放；
- `h_acc/v_acc` 到 sigma 的映射仍未确定，A2.4 之前不动；
- 同输入 harness 不经过 LIVMapper，A2.1d 验证的是“后端携带字段不改变轨迹”；
  relay→mapper 的精确匹配由单测覆盖，真实链路仍需 bag 复跑。
