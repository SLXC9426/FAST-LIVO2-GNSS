import numpy as np

RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"
REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\campus01_reference.tum"


def load_tum(p):
    d = np.loadtxt(p)
    return d[:, 0], d[:, 1:4]


def interp(rt, rp, qt):
    return np.array([np.interp(qt, rt, rp[:, k]) for k in range(3)]).T


def umeyama(est, gt):
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg


# ---- P2: frontend vs factor-graph smoothed ----
rt, rp = load_tum(REF)
for name, label in (("great_campus01_graph", "frontend ESKF"), ("great_campus01_graph_graph", "factor-graph")):
    ft, fp = load_tum(f"{RES}\\{name}.txt")
    t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
    m = (rt >= t0) & (rt <= t1)
    p_f = interp(ft, fp, rt[m])
    p_g = rp[m]
    e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
    de = np.diff(p_f, axis=0)
    dg = np.diff(p_g, axis=0)
    rpe = np.linalg.norm(de - dg, axis=1)
    print(f"P2 {label:14s}: APE_rmse {np.sqrt(np.mean(e**2)):6.2f} m | mean {np.mean(e):5.2f} | "
          f"max {np.max(e):6.2f} | RPE {np.sqrt(np.mean(rpe**2)):4.2f} | n={m.sum()}")

# ---- P2: latency ----
lat = np.loadtxt(f"{RES}\\great_campus01_graph_latency.csv", delimiter=",", skiprows=1)
if lat.ndim == 1:
    lat = lat.reshape(1, -1)
print("\nP2 latency (ms):")
for name, v in (("frontend e2e", lat[:, 1]), ("graph opt", lat[:, 2]), ("graph queue", lat[:, 3]), ("graph output lag", lat[:, 4])):
    print(f"  {name:16s}: mean {np.mean(v):8.2f}  p50 {np.percentile(v, 50):8.2f}  p95 {np.percentile(v, 95):8.2f}  max {np.max(v):9.2f}")

# ---- P3: dynamic stats ----
dyn = np.loadtxt(f"{RES}\\great_campus01_dynamic_dyn.csv", delimiter=",", skiprows=1)
if dyn.ndim == 1:
    dyn = dyn.reshape(1, -1)
ratio = dyn[:, 3] / np.maximum(dyn[:, 1], 1)
print(f"\nP3 dynamic/occluded ratio: mean {np.mean(ratio)*100:.2f}%  p95 {np.percentile(ratio,95)*100:.2f}%  "
      f"max {np.max(ratio)*100:.1f}%  over {len(dyn)} frames")
print(f"P3 matched-inlier ratio : mean {np.mean(dyn[:,2]/np.maximum(dyn[:,1],1))*100:.2f}%")
