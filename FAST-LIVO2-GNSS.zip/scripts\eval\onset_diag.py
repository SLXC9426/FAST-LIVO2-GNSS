#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Motion-onset diagnostic: compare the estimate and the reference as time series.

Prints, per time bucket, the displacement each trajectory actually travelled and
the position error, after a global 2D alignment. This separates three very
different situations that a single APE number cannot:

  * the estimate moves while the reference is stationary (fabricated motion),
    or vice versa (lost motion)  -> a scale / onset problem;
  * both move equally but the error is a constant offset  -> a datum problem;
  * the error grows smoothly  -> ordinary drift.

Usage:
  onset_diag.py <reference.tum> <traj> [--buckets N] [--from S] [--to S]
"""
import sys
import numpy as np


def load(p):
    t, x = [], []
    for l in open(p):
        q = l.split()
        if len(q) >= 4:
            try:
                t.append(float(q[0]))
                x.append([float(q[1]), float(q[2]), float(q[3])])
            except ValueError:
                pass
    return np.array(t), np.array(x)


def umeyama2d(src, dst):
    ms, md = src[:, :2].mean(0), dst[:, :2].mean(0)
    H = (src[:, :2] - ms).T @ (dst[:, :2] - md)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R2 = Vt.T @ np.diag([1, d]) @ U.T
    R = np.eye(3)
    R[:2, :2] = R2
    return R, np.array([md[0], md[1], 0.0]) - R @ np.array([ms[0], ms[1], 0.0])


def main():
    a = sys.argv[1:]
    ref, traj = a[0], a[1]
    nb, t_from, t_to = 15, None, None
    i = 2
    while i < len(a):
        if a[i] == "--buckets":
            nb = int(a[i + 1]); i += 2
        elif a[i] == "--from":
            t_from = float(a[i + 1]); i += 2
        elif a[i] == "--to":
            t_to = float(a[i + 1]); i += 2
        else:
            i += 1

    rt, rp = load(ref)
    t, x = load(traj)
    if len(t) < 5:
        print("!! too few poses")
        return 1
    # --from/--to are offsets in seconds from the trajectory's first pose
    # (the raw stamps are absolute UNIX seconds, which nobody wants to type).
    t_base = t[0]
    if t_from is not None:
        m = t >= t_base + t_from
        t, x = t[m], x[m]
    if t_to is not None:
        m = t <= t_base + t_to
        t, x = t[m], x[m]
    if len(t) < 5:
        print("!! selection has too few poses")
        return 1

    ir = np.array([int(np.argmin(np.abs(rt - v))) for v in t])
    ok = np.abs(rt[ir] - t) < 0.25
    R, tr = umeyama2d(x[ok], rp[ir][ok])
    al = (R @ x.T).T + tr

    t0, t1 = t[ok][0], t[ok][-1]
    edges = np.linspace(t0, t1, nb + 1)
    print("ref: %d poses | traj: %d poses | aligned on %d" % (len(rt), len(t), ok.sum()))
    print("%8s %10s %10s %10s %10s %9s" %
          ("t_start", "est_step", "ref_step", "est_cum", "ref_cum", "err_2d"))
    ecum = rcum = 0.0
    for k in range(nb):
        m = (t[ok] >= edges[k]) & (t[ok] < edges[k + 1])
        idx = np.where(m)[0]
        if len(idx) < 2:
            continue
        est_step = np.sum(np.linalg.norm(np.diff(al[ok][idx][:, :2], axis=0), axis=1))
        ref_step = np.sum(np.linalg.norm(np.diff(rp[ir][ok][idx][:, :2], axis=0), axis=1))
        ecum += est_step
        rcum += ref_step
        err = np.linalg.norm(al[ok][idx][:, :2] - rp[ir][ok][idx][:, :2], axis=1)
        print("%8.1f %10.2f %10.2f %10.2f %10.2f %9.2f" %
              (edges[k] - t0, est_step, ref_step, ecum, rcum, np.sqrt((err ** 2).mean())))
    return 0


if __name__ == "__main__":
    sys.exit(main())
