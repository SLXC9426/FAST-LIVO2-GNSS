#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Extract file entries for a station from a CDDIS directory listing (HTML).

CDDIS listings are Apache index pages; the file names appear inside href
attributes. Kept as a script rather than a shell one-liner because the patterns
contain '>' which cmd would treat as a redirection.

Usage: list_cddis.py <listing.html> [station_prefix]
"""
import re
import sys

path = sys.argv[1]
prefix = sys.argv[2] if len(sys.argv) > 2 else "WUH"

html = open(path, encoding="utf-8", errors="ignore").read()
names = [n.strip() for n in re.findall(r'href="([^"]+)"', html)]
# CDDIS file rows: <a class="archiveItemText" id="NAME" title="DataFile" href="NAME ">
# followed later by <span class="fileInfo">SIZE</span>. Keep the trailing space in
# mind: the raw href value ends with one, so names must be stripped.
rows = re.findall(r'id="([^"]+\.(?:gz|crx|rnx|tar|zip|Z))"[^>]*>.*?fileInfo">([^<]*)<', html, re.S)
files = [n for n in names if re.search(r"\.(gz|crx|rnx|Z|zip|tar)$", n, re.I)]
station = [n for n in files if n.upper().startswith(prefix.upper())]
size = {}
for n, s in rows:
    size[n.strip()] = s.strip()

print("total hrefs: %d, data files: %d, %s*: %d" % (len(names), len(files), prefix, len(station)))
for n in sorted(station)[:40]:
    print("   %-52s %s" % (n, size.get(n, "")))
if not station:
    print("--- first 25 hrefs (to see the listing format) ---")
    for n in names[:25]:
        print("  ", n)
    hits = [m.start() for m in re.finditer(prefix, html, re.I)]
    print("--- occurrences of %r in the page: %d ---" % (prefix, len(hits)))
    for h in hits[:5]:
        print("   ...", html[max(0, h - 120):h + 80].replace("\n", " "))
