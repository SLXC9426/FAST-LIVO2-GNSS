﻿#ifndef GLOBAL_POSE_GRAPH_H_
#define GLOBAL_POSE_GRAPH_H_

#include <Eigen/Dense>
#include <atomic>
#include <condition_variable>
#include <cstdint>
#include <deque>
#include <fstream>
#include <map>
#include <mutex>
#include <string>
#include <thread>
#include <vector>

#include "gnss_innovation.h"
#include "gnss_quality.h"
#include "graph_fit.h"
#include "rtk_time_association.h"
#include "static_anchor_validity.h"

namespace fast_livo
{

// P5b: bounded-history global position graph (GTSAM), the online port of the
// validated offline v2 factor set (P1a static rigid + P1b transition + P4a z).
// It consumes keyframes and raw ENU fixes, solves the last `window` keyframes
// on a background thread, and writes the smoothed window as a TUM file.
// Default-off: LIVMapper only creates it when online_graph/en is true.
//
// P0 (2026-10-30): the graph now also consumes the per-epoch RTK quality
// record, the per-keyframe LiDAR Hessian lambda_min, and the raw DD epochs.
// The latter add TDDD (time-differenced double-difference) relative factors,
// which are the independent relative observation the LIO+RTK pair lacks.
class GlobalPoseGraph
{
public:
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  struct Keyframe
  {
    double t = 0.0;
    Eigen::Vector3d p = Eigen::Vector3d::Zero();
    Eigen::Matrix3d R = Eigen::Matrix3d::Identity();
    // Result nodes only: input LIO position before global optimization.
    Eigen::Vector3d p_in = Eigen::Vector3d::Zero();
    // Min eigenvalue of the 6-DoF LiDAR pose Hessian (0 = unknown).
    double lambda_min = 0.0;
    // R4.3: optimized ENU velocity at this node (result field, not an input).
    Eigen::Vector3d v = Eigen::Vector3d::Zero();
    // R4.2c: frontend's locked world<-ENU transform (world = R*enu + t) and LIO
    // scale. When valid, the graph uses it instead of its own yaw fit.
    bool have_frame = false;
    Eigen::Matrix3d R_world_from_enu = Eigen::Matrix3d::Identity();
    Eigen::Vector3d t_world_from_enu = Eigen::Vector3d::Zero();
    double frame_scale = 1.0;
  };

  struct Fix
  {
    double t = 0.0;
    Eigen::Vector3d p = Eigen::Vector3d::Zero();
    // P0 quality record. sigma_h/v are 1-sigma metres (0 = use the legacy
    // auto-sigma). status follows GNSS_FIX_STATUS; nsat/pdop/sigma0/rms_xyz
    // are 0 when the source does not carry them.
    double sigma_h = 0.0;
    double sigma_v = 0.0;
    int status = -1;
    int nsat = 0;
    double pdop = 0.0;
    double sigma0 = 0.0;
    double rms_xyz = 0.0;
    // A2.1: per-epoch quality metadata. Carried into the trace only; no factor,
    // sigma or gate reads these fields yet.
    unsigned int h_acc_mm = 0;
    unsigned int v_acc_mm = 0;
    int carr_soln = 0;
    int fix_type = 0;
    bool quality_valid = false;
    bool has_p_dop = false;
    bool has_h_acc = false;
    bool has_v_acc = false;
    std::string quality_source;
  };

  // One double-difference pair of a single epoch. ECEF positions are kept so
  // the graph can evaluate the geometry in its own ENU frame.
  struct DdPair
  {
    std::string sys, freq, ref, sat;
    double code = 0.0;         // DD pseudorange, m
    double phase = 0.0;        // DD carrier phase, m (already x wavelength)
    double sigma_phase = 0.015;
    double elev_sat = 0.0;
    double elev_ref = 0.0;
    Eigen::Vector3d sat_ecef = Eigen::Vector3d::Zero();
    Eigen::Vector3d ref_ecef = Eigen::Vector3d::Zero();
    bool slip = false;
    bool ref_change = false;
  };
  struct DdEpoch
  {
    double t = 0.0;
    double ratio = 0.0;  // ambiguity-fix ratio from the producer; 0 = unknown
    std::vector<DdPair> pairs;
  };

  // R4.3: one Doppler velocity epoch in the graph ENU frame.
  struct Vel
  {
    double t = 0.0;
    Eigen::Vector3d v = Eigen::Vector3d::Zero();
    double sigma_h = 0.0;  // <=0 = unknown, use the configured floor
    double sigma_v = 0.0;
    std::string source;    // "ins" or "doppler"; diagnostic only
  };

  struct Config
  {
    int window = 1500;                 // bounded history (keyframes)
    Eigen::Vector3d lever = Eigen::Vector3d(-0.05, -0.325, 0.165);
    // P0: 0.01 m is the offline Stage-2 static zero-displacement sigma. The
    // old 0.005 was so stiff that the anchors dominated the absolute factors.
    double sig_rigid = 0.01;
    // Rotation sigma for the static-rigid and LIVO relative-pose factors. The
    // graph now optimizes Pose3, so orientation is a real constraint; these are
    // 1-sigma tangent-angle values (rad), not degrees.
    double sig_rigid_rot = 0.005;
    double sig_odom_rot = 0.01;
    // Pose3 has a free global-orientation gauge: only relative rotation factors
    // constrain it. Anchor the first node's rotation weakly to the LIO/ENU
    // initialization so the solver cannot drift along that null direction.
    double sig_rot_prior = 0.01;  // rad

    // ---- R4.3: Doppler velocity nodes ------------------------------------
    bool vel_en = true;
    double vel_sigma_floor = 0.20;   // m/s, never trust the receiver below this
    double vel_sigma_ceil = 2.0;     // m/s, never fully discard a velocity epoch
    double vel_max_dt = 1.0;         // s, max gap between the two keyframe nodes
    double vel_rw_sigma = 0.5;       // m/s per sqrt(s), random-walk smoothness
    // Trapezoidal position/velocity consistency: p_j - p_i ~= 0.5*(v_i+v_j)*dt.
    // Without this the velocity nodes are a separate smoother and cannot
    // correct the pose trajectory. sigma(dt) = sqrt(sig_motion^2 +
    // motion_accel_psd*dt^3/3); the PSD term is a white-acceleration model and
    // is not yet calibrated on real data.
    double sig_motion = 0.10;        // m, model floor
    double motion_accel_psd = 0.01;  // m^2/s^3
    // R4.4: compute the true marginal covariance at the latest pose/velocity.
    // This factorizes the linearized graph, so it costs more than the solve;
    // set false if the node must run at a very tight CPU budget.
    bool cov_en = true;

    // ---- R4.4b: fixed-lag boundary prior --------------------------------
    // When the window drops its oldest node, the factors touching it are lost.
    // The new oldest node inherits the previous solve's single-node marginal as
    // a prior. This is a block-diagonal approximation of the joint Schur
    // marginalization (cross-correlations with the other retained nodes are not
    // represented), not a full fixed-lag smoother.
    bool fixed_lag_en = true;
    double boundary_sigma_pos = 0.05;  // m, fallback when no marginal is available
    double boundary_sigma_rot = 0.005; // rad
    double boundary_sigma_vel = 0.05;  // m/s
    // Static anchor consistency. c01's static RTK is good (~0.2 m from LIO)
    // and a strong anchor is best; c02's static RTK has a ~4 m bias, and a
    // strong anchor pulls the static run away from the moving one (full 2D
    // 0.833 -> 1.992 on c01 when the anchor was weakened unconditionally).
    // Rule: |anchor - LIO static median| <= static_anchor_consistency ->
    // sig_anchor (strong); otherwise static_anchor_weak.
    double sig_anchor = 0.3;
    double static_anchor_weak = 10.0;
    double static_anchor_consistency = 1.0;
    double detect_thresh = 0.20;
    int detect_win = 3;
    // ---- A3.1: static-anchor validity gate ------------------------------
    // Default off. When on, it only decides whether an existing static-run
    // anchor factor may be inserted; the legacy anchor estimator, sigma and
    // every A2 gate remain untouched. WEAK and UNAVAILABLE both skip add_abs.
    bool static_anchor_validity_en = false;
    // A3.2: unified-set estimation. Requires static_anchor_validity_en. When
    // on, a VALID run's anchor is re-estimated from exactly the validity-
    // selected carrier-fixed subset (sample-ID chain traced next to the
    // diagnostics path); rejected samples never re-enter the anchor.
    bool static_anchor_unified_en = false;
    StaticAnchorValidityParams static_anchor_validity;
    std::string static_anchor_diagnostics_path;
    std::string anchor_trace_path;  // read-only actual anchor/noise snapshot
    // R0/R2: read-only diagnostics, empty = off; they never feed back into
    // estimation. solve_watermark_path gets a JSONL record per solve (input
    // snapshot watermarks, fit support) plus a final receive summary;
    // usage_trace_path gets the real fix-ID usage of the initial-fit samples
    // and the transition factors (CSV, rewritten per solve).
    std::string solve_watermark_path;
    std::string usage_trace_path;
    // A4/W1: fixed odometer horizontal sigma (meters). 0 = disabled, use the
    // historical fit_rms formula; a positive value replaces it (clamped to
    // [0.05, 0.5]) and changes nothing else.
    double odom_sigma_fixed = 0.0;
    double trans_sigma_xy = 0.2;
    double trans_sigma_z = 1.0;
    int trans_kf = 8;
    double sig_odom_z = 0.10;
    double sig_rtk_z = 2.0;
    double max_fix_error = 30.0;  // m, prediction error for a fix jump
    double max_fix_dt = 2.0;      // s, longer gaps reset the reference
    double solve_rate = 2.0;      // Hz, cap re-solves when fixes arrive at 10 Hz
    bool prioritize_new_keyframes = false;
    std::string output_path;

    // ---- P0: TDDD relative factors -------------------------------------
    bool tddd_en = true;
    // Base station ECEF used by the DD generator. campus-01 and campus-02
    // differ by a few metres, so the node overrides this from the launch file.
    Eigen::Vector3d base_ecef =
        Eigen::Vector3d(-2267749.9279, 5009154.2407, 3221290.6333);
    double tddd_sigma_scale = 1.0;
    int tddd_min_pairs = 6;
    // 0.25 s is the correct tolerance once the DD/keyframe phase offset is
    // removed. Widening it to 0.6 s (the c02 phase is .35 s) matched DD epochs
    // that were not time-aligned with the keyframe interval and added biased
    // TDDD rows (c01: 2440 -> 7305 rows, full 2D 0.833 -> 1.97).
    double tddd_max_dt = 0.25;     // s, keyframe <-> DD epoch tolerance
    // Do NOT estimate a single global shift by default: c01's keyframe phase
    // drifts from -0.05 to -0.10 s over the run, and a global median shifted
    // the matching epoch (c01 full 2D 0.833 -> 1.096). The correct default is
    // no shift + 0.25 s; c02 (a stable +0.40 s phase) can set the shift
    // explicitly. Per-interval interpolation is the proper long-term fix.
    bool tddd_time_shift_auto = false;
    double tddd_time_shift = 0.0;  // explicit override (s)
    bool tddd_freq_sigma_en = true;
    bool tddd_elev_weight_en = true;
    // R4.5/R3-lite: two-epoch noise, quality gate and non-overlapping anchors.
    // - sigma^2 = sigma_phase(e1)^2 + sigma_phase(e2)^2 + model^2
    // - ratio (when known) must be >= tddd_min_ratio
    // - a DD epoch may appear in at most one TDDD factor, otherwise the same
    //   phase observation is counted twice without a cross-covariance.
    double tddd_model_sigma = 0.01;   // m, time sync/atmosphere/model floor
    double tddd_min_ratio = 0.0;      // 0 = do not gate on ratio
    bool tddd_nonoverlap = true;
    // Correlation between DD rows sharing the reference satellite within one
    // epoch: Cov(DD_i, DD_j) = rho * min_k(sigma_k^2), i != j. 0 = diagonal
    // (the old, over-confident model); 0.5 is the equal-SD approximation.
    double tddd_ref_corr = 0.5;

    // ---- A1: RTK epoch <-> keyframe time association -------------------
    // true: each RTK epoch becomes one InterpolatedAbsPosFactor evaluated on
    // the Pose3 geodesic between its two bracketing keyframes. false restores
    // the A0 unique-nearest rule (0.6 s, one fix per keyframe) and executes the
    // unchanged legacy factor loop. mapping_great.launch turns it on by default
    // for the A1 arm.
    bool rtk_interp_en = false;
    RtkInterpParams rtk_interp;
    // A1 ablation: static-epoch rule, independent of the placement rule.
    // true  = A1: drop an epoch when either bracketing keyframe is a static
    //         member (epoch-level rule).
    // false = A0-compatible: drop an epoch only when the keyframe it would be
    //         attached to (nearest keyframe) is a static member. A0 already
    //         skips static keyframes; this makes the static rule explicit and
    //         lets A1-T isolate the time-placement change from it.
    bool rtk_static_rule_bracket = true;
    // Motion-model floor (m) added in quadrature to the RTK sigma. It covers
    // the constant-body-twist assumption between keyframes (acceleration,
    // angular rate, lever-arm rotation, LiDAR/GNSS time sync), not the RTK
    // measurement itself. First-round conservative value; needs calibration.
    double rtk_interp_model_sigma = 0.10;
    // Cauchy kernel on the 3D interpolated residual. The legacy path uses
    // separate XY (Cauchy) and Z (Huber) kernels; a single 3D factor cannot
    // split them, so this is one switch for the whole vector.
    bool rtk_interp_robust_en = true;
    // Optional CSV trace of the epoch association (one row per RTK epoch seen
    // in the retained window). Empty = no file.
    std::string assoc_trace_path;
    // A2.2: thresholds of the unified quality classifier.
    GnssQualityParams gnss_quality;
    // A2.3: optional class gate. Default off, so A1/A2.1/A2.2 behaviour is
    // unchanged. When on, classification can reject an absolute factor; it
    // still does not change any sigma or the A1 time association.
    bool rtk_class_gate_en = false;
    GnssQualityGatePolicy rtk_class_gate;
    // A2.4: independent-prediction innovation gate. Default off. The prediction
    // is anchor_fix + scaled LIO displacement; P_pred grows with travelled
    // distance. This is the test that can catch the 26-29 m outliers the class
    // gate and the 30 m jump gate miss.
    bool rtk_innovation_gate_en = false;
    GnssInnovationParams rtk_innovation;
    // ---- A2.5: robust / two-pass initial alignment -----------------------
    // The innovation prediction uses the fitted yaw/scale and sig_rtk_xy comes
    // from the fit RMS, so a 26-29 m outlier in the fit pollutes the gate that
    // is supposed to reject it. Pass 1 fits everything; the innovation screen
    // produces a fixed mask; pass 2 refits on accepted samples only.
    double fit_max_bracket_sec = 0.0;  // 0 retains the unbounded fit support
    bool fit_reject_bad_endpoints = false;
    bool fit_use_frontend_yaw = true;
    double fallback_position_sigma = 0.01;
    bool fit_robust_en = false;        // Huber IRLS for pass 1
    double fit_huber_k = 1.5;          // MAD units
    bool fit_two_pass_en = false;      // requires rtk_innovation_gate_en
    int fit_min_samples = 20;
    double fit_min_accepted_ratio = 0.5;
    double fit_max_scale_delta = 0.05;
    double fit_max_yaw_delta_deg = 5.0;
    double fit_max_gap_ratio = 0.5;    // largest accepted gap / span
    // A second fit must reduce the accepted-sample RMS by at least this
    // fraction; otherwise the first fit is kept. This prevents a tiny scale
    // change with no residual gain from being amplified by the trajectory
    // length (0.06% over 2 km is already ~1 m).
    double fit_min_rms_gain = 0.01;

    // ---- P0: per-epoch quality gate / sigma ----------------------------
    bool quality_gate_en = true;
    int quality_min_status = 2;    // float or better
    int quality_min_nsat = 0;      // 0 = disabled
    double quality_max_pdop = 0.0; // 0 = disabled
    double quality_max_sigma0 = 0.0;
    double quality_max_rms = 0.0;
    double sigma_h_floor = 0.15;
    double sigma_h_ceil = 5.0;
    double sigma_v_floor = 0.3;
    double sigma_v_ceil = 10.0;

    // ---- P0: separate XY robust kernel ---------------------------------
    bool cauchy_xy_en = true;
    double cauchy_xy_k = 1.0;

    // ---- P0: degeneracy-aware RTK weight -------------------------------
    bool lambda_weight_en = true;
    double lambda_expected_sigma = 0.4;
    double lambda_fit_k = 4.5;
    double lambda_w_min = 0.2;

    // ---- P0: global LIO scale in the initial fit -----------------------
    // c02's LIO span is ~8.6% short of GNSS. The graph estimates one 2D
    // similarity scale together with yaw/translation; TDDD/absolute factors
    // then see a metrically consistent LIO shape.
    bool scale_fit_en = true;
    double scale_min = 0.90;
    double scale_max = 1.10;
  };

  // A2.5: which fit was applied and why a second pass was refused.
  struct FitDiagnostics
  {
    int n_total = 0;
    int n_accepted = 0;
    double scale1 = 1.0;
    double scale2 = 1.0;
    double yaw1 = 0.0;
    double yaw2 = 0.0;
    double rms1 = 0.0;
    double rms2 = 0.0;
    double rms1_accepted = 0.0;  // pass-1 fit evaluated on the accepted mask
    int applied_pass = 1;
    std::string fallback;
  };

  struct Stats
  {
    double last_solve_ms = 0.0;
    double last_result_stamp = 0.0;
    double oldest_stamp = 0.0;
    double newest_stamp = 0.0;
    uint64_t result_seq = 0;
    int keyframes = 0;
    int total_keyframes = 0;
    int fixes = 0;
    int rtk_used = 0;
    // A1: epochs that produced a factor, plus disjoint skip counters so the
    // ablation can tell a static rule from a quality/association rejection.
    int rtk_interp_used = 0;
    int rtk_skip_static = 0;
    int rtk_skip_quality = 0;
    int rtk_skip_assoc = 0;
    int rtk_skip_class = 0;
    int rtk_innov_rejected = 0;
    int rtk_innov_invalid = 0;
    // Epochs addFix's 30 m prediction gate dropped before the solve. They get
    // a trace row with decision jump_rejected so the epoch table is complete.
    int rtk_pre_rejected = 0;
    int rejected_fixes = 0;
    int solves = 0;
    int status = 0;  // 0=idle, 1=ok, 2=not enough data, 3=solve error
    bool window_slid = false;  // total_keyframes > window; oldest nodes dropped
    // P0 diagnostics.
    int tddd_used = 0;
    int dd_epochs = 0;
    int vel_used = 0;
    double vel_rms = 0.0;  // m/s, RMS of the interpolated Doppler residual
    int marginalized = 0;  // 1 if this solve used a boundary prior
    double scale = 1.0;
    double w_rtk_med = 1.0;
    FitDiagnostics fit;
  };

  // Fixed-size Eigen members in these structs require aligned allocators when
  // the ROS build enables -march=native (AVX); default std::deque/vector
  // allocation can otherwise abort with "double free or corruption".
  using KeyframeVector = std::vector<Keyframe, Eigen::aligned_allocator<Keyframe>>;
  using FixVector = std::vector<Fix, Eigen::aligned_allocator<Fix>>;

  // Immutable snapshot of the last successful solve, consumed by the ROS
  // wrapper to publish odometry/path/status without touching the graph state.
  struct Result
  {
    EIGEN_MAKE_ALIGNED_OPERATOR_NEW
    bool valid = false;
    uint64_t seq = 0;
    double stamp = 0.0;      // last keyframe time
    double solve_ms = 0.0;
    int keyframes = 0;
    int total_keyframes = 0;
    int fixes = 0;
    int rtk_used = 0;
    int rejected_fixes = 0;
    bool window_slid = false;
    Eigen::Matrix3d Rz = Eigen::Matrix3d::Identity();  // ENU <- LIO world yaw
    Eigen::Vector3d tr = Eigen::Vector3d::Zero();      // ENU <- LIO world translation
    double scale = 1.0;      // LIO -> ENU horizontal similarity scale
    KeyframeVector nodes;    // t, optimized p, EKF orientation passthrough
    // R4.4: marginal posterior of the latest pose/velocity, in the GTSAM local
    // tangent frame (body). cov_pose is reordered to ROS [pos, rot].
    bool cov_valid = false;
    Eigen::Matrix<double, 6, 6> cov_pose = Eigen::Matrix<double, 6, 6>::Zero();
    Eigen::Matrix<double, 3, 3> cov_vel = Eigen::Matrix<double, 3, 3>::Zero();
  };

  explicit GlobalPoseGraph(const Config &cfg);
  ~GlobalPoseGraph();

  void addKeyframe(const Keyframe &kf);
  void addFix(const Fix &fx);
  void addDdEpoch(const DdEpoch &dd);
  void addVel(const Vel &vel);
  // ENU frame origin (WGS84). Required for the TDDD geometry. The first fix's
  // origin is normally the same frame the ENU positions are expressed in.
  void setEnuOrigin(double lat, double lon, double alt);
  Stats getStats() const;
  bool getLatestResult(Result &out, uint64_t &last_seq) const;
  void stop();

private:
  // R4.4b: single-node marginal of a keyframe that will become the new window
  // boundary, expressed in the world frame so it survives frame re-fits.
  struct BoundaryPrior
  {
    bool valid = false;
    bool have_pose_cov = false;
    bool have_vel_cov = false;
    Eigen::Matrix3d R_world = Eigen::Matrix3d::Identity();
    Eigen::Vector3d p_world = Eigen::Vector3d::Zero();
    Eigen::Vector3d v_world = Eigen::Vector3d::Zero();
    // GTSAM local order: pose [rot, trans], velocity [v].
    Eigen::Matrix<double, 6, 6> cov_pose = Eigen::Matrix<double, 6, 6>::Zero();
    Eigen::Matrix<double, 3, 3> cov_vel = Eigen::Matrix<double, 3, 3>::Zero();
    Eigen::Matrix<double, 6, 3> cov_pose_vel = Eigen::Matrix<double, 6, 3>::Zero();
  };

  // A1: one trace record per RTK epoch, keyed by fix time so duplicate
  // publications collapse. Only written when cfg_.assoc_trace_path is set.
  struct AssocTraceRow
  {
    int key_i = -1;
    int key_j = -1;
    double alpha = 0.0;
    double dt = 0.0;
    double bracket_dt = 0.0;
    int status = -1;
    int quality = -1;
    int static_id = -1;  // static run touching the placement, -1 = none
    int reason = 0;      // AssocReason
    int factor = 0;
    // A2.1: quality of this epoch, copied from the Fix for the trace.
    int nsat = 0;
    double pdop = 0.0;
    unsigned int h_acc_mm = 0;
    unsigned int v_acc_mm = 0;
    int carr_soln = 0;
    int fix_type = 0;
    int q_valid = 0;
    int has_p_dop = 0;
    int has_h_acc = 0;
    int has_v_acc = 0;
    std::string q_source;
    // A2.2: unified classification of this epoch (trace only).
    int q_class = 0;  // GnssQualityClass
    std::string q_reason;
    // A2.4: gamma of the innovation test; -1 = not evaluated.
    double innov_gamma = -1.0;
    // A2.5: 1 if this epoch moved the prediction anchor.
    int anchor_update = 0;
  };

  // R0: receive/solve watermark snapshot, captured in run() under the same
  // lock that copies the solve snapshot. received_* counts what the process
  // accepted; *_buffer counts the deques; the solve's own consumption is
  // recorded separately in the per-solve watermark record.
  struct WatermarkSnapshot
  {
    int64_t snapshot_monotonic_ns = 0;
    int kf_buffer = 0;
    int fix_buffer = 0;
    int received_kf = 0;
    int received_fix = 0;
    double first_kf_t = 0.0;
    double last_kf_t = 0.0;
    double first_fix_t = 0.0;
    double last_fix_t = 0.0;
  };

  void run();
  void solve(const KeyframeVector &kfs, const FixVector &fixes,
             const WatermarkSnapshot &wm_snap);
  void writeAssocTrace(double t_min) const;
  void setStatus(int status);
  // R0: final receive summary, written from stop() so a harness can prove
  // that every published message was actually consumed by this process.
  void writeFinalWatermark();

  Config cfg_;
  mutable std::mutex mtx_;
  std::condition_variable cv_;
  std::deque<Keyframe, Eigen::aligned_allocator<Keyframe>> keyframes_;
  std::deque<Fix, Eigen::aligned_allocator<Fix>> fixes_;
  std::deque<DdEpoch> dd_epochs_;
  std::deque<Vel> vels_;
  // Fixes dropped by the addFix jump gate, kept for the per-epoch trace only.
  std::deque<Fix, Eigen::aligned_allocator<Fix>> rejected_log_;
  std::map<double, BoundaryPrior> boundary_priors_;
  // A1: association trace, solve thread only.
  std::map<double, AssocTraceRow> assoc_trace_;
  Fix last_fix_;
  Fix prev_fix_;
  bool have_last_fix_ = false;
  bool have_prev_fix_ = false;
  bool dirty_ = false;
  bool stop_ = false;
  std::thread thread_;

  bool have_origin_ = false;
  double origin_lat_ = 0.0;
  double origin_lon_ = 0.0;
  double origin_alt_ = 0.0;
  Eigen::Vector3d origin_ecef_ = Eigen::Vector3d::Zero();

  mutable std::mutex result_mtx_;
  Result latest_;
  uint64_t result_seq_ = 0;
  std::atomic<int> total_keyframes_{0};
  std::atomic<int> rejected_fixes_{0};

  // R0: receive watermark. first/last stamps are updated under mtx_ inside
  // the add* callbacks; the counters are atomic so stop() can read them.
  std::atomic<int> received_keyframes_{0};
  std::atomic<int> received_fixes_{0};
  double first_kf_t_ = 0.0;
  double last_kf_t_ = 0.0;
  double first_fix_t_ = 0.0;
  double last_fix_t_ = 0.0;
  std::atomic<uint64_t> solve_seq_{0};
  std::ofstream wm_stream_;  // opened in the ctor when the path is set

  mutable std::mutex stats_mtx_;
  Stats stats_;
};

}  // namespace fast_livo

#endif  // GLOBAL_POSE_GRAPH_H_
