# A3.1 静态锚有效性门：实现与验证

> 分支：`feat/a3.1-static-anchor-validity`（从 `a3-baseline` / `eb64f4f` 创建）
> 实现提交：`c6aca6b`；失败行诊断补全：`a67a528`；证据提交见仓库历史。
> 基线代码：`a2-freeze` / `68da087`；`a3-baseline` / `a2-freeze` 标签均未移动。
> 本阶段只决定是否允许插入既有静态锚因子；未改锚估计、锚噪声、A2 门控和
> A1 静态跳过规则。

## 1. 实现

新增：

- `include/static_anchor_validity.h`：参数、样本、结果、三态/拒绝原因、纯计算接口；
- `src/static_anchor_validity.cpp`：基于 fix 时间的两端裁剪、Fixed/Float 统计、
  净位移/P95/最大偏离/稳健 σ/慢漂移、三态判定；
- `test/static_anchor_validity_selftest.cpp`：合成样本自测。

接入：

- `include/global_pose_graph.h`：`static_anchor_validity_en`、参数、诊断路径；
- `src/global_pose_graph.cpp`：在候选样本收集之后、`add_abs()` 之前调用；
  非 `STATIC_ANCHOR_VALID` 时 `has_anchor=false`，不插入该静态锚；
- `src/online_graph_node.cpp`：读取 ROS 参数；
- `launch/mapping_great.launch`：参数入口，默认关闭；
- `CMakeLists.txt`：新源文件与自测目标。

关闭时（默认）不调用分类器、不写诊断，锚输入与 A2.5 冻结版本一致。

三态：

| 状态 | 条件 | 行为 |
|---|---|---|
| `STATIC_ANCHOR_VALID` | 有参考起点；六个阈值全部配置且通过 | 保留原锚 |
| `STATIC_ANCHOR_WEAK` | 无硬失败，但无参考起点或阈值未配置 | 不插入锚 |
| `STATIC_ANCHOR_UNAVAILABLE` | 样本/Fixed 比例/位移/离散度/慢漂移/窗口失败 | 不插入锚 |

阈值 0 表示未配置，不能当作通过；`VALID` 要求六个阈值全部为正。

### 1.1 FIXED / GOOD 语义审计

`GOOD` 不是独立的非固定类别，而是载波固定解的一个子类：

- `gnss_quality.h::classifyGnssQuality()` 在规定 `fix_type`、`valid` 后，先判
  `carr_soln >= 2`；满足 good 的 nsat/PDOP 门限返回 `GOOD`，否则返回 `FIXED`；
- `GnssQuality.msg` 明确 `carr_soln=2` 为 fixed；
- `gnss_quality_classifier_selftest` 有 “fixed + good geometry -> GOOD” 用例；
- 因此 `FIXED ∪ GOOD` = 载波固定族，`fixed_count` 把两者相加是正确映射，不是
  把“质量良好”当成固定解。`FLOAT` 仍单独计数。

## 2. 自测

- 新增 `static_anchor_validity_selftest`：37 项检查全部 PASS；
- 全量 14 个自测全部 PASS（`A3.1/all_selftests.log`）。

## 3. A3.1 关闭：campus-02 全段回归

最终二进制：

```
e1d856ccf75d69ed13f41bfd6a93f43d1424b012b4fc5f0330fc453f50be3b13  online_graph_node
3e0d5ad3c93eb415e2b800858eda9c22ea67ac934d2da65734b48bfec8aa4c3a  libonline_graph.so
97e20303e707e62b6c86098678160d91b80073872b2a821bef8b6a2bddefde28  static_anchor_validity_selftest
```

运行：`run_arm.sh c02 A3OFF 1 1 1.0 <port>`，805 s，其它参数与 A1 相同。

| 对照 | SHA256 / 差异 |
|---|---|
| `c02_A3OFF.tum` | `e112b7eb6a7db5c2c35823376a2ab180b5bf4d056e0b53c49cb308eae9cc65cc` |
| `c02_A1R.tum`（A2.5 同源参考） | `e112b7eb…65cc` |
| `cmp c02_A3OFF.tum c02_A1R.tum` | **逐字节相同** |
| `c02_A1.tum`（A2.5 前的旧 A1） | `8055e1a9…04cd`；与 A3OFF 最大位置差 `1e-11 m` |

结论：A3.1 关闭时，最终二进制与 A2.5 同源 A1R 逐字节一致。与旧 A1 的
`1e-11 m` 差异是 A2.5 重建已知的浮点重排（A2.5 报告已记录 A1R vs A1
最大 `1e-11 m`），不是 A3.1 引入。

## 4. A3.1 开启：campus-02 启动段（VALID）

配置：`trim_start=13`、`trim_end=2`、`onset=116.9`、`fallback=2`、
`min_samples=80`、`min_fixed_ratio=0.9`、`max_net=1.5`、`max_p95=0.3`、
`max_dev=0.5`、`max_slow=1.2`；120 s，带 c02 质量 CSV。

诊断（`runs/c02_A3ON_valid.csv`）：

| 项 | 值 |
|---|---:|
| raw run | 0–119.1 s，119 个候选样本 |
| 裁剪窗 | 13.0–114.9 s（reference_onset） |
| 裁剪后关键帧 / fix 范围 | 14.0–114.05 s / 13.5–114.5 s |
| 样本 | 101；Fixed/GOOD 101；Float 0；other 0；ratio 1.000 |
| `candidate_q_net_displacement` | 0.0977 m |
| `candidate_q_p95` / `max_deviation` / `sigma` | 0.1136 / 0.1157 / 0.0314 m |
| `candidate_q_slow_drift` | 0.1457 m |
| LIO 净位移 | 0.0110 m |
| 状态 | `STATIC_ANCHOR_VALID` |

CSV/结果结构仍沿用历史字段名，语义对应如下（A3.2 前建议重命名）：

| 历史字段 / CSV 列 | 语义名 |
|---|---|
| `rtk_net_displacement` | `candidate_q_net_displacement` |
| `rtk_robust_p95` | `candidate_q_p95` |
| `rtk_max_deviation` | `candidate_q_max_deviation` |
| `rtk_robust_sigma` | `candidate_q_sigma` |
| `rtk_slow_drift` | `candidate_q_slow_drift` |

这些量描述的是关联、杆臂补偿后的候选锚观测 `q`，不是未经处理的 RTK 原始位置；
不能把 `candidate_q_sigma` 直接解释为接收机测量噪声。

该 run 输出 `c02_A3ON.tum`，SHA256 `8966b8f2…8b21`。同输入、同质量 CSV、
A3.1 关闭的 120 s 对照 `c02_A3QOFF.tum` 哈希相同，`cmp` 逐字节一致：
**VALID 不改变任何因子**。

注意：120 s 截断使检测器末端为 119.1 s（中心窗口缺少未来帧），与 A3 基线的
117.1 s 不同；裁剪到 114.9 s 后不进入锚样本。

## 5. A3.1 开启：失败路径（UNAVAILABLE）

同配置，仅把 `max_slow_drift` 改为 0.05。诊断：

```
状态       STATIC_ANCHOR_UNAVAILABLE
拒绝原因   RTK_SLOW_DRIFT
reason     rtk_slow_drift=0.146>0.050
```

该 run 输出 `c02_A3ONINV.tum`，SHA256 `d3076d42…7c72`；与 VALID 的
`c02_A3ON.tum` 最大位置差 0.3189 m（中位 0.3189 m），确认该静态锚被移除。
首个 run 被拒绝时触发原有 keyframe 0 `p0` 边界先验（无锚时的既有回退），
不是静态锚因子。

## 6. c01 跨数据集机制验证

c01 静态检测得到两个段：0.0–26.0 s（27 帧）和 429.5–605.7 s（177 帧）；
参考运动起点为 28.1 s（>0.5 m）/ 28.8 s（>1.0 m）。启动段 LIO 速度中位
0.0000，无 U 向瞬态；长段原始样本 122 Fixed / 55 Float，适合作为低 Fixed
比例和长段慢漂移的反例。

### 6.1 A3.1 关闭：c01 全段回归

`c01_A3OFF.tum` SHA256 `07dbf599…53b0`，与 A2.5 同源 `c01_A1R.tum`
（`07dbf599…53b0`）**逐字节相同**（606 行）。A3.1 关闭在 c01 上同样保持
A2.5 输出。

### 6.2 c01 启动段：VALID

配置：`trim_start=0`、`trim_end=2`、`onset=28.1`、`min_samples=20`、
`min_fixed_ratio=0.9`、`max_net=1.5`、`max_p95=0.3`、`max_dev=0.5`、
`max_slow=1.2`。

| 项 | 值 |
|---|---:|
| raw / trimmed | 0–26.0 / 0–26.0 s |
| 样本 | 26；Fixed/GOOD 26；Float 0；ratio 1.000 |
| `candidate_q_net_displacement` | 0.073250 m |
| `candidate_q_p95` / `max` / `sigma` | 0.009691 / 0.072319 / 0.002161 m |
| `candidate_q_slow_drift` | 0.016105 m |
| 状态 | `STATIC_ANCHOR_VALID` |

`c01_A3ON.tum` 与同输入、同质量 CSV、关闭状态的 `c01_A3QOFF.tum` 哈希相同
（`ae7993fb…e08`），`cmp` 逐字节一致。把 `max_slow_drift` 收紧到 0.2 后仍
为 `VALID`（slow=0.016 < 0.2），说明该段在更严门限下依然稳定。

### 6.3 c01 长段：LOW_FIXED_RATIO

从 420 s 起回放 200 s，覆盖 429.5–605.7 s 长段；`trim_start=0`、
`fallback_end_trim=2`、`min_fixed_ratio=0.9`：

| 项 | 值 |
|---|---:|
| raw / trimmed | 9.0–185.2 / 9.0–183.2 s（相对回放起点） |
| 样本 | 177 raw；173 trimmed；Fixed/GOOD 118；Float 55；ratio 0.682 |
| `candidate_q_net` / P95 / max / sigma | 0.478193 / 0.189492 / 0.637694 / 0.017471 m |
| `candidate_q_slow_drift` | 0.380037 m |
| 状态 / 原因 | `STATIC_ANCHOR_UNAVAILABLE` / `LOW_FIXED_RATIO` |

此前的实现先做数量/比例检查再算统计，导致失败行统计为 0；现已把统计移到
数量/比例检查之前（`a67a528`），失败行也会输出 candidate-q 诊断。

### 6.4 c01 长段：慢漂移与长度对比

同一长段，`min_fixed_ratio=0.6`（0.682 通过）、`max_slow_drift=0.2`：
状态 `STATIC_ANCHOR_UNAVAILABLE`，原因 `RTK_SLOW_DRIFT`，
`candidate_q_slow_drift=0.380>0.200`。

同 `max_slow_drift=0.2` 的 26 样本启动段仍 `VALID`（0.016），因此短段与
176 样本长段的慢漂移区分是可见的。

### 6.5 c02 启动瞬态反例

c01 启动段没有 U 向瞬态，因此“包含启动瞬态的候选段应被拒绝”由 c02 承担：
`trim_start=0`、`trim_end=0`、`fallback_end_trim=2` 得到 0–117.1 s：

| 项 | 值 |
|---|---:|
| 样本 | 116；Fixed/GOOD 107；Float 9；ratio 0.922 |
| `candidate_q_net` / P95 / max / sigma | 1.117604 / 0.115650 / 0.865336 / 0.033883 m |
| 状态 / 原因 | `STATIC_ANCHOR_UNAVAILABLE` / `RTK_DISPERSION_TOO_LARGE` |

`max_deviation=0.865>0.5` 触发拒绝；门没有使用 `gap`。注意这里是 Fixed-only
统计：早期 9 个 Float 瞬态样本不计入 P95，但 10–12 s 的 Fixed 瞬态仍使 max
超限。若瞬态全部为 Float，Fixed-only 统计可能放过它；A3.2 切换到 Fixed-only
锚输入后这一风险才真正闭合。

### 6.6 配置差异

c01 启动段使用 `trim_start=0 / onset=28.1 / min_samples=20`，c02 使用
`trim_start=13 / onset=116.9 / min_samples=80`；最大阈值相同
（1.5 / 0.3 / 0.5 / 1.2，ratio 0.9）。控制流在两组数据上成立，但**统一的
trim/最小样本配置尚未建立**，这是阈值跨数据集验收仍未完成的核心原因。

## 7. 基线（关键帧时间）与门（fix 时间）的差异

A3 基线按**关键帧时间**统计：

- 13–116.1 s：104 Fixed，P95 0.114 m，最大 0.690 m；
- 13–115.1 s：103 Fixed，最大 0.140 m。

A3.1 按**关联 fix 时间**裁剪到 13.0–114.9 s：

- 101 Fixed，P95 0.114 m，最大 0.116 m；
- 关键帧 14.0–114.05，fix 13.5–114.5。

两者不矛盾：基线的 0.690 m 样本是 keyframe 116.1 / fix 116.5，已被 fix 时间
终点 114.9 排除；keyframe 13.0 / fix 12.5 也被起点 13.0 排除。这正是风险 C
要求的“按 fix 时间裁剪”，不是统计错误。A3 基线的 104/0.690 仍是关键帧口径的
参考值；门的实际输入是 101/0.116。

另外，A3 基线的“RTK 段内净位移 0.878 m”是**全部原始 fix**（段内首末）的
口径；门的 0.0977 m 是**关联到关键帧、通过 quality_ok、且裁剪后的 q 样本**
口径。二者不能直接互换。门必须用候选锚样本的 q 统计来设阈值；0.878 m 是
全部原始 fix 的端点口径，可能包含未被锚使用的边界/非关联 fix，用它设阈值
会误判候选样本。基线的稳定核 P95 0.114 m 与门的 0.1136 m 一致，说明候选
样本本身稳定。

## 8. 验收清单

### 8.1 代码验收（实现与 c02/c01 控制流）

| 验收项 | 状态 |
|---|---|
| A2 冻结保护 | c02/c01 A3OFF 均与 A1R 逐字节一致；标签未动 |
| 默认关闭 | 不调用分类器、不写诊断；TUM 不变 |
| 按 fix 时间裁剪 | 通过；记录 raw/trimmed 与 kf/fix 范围 |
| Fixed / Float 分开 | 通过；`FIXED`+`GOOD` = 载波固定族，Float 单列 |
| 门与因子插入解耦 | 通过；c02/c01 VALID 均与关闭状态 TUM 相同 |
| 失败路径 | 通过；LOW_FIXED_RATIO、RTK_SLOW_DRIFT、RTK_DISPERSION 均有记录 |
| 失败行统计 | 通过；统计已移到数量/比例检查之前 |
| 可复现性 | 通过；自测确定性；相同配置 TUM 相同 |

### 8.2 跨数据集阈值验收

| 验收项 | 状态 |
|---|---|
| GOOD 与 FIXED 语义审计 | 通过（见 §1.1） |
| c02 启动段 VALID | 通过（机制验证值） |
| c01 启动段 VALID | 通过（机制验证值） |
| c01 低 Fixed 比例拒绝 | 通过（0.682 < 0.9） |
| c01 长段慢漂移拒绝 | 通过（0.380 > 0.2） |
| c01 短段在同 0.2 门限下放行 | 通过（0.016 < 0.2） |
| c02 启动瞬态拒绝 | 通过（max 0.865 > 0.5） |
| 统一 trim/最小样本配置 | **未完成**：c02 用 13 s/80，c01 用 0 s/20 |
| 其它静态段/数据集 | **未完成** |

结论：**A3.1 代码验收通过；阈值跨数据集验收尚未完成**。A3.1 暂不冻结，
A3.2 不开始。

## 9. 未做与风险

- c01 已跑（启动段与长段），但其它静态段/数据集未跑；
- 13 s / 2 s、0 s / 28.1 s、`min_samples=80/20` 与六个阈值仍是**机制验证值**，
  未校准、未冻结；统一 trim/最小样本配置尚未建立；
- 单个 `reference_onset_sec` 只适合启动静态段；长段只能用 fallback，最高
  状态为 WEAK；
- 诊断文件每次求解重写，保留最近一次求解的候选段；
- 慢漂移采用线性趋势位移，非线性漂移可能低估；
- 失败行统计已补齐，但 WEAK 仍不插入锚；A3.2 不开始，直到 A3.1 阈值验收完成。

## 10. 复现命令

```bash
# 自测
bash 06_exec/optimization/run_selftests.sh

# A3.1 关闭全段
bash 06_exec/optimization/run_arm.sh c02 A3OFF 1 1 1.0 11411

# A3.1 开启（VALID）
bash 06_exec/optimization/run_arm_a31.sh c02 A3ON 1 1 1.0 11420 120 '' 1 \
  <c02_quality.csv> 0 0 0 0 0 0 0 1 13 2 116.9 2 80 0.9 1.5 0.3 0.5 1.2 \
  runs/c02_A3ON_valid.csv
```
