# A0/A1 evaluation

reference: `/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data/campus01_reference.tum`

| arm | rows | matched | ATE med/p95/RMSE (m) | abs 2D RMSE | abs 3D RMSE | abs p95 | 2D RMSE after constant-bias removal | RPE1 RMSE | RPE10 RMSE |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| A1 | 606 | 606 | 0.388 / 1.282 / 0.706 | 0.509 | 0.804 | 1.575 | 0.442 | 0.101 | 0.516 |
| B3 | 606 | 606 | 0.402 / 1.287 / 0.710 | 0.511 | 0.807 | 1.576 | 0.443 | 0.101 | 0.518 |

## Segment absolute 2D / 3D / bias-removed 2D RMSE (m)

| arm | 0-120s | 240-360s |
|---|---|---|
| A1 | 0.546 / 0.716 / 0.722 | 0.419 / 0.681 / 0.395 |
| B3 | 0.546 / 0.716 / 0.724 | 0.430 / 0.702 / 0.400 |

- A1 median ENU bias: E -0.015, N 0.386, U 0.181 m

- B3 median ENU bias: E -0.015, N 0.389, U 0.181 m
