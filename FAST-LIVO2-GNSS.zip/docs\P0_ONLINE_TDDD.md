# P0：在线图 TDDD / 质量 / λmin / 尺度（2026-10-30）

## 1. 目标

把离线 Stage-2/Stage-4 已经验证的因子集搬进 C++ `GlobalPoseGraph`，并让在线图
第一次拥有“独立相对观测”：

- TDDD（time-differenced double-difference）相对因子；
- 逐历元 RTK 质量门与 `sigma_h/v`；
- XY/Z 分离的绝对因子（XY Cauchy）；
- 基于 LiDAR Hessian `lambda_min` 的 RTK 权重；
- 初始拟合中的全局 LIO 尺度（c02 的 ~8.6% 尺度差）；
- 静止零位移先验（`sig_rigid=0.01`）。

## 2. 改动文件

| 文件 | 内容 |
|---|---|
| `msg/OnlineGraphKeyframe.msg` | 新增：pose + `lambda_min` |
| `msg/OnlineGraphFix.msg` | 新增：ENU + 协方差 + status/nsat/pdop/sigma0/rms + ENU 原点 |
| `include/global_pose_graph.h` | `Keyframe.lambda_min`、`Fix` 质量字段、`DdPair/DdEpoch`、P0 Config、`addDdEpoch/setEnuOrigin`、`Result.scale`、`Stats.tddd_used/scale/w_rtk_med` |
| `src/global_pose_graph.cpp` | `TdddFactor`、`AbsPosXYFactor`、`AbsPosZFactor`；TDDD 构建；质量门；λmin 权重；全局尺度拟合；静止先验；健康日志 |
| `src/online_graph_node.cpp` | 订阅 `/online_graph/keyframe`（新类型）、`/online_graph/gnss_enu`（新类型）、`/rtk/dd`；参数透传；状态字段 |
| `src/LIVMapper.cpp` | 发布新 keyframe/fix；`lambda_min`；协方差/status/hdop；ENU 原点 |
| `CMakeLists.txt` | 新增消息；`laser_mapping` 的 message 依赖 |
| `launch/mapping_great.launch` | P0 参数与 `base_ecef` |

## 3. 因子与规则

### 3.1 TDDD

对相邻关键帧 `i,i+1`（间隔 0.8–1.2 s）：

1. 找最近的两个 DD 历元（`tddd_max_dt=0.6 s`）。注意：c02 的关键帧在
   bag 的 `.35 s` 相位、DD 历元在整秒，0.25 s 容差会让 c02 一个 TDDD 都配不上
   （实测 `tddd=0`）；0.6 s 后 c02 在 123 s 已有 2,304 条；
2. 取同一 `sys/freq/ref/sat` 的公共对；
3. 丢弃 `slip/ref_change`、仰角 <5° 的对；
4. 在图的 ENU 原点下计算：

```
g = 0.5*(unit(ref1-p)+unit(ref2-p)) - 0.5*(unit(sat1-p)+unit(sat2-p))
y = (phase2 - phase1) - (dd_geom2 - dd_geom1)
```

5. 加 1 维因子 `g·(p_{i+1}-p_i) - y`，σ = `tddd_sigma_scale * sqrt(2) *
   max(sigma_phase, 1e-3)`；L1/L2 8 mm、B3I 15 mm、B2I 25 mm，仰角加权；
6. 每段至少 `tddd_min_pairs=6` 对才加入（避免单历元弱约束）。

### 3.2 质量门

`quality_gate_en` 打开时，绝对因子要求：

- `status >= quality_min_status`（默认 2 = Float 及以上）；
- `nsat/pdop/sigma0/rms` 仅在 >0 时检查（NavSatFix 路径只填 status/σ）。

逐历元 σ：`sigma_h/v` 有效时用其值并 clamp 到 [0.15,5.0]/[0.3,10.0]；否则回退
`6 - 0.6*fit_rms` 的旧 auto-sigma。

### 3.3 鲁棒核

- XY：Cauchy(1.0)，XY 与 Z 分开建模；垂直离群不再削弱水平；
- Z：Huber(1.345)；
- TDDD：Huber(1.345)。

### 3.4 λmin 权重

```
s_fit = fit_rms / 0.4
trust = sigmoid((4.5 - s_fit)/0.25) * sigmoid(s_lam)
w_rtk = 1 - 0.8*trust,  clip [0.2,1]
sigma_h_eff = sigma_h / sqrt(w_rtk)
```

静态节点不参与绝对因子，由 static anchor/零位移先验处理。

### 3.5 全局尺度

初始拟合从刚体升级为 2D 相似变换：yaw + 平移 + 尺度（[0.90,1.10]）。
`lio_p = scale * p_lio`，相对因子/TDDD/绝对因子共享同一尺度；
杆臂 `R*lever` 是物理量，不乘尺度。`Result.scale` 用于 `graph_correction` 的
逆变换。

## 4. 运行

### c01

```bash
roslaunch fast_livo mapping_great.launch rviz:=false \
  seq_name:=p0_c01 cfg:=great_campus01_online
# 另开：主 bag + 1 Hz RTK bag + DD bag
rosbag play -q --queue 5000 campus-01-full.bag \
  campus01_rtk1hz.bag c01_dd_greatmsf.bag
```

### c02（必须覆盖基站 ECEF）

```bash
roslaunch fast_livo mapping_great.launch rviz:=false \
  seq_name:=p0_c02 cfg:=great_campus02_online \
  online_graph_base_ecef:="[-2267750.14853585, 5009154.50747098, 3221294.38263863]"
rosbag play -q --queue 5000 campus-02.bag \
  campus02_rtk1hz.bag c02_dd_greatmsf.bag
```

### 消融开关

```
online_graph_tddd_en:=false
online_graph_quality_gate_en:=false
online_graph_cauchy_xy_en:=false
online_graph_lambda_weight_en:=false
online_graph_scale_fit_en:=false
online_graph_sig_rigid:=0.005
```

健康字段在 `/online_graph/status`：`tddd_used`、`dd_epochs`、`scale`、
`w_rtk_med`；库也会打印 `[ONLINE GRAPH] ...` 健康行。

## 5. 冒烟结果（c01，归档 1 Hz bag + c01_dd_greatmsf.bag）

| 段长 | 图 2D RMSE | EKF 2D RMSE | TDDD 行数 | scale | w_rtk | 单次求解 |
|---|---:|---:|---:|---:|---:|---:|
| 60 s | **0.347** | 0.376 | 913 | 0.985 | 0.67 | 11 ms |
| 180 s | 0.819 | 0.736 | 2,391 | 0.998 | 0.64 | 37–44 ms |

读数：

- TDDD/质量/λmin/尺度链路全部生效；180 s 时尺度稳定在 0.998，说明全局尺度
  估计在长窗口上收敛；
- c01 180 s 图与 EKF 同量级（0.82 vs 0.74），没有出现明显退化；
- 60 s 段图优于 EKF（0.347 vs 0.376），但样本短，不作为结论。

## 5.1 全量结果（2026-10-30，N=1，非受控同输入）

### c01 607 s（强静止锚 0.3 m + scale 开）

| 指标 | P0 图 | 基线图（rerun_1023） |
|---|---:|---:|
| full 3D / 2D | 0.932 / **0.833** | 1.053 / 0.900 |
| steady 3D / 2D | 0.844 / 0.762 | 0.809 / 0.679 |
| movfit 2D | 0.909 | 1.026 |
| stat@movfit 2D | 0.787 | 0.731 |
| static-loc pooled | 0.0025 | 0.0009 |
| along / cross RMS | 0.860 / 0.487 | 0.627 / 0.751 |

c01 的 full/movfit 改善，但 steady 与 along 退化；误差从 cross 转到 along。P0 的
`fit_rms=1.9` 让 λmin 权重只有 0.905（几乎不降 RTK），没有复现离线 Stage-4
c01 λmin 的 along 0.622；说明 λmin 的 `s_fit` 标定需要单独做 c01 A/B。

### c02 806 s（强静止锚 0.3 m + scale 开）

| 指标 | P0 图 | 基线图（rerun_1023） |
|---|---:|---:|
| full 3D / 2D | 1.328 / 1.275 | 1.335 / 1.196 |
| steady 3D / 2D | **0.879 / 0.784** | 1.089 / 0.875 |
| movfit 3D / 2D | **1.063 / 0.974** | 1.286 / 1.083 |
| stat@movfit 2D | 1.898 | 1.504 |
| static-loc first / second | 0.106 / 0.0025 | 0.018 / 0.0005 |
| 0:150 / 115:150 | 0.536 / 0.628 | — |
| 150:300 / 300:450 | 0.800 / 0.399 | — |
| 450:600 / 600:806 | 0.424 / 0.506 | — |

steady/movfit 是真实改善；full 被第一段静止的绝对锚定拖住：`stat@movfit=1.898`
而静止段局部形状只有 0.106。根因是 c02 静止 RTK 的 ~4 m 偏置被 `sig_anchor=0.3`
硬锚进图；scale 在 1.10↔1.00 之间振荡（`fit=8.5`）。

### c02 300 s（弱静止锚 10 m + scale off）

| 指标 | 强锚 + scale 开 | 弱锚 + scale off |
|---|---:|---:|
| full 3D / 2D | 1.175 / 1.059（0–300 段） | **1.175 / 1.059** |
| 0:150 | 0.536 | **0.380** |
| 115:150 | 0.628 | 0.631 |
| 150:300 | 0.800 | 0.853 |
| stat@movfit | 1.898 | **1.150** |
| static-loc first | 0.106 | 0.078 |

弱锚把启动/静止绝对误差显著拉回，代价是 150–300 s 略差（scale off 没修正 c02
的 8.6% 尺度）。正确做法是 **弱锚 + 尺度在可靠窗口后锁定**，而不是全程重估。

### 静止锚不能一刀切：一致性门

c01 用弱锚（10 m）当对照，结果直接崩：

| c01 607 s | 强锚 0.3 m | 弱锚 10 m |
|---|---:|---:|
| full 2D | **0.833** | 1.992 |
| steady 2D | **0.762** | 2.009 |
| stat@movfit 2D | **0.787** | 3.460 |
| static-loc pooled | **0.0025** | 0.0315 |

c01 的静止 RTK 本来只有 ~0.2 m 偏差，弱锚让静止段漂离运动段 3.46 m；c02 的
静止 RTK 有 ~4 m 偏置，强锚又把它拉坏。因此加入一致性门：

```
gap = |RTK static median - LIO static median|
sig_anchor = gap <= 1.0 m ? 0.3 m : 10.0 m
```

c01 的 gap ~0.2 m → 强锚；c02 的 gap ~4 m → 弱锚。这样不需要按数据集写死。

### TDDD 的时间相位：容差不能代替对齐

c01 的 DD 历元在整秒、关键帧在 `.05 s`；c02 的 DD 在整秒、关键帧在
`.35–.40 s`。把 `tddd_max_dt` 从 0.25 放宽到 0.6 虽然让 c02 有了 TDDD，
但 c01 的 TDDD 行数从 2,440 涨到 7,305，full 2D 从 0.833 掉到 1.97——多出来的
是“相位没对齐”的区间。正确做法是估计固定相位差：

```
tshift = median(nearest DD t - keyframe t)   # c01 -0.05 s, c02 +0.40 s
nearest_dd(t) 用 t + tshift 匹配；容差回到 0.25 s
```

实测结论：**全局中位 shift 不可靠**。c01 关键帧相位在 607 s 内从 −0.05 漂到
−0.10 s；用全窗口中位 shift 后 TDDD 从 2,440 涨到 2,977，full 从 0.833 掉到
1.096。因此最终默认是 **`tddd_time_shift_auto=false`、`tddd_time_shift=0`、
`tddd_max_dt=0.25`**；c02 的 +0.40 s 相位稳定，显式传
`online_graph_tddd_time_shift:=0.4`。c01 的最佳仍是“不 shift + 0.25”的 0.833。

注意：即使选了正确 DD 历元，DD 区间与关键帧区间仍有 0.4 s 起点差；严格的
TDDD 应把位置状态插值到 DD 时刻（3 状态因子），这是下一步。

## 6. 已知限制

1. **未跑完整 607 s / c02**：需要 N=3 A/B 才能判断 TDDD+static+Cauchy+λmin+scale
   是否复现离线 Stage-2 的 c02 full 0.820。
2. **初始拟合仍非鲁棒**：`fit_rms`/scale 使用全部 fix；c02 的 4 m 持续偏置可能
   影响尺度。下一步应加 trimmed/IRLS 重拟合。
3. **c01 Cauchy 稳定性**：离线 Stage-2 显示 c01 Cauchy 1.0 的 N=3 极差偏大；
   在线默认打开 Cauchy，需要用 `online_graph_cauchy_xy_en:=false` 做 A/B。
4. **质量字段不完整**：NavSatFix 路径只有 status/σ，没有 NSat/PDOP/sigma0/RMS；
   `OnlineGraphFix` 已留字段，等 `.flt` 质量 CSV 接入后启用。
5. **c02 基站**：必须覆盖 `online_graph_base_ecef`，否则 TDDD 的 base 项错误。
6. **scale 的窗口敏感性**：c01 60 s 时 0.985、180 s 时 0.998；c02 在静止段
   （0–115 s）尺度不可辨识，会钳到 0.90，运动开始后又钳到 1.10（真实约 1.095）。
   下一步需要“LIO 水平跨度 < 阈值时冻结 scale=1”的 guard，或把 scale 做成
   随机游走状态，避免启动段跳变。
7. **c02 主题**：`campus02_rtk1hz.bag` 发布 `/gnss_rtk`，不是 `/gnss`；
   `segment_run_rtk.sh` 的 campus02 默认 `/gnss` 会让图 `fixes=0`。运行时用
   第 8 个参数覆盖为 `/gnss_rtk`。

## 7. 下一步

1. c01 607 s + c02 806 s 全量，N=3；A/B：base / +TDDD / +quality / +Cauchy /
   +λmin / +scale。
2. c02 先看 `scale` 是否落在 1.05–1.10；若不在，检查 base ECEF/时间基/LIO 尺度。
3. 加 trimmed/IRLS 初始拟合，避免 4 m 偏置污染 scale。
4. 在线图静止锚定仍用 LIO mask；c02 的静态绝对误差需要质量门控 RTK 中位 anchor。
