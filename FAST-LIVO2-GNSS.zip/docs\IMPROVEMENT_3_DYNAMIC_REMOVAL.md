# 改进 3：动态目标剔除（几何 + 时间一致性）

## 问题

原系统无任何动态处理：体素图 50 点后永久冻结（`update_enable_=false`），
动态目标（行人/车辆）的点被当作静态表面插入地图，留下"幽灵平面"；
`/dyn_obj` 等发布器是死代码。动态目标对定位与建图的干扰：
1. 移动物体的点被匹配到错误平面（拉偏位姿）；
2. 移动物体表面被建入地图（幽灵平面），此后持续干扰匹配；
3. 车/人遮挡的静态表面无法被重新观测（地图冻结）。

## 方案（几何 + 时间一致性，全部 config 门控，默认关）

### 1) 逐点动态判定（`occlusion.en` 提供证据）

与改进 1 共享的光线遮挡判定：被高置信平面"挡在后方"的点
（`raycast::isPointOccluded`）→ 标记 `pv.is_dynamic` →
不参与匹配、**不插入地图**（`UpdateVoxelMap` 跳过），并记录其遮挡平面。

### 2) 体素时间一致性统计（`dynamic_remove.en`）

`VoxelPlane` 新增统计字段：`obs_count_`（观测点数）、`dynamic_hit_`
（冲突点数）、`dynamic_score_ = dynamic_hit_/max(obs_count_,1)`、`is_dynamic_`。

两个证据来源：
- **遮挡证据**（`StateEstimation` 末尾，串行）：每帧被遮挡点对其遮挡平面
  `obs_count_++ / dynamic_hit_++`——持续被"穿过"的平面（如开过的门、
  移走的车辆留下的幽灵面）快速累积冲突；
- **插入冲突**（`UpdateVoxelMap` 每点）：落入平面片内（`range_dis ≤ 3·radius`）
  但距平面 `> conflict_thresh`（默认 0.5m）的点计为冲突——静止物体旁的
  移动目标若与平面同体素，随时间累积证据。

`checkPlaneDynamics`：`obs_count_ ≥ obs_min` 且 `dynamic_score_ > dynamic_ratio`
→ `is_dynamic_ = true` → 匹配阶段排除、发布/统计排除、遗忘清扫删除。

### 3) 遗忘机制（修复"永久冻结"）

- 每根体素记录 `last_obs_frame_`（插入时刷新）；
- 每 `check_interval` 帧（默认 50）执行 `forgetStaleVoxels()`：
  - 空闲超过 `max_idle_frames`（默认 100）的根体素 → 删除（幽灵平面清除）；
  - 子树含 `is_dynamic_` 平面（`obs_count_ ≥ obs_min`）→ 删除；
- 删除后体素重建，被遮挡的静态表面重新可观测。

### 4) 鲁棒 PCA（与改进 1 共享）

`init_plane` 的 IRLS 重加权保证：动态点混入时平面仍由静态内点主导，
不会因单帧污染而整体错误。

### 5) 输出（接活死代码发布器）

`dynamic_remove.pub_dyn_en`：
- `/dyn_obj`：当前帧被判为动态/遮挡的点（世界系）；
- `/dyn_obj_removed`：剔除后的当前帧；
- `/dyn_obj_dbg_hist`：全图平面中心点，`intensity = dynamic_score_`。

统计日志：`Log/result/<seq>_dyn.csv`（`stamp, total, matched, dyn`），
由 `eval_dynamic.py` 生成动态点比例/内点率曲线。

## 设计要点与边界

- **方向性**：冲突统计针对"被违反的平面"（遮挡证据）与"所在体素的平面"
  （插入冲突），避免把"移动物体自身"误判为静态平面动态——移动物体表面
  由空闲遗忘 + 鲁棒 PCA 处理；
- **参数语义**：`dynamic_ratio=0.6` 意为"冲突点占比超过 60% 且观测数足够"，
  静止墙前的短暂行人不会触发（冲突占比低）；
- **与遮挡的关系**：`occlusion.en` 关闭时仅靠插入冲突统计仍可工作
  （效果弱一些）；两者同开效果最佳（改进 1 文档已说明）。

## 对比方法

同一二进制开关对比（`dynamic_remove.en`），指标：
- 轨迹 APE/RPE（`eval_occlusion.py`）；
- 动态点比例时间曲线 + 匹配内点率（`eval_dynamic.py`）；
- 地图目视：`Log/pcd` 保存的剔除前后地图（`pcd_save.pcd_save_en: true`）。

推荐数据集：GREAT campus-01（道路车辆/行人）、NTU-VIRAL（校园人群）。

## 参数

```yaml
dynamic_remove:
  en: true
  conflict_thresh: 0.5    # 距平面超过该值计为冲突（m）
  dynamic_ratio: 0.6      # 冲突占比阈值
  obs_min: 20             # 判定所需最少观测点数
  max_idle_frames: 100    # 空闲遗忘帧数
  check_interval: 50      # 遗忘清扫周期（帧）
  pub_dyn_en: true        # 发布 /dyn_obj 等
```
