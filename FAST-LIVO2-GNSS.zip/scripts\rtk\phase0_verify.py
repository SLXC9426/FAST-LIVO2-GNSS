#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 0 data audit for the campus-01 RTK tight-coupling work.

Read-only.  Uses a text-level RINEX epoch scanner (fast, no observation parsing)
to verify coverage and epoch alignment.  The observation values themselves are
validated later, in the DD preprocessing stage.
"""
import os
from datetime import datetime

import numpy as np

BASE_DIR = "/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02"
BASE_0200 = os.path.join(BASE_DIR, "base_0200.rnx")
BASE_0215 = os.path.join(BASE_DIR, "base_0215.rnx")
ROVER = "/home/slxc9426/great_pvt/obs/campus-day.20O"
NAV = "/home/slxc9426/great_pvt/gnss/brdm3010.20p"
REF = "/home/slxc9426/eval_great/campus01_reference.tum"
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/logs/phase0_data_audit.txt"

BAG_START = 1603764571.80
WINDOW = 607.0
# RINEX observation epochs are in GPS time; the bag/reference are UTC.
# 2020-10-27: GPS-UTC = 18 s (LEAP SECONDS in both RINEX headers).
LEAP_SECONDS = 18
# bag window 1603764571.8 .. 1603765178.8 UTC == 02:09:31.8 .. 02:19:38.8 UTC
# == 02:09:49.8 .. 02:19:56.8 GPS -> integer GPS epochs 02:09:50 .. 02:19:56.
W0 = np.datetime64("2020-10-27T02:09:50")
W1 = np.datetime64("2020-10-27T02:19:56")
W0_UTC = np.datetime64("2020-10-27T02:09:32")
W1_UTC = np.datetime64("2020-10-27T02:19:38")


def parse_epoch(line):
    """RINEX 3 observation epoch line: > yyyy mm dd hh mm ss.sssssss flag nsat"""
    p = line[1:].split()
    if len(p) < 6:
        return None
    try:
        y, mo, d, h, mi = (int(p[i]) for i in range(5))
        sec = float(p[5])
    except ValueError:
        return None
    whole = int(sec)
    frac = sec - whole
    # 60.0 can appear as a leap second; datetime cannot represent it.
    if whole >= 60:
        whole = 59
        frac = 0.999999999
    return np.datetime64(datetime(y, mo, d, h, mi, whole), "ns") + np.timedelta64(
        int(round(frac * 1e9)), "ns"
    )


def scan_obs(path):
    epochs = []
    sats = set()
    nlines = 0
    with open(path, "r", errors="replace") as f:
        for line in f:
            nlines += 1
            if line.startswith(">"):
                t = parse_epoch(line)
                if t is not None:
                    epochs.append(t)
            elif len(line) >= 3 and line[0] in "GRECJS" and line[1:3].isdigit():
                sats.add(line[:3])
    return np.array(epochs, dtype="datetime64[ns]"), sats, nlines


def scan_nav(path):
    header = []
    n_epoch = 0
    nlines = 0
    with open(path, "r", errors="replace") as f:
        in_header = True
        for line in f:
            nlines += 1
            if in_header:
                header.append(line.rstrip())
                if "END OF HEADER" in line:
                    in_header = False
                continue
            if line.startswith(">"):
                n_epoch += 1
    return header, n_epoch, nlines


def main():
    lines = []

    def out(s=""):
        print(s)
        lines.append(s)

    out("=== Phase 0 data audit (campus-01, 607 s window) ===")
    out("")
    out("--- base 1 Hz RINEX ---")
    for label, path in (("base 02:00-02:15", BASE_0200), ("base 02:15-02:30", BASE_0215)):
        t, sats, nl = scan_obs(path)
        out(f"{label}: {len(t)} epochs, {t[0]} .. {t[-1]}, {len(sats)} sats, {nl} lines")
        out(f"  systems: {sorted(set(s[0] for s in sats))}")

    out("")
    out("--- rover 1 Hz RINEX ---")
    rt, rsats, rnl = scan_obs(ROVER)
    out(f"rover: {len(rt)} epochs, {rt[0]} .. {rt[-1]}, {len(rsats)} sats, {rnl} lines")
    out(f"  systems: {sorted(set(s[0] for s in rsats))}")
    for sysname in "GRECJS":
        ss = sorted(s for s in rsats if s.startswith(sysname))
        if ss:
            out(f"  {sysname}: {len(ss)} sats -> {ss}")

    # Combine base files, dropping the duplicate 02:15:00 boundary epoch.
    b0, _, _ = scan_obs(BASE_0200)
    b1, _, _ = scan_obs(BASE_0215)
    bt = np.unique(np.concatenate([b0, b1]))
    common = np.intersect1d(bt, rt)
    win = common[(common >= W0) & (common <= W1)]
    out("")
    out("--- epoch alignment ---")
    out(f"base unique epochs: {len(bt)}; rover epochs: {len(rt)}; common: {len(common)}")
    out(f"first common: {common[0] if len(common) else 'NONE'}")
    out(f"last common:  {common[-1] if len(common) else 'NONE'}")
    out(f"evaluation-window common epochs: {len(win)} (expected 607)")
    if len(win):
        out(f"window first/last (GPS): {win[0]} / {win[-1]}")
        out(f"window first/last (UTC): {win[0] - np.timedelta64(LEAP_SECONDS, 's')} / "
            f"{win[-1] - np.timedelta64(LEAP_SECONDS, 's')}")
        out(f"time base: RINEX = GPS; bag/reference = UTC; GPS-UTC = {LEAP_SECONDS} s")

    out("")
    out("--- broadcast ephemeris ---")
    header, n_epoch, nl = scan_nav(NAV)
    for h in header[:8]:
        out("  " + h)
    out(f"nav epoch records: {n_epoch}, lines: {nl}")
    out("  expected systems in header: GPS/GLO/GAL/BDS/QZS/SBAS/IRNSS")

    out("")
    out("--- reference and bag ---")
    tt = []
    for line in open(REF, "r", errors="replace"):
        q = line.split()
        if len(q) >= 4:
            try:
                tt.append(float(q[0]))
            except ValueError:
                pass
    tt = np.array(tt)
    out(f"reference: {len(tt)} poses, t0={tt[0]:.3f}, t1={tt[-1]:.3f}, span={tt[-1]-tt[0]:.3f} s")
    out(f"bag start: {BAG_START:.3f}; window end: {BAG_START + WINDOW:.3f}")
    out(f"reference start offset from bag: {tt[0] - BAG_START:+.3f} s")

    out("")
    out("--- fixed base coordinate (GREAT_RTK_campus01_fixbase.xml) ---")
    out("  WUHN/WUH2 ECEF: -2267749.9279  5009154.2407  3221290.6333")
    out("  RINEX header : -2267749.0000  5009154.0000  3221290.0000")
    out("  header-to-fixed difference: 0.928 / 0.241 / 0.633 m (use the fixed value)")
    out("")
    out("PHASE0_RESULT " + (
        "PASS" if len(win) == 607 and np.all(np.diff(win).astype("timedelta64[s]").astype(int) == 1)
        else "CHECK"
    ))

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")
    print("\nwrote " + OUT)


if __name__ == "__main__":
    main()
