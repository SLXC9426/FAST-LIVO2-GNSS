#!/usr/bin/env python3
"""R4.2b smoke check: optimized Pose3 graph vs the LIO input it consumed.

The frontend writes world-frame poses; the graph writes ENU poses. The last
[ONLINE GRAPH] line carries the fitted yaw/translation/scale, so the frontend
trajectory can be mapped into the same ENU frame before comparing.

usage: compare_pose3.py <frontend.txt> <graph.tum> <node.log>
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

import numpy as np


def load(path: Path):
    rows = []
    for line in path.open(errors="ignore"):
        p = line.split()
        if len(p) != 8:
            continue
        try:
            rows.append([float(v) for v in p])
        except ValueError:
            pass
    return np.asarray(rows)


def quat_to_R(q):
    x, y, z, w = q
    n = np.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def parse_frame(log_path: Path):
    m_yaw = re.compile(r"yaw=([-+0-9.]+)")
    m_tr = re.compile(r"tr=([-+0-9.]+),([-+0-9.]+),([-+0-9.]+)")
    m_scale = re.compile(r"scale=([-+0-9.]+)")
    got = None
    for line in log_path.open(errors="ignore"):
        if "[ONLINE GRAPH]" not in line:
            continue
        y = m_yaw.search(line)
        t = m_tr.search(line)
        s = m_scale.search(line)
        if y and t and s:
            got = (y, t, s)
    if got is None:
        return None
    y, t, s = got
    yaw = np.radians(float(y.group(1)))
    tr = np.array([float(t.group(1)), float(t.group(2)), float(t.group(3))])
    scale = float(s.group(1))
    c, sn = np.cos(yaw), np.sin(yaw)
    Rz = np.array([[c, -sn, 0.0], [sn, c, 0.0], [0.0, 0.0, 1.0]])
    return Rz, tr, scale


def main() -> int:
    if len(sys.argv) != 4:
        print("usage: compare_pose3.py <frontend.txt> <graph.tum> <node.log>")
        return 2
    front = load(Path(sys.argv[1]))
    graph = load(Path(sys.argv[2]))
    frame = parse_frame(Path(sys.argv[3]))
    if frame is None:
        print("could not parse yaw/tr/scale from the log")
        return 1
    Rz, tr, scale = frame
    if len(front) < 2 or len(graph) < 2:
        print(f"front={len(front)} graph={len(graph)} (not enough rows)")
        return 1
    tf = front[:, 0]
    dpos, dang = [], []
    for row in graph:
        i = int(np.argmin(np.abs(tf - row[0])))
        if abs(tf[i] - row[0]) > 0.05:
            continue
        p_front_enu = Rz @ (scale * front[i, 1:4]) + tr
        dpos.append(np.linalg.norm(row[1:4] - p_front_enu))
        # The graph TUM writes the orientation back in the LIO world frame
        # (Rz^T * T_enu), so it is directly comparable to the frontend.
        Rf = quat_to_R(front[i, 4:8])
        Rg = quat_to_R(row[4:8])
        c = np.clip((np.trace(Rg.T @ Rf) - 1.0) / 2.0, -1.0, 1.0)
        dang.append(np.degrees(np.arccos(c)))
    print(f"front={len(front)} graph={len(graph)} matched={len(dpos)}")
    print(f"  yaw={np.degrees(np.arctan2(Rz[1,0], Rz[0,0])):.3f} deg  scale={scale:.5f}")
    if dpos:
        print("  |dp|  median=%.4f p95=%.4f max=%.4f m" % (np.median(dpos), np.percentile(dpos, 95), max(dpos)))
        print("  |dang| median=%.4f p95=%.4f max=%.4f deg" % (np.median(dang), np.percentile(dang, 95), max(dang)))
    qn = np.linalg.norm(graph[:, 4:8], axis=1)
    print("  graph quat norm min/max = %.6f / %.6f" % (qn.min(), qn.max()))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
