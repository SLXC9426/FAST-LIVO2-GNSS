# FAST-LIVO2-GNSS

基于 [FAST-LIVO2](https://github.com/hku-mars/FAST-LIVO2)（T-RO '24）扩展的 **LiDAR-视觉-惯性 + RTK 多源融合定位建图系统**。在原 LIVO 误差状态估计框架中引入 RTK 绝对位置观测，实现室外开阔/城市环境下的全局一致轨迹：位置域观测更新、杆臂补偿、噪声自适应、卡方野值剔除，并进一步增加了 RTK 质量通道、时间关联、创新门控与 1 Hz 全局位姿图等改进。

> 上游代码遵循 GPLv2 发布（见 [LICENSE](LICENSE)）；本仓库的 GNSS/RTK 扩展部分沿用同一许可证。

## 1. 目录结构

```
FAST-LIVO2-GNSS/
├── src/                    # 核心源码（14 个 cpp：LIVMapper、IMU_Processing、gnss_processing、
│                           #   rtk_tight、factor_graph、global_pose_graph、static_anchor_validity 等）
├── include/                # 头文件（含 gnss_processing.h、gnss_quality.h、rtk_tight.h、
│                           #   gnss_alignment_state.h、fusion_supervisor.h 等 GNSS 扩展接口）
├── config/                 # ROS 参数配置（主数据集 + 实验变体，共 129 个 yaml）
├── launch/                 # ROS launch 文件（主入口 mapping_great.launch 等）
├── msg/                    # 自定义消息（GnssQuality、RtkDD、OnlineGraph* 等）
├── scripts/                # 评估与数据处理脚本（eval/、rtk/、dev/、配置生成器）
├── test/                   # C++ 单元/集成自测
├── docs/                   # 设计文档与实验证据
│   ├── *.md                #   设计与方法文档（IMPROVEMENT_*、RTK_TIGHT_TDCP、GV1_METHOD、
│   │                       #   ONLINE_GRAPH_DESIGN、PROJECT_SUMMARY 等）
│   ├── a*_evidence/        #   A0–A4 各阶段实验证据（trace/TUM/哈希/报告）
│   └── project/            #   ★ 本仓库新增：由项目全量资料重新提炼的核心要点文档
├── rviz_cfg/               # RViz 可视化配置
├── pics/                   # 架构图
├── GNSS_INTEGRATION_GUIDE.md   # RTK 集成指南（观测模型/雅可比/调参）
└── CMakeLists.txt / package.xml
```

## 2. 构建与运行

### 2.1 依赖

与上游 FAST-LIVO2 相同：Ubuntu 18.04–20.04、ROS1、PCL ≥ 1.8、Eigen ≥ 3.3.4、OpenCV ≥ 4.2、
[Sophus](https://github.com/strasdat/Sophus)（`a621ff`）、[rpg_vikit](https://github.com/xuankuzcr/rpg_vikit)。

### 2.2 编译

```bash
cd ~/catkin_ws/src
# 将本仓库放入 catkin 工作区
cd ..
catkin_make
source ~/catkin_ws/devel/setup.bash
```

### 2.3 运行

```bash
# LIVO + RTK 融合（campus 数据集示例）
roslaunch fast_livo mapping_great.launch
# 数据回放
rosbag play YOUR_DATA.bag
```

GNSS 观测默认通过 `/gnss/fix`（NavSatFix）订阅；启用/关闭 GNSS 及各改进模块见对应
yaml 的 `common/gnss_en` 与文档说明。配置入口推荐：
`great_campus0X_fusion.yaml`（观测级融合）、`great_campus0X_graph.yaml`（在线因子图）、
`avia_gnss.yaml`（最小 GNSS 示例）。

## 3. 核心机制速览

- **总体架构**：前端 19 维 ESIKF（LiDAR 点面残差 + 视觉光度残差交替迭代）+ 位置域 GNSS
  观测更新 + 后端独立进程 1 Hz 位置-only 全局位姿图（GTSAM：LIO 相对因子 + RTK 绝对因子 +
  静止锚点），图输出不回写滤波器（失败安全设计）。
- **观测模型**：RTK 提供 ENU 局部系绝对位置观测 `z = p_IMU + R·p_lever_arm + n`；ENU↔world
  用 2D Procrustes 鲁棒对齐（拟合残差 > 5 m 时整体关闭融合）。
- **噪声自适应**：按 fix 类型分档（FIX 1.2 m / Float 2.5 m / DGPS 3 m / Single 5 m）做门控，
  增益用 MAD 自适应 σ，两者分离；Joseph 形式协方差更新。
- **野值剔除**：卡方检验（阈值 7.815 / 12.592）。
- **改进链路**（详见 `docs/project/`）：A1 RTK 历元-关键帧时间关联插值；A2 质量通道
  （`GnssQuality.msg`）、分类门控（默认关闭）、独立 LIO 递推 χ² 创新门控（默认关闭）；
  A3 启动段静态锚基线；ZUPT + 输出层静止保持；P 系列遮挡剔除、动态点移除、四源监督等。
  另有默认关闭的双差观测级紧组合分支（`src/rtk_tight.cpp`，详见 `docs/project/04_RTK紧组合设计.md`）。

## 4. 文档索引

| 文档 | 内容 |
|---|---|
| [GNSS_INTEGRATION_GUIDE.md](GNSS_INTEGRATION_GUIDE.md) | RTK 集成：步骤、观测模型、坐标系、调参建议 |
| [docs/project/01_项目概述与方法架构.md](docs/project/01_项目概述与方法架构.md) | ★ 系统架构、方法理论核心要点 |
| [docs/project/02_精度评估与改进历程.md](docs/project/02_精度评估与改进历程.md) | ★ 各阶段改进内容与量化效果、数字口径说明 |
| [docs/project/03_RTK紧组合设计.md](docs/project/03_RTK紧组合设计.md) | ★ 双差观测级分支：模型、质量通道、门控与结论 |
| [docs/project/04_A0-A4优化与验收记录.md](docs/project/04_A0-A4优化与验收记录.md) | ★ A0–A4 各阶段目的/做法/结论/默认开关 |
| [docs/project/05_审查结论与遗留问题.md](docs/project/05_审查结论与遗留问题.md) | ★ 红队审查结论、当前状态与开放问题 |
| [docs/PROJECT_SUMMARY.md](docs/PROJECT_SUMMARY.md) | 项目阶段总结（源码内原始文档） |
| [docs/RTK_TIGHT_TDCP.md](docs/RTK_TIGHT_TDCP.md) | RTK 紧组合与 TDCP 设计 |
| [docs/IMPROVEMENT_1_OCCLUSION.md](docs/IMPROVEMENT_1_OCCLUSION.md) | 遮挡剔除改进 |
| [docs/IMPROVEMENT_2_FACTOR_GRAPH.md](docs/IMPROVEMENT_2_FACTOR_GRAPH.md) | 因子图改进 |
| [docs/IMPROVEMENT_3_DYNAMIC_REMOVAL.md](docs/IMPROVEMENT_3_DYNAMIC_REMOVAL.md) | 动态点移除改进 |

## 5. 关键结果（更正后口径）

同输入后端重放，campus-01/02 数据集（完整脉络见 `docs/project/02_精度评估与改进历程.md`）：

| 数据 | 指标 | A0（最近邻） | A1（历元插值） |
|---|---|---:|---:|
| c01 | ATE RMSE (m) | 1.066 | **0.691** |
| c02 | ATE RMSE (m) | 1.127 | **0.867** |

相对原版 FAST-LIVO2：c01 二维 ATE 2.294 → 0.899 m（−60.8%）；c02 原版发散（~6.0×10⁴ m）
变为可用。A2 创新门控将保留侧最大 RTK 误差从 29.45/27.23 m 降至 3.10/3.20 m，
误拒绝为 0，ATE/RPE 中性，默认关闭待真实数据验证。

## 6. 说明

- 本仓库由项目完整工作快照提炼：保留全部源码、配置、launch、msg、脚本、测试与设计文档；
  省略了与主线重复的历史归档（`attic/`）、运行日志（`Log/`）、大体积附件
  （`Supplementary/`，约 19.6 MB PDF）与 `__pycache__` 缓存。
- 同一指标在不同批次/二进制下存在多套数字，引用时请以
  `docs/project/02_精度评估与改进历程.md` 的口径说明为准。
- 上游 FAST-LIVO2 论文：[arXiv:2408.14035](https://arxiv.org/pdf/2408.14035)；
  上游开发者：Chunran Zheng（[zhengcr@connect.hku.hk](mailto:zhengcr@connect.hku.hk)）。
