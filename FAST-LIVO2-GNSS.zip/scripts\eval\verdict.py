#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""N-sample verdict: median + spread per arm, difference vs chaos floor (T0-2).

Single-run full-length APE comparisons are not decidable on their own: the
run-to-run chaos band of the estimator is of the same order as the effects
being compared (EVAL_PROTOCOL §2/§13, and the 09-13 vs 09-25 steady sign flip).
This tool enforces the T0-2 protocol:

  * group registry rows by tag prefix (the repeated-run naming from
    floor_stats.py: <group>_r<N>, or any prefix you pass)
  * per group: n, median, min/max of the chosen metric(s), cfg_hash and n_full
    consistency checks (same config / no dropped frames)
  * floor = max spread within the groups (or --floor override, or the measured
    per-sequence constants documented in EVAL_PROTOCOL §T0)
  * verdict line: |median_A - median_B| vs floor, plus the N>=3 validity check
    (n<3 is INVALID per protocol §13.3: a 2-run range is a lower bound)

Works with any registry columns, including the T0-1 segment scopes (r2_mov,
r2_stat_gf, r2_stdyloc, r2_statloc). With a single group it just reports the
distribution (e.g. the T2-0 wander-census usage).

Usage:
  verdict.py [--registry PATH]... [--field F]... [--floor X] [--min-n N]
             GROUP_A [GROUP_B]

  GROUP_x are tag prefixes; pass one registry per --registry (default:
  ~/catkin_ws/src/fast_livo/Log/result/registry.csv). Exit code is 0 unless a
  comparison was requested and came out INVALID (n<min-n) -- so a batch driver
  can treat "not decidable" as a failure.
"""
import argparse
import csv
import os
import sys

DEFAULT_REGISTRY = os.path.expanduser(
    "~/catkin_ws/src/fast_livo/Log/result/registry.csv")


def median(xs):
    s = sorted(xs)
    n = len(s)
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def load_registries(paths):
    rows = []
    for p in paths:
        if not os.path.exists(p):
            sys.exit("registry not found: %s" % p)
        with open(p, newline="", encoding="utf-8", errors="replace") as fh:
            for r in csv.DictReader(fh):
                r["_registry"] = os.path.basename(p)
                rows.append(r)
    return rows


def num(row, key):
    v = (row.get(key) or "").strip()
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def group_stats(rows, prefix, fields):
    sel = [r for r in rows if (r.get("tag") or "").strip().startswith(prefix)]
    hashes = sorted({(r.get("cfg_hash") or "").strip() for r in sel})
    nfs = sorted({(r.get("n_full") or "").strip() for r in sel})
    # A config mismatch makes the group meaningless. A small n_full difference
    # (a couple of dropped frames, protocol 2a) is a warning, not a verdict
    # killer; a large one means the runs saw different input streams.
    nf_mismatch = False
    try:
        nf_vals = [int(float(x)) for x in nfs if x]
        if len(nf_vals) > 1:
            nf_mismatch = (max(nf_vals) - min(nf_vals)) > max(
                10, int(0.005 * max(nf_vals)))
    except (ValueError, TypeError):
        nf_mismatch = len(nfs) > 1
    out = dict(prefix=prefix, n=len(sel), hashes=hashes, nfs=nfs, sel=sel,
               hash_mismatch=len(hashes) > 1, nf_mismatch=nf_mismatch)
    for f in fields:
        vals = [num(r, f) for r in sel]
        vals = [v for v in vals if v is not None]
        out[f] = dict(vals=vals,
                      med=median(vals) if vals else None,
                      spread=(max(vals) - min(vals)) if len(vals) >= 2 else None)
    return out


def print_group(g, fields):
    print("group %-28s n=%d rows%s" % (g["prefix"], g["n"],
                                       "" if g["n"] else "  (NO ROWS)"))
    if g["hashes"]:
        flag = "   <-- MISMATCH: runs differ in configuration" if g["hash_mismatch"] else ""
        print("  cfg_hash: %s%s" % (", ".join(g["hashes"]), flag))
    if g["nfs"]:
        if g["nf_mismatch"]:
            flag = "   <-- MISMATCH: input streams differ (not a 2-frame drop)"
        elif len(g["nfs"]) > 1:
            flag = "   <-- warning: small frame drop (protocol 2a)"
        else:
            flag = ""
        print("  n_full  : %s%s" % (", ".join(g["nfs"]), flag))
    for f in fields:
        st = g[f]
        if not st["vals"]:
            print("  %-12s : no values" % f)
            continue
        detail = " ".join("%.4f" % v for v in st["vals"])
        line = "  %-12s : median %.4f | runs %s" % (f, st["med"], detail)
        if st["spread"] is not None:
            line += " | spread %.4f" % st["spread"]
        print(line)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("groups", nargs="+", help="tag prefixes (1 = stats only, 2 = verdict)")
    ap.add_argument("--registry", action="append", default=None)
    ap.add_argument("--field", action="append", default=None,
                    help="registry column to judge (default r2_full; repeatable)")
    ap.add_argument("--floor", type=float, default=None,
                    help="override the chaos floor (else max group spread)")
    ap.add_argument("--min-n", type=int, default=3)
    args = ap.parse_args()

    fields = args.field or ["r2_full"]
    rows = load_registries(args.registry or [DEFAULT_REGISTRY])
    groups = [group_stats(rows, p, fields) for p in args.groups]
    for g in groups:
        print_group(g, fields)

    rc = 0
    if len(groups) < 2:
        print("\n(single group: distribution only, no verdict)")
        return 0

    print("")
    a, b = groups
    mismatch = [g["prefix"] for g in groups
                if g["hash_mismatch"] or g["nf_mismatch"]]
    invalid = (a["n"] < args.min_n or b["n"] < args.min_n or bool(mismatch))
    if invalid:
        if mismatch:
            print("VALIDITY: INVALID (cfg_hash/n_full mismatch in group(s): %s)"
                  % ", ".join(mismatch))
            print("  the rows do not belong to one configuration/input stream; "
                  "medians above are diagnostic only")
        else:
            print("VALIDITY: INVALID (n_A=%d n_B=%d < min-n=%d; protocol T0-2 / §13.3: "
                  "a 2-run range is a floor LOWER BOUND, not a floor)" %
                  (a["n"], b["n"], args.min_n))
        rc = 1
    else:
        print("VALIDITY: ok (n_A=%d n_B=%d >= %d)" % (a["n"], b["n"], args.min_n))

    for f in fields:
        ma, mb = a[f]["med"], b[f]["med"]
        if ma is None or mb is None:
            print("VERDICT[%s]: missing values in at least one group" % f)
            continue
        spreads = [g[f]["spread"] for g in groups if g[f]["spread"] is not None]
        floor = args.floor if args.floor is not None else (max(spreads) if spreads else None)
        if floor is None:
            print("VERDICT[%s]: no floor available (need >=2 runs per group or --floor)" % f)
            continue
        d = abs(ma - mb)
        src = "override" if args.floor is not None else "max group spread"
        verdict = "REAL (exceeds floor)" if d > floor else "NOT RESOLVABLE (within floor)"
        print("VERDICT[%s]: %s %.4f vs %s %.4f | |d_med|=%.4f vs floor %.4f (%s) -> %s"
              % (f, a["prefix"], ma, b["prefix"], mb, d, floor, src, verdict))
        if invalid:
            print("           (numbers above are informational only: validity check failed)")
    return rc


if __name__ == "__main__":
    sys.exit(main())
