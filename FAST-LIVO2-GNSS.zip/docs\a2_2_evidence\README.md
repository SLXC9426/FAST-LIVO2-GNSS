# A2.2：在线/离线统一的质量分类

分支：`fix/a2-quality-channel`（A2.1 之后）
目标：在线 ublox 与离线 RTKLIB 归一化到同一输入结构，走同一个分类器；
A2.2 **只输出分类、原因和统计**，不改变因子构建、sigma 或门控结果。

## 1. 输入归一化

```
ublox:  GnssPVTSolnMsg → GnssQuality → Fix
                         carr_soln / fix_type / num_sv / p_dop
RTKLIB: quality.csv   → feed adapter
                         status→carr_soln（Fixed=2, Float=1, 其它=0）
                         nsat / pdop / sigma0
                    ↓
             GnssQualityInput（source 只用于 trace）
                    ↓
             classifyGnssQuality()
```

两者都不把 `h_acc/v_acc` 当作 sigma；RTKLIB 表没有这两个字段，保持
`has_h_acc/has_v_acc=false`。

## 2. 分类规则

`include/gnss_quality.h`：

| 条件 | 类别 | reason |
|---|---|---|
| 没有质量记录 | `UNKNOWN` | `no_quality_record` |
| `valid=false` | `INVALID` | `invalid_flag` |
| `fix_type<=0` | `INVALID` | `no_fix` |
| `fix_type < min_fix_type(2)` | `INVALID` | `fix_type` |
| 已知 `num_sv < 8` 或已知 `p_dop > 5` | `DEGRADED` | `few_sats` / `pdop_high` |
| 载波 fixed 且在 good 界内（nsat≥12, pdop≤3） | `GOOD` | 空 |
| 载波 fixed，几何一般 | `FIXED` | 空 |
| 载波 float | `FLOAT` | 空 |
| 无载波（SPP/DGPS） | `DEGRADED` | `no_carrier` |

要点：

- **未知字段不参与判断**：`has_p_dop=false` 时 0 不会触发 `pdop_high`；
  `num_sv=0` 视为未知，不触发 `few_sats`；
- 边界包含：`num_sv==8`、`p_dop==5` 通过；
- `DEGRADED` 仍然 `usable=true`，A2.3 的 B2 才决定是否拒绝；
- 阈值（8/5、12/3）是**观察用首轮值**，不是已标定门限。

## 3. trace

关联 CSV 追加 `q_class`、`q_reason`；此前的 `q_source/q_valid/nsat/pdop/...`
保留，因此每个历元可以同时看到原始字段与分类结果。

## 4. 测试

`gnss_quality_classifier_selftest`（新增，20 项）：

- 空缺、无效、无解、DR、2D/3D 边界；
- GOOD/FIXED/FLOAT/DEGRADED 阶梯；
- 卫星数/PDOP 只在已知时生效，未知值不误杀；
- 边界值包含；
- RTKLIB status→carr_soln 映射与有效性；
- 在线/离线同一归一化输入得到同一分类。

## 5. B1 实验（只记录，不门控）

B0 = A1 基线（无质量表）；B1 = A1 + 质量表 + 分类 trace，门控关闭。

验收：**B1 的 TUM 必须与 A1 逐文件相同**（分类不参与因子）。

| 数据 | A1 TUM | B1 TUM | 结果 |
|---|---|---|---|
| c01 | `07dbf599…` | `07dbf599…` | **逐文件相同** |
| c02 | `8055e1a9…` | `8055e1a9…` | **逐文件相同** |

分类分布（B1 trace，含静态/边界历元）：

| 数据 | 行数 | GOOD | FIXED | FLOAT | DEGRADED | INVALID | UNKNOWN |
|---|---:|---:|---:|---:|---:|---:|---:|
| c01 | 604 | 221 | 114 | 94 | 130 | 0 | 45 |
| c02 | 802 | 458 | 173 | 20 | 78 | 0 | 73 |

DEGRADED 的原因：c01 `pdop_high` 71 / `few_sats` 59；c02 18 / 60。
UNKNOWN 全部是 RTKLIB 质量表没有对应历元（c01 45、c02 73），不是分类失败。

**不要用这张表里的“因子率”解释质量**：A2.2 的 `factor` 列同时受静态段
跳过和关联规则影响（例如 c01 的 GOOD 因子率 0.326 主要因为其中很多历元
落在静态段），与质量本身无关。按分类的误差分析留到 A2.3 的 B2。

## 6. 明确未改

- 因子构建、RTK sigma、Cauchy、静态规则、A1 时间关联；
- `fix_quality_ok`（仍只读 status/sigma）；
- `addFix` 跳变门限；
- `h_acc/v_acc` 仍未映射到 sigma。

## 7. 限制

- 分类阈值是首轮观察值，A2.3 依据实际分布与误拒绝率再定；
- 同输入 harness 不经过 LIVMapper，在线通道的分类只由单测和消息字段覆盖；
- 尚未按分类统计绝对误差（A2.3 的 B2 工作）。
