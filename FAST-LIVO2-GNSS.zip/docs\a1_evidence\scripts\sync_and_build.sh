#!/bin/bash
# Mirror the canonical Windows git tree into the WSL catkin workspace, then
# build fast_livo. The WSL copy is a plain copy (not a symlink), so it must be
# refreshed after every source edit.
#
#   wsl -d Ubuntu-20.04 -- bash /mnt/c/Users/.../06_exec/optimization/sync_and_build.sh
set -eo pipefail  # ROS setup.bash reads unset vars; do not use -u
export LANG=C.UTF-8

SRC="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main"
DST="$HOME/catkin_ws/src/fast_livo"

if [ ! -d "$SRC" ]; then
  echo "source tree not found: $SRC" >&2
  exit 1
fi

for d in src include test launch msg config scripts; do
  if [ -d "$SRC/$d" ]; then
    rsync -a --delete "$SRC/$d/" "$DST/$d/"
  fi
done
for f in CMakeLists.txt package.xml; do
  cp -a "$SRC/$f" "$DST/$f"
done

source /opt/ros/noetic/setup.bash
cd "$HOME/catkin_ws"
catkin_make --pkg fast_livo -j4 "$@"
