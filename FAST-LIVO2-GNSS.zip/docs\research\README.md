# docs/research/ — 研发规范与任务档案

> 自 2026-11-07 起，本目录是《FAST-LIVO2 项目执行总纲 V1.0》的落地位置，所有代码修改、算法实验、结果审查和阶段验收以它为统一依据。

## 文件索引

| 文件 | 内容 |
|---|---|
| [00_PROJECT_CHARTER.md](00_PROJECT_CHARTER.md) | 执行总纲 V1.0：三层目标、七条原则、P0–P5、G0–G4 验收门、SOP、停止规则 |
| [TEMPLATE_TASK_SHEET.md](TEMPLATE_TASK_SHEET.md) | 标准研发任务单模板（任何新开发工作先填写） |
| [08_DECISION_LOG.md](08_DECISION_LOG.md) | 研究决策日志（含旧结论效力裁决 D-004、P0 收口与 P2 放行 D-006） |
| tasks/P0/ | P0 阶段六项交付物（P0-01 至 P0-06） |
| tasks/P1/P1_系统误差根因报告_V1.md | 六问直答 + 根因排序 RC-1..RC-6 + 口径警示 |
| tasks/P2/P2实验预登记_2026-11-07.md | EXP-P2-001/002/003 预登记草案与全局护栏 |

## 与旧文档的关系（避免两套验收标准）

- `docs/EVAL_PROTOCOL.md`：**继续有效**（口径、噪声地板），并入新评价协议。
- `docs/EXPERIMENT_TEMPLATE.md`、`docs/WORKFLOW_ROLLBACK.md` 等：被总纲 §5.2/§九 取代处按总纲执行，其余继续有效。
- A0–A4、R 系列、红队审查等历史文档：保留为证据，引用前查 `tasks/P0/P0-05_历史实验索引.md` 的状态列。

## 当前状态速览

- 阶段：**P0 收口 → P2 预登记完成，待 G1 启动实施**，基线身份 `baseline/p0-seal-20261107` @ `e54430d`。
- 根因排序与放行：《系统误差根因报告 V1》已发布（RC-1 航向锁定 / RC-2 过渡段约束 / RC-3 前端积压 / RC-4 长括距 / RC-5 启动常值偏置待验证 / RC-6 垂直通道待查）。
- 绝对 ENU 指标：NOT_VERIFIED（不可评估）。
- campus-03：留出集，观测已解算，融合未跑，算法冻结前禁止使用。
