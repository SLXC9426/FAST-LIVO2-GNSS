#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Verify a GREAT-PVT .flt solution that was produced with doppler enabled.

R3 stage 4 / item 6.1. The checklist asks to "confirm the Vx/Vy/Vz columns are
non-zero", but that alone does not say whether the velocities are any good, and
the stage's later design decisions depend on their quality. This tool therefore
reports three things:

1. how many epochs carry a non-zero ECEF velocity (and the formal V-RMS), against
   the same file produced with doppler off;
2. the velocity cross-checked against an INDEPENDENT estimate - the central
   difference of the positions - which is what makes the numbers evidence rather
   than a restatement of the file's own claim. A forward difference is NOT used:
   over 1 s a vehicle's own acceleration and curvature contribute ~0.25 m/s of
   apparent disagreement, which would be mistaken for a velocity error;
3. a split by fix status and by speed, because for a stationary vehicle both
   sides are ~0 (a vacuous comparison) and because GREAT-PVT's Float epochs are
   measurably much worse than its Fixed ones - which is what decides whether the
   formal velocity sigma can be trusted.

.flt columns: 0 TOW | 1-3 X Y Z | 4-6 Vx Vy Vz | 7-9 XYZ-RMS | 10-12 V-RMS |
              13 NSat | 14 PDOP | 15 sigma0 | 16 AmbStatus | 17 Ratio | 18 BL | 19 Quality

Usage:
  verify_flt_doppler.py <with_doppler.flt> [<without_doppler.flt>]
                        [--window TOW_START TOW_LEN]
"""
import math
import os
import sys


def load(path, window=None):
    out = []
    for line in open(path, errors='ignore'):
        if line.startswith('#') or not line.strip():
            continue
        r = line.split()
        if len(r) < 17:
            continue
        tow = float(r[0])
        if window and not (window[0] <= tow <= window[0] + window[1]):
            continue
        out.append(dict(tow=tow, p=(float(r[1]), float(r[2]), float(r[3])),
                        v=(float(r[4]), float(r[5]), float(r[6])),
                        rms=max(float(r[7]), float(r[8]), float(r[9])),
                        vrms=max(float(r[10]), float(r[11]), float(r[12])),
                        nsat=int(r[13]), pdop=float(r[14]), amb=r[16]))
    return out


def report(name, rows):
    nz = [r for r in rows if math.sqrt(sum(c * c for c in r['v'])) > 1e-6]
    sp = [math.sqrt(sum(c * c for c in r['v'])) for r in nz]
    print('%-34s epochs=%-5d nonzero_vel=%-5d' % (name, len(rows), len(nz)), end='')
    if sp:
        print('  |V| mean=%.3f max=%.3f  V-RMS max=%.3f m/s'
              % (sum(sp) / len(sp), max(sp), max(r['vrms'] for r in rows)))
    else:
        print()


def quality(rows, prefix='   '):
    res = []
    for i in range(1, len(rows) - 1):
        a, b, c = rows[i - 1], rows[i], rows[i + 1]
        if abs(b['tow'] - a['tow'] - 1.0) > 1e-6 or abs(c['tow'] - b['tow'] - 1.0) > 1e-6:
            continue
        vp = tuple((c['p'][k] - a['p'][k]) / 2.0 for k in range(3))   # central difference
        res.append((math.dist(vp, b['v']), math.sqrt(sum(c2 * c2 for c2 in vp)), b))
    if not res:
        print(prefix + '(no comparable 1 Hz triples)')
        return
    print('%scomparable 1 Hz triples: %d' % (prefix, len(res)))
    groups = (('slow  (|V|<=1 m/s)', [r for r in res if r[1] <= 1.0]),
              ('moving+Fixed       ', [r for r in res if r[1] > 1.0 and r[2]['amb'].lower().startswith('fix')]),
              ('moving+Float       ', [r for r in res if r[1] > 1.0 and not r[2]['amb'].lower().startswith('fix')]))
    for label, sel in groups:
        if not sel:
            continue
        e = sorted(x[0] for x in sel)
        print('%s  %s n=%-4d |dV| p50=%.4f p90=%.4f p95=%.4f max=%.4f m/s'
              % (prefix, label, len(e), e[len(e) // 2], e[int(len(e) * 0.9)],
                 e[int(len(e) * 0.95)], e[-1]))
    vr = sorted(r[2]['vrms'] for r in res)
    print('%s  formal V-RMS over those epochs: p50=%.3f max=%.3f m/s'
          % (prefix, vr[len(vr) // 2], vr[-1]))
    print('%s  ^ compare the two lines: a formal sigma far below the measured |dV|'
          % prefix)
    print('%s    means the reported velocity precision must not be trusted as sigma.'
          % prefix)


def main():
    a = sys.argv[1:]
    if len(a) < 1:
        print(__doc__)
        return 1
    window = None
    if '--window' in a:
        i = a.index('--window')
        window = (float(a[i + 1]), float(a[i + 2]))
        a = a[:i]
    print('=== doppler columns populated? ===')
    rows_dop = load(a[0], window)
    report(os.path.basename(a[0]) + ' (doppler on)', rows_dop)
    if len(a) > 1:
        report(os.path.basename(a[1]) + ' (doppler off)', load(a[1], window))
    if window:
        print('(restricted to TOW %g..%g)' % (window[0], window[0] + window[1]))
    print()
    print('=== velocity quality vs the position derivative (central difference) ===')
    quality(rows_dop)
    return 0


if __name__ == '__main__':
    sys.exit(main())
