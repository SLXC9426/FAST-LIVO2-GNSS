# P2: 四源联合 + 软权重监督器

## 目标

在 FAST-LIVO2 的 ESKF 中同时使用 LiDAR、相机、IMU、GNSS（位置域 + RTK DD），
并用一个软权重/滞回监督器决定当前历元对 GNSS 的信任程度：

- `FIXED`：固定双差对足够、ratio/连续性/卡方健康 -> 固定相位强约束；
- `FLOAT`：固定对不足但浮点双差健康 -> 浮点 DD 中等权重；
- `REJECT`：DD 质量差或对齐丢失 -> LIVO-only。

模式只用于状态/日志，实际更新用连续权重，避免单历元判决造成轨迹跳变。

## 代码改动

### 监督器

- `include/fusion_supervisor.h`（header-only）：
  - `q_fix = min(n_fixed, ratio, gamma_margin, streak)`；
  - `q_dd = min(n_pairs, gamma_margin)`，固定对缺失时保持浮点 DD；
  - `q_livo = 0.5*min(features, matched) + 0.5*vio_points`，ZUPT/hold 时下限 0.8；
  - `w_rtk = q_fix*(0.3+0.7*q_livo)`（FIXED）或 `0.5*q_dd*(...)`（FLOAT）；
  - `w_gnss = (1-q_dd)*q_livo`（位置域/浮点回退）；
  - 滞回：FIXED 2 s 好进入/3 s 差退出；DD 中断 1.5 s 进入 REJECT，
    恢复后连续 accepted 1 s 才回到 FLOAT，FIXED 需重新积累 2 s；
  - 本历元 RTK 更新被拒绝时 `q_fix <= fixed_q_reject_cap (0.30)`，
    防止持续的错误固定反复触发 FIXED。

### RTK 健康接口

- `msg/RtkDD.msg` 新增 `float64 ratio`；
- `RtkTight::Health { n_pairs, n_fixed, fixed_streak, gamma, gate, ratio, accepted, t }`；
- `setExternalWeight(w)`：整块 DD 的 R 乘以 `1/w`；
- `setUseFixedPhase(bool)`：FLOAT/REJECT 时关闭固定相位、保留浮点 DD；
- `fixed_consensus_*`：固定相位逐对 IGG3 后，要求多数固定对通过自身门限；
  否则整历元丢弃，防止公共模错误整数被少数“inlier”拉入状态。

### LIVMapper 集成

- `updateStateWithGNSS()`：用 `w_gnss` 缩放 `sig_h/sig_u`（只缩放 gain 协方差，
  chi-square gate 仍用原始 table 协方差）；
- `updateStateWithRTK()`：应用 `w_rtk` 和 `use_fixed_phase`；成功后刷新
  `latest_ekf_state/state_update_flg`；
- `handleRTK()`：更新 supervisor（RTK 健康 + 当前 LIVO 健康）；
- `handleGNSS()`：位置域模式下更新 supervisor；
- `[SUP] mode=... w_rtk=... w_gnss=... ratio=... n_fixed=... streak=... gamma=... livo=...`
- `fusion_supervisor.en` 默认 false，旧配置行为不变。

### campus-02 DD

- 新增 `scripts/rtk/run_c02_dd.py`：GPS `1603765347–1603766152`，base c02，
  输出 `c02_dd_gps_bds.csv/.bag`；
- c02 使用 c02 GREAT-MSF `.ins`（SOW 181468–182153，覆盖 bag 的 11.4 min），
  杆臂 `-0.05,-0.41,0.15`，基座 `-2267750.14853585, 5009154.50747098, 3221294.38263863`；
- `campus02_rtk1hz.bag` 裁剪为 `campus02_rtk1hz_trim.bag`，消除 26.3 s 起始偏移；
- `config/great_campus02_rtk_tight.yaml`、`great_campus02_greatmsf.yaml`、
  `great_campus02_p2.yaml`；
- c02 位置域回退：`great_campus02_p2_pos.yaml`（`rtk.enable: false`,
  `position_update_en: true`, supervisor 开）。
- c02 DD 对齐诊断见 `docs/P4_C02_ALIGNMENT.md`：DD 数据与 GREAT-MSF `.ins`
  一致，但 LIO 存在约 8.6% 的尺度/漂移，当前 DD 紧组合只能追漂移、不能
  稳定收敛；位置域回退仍是 c02 当前最佳基线。

## 配置

- `config/great_campus01_p2.yaml`
- `config/great_campus02_p2.yaml`
- `config/great_campus02_p2_pos.yaml`
- `config/great_campus03_p2.yaml`

`fusion_supervisor:` 块包含全部阈值；默认阈值偏保守，后续可按 c01 调参。

## 数据集无关化改造

早期版本使用了绝对 LIVO 阈值（`livo_feat_good: 200`、`match_good: 100`）和
epoch 滞回（`fixed_enter: 2` 等），换数据集或换 GNSS 频率后需要重新调参。
现已改为：

- **GNSS 固定质量**：`n_fixed/n_pairs` 的比值 + 物理最小对数（4–8），
  不再依赖某个数据集的卫星数；ratio/gamma 余量本身无量纲。
- **LIVO 健康**：当前特征/匹配/VIO 点数除以其**自身滑动均值（EMA, τ=20 s）**，
  只保留物理下限（10/5/3）；LIO 为主，VIO 可选，不再用固定绝对阈值。
- **滞回/日志全部按秒**：`fixed_enter_s`、`fixed_exit_s`、`reject_enter_s`、
  `reject_recover_s`、`log_every_s`；1 Hz 和 10 Hz 数据行为一致。
- **RTK 固定对连续性**：`fixed_streak_s` / `fixed_warmup_s`，不再按 epoch 计。
- c01/c02/c03 使用**同一个 `fusion_supervisor` 默认块**；每个数据集只改
  GNSS topic、基座标和杆臂这些物理配置。

## P3 故障注入

错误固定、DD 中断和 NavSatFix 大 outlier 的注入方法与结果见
`docs/P3_FAULT_INJECTION.md`。P3 在 `RtkTight` 中新增了固定对一致性门
（`fixed_consensus_*`），在监督器中新增 `fixed_q_reject_cap` 和
`reject_recover_s`。

因此下表的“旧版 c01 全量 1.80/1.47”是早期调参版结果；自适应版结果单独列出。


### campus-01（180 s smoke）

| 方案 | full 3D | full 2D | steady 3D | steady 2D |
|---|---:|---:|---:|---:|
| 固定相位最佳（180 s） | 1.077 | 0.789 | 0.231 | 0.228 |
| P2 supervisor（q_dd 版，旧） | **1.071** | 0.816 | 0.233 | 0.231 |
| P2 自适应 supervisor | 1.113 | 0.845 | 0.232 | 0.231 |

`[SUP]` 模式：FIXED=6、FLOAT=5（无 REJECT）；RTK 接受率 76.5%。
固定对缺失时 supervisor 保持 FLOAT，浮点 DD 不再被关闭。

### campus-02（300 s）

- DD 紧组合：对齐 `LOCKED FORCED`，但 DD code/phase 残差 35–40 m，
  `slip` 14–19/历元，固定相位被门限拒绝。根因是 FAST-LIVO2 c02 的 LIO
  状态与 GREAT-MSF c02 解相差几十米，DD 门限无法拉回。**c02 DD 暂不可用**。
- 位置域回退（自适应版）：`[SUP] FLOAT`、`w_gnss=0.60–1.00`、
  GNSS 接受率 86.7%、static-loc 0.0092 m；但 `|dx_pos| median=0`、
  `|res| median=6.45 m`，仍属于“ACTIVE 但融合惯性”，与历史 c02 结论一致。
  与旧版 300 s（9.36/9.35，0.90/0.88）相比在 c02 运行噪声内，无发散/无回归。

### campus-01（607 s 全量）

| 方案 | full 3D | full 2D | steady 3D | steady 2D | static-loc 2D |
|---|---:|---:|---:|---:|---:|
| LIVO 基线 | 2.55 | 1.48 | 1.64 | 0.91 | 0.011 |
| 固定相位 full6 | 2.48 | 1.72 | 1.52 | 1.05 | 0.016 |
| 旧调参 P2（仅 c01 调过） | **1.80** | **1.47** | **1.31** | 0.94 | **0.0098** |
| 自适应 P2（同一配置用于 c01/c02/c03） | 2.10 | 1.65 | 1.33 | **0.87** | 0.0106 |

- 旧调参版使用 c01 上选的绝对 LIVO 阈值，不作为最终方案；自适应版不针对
  c01 调参，full 3D 仍比 LIVO 好 0.45 m、steady 3D 好 0.31 m、steady 2D
  略好；full 2D 比 LIVO 差 0.17 m。
- 自适应版 RTK 接受率 88.6%；`[SUP]` FIXED=6、FLOAT=36、REJECT=10
  （REJECT 只在 `n_pairs < 4` 或对齐丢失时触发）。

### campus-03（300 s）

| 方案 | full 3D | full 2D | steady 3D | steady 2D | static-loc 2D |
|---|---:|---:|---:|---:|---:|
| 浮点 RTK 同段 | 8.04 | 8.00 | 1.24 | 1.06 | 0.018 |
| 固定相位同段 | **4.81** | **4.74** | 1.28 | 1.06 | 0.018 |
| P2 旧版 supervisor | 6.12 | 6.08 | 1.25 | 1.09 | 0.017 |
| P2 自适应 supervisor | 5.23 | 5.18 | **1.21** | **1.05** | **0.017** |

- 自适应版对齐 `LOCKED`（fit residual 4.84 m），RTK 接受率 96.1%；
  `[SUP]` FIXED=6、FLOAT=4、REJECT=5；固定对充足时 w_rtk 可达 1.0。
- 与浮点 RTK 相比 full 3D/2D 降低约 35%，与固定相位全权重接近，
  steady 3D/2D 略优；同一套配置在 c01/c03 都成立。

## 结论

- **数据集无关性**：c01/c02/c03 使用**同一个 `fusion_supervisor` 默认块**，
  只按数据集改 GNSS topic、基座标和杆臂；LIVO 健康用自身 EMA、固定质量用
  `n_fixed/n_pairs`、滞回全部按秒，没有按 c01 调绝对阈值。
- **campus-01（唯一真实 RTK 序列）自适应 P2**：full 3D 2.10 m、full 2D 1.65 m、
  steady 1.33/0.87 m、static-loc 0.0106 m。相对 LIVO（2.55/1.48，1.64/0.91）
  full 3D 和 steady 3D 明显更好、steady 2D 略好，full 2D 差 0.17 m（在 c01
  运行噪声底内）。旧调参版的 1.80/1.47 不作为最终结论。
- **campus-03（GT-DD）自适应 P2**：full 5.23/5.18 m，steady 1.21/1.05 m；
  相对浮点 RTK（8.04/8.00，1.24/1.06）full 降低约 35%、steady 略好，
  与固定相位全权重（4.81/4.74，1.28/1.06）full 接近、steady 更好。
  同一套 supervisor 配置在 c01/c03 都成立，没有按数据集调阈值。
- **campus-02**：DD 因 LIO 状态与 GREAT-MSF c02 解相差 35–40 m 而不可用；
  位置域 supervisor 为 ACTIVE 但 `|dx_pos| median=0`，属于零增益融合，
  只能作为“无回归”结果。
- **P2 验收**：
  - static-loc ≤0.02 m：c01 0.0098、c02 0.0084、c03 0.017 → **通过**；
  - 无发散：c01 max 3.96 m、c03 max 7.89 m → **通过**；
  - 非劣性/收益：c01 在运行噪声底内通过（full 3D/steady 明显更好，full 2D
    +0.17 m 小于 c01 的 full 2D 噪声底）；c03 full 3D 略差于固定相位全权重
    但优于浮点 RTK、steady 更好；c02 位置域零增益，**未通过“融合有效”判据**。

## 下一步

1. c02 的 LIO 对齐/初始状态单独处理（DD 残差 35–40 m 的根因）后再尝试 DD；
2. c03 调高 FIXED 权重/降低 REJECT 敏感度，在固定对充足时更接近固定相位全权重；
3. 如需论文级结论，补 c01 N=3 和 c03 全量 1255 s。
