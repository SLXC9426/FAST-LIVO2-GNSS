# 改进 2：滑动窗口因子图后端（前端 ESKF 不变）

## 动机

原系统是单状态 19 维误差状态 iEKF（`IMU_Processing.cpp` 传播 +
`VoxelMapManager::StateEstimation` / `VIOManager::updateState` 更新）：
- 无历史信息：每一帧只做一次滤波更新，无法回溯修正；
- 协方差更新 `P = (I-G)P` 非 Joseph 形式，长期运行一致性受损；
- 遮挡/退化帧的误差无法被后续帧"拉回"。

## 架构（LIO-SAM 式：前端滤波 + 后端平滑）

```
IMU ──► 前端 ESKF/iEKF（实时，延迟不变）──► /aft_mapped_to_init
                │
                ├─ 关键帧（距离/转角/帧数阈值）──► 因子图后端（独立线程）
                │        └─ IMU 原始流（imu_cbk 推送）
                ▼
        滑动窗口（W 个关键帧位姿+速度）
        IMU 预积分因子 + LiDAR 里程计因子 + GNSS 位置因子
        Gauss-Newton（对角预处理 + 线搜索）
        Schur 补边缘化（最老关键帧）
                │
                ▼
        /LIVO2/smoothed_odom + Log/result/<seq>_graph.txt + 延迟 CSV
```

- 前端完全不改：实时输出与延迟不变；
- 后端独立 `std::thread`（`factor_graph.thread_en`），主循环经互斥队列推
  关键帧/IMU，结果经互斥槽位取回发布（跨线程安全）；
- 后端输出滞后约一个窗口（平滑的固有代价），这正是延迟对比的测量对象。

## 因子与数学（全部经有限差分数值验证）

### 状态与扰动约定

窗口状态：`[R_0, p_0, v_0, ..., R_{W-1}, p_{W-1}, v_{W-1}, b_g, b_a]`，共 `9W+6` 维。
右扰动：`R ← R·Exp(δφ)`，`p ← p + δp`，`v ← v + δv`。

### IMU 预积分（VINS 式中点积分）

对关键帧对 `(k, k+1)` 间 IMU 样本：

```
ΔR' = ΔR·Exp((ω̄ − b_g)·dt),   Δv' = Δv + ½(ΔR·a_0 + ΔR'·a_1)·dt,
Δp' = Δp + Δv·dt + ½·un_acc·dt²    （Δv 用旧值，与 VINS 一致）
```

偏置一阶 Jacobian（约定 `δΔR = ΔR·Exp(J_R_bg·δb)`，**注意 `un_acc_0` 通过
累积 ΔR 依赖 b_g**）：

```
J_R_bg' = Exp(−ω̄dt)·J_R_bg − J_r(ω̄dt)·dt
J_v_bg' = J_v_bg − ½·(ΔR[a0]×·J_R_bg + ΔR'[a1]×·J_R_bg')·dt
J_v_ba' = J_v_ba − ½(ΔR+ΔR')·dt
J_p_bg' = J_p_bg + J_v_bg·dt − ¼·bg_term·dt²
J_p_ba' = J_p_ba + J_v_ba·dt − ½·dR_avg·dt²
```

协方差传播（VINS 式 `Σ' = F·Σ·Fᵀ + Q_dt`，**速度噪声必须耦合进位置块**，
否则 `info_p` 虚高 6 个数量级导致数值病态；`Q` 用连续噪声密度
`σ²·dt` 离散化）。

残差（含偏置一阶修正 `dR_c = dR·Exp(J_R_bg·δb)` 等）：

```
e_R = Log(dR_cᵀ·R_kᵀ·R_{k+1})
e_v = R_kᵀ(v_{k+1} − v_k − g·Δt) − Δv_c
e_p = R_kᵀ(p_{k+1} − p_k − v_k·Δt − ½g·Δt²) − Δp_c
```

Jacobian（右扰动，`Jri = J_r⁻¹(e_R)`）：

```
∂e_R/∂φ_k = −Jri·R_{k+1}ᵀR_k        ∂e_R/∂φ_{k+1} = Jri
∂e_v/∂φ_k = [R_kᵀw_v]×              ∂e_v/∂v_k = −R_kᵀ   ∂e_v/∂v_{k+1} = R_kᵀ
∂e_p/∂φ_k = [R_kᵀw_p]×              ∂e_p/∂p_k = −R_kᵀ   ∂e_p/∂p_{k+1} = R_kᵀ
∂e_p/∂v_k = −R_kᵀ·Δt
∂e_R/∂b_g = −Jri·(R_{k+1}ᵀR_k·ΔR)·J_R_bg
∂e_v/∂b_g = −J_v_bg   ∂e_v/∂b_a = −J_v_ba
∂e_p/∂b_g = −J_p_bg   ∂e_p/∂b_a = −J_p_ba
```

### LiDAR 里程计因子

```
e_R = Log(R_relᵀR_kᵀR_{k+1}),  e_p = R_relᵀR_kᵀ(p_{k+1}−p_k) − p_rel
∂e_p/∂φ_k = R_relᵀ·[R_kᵀq]×
```

信息矩阵：`diag(1/σ_rot²·I₃, 1/σ_pos²·I₃)`。

### GNSS 位置因子（LIVO_GNSS 模式）

`e = p_k + R_k·lever − z`，`∂e/∂φ_k = −[R_k·lever]×`，`∂e/∂p_k = I`。
ENU→世界（Z-down）由 `enu_R_world` 转换，yaw 对齐完成前不附加。

### 数值求解（与仿真脚本逐行一致）

1. 先验锚定弱可观模式：节点 0 gauge `1e4·I₉`（σ≈1cm）、偏置 `1e3·I₆`、
   速度 `1e2·I₃`（锚前端速度，σ≈0.1m/s）——**没有这些，`b_g` 与 θ、
   v 与 θ 的不可区分模式使法方程近奇异，GN 步长爆炸**；
2. 对角预处理 `A_sc = D⁻¹AD⁻¹`（不改变最优解，改善条件数）；
3. Levenberg 阻尼 `λ = 1e-6·max(diag(A_sc))`；
4. **线搜索**：步长只在总代价（所有因子加权残差平方和）下降时接受，
   否则减半重试（最多 15 次）——**防止弱约束变量的大步长破坏线性化**；
5. 因子级 Huber 鲁棒核（`robust_en`，Mahalanobis 尺度 `robust_delta`）。

### Schur 补边缘化（`marginalize`）

窗口满时对最老节点做 Schur 补：

```
A_marg = A_rr − A_rb·A_bb⁻¹·A_br,   b_marg = b_r − A_rb·A_bb⁻¹·b_b
```

保留"新最老节点位姿+速度 + 偏置"的 15×15 边际块作为固定线性化点先验
（GTSAM 之外常见的轻量近似；`marginalize=false` 则直接丢弃）。

## 延迟/时间/精度分析

- **前端**：`handleLIO` 端到端延迟（`ros::Time::now() − 数据时间`）；
- **后端**：`last_opt_time`（优化耗时）、`last_queue_latency`（队列等待）、
  `last_output_latency`（输出滞后）——写入 `Log/result/<seq>_latency.csv`；
- **精度**：`eval_graph.py` 对比前端 vs 后端 vs GT 的 APE/RPE；
- **数值仿真**（`scripts/sim/sim_filter_compare.py`，Windows 可跑）：
  合成 IMU+LiDAR 序列（60 s 圆轨迹 + 爬升，odom 噪声 5 cm / 1e-2 rad，
  IMU 白噪声 σ_a=0.5、σ_g=0.02，bias 真值 5e-3/0.05）：

  | 指标 | ESKF 前端 | 因子图后端 |
  |---|---|---|
  | ATE RMSE（seed 0, 60 s） | 12.97 cm | **8.48 cm（−35%）** |
  | ATE max | 236 cm | **21 cm（−91%，无尖峰）** |
  | ATE RMSE（seed 1-3, 30 s） | 17.2–17.4 cm | **8.1–8.5 cm（−52%）** |
  | bias 估计误差（收敛后） | — | bg 1.3–3.0 mrad，ba 32–60 mm/s² |

  **窗口大小敏感性**（15 s 序列）：

  | window | ATE RMSE | 说明 |
  |---|---|---|
  | 10 | 10.67 cm | 8.00 cm（+Schur 边缘化） |
  | 25 | 8.17 cm | 默认 |
  | 50 | 8.24 cm | 饱和 |

  单关键帧耗时：ESKF ≈ 1.1 ms → 因子图 ≈ 0.15–1.1 s（Python 参考实现；
  C++ Eigen 版本预计低 1–2 个数量级，以实际运行统计为准）。后端输出滞后 =
  窗口 × 关键帧间隔（默认 25 × 0.1 s ≈ 2.5 s）。

### 实现要点（数值仿真验证过程中发现并修复的问题）

1. **GN 步符号**：`δ = −A⁻¹b`（`b = JᵀWr` 是上坡方向）——漏掉负号会使
   残差翻倍、任何线搜索都被拒绝；
2. **odom 因子测量索引**：窗口滑动后必须用"节点对应的全局关键帧索引"
   取测量（`win_k[]`），按窗口内索引取 `meas_R[i]` 会导致 kf≥窗口后完全错位、
   轨迹爆炸——C++ 端因相对位姿随节点保存而无此问题；
3. **预积分协方差下限**：bias 未完全估计时 0.1 s 预积分实际精度约
   σ_p≈5 cm、σ_v≈0.2 m/s、σ_θ≈1e-2 rad，远超白噪声理论值——不加下限时
   preint 信息矩阵主导 odom ~100 倍，平滑器退化；
4. **bias 先验分离**：b_g 紧（σ=0.01）、b_a 松（σ=0.1）——b_g 先验过松时
   弱可观测 bias 会吸收全部窗口误差（过拟合，b_g 被推到 0.1+ rad/s）。

## 参数

```yaml
factor_graph:
  en: true
  window_size: 25         # 窗口关键帧数（越大越平滑，延迟越高）
  kf_dist: 1.0            # 关键帧距离阈值（m）
  kf_rot_deg: 10.0        # 关键帧转角阈值（°）
  kf_min_frames: 10       # 强制关键帧帧数
  odom_rot_sigma: 0.01    # 里程计旋转噪声（rad）
  odom_pos_sigma: 0.05    # 里程计位置噪声（m）
  imu_gyr_sigma: 0.02     # 陀螺连续噪声密度（rad/s/√Hz）
  imu_acc_sigma: 0.5      # 加计连续噪声密度（m/s²/√Hz）
  imu_bg_sigma: 0.0001
  imu_ba_sigma: 0.0005
  marginalize: true       # Schur 边缘化
  gnss_en: true           # GNSS 位置因子（LIVO_GNSS）
  gnss_pos_sigma: 0.5
  robust_en: true         # 因子级 Huber
  robust_delta: 1.5
  thread_en: true         # 独立线程
  max_gn_iter: 8          # 内层 GN 迭代（×15 线搜索步）
```
