#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R4-5 one-shot patch: factor_graph latency clock (run once, then obsolete)."""
import io

p = "src/factor_graph.cpp"
s = io.open(p, encoding="utf-8").read()

subs = [
    ("""void FactorGraph::pushKeyframe(const GraphKeyframe &kf)
{
  std::lock_guard<std::mutex> lk(mtx_);
  kf_queue_.push_back(kf);
  cv_.notify_all();
}""",
     """void FactorGraph::pushKeyframe(const GraphKeyframe &kf)
{
  std::lock_guard<std::mutex> lk(mtx_);
  // R4-5: stamp the wall clock HERE, at enqueue. The queue/output latencies
  // used to be wallTime() - kf.stamp, i.e. wall clock minus the DATA
  // timestamp - a constant (negative for 2020-era bags), not a latency.
  kf_queue_.push_back(kf);
  kf_queue_.back().push_wt = wallTime();
  cv_.notify_all();
}"""),
    ("stats_.last_output_latency = wallTime() - window_.back().stamp;",
     "stats_.last_output_latency = wallTime() - window_.back().push_wt;"),
    ("const double queue_latency = wallTime() - kf.stamp;",
     "const double queue_latency = wallTime() - kf.push_wt;"),
    ("window_.push_back(Node{kf.stamp, kf.R, kf.p, kf.v, kf.gravity, kf.v});",
     "window_.push_back(Node{kf.stamp, kf.push_wt, kf.R, kf.p, kf.v, kf.gravity, kf.v});"),
]
for old, new in subs:
    n = s.count(old)
    if n == 0:
        print("MISS: %s..." % old[:60])
    s = s.replace(old, new)
    print("ok(%d): %s..." % (n, old[:50]))

io.open(p, "w", encoding="utf-8", newline="").write(s)
print("done")
