#!/bin/bash
# R6 P0-B N=3: pure-LIVO trajectories for the offline global-position-graph v1.
# The graph itself is offline (global_position_graph.py); this batch only
# produces 3 independent LIVO runs per dataset on the CURRENT binary.
#
#   bash run_gv1_livo.sh [outdir]
#
# Output tags: gv1_<seq>_livo_r1..r3 ; logs in <outdir>/livo_batch.log
export LANG=C.UTF-8
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
SEG=$REPO/scripts/eval/segment_run.sh
OUT=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/gv1}
mkdir -p "$OUT"
LOG=$OUT/livo_batch.log
: > "$LOG"
echo "=== GV1 LIVO N=3 | $(date +%F' '%T) ===" | tee -a "$LOG"
echo "libs $(md5sum "$HOME/catkin_ws/devel/lib/liblaser_mapping.so" | cut -c1-8)" | tee -a "$LOG"

run_seq () {
  local SEQ=$1 DUR=$2
  for k in 1 2 3; do
    echo "--- $SEQ r$k start $(date +%T) ---" | tee -a "$LOG"
    DRAIN_ITERS=80 bash "$SEG" "$SEQ" livo 0 "$DUR" \
      "gv1_${SEQ}_livo_r$k" "" "" "great_${SEQ}" >> "$LOG" 2>&1
    echo "--- $SEQ r$k done $(date +%T) ---" | tee -a "$LOG"
  done
}

run_seq campus01 607
run_seq campus02 806
echo "GV1_LIVO_DONE $(date +%T)" | tee -a "$LOG"
