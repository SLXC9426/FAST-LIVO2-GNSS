# P5 执行日志：第一轮改进尝试

## 目标

按 P5 计划先做“粗捕获 + RTK 信任”层，目标是把 c01 从 full 2.10 / steady 1.33
推向 1 m 级，并让 c02 的 DD 能收敛。结果：三个尝试都验证了边界，但**都未达到
净增益，已回退到 P2 基线**。本轮的主要产出是确认了下一个正确方向。

## 尝试 1：DD code 粗捕获

### 设计

- `rtk/coarse_acq_en`：首个 DD 更新前使用
  `coarse_acq_code_sigma=3 m`、`coarse_acq_prior_sigma=20 m`；
- 粗捕获期间绕过 `max_corr`，让一次更新能消掉米级 offset；
- 仅当对齐拟合残差 ≤1 m 时启用（c01 0.51 m 允许，c02 1.4 m 禁止）。

### 结果

c01（`p5_c01_dd_coarse2`）：

```
accept t=... |r_code|=2.00 |dx_pos|=0.680
accept t=... |r_code|=2.78 |dx_pos|=0.675
accept t=... |r_code|=3.11 |dx_pos|=0.718
...
accept t=... |r_code|=4.35 |dx_pos|=2.546
reject ... gamma=174.9 |r_phase|=2.39
...
|r_code|=8.5, |r_phase|=6.1
```

c02（`p5_c02_dd_coarse` / `..._rel`）：

```
accept ... |r_code|=54.06 |dx_pos|=55.055
next |r_code|=90.42
```

- c01 的 DD code 残差从 2 m 涨到 8 m，固定相位残差到 6 m；
- c02 在绝对 yaw 下直接拉 55 m，随后残差 90 m；
- 结论：**DD code 不能作为米级粗捕获的绝对锚**。code 的多路径/系统误差和
  yaw 误差会被大 gain 放大，`max_corr` 不是唯一原因。

### 处置

- `coarse_acq_en` 默认改为 **false**；
- 代码保留，仅作为未来“scale-aware acquisition”的基础；
- 对齐残差 guard（≤1 m）保留。

## 尝试 2：固定相位数据驱动 warm-up

### 设计

原来的 `fixed_warmup_s=30 s` 到点后强制切到 0.5 m tight gate；如果 30 s 时
状态还差 1–2 m，之后所有固定相位都会被拒绝。改为：

- 保持 loose gate（c01 配置 `fixed_phase_gate=5.0`），直到固定相位残差
  `phase_rms ≤0.5 m` 连续 5 s，再切 tight；
- 新增 `Health.phase_rms`、`fixed_settle_en/rms/s`。

### 结果

c01 `p5_c01_settle`：

- 固定相位确实被使用，`fixed=10–13`，`|r_phase|` 在 1–4 m 间振荡；
- 直到 `t=1603764717` 才满足 `phase_rms=0.38`（loose gate 用了约 5 s 的
  稳定窗口，但此前经历了约 80 s 的拉锯）；
- 没有形成“一次收敛”，而是每隔几个历元拉 1 m、再被拒绝。

结论：数据驱动 settle 本身可用，但在固定相位残差是**公共帧偏移**时，逐历元
拉 1 m 会振荡，不能替代一次性的帧平移估计。

### 处置

- `fixed_settle_en` 默认改为 **false**，恢复时间 warm-up；
- 诊断字段保留。

## 尝试 3：降低固定比例门限

### 设计

c01 的 DD 固定行比例 41.6%，c02 65.9%；原监督器 `fixed_ratio_good=0.60`
使 c01 很难进入 FIXED。把 `fixed_ratio_good` 降到 0.40，让 c01 的
`q_fix` 能过 `fixed_q_min=0.55`。

### 结果

c01 `p5_c01_ratio40`：

| 指标 | 基线 `p2_adapt2_c01_full` 0–300 s | ratio40 |
|---|---|---|
| full 3D | 1.5895 | 1.7078 |
| 2D | 1.3822 | 1.3904 |
| steady 3D | 0.8397（607 s 运行） | 0.8509 |

- FIXED 确实被激活（`FIXED=7`，`fixed=10–13`）；
- 但固定相位残差 1–4 m，更新在“拉 1 m → 下一历元拒绝”之间振荡；
- full 变差约 7.5%，没有净增益。

### 处置

- `fixed_ratio_good` 回退到 **0.60**；
- 正式配置恢复 P2 基线。

## 本轮结论

1. **DD code 不适合做粗捕获**：code 的系统误差和 yaw 误差会被大 gain 放大；
2. **固定相位逐历元拉 1 m 不适合消除公共帧偏移**：会振荡，且可能让 full 变差；
3. **c01 的固定比例 41.6% 不是主要问题**：即使 FIXED 激活，残差仍大；
4. 真正的下一步是**一次性估计固定相位的公共帧平移**，而不是继续调
   code sigma / ratio / max_corr。

## 下一步（P5.3 修正版）

四次尝试共同说明：**固定相位残差是时变的垂直/尺度漂移，不是常量帧平移。**
下一步不再做帧平移，而是做状态级修正：

1. 在 ESKF 中增加**垂直漂移状态**（或垂直速度尺度），用固定相位/DD 垂直
   残差估计；先验/限幅，避免与 LIO 垂直通道冲突；
2. 在 ESKF 中增加**水平尺度状态**（或 LIO 增量尺度），用 `align-rel` 的
   scale 和 DD 位移残差估计；c02 的 8.6% 尺度误差是主要目标；
3. 固定相位只做观测，不再承担“帧平移”的角色；
4. 验收：
   - c01 full ≤1.2 m、steady ≤0.8 m；
   - c02 DD 可用且 steady ≤0.6 m，或明确保留位置域回退；
   - P3 的 1 m 错误固定、DD 中断、+30 m outlier 全部回归通过。

在状态级修正完成前，正式链路保持 P2 基线；c02 继续使用位置域回退。

## 尝试 4：一次性固定相位帧平移（P5.3）

### 设计

在首次固定相位窗口内累计固定相位残差 `r` 和几何方向 `d`，解
`A δ = b`（`A=Σddᵀ`，`b=Σd r`），若残差能被一个平移解释
（拟合残差 ≤0.5 m），把 `δ` 从 ENU 转到 world 并修正 `enu_t_world`，
跳过该历元的状态更新。窗口 60 s、最少 8 对；P3 的后期错误固定不会进入
这个窗口。

### 结果

c01 `p5_c01_frameoff` 在 `t=1603764695` 得到：

```
[RTK] frame offset estimate dENU=(-1.09 0.76 -9.52) |d|=9.62 fit=0.01 m=11
[RTK] frame translation applied: dENU=(-1.09 0.76 -9.52) |d|=9.62 m
```

拟合残差只有 0.01 m，说明**该历元的 11 个固定相位残差几乎完美地由一个
9.5 m 的垂直平移解释**。但修正后下一历元的固定残差又回到 2–4 m：

```
reject t=... |r_phase|=2.83
reject t=... |r_phase|=2.80
accept t=... |r_phase|=2.10 |dx_pos|=1.000
```

结论：固定相位残差不是一个**稳定的常量平移**。c01 在某一历元可以把
9.5 m 垂直 offset 拟合到 0.01 m，但下一秒残差就恢复；这说明主导项是
LIO 的时变垂直/尺度漂移，而不是一个可以一次性扣掉的帧平移。直接应用
这次 9.5 m 垂直修正也会把轨迹整体抬高/压低，风险很大。

### 处置

- `frame_offset_en` 默认改为 **false**；
- 新增 `frame_offset_max_vertical=1.0 m` 保护：即使手动开启，9.5 m 垂直
  估计也会被拒绝（两个帧初始都是重力对齐的，垂直平移不应超过 1 m）；
- 代码保留作诊断/实验，不进入正式链路。

## 尝试 5：20 维垂直偏置 b_z（Stage A）

按 `P5.4_STATE_DESIGN.md` 把 `DIM_STATE` 扩到 20，加入 `b_z`，同步
IMU 协方差、GNSS/RTK H、输出 `truePos()` 和限幅。

c01 300 s，同一二进制，仅切换 `gnss/state_bz_en`：

| 配置 | full 3D | steady 3D | static-loc | 对齐拟合残差 |
|---|---|---|---|---|
| `b_z` 关闭 | **1.5857** | 0.8757 | 0.0022 | 0.51 m |
| `b_z` 开启 | 1.9327 | 0.8769 | 0.0022 | 0.95 m |

- 20 维脚手架在 `b_z` 关闭时与 19 维基线一致（1.5857 vs 1.5895），说明
  `DIM_STATE` 扩展本身没有回归；
- `b_z` 开启没有降低固定相位垂直残差，反而吸收 GNSS 垂直噪声/帧差，full
  变差约 0.35 m；
- 当前 GNSS/DD 垂直观测不足以把 `b_z` 与垂直位置/重力/加速度零偏分开，
  该状态不可辨识。

处置：`gnss/state_bz_en` 默认 **false**；保留 20 维脚手架，Stage B 直接把
索引 19 改作水平尺度 `s`，不再同时加 `b_z`。

## 尝试 6：20 维水平尺度 s（Stage B）

把索引 19 从 `b_z` 改作水平尺度 `s`，观测模型 `p_true=[s·px,s·py,pz]`，
GNSS/RTK 增加 `H_s`。

c02 绝对对齐（`p5_c02_scale`）：

- 对齐 yaw -15.98°、拟合残差 1.92 m；
- 首个 DD `|r_code|=51 m`，`s=0.9991`，之后残差 60–64 m；
- 尺度状态学不到东西，因为残差主要是帧/yaw 误差。

c02 相对对齐（`p5_c02_scale_rel`）：

- yaw 8.77°、拟合残差 1.25 m，首个 `|r_code|=4.6–8.1 m`；
- 随后固定相位 `|r_phase|=8.09 m` 被接受并拉 `dx_pos=12.926 m`；
- `s` 被带到 0.974（方向错误），残差 16–33 m，发散。

结论：尺度状态与帧/yaw 误差强耦合。在 c02 帧未稳定、固定相位仍有 8 m
公共残差时开启 `s`，只会把固定相位的大修正吸进尺度。`state_scale_en`
默认 **false**；20 维第 20 维固定为 1，正式链路等价于 19 维基线。Stage B
在帧对齐/固定相位一致性解决前不进入正式链路。

## 尝试 7：DD 打分对齐 + 固定相位 code 门

### 改动

- `tryAlignGnssYaw` 在锁定前用缓冲的 DD code 给“绝对/相对”两个候选打分：
  `[GNSS] align-dd: abs=... rel=... chosen=... max=...`；
- 只有最优候选的稳健 DD code RMS ≤ `gnss/align_dd_max_rms`（默认 6 m）
  才允许锁定，否则 `alignment WITHHELD`；
- 固定相位入口增加 `fixed_phase_code_gate_en`：上一历元 code RMS >3 m 时
  只用浮点 DD，禁止固定相位大修正进入状态；
- `fusion_health.py` 修正对 `LOCKED (..., relative)` 的识别。

### c01 300 s（正增益）

```
align-dd: abs=2.06 m rel=1.72 m chosen=relative
Frame alignment LOCKED (..., relative)
  yaw=+22.238 deg, fit_resid=0.176 m
[RTK] accept ... fixed=7 |r_code|=1.70 |r_phase|=0.25 ...
```

| 指标 | 基线 | alignfix |
|---|---|---|
| full 3D | 1.5857 | **1.2698** |
| 2D | 1.3675 | **0.9759** |
| steady 3D | 0.8757 | **0.7190** |

- 相对对齐的 fit residual 从 0.51 m 降到 0.18 m；
- 固定相位残差从 2–4 m 降到 0.2–0.7 m；
- accept rate 94.3%，FIXED=6/FLOAT=16/REJECT=2。

### c02 300 s（正确拒绝）

```
align-dd: abs=10.10 m rel=9.22 m chosen=relative max=6.0 m
alignment WITHHELD: DD code score 9.22 m > 6.0 m
```

- 绝对/相对候选的 DD code RMS 都在 9–15 m，没有一个能过 6 m；
- 系统正确拒绝锁定，避免再次出现 55 m 跳变；
- c02 仍然只能走位置域回退；这确认了 c02 的瓶颈是 LIO 尺度/形状，
  不是对齐参数。

### c01 全序列 607 s（混合结果）

| 运行 | full 3D | steady 3D | 0–300 s | 对齐 |
|---|---|---|---|---|
| P2 基线 | 2.10 | 1.33 | 1.5895 | 绝对，fit 0.51 m |
| alignfix 300 s | — | — | 1.2698 | 相对，DD score 1.72 m，fit 0.176 m |
| alignfix 607 s | 2.4947 | 1.7606 | 1.4146 | 绝对，DD score 5.66 m，fit 1.16 m |

- 300 s 运行明确改善；
- 607 s 运行前 300 s 也优于基线（1.4146 vs 1.5895），但 300–607 s
  变差，full/steady 低于基线；
- 607 s 运行的 DD 候选分数 5.66 m（相对 6.04 m），已经接近 6 m 门限，
  对齐质量明显不如 300 s 运行的 1.72 m；
- 这是 N=1 的 LIO 运行差异，不能据此判断 DD 打分本身有害；需要 N=3
  同配置重复，区分“对齐候选好坏”和“LIO 轨迹本身好坏”。

### 结论

- **c02**：绝对/相对候选 DD code RMS 均 9–15 m，正确 withhold；不会再
  出现 55 m 跳变，但 c02 DD 仍不可用，保留位置域回退；
- **c01**：DD 打分能选出好候选时（300 s，score 1.72 m）明显提升；候选
  接近门限时（607 s，5.66 m）结果不稳定，需要 N=3；
- **固定相位 code 门**：上一历元 code RMS >3 m 时只用浮点 DD，避免 c02
  的 8 m 固定相位大修正；
- 下一步：c01 300 s N=3 + c01 607 s N=2，确认 DD 打分的稳定性；c02 在
  DD score <6 m 之前不启用 DD。

## 当前代码状态

- `DIM_STATE=20`，第 20 维为水平尺度 `s`，`gnss/state_scale_en=false`
  （固定为 1；实测 Stage B 在 c02 帧不稳定时发散）；
- `coarse_acq_en=false`、`fixed_settle_en=false`，正式配置 `fixed_ratio_good=0.60`；
- 新增诊断字段 `Health.code_rms`、`Health.phase_rms` 保留；
- 自动相对对齐回退保留（仅绝对拟合残差 >5 m 且相对残差 <5 m 时触发）；
- 结果输出使用 `truePos()`（`s=1` 时与旧轨迹一致）；
- 实验配置在 `config/experiments/`，未污染正式配置；
- 相关运行：`p5_c01_dd_coarse2`、`p5_c01_settle`、`p5_c01_ratio40`、
  `p5_c02_dd_coarse`、`p5_c02_dd_coarse_rel`、`p5_c01_bz`、`p5_c01_bzoff`、
  `p5_c02_scale`、`p5_c02_scale_rel`。
