#!/usr/bin/env bash
# Freeze diagnosis matrix v3: shared persistent roscore, per-mode runs.
# usage: bash run_toff3.sh <mode1> [mode2 ...]
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
mkdir -p ~/logs

# shared roscore (survives all modes)
if ! pgrep -f 'bin/roscore' > /dev/null; then
  roscore > ~/logs/roscore.log 2>&1 &
  RPID=$!
  sleep 5
else
  RPID=""
fi

BAG=/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag
for MODE in "$@"; do
  rm -f Log/result/great_urban01_$MODE.txt
  roslaunch fast_livo mapping_great_urban01.launch mode:=$MODE rviz:=false > ~/logs/ur_$MODE.log 2>&1 &
  LPID=$!
  sleep 50
  /opt/ros/noetic/bin/rosbag play -s 170 -u 45 --clock $BAG > ~/logs/ur_play_$MODE.log 2>&1
  sleep 5
  kill $LPID 2>/dev/null
  sleep 4
  echo "==== $MODE ===="
  grep -o 'effective feature num: [0-9]*' ~/logs/ur_$MODE.log | awk '{s+=$4; n++} END {if (n>0) printf "mean eff feat: %.1f (n=%d)\n", s/n, n}'
  N=$(wc -l < Log/result/great_urban01_$MODE.txt 2>/dev/null || echo 0)
  echo "traj lines: $N"
  if [ "$N" -gt 1 ]; then
    head -1 Log/result/great_urban01_$MODE.txt
    tail -1 Log/result/great_urban01_$MODE.txt
    awk 'NR>1 {dx=$2-px; dy=$3-py; dz=$4-pz; s+=sqrt(dx*dx+dy*dy+dz*dz)} {px=$2; py=$3; pz=$4} END {printf "traj total length: %.2f m over %d lines\n", s, NR}' Log/result/great_urban01_$MODE.txt
  fi
done

if [ -n "$RPID" ]; then
  kill $RPID 2>/dev/null
fi
