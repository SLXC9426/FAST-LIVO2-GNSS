#!/usr/bin/env python3
"""Patch rawdata2bag_great.py: left camera only + non-fatal camera export."""
import io

p = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/rawdata2bag_great.py"
txt = io.open(p, encoding="utf-8").read()

old_cam = """    cameras = [
        (0, 'camera_gray_left', '/img0_raw'),
        (1, 'camera_gray_right', '/img1_raw')
    ]"""
new_cam = """    # left camera only: FAST-LIVO2 uses /img0_raw and the img1 raw download
    # is incomplete (10632 vs 12121 frames), which used to crash the converter
    # before the LiDAR export ever ran
    cameras = [
        (0, 'camera_gray_left', '/img0_raw'),
    ]"""
assert old_cam in txt, "cameras block not found"
txt = txt.replace(old_cam, new_cam)

old_imread = """        cv_image = cv2.imread(image_filename)

        if camera in (0, 1):"""
new_imread = """        cv_image = cv2.imread(image_filename)
        if cv_image is None:
            print('[WARN] skipping unreadable image', image_filename)
            continue

        if camera in (0, 1):"""
assert old_imread in txt, "imread block not found"
txt = txt.replace(old_imread, new_imread)

io.open(p, "w", encoding="utf-8").write(txt)
print("patched OK")
