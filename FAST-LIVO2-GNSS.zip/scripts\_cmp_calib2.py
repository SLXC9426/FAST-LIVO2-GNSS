#!/usr/bin/env python3
"""Parse GREAT extrinsic xml files (3 dates) and compare against the extrinsic
values embedded in config/great_campus01.yaml (derived from 2020-10-27)."""
import io, os, re
import numpy as np

BASE = r"D:\BaiduNetdiskDownload\Urban-01\Sensor_Params\Sensor_Parameters"
CONF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\config\great_campus01.yaml"


def parse_xml(path):
    txt = io.open(path, encoding="utf-8", errors="replace").read()
    out = {}
    for m in re.finditer(r"<(\w+)>\s*([\d\s.,eE+-]+?)\s*</\1>", txt):
        vals = [float(x) for x in m.group(2).replace("\n", ",").split(",") if x.strip()]
        out[m.group(1)] = np.array(vals)
    return out


def mats(x):
    """returns dict name -> (R(3,3), t(3,))"""
    res = {}
    for k, v in x.items():
        if v.size == 16 and k not in ("AntennaLever1", "AntennaLever2"):
            M = v.reshape(4, 4)
            res[k] = (M[:3, :3], M[:3, 3])
    return res


def load_conf_extr():
    txt = io.open(CONF, encoding="utf-8", errors="replace").read()
    m = re.search(r"extrinsic_T: \[(.*?)\]", txt)
    t = np.array([float(a) for a in m.group(1).split(",")])
    m = re.search(r"extrinsic_R: \[(.*?)\]", txt)
    r = np.array([float(a) for a in m.group(1).split(",")]).reshape(3, 3)
    m = re.search(r"Rcl: \[(.*?)\]", txt)
    Rcl = np.array([float(a) for a in m.group(1).split(",")]).reshape(3, 3)
    m = re.search(r"Pcl: \[(.*?)\]", txt)
    Pcl = np.array([float(a) for a in m.group(1).split(",")])
    return r, t, Rcl, Pcl


def fmt(a, n=5):
    return " ".join(f"{v: .5f}" for v in a)


def main():
    cfg_R, cfg_t, cfg_Rcl, cfg_Pcl = load_conf_extr()
    print("config(great_campus01) LiDAR->IMU R/t:")
    print("  R =", fmt(cfg_R.flatten(), 4))
    print("  t =", fmt(cfg_t, 4))
    print("config Rcl (cam0->LiDAR):")
    print("  Rcl =", fmt(cfg_Rcl.flatten(), 4))
    print("  Pcl =", fmt(cfg_Pcl, 4))
    print()

    for date in ("2020-10-27", "2020-10-29", "2022-10-27"):
        p = os.path.join(BASE, date, "extrinsic_parameters.xml")
        if not os.path.exists(p):
            print(f"[{date}] MISSING {p}")
            continue
        x = parse_xml(p)
        M = mats(x)
        R_IMU_L, t_IMU_L = M["LIDAR_T_IMU"]  # IMU -> LiDAR
        R_L_IMU, t_L_IMU = R_IMU_L.T, -R_IMU_L.T @ t_IMU_L  # LiDAR -> IMU
        R_I_c0, t_I_c0 = M["IMU_T_cam0"]  # cam0 -> IMU
        Rcl = R_IMU_L @ R_I_c0  # cam0 -> LiDAR
        Pcl = R_IMU_L @ t_I_c0 + t_IMU_L
        dR = np.linalg.norm(Rcl - cfg_Rcl)
        dP = np.linalg.norm(Pcl - cfg_Pcl)
        dRt = np.linalg.norm(R_L_IMU - cfg_R)
        dt = np.linalg.norm(t_L_IMU - cfg_t)
        print(f"[{date}] LiDAR->IMU: dR={dRt:.2e} dt={dt:.2e} | "
              f"cam0->LiDAR: dRcl={dR:.2e} dPcl={dP:.2e}")
        print(f"    Rcl = {fmt(Rcl.flatten(), 4)}")
        print(f"    Pcl = {fmt(Pcl, 4)}")
        # lever arms
        la1 = re.search(r'AntennaLever1[^>]*?X="(-?[\d.]+)" Y="(-?[\d.]+)" Z="(-?[\d.]+)"', io.open(p, encoding="utf-8", errors="replace").read())
        if la1:
            print(f"    AntennaLever1 = ({la1.group(1)}, {la1.group(2)}, {la1.group(3)})")
        print()


if __name__ == "__main__":
    main()
