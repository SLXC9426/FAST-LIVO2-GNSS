#!/usr/bin/env python3
"""Restore img1 export in rawdata2bag_great.py (img1 raw data is now complete)."""
import io

p = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/rawdata2bag_great.py"
txt = io.open(p, encoding="utf-8").read()

old_cam = """    # left camera only: FAST-LIVO2 uses /img0_raw and the img1 raw download
    # is incomplete (10632 vs 12121 frames), which used to crash the converter
    # before the LiDAR export ever ran
    cameras = [
        (0, 'camera_gray_left', '/img0_raw'),
    ]"""
new_cam = """    cameras = [
        (0, 'camera_gray_left', '/img0_raw'),
        (1, 'camera_gray_right', '/img1_raw'),
    ]"""
assert old_cam in txt, "cameras block not found"
txt = txt.replace(old_cam, new_cam)
io.open(p, "w", encoding="utf-8").write(txt)
print("img1 export restored")
