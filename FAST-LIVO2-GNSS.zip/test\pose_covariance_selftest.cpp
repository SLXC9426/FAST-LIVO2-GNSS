﻿/*
R5.1 self-test: covariance coordinate transforms.

Checks that
  fast_livo::poseCovarianceToEnu(P_local, R_enu_body)
matches the sample covariance of errors mapped from the GTSAM body tangent
[rotation, translation] to ROS [translation, rotation] in ENU, and that
  fast_livo::velocityCovarianceToBody(P_enu, R_enu_body)
matches the sample covariance of R^T * e_enu.

A bare block swap (the pre-R5.1 code) fails this test for a non-identity R.

Exit code 0 = pass, 1 = failure.
*/

#include "graph_covariance.h"

#include <Eigen/Dense>
#include <Eigen/Geometry>

#include <cmath>
#include <cstdio>
#include <random>
#include <vector>

namespace
{

int g_failures = 0;

void check(const char *name, double value, double expected, double tol)
{
  const bool ok = std::fabs(value - expected) <= tol;
  std::printf("%s  %-34s value=%.6f expected=%.6f tol=%.4f\n",
              ok ? "ok  " : "FAIL", name, value, expected, tol);
  if (!ok) ++g_failures;
}

Eigen::Matrix3d randomRotation(std::mt19937 &rng)
{
  std::uniform_real_distribution<double> angle(-M_PI, M_PI);
  std::normal_distribution<double> nd(0.0, 1.0);
  Eigen::Vector3d axis(nd(rng), nd(rng), nd(rng));
  if (axis.norm() < 1e-9) axis = Eigen::Vector3d::UnitZ();
  axis.normalize();
  return Eigen::AngleAxisd(angle(rng), axis).toRotationMatrix();
}

Eigen::Matrix<double, 6, 6> randomSpd6(std::mt19937 &rng)
{
  std::normal_distribution<double> nd(0.0, 1.0);
  Eigen::Matrix<double, 6, 6> A;
  for (int r = 0; r < 6; ++r)
    for (int c = 0; c < 6; ++c) A(r, c) = nd(rng);
  Eigen::Matrix<double, 6, 6> P = A * A.transpose();
  P += 0.1 * Eigen::Matrix<double, 6, 6>::Identity();
  return P;
}

Eigen::Matrix3d randomSpd3(std::mt19937 &rng)
{
  std::normal_distribution<double> nd(0.0, 1.0);
  Eigen::Matrix3d A;
  for (int r = 0; r < 3; ++r)
    for (int c = 0; c < 3; ++c) A(r, c) = nd(rng);
  Eigen::Matrix3d P = A * A.transpose();
  P += 0.1 * Eigen::Matrix3d::Identity();
  return P;
}

}  // namespace

int main()
{
  std::mt19937 rng(20261104u);
  std::normal_distribution<double> nd(0.0, 1.0);
  const int N = 200000;

  const Eigen::Matrix3d R = randomRotation(rng);
  const Eigen::Matrix<double, 6, 6> P6 = randomSpd6(rng);
  const Eigen::Matrix3d P3 = randomSpd3(rng);

  // Sample from the GTSAM body tangent [rot, trans].
  Eigen::LLT<Eigen::Matrix<double, 6, 6>> llt6(P6);
  Eigen::Matrix<double, 6, 6> L6 = llt6.matrixL();
  Eigen::LLT<Eigen::Matrix3d> llt3(P3);
  Eigen::Matrix3d L3 = llt3.matrixL();

  Eigen::Matrix<double, 6, 6> sample_pose = Eigen::Matrix<double, 6, 6>::Zero();
  Eigen::Matrix3d sample_vel = Eigen::Matrix3d::Zero();
  for (int k = 0; k < N; ++k)
  {
    Eigen::Matrix<double, 6, 1> z6;
    for (int i = 0; i < 6; ++i) z6(i) = nd(rng);
    const Eigen::Matrix<double, 6, 1> e_local = L6 * z6;
    Eigen::Matrix<double, 6, 1> e_ros;
    e_ros.head<3>() = R * e_local.tail<3>();   // translation in ENU
    e_ros.tail<3>() = R * e_local.head<3>();   // rotation in ENU
    sample_pose += e_ros * e_ros.transpose();

    Eigen::Vector3d z3(nd(rng), nd(rng), nd(rng));
    const Eigen::Vector3d e_enu = L3 * z3;
    const Eigen::Vector3d e_body = R.transpose() * e_enu;
    sample_vel += e_body * e_body.transpose();
  }
  sample_pose /= static_cast<double>(N);
  sample_vel /= static_cast<double>(N);

  const Eigen::Matrix<double, 6, 6> expected_pose = fast_livo::poseCovarianceToEnu(P6, R);
  const Eigen::Matrix3d expected_vel = fast_livo::velocityCovarianceToBody(P3, R);
  const double pose_rel = (sample_pose - expected_pose).norm() / expected_pose.norm();
  const double vel_rel = (sample_vel - expected_vel).norm() / expected_vel.norm();
  check("pose cov relative error", pose_rel, 0.0, 0.02);
  check("velocity cov relative error", vel_rel, 0.0, 0.02);

  // A bare block swap must fail for a generic rotation: verify the test is
  // sensitive by comparing against the unrotated swap.
  Eigen::Matrix<double, 6, 6> swapped;
  swapped.block<3, 3>(0, 0) = P6.block<3, 3>(3, 3);
  swapped.block<3, 3>(0, 3) = P6.block<3, 3>(3, 0);
  swapped.block<3, 3>(3, 0) = P6.block<3, 3>(0, 3);
  swapped.block<3, 3>(3, 3) = P6.block<3, 3>(0, 0);
  const double swap_rel =
      (swapped - expected_pose).norm() / expected_pose.norm();
  check("bare block swap is rejected", swap_rel > 0.01 ? 1.0 : 0.0, 1.0, 0.0);

  // R5.3: joint boundary covariance. The pose block is GTSAM [rot, trans_body],
  // velocity is ENU; the residual is [rot, trans_enu, vel_enu]. Verify the
  // A P A^T transform, including a non-zero pose-velocity cross block.
  {
    Eigen::Matrix<double, 9, 9> P9 = Eigen::Matrix<double, 9, 9>::Zero();
    P9.block<6, 6>(0, 0) = P6;
    P9.block<3, 3>(6, 6) = P3;
    std::normal_distribution<double> nd(0.0, 0.2);
    Eigen::Matrix<double, 6, 3> C;
    for (int r = 0; r < 6; ++r)
      for (int c = 0; c < 3; ++c) C(r, c) = nd(rng);
    P9.block<6, 3>(0, 6) = C;
    P9.block<3, 6>(6, 0) = C.transpose();

    Eigen::Matrix<double, 9, 9> A = Eigen::Matrix<double, 9, 9>::Identity();
    A.block<3, 3>(3, 3) = R;
    const Eigen::Matrix<double, 9, 9> expected9 = A * P9 * A.transpose();
    const Eigen::Matrix<double, 9, 9> actual9 =
        fast_livo::boundaryJointCovarianceToEnu(P6, P3, C, R);
    const double rel9 =
        (actual9 - expected9).norm() / expected9.norm();
    check("boundary joint cov relative error", rel9, 0.0, 1e-12);

    const Eigen::Matrix3d expected_tt = R * P6.block<3, 3>(3, 3) * R.transpose();
    check("boundary joint trans block",
          (actual9.block<3, 3>(3, 3) - expected_tt).norm(),
          0.0, 1e-12);
    const Eigen::Matrix<double, 6, 3> actual_cross =
        actual9.block<6, 3>(0, 6);
    const double cross_err =
        (actual_cross.topRows<3>() - C.topRows<3>()).norm() +
        (actual_cross.bottomRows<3>() - R * C.bottomRows<3>()).norm();
    check("boundary joint cross block", cross_err, 0.0, 1e-12);
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: covariance coordinate transforms\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
