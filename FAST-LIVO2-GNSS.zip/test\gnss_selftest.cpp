/*
ENU <-> WGS84 round-trip self-test (R3 阶段 0 / WP6).

Purpose: enuToWgs84 had a wrong Bowring denominator (p * (1 - e2*a) ~= -42696
instead of p * b). This asset is what makes that class of error falsifiable, and
it must fail if the inverse is broken again.

Two directions are checked over a matrix of origins and test points:

  (1) ENU -> WGS84 -> ENU
      position residual in metres          threshold 1e-3 m
  (2) WGS84 -> ENU -> WGS84
      angular residual in radians          threshold 1e-9 rad
      height residual in metres            threshold 1e-3 m

Coverage, as required by the WP6 plan: equator / mid latitude / high latitude /
near-pole, positive and negative longitude, and altitude -100 / 0 / 3000 m.
Exactly 90 deg is excluded: longitude is undefined there, so the round trip is
singular by construction rather than a code defect.

Standalone: no gtest and no ROS node. Built as the `gnss_selftest` target against
the real gnss_proc library and run manually:

    ./devel/lib/fast_livo/gnss_selftest

Exit code 0 = all thresholds met, 1 = at least one failure.
*/

#include "gnss_processing.h"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace
{

struct Origin
{
  const char *name;
  double lat, lon, alt;
};

// Geographic spread of the ENU frame origin. The near-polar cases are the ones
// the old altitude expression (p / cos(lat) - N) degraded on.
const Origin kOrigins[] = {
    {"equator   lon=0     ", 0.0, 0.0, 0.0},
    {"equator   lon=+120  ", 0.0, 120.0, 0.0},
    {"equator   lon=-120  ", 0.0, -120.0, 0.0},
    {"midlat-N  lon=+90   ", 45.0, 90.0, 0.0},
    {"midlat-S  lon=-75   ", -45.0, -75.0, 3000.0},
    {"highlat-N lon=+20   ", 70.0, 20.0, 0.0},
    {"highlat-S lon=-150  ", -70.0, -150.0, -100.0},
    {"nearpole-N lat=89.9", 89.9, 10.0, 0.0},
    {"nearpole-S lat=-89.9", -89.9, -30.0, 0.0},
};

// ENU test offsets (east, north, up) in metres. Local ones dominate; one large
// offset keeps the tangent-plane arithmetic honest far from the origin. The
// conversion is exact ECEF differencing, so distance from the origin must not
// change the round-trip quality.
const double kEnuOffset[][3] = {
    {0.0, 0.0, 0.0},       {-1000.0, -1000.0, -100.0}, {1000.0, 1000.0, 100.0},
    {-100.0, 250.0, 0.0},  {250.0, -100.0, 3000.0},    {12345.0, -6789.0, -50.0},
    {-100000.0, 100000.0, 1000.0},
};

const double kAltitudes[] = {-100.0, 0.0, 3000.0};

double deg2rad(double d) { return d * M_PI / 180.0; }

} // namespace

int main()
{
  int failures = 0;

  double max_enu_resid = 0.0;    // test (1), metres
  double max_ang_resid = 0.0;    // test (2), radians
  double max_alt_resid = 0.0;    // test (2), metres
  const char *worst_enu_case = "";
  const char *worst_ang_case = "";

  const double kEnuTol = 1e-3;   // 1 mm
  const double kAngTol = 1e-9;   // rad
  const double kAltTol = 1e-3;   // 1 mm

  std::printf("=== (1) ENU -> WGS84 -> ENU ===\n");
  for (const Origin &o : kOrigins)
  {
    GnssProcess gp;
    gp.setOrigin(o.lat, o.lon, o.alt);
    if (!gp.isOriginSet())
    {
      std::printf("  FAIL %s : origin not set\n", o.name);
      failures++;
      continue;
    }

    for (const auto &d : kEnuOffset)
    {
      const double e = d[0], n = d[1], u = d[2];
      double lat = 0.0, lon = 0.0, alt = 0.0;
      gp.enuToWgs84(e, n, u, lat, lon, alt);

      double e2 = 0.0, n2 = 0.0, u2 = 0.0;
      gp.wgs84ToEnu(lat, lon, alt, e2, n2, u2);

      const double re = e - e2, rn = n - n2, ru = u - u2;
      const double resid = std::sqrt(re * re + rn * rn + ru * ru);
      if (resid > max_enu_resid)
      {
        max_enu_resid = resid;
        worst_enu_case = o.name;
      }
      if (resid > kEnuTol)
      {
        std::printf("  FAIL %s  ENU(%.1f, %.1f, %.1f) -> resid %.6g m\n",
                    o.name, e, n, u, resid);
        failures++;
      }
    }
  }
  std::printf("  max residual over %zu origins x %zu offsets: %.6g m  (tol %.0e m)  worst=%s\n",
              sizeof(kOrigins) / sizeof(kOrigins[0]),
              sizeof(kEnuOffset) / sizeof(kEnuOffset[0]), max_enu_resid, kEnuTol,
              worst_enu_case);
  std::printf("  %s\n", max_enu_resid <= kEnuTol ? "PASS" : "FAIL");

  std::printf("\n=== (2) WGS84 -> ENU -> WGS84 ===\n");
  // Test points: the origin plus small geodetic offsets, so each case stays
  // inside one ENU frame; altitudes swept over -100 / 0 / 3000 m.
  const double kLatOff[] = {0.0, 0.0005, -0.0005, 0.005, -0.005};
  const double kLonOff[] = {0.0, 0.0005, -0.0005, 0.005, -0.005};

  for (const Origin &o : kOrigins)
  {
    GnssProcess gp;
    gp.setOrigin(o.lat, o.lon, o.alt);

    for (double dlat : kLatOff)
    {
      for (double dlon : kLonOff)
      {
        const double lat_in = o.lat + dlat;
        const double lon_in = o.lon + dlon;
        if (std::fabs(lat_in) >= 90.0) continue; // singular, not a code defect

        for (double alt_in : kAltitudes)
        {
          double e = 0.0, n = 0.0, u = 0.0;
          gp.wgs84ToEnu(lat_in, lon_in, alt_in, e, n, u);

          double lat = 0.0, lon = 0.0, alt = 0.0;
          gp.enuToWgs84(e, n, u, lat, lon, alt);

          const double dlat_r = deg2rad(lat - lat_in);
          const double dlon_r = deg2rad(lon - lon_in);
          // The angular residual is scale-dependent in metres; weight longitude
          // by cos(lat) so a near-pole longitude error is not under-reported.
          const double ang = std::max(std::fabs(dlat_r),
                                      std::fabs(dlon_r) * std::cos(deg2rad(lat_in)));
          const double dalt = alt - alt_in;

          if (ang > max_ang_resid)
          {
            max_ang_resid = ang;
            worst_ang_case = o.name;
          }
          if (std::fabs(dalt) > max_alt_resid) max_alt_resid = std::fabs(dalt);

          if (ang > kAngTol || std::fabs(dalt) > kAltTol)
          {
            std::printf("  FAIL %s  in(%.6f, %.6f, %.1f) -> out(%.6f, %.6f, %.2f)"
                        "  d_ang %.6g rad  d_alt %.6g m\n",
                        o.name, lat_in, lon_in, alt_in, lat, lon, alt, ang, dalt);
            failures++;
          }
        }
      }
    }
  }
  std::printf("  max angular residual: %.6g rad  (tol %.0e rad)  worst=%s\n",
              max_ang_resid, kAngTol, worst_ang_case);
  std::printf("  max height  residual: %.6g m    (tol %.0e m)\n", max_alt_resid, kAltTol);
  std::printf("  %s\n",
              (max_ang_resid <= kAngTol && max_alt_resid <= kAltTol) ? "PASS" : "FAIL");

  std::printf("\n%s (%d failure%s)\n", failures == 0 ? "ALL PASS" : "FAILED",
              failures, failures == 1 ? "" : "s");
  return failures == 0 ? 0 : 1;
}
