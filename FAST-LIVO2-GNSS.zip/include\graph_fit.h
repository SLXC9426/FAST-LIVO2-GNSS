#ifndef GRAPH_FIT_H_
#define GRAPH_FIT_H_

// A2.5: robust 2D similarity fit between LIO positions and ENU fixes.
//
// The graph's initial alignment is a yaw/scale/translation fit of the LIO
// track to the GNSS track. It is the seed for the innovation gate's prediction
// (scale and yaw) and for sig_rtk_xy (via fit RMS), so a single 26-29 m gross
// error can bias the whole alignment. This header extracts the fit so the
// two-pass and Huber variants can be unit-tested against the exact pass-1
// formulas used before A2.5.
//
// Model: enu ~= scale * Rz(yaw) * lio + tr, with the vertical channel pinned to
// the mean difference (the existing graph behaviour).
// Header-only (Eigen) so the tests do not need GTSAM.

#include <Eigen/Dense>

#include <algorithm>
#include <cmath>
#include <string>
#include <vector>

namespace fast_livo
{

struct SimilarityFitOptions
{
  bool scale_fit = true;
  double scale_min = 0.90;
  double scale_max = 1.10;
  // Frontend already locked world<-ENU; its yaw wins over the fitted one.
  bool have_yaw_override = false;
  double yaw_override = 0.0;
};

struct SimilarityFitResult
{
  bool valid = false;
  double yaw = 0.0;
  double scale = 1.0;
  double rms = 0.0;  // weighted XY RMS
  Eigen::Vector3d tr = Eigen::Vector3d::Zero();
  int n = 0;
  double weight_sum = 0.0;
};

inline double fitMedian(std::vector<double> v)
{
  if (v.empty()) return 0.0;
  const size_t k = v.size() / 2;
  std::nth_element(v.begin(), v.begin() + k, v.end());
  const double hi = v[k];
  if (v.size() % 2) return hi;
  std::nth_element(v.begin(), v.begin() + k - 1, v.end());
  return 0.5 * (v[k - 1] + hi);
}

// Weighted fit. `weights` empty = all ones. `weights[i] <= 0` drops a sample.
inline SimilarityFitResult fitSimilarity2D(
    const std::vector<Eigen::Vector3d> &lio,
    const std::vector<Eigen::Vector3d> &enu,
    const std::vector<double> &weights,
    const SimilarityFitOptions &opt)
{
  SimilarityFitResult out;
  const size_t n = std::min(lio.size(), enu.size());
  if (n == 0) return out;

  const auto wof = [&](size_t i) {
    const double w = weights.empty() ? 1.0 : weights[i];
    return std::isfinite(w) && w > 0.0 ? w : 0.0;
  };

  double wsum = 0.0, mx = 0.0, my = 0.0, mrx = 0.0, mry = 0.0, mrz = 0.0,
         msz = 0.0;
  for (size_t i = 0; i < n; ++i)
  {
    const double w = wof(i);
    if (w <= 0.0) continue;
    wsum += w;
    mx += w * lio[i].x();
    my += w * lio[i].y();
    mrx += w * enu[i].x();
    mry += w * enu[i].y();
    mrz += w * enu[i].z();
    msz += w * lio[i].z();
  }
  if (!(wsum > 0.0)) return out;
  mx /= wsum; my /= wsum;
  mrx /= wsum; mry /= wsum; mrz /= wsum; msz /= wsum;

  double sc = 0.0, sd = 0.0, spread = 0.0;
  for (size_t i = 0; i < n; ++i)
  {
    const double w = wof(i);
    if (w <= 0.0) continue;
    const double lx = lio[i].x() - mx, ly = lio[i].y() - my;
    const double ex = enu[i].x() - mrx, ey = enu[i].y() - mry;
    sc += w * (lx * ey - ly * ex);
    sd += w * (lx * ex + ly * ey);
    spread += w * (lx * lx + ly * ly);
  }
  // A degenerate LIO track has no direction; do not hand back a random yaw.
  if (!(spread > 1e-9)) return out;

  const double yaw = opt.have_yaw_override ? opt.yaw_override
                                           : std::atan2(sc, sd);
  const double cy = std::cos(yaw), sy = std::sin(yaw);

  double scale = 1.0;
  if (opt.scale_fit)
  {
    double num = 0.0, den = 0.0;
    for (size_t i = 0; i < n; ++i)
    {
      const double w = wof(i);
      if (w <= 0.0) continue;
      const double lx = lio[i].x() - mx, ly = lio[i].y() - my;
      const double ex = enu[i].x() - mrx, ey = enu[i].y() - mry;
      const double qx = cy * lx - sy * ly;
      const double qy = sy * lx + cy * ly;
      num += w * (qx * ex + qy * ey);
      den += w * (qx * qx + qy * qy);
    }
    if (den > 1e-9) scale = num / den;
    if (!std::isfinite(scale)) scale = 1.0;
    scale = std::min(opt.scale_max, std::max(opt.scale_min, scale));
  }

  out.tr << mrx - scale * (cy * mx - sy * my),
      mry - scale * (sy * mx + cy * my), mrz - msz;

  double sq = 0.0;
  for (size_t i = 0; i < n; ++i)
  {
    const double w = wof(i);
    if (w <= 0.0) continue;
    const double qx = scale * (cy * lio[i].x() - sy * lio[i].y()) + out.tr.x();
    const double qy = scale * (sy * lio[i].x() + cy * lio[i].y()) + out.tr.y();
    const double dx = qx - enu[i].x();
    const double dy = qy - enu[i].y();
    sq += w * (dx * dx + dy * dy);
  }
  out.yaw = yaw;
  out.scale = scale;
  out.rms = std::sqrt(std::max(0.0, sq / wsum));
  out.n = static_cast<int>(n);
  out.weight_sum = wsum;
  out.valid = std::isfinite(out.rms) && std::isfinite(out.tr.x()) &&
              std::isfinite(out.tr.y()) && std::isfinite(out.tr.z());
  return out;
}

// Weighted XY RMS of an existing fit on a (possibly different) weight set.
// Used by the A2.5 guard: a second fit is accepted only when it actually
// explains the accepted samples better than the first one.
inline double similarityFitRms(
    const SimilarityFitResult &fit,
    const std::vector<Eigen::Vector3d> &lio,
    const std::vector<Eigen::Vector3d> &enu,
    const std::vector<double> &weights)
{
  const size_t n = std::min(lio.size(), enu.size());
  double wsum = 0.0, sq = 0.0;
  for (size_t i = 0; i < n; ++i)
  {
    const double w = weights.empty() ? 1.0 : weights[i];
    if (!std::isfinite(w) || w <= 0.0) continue;
    const double cy = std::cos(fit.yaw), sy = std::sin(fit.yaw);
    const double qx = fit.scale * (cy * lio[i].x() - sy * lio[i].y()) +
                      fit.tr.x();
    const double qy = fit.scale * (sy * lio[i].x() + cy * lio[i].y()) +
                      fit.tr.y();
    const double dx = qx - enu[i].x();
    const double dy = qy - enu[i].y();
    sq += w * (dx * dx + dy * dy);
    wsum += w;
  }
  return wsum > 0.0 ? std::sqrt(std::max(0.0, sq / wsum)) : 0.0;
}

// Huber IRLS. The scale in `huber_k` is MAD units: c = huber_k * 1.4826 * MAD,
// floored at 0.2 m so a perfectly clean fit does not downweight ordinary noise.
inline SimilarityFitResult fitSimilarity2DRobust(
    const std::vector<Eigen::Vector3d> &lio,
    const std::vector<Eigen::Vector3d> &enu,
    const SimilarityFitOptions &opt, double huber_k = 1.5, int iterations = 3)
{
  const size_t n = std::min(lio.size(), enu.size());
  std::vector<double> w(n, 1.0);
  SimilarityFitResult fit = fitSimilarity2D(lio, enu, w, opt);
  if (!fit.valid) return fit;

  for (int it = 0; it < iterations; ++it)
  {
    std::vector<double> res;
    res.reserve(n);
    for (size_t i = 0; i < n; ++i)
    {
      const double qx = fit.scale * (std::cos(fit.yaw) * lio[i].x() -
                                     std::sin(fit.yaw) * lio[i].y()) +
                        fit.tr.x();
      const double qy = fit.scale * (std::sin(fit.yaw) * lio[i].x() +
                                     std::cos(fit.yaw) * lio[i].y()) +
                        fit.tr.y();
      res.push_back(std::hypot(qx - enu[i].x(), qy - enu[i].y()));
    }
    const double med = fitMedian(res);
    std::vector<double> dev;
    dev.reserve(n);
    for (double r : res) dev.push_back(std::fabs(r - med));
    const double mad = std::max(1e-6, fitMedian(dev));
    const double c = std::max(0.2, huber_k * 1.4826 * mad);
    for (size_t i = 0; i < n; ++i)
      w[i] = res[i] <= c ? 1.0 : c / std::max(res[i], 1e-9);
    fit = fitSimilarity2D(lio, enu, w, opt);
    if (!fit.valid) return fit;
  }
  return fit;
}

}  // namespace fast_livo

#endif  // GRAPH_FIT_H_
