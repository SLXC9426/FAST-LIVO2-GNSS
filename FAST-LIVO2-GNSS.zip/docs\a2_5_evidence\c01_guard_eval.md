# A0/A1 evaluation

reference: `/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data/campus01_reference.tum`

| arm | rows | matched | ATE med/p95/RMSE (m) | abs 2D RMSE | abs 3D RMSE | abs p95 | 2D RMSE after constant-bias removal | RPE1 RMSE | RPE10 RMSE |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| F1 | 606 | 606 | 0.402 / 1.287 / 0.710 | 0.511 | 0.807 | 1.576 | 0.443 | 0.101 | 0.518 |
| F3g | 606 | 606 | 0.402 / 1.287 / 0.710 | 0.511 | 0.807 | 1.576 | 0.443 | 0.101 | 0.518 |
| F4g | 606 | 606 | 1.277 / 2.040 / 1.398 | 0.586 | 1.139 | 1.770 | 0.471 | 0.100 | 0.511 |

## Segment absolute 2D / 3D / bias-removed 2D RMSE (m)

| arm | 0-120s | 240-360s |
|---|---|---|
| F1 | 0.546 / 0.716 / 0.724 | 0.430 / 0.702 / 0.400 |
| F3g | 0.546 / 0.716 / 0.724 | 0.430 / 0.702 / 0.400 |
| F4g | 0.559 / 0.717 / 0.720 | 0.443 / 0.742 / 0.397 |

- F1 median ENU bias: E -0.015, N 0.389, U 0.181 m

- F3g median ENU bias: E -0.015, N 0.389, U 0.181 m

- F4g median ENU bias: E 0.208, N 0.412, U 0.021 m
