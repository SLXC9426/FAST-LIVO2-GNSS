#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarise the GNSS velocity (doppler) observation from gnss_poses.txt DV records.

R3 stage 4 (L2) items 6.5 / 6.6. The DV record is written once per epoch that
actually USED the velocity observation, and carries

    DV <t_g_rel> <|v|_lio> <|v|_gnss> <|res_v|> <lever>

The checks this supports:

  * 6.5 standstill: the residual must go to ~0 as the speed goes to ~0. Printed as
    a speed-binned table, because a single global mean hides exactly this
    (campus-01 is parked for much of the recording, and a residual that is small
    only when moving would still look fine on average).
  * the lever term |R*(omega x p_lever)| must grow with the turn rate: it is ~0
    going straight and ~0.1-0.2 m/s in a turn with this 0.37 m antenna. Printing it
    against speed makes a silently-absent correction visible (that is how the
    omega source bug was found: the term was structurally zero).

Usage:
  gnss_vel_stats.py <gnss_poses.txt> [more.txt ...]
"""
import math
import sys


def load(path):
    dv = []
    for ln in open(path, errors='replace'):
        if not ln.startswith('DV'):
            continue
        p = ln.split()
        if len(p) != 6:
            continue
        try:
            dv.append((float(p[1]), float(p[2]), float(p[3]), float(p[4]), float(p[5])))
        except ValueError:
            continue
    return dv


def pct(v, q):
    if not v:
        return float('nan')
    s = sorted(v)
    i = min(len(s) - 1, max(0, int(round((len(s) - 1) * q / 100.0))))
    return s[i]


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        return 1
    for path in sys.argv[1:]:
        dv = load(path)
        print('=== %s' % path)
        if not dv:
            print('   no DV records (gnss/use_velocity off, or no velocity epoch '
                  'matched/passed the status gate)')
            print()
            continue
        n = len(dv)
        print('   %d epochs used the velocity observation' % n)

        # ---- 6.5: residual vs speed -----------------------------------------
        bins = [(0.0, 0.3), (0.3, 1.0), (1.0, 3.0), (3.0, 6.0), (6.0, 1e9)]
        print('   %-14s %6s %9s %9s %9s %9s' % ('|v| bin (m/s)', 'n', '|res_v| mean',
                                                'p50', 'p95', '|lever| p50'))
        for lo, hi in bins:
            sel = [d for d in dv if lo <= d[1] < hi]
            if not sel:
                continue
            r = [d[3] for d in sel]
            lv = [d[4] for d in sel]
            print('   %-14s %6d %9.4f %9.4f %9.4f %9.4f'
                  % ('%.1f-%.1f' % (lo, hi) if hi < 1e8 else '>%.1f' % lo,
                     len(sel), sum(r) / len(r), pct(r, 50), pct(r, 95), pct(lv, 50)))
        r_all = [d[3] for d in dv]
        print('   overall |res_v|: mean %.4f p50 %.4f p95 %.4f max %.4f m/s'
              % (sum(r_all) / n, pct(r_all, 50), pct(r_all, 95), max(r_all)))
        # the two quantities the model relates: |v|_lio vs |v|_gnss
        dsp = sorted(abs(d[1] - d[2]) for d in dv)
        print('   | |v|_lio - |v|_gnss| : p50 %.4f p95 %.4f m/s (speed, not vector)'
              % (pct(dsp, 50), pct(dsp, 95)))
        print('   lever term max %.4f m/s  (should be ~0 straight, ~0.1-0.2 in a turn)'
              % max(d[4] for d in dv))
        print()
    return 0


if __name__ == '__main__':
    sys.exit(main())
