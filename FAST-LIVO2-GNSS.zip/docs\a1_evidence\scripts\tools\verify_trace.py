#!/usr/bin/env python3
"""A1 archive check: every candidate RTK epoch gets exactly one decision.

For one arm, compares the association trace with the input fix stream:
  - trace timestamps are unique;
  - every fix inside the keyframe span appears exactly once;
  - no trace row is outside the input stream;
  - decision counts are disjoint and sum to the row count;
  - factor == 1 iff decision == "factor";
  - duplicate publications are marked as such.
Prints a compact report and exits non-zero on a contract violation.
"""
import argparse
import csv
from collections import Counter
from pathlib import Path

import numpy as np


def load_times(path):
    t = []
    for line in Path(path).open(errors="ignore"):
        s = line.split()
        if len(s) < 4:
            continue
        try:
            t.append(float(s[0]))
        except ValueError:
            pass
    return np.asarray(sorted(t))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", required=True)
    ap.add_argument("--livo", required=True)
    ap.add_argument("--rtk", required=True)
    ap.add_argument("--tol", type=float, default=1e-6)
    args = ap.parse_args()

    kf = load_times(args.livo)
    rtk = load_times(args.rtk)
    rtk = rtk[(rtk >= kf[0]) & (rtk <= kf[-1])]
    # one epoch per distinct timestamp (duplicate publications are one epoch)
    uniq = [rtk[0]] if len(rtk) else []
    for t in rtk[1:]:
        if t - uniq[-1] > args.tol:
            uniq.append(t)
    uniq = np.asarray(uniq)

    rows = []
    with open(args.trace, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    tt = np.array([float(r["t_fix"]) for r in rows])
    decisions = Counter(r["decision"] for r in rows)
    status = Counter(r["status"] for r in rows)

    problems = []
    if len(np.unique(tt)) != len(tt):
        problems.append("duplicate t_fix rows")
    missing = 0
    for t in uniq:
        if len(tt) == 0 or np.min(np.abs(tt - t)) > 1e-3:
            missing += 1
    extra = 0
    for t in tt:
        if np.min(np.abs(uniq - t)) > 1e-3:
            extra += 1
    if missing:
        problems.append(f"{missing} input epochs have no decision row")
    # Rows outside [first, last] keyframe are legitimate: the association
    # reports before_range/after_range for the +-5 s halo. They are reported
    # but are not a contract violation.

    bad_factor = sum(1 for r in rows
                     if (int(r["factor"]) == 1) != (r["decision"] == "factor"))
    if bad_factor:
        problems.append(f"{bad_factor} rows disagree on factor/decision")
    if sum(decisions.values()) != len(rows):
        problems.append("decision counts do not sum to rows")

    miss_t = [t for t in uniq
              if len(tt) == 0 or np.min(np.abs(tt - t)) > 1e-3]
    extra_t = [t for t in tt
               if len(uniq) == 0 or np.min(np.abs(uniq - t)) > 1e-3]
    print(f"trace={len(rows)} input_epochs={len(uniq)} "
          f"missing={missing} extra={extra} unique_t={len(np.unique(tt))}")
    if miss_t:
        print("missing at:", [f"{t:.3f}" for t in miss_t[:8]])
    if extra_t:
        print("extra at:  ", [f"{t:.3f}" for t in extra_t[:8]])
    print("decisions:", dict(decisions))
    print("status:", dict(status))
    if problems:
        print("FAIL:", "; ".join(problems))
        return 1
    print("PASS")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
