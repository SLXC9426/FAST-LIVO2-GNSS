#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Attach GREAT-MSF TCRTK fixed-phase information to an existing DD CSV.

MVP data path
-------------
Input:
  * DD CSV from scripts/rtk/rtk_preprocess.py (code/phase/satellite ECEF).
  * GREAT-MSF .ins solution (fixed epochs, ECEF, pitch/roll/yaw).
Output:
  * Same CSV plus fix_valid, dd_phase_fixed, amb_bias, n_int, fix_residual.

The integer is recovered per satellite pair from the GREAT-MSF fixed
trajectory, with the antenna lever arm applied.  A per-pair fractional bias is
estimated over all fixed epochs (circular median) and removed; this absorbs the
broadcast-orbit/clock and antenna-phase differences between GREAT-MSF and the
DD generator.  A pair is marked usable only when GREAT-MSF is Fixed, there is no
slip/reference change, and the fixed-phase residual is below --gate.

This is the MVP bridge: it does not modify GREAT-MSF internals.  The fixed
phase is then consumed by RtkTight (rtk/fixed_phase_en=true).
"""
import argparse
import csv
import json
import math
import os
import sys
from collections import defaultdict

import numpy as np

C_LIGHT = 299792458.0
GPS_EPOCH_UNIX = 315964800.0
LAMBDA = {
    ("G", "L1"): C_LIGHT / 1575.42e6,
    ("G", "L2"): C_LIGHT / 1227.60e6,
    ("C", "B2I"): C_LIGHT / 1207.14e6,
    ("C", "B3I"): C_LIGHT / 1268.52e6,
}
WGS84_A = 6378137.0
WGS84_E2 = 6.6943799901413165e-3


def ecef_to_geodetic(xyz):
    x, y, z = xyz
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1.0 - WGS84_E2))
    for _ in range(8):
        s = math.sin(lat)
        n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
        h = p / math.cos(lat) - n
        lat = math.atan2(z, p * (1.0 - WGS84_E2 * n / (n + h)))
    s = math.sin(lat)
    n = WGS84_A / math.sqrt(1.0 - WGS84_E2 * s * s)
    h = p / math.cos(lat) - n
    return lat, lon, h


def dcm_body_to_enu(pitch_deg, roll_deg, yaw_deg):
    p, r, y = map(math.radians, (pitch_deg, roll_deg, yaw_deg))
    sp, cp = math.sin(p), math.cos(p)
    sr, cr = math.sin(r), math.cos(r)
    sy, cy = math.sin(y), math.cos(y)
    return np.array([
        [cy * cr - sy * sp * sr, -sy * cp, cy * sr + sy * sp * cr],
        [sy * cr + cy * sp * sr, cy * cp, sy * sr - cy * sp * cr],
        [-cp * sr, sp, cp * cr],
    ])


def dcm_ecef_to_enu(lat, lon):
    sl, cl = math.sin(lat), math.cos(lat)
    so, co = math.sin(lon), math.cos(lon)
    return np.array([
        [-so, co, 0.0],
        [-sl * co, -sl * so, cl],
        [cl * co, cl * so, sl],
    ])


def circular_median(values):
    values = np.asarray(values, dtype=float)
    ang = 2.0 * math.pi * values
    mean_ang = math.atan2(np.mean(np.sin(ang)), np.mean(np.cos(ang)))
    return (mean_ang / (2.0 * math.pi) + 0.5) % 1.0 - 0.5


def load_ins(path):
    """Return {sow_int: (ecef, pitch, roll, yaw, amb_status, ratio)}."""
    out = {}
    with open(path, "r", errors="replace") as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            v = line.split()
            if len(v) < 21:
                continue
            try:
                t = float(v[0])
                ecef = np.array([float(v[1]), float(v[2]), float(v[3])])
                pitch, roll, yaw = float(v[7]), float(v[8]), float(v[9])
                status = v[19]
                ratio = float(v[20])
            except (ValueError, IndexError):
                continue
            key = int(round(t))
            if key not in out:
                out[key] = (ecef, pitch, roll, yaw, status, ratio)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dd-csv", required=True)
    ap.add_argument("--ins", required=True)
    ap.add_argument("--out-csv", required=True)
    ap.add_argument("--lever", default="-0.05,-0.41,0.15",
                    help="antenna lever arm in IMU RFU frame (m)")
    ap.add_argument("--base-ecef", default="-2267749.9279,5009154.2407,3221290.6333",
                    help="base ECEF used by the DD generator")
    ap.add_argument("--gate", type=float, default=0.10,
                    help="max fixed-phase residual (m) for fix_valid=1")
    ap.add_argument("--min-epochs", type=int, default=10,
                    help="minimum fixed epochs for a per-pair bias estimate")
    ap.add_argument("--mad-k", type=float, default=3.0,
                    help="per-pair sigma = mad_k * bias_MAD * wavelength")
    ap.add_argument("--max-mad", type=float, default=0.15,
                    help="reject a pair whose bias MAD exceeds this (cycles)")
    ap.add_argument("--sigma-floor", type=float, default=0.03,
                    help="minimum per-pair fixed-phase sigma (m)")
    ap.add_argument("--sigma-ceil", type=float, default=1.0,
                    help="maximum per-pair fixed-phase sigma (m)")
    ap.add_argument("--summary", default="")
    args = ap.parse_args()

    lever = np.array([float(x) for x in args.lever.split(",")])
    base = np.array([float(x) for x in args.base_ecef.split(",")])
    ins = load_ins(args.ins)
    rows = list(csv.DictReader(open(args.dd_csv, newline="")))
    if not rows:
        raise SystemExit("empty DD CSV")
    if not ins:
        raise SystemExit("empty/unsupported .ins file")

    def antenna_position(sow):
        rec = ins.get(sow)
        if rec is None:
            return None
        ecef, pitch, roll, yaw, status, ratio = rec
        lat, lon, _ = ecef_to_geodetic(ecef)
        return ecef + dcm_ecef_to_enu(lat, lon).T @ dcm_body_to_enu(pitch, roll, yaw) @ lever, status, ratio

    def dd_geom(row, p_ant):
        sat = np.array([float(row["sat_x"]), float(row["sat_y"]), float(row["sat_z"])])
        ref = np.array([float(row["ref_x"]), float(row["ref_y"]), float(row["ref_z"])])
        return ((np.linalg.norm(sat - p_ant) - np.linalg.norm(sat - base)) -
                (np.linalg.norm(ref - p_ant) - np.linalg.norm(ref - base)))

    # Pass 1: per-pair fractional bias from fixed epochs.
    by_key = defaultdict(list)
    for r in rows:
        sow = int(round((float(r["t_gps"]) - GPS_EPOCH_UNIX) % 604800.0))
        ap = antenna_position(sow)
        if ap is None or ap[1] != "Fixed":
            continue
        if int(r.get("slip", 0)) or int(r.get("ref_change", 0)):
            continue
        key = (r["sys"], r["freq"], r["ref_sat"], r["sat"])
        frac = ((float(r["dd_phase"]) - dd_geom(r, ap[0])) / LAMBDA[(r["sys"], r["freq"])])
        by_key[key].append(frac - round(frac))

    bias = {}
    mad_map = {}
    for key, vals in by_key.items():
        if len(vals) >= args.min_epochs:
            b = circular_median(vals)
            bias[key] = b
            mad_map[key] = float(np.median(np.abs(np.asarray(vals) - b)))
    print("pairs with bias estimate: %d / %d" % (len(bias), len(by_key)))

    # Pass 2: fixed phase and validity.
    fields = list(rows[0].keys())
    for extra in ("fix_valid", "dd_phase_fixed", "amb_bias", "n_int", "fix_residual",
                  "bias_mad", "sigma_phase_fixed", "ratio"):
        if extra not in fields:
            fields.append(extra)
    n_fix = n_fixed_epoch_rows = 0
    out_rows = []
    for r in rows:
        sow = int(round((float(r["t_gps"]) - GPS_EPOCH_UNIX) % 604800.0))
        key = (r["sys"], r["freq"], r["ref_sat"], r["sat"])
        r["fix_valid"] = 0
        r["dd_phase_fixed"] = r["dd_phase"]
        r["amb_bias"] = 0.0
        r["n_int"] = 0
        r["fix_residual"] = 0.0
        r["bias_mad"] = 0.0
        r["sigma_phase_fixed"] = 0.0
        r["ratio"] = 0.0
        ap = antenna_position(sow)
        if ap is not None and sow in ins:
            p_ant, status, ratio = ap
            r["ratio"] = ratio
            geom = dd_geom(r, p_ant)
            lam = LAMBDA[(r["sys"], r["freq"])]
            n_float = (float(r["dd_phase"]) - geom) / lam
            b = bias.get(key, 0.0)
            mad = mad_map.get(key, 1e9)
            n_int = int(round(n_float - b))
            phase_fixed = float(r["dd_phase"]) - lam * (n_int + b)
            residual = phase_fixed - geom
            sigma = min(args.sigma_ceil, max(args.sigma_floor, args.mad_k * mad * lam))
            r["amb_bias"] = b
            r["bias_mad"] = mad
            r["sigma_phase_fixed"] = sigma
            r["n_int"] = n_int
            r["dd_phase_fixed"] = phase_fixed
            r["fix_residual"] = residual
            if (key in bias and mad <= args.max_mad and status == "Fixed"
                    and not int(r.get("slip", 0))
                    and not int(r.get("ref_change", 0)) and abs(residual) <= args.gate):
                r["fix_valid"] = 1
                n_fix += 1
                n_fixed_epoch_rows += 1
        out_rows.append(r)

    with open(args.out_csv, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(out_rows)

    epochs = len({int(float(r["t_gps"])) for r in rows})
    summary = {
        "dd_csv": args.dd_csv,
        "ins": args.ins,
        "out_csv": args.out_csv,
        "n_rows": len(rows),
        "n_epochs": epochs,
        "n_pairs": len(by_key),
        "n_pairs_with_bias": len(bias),
        "n_fixed_rows": n_fix,
        "fixed_row_fraction": n_fix / len(rows) if rows else 0.0,
        "gate_m": args.gate,
        "mad_k": args.mad_k,
        "max_mad": args.max_mad,
        "sigma_floor": args.sigma_floor,
        "sigma_ceil": args.sigma_ceil,
        "lever": lever.tolist(),
        "base_ecef": base.tolist(),
    }
    if args.summary:
        with open(args.summary, "w") as f:
            json.dump(summary, f, indent=2)
    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
