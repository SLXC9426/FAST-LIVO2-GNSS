#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Print the text of a .pptx, slide by slide (for grounding written material).

Uses python-pptx when available; otherwise falls back to reading the slide XML
straight from the zip, so the tool works without extra dependencies.

Usage: extract_pptx.py <file.pptx> [--notes]
"""
import re
import sys
import zipfile


def via_zip(path):
    out = []
    with zipfile.ZipFile(path) as z:
        slides = sorted(
            (n for n in z.namelist() if re.match(r"ppt/slides/slide\d+\.xml$", n)),
            key=lambda n: int(re.search(r"(\d+)", n.split("/")[-1]).group(1)))
        for n in slides:
            xml = z.read(n).decode("utf-8", "ignore")
            texts = re.findall(r"<a:t>([^<]*)</a:t>", xml)
            out.append((n, texts))
    return out


def via_pptx(path, want_notes):
    from pptx import Presentation
    prs = Presentation(path)
    out = []
    for i, slide in enumerate(prs.slides, 1):
        texts = []
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    line = "".join(r.text for r in para.runs).strip()
                    if line:
                        texts.append(line)
            if shape.has_table:
                for row in shape.table.rows:
                    texts.append(" | ".join(c.text.strip() for c in row.cells))
        if want_notes and slide.has_notes_slide:
            nt = slide.notes_slide.notes_text_frame.text.strip()
            if nt:
                texts.append("[NOTE] " + nt.replace("\n", " "))
        out.append(("slide %d" % i, texts))
    return out


def main():
    path = sys.argv[1]
    want_notes = "--notes" in sys.argv
    try:
        slides = via_pptx(path, want_notes)
    except Exception as e:
        print("(python-pptx unavailable: %s; falling back to raw XML)\n" % e)
        slides = via_zip(path)
    for name, texts in slides:
        print("=== %s ===" % name)
        for t in texts:
            print(t)
        print()


if __name__ == "__main__":
    main()
