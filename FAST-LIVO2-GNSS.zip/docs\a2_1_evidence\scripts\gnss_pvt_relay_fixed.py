#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""M0.4: GNSS PVT relay node.

Subscribes /ublox_driver/receiver_pvt (gnss_comm/GnssPVTSolnMsg) and publishes:
  1. /gnss/vel_enhanced  (TwistWithCovarianceStamped) — ECEF velocity
     (frontend gnss_vel_cbk interprets Twist.linear as ECEF; NED->ECEF here)
  2. /gnss/fix_enhanced  (sensor_msgs/NavSatFix) — position + quality-mapped
     status (project fix-type codes: 5=RTK_FIXED, 2=PHASE_FLOAT, 0=SINGLE)
     + position_covariance from h_acc/v_acc (frontend uses cov when
     std in [0.3, 100] m, else falls back to the fix-type table)

All new topics; the frontend config chooses original vs enhanced — baseline
runs are unaffected by this node's existence.
"""
import math
import rospy
from gnss_comm.msg import GnssPVTSolnMsg
from fast_livo.msg import GnssQuality
from sensor_msgs.msg import NavSatFix, NavSatStatus
from geometry_msgs.msg import TwistWithCovarianceStamped

# project fix-type codes (gnss_processing.h): 5=RTK_FIXED 4=PHASE_FIX 2=FLOAT 0=SINGLE
CARR_SOLN_TO_STATUS = {2: 5, 1: 2, 0: 0}
COV_FLOOR = 0.3   # frontend only accepts std in [0.3, 100] m
COV_CEIL = 100.0


def ned_to_ecef(lat_deg, lon_deg, vn, ve, vd):
    lat = math.radians(lat_deg)
    lon = math.radians(lon_deg)
    sl, cl = math.sin(lon), math.cos(lon)
    sp, cp = math.sin(lat), math.cos(lat)
    # ENU unit vectors expressed in ECEF
    e = (-sl, cl, 0.0)
    n = (-sp * cl, -sp * sl, cp)
    u = (cp * cl, cp * sl, sp)
    return (ve * e[0] + vn * n[0] - vd * u[0],
            ve * e[1] + vn * n[1] - vd * u[1],
            ve * e[2] + vn * n[2] - vd * u[2])


def clamp_cov(sigma):
    s = min(max(sigma, COV_FLOOR), COV_CEIL)
    return s * s


def pvt_cbk(msg):
    # PVT has no ROS header; convert GPS week/tow to Unix (leap seconds 18).
    now = rospy.Time.from_sec(315964800.0 + msg.time.week * 604800.0 + msg.time.tow - 18.0)

    # --- ECEF velocity (NED -> ECEF with this epoch's geodetic position) ---
    vx, vy, vz = ned_to_ecef(msg.latitude, msg.longitude,
                             msg.vel_n, msg.vel_e, msg.vel_d)
    tw = TwistWithCovarianceStamped()
    tw.header.stamp = now
    tw.header.frame_id = 'ecef'
    tw.twist.twist.linear.x = vx
    tw.twist.twist.linear.y = vy
    tw.twist.twist.linear.z = vz
    va = max(msg.vel_acc, 0.05)
    tw.twist.covariance[0] = va * va
    tw.twist.covariance[7] = va * va
    tw.twist.covariance[14] = va * va
    pub_vel.publish(tw)

    # --- enhanced NavSatFix ---
    fix = NavSatFix()
    fix.header.stamp = now
    fix.status.status = CARR_SOLN_TO_STATUS.get(msg.carr_soln, 0)
    fix.status.service = NavSatStatus.SERVICE_GPS
    fix.latitude = msg.latitude
    fix.longitude = msg.longitude
    fix.altitude = msg.altitude
    ha = max(msg.h_acc, 0.0)
    vv = max(msg.v_acc, 0.0)
    fix.position_covariance[0] = clamp_cov(ha)
    fix.position_covariance[4] = clamp_cov(ha)
    fix.position_covariance[8] = clamp_cov(vv)
    fix.position_covariance_type = NavSatFix.COVARIANCE_TYPE_DIAGONAL_KNOWN
    pub_fix.publish(fix)

    # --- A2.1: quality record of the SAME solution ---
    # Same header.stamp as the fix so the mapper can match exactly; never
    # approximate-match an adjacent epoch. The source message carries h_acc in
    # metres; keep millimetres here (accuracy estimate, not a sigma).
    q = GnssQuality()
    q.header.stamp = now
    q.header.frame_id = fix.header.frame_id
    q.num_sv = msg.num_sv
    q.p_dop = msg.p_dop
    q.carr_soln = msg.carr_soln
    q.fix_type = msg.fix_type
    q.h_acc_mm = int(round(max(msg.h_acc, 0.0) * 1000.0))
    q.v_acc_mm = int(round(max(msg.v_acc, 0.0) * 1000.0))
    q.valid = bool(msg.valid_fix)
    q.has_p_dop = msg.p_dop > 0.0
    q.has_h_acc = msg.h_acc > 0.0
    q.has_v_acc = msg.v_acc > 0.0
    pub_quality.publish(q)


def main():
    global pub_vel, pub_fix, pub_quality
    rospy.init_node('gnss_pvt_relay')
    sub_topic = rospy.get_param('~sub_topic', '/ublox_driver/receiver_pvt')
    vel_topic = rospy.get_param('~vel_topic', '/gnss/vel_enhanced')
    fix_topic = rospy.get_param('~fix_topic', '/gnss/fix_enhanced')
    quality_topic = rospy.get_param('~quality_topic', '/gnss/quality')
    pub_vel = rospy.Publisher(vel_topic, TwistWithCovarianceStamped, queue_size=50)
    pub_fix = rospy.Publisher(fix_topic, NavSatFix, queue_size=50)
    pub_quality = rospy.Publisher(quality_topic, GnssQuality, queue_size=50)
    rospy.Subscriber(sub_topic, GnssPVTSolnMsg, pvt_cbk, queue_size=50)
    rospy.loginfo('[gnss_pvt_relay] %s -> %s + %s', sub_topic, vel_topic, fix_topic)
    rospy.spin()


if __name__ == '__main__':
    main()
