"""Causal antenna-stability diagnostic. Never authorizes an absolute anchor."""
from dataclasses import dataclass,asdict
import math
import numpy as np

@dataclass(frozen=True)
class Params:
    window_sec:float=20.
    min_coverage:float=.9
    max_gap_sec:float=2.5
    max_lio_age_sec:float=2.5
    max_lio_gap_sec:float=2.5
    min_fixed_ratio:float=.9
    max_p95_m:float=.3
    max_deviation_m:float=.5
    max_net_m:float=1.5
    max_trend_m:float=1.2
    static_speed_mps:float=.03
    confirm_sec:float=2.

def diagnose(lio,observations,eligible,params=Params()):
    values=asdict(params)
    if any(not math.isfinite(v) or v<=0 for v in values.values()) or params.min_coverage>1 or params.min_fixed_ratio>1:
        raise ValueError('invalid diagnostic parameters')
    lio=np.asarray(lio,dtype=float);obs=np.asarray(observations,dtype=float);flags=np.asarray(eligible)
    for a in [lio,obs]:
        if a.ndim!=2 or a.shape[1]<4 or not np.isfinite(a[:,:4]).all() or np.any(np.diff(a[:,0])<=0):
            raise ValueError('invalid/nonmonotonic diagnostic input')
    if len(flags)!=len(obs) or flags.dtype!=np.bool_:raise ValueError('eligible mask must contain one boolean per observation')
    rows=[];last_state=None;confirmed_from=None;obs_start=None
    for i,z in enumerate(obs):
        t=z[0];lo=t-params.window_sec;metrics={};state='WAIT';reason='insufficient_duration'
        if i==0 or t-obs[i-1,0]>params.max_gap_sec:obs_start=t;confirmed_from=None
        prefix=lio[lio[:,0]<=t]
        fresh=len(prefix)>0 and t-prefix[-1,0]<=params.max_lio_age_sec
        good=False
        if not fresh:state='UNAVAILABLE';reason='lio_stale_or_missing'
        elif len(prefix)>=2:
            static_start=prefix[-1,0]
            for j in range(len(prefix)-1,0,-1):
                dt=prefix[j,0]-prefix[j-1,0]
                speed=np.linalg.norm(prefix[j,1:4]-prefix[j-1,1:4])/dt
                if dt>params.max_lio_gap_sec or speed>params.static_speed_mps:break
                static_start=prefix[j-1,0]
            metrics['lio_age']=float(t-prefix[-1,0]);metrics['stationary_duration']=float(t-static_start)
            if t-max(static_start,obs_start)>=params.window_sec-1e-7:
                # Clip supported intervals to the window. An endpoint need not
                # fall exactly on lo; no future sample is used.
                covered=0.;fixed_time=0.;largest=0.
                for j in range(max(1,int(np.searchsorted(obs[:i+1,0],lo))),i+1):
                    gap=obs[j,0]-obs[j-1,0];duration=max(0.,min(t,obs[j,0])-max(lo,obs[j-1,0]))
                    largest=max(largest,gap)
                    if gap<=params.max_gap_sec:
                        covered+=duration
                        if flags[j-1] and flags[j]:fixed_time+=duration
                ratio=fixed_time/covered if covered else 0.
                select=(obs[:i+1,0]>=lo)&flags[:i+1]
                p=obs[:i+1][select];coverage=covered/params.window_sec
                metrics.update(coverage=float(coverage),fixed_ratio=float(ratio),max_gap=float(largest))
                good=coverage>=params.min_coverage and largest<=params.max_gap_sec and ratio>=params.min_fixed_ratio and len(p)>=3
                reason='coverage_quality_or_dispersion'
                if len(p)>=3:
                    dev=np.linalg.norm(p[:,1:4]-np.median(p[:,1:4],axis=0),axis=1);dt=p[:,0]-p[:,0].mean()
                    trend=float(np.linalg.norm(dt@(p[:,1:4]-p[:,1:4].mean(0))/(dt@dt))*(p[-1,0]-p[0,0]))
                    metrics.update(p95=float(np.percentile(dev,95)),maximum=float(dev.max()),net=float(np.linalg.norm(p[-1,1:4]-p[0,1:4])),trend=trend)
                    good=good and all(math.isfinite(metrics[k]) and metrics[k]<=bound for k,bound in [('p95',params.max_p95_m),('maximum',params.max_deviation_m),('net',params.max_net_m),('trend',params.max_trend_m)])
        if good:
            if confirmed_from is None:confirmed_from=t
            if t-confirmed_from>=params.confirm_sec-1e-7:state='STABLE_DIAGNOSTIC';reason='internal_stability_only'
        else:confirmed_from=None
        if state!=last_state:
            rows.append(dict(stamp=float(t),state=state,reason=reason,metrics=metrics));last_state=state
    return rows
