#!/usr/bin/env bash
# ============================================================================
# run_urban01.sh - end-to-end evaluation of the three FAST-LIVO2 improvements
# on GREAT-Dataset urban-01 (6 modes).
#
# Modes:
#   baseline      - all improvements OFF (original behaviour)
#   occlusion     - P1: occlusion-aware LIO/VIO + robust kernels
#   dynamic       - P3: dynamic-object removal
#   graph         - P2: sliding-window factor-graph backend
#   improved      - P1+P2+P3
#   improved_gnss - P1+P2+P3 + GNSS tight coupling (needs GNSS/gnss.pos)
#
# Usage (Ubuntu, after catkin_make):
#   DATA=/path/to/urban-01 ./scripts/eval/run_urban01.sh            # all modes
#   DATA=/path/to/urban-01 MODES="baseline improved" ./scripts/eval/run_urban01.sh
#
# Requirements: roslaunch, rosbag, python3 (numpy, matplotlib), evo (optional)
# ============================================================================
set -e
ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
DATA="${DATA:-$HOME/datasets/urban-01}"
MODES="${MODES:-baseline occlusion dynamic graph improved improved_gnss}"
BAG="$DATA/urban-01.bag"
REF="$DATA/urban-01_reference.tum"
START="${START:--s 5}"     # skip the initial stationary part (tune per bag)
DUR="${DUR:-}"              # e.g. -u 400 to limit the playback length

# ---------------------------------------------------------------- bag + GT
if [ ! -f "$BAG" ]; then
  echo "== converting raw data to bag =="
  python3 "$ROOT/Log/GREAT/rawdata2bag_great.py" raw_synced "$DATA" -n urban-01 --imu tactical
  # NOTE: run the same command with --imu mems if the tactical file is absent.
fi
if [ ! -f "$REF" ]; then
  echo "== converting ground truth =="
  GT_FILE="$DATA/Reference_Solution/groundtruth.txt"
  [ -f "$GT_FILE" ] || GT_FILE="$DATA/groundtruth.txt"
  python3 "$ROOT/Log/GREAT/groundtruth2tum.py" "$GT_FILE" "$REF"
fi

# ---------------------------------------------------------------- run modes
for mode in $MODES; do
  echo ""
  echo "########## mode = $mode ##########"
  # start the mapping node (config chosen by the launch arg `mode:=...`)
  roslaunch fast_livo mapping_great_urban01.launch mode:=$mode rviz:=false &
  LPID=$!
  sleep 3
  rosbag play $START $DUR "$BAG" --clock
  wait $LPID || true

  # ------------------------------------------------------------ evaluation
  OUT="$ROOT/Log/eval/urban01_$mode"
  mkdir -p "$OUT"
  SEQ="great_urban01_$mode"
  FRONT="$ROOT/Log/result/$SEQ.txt"

  if [ -f "$FRONT" ] && [ -f "$REF" ]; then
    python3 "$ROOT/scripts/eval/eval_occlusion.py" \
        --gt "$REF" --base "$FRONT" --imp "$FRONT" --out "$OUT" 2>/dev/null || \
    python3 - "$REF" "$FRONT" "$OUT" <<'EOF'
import sys, os
import numpy as np

def load_tum(p):
    d = np.loadtxt(p)
    return d[:, 0], d[:, 1:4]

def interp(rt, rp, qt):
    return np.array([np.interp(qt, rt, rp[:, k]) for k in range(3)]).T

def umeyama(est, gt):
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg

rt, rp = load_tum(sys.argv[1])
ft, fp = load_tum(sys.argv[2])
t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
m = (rt >= t0) & (rt <= t1)
e = np.linalg.norm(umeyama(interp(ft, fp, rt[m]), rp[m]) - rp[m], axis=1)
rpe = np.linalg.norm(np.diff(interp(ft, fp, rt[m]), axis=0) - np.diff(rp[m], axis=0), axis=1)
os.makedirs(sys.argv[3], exist_ok=True)
with open(os.path.join(sys.argv[3], "metrics.txt"), "w") as f:
    f.write(f"ape_rmse {np.sqrt(np.mean(e**2)):.4f}\n")
    f.write(f"ape_mean {np.mean(e):.4f}\n")
    f.write(f"ape_max {np.max(e):.4f}\n")
    f.write(f"rpe_rmse {np.sqrt(np.mean(rpe**2)):.4f}\n")
print(f"  APE RMSE {np.sqrt(np.mean(e**2))*100:.1f} cm | mean {np.mean(e)*100:.1f} cm | max {np.max(e)*100:.1f} cm")
EOF
  fi

  # P2: graph trajectory + latency
  if [ -f "$ROOT/Log/result/$SEQ"'_graph.txt' ]; then
    python3 "$ROOT/scripts/eval/eval_graph.py" \
        --gt "$REF" \
        --front "$FRONT" \
        --graph "$ROOT/Log/result/$SEQ"'_graph.txt' \
        --latency "$ROOT/Log/result/$SEQ"'_latency.csv' \
        --out "$OUT" || true
  fi
  # P3: dynamic statistics
  if [ -f "$ROOT/Log/result/$SEQ"'_dyn.csv' ]; then
    python3 "$ROOT/scripts/eval/eval_dynamic.py" \
        --dyn "$ROOT/Log/result/$SEQ"'_dyn.csv' --out "$OUT" || true
  fi
done

# ------------------------------------------------------------ summary table
echo ""
echo "==================== summary ===================="
printf "%-18s %10s %10s %10s %10s\n" "mode" "APE_RMSE" "APE_mean" "APE_max" "RPE"
for mode in $MODES; do
  M="$ROOT/Log/eval/urban01_$mode/metrics.txt"
  if [ -f "$M" ]; then
    read -r a < <(grep ape_rmse "$M" | awk '{print $2}')
    read -r b < <(grep ape_mean "$M" | awk '{print $2}')
    read -r c < <(grep ape_max "$M" | awk '{print $2}')
    read -r d < <(grep rpe_rmse "$M" | awk '{print $2}')
    printf "%-18s %10.2f %10.2f %10.2f %10.2f\n" "$mode" "$a" "$b" "$c" "$d"
  else
    printf "%-18s %10s\n" "$mode" "n/a"
  fi
done
