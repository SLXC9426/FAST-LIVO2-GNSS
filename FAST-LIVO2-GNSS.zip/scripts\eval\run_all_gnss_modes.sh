#!/bin/bash
# Run the single-RTK baseline (GNSS_ONLY) full-length for campus-01/02.
# Output (evaluation results) also goes to /home/slxc9426/modes_summary.txt.
#
# The GNSS+IMU mode also exists in the estimator (SLAM_MODE::GNSS_IMU) but is not
# part of the reported results: the doc compares 单 RTK / 纯 LIVO / LIVO+RTK.
export LANG=C.UTF-8
HERE="$(dirname "$0")"
G=$HOME/datasets/GREAT
OUT=$HOME/modes_summary.txt
: > "$OUT"

bash "$HERE/kill_ros.sh"

run() {
  echo "=== $1 / $2 ===" | tee -a "$OUT"
  bash "$HERE/run_gnss_modes.sh" "$1" "$2" "$3" "$4" 2>&1 | tee -a "$OUT"
}

run campus01 gnssonly c01_final_gnssonly "$G/campus01_rtk1hz.bag"
run campus02 gnssonly c02_final_gnssonly "$G/gnss_c02_trim.bag"
echo ALL_MODES_DONE | tee -a "$OUT"
