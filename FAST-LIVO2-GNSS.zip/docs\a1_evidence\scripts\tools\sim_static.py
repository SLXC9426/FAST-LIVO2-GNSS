#!/usr/bin/env python3
"""Count static-detector members for the A0/A1 windows.

Mirrors global_pose_graph.cpp: LIO speed per keyframe, median over +-detect_win,
threshold 0.20 m/s, runs joined when the gap is <= 2 keyframes. Used only to
explain why rtk= is smaller than the keyframe count; it does not replace the
node's own detector.
"""
import argparse

import numpy as np

ROOT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main"
LIVO = ROOT + "/03_实验记录/对比实验/gv1/oracle/gv1_campus0{}_livo_r1_base.tum"


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("campus", choices=["c01", "c02"])
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--dur", type=float, default=0.0)
    args = ap.parse_args()

    d = np.loadtxt(LIVO.format(args.campus[-1]))
    t, p = d[:, 0], d[:, 1:4]
    t0 = t[0] + args.start
    dur = args.dur or (t[-1] - t[0] - args.start)
    sel = (t >= t0) & (t <= t0 + dur)
    t, p = t[sel], p[sel]
    n = len(t)
    speed = np.zeros(n)
    dt = np.diff(t)
    speed[1:] = np.linalg.norm(np.diff(p, axis=0), axis=1) / np.maximum(dt, 1e-9)
    stat = np.zeros(n, bool)
    for i in range(n):
        a, b = max(0, i - 3), min(n - 1, i + 3)
        stat[i] = np.median(speed[a:b + 1]) < 0.20

    runs = []
    i = 0
    while i < n:
        if not stat[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and stat[j + 1]:
            j += 1
        if runs and i - runs[-1][1] <= 2:
            runs[-1] = (runs[-1][0], j)
        else:
            runs.append((i, j))
        i = j + 1
    member = np.zeros(n, bool)
    for a, b in runs:
        member[a:b + 1] = True
    print(f"{args.campus}: kf={n} static_members={int(member.sum())} "
          f"moving={int((~member).sum())} runs={[(a, b) for a, b in runs]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
