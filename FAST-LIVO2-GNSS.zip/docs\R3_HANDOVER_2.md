# R3 交接文档 2（续轮：NEXT_STEPS 的 P0 与 P1 已处理完毕）

> 面向"接手继续做的人（或下一个会话的我）"。记录 `R3_NEXT_STEPS.md` 里 P0-1/P0-2/P1-1/P1-2 四项的
> 执行结果、量出的数字、新增的资产、以及哪些坑已经踩过。技术细节一律以 `docs/EVAL_PROTOCOL.md`
> §13（P0-1/P0-2）、§14（P1-2）、§15（P1-1，含四轮第三层追查）为准，本文只做索引与状态。
> 上一轮的交接见 `docs/R3_HANDOVER.md`；下一轮的计划见 `docs/R3_NEXT_STEPS.md`（已随本轮结果更新）。

## 1. 一句话状态

`R3_NEXT_STEPS` 的 P0 与 P1 **全部处理完毕**：P0-1（全程噪声地板）✅、P0-2（时间一致性护栏，按可落地形态）✅、
P1-2（门控 sigma 标定，**否定结果**）✅、P1-1（后端精度诊断，主因修复 4× + 残余逐层归因）✅。
**7 个提交、7 个标签**，master 干净（仅无关的未跟踪脚本 `scripts/dev/extract_pptx.py`）。
阶段 6（是否进 L3）仍未决策；P1-3（有界物理漂移先验）是下一个设计优先的大项。

| 项 | 内容 | 状态 | 提交 | 标签 |
|---|---|---|---|---|
| P0-1 | 全程噪声地板实测（livo/gnss 各 3 样本） | ✅ | `2be4a1c` | `r3-p0-floor-guards` |
| P0-2 | 时间一致性护栏（自检 + 运行级门禁，各自证伪） | ✅ | `2be4a1c` | 同上 |
| P1-2 | 门控 sigma 标定 A/B（**否定**：门限不是限幅项） | ✅ | `9cd83af` | `r3-p1-2-gate-sigma` |
| P1-1 r1 | 后端漂移主因定位（odom/preint 平衡）+ 4× 修复 | ✅ | `1cac195` | `r3-p1-1-backend-drift` |
| P1-1 r2 | 第三层画像 + 先验符号修复 + 结构性事实 | ✅ | `6fe4f98`/`b2bbbdf` | `r3-p1-1-third-layer`/`r3-p1-1-prior-sign` |
| P1-1 r3 | 新鲜分歧归因（滤波器速度超前 ~0.3 m/s） | ✅ | `ed3f791` | `r3-p1-1-attribution` |
| P1-1 r4 | v_ref 自洽性探针（边际，默认关）+ 收尾 | ✅ | `0788854` | `r3-p1-1-vref-probe` |

## 2. 必须随结果一起引用的结论（防误用清单）

1. **全程噪声地板实测替换了协议 §2(c) 的跨编译估计**：c01 **livo 1.13 m(3D)/0.23 m(2D)**、
   **gnss 0.66 m(3D)/0.34 m(2D)**（同二进制，各 3 样本）。据此：
   **c01 livo 的 +0.49 m（WP11）不可判定**；已记录的 `c01_final_gnss` vs `c01_final_livo` 之差（0.34/0.12 m）
   也在地板内，**不能用它谈"融合边际收益缩小"**（§13.3）。
2. **n=2 的极差是地板的下界**：gnss 臂配对给 0.065 m(2D)，三次才是 0.337 m；但 200 s 段同配置跨会话三次只差
   0.013 m ⇒ 是样本数不足，不是普遍会话效应（§13.3）。**200 s 段的地板同样被配对低估**：同配置干净运行 10 次
   极差 **0.136 m**（§8.2 配对口径 0.095，§14.6）。
3. **门控 sigma 不是限幅项**（P1-2，否定）：`gnss/sigma_fixed` 1.2→2.0/2.5 四个统计量一致偏坏，
   融合对纯 LIVO 的边际收益从 +0.027 变 −0.035/−0.018 m；机制：放宽后多收的是**对齐后暂态段（65–130 s）
   残差最大**的历元。**限幅项是每历元增益（~5e-4，由先验决定）** ⇒ 对应 P1-3/A3-2（§14）。
   **WP10b 的"整体调大默认值"在 c01 与 c02 上都被否定。**
4. **两个否定结论必须随 P1-2 引用**：① 完整 OOSM 不做（时间错配实测 0）；② 速度观测无收益（增益 0.10）——
   这两条是上一轮的，本轮再追加：③ **门控 sigma 不是限幅项**；④ **v_ref 自洽性探针非决定性**（170 vs 185，默认关）。
5. **fg 线的前端数字不能与主配置混比**：`thread_en: true` 使前端随线程时序波动（2D 0.69–0.97，10 次 n 均 3945，§15.6）。
6. **重建同源码得到逐字节相同的 `lib*.so`** ⇒ 跨编译差异只可能来自源码改动（§13.3）。

## 3. 后端精度线（P1-1）的最终地图

后端（FG 线）APE 711 cm vs 前端 103 cm 的完整归因链（§15）：

| 层级 | 内容 | 状态 |
|---|---|---|
| 主因 | **odom/preint 权重平衡**：预积分 σ 地板（0.05 m）与里程计 σ 同权，系统性分歧（每链 \|ev\| 0.066 m/s）被滑窗钉住逐链累积成 ~0.3 m/s 漂移 | **已修复**：odom 刚 10 倍 → 711→185/180 cm（`great_campus01_fg_stiffodom.yaml`，推荐臂） |
| 次因 | 边缘化先验线性项**符号反了**（prior_b_ 应为 −bmarg） | **已修复**（代数正确；实数据中性，bmarg≈0 时不可见） |
| 残余 r1 | 沿轨迹 ~2 m、加速段（30–44 s）以 ~0.1-0.15 m/链获得、巡航冻结 | 已画像（§15.5） |
| 残余 r2 | 新鲜节点**只被一条里程计因子约束** ⇒ 量测 100% 获胜、后端对最新节点无平滑作用；后端的价值=带进 GNSS 绝对信息 | 已确认（§15.6） |
| 残余 r3 | 加速段新鲜分歧 ~0.13 m/链 = **滤波器速度超前位置增量 ~0.3 m/s**（v_ref 与位置增量不自洽）× dt | **已归因**（§15.6 三速度表） |
| 探针 | v_ref 改位置隐含速度：基线 5 → 170.5（边际），10 → 201（反噬） | **非决定性，默认关** |
| 残余 | ~170 vs 前端 ~100 cm | **接受为未完全解释**，证据链在 §15.5/15.6 |

排除清单（每个都有实验）：窗口大小、边缘化、旋转（恒 0.45°）、收敛（iter 40）、速度通道权重、
GNSS σ 放开（更差）、bag 的 IMU 数据（独立复算一致）。

## 4. 新增的可复用资产

**代码**（全部默认=历史行为，零影响除非显式开启）：
- `factor_graph/diag_link_every_n`（逐链因子诊断，默认 0）与 `[FG-LINK]/[FG-DP]/[FG-DEC]` 三种输出；
- `factor_graph/v_prior_weight`（默认 100=历史 1e2；A/b 与 stateCost 两处同步）；
- `factor_graph/v_ref_pos_frames`（默认 0=滤波器速度）+ LIVMapper 的 (stamp, position) 历史队列；
- **边缘化先验符号修复**（`prior_b_ = −bmarg`，factor_graph.cpp，含推导注释）；
- `factor_graph_selftest` 新增 **test 5**（离群量测不得行走锚点；现 20 项）；
- `test/gnss_processing_selftest.cpp`（新目标 `gnss_processing_selftest`：噪声表绝对尺度 + L2 同帧，6 节）。

**配置**（`scripts/make_gate_configs.py` 与 `scripts/make_fg_diag_configs.py` 可再生）：
- `great_campus01_gate20/25.yaml`（P1-2 两臂）；
- `great_campus01_fg_stiffodom.yaml`（**推荐臂**）、`_w5`、`_sodom2`、`_sodom_gnss45`、`_sodom_nognss(_diag)`、
  `_stiffodom_it40`、`_stiffodom_vp1e4`、`_stiffodom_vref5/10`（P1-1 判别/探针臂）。

**脚本**：
- `scripts/eval/full_floor_run.sh` + `floor_stats.py`（全程噪声地板：跑 + 统计）；
- `scripts/eval/gnss_dt_stats.py --check`（时间一致性门禁，带退出码）；
- `p0_1_floor/`、`p1_2_gate/`、`p1_1_backend/`（三个证据目录，各带 README 与原始日志，28 MB 内）。

**记账**：本轮 11 次运行全部追加进 `Log/result/registry.csv`（4 次全程地板 + 1 次证伪 + 14 次段运行）。
**注意**：`wp2guard_falsify` 与 `p12_guard_*` 等**证伪/注入运行**的 cfg_hash 是正常的（坏的是代码或输入），
不可当基线引用（§13.4、§14.5）。

## 5. 待办（下一步，按建议优先级）

1. **P1-3 有界物理漂移先验**（前端融合收益的限幅项，本轮 P1-2 的结论所指）：v_ref 不取在线新息尺度，
   而取有界物理漂移模型；需与 c02 护栏一起设计（inflate_prior 的教训：循环论证在 c02 有害）。
   判据：c01 0–200 s 的 2D 改善须超过该臂实测极差（0.106 m，n=4）；c02 保持 WITHHELD 不劣化。
2. **后端第三层残余**（~170 vs 前端 ~100 cm，诊断路径不影响任何已记录 APE）：入口 = 逐链打印
   `dp_imu/Δp_front/v_k·dt` 分解（`[FG-DEC]` 已有载体，`diag_link_every_n` 开启即得）+ GT 对齐归因
   （**必须先做框架对齐**，前端与 GT 相差 ~21.9° 偏航，§15.6）。
3. **P2-1 阶段 6 决策门**：把 0.25 m 差距分解到四个来源（LIO 漂移 / A3 常量偏移 / 拟合残差 0.54 m / WP7 少修正）
   后决定是否进 L3。注意判据要用 §14.6 修正后的 200 s 地板（0.136 m）。
4. **P3 小项**：延迟插桩时间基准（§10.5）、`propagateStateToTime` 协方差索引（§11.3）、三处 BOM。
5. **不做**（沿用改动方案 §8 + 本轮追加）：完整 OOSM、速度观测当精度手段、**整体调大噪声表默认值**
   （c01+c02 都否定）、WP11 的可判定性追问（地板所限）。

## 6. 环境与流程坑（本轮新增/再次验证的）

1. **cmd 里没有 heredoc、tail、sleep、head**；`\$` 会被吃掉或原样传递——**凡带变量/管道的 WSL 命令一律写成
   脚本文件再执行**（本轮因此浪费了至少六次调用）。
2. **`''` 从 cmd 直接传给 wsl 会变成字面量两个引号** → `gnss_topic: "''"` → ROS 空名异常、节点秒退
   （`p11_fg_diag` 第一跑即此）。传空参数必须经 `bash -lc "..."` 或脚本文件。
3. **eval_graph.py 用相似变换（含尺度）对齐**，与 `eval_unified.py` 的 SE(3) 口径**不可互比**。
4. **GT 归因必须先框架对齐**：前端与 GT 相差 ~21.9° 偏航，未对齐的逐链向量差被框架旋转主导
   （0.44 m 假误差 = 1.07 m × 0.41 rad）；对齐偏航用逐链位移方向的**中位差**最稳健（直接 Procrustes 会因
   两文件行数不同而配错行，yaw 拟出 157° 的垃圾值）。
5. **注入对照必须落在"干净臂接受的历元"**（§12.2 教训再次验证）：+30 m@idx100 落在无论如何都拒的区间，
   无判别力；补的 +30 m@idx141（干净臂接受）才把 γ 从"无拒绝"抬到 587.6 被拒。
6. **`config/` 的派生臂配置一律用生成脚本**（UTF-8、LF），不要用 PowerShell Set-Content（历史上把中文注释
   写成非 UTF-8 导致 roslaunch 静默失败的坑）。
7. **同步脚本的失败上报是好的**：编译错误会打印并返回非零（本轮注释少写 `//` 被它当场抓住）。

## 7. 怎么复算（速查）

```bash
# 0) 同步 + 编译 + 三个自检（20 项因子图 / 6 节 GnssProcess / ENU 往返）
wsl -d Ubuntu-20.04 -e bash <repo>/scripts/dev/sync_to_wsl.sh
wsl -d Ubuntu-20.04 -e bash <parent>/p0_1_floor/run_selftests.sh

# 1) P0-1 全程噪声地板（约 50 min）+ 地板表
wsl -d Ubuntu-20.04 -e bash <repo>/scripts/eval/full_floor_run.sh campus01 "livo gnss" 2 <out.txt>
python3 <repo>/scripts/eval/floor_stats.py campus01_floor

# 2) P0-2 时间一致性门禁（秒级）
python3 <repo>/scripts/eval/gnss_dt_stats.py --check <gnss_poses.txt>

# 3) P1-2 门控 sigma A/B（约 30 min）+ 护栏（约 12 min）
wsl -d Ubuntu-20.04 -e bash <parent>/p1_2_gate/run_ab.sh
wsl -d Ubuntu-20.04 -e bash <parent>/p1_2_gate/run_guard.sh great_campus01
wsl -d Ubuntu-20.04 -e bash <parent>/p1_2_gate/run_followup.sh

# 4) P1-1 后端判别臂（约 25 min）+ 第三层归因（约 8 min）
wsl -d Ubuntu-20.04 -e bash <parent>/p1_1_backend/run_experiments.sh
wsl -d Ubuntu-20.04 -e bash <parent>/p1_1_backend/run_final.sh
wsl -d Ubuntu-20.04 -e bash <parent>/p1_1_backend/run_signfix.sh
wsl -d Ubuntu-20.04 -e bash <parent>/p1_1_backend/run_third.sh
python3 <parent>/p1_1_backend/dec_attr.py <seg log> <gt.tum> <front.tum>
```

## 8. 一句话提醒

本轮有**两个否定结论**（门控 sigma 不是限幅项；v_ref 探针非决定性）和**一个判据修正**
（全程地板 1.13/0.66 m、200 s 地板 0.136 m，均Replace了配对/跨编译的低估口径）——引用任何本轮数字时
必须带上这些限定，否则会被误用。后端推荐配置是 `great_campus01_fg_stiffodom.yaml`（odom 刚 10 倍），
其残余 ~80 cm 的证据链完整保存在协议 §15 与 `p1_1_backend/`。
