#!/usr/bin/env python3
"""Compare bag /imu_raw values against raw Tactical_imu_data.txt at same time."""
import rosbag
import numpy as np

# raw file
rows = []
with open("/home/slxc9426/datasets/GREAT/IMU/Tactical_imu_data.txt") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "ime" in line:
            continue
        rows.append([float(x) for x in line.split()])
a = np.array(rows)
OFFSET = 604800 * 2129 + 315964800 - 18
t_unix = a[:, 0] + OFFSET

b = rosbag.Bag("/home/slxc9426/datasets/GREAT/GREAT.bag")
n = 0
for topic, msg, t in b.read_messages(topics=["/imu_raw"], start_time=genpy.Time(t_unix[100]), end_time=genpy.Time(t_unix[100] + 0.02)):
    ts = msg.header.stamp.to_sec()
    i = np.argmin(np.abs(t_unix - ts))
    raw = a[i]
    print("t=%.6f raw: gyr=(%.4f,%.4f,%.4f) acc=(%.4f,%.4f,%.4f) | bag: gyr=(%.4f,%.4f,%.4f) acc=(%.4f,%.4f,%.4f)" %
          (ts, raw[1], raw[2], raw[3], raw[4], raw[5], raw[6],
           msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z,
           msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z))
    n += 1
    if n > 3:
        break
b.close()
