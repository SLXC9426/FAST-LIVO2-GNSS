#!/usr/bin/env python3
"""A2.3: what the class gate accepts/rejects, and at what cost.

For every epoch that reached the gate (decision factor or class_gated), compare
the RTK horizontal error against the reference truth:
  - anomaly  = RTK horizontal error > --anomaly (default 1.0 m)
  - rejected = decision == class_gated
Report rejection rate overall, anomaly recall, and the false-rejection rate on
epochs whose RTK error is small. Also break the RTK error distribution down by
quality class and by kept/rejected.
"""
import argparse
import csv
from collections import defaultdict

import numpy as np


def load_tum(path):
    t, p = [], []
    for line in open(path, errors="ignore"):
        s = line.split()
        if len(s) < 4:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
        except ValueError:
            continue
    order = np.argsort(t)
    return np.asarray(t)[order], np.asarray(p)[order]


def nearest(t, ts):
    if len(ts) == 0:
        return -1
    j = int(np.argmin(np.abs(ts - t)))
    return j if abs(ts[j] - t) <= 0.11 else -1


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--trace", required=True)
    ap.add_argument("--rtk", required=True, help="RTK fix TUM")
    ap.add_argument("--ref", required=True, help="reference TUM")
    ap.add_argument("--anomaly", type=float, default=1.0, help="m, horizontal")
    ap.add_argument("--good", type=float, default=0.5, help="m, horizontal")
    ap.add_argument("--debias", action="store_true",
                    help="remove the median ENU offset first; required on c02 "
                         "where the static-anchor bias (~4 m) dominates")
    args = ap.parse_args()

    tt, tp = load_tum(args.ref)
    rt, rp = load_tum(args.rtk)
    if args.debias:
        diffs = []
        for t, p in zip(rt, rp):
            k = nearest(t, tt)
            if k >= 0:
                diffs.append(p - tp[k])
        if diffs:
            b = np.median(np.asarray(diffs), axis=0)
            print(f"removed median ENU bias: {b[0]:.3f} {b[1]:.3f} {b[2]:.3f} m")
            rp = rp - b
    rows = list(csv.DictReader(open(args.trace, encoding="utf-8")))

    gated_decisions = {"class_gated", "innovation_gated"}
    decisions = defaultdict(int)
    for r in rows:
        decisions[r["decision"]] += 1

    eligible = rejected = 0
    anomaly_n = anomaly_rej = 0
    good_n = good_rej = 0
    by_class = defaultdict(lambda: [0, 0, []])
    kept_err, rej_err = [], []
    for r in rows:
        dec = r["decision"]
        if dec != "factor" and dec not in gated_decisions:
            continue
        t = float(r["t_fix"])
        j = nearest(t, rt)
        if j < 0:
            continue
        k = nearest(t, tt)
        if k < 0:
            continue
        e = float(np.linalg.norm((rp[j] - tp[k])[:2]))
        rejected_here = dec in gated_decisions
        eligible += 1
        rejected += int(rejected_here)
        (rej_err if rejected_here else kept_err).append(e)
        c = r["q_class"]
        by_class[c][0] += 1
        by_class[c][1] += int(rejected_here)
        by_class[c][2].append(e)
        if e > args.anomaly:
            anomaly_n += 1
            anomaly_rej += int(rejected_here)
        if e <= args.good:
            good_n += 1
            good_rej += int(rejected_here)

    def line(name, v):
        if not v:
            return f"{name}: n=0"
        v = np.asarray(v)
        return (f"{name}: n={v.size} med={np.median(v):.3f} "
                f"p95={np.percentile(v, 95):.3f} max={v.max():.3f}")

    print(f"decisions={dict(decisions)}")
    print(f"gate-eligible={eligible} rejected={rejected} "
          f"rate={rejected / max(eligible, 1):.3f}")
    rej_gamma = [float(r["innov_gamma"]) for r in rows
                 if r["decision"] in gated_decisions
                 and r.get("innov_gamma", "-1") not in ("", "-1")]
    if rej_gamma:
        g = np.asarray(rej_gamma)
        print(f"rejected innovation gamma: n={g.size} med={np.median(g):.2f} "
              f"p95={np.percentile(g, 95):.2f} max={g.max():.2f}")
    print(f"anomaly>({args.anomaly:g} m): {anomaly_n}, "
          f"rejected {anomaly_rej} ({anomaly_rej / max(anomaly_n, 1):.3f})")
    print(f"good<={args.good:g} m: {good_n}, "
          f"falsely rejected {good_rej} ({good_rej / max(good_n, 1):.3f})")
    print(line("RTK error | kept", kept_err))
    print(line("RTK error | rejected", rej_err))
    print("by class (eligible / rejected / median err):")
    for c in sorted(by_class):
        n, rj, errs = by_class[c]
        med = np.median(errs) if errs else float("nan")
        print(f"  {c:<9} {n:5d} {rj:5d} {med:.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
