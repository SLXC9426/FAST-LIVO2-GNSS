#!/usr/bin/env python3
import rosbag, genpy, numpy as np
import sensor_msgs.point_cloud2 as pc2
import collections

BAG = "/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag"
b = rosbag.Bag(BAG)

# IMU at later times (vehicle should be moving)
for tag, ts in [("t=100", 1603774114.0), ("t=300", 1603774314.0), ("t=600", 1603774614.0)]:
    accs, gyrs = [], []
    for topic, msg, t in b.read_messages(topics=["/imu_raw"], start_time=genpy.Time(ts), end_time=genpy.Time(ts + 3)):
        accs.append([msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])
        gyrs.append([msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z])
    a = np.array(accs)
    g = np.array(gyrs)
    print(tag, "n=", len(a), "acc mean", a.mean(0).round(3),
          "gyr absmax", np.abs(g).max(0).round(4), "gyr std", g.std(0).round(4))

# pointcloud time-field distribution over 1s
t0 = 1603774114.0
buckets = collections.Counter()
n = 0
for topic, msg, t in b.read_messages(topics=["/points_raw"], start_time=genpy.Time(t0), end_time=genpy.Time(t0 + 1)):
    pts = list(pc2.read_points(msg, field_names=("time",), skip_nans=True))
    for p in pts:
        buckets[int(p[0] // 5000)] += 1
    n += 1
print("scans in 1s:", n, "time-bucket(5ms):", dict(sorted(buckets.items())))
b.close()
