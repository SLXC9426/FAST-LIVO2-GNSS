import importlib.util,json,sys,tempfile,unittest
from pathlib import Path
import numpy as np
S=Path(__file__).resolve().parents[1]
def load(name):
    spec=importlib.util.spec_from_file_location(name,S/f'scripts/eval/{name}.py');m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
g=load('online_stability');seal=load('sealed_run')
def track(t):return np.column_stack([t,np.zeros((len(t),3))])
def stable(rows):return [r['stamp'] for r in rows if r['state']=='STABLE_DIAGNOSTIC']
class G2(unittest.TestCase):
 def test_stale_and_motion_window(self):
  t=np.arange(61.);o=track(t);flags=np.ones(len(t),dtype=bool)
  self.assertFalse(stable(g.diagnose(track(np.arange(6.)),o,flags)))
  l=track(t);l[:,1]=np.minimum(t,15.)
  self.assertGreaterEqual(stable(g.diagnose(l,o,flags))[0],37.)
 def test_rates_and_prefix_and_bias(self):
  for hz in [.5,1,1.23,5,10]:
   t=np.arange(0,45,1/hz);a=track(t);f=np.ones(len(t),dtype=bool);r=g.diagnose(a,a,f)
   self.assertTrue(stable(r));self.assertGreaterEqual(stable(r)[0],22-1e-6);self.assertLessEqual(stable(r)[0],22+3/hz)
   cut=len(t)//2;short=g.diagnose(a[:cut],a[:cut],f[:cut]);self.assertEqual(short,[x for x in r if x['stamp']<=t[cut-1]])
   b=a.copy();b[:,1:4]+=[5,8,2];self.assertEqual([x['state'] for x in r],[x['state'] for x in g.diagnose(a,b,f)])
 def test_gap_unknown_invalid(self):
  t=np.r_[np.arange(25.),np.arange(40.,70.)];a=track(t);f=np.ones(len(t),dtype=bool)
  after=[r for r in g.diagnose(a,a,f) if r['stamp']>=40]
  self.assertEqual(after[0]['state'],'WAIT');self.assertGreaterEqual(stable(after)[0],62.)
  self.assertFalse(stable(g.diagnose(a,a,np.zeros(len(t),dtype=bool))))
  for bad in [np.nan,np.inf]:
   b=a.copy();b[1,1]=bad
   with self.assertRaises(ValueError):g.diagnose(a,b,f)
  b=a.copy();b[1,0]=b[0,0]
  with self.assertRaises(ValueError):g.diagnose(a,b,f)
class Sealing(unittest.TestCase):
 def test_snapshot_survives_workspace_edit(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);script=p/'entry.py';data=p/'input.txt';data.write_text('OLD')
   script.write_text('import pathlib,sys;print(pathlib.Path(sys.argv[1]).read_text())')
   actual,m=seal.seal(p/'run',[script,data],[sys.executable,str(script),str(data)])
   data.write_text('NEW');script.write_text('raise RuntimeError()')
   import subprocess
   self.assertEqual(subprocess.check_output(actual,text=True).strip(),'OLD')
   with self.assertRaises(FileExistsError):seal.seal(p/'run',[data],[sys.executable])
 def test_process_failure_and_review_binding(self):
  with tempfile.TemporaryDirectory() as d:
   p=Path(d);s=p/'fail.py';s.write_text('raise SystemExit(3)')
   r=seal.execute(p/'failed',[s],[sys.executable,str(s)]);self.assertEqual(r['status'],'FAILED');self.assertEqual(r['coverage'],'NOT_EVALUATED')
   original=p/'manifest.json';original.write_text('{"status":"FAILED"}')
   receipt=p/'receipt.json';seal.review(original,{'imu':4},{'imu':4},True,True,True,'independent index check',receipt)
   self.assertTrue(seal.verify_receipt(original,receipt));original.write_text('{}');self.assertFalse(seal.verify_receipt(original,receipt))
   bad=seal.review(original,{'imu':4},{'imu':3},True,True,True,'missing message',p/'bad.json');self.assertEqual(bad['status'],'FAILED')
   seal.review(original,{'imu':4},{'imu':4},True,True,None,'historical data only',p/'data.json')
   self.assertFalse(seal.verify_receipt(original,p/'data.json'))
   self.assertTrue(seal.verify_receipt(original,p/'data.json',allow_data_only=True))
if __name__=='__main__':unittest.main(verbosity=2)
