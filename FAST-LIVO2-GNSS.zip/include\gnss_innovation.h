#ifndef GNSS_INNOVATION_H_
#define GNSS_INNOVATION_H_

// A2.4: chi-square innovation test for an RTK epoch.
//
// The class gate in A2.3 rejects whole categories and therefore both misses
// large outliers and throws away good epochs. This test instead compares the
// measurement with an INDEPENDENT prediction:
//   r     = z_rtk - (anchor_fix + LIO displacement since the anchor)
//   S     = P_pred + P_fix
//   gamma = r^T S^-1 r,  reject when gamma > chi2(3, 0.99) = 11.345
//
// P_pred must come from the prediction, never from the current RTK-LIO
// residual: feeding the innovation back into the prior is the circular
// inflation that already disabled the chi-square gate elsewhere in this
// project. The caller supplies S; this header only evaluates it.
// Header-only (Eigen) so the threshold behaviour is unit-tested.

#include <Eigen/Dense>
#include <algorithm>
#include <cmath>

namespace fast_livo
{

struct GnssInnovationParams
{
  double chi2 = 11.345;       // chi2(3, 0.99)
  double sigma0 = 0.30;       // m, prediction floor
  double drift = 0.02;        // m of prediction sigma per m travelled
  double sigma_ceil = 10.0;   // m, cap so a long outage can recover
};

struct GnssInnovationResult
{
  double gamma = 0.0;
  bool reject = false;
  bool valid = false;  // false = S not finite/SPD; treated as a rejection
};

inline GnssInnovationResult evaluateGnssInnovation(
    const Eigen::Vector3d &r, const Eigen::Matrix3d &S,
    const GnssInnovationParams &p)
{
  GnssInnovationResult out;
  if (!r.allFinite() || !S.allFinite())
  {
    out.valid = false;
    out.reject = true;
    return out;
  }
  // A positive determinant is not positive definiteness: two negative
  // eigenvalues also give det > 0. Check symmetry explicitly (LLT only reads
  // one triangle), then let Cholesky decide. Solve S x = r instead of forming
  // an explicit inverse.
  const double sym_tol = 1e-9 * std::max(1.0, S.norm());
  if ((S - S.transpose()).norm() > sym_tol || S.diagonal().minCoeff() <= 0.0)
  {
    out.valid = false;
    out.reject = true;
    return out;
  }
  const Eigen::LLT<Eigen::Matrix3d> llt(S);
  if (llt.info() != Eigen::Success)
  {
    out.valid = false;
    out.reject = true;
    return out;
  }
  const Eigen::Vector3d x = llt.solve(r);
  out.gamma = r.dot(x);
  out.valid = std::isfinite(out.gamma) && out.gamma >= 0.0;
  out.reject = !out.valid || out.gamma > p.chi2;
  return out;
}

// Prediction sigma for a displacement of `distance` metres since the anchor.
inline double gnssPredictionSigma(double distance, const GnssInnovationParams &p)
{
  const double s = p.sigma0 + p.drift * std::abs(distance);
  return std::min(p.sigma_ceil, std::max(p.sigma0, s));
}

}  // namespace fast_livo

#endif  // GNSS_INNOVATION_H_
