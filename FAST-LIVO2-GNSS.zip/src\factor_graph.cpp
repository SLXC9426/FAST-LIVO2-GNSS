/*
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with a sliding-window factor-graph backend (Improvement 2).

Implements the sliding-window Gauss-Newton optimizer over keyframe poses,
velocities and IMU biases with:
  - IMU pre-integration factors (VINS-style midpoint integration + first-order
    bias Jacobians; validated numerically by scripts/sim/sim_filter_compare.py),
  - LiDAR odometry relative-pose factors,
  - GNSS position factors (optional),
  - Schur-complement marginalization prior of the oldest keyframe (optional).

All math uses right perturbations: R <- R * Exp(dphi), p <- p + dp, v <- v + dv.
Bias Jacobian convention: dR(b+db) = dR * Exp(J_R_bg * db), dv(b+db) = dv + J_v_* db.
*/

#include "factor_graph.h"

#include <algorithm>
#include <chrono>
#include <cmath>
#include <iostream>

namespace fast_livo
{

namespace
{
inline double wallTime()
{
  return std::chrono::duration<double>(std::chrono::steady_clock::now().time_since_epoch()).count();
}

// robust (Huber) weight for a scalar Mahalanobis residual
inline double huberWeight(const double maha, const double delta)
{
  if (delta <= 0.0) return 1.0;
  if (maha <= delta) return 1.0;
  return delta / maha;
}
} // namespace

FactorGraph::FactorGraph(const GraphConfig &cfg) : cfg_(cfg)
{
  if (cfg_.thread_en)
  {
    thread_ = std::thread(&FactorGraph::threadLoop, this);
  }
}

FactorGraph::~FactorGraph()
{
  stop();
}

void FactorGraph::stop()
{
  if (thread_.joinable())
  {
    {
      std::lock_guard<std::mutex> lk(mtx_);
      stop_ = true;
    }
    cv_.notify_all();
    thread_.join();
  }
}

void FactorGraph::pushImu(const ImuSample &imu)
{
  // imu_mtx_ (not mtx_): this is called from the main thread at 200 Hz and
  // must never block on the optimize thread's pre-integration.
  std::lock_guard<std::mutex> lk(imu_mtx_);
  imu_ring_.push_back(imu);
  while (imu_ring_.size() > 2 && imu_ring_.front().t < imu.t - 60.0)
  {
    imu_ring_.pop_front();
  }
}

void FactorGraph::pushKeyframe(const GraphKeyframe &kf)
{
  std::lock_guard<std::mutex> lk(mtx_);
  // R4-5: stamp the wall clock HERE, at enqueue. The queue/output latencies
  // used to be wallTime() - kf.stamp, i.e. wall clock minus the DATA
  // timestamp - a constant (negative for 2020-era bags), not a latency.
  kf_queue_.push_back(kf);
  kf_queue_.back().push_wt = wallTime();
  cv_.notify_all();
}

bool FactorGraph::getLatest(GraphResult &out)
{
  std::lock_guard<std::mutex> lk(res_mtx_);
  if (!have_result_) return false;
  out = result_;
  return true;
}

GraphStats FactorGraph::getStats()
{
  std::lock_guard<std::mutex> lk(res_mtx_);
  return stats_;
}

// ---------------------------------------------------------------------------
// IMU pre-integration (VINS-style midpoint integration).
// Samples imu_ring_ under imu_mtx_ then computes without holding any lock, so
// the main thread's pushImu (200 Hz) is never blocked by this.
// ---------------------------------------------------------------------------
FactorGraph::Preint FactorGraph::preintegrate(double t0, double t1, const Eigen::Vector3d &bg, const Eigen::Vector3d &ba)
{
  Preint pi;
  pi.dt = t1 - t0;
  if (pi.dt <= 0) return pi;
  pi.bg0 = bg;
  pi.ba0 = ba;

  std::vector<ImuSample> sam;
  {
    std::lock_guard<std::mutex> lk(imu_mtx_);
    for (const auto &s : imu_ring_)
    {
      if (s.t > t0 && s.t <= t1 + 1e-6) sam.push_back(s);
    }
  }
  if (sam.empty()) { pi.dt = 0; return pi; }

  const double gyr_sigma2 = cfg_.imu_gyr_sigma * cfg_.imu_gyr_sigma; // kept for the F-matrix scaling below
  const double acc_sigma2 = cfg_.imu_acc_sigma * cfg_.imu_acc_sigma;

  for (size_t i = 0; i < sam.size(); i++)
  {
    const double t_next = (i + 1 < sam.size()) ? sam[i + 1].t : t1;
    const double dt = t_next - sam[i].t;
    if (dt <= 0) continue;

    const Eigen::Vector3d gyr0 = sam[i].gyr;
    const Eigen::Vector3d acc0 = sam[i].acc;
    Eigen::Vector3d gyr1 = gyr0;
    Eigen::Vector3d acc1 = acc0;
    if (i + 1 < sam.size())
    {
      gyr1 = sam[i + 1].gyr;
      acc1 = sam[i + 1].acc;
    }
    const Eigen::Vector3d w = 0.5 * (gyr0 + gyr1) - bg;
    const Eigen::Vector3d a0 = acc0 - ba;
    const Eigen::Vector3d a1 = acc1 - ba;

    // --- deltas (mid-point; dp uses the OLD dv, as in VINS) ---
    const Eigen::Vector3d un_acc_0 = pi.dR * a0;
    const Eigen::Matrix3d dR_new = pi.dR * fg_so3::Exp(w * dt);
    const Eigen::Matrix3d dR_old = pi.dR;
    const Eigen::Vector3d un_acc_1 = dR_new * a1;
    const Eigen::Vector3d un_acc = 0.5 * (un_acc_0 + un_acc_1);
    pi.dp += pi.dv * dt + 0.5 * un_acc * dt * dt; // old dv
    pi.dv += un_acc * dt;
    pi.dR = dR_new;

    // --- exact first-order bias Jacobians of the recursion above ---
    // NOTE: un_acc_0 = dR*a0 depends on bg through the ACCUMULATED dR, so both
    // the old (dR_old, J_R_bg, a0) and the new (dR_new, JRbg_new, a1) terms appear.
    const Eigen::Matrix3d a0_x = fg_so3::hat(a0);
    const Eigen::Matrix3d a1_x = fg_so3::hat(a1);
    const Eigen::Matrix3d JRbg_new = fg_so3::Exp(-w * dt) * pi.J_R_bg - fg_so3::rightJacobian(w * dt) * dt;
    const Eigen::Matrix3d dR_avg = 0.5 * (dR_old + dR_new);
    const Eigen::Matrix3d bg_term = dR_old * a0_x * pi.J_R_bg + dR_new * a1_x * JRbg_new;

    pi.J_p_bg += pi.J_v_bg * dt - 0.25 * bg_term * dt * dt;
    pi.J_p_ba += pi.J_v_ba * dt - 0.5 * dR_avg * dt * dt;
    pi.J_v_bg += -0.5 * bg_term * dt;
    pi.J_v_ba += -dR_avg * dt;
    pi.J_R_bg = JRbg_new;

    // --- discrete noise covariance with state-transition propagation
    // (VINS-style: Sigma' = F Sigma F^T + Q_dt; velocity noise must couple
    //  into the position block, otherwise info_p is absurdly large) ---
    Eigen::Matrix<double, 15, 15> F = Eigen::Matrix<double, 15, 15>::Identity();
    F.block<3, 3>(0, 0) = fg_so3::Exp(-w * dt);
    F.block<3, 3>(0, 9) = -fg_so3::rightJacobian(w * dt) * dt;
    F.block<3, 3>(3, 0) = -0.5 * (dR_old * a0_x + dR_new * a1_x) * dt;
    F.block<3, 3>(3, 9) = -0.5 * bg_term * dt;
    F.block<3, 3>(3, 12) = -dR_avg * dt;
    F.block<3, 3>(6, 3) = Eigen::Matrix3d::Identity() * dt;
    F.block<3, 3>(6, 9) = -0.25 * bg_term * dt * dt;
    F.block<3, 3>(6, 12) = -0.5 * dR_avg * dt * dt;
    Eigen::Matrix<double, 15, 15> Q = Eigen::Matrix<double, 15, 15>::Zero();
    // continuous noise densities sigma -> per-step variance = sigma^2 * dt
    Q.block<3, 3>(0, 0) = cfg_.imu_gyr_sigma * cfg_.imu_gyr_sigma * dt * Eigen::Matrix3d::Identity();
    Q.block<3, 3>(3, 3) = cfg_.imu_acc_sigma * cfg_.imu_acc_sigma * dt * Eigen::Matrix3d::Identity();
    Q.block<3, 3>(6, 6) = 0.25 * cfg_.imu_acc_sigma * cfg_.imu_acc_sigma * dt * dt * dt * Eigen::Matrix3d::Identity();
    Q.block<3, 3>(9, 9) = cfg_.imu_bg_sigma * cfg_.imu_bg_sigma * dt * Eigen::Matrix3d::Identity();
    Q.block<3, 3>(12, 12) = cfg_.imu_ba_sigma * cfg_.imu_ba_sigma * dt * Eigen::Matrix3d::Identity();
    pi.cov15 = F * pi.cov15 * F.transpose() + Q;
  }
  // floor the covariance at the *practical* pre-integration accuracy: with
  // imperfectly estimated IMU biases the true prediction error is ~5 cm /
  // 0.2 m/s / 1e-2 rad over 0.1 s, far above the white-noise-only value.
  // Without this floor the preint info dominates the odometry info ~100x and
  // the smoother degenerates (validated by scripts/sim/sim_filter_compare.py).
  pi.cov = pi.cov15.block<9, 9>(0, 0);
  for (int k = 0; k < 3; k++)
  {
    pi.cov(k, k) = std::max(pi.cov(k, k), 0.01 * 0.01);
    pi.cov(3 + k, 3 + k) = std::max(pi.cov(3 + k, 3 + k), 0.2 * 0.2);
    pi.cov(6 + k, 6 + k) = std::max(pi.cov(6 + k, 6 + k), 0.05 * 0.05);
  }
  return pi;
}

// ---------------------------------------------------------------------------
// R3-WP5: the parallel-array invariant. See the header for why it matters.
// ---------------------------------------------------------------------------
bool FactorGraph::sideArraysConsistent() const
{
  const size_t n = window_.size();
  return preints_.size() == n && kf_rel_R_.size() == n &&
         kf_rel_p_.size() == n && node_gnss_.size() == n;
}

// ---------------------------------------------------------------------------
// R3-WP4: the line-search objective.
//
// Every term here must have a counterpart in the A/b assembly in optimizeWindow.
// A term present in A/b but missing here makes the Gauss-Newton direction
// non-descent for the cost that the line search actually evaluates, so steps get
// rejected (or wrongly accepted) and the optimizer silently stops making
// progress. The three terms marked WP4 were missing before this change.
//
// The robust weights (wfac) must match the A/b construction exactly; the GNSS
// factor is deliberately NOT robust-weighted there, so it is not weighted here
// either (if Huber is ever added to the GNSS factor, both places must change).
// ---------------------------------------------------------------------------
double FactorGraph::stateCost(const Eigen::Vector3d &bg_t, const Eigen::Vector3d &ba_t,
                              const Eigen::Matrix3d &R0_lin, const Eigen::Vector3d &p0_lin,
                              const Eigen::Vector3d &v0_lin) const
{
  const int N = (int)window_.size();
  double cost = 0.0;

  // ---- WP4 (term 2 of 3): Schur marginalized prior ----
  // A/b: A += J^T prior_A_ J, b += J^T (prior_A_ r - prior_b_), i.e. the implied
  // cost is r^T prior_A_ r - 2 r^T prior_b_. Dropping the additive constant
  // prior_b_^T prior_A_^-1 prior_b_ is safe: it is identical for every candidate
  // in the line search, so only differences matter. r is built exactly as in the
  // A/b block above, including the -I block on the rotation, which is already
  // implied by using Log() of the relative rotation.
  if (have_prior_)
  {
    Eigen::VectorXd r(15);
    r.segment<3>(0) = fg_so3::Log(window_[0].R.transpose() * prior_R0_);
    r.segment<3>(3) = window_[0].p - prior_p0_;
    r.segment<3>(6) = window_[0].v - prior_v0_;
    r.segment<3>(9) = bg_t - prior_bg_;
    r.segment<3>(12) = ba_t - prior_ba_;
    cost += r.dot(prior_A_ * r) - 2.0 * r.dot(prior_b_);
  }

  for (int i = 1; i < N; i++)
  {
    const Node &nk = window_[i - 1];
    const Node &nj = window_[i];

    // ---------- LiDAR odometry factor ----------
    Eigen::Vector3d eR = fg_so3::Log(kf_rel_R_[i].transpose() * nk.R.transpose() * nj.R);
    Eigen::Vector3d ep = kf_rel_R_[i].transpose() * nk.R.transpose() * (nj.p - nk.p) - kf_rel_p_[i];
    Eigen::VectorXd r6(6);
    r6 << eR, ep;
    Eigen::MatrixXd W = Eigen::MatrixXd::Zero(6, 6);
    W.block<3, 3>(0, 0) = 1.0 / (cfg_.odom_rot_sigma * cfg_.odom_rot_sigma) * Eigen::Matrix3d::Identity();
    W.block<3, 3>(3, 3) = 1.0 / (cfg_.odom_pos_sigma * cfg_.odom_pos_sigma) * Eigen::Matrix3d::Identity();
    const double maha6 = std::sqrt(r6.dot(W * r6));
    const double wf6 = cfg_.robust_en ? huberWeight(maha6, cfg_.robust_delta) : 1.0;
    cost += wf6 * r6.dot(W * r6);

    // ---------- IMU pre-integration factor ----------
    const Preint &pi = preints_[i];
    if (pi.dt > 1e-3)
    {
      const Eigen::Vector3d dbg = bg_t - pi.bg0;
      const Eigen::Vector3d dba = ba_t - pi.ba0;
      const Eigen::Matrix3d dR_c = pi.dR * fg_so3::Exp(pi.J_R_bg * dbg);
      const Eigen::Vector3d dv_c = pi.dv + pi.J_v_bg * dbg + pi.J_v_ba * dba;
      const Eigen::Vector3d dp_c = pi.dp + pi.J_p_bg * dbg + pi.J_p_ba * dba;
      const Eigen::Vector3d g = (nj.gravity.norm() > 1e-6) ? nj.gravity : gravity_;
      eR = fg_so3::Log(dR_c.transpose() * nk.R.transpose() * nj.R);
      const Eigen::Vector3d ev = nk.R.transpose() * (nj.v - nk.v - g * pi.dt) - dv_c;
      ep = nk.R.transpose() * (nj.p - nk.p - nk.v * pi.dt - 0.5 * g * pi.dt * pi.dt) - dp_c;
      Eigen::VectorXd r9(9);
      r9 << eR, ev, ep;
      const Eigen::Matrix<double, 9, 9> info = (pi.cov + 1e-6 * Eigen::Matrix<double, 9, 9>::Identity()).inverse();
      const double maha9 = std::sqrt(r9.dot(info * r9));
      const double wf9 = cfg_.robust_en ? huberWeight(maha9, cfg_.robust_delta) : 1.0;
      cost += wf9 * r9.dot(info * r9);
    }
  }

  // ---- WP4 (term 1 of 3): GNSS position factors ----
  // A/b: A += J^T w J, b += J^T w r with w = 1/sigma^2, no robust weight. The
  // residual and lever arm must match the A/b line exactly.
  if (cfg_.gnss_en)
  {
    for (int i = 0; i < N; i++)
    {
      if (!node_gnss_[i].have) continue;
      const Node &nj = window_[i];
      const Eigen::Vector3d r = nj.p + nj.R * cfg_.lever - node_gnss_[i].pos;
      const double w = 1.0 / (node_gnss_[i].sigma * node_gnss_[i].sigma);
      cost += w * r.squaredNorm();
    }
  }

  // ---------- per-node velocity prior ----------
  // MUST match the A/b assembly's cfg_.v_prior_weight (the WP4 lesson).
  for (int i = 0; i < N; i++)
  {
    const Eigen::Vector3d dv = window_[i].v - window_[i].v_ref;
    cost += cfg_.v_prior_weight * dv.dot(dv);
  }

  // ---- WP4 (term 3 of 3): node0 gauge ----
  // The A/b assembly adds 1e4*I(9,9) on node 0 and NOTHING to b, so it penalises
  // the increment of node 0 relative to this iteration's linearization point -
  // not the absolute pose. Hence the explicit R0_lin/p0_lin/v0_lin arguments.
  {
    const Eigen::Vector3d dth = fg_so3::Log(R0_lin.transpose() * window_[0].R);
    const Eigen::Vector3d dp = window_[0].p - p0_lin;
    const Eigen::Vector3d dv = window_[0].v - v0_lin;
    cost += 1e4 * (dth.squaredNorm() + dp.squaredNorm() + dv.squaredNorm());
  }

  // ---------- bias priors (bg tight, ba loose) ----------
  cost += 1e4 * bg_t.dot(bg_t) + 1e2 * ba_t.dot(ba_t);
  return cost;
}

// ---------------------------------------------------------------------------
// Gauss-Newton optimization of the whole window.
// Returns the number of iterations used.
// ---------------------------------------------------------------------------
int FactorGraph::optimizeWindow()
{
  const int N = (int)window_.size();
  if (N < 1) return 0;

  // R3-WP5 guard: the five parallel arrays are indexed by the same node index, so
  // a length mismatch silently attaches every factor to the wrong node and the
  // result is garbage rather than a visible failure (the marginalize=false path
  // used to do exactly this). Checked explicitly rather than with assert():
  // this build defines NDEBUG, so assert() would be compiled out, and aborting a
  // live mapping run is worse than skipping one optimization.
  if (!sideArraysConsistent())
  {
    std::cerr << "[ FG ] parallel-array size mismatch: window=" << window_.size()
              << " preints=" << preints_.size()
              << " kf_rel_R=" << kf_rel_R_.size()
              << " kf_rel_p=" << kf_rel_p_.size()
              << " node_gnss=" << node_gnss_.size()
              << " - skipping this optimization instead of mis-indexing the factors"
              << std::endl;
    return 0;
  }

  const int dim = 9 * N + 6; // poses+vels + bias(6)

  Eigen::MatrixXd A(dim, dim);
  Eigen::VectorXd b(dim);

  int used_iters = 0;
  for (int iter = 0; iter < cfg_.max_gn_iter; iter++)
  {
    A.setZero();
    b.setZero();
    used_iters = iter + 1;

    // ---- marginalized prior (Improvement 2): fixed linearization point on
    // the oldest remaining keyframe pose+vel and the biases ----
    if (have_prior_)
    {
      Eigen::VectorXd r(15);
      r.segment<3>(0) = fg_so3::Log(window_[0].R.transpose() * prior_R0_);
      r.segment<3>(3) = window_[0].p - prior_p0_;
      r.segment<3>(6) = window_[0].v - prior_v0_;
      r.segment<3>(9) = bias_g_ - prior_bg_;
      r.segment<3>(12) = bias_a_ - prior_ba_;
      // J: 15x15, rows = residual dims, cols = state perturbations (node0 9 + bias 6)
      Eigen::MatrixXd J = Eigen::MatrixXd::Identity(15, 15);
      J.block<3, 3>(0, 0) = -Eigen::Matrix3d::Identity();
      const Eigen::MatrixXd Jc = J.block<15, 9>(0, 0); // cols 0..8  -> node0
      const Eigen::MatrixXd Jb = J.block<15, 6>(0, 9); // cols 9..14 -> bias
      A.block<9, 9>(0, 0) += Jc.transpose() * prior_A_ * Jc;
      A.block<9, 6>(0, 9 * N) += Jc.transpose() * prior_A_ * Jb;
      A.block<6, 9>(9 * N, 0) += Jb.transpose() * prior_A_ * Jc;
      A.block<6, 6>(9 * N, 9 * N) += Jb.transpose() * prior_A_ * Jb;
      b.segment<9>(0) += Jc.transpose() * (prior_A_ * r - prior_b_);
      b.segment<6>(9 * N) += Jb.transpose() * (prior_A_ * r - prior_b_);
    }

    // ---- factors between consecutive keyframes ----
    for (int i = 1; i < N; i++)
    {
      const Node &nk = window_[i - 1];
      const Node &nj = window_[i];
      const Preint &pi = preints_[i];

      // ---------- IMU pre-integration factor ----------
      if (pi.dt > 1e-3)
      {
        const Eigen::Vector3d dbg = bias_g_ - pi.bg0;
        const Eigen::Vector3d dba = bias_a_ - pi.ba0;
        const Eigen::Matrix3d dR_c = pi.dR * fg_so3::Exp(pi.J_R_bg * dbg);
        const Eigen::Vector3d dv_c = pi.dv + pi.J_v_bg * dbg + pi.J_v_ba * dba;
        const Eigen::Vector3d dp_c = pi.dp + pi.J_p_bg * dbg + pi.J_p_ba * dba;
        const double dt = pi.dt;

        const Eigen::Vector3d eR = fg_so3::Log(dR_c.transpose() * nk.R.transpose() * nj.R);
        const Eigen::Vector3d g = (nj.gravity.norm() > 1e-6) ? nj.gravity : gravity_;
        const Eigen::Vector3d w_v = nj.v - nk.v - g * dt;
        const Eigen::Vector3d w_p = nj.p - nk.p - nk.v * dt - 0.5 * g * dt * dt;
        const Eigen::Vector3d ev = nk.R.transpose() * w_v - dv_c;
        const Eigen::Vector3d ep = nk.R.transpose() * w_p - dp_c;

        Eigen::VectorXd r(9);
        r << eR, ev, ep;

        const Eigen::Matrix3d Jri = fg_so3::inverseRightJacobian(eR);
        Eigen::MatrixXd J(9, 27); // cols: node k [9], node k+1 [9], bias [9]
        J.setZero();
        J.block<3, 3>(0, 0) = -Jri * nj.R.transpose() * nk.R;
        J.block<3, 3>(0, 9) = Jri;
        J.block<3, 3>(0, 18) = -Jri * (nj.R.transpose() * nk.R * pi.dR) * pi.J_R_bg; // d eR / d bg
        J.block<3, 3>(3, 0) = fg_so3::hat(nk.R.transpose() * w_v);
        J.block<3, 3>(3, 6) = -nk.R.transpose();
        J.block<3, 3>(3, 15) = nk.R.transpose();
        J.block<3, 3>(3, 18) = -pi.J_v_bg;
        J.block<3, 3>(3, 21) = -pi.J_v_ba;
        J.block<3, 3>(6, 0) = fg_so3::hat(nk.R.transpose() * w_p);
        J.block<3, 3>(6, 3) = -nk.R.transpose();
        J.block<3, 3>(6, 6) = -nk.R.transpose() * dt;
        J.block<3, 3>(6, 12) = nk.R.transpose();
        J.block<3, 3>(6, 18) = -pi.J_p_bg;
        J.block<3, 3>(6, 21) = -pi.J_p_ba;

        const Eigen::Matrix<double, 9, 9> info = (pi.cov + 1e-6 * Eigen::Matrix<double, 9, 9>::Identity()).inverse();
        const double maha = std::sqrt(r.dot(info * r));
        const double wfac = cfg_.robust_en ? huberWeight(maha, cfg_.robust_delta) : 1.0;
        const double sw = std::sqrt(wfac);

        // node blocks (9 dims each)
        const std::vector<int> cols = {i - 1, i};
        for (int c = 0; c < 2; c++)
        {
          const int gi = cols[c];
          const Eigen::MatrixXd Jc = J.block<9, 9>(0, 9 * c);
          const Eigen::MatrixXd JcW = Jc.transpose() * info;
          A.block<9, 9>(gi * 9, gi * 9) += sw * sw * (JcW * Jc);
          b.segment<9>(gi * 9) += sw * sw * (JcW * r);
          const int gj = cols[1 - c];
          if (gj > gi)
          {
            const Eigen::MatrixXd Jd = J.block<9, 9>(0, 9 * (1 - c));
            const Eigen::MatrixXd JcWd = JcW * Jd;
            A.block<9, 9>(gi * 9, gj * 9) += sw * sw * JcWd;
            A.block<9, 9>(gj * 9, gi * 9) += sw * sw * JcWd.transpose();
          }
        }
        // bias block (6 dims only: bg+ba; offset 9*N, after all nodes)
        {
          const int gi = N;
          const Eigen::MatrixXd Jb = J.block<9, 6>(0, 18);
          const Eigen::MatrixXd JbW = Jb.transpose() * info;
          A.block<6, 6>(gi * 9, gi * 9) += sw * sw * (JbW * Jb);
          b.segment<6>(gi * 9) += sw * sw * (JbW * r);
          for (int c = 0; c < 2; c++)
          {
            const int gi2 = cols[c];
            const Eigen::MatrixXd Jn = J.block<9, 9>(0, 9 * c);
            const Eigen::MatrixXd JnW = Jn.transpose() * info;
            const Eigen::MatrixXd JnWJb = JnW * Jb;
            A.block<9, 6>(gi2 * 9, gi * 9) += sw * sw * JnWJb;
            A.block<6, 9>(gi * 9, gi2 * 9) += sw * sw * JnWJb.transpose();
          }
        }
      }

      // ---------- LiDAR odometry factor (relative pose from the frontend) ----------
      {
        const Eigen::Vector3d eR = fg_so3::Log(kf_rel_R_[i].transpose() * nk.R.transpose() * nj.R);
        const Eigen::Vector3d q = nj.p - nk.p;
        const Eigen::Vector3d ep = kf_rel_R_[i].transpose() * nk.R.transpose() * q - kf_rel_p_[i];
        Eigen::VectorXd r(6);
        r << eR, ep;

        const Eigen::Matrix3d Jri = fg_so3::inverseRightJacobian(eR);
        Eigen::MatrixXd J(6, 18);
        J.setZero();
        J.block<3, 3>(0, 0) = -Jri * nj.R.transpose() * nk.R;
        J.block<3, 3>(0, 9) = Jri;
        // d ep / d phi_k = R_rel^T [R_k^T q]x  (validated by finite differences)
        J.block<3, 3>(3, 0) = kf_rel_R_[i].transpose() * fg_so3::hat(nk.R.transpose() * q);
        J.block<3, 3>(3, 3) = -kf_rel_R_[i].transpose() * nk.R.transpose();
        J.block<3, 3>(3, 12) = kf_rel_R_[i].transpose() * nk.R.transpose();

        Eigen::MatrixXd W = Eigen::MatrixXd::Zero(6, 6);
        W.block<3, 3>(0, 0) = 1.0 / (cfg_.odom_rot_sigma * cfg_.odom_rot_sigma) * Eigen::Matrix3d::Identity();
        W.block<3, 3>(3, 3) = 1.0 / (cfg_.odom_pos_sigma * cfg_.odom_pos_sigma) * Eigen::Matrix3d::Identity();
        const double maha = std::sqrt(r.dot(W * r));
        const double wfac = cfg_.robust_en ? huberWeight(maha, cfg_.robust_delta) : 1.0;
        const double sw = std::sqrt(wfac);

        const int gi = i - 1, gj = i;
        const Eigen::MatrixXd Jc = J.block<6, 9>(0, 0);
        const Eigen::MatrixXd Jd = J.block<6, 9>(0, 9);
        const Eigen::MatrixXd JcW = Jc.transpose() * W;
        const Eigen::MatrixXd JdW = Jd.transpose() * W;
        A.block<9, 9>(gi * 9, gi * 9) += sw * sw * (JcW * Jc);
        A.block<9, 9>(gj * 9, gj * 9) += sw * sw * (JdW * Jd);
        const Eigen::MatrixXd JcWd = JcW * Jd;
        A.block<9, 9>(gi * 9, gj * 9) += sw * sw * JcWd;
        A.block<9, 9>(gj * 9, gi * 9) += sw * sw * JcWd.transpose();
        b.segment<9>(gi * 9) += sw * sw * (JcW * r);
        b.segment<9>(gj * 9) += sw * sw * (JdW * r);
      }
    }

    // ---------- GNSS position factors (all nodes) ----------
    if (cfg_.gnss_en)
    {
      for (int i = 0; i < N; i++)
      {
        if (!node_gnss_[i].have) continue;
        const Node &nj = window_[i];
        const Eigen::Vector3d z = nj.p + nj.R * cfg_.lever - node_gnss_[i].pos;
        Eigen::VectorXd r(3);
        r = z;
        Eigen::MatrixXd J(3, 9);
        J.setZero();
        J.block<3, 3>(0, 0) = -nj.R * fg_so3::hat(cfg_.lever);   // right perturbation
        J.block<3, 3>(0, 3) = Eigen::Matrix3d::Identity();
        const double w = 1.0 / (node_gnss_[i].sigma * node_gnss_[i].sigma);
        A.block<9, 9>(i * 9, i * 9) += J.transpose() * w * J;
        b.segment<9>(i * 9) += J.transpose() * w * r;
      }
    }

    // ---- gauge / bias / velocity priors (anchor the weakly-observable modes;
    //      validated numerically by scripts/sim/sim_filter_compare.py) ----
    A.block<9, 9>(0, 0) += 1e4 * Eigen::MatrixXd::Identity(9, 9); // gauge on node 0 (sigma ~ 1 cm)
    // bias prior: bg tight (sigma 0.01 rad/s, frontend estimate is good), ba loose
    // (sigma 0.1 m/s^2) - a too-loose bg prior lets the weakly observable bias
    // absorb all window errors (overfitting)
    A.block<3, 3>(9 * N, 9 * N) += 1e4 * Eigen::Matrix3d::Identity();
    A.block<3, 3>(9 * N + 3, 9 * N + 3) += 1e2 * Eigen::Matrix3d::Identity();
    for (int i = 0; i < N; i++)
    {
      A.block<3, 3>(9 * i + 6, 9 * i + 6) += cfg_.v_prior_weight * Eigen::Matrix3d::Identity();
      b.segment<3>(9 * i + 6) += cfg_.v_prior_weight * (window_[i].v - window_[i].v_ref);
    }
    Eigen::VectorXd bias_vec(6);
    bias_vec << bias_g_, bias_a_;
    b.segment<3>(9 * N) += 1e4 * bias_vec.segment<3>(0);
    b.segment<3>(9 * N + 3) += 1e2 * bias_vec.segment<3>(3);

    // ---- total cost of the current state (for the line search) ----
    // R3-WP4: the objective now lives in stateCost() so that it can be tested
    // directly (test/factor_graph_selftest.cpp), and so that the A/b assembly
    // above and the line-search objective cannot drift apart unnoticed. It MUST
    // contain every term the A/b assembly has: a term present in one and missing
    // from the other makes the GN direction non-descent for the cost being
    // evaluated, and the line search then rejects (or wrongly accepts) steps.
    //
    // Linearization point of this iteration. The A/b assembly adds 1e4*I on node
    // 0 with no b contribution, i.e. it penalises the INCREMENT of node 0 rather
    // than its absolute pose, so the cost has to be told which point that
    // increment is measured from. (The Schur prior needs no snapshot: it carries
    // its own fixed linearization point, prior_R0_/prior_p0_/prior_v0_.)
    const Eigen::Matrix3d R0_iter = window_[0].R;
    const Eigen::Vector3d p0_iter = window_[0].p;
    const Eigen::Vector3d v0_iter = window_[0].v;

    // ---- solve with diagonal preconditioning + Levenberg damping ----
    Eigen::VectorXd Dv = A.diagonal().cwiseSqrt();
    for (int i = 0; i < dim; i++)
    {
      if (Dv(i) < 1e-9) Dv(i) = 1.0;
    }
    Eigen::MatrixXd Asc = A;
    for (int i = 0; i < dim; i++)
    {
      for (int j = 0; j < dim; j++) { Asc(i, j) /= (Dv(i) * Dv(j)); }
    }
    const double lam = std::max(1e-8, 1e-6 * Asc.diagonal().maxCoeff());
    const Eigen::VectorXd b_scaled = (b.array() / Dv.array()).matrix();
    // NOTE: the GN step is delta = -(A^-1 b); b = J^T W r points UPHILL, so the
    // minus sign is essential (without it the residuals double and the line
    // search rejects every step)
    Eigen::VectorXd delta = -(Asc + lam * Eigen::MatrixXd::Identity(dim, dim)).ldlt().solve(b_scaled);
    delta = (delta.array() / Dv.array()).matrix();
    if (!delta.allFinite())
    {
      std::cout << "[ FG ] optimization diverged (non-finite delta), keeping previous solution" << std::endl;
      break;
    }

    // ---- line search: accept the step only if the total cost decreases ----
    double cur_cost = stateCost(bias_g_, bias_a_, R0_iter, p0_iter, v0_iter);
    Eigen::VectorXd step = delta;
    bool accepted = false;
    for (int ls = 0; ls < 15; ls++)
    {
      for (int i = 0; i < N; i++)
      {
        window_[i].R = window_[i].R * fg_so3::Exp(step.segment<3>(9 * i));
        window_[i].p += step.segment<3>(9 * i + 3);
        window_[i].v += step.segment<3>(9 * i + 6);
      }
      const Eigen::Vector3d bg_t = bias_g_ + step.segment<3>(9 * N);
      const Eigen::Vector3d ba_t = bias_a_ + step.segment<3>(9 * N + 3);
      const double new_cost = stateCost(bg_t, ba_t, R0_iter, p0_iter, v0_iter);
      if (new_cost < cur_cost)
      {
        bias_g_ = bg_t;
        bias_a_ = ba_t;
        cur_cost = new_cost;
        accepted = true;
        break;
      }
      // revert and halve the step
      for (int i = 0; i < N; i++)
      {
        window_[i].R = window_[i].R * fg_so3::Exp(-step.segment<3>(9 * i));
        window_[i].p -= step.segment<3>(9 * i + 3);
        window_[i].v -= step.segment<3>(9 * i + 6);
      }
      step *= 0.5;
    }
    if (!accepted) break;
    if (step.norm() < 1e-6) break;
  }

  // keep the last normal equations for marginalization
  last_A_ = A;
  last_b_ = b;
  return used_iters;
}

// ---------------------------------------------------------------------------
// Marginalize the oldest keyframe: Schur complement of node 0, keeping a
// fixed-linearization-point prior on the new first node + biases.
// ---------------------------------------------------------------------------
void FactorGraph::marginalizeOldest(const Eigen::MatrixXd &A, const Eigen::VectorXd &b)
{
  const int N = (int)window_.size();
  if (N < 2) return;
  const int dim = 9 * N + 6;

  // node0: 0..8, rest: 9..dim-1  (rest = nodes 1..N-1 + bias)
  const int m = dim - 9;
  // NOTE: m is a runtime value, so the dynamic-size block/segment forms are
  // required (the fixed-size forms block<9,m>/segment<m> do not compile)
  const Eigen::MatrixXd Abb = A.block<9, 9>(0, 0);
  const Eigen::MatrixXd Abr = A.block(0, 9, 9, m);
  const Eigen::MatrixXd Arb = A.block(9, 0, m, 9);
  const Eigen::MatrixXd Arr = A.block(9, 9, m, m);
  const Eigen::VectorXd bb = b.segment<9>(0);
  const Eigen::VectorXd br = b.segment(9, m);

  const Eigen::MatrixXd Abb_inv_br = Abb.ldlt().solve(Abr);
  const Eigen::MatrixXd Amarg = Arr - Arb * Abb_inv_br;
  const Eigen::VectorXd bmarg = br - Arb * Abb.ldlt().solve(bb);

  // keep only the (old node1 pose+vel) + bias block
  // layout of Amarg: [node1 (9), nodes 2..N-1 (9(N-2)), bias (6)]
  const int nb = 9 + 6;
  Eigen::MatrixXd prior_A(nb, nb);
  prior_A.setZero();
  prior_A.block<9, 9>(0, 0) = Amarg.block<9, 9>(0, 0);
  prior_A.block<9, 6>(0, 9) = Amarg.block(0, m - 6, 9, 6);
  prior_A.block<6, 9>(9, 0) = Amarg.block(m - 6, 0, 6, 9);
  prior_A.block<6, 6>(9, 9) = Amarg.block(m - 6, m - 6, 6, 6);
  Eigen::VectorXd prior_b(nb);
  prior_b.segment<9>(0) = bmarg.segment<9>(0);
  prior_b.segment<6>(9) = bmarg.segment(m - 6, 6);

  // fixed linearization point
  prior_A_ = prior_A;
  // R3 P1-1 third layer: the marginalized model in the remaining increments
  // delta_r is  0.5*delta_r' * Amarg * delta_r + bmarg' * delta_r  (derived by
  // minimizing the joint model over delta_0). The application below expresses
  // this prior through the residual r = x - x0 (x0 = the state at
  // marginalization) as  cost = 0.5 r' prior_A r - r' prior_b_,  whose linear
  // coefficient is -prior_b_. Matching the two gives prior_b_ = -bmarg; storing
  // +bmarg FLIPPED the sign of the correction, so every marginalization pushed
  // the anchor further along the current residuals instead of pulling it back -
  // the walk test 5 below (and the real-data drift in EVAL_PROTOCOL 15.5)
  // measures it at ~0.01 m per marginalization, compounding to metres.
  prior_b_ = -prior_b;
  prior_R0_ = window_[1].R;
  prior_p0_ = window_[1].p;
  prior_v0_ = window_[1].v;
  prior_bg_ = bias_g_;
  prior_ba_ = bias_a_;
  have_prior_ = true;

  // slide the window
  window_.erase(window_.begin());
  preints_.erase(preints_.begin());
  kf_rel_R_.erase(kf_rel_R_.begin());
  kf_rel_p_.erase(kf_rel_p_.begin());
  node_gnss_.erase(node_gnss_.begin());
}

// ---------------------------------------------------------------------------
// Publish the newest optimized pose (R3 stage 2, prerequisite for WP4's
// verification). Shared by both execution paths: optimizeOnce() used to run the
// optimization and then publish nothing, so LIVMapper's non-threaded fallback
// (optimizeOnce() followed by pollGraphResult()) silently produced no graph
// output, including the Log/result/<seq>_graph.txt that WP4 must be evaluated on.
// ---------------------------------------------------------------------------
void FactorGraph::publishResult(double opt_time, double queue_latency, int used_iters)
{
  std::lock_guard<std::mutex> lk2(res_mtx_);
  result_.updated = true;
  result_.stamp = window_.back().stamp;
  result_.R = window_.back().R;
  result_.p = window_.back().p;
  result_.v = window_.back().v;
  stats_.last_opt_time = opt_time;
  stats_.last_queue_latency = queue_latency;
  stats_.last_output_latency = wallTime() - window_.back().push_wt;
  stats_.window = (int)window_.size();
  stats_.iters = used_iters;
  stats_.keyframes_total++;
  have_result_ = true;
}

// ---------------------------------------------------------------------------
// Optimizer thread: consume keyframes, pre-integrate, optimize, publish result
// ---------------------------------------------------------------------------
void FactorGraph::threadLoop()
{
  std::unique_lock<std::mutex> lk(mtx_);
  while (true)
  {
    cv_.wait(lk, [this] { return stop_ || !kf_queue_.empty(); });
    if (stop_ && kf_queue_.empty()) break;
    if (kf_queue_.empty()) continue;

    GraphKeyframe kf = kf_queue_.front();
    kf_queue_.pop_front();
    const double queue_latency = wallTime() - kf.push_wt;

    // pre-integrate from the previous keyframe (samples imu_ring_ under
    // imu_mtx_ internally; computes unlocked so the main thread's 200 Hz
    // pushImu is never blocked)
    Preint pi;
    if (!window_.empty())
    {
      pi = preintegrate(window_.back().stamp, kf.stamp, bias_g_, bias_a_);
    }

    // add the new node
    window_.push_back(Node{kf.stamp, kf.push_wt, kf.R, kf.p, kf.v, kf.gravity, kf.v});
    preints_.push_back(pi);
    kf_rel_R_.push_back(kf.R_rel);
    kf_rel_p_.push_back(kf.p_rel);
    GnssFix gf;
    gf.have = kf.have_gnss;
    gf.pos = kf.gnss_pos;
    gf.sigma = kf.gnss_sigma;
    node_gnss_.push_back(gf);

    // P1-1 diagnostic: the RAW disagreement between the two factor families on
    // the freshly pushed link, evaluated at the frontend poses BEFORE any
    // optimization. The odometry factor is exact by construction there (both
    // sides come from the frontend), so its residual measures nothing; the
    // pre-integration residual is the quantity that competes with it in the
    // optimization (same sigma order), and a systematic value here is what the
    // window-slide + oldest-node pin then accumulates into a trajectory offset.
    // NOTE on reading it: once the window has drifted, nk is an *optimized*
    // node, so |ep| then tracks the accumulated drift rather than the fresh
    // disagreement - the clean per-link quantity is |ev| (the v-prior keeps the
    // node velocities at the frontend's, EVAL_PROTOCOL 15). Print only; no
    // state is touched. Off by default (diag_link_every_n = 0).
    diag_count_++;
    if (cfg_.diag_link_every_n > 0 && pi.dt > 1e-3 && window_.size() >= 2 &&
        (diag_count_ % cfg_.diag_link_every_n) == 0)
    {
      const Node &nk = window_[window_.size() - 2];
      const Node &nj = window_.back();
      const Eigen::Vector3d dbg = bias_g_ - pi.bg0;
      const Eigen::Vector3d dba = bias_a_ - pi.ba0;
      const Eigen::Matrix3d dR_c = pi.dR * fg_so3::Exp(pi.J_R_bg * dbg);
      const Eigen::Vector3d dv_c = pi.dv + pi.J_v_bg * dbg + pi.J_v_ba * dba;
      const Eigen::Vector3d dp_c = pi.dp + pi.J_p_bg * dbg + pi.J_p_ba * dba;
      const double dt = pi.dt;
      const Eigen::Vector3d eR = fg_so3::Log(dR_c.transpose() * nk.R.transpose() * nj.R);
      const Eigen::Vector3d g = (nj.gravity.norm() > 1e-6) ? nj.gravity : gravity_;
      const Eigen::Vector3d w_v = nj.v - nk.v - g * dt;
      const Eigen::Vector3d w_p = nj.p - nk.p - nk.v * dt - 0.5 * g * dt * dt;
      const Eigen::Vector3d ev = nk.R.transpose() * w_v - dv_c;
      const Eigen::Vector3d ep = nk.R.transpose() * w_p - dp_c;
      const Eigen::Vector3d ep_w = nk.R * ep; // world-frame direction of the position disagreement
      std::printf("[FG-LINK] t=%.2f dt=%.3f v=%.2f |ep|=%.4f ep_w=(%+.3f,%+.3f,%+.3f) "
                  "|ev|=%.4f |eR|deg=%.4f\n",
                  nj.stamp, dt, nj.v.norm(), ep.norm(), ep_w(0), ep_w(1), ep_w(2),
                  ev.norm(), eR.norm() * 57.3);
      std::printf("[FG-DP  ] t=%.2f dp=(%+.4f,%+.4f,%+.4f) |dp|=%.4f dv=(%+.4f,%+.4f,%+.4f) "
                  "|dv|=%.4f bg=(%+.4f,%+.4f,%+.4f) ba=(%+.4f,%+.4f,%+.4f)\n",
                  nj.stamp, pi.dp(0), pi.dp(1), pi.dp(2), pi.dp.norm(),
                  pi.dv(0), pi.dv(1), pi.dv(2), pi.dv.norm(),
                  bias_g_(0), bias_g_(1), bias_g_(2), bias_a_(0), bias_a_(1), bias_a_(2));
      // P1-1 third layer: the three-way decomposition of the fresh disagreement,
      // using the PUSHED previous pose/velocity (pre-optimization) so every term
      // is attributable:
      //   dp_front  = the frontend's displacement over the link (world)
      //   dp_imu_w  = the pre-integration's displacement (world)
      //   vkdt+grav = the velocity reference term and gravity term (world)
      // identity: dp_front - vkdt - grav - dp_imu_w = the fresh residual (world)
      if (prev_pushed_valid_)
      {
        const Eigen::Vector3d dp_front = kf.p - prev_pushed_p_;
        const Eigen::Vector3d dp_imu_w = prev_pushed_R_ * pi.dp;
        const Eigen::Vector3d vkdt = prev_pushed_v_ * pi.dt;
        const Eigen::Vector3d grav = -0.5 * g * dt * dt;
        std::printf("[FG-DEC  ] t=%.2f dp_front=(%+.4f,%+.4f,%+.4f) dp_imu_w=(%+.4f,%+.4f,%+.4f) "
                    "vkdt=(%+.4f,%+.4f,%+.4f) grav=(%+.4f,%+.4f,%+.4f)\n",
                    nj.stamp, dp_front(0), dp_front(1), dp_front(2),
                    dp_imu_w(0), dp_imu_w(1), dp_imu_w(2),
                    vkdt(0), vkdt(1), vkdt(2), grav(0), grav(1), grav(2));
      }
    }

    // optimize (window_ is private to this thread)
    lk.unlock();
    const double t0 = wallTime();
    const int used_iters = optimizeWindow();
    const double opt_time = wallTime() - t0;
    lk.lock();

    // marginalize the oldest keyframe if the window is full
    if (cfg_.marginalize && (int)window_.size() > cfg_.window_size)
    {
      marginalizeOldest(last_A_, last_b_);
    }
    else if ((int)window_.size() > cfg_.window_size)
    {
      // marginalize disabled: drop the oldest node, no Schur prior.
      // R3-WP5: the parallel arrays must slide WITH the window. Erasing only
      // window_ re-attached every factor to the wrong node from here on
      // (preints_[i] etc. index by node), which is silent and wrong rather than
      // a crash - the reason this path is now guarded by sideArraysConsistent().
      window_.erase(window_.begin());
      preints_.erase(preints_.begin());
      kf_rel_R_.erase(kf_rel_R_.begin());
      kf_rel_p_.erase(kf_rel_p_.begin());
      node_gnss_.erase(node_gnss_.begin());
      have_prior_ = false;
    }

    // publish the newest optimized pose
    publishResult(opt_time, queue_latency, used_iters);

    // P1-1: remember this keyframe's pushed quantities - the next link's
    // fresh-disagreement decomposition needs the PRE-optimization values
    prev_pushed_p_ = kf.p;
    prev_pushed_v_ = kf.v;
    prev_pushed_R_ = kf.R;
    prev_pushed_valid_ = true;
  }
}

// synchronous single-shot processing (used for tests / non-threaded mode)
int FactorGraph::optimizeOnce()
{
  std::unique_lock<std::mutex> lk(mtx_);
  while (!kf_queue_.empty())
  {
    GraphKeyframe kf = kf_queue_.front();
    kf_queue_.pop_front();
    const double queue_latency = wallTime() - kf.push_wt;
    Preint pi;
    if (!window_.empty())
    {
      pi = preintegrate(window_.back().stamp, kf.stamp, bias_g_, bias_a_);
    }
    window_.push_back(Node{kf.stamp, kf.push_wt, kf.R, kf.p, kf.v, kf.gravity, kf.v});
    preints_.push_back(pi);
    kf_rel_R_.push_back(kf.R_rel);
    kf_rel_p_.push_back(kf.p_rel);
    GnssFix gf;
    gf.have = kf.have_gnss;
    gf.pos = kf.gnss_pos;
    gf.sigma = kf.gnss_sigma;
    node_gnss_.push_back(gf);
    lk.unlock();
    const double t0 = wallTime();
    const int used_iters = optimizeWindow();
    const double opt_time = wallTime() - t0;
    lk.lock();
    if (cfg_.marginalize && (int)window_.size() > cfg_.window_size)
    {
      marginalizeOldest(last_A_, last_b_);
    }
    else if ((int)window_.size() > cfg_.window_size)
    {
      // marginalize disabled: drop the oldest node, no Schur prior.
      // R3-WP5: the parallel arrays must slide WITH the window. Erasing only
      // window_ re-attached every factor to the wrong node from here on
      // (preints_[i] etc. index by node), which is silent and wrong rather than
      // a crash - the reason this path is now guarded by sideArraysConsistent().
      window_.erase(window_.begin());
      preints_.erase(preints_.begin());
      kf_rel_R_.erase(kf_rel_R_.begin());
      kf_rel_p_.erase(kf_rel_p_.begin());
      node_gnss_.erase(node_gnss_.begin());
      have_prior_ = false;
    }
    // publish, exactly as the threaded path does (see publishResult's note)
    publishResult(opt_time, queue_latency, used_iters);
  }
  return 0;
}

} // namespace fast_livo
