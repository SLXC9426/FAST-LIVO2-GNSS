import calendar
from datetime import datetime
import numpy as np
from rtk_preprocess import parse_obs_file, WAVELEN

ROVER = "/home/slxc9426/great_pvt/obs/campus-day.20O"
t0 = calendar.timegm(datetime(2020, 10, 27, 2, 9, 50).timetuple())
rv, _ = parse_obs_file(ROVER, ("G",), (t0, t0 + 2))
print("epochs", [(e.t_gps, sorted(e.sats)) for e in rv])
for sat in ["G02", "G05", "G13", "G15", "G29"]:
    print("\n", sat)
    prev = None
    for e in rv:
        o = e.sats.get(sat)
        if not o:
            continue
        ph = o["L1C"].value
        dp = o["D1C"].value
        print(f"  t={e.t_gps:.0f} phase_cycles={ph:.3f} doppler_Hz={dp:.3f}")
        if prev is not None:
            dt = e.t_gps - prev[0]
            dphi_m = (ph - prev[1]) * WAVELEN[("G", "L1")]
            pred = 0.5 * (dp + prev[2]) * dt * WAVELEN[("G", "L1")]
            print(f"    dphi_m={dphi_m:.3f} pred(+D)={pred:.3f} "
                  f"res_plus={dphi_m-pred:.3f} res_minus={dphi_m+pred:.3f}")
        prev = (e.t_gps, ph, dp)
