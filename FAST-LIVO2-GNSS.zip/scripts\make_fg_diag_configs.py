#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive every P1-1 (factor-graph backend diagnosis) config arm from
great_campus01_fg_line.yaml. Each arm changes ONE or TWO graph keys and nothing
else; the graph backend does not feed back into the frontend, so none of these
affects the recorded frontend APEs.

  great_campus01_fg_w5.yaml            window_size 25 -> 5
  great_campus01_fg_stiffodom.yaml     odom sigma 0.05/0.01 -> 0.005/0.001   (adopted)
  great_campus01_fg_sodom2.yaml        odom sigma -> 0.001/0.0002 (saturation check)
  great_campus01_fg_sodom_gnss45.yaml  stiffodom + gnss_pos_sigma -> 4.5
  great_campus01_fg_sodom_nognss.yaml  stiffodom2 + graph gnss_en -> false

Results and the mechanism: docs/EVAL_PROTOCOL.md section 15.
"""
import os

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.join(HERE, os.pardir, "config", "great_campus01_fg_line.yaml")


def derive(name, subs):
    with open(BASE, encoding="utf-8") as fh:
        text = fh.read()
    for old, new in subs:
        assert old in text, "pattern not found: %r" % old
        text = text.replace(old, new, 1)
    dst = os.path.join(HERE, os.pardir, "config", name)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.write(text)
    print("wrote %s" % os.path.normpath(dst))


derive("great_campus01_fg_w5.yaml",
       [("  window_size: 25", "  window_size: 5  # P1-1: small window")])
derive("great_campus01_fg_stiffodom.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer (adopted)"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer (adopted)")])
derive("great_campus01_fg_sodom2.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.0002  # P1-1: 50x stiffer"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.001  # P1-1: 50x stiffer")])
derive("great_campus01_fg_sodom_gnss45.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer"),
        ("  gnss_pos_sigma: 0.5", "  gnss_pos_sigma: 4.5  # P1-1: the frontend's adaptive scale")])
derive("great_campus01_fg_sodom_nognss.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.0002  # P1-1: 50x stiffer"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.001  # P1-1: 50x stiffer"),
        ("  gnss_en: true", "  gnss_en: false  # P1-1: pure odometry smoothing")])
derive("great_campus01_fg_sodom_nognss_diag.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.0002  # P1-1: 50x stiffer"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.001  # P1-1: 50x stiffer"),
        ("  gnss_en: true", "  gnss_en: false  # P1-1: pure odometry smoothing"),
        ("  max_gn_iter: 8", "  max_gn_iter: 8\n  diag_link_every_n: 1  # P1-1: per-link diagnostics")])
derive("great_campus01_fg_stiffodom_it40.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer (adopted)"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer (adopted)"),
        ("  max_gn_iter: 8", "  max_gn_iter: 40  # P1-1 third layer: convergence probe")])
derive("great_campus01_fg_stiffodom_vp1e4.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer (adopted)"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer (adopted)"),
        ("  max_gn_iter: 8", "  max_gn_iter: 8\n  v_prior_weight: 10000.0  # P1-1 third layer: velocity-anchor probe")])
derive("great_campus01_fg_stiffodom_vref5.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer (adopted)"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer (adopted)"),
        ("  max_gn_iter: 8", "  max_gn_iter: 8\n  v_ref_pos_frames: 5  # P1-1 third layer: position-implied v_ref")])
derive("great_campus01_fg_stiffodom_vref10.yaml",
       [("  odom_rot_sigma: 0.01", "  odom_rot_sigma: 0.001  # P1-1: 10x stiffer (adopted)"),
        ("  odom_pos_sigma: 0.05", "  odom_pos_sigma: 0.005  # P1-1: 10x stiffer (adopted)"),
        ("  max_gn_iter: 8", "  max_gn_iter: 8\n  v_ref_pos_frames: 10  # P1-1 third layer: position-implied v_ref")])
