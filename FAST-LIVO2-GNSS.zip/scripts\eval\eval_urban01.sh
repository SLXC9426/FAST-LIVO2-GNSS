#!/usr/bin/env bash
# Official urban-01 evaluation AFTER the covariance-floor fix.
# Plays from t=60s (includes the 90 s standstill that used to freeze the
# estimator) for 400 s. Reports trajectory length + evo APE (Umeyama align).
# usage: bash eval_urban01.sh <mode> [start] [dur]
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
MODE=$1
START=${2:-60}
DUR=${3:-400}
BAG=/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag
mkdir -p ~/logs
SEQ=great_urban01_$MODE
rm -f Log/result/$SEQ.txt Log/result/${SEQ}_graph.txt Log/result/${SEQ}_latency.csv Log/result/${SEQ}_dyn.csv

if ! pgrep -f 'bin/roscore' > /dev/null; then
  roscore > ~/logs/roscore.log 2>&1 &
  sleep 5
fi

roslaunch fast_livo mapping_great_urban01.launch mode:=$MODE rviz:=false > ~/logs/ur_$MODE.log 2>&1 &
LPID=$!
sleep 50
/opt/ros/noetic/bin/rosbag play -s $START -u $DUR --clock $BAG > ~/logs/ur_play_$MODE.log 2>&1
sleep 5
kill $LPID 2>/dev/null
sleep 3

echo "==== $MODE (t=$START..$((START+DUR))s) ===="
grep -o 'effective feature num: [0-9]*' ~/logs/ur_$MODE.log | awk '{s+=$4; n++} END {if (n>0) printf "mean eff feat: %.1f (n=%d)\n", s/n, n}'
N=$(wc -l < Log/result/$SEQ.txt 2>/dev/null || echo 0)
echo "traj lines: $N"
if [ "$N" -gt 1 ]; then
  head -1 Log/result/$SEQ.txt
  tail -1 Log/result/$SEQ.txt
  awk 'NR>1 {dx=$2-px; dy=$3-py; dz=$4-pz; s+=sqrt(dx*dx+dy*dy+dz*dz)} {px=$2; py=$3; pz=$4} END {printf "traj total length: %.2f m over %d lines\n", s, NR}' Log/result/$SEQ.txt
  # evo APE with Umeyama alignment
  if command -v evo_ape >/dev/null 2>&1; then
    cp /mnt/d/BaiduNetdiskDownload/Urban-01/urban01_reference.tum /tmp/ref_${MODE}.tum
    evo_ape tum /tmp/ref_${MODE}.tum Log/result/$SEQ.txt -a --no_warnings 2>/dev/null | grep -E 'rmse|mean|max' | head -4
  fi
fi
