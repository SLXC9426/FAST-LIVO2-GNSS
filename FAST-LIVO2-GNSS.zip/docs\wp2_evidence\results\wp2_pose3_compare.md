# WP2 同输入对照：Pose3 后端

| arm | n | matched | ATE median | ATE p95 | ATE RMSE |
|---|---:|---:|---:|---:|---:|
| online_pose3 | 805 | 805 | 1.063 | 2.855 | 1.515 |
| online_point3 | 805 | 805 | 1.271 | 3.491 | 1.806 |
| offline_static_cauchy | 805 | 805 | 1.307 | 3.736 | 1.903 |

## Pose3 vs Point3 同输入

- 位置差 median/p95/max：0.312 / 1.549 / 2.311 m
- 姿态差 median/p95/max：0.776 / 1.914 / 3.107 deg

## Pose3 vs 离线图（static+Cauchy, no TDDD）

- 位置差 median/p95/max：0.497 / 1.991 / 2.618 m
