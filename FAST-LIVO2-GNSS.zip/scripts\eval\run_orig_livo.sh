#!/bin/bash
# Run the ORIGINAL (vanilla) FAST-LIVO2 in LIVO mode on the GREAT campus data,
# and evaluate with the same protocol/reference as our modified build.
#
# The original has no GNSS support at all and no ZUPT, so this is a pure
# LIVO baseline: LiDAR + IMU + vision. The sensor configuration (extrinsics,
# camera, preprocess, IMU noise) is byte-identical to our runs - the two config
# files are copies of ours - so the comparison isolates the code differences
# (frame alignment, GNSS fusion, ZUPT, robustness fixes).
#
# Usage: run_orig_livo.sh <campus01|campus02> <tag> [dur_s]
export LANG=C.UTF-8
SEQ=$1; TAG=$2; DUROV=${3:-}
source /opt/ros/noetic/setup.bash
source $HOME/catkin_ws_orig/devel/setup.bash
WS=$HOME/catkin_ws_orig/src/fast_livo
cd "$WS"

case "$SEQ" in
  campus01) BAG=$HOME/datasets/GREAT/campus-01-full.bag; DUR=607 ;;
  campus02) BAG=$HOME/datasets/GREAT/campus-02.bag;      DUR=806 ;;
  *) echo "unknown $SEQ"; exit 1 ;;
esac
REF=$HOME/eval_great/${SEQ}_reference.tum
[ -n "$DUROV" ] && DUR=$DUROV
CFG=config/great_${SEQ}.yaml

# LIVO: both modalities on (the original's default), no GNSS key exists for it
sed -i 's/^  lidar_en: .*/  lidar_en: 1/' "$CFG"
sed -i 's/^  img_en: .*/  img_en: 1/'     "$CFG"

RES=Log/result/${TAG}.txt
mkdir -p Log/result
: > "$RES"

bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval/kill_ros.sh
roslaunch fast_livo mapping_great_orig.launch seq_name:=$TAG cfg:=great_${SEQ} \
    > $HOME/orig_${TAG}.log 2>&1 &
MP=$!
sleep 8
rosbag play -q --queue 5000 -s 0 -u $DUR "$BAG" > /dev/null 2>&1 &
PP=$!
wait $PP 2>/dev/null || true

last=-1; stable=0
for i in $(seq 1 60); do
  sleep 4
  n=$(wc -l < "$RES" 2>/dev/null || echo 0)
  if [ "$n" = "$last" ]; then stable=$((stable+1)); else stable=0; fi
  last=$n
  [ "$stable" -ge 3 ] && break
done
kill -9 $MP 2>/dev/null || true
bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval/kill_ros.sh
echo "[$TAG] $(wc -l < "$RES") lines"

python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/eval/eval_unified.py \
    "$RES" "$REF" "$TAG" --config "$CFG"
cp "$RES" "$HOME/eval_great/final_${TAG}.txt" 2>/dev/null || true
