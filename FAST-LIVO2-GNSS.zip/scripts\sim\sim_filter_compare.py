#!/usr/bin/env python3
"""
Numerical validation & comparison for FAST-LIVO2 Improvement 2
(sliding-window factor-graph backend vs frontend ESKF).

Part A - math validation by finite differences (mirrors src/factor_graph.cpp):
  A1. SO(3) helpers (Exp/Log/right Jacobian) used by the C++ backend
  A2. IMU pre-integration bias Jacobians (J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba)
  A3. pre-integration factor Jacobians wrt poses / velocities / biases
  A4. LiDAR odometry factor Jacobians
  A5. Schur-complement marginalization

Part B - synthetic IMU+LiDAR sequence:
  B1. frontend ESKF (same formulas as src/IMU_Processing.cpp)
  B2. sliding-window factor graph (same formulas as src/factor_graph.cpp)
  B3. ATE / RPE vs ground truth + per-step timing + latency

Runs on Windows with numpy/scipy only (matplotlib optional).

Usage:
  python scripts/sim/sim_filter_compare.py [--validate] [--sim] [--seed N]
"""

import argparse
import os
import sys
import time

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MPL = True
except Exception:
    HAS_MPL = False

OUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "..", "Log", "sim")

# ---------------------------------------------------------------------------
# SO(3) helpers (identical to fg_so3 in factor_graph.h)
# ---------------------------------------------------------------------------


def hat(v):
    return np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])


def so3_exp(phi):
    theta = np.linalg.norm(phi)
    if theta < 1e-12:
        return np.eye(3)
    u = phi / theta
    ct, st = np.cos(theta), np.sin(theta)
    return ct * np.eye(3) + (1.0 - ct) * np.outer(u, u) + st * hat(u)


def so3_log(R):
    # w = (R21-R12, R02-R20, R10-R01) = 2*sin(theta)*axis.
    # Log = theta*axis = theta/(2 sin theta) * w;  small angles: ~ w/2.
    w = np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])
    theta_w = 0.5 * np.linalg.norm(w)  # ~ sin(theta)
    if theta_w < 1e-4:  # theta ~ sin(theta) -> Log ~ 0.5*w
        return 0.5 * w
    cos_theta = min(1.0, max(-1.0, 0.5 * (np.trace(R) - 1.0)))
    theta = np.arccos(cos_theta)
    if theta < 1e-9:
        return np.zeros(3)
    if abs(np.pi - theta) < 1e-3:
        return theta * w / np.linalg.norm(w)
    return theta / (2.0 * np.sin(theta)) * w


def right_jacobian(phi):
    theta = np.linalg.norm(phi)
    if theta < 1e-12:
        return np.eye(3)
    w = hat(phi)
    ct, st = np.cos(theta), np.sin(theta)
    return np.eye(3) - (1.0 - ct) / (theta * theta) * w + (theta - st) / (theta ** 3) * w @ w


def inv_right_jacobian(phi):
    theta = np.linalg.norm(phi)
    if theta < 1e-12:
        return np.eye(3)
    w = hat(phi)
    ct = np.cos(theta)
    return np.eye(3) + 0.5 * w + (1.0 / (theta * theta) - (1.0 + ct) / (2.0 * theta * np.sin(theta))) * w @ w


# ---------------------------------------------------------------------------
# IMU pre-integration (identical to FactorGraph::preintegrate)
# ---------------------------------------------------------------------------


def preintegrate(samples, bg, ba):
    """samples: list of (t, acc, gyr) sorted by t, spanning (t0, t1].
    Returns (dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov9, bg0, ba0, dt)."""
    if len(samples) < 1:
        return None
    dR = np.eye(3)
    dv = np.zeros(3)
    dp = np.zeros(3)
    J_R_bg = np.zeros((3, 3))
    J_v_bg = np.zeros((3, 3))
    J_v_ba = np.zeros((3, 3))
    J_p_bg = np.zeros((3, 3))
    J_p_ba = np.zeros((3, 3))
    cov15 = np.zeros((15, 15))  # [theta, v, p, bg, ba], VINS-style propagation
    t1 = samples[-1][0]
    gyr_s2 = 0.02 ** 2  # imu_gyr_sigma
    acc_s2 = 0.5 ** 2  # imu_acc_sigma
    bg_s2 = 0.0001 ** 2
    ba_s2 = 0.0005 ** 2
    for i, (t, acc, gyr) in enumerate(samples):
        t_next = samples[i + 1][0] if i + 1 < len(samples) else t1
        dt = t_next - t
        if dt <= 0:
            continue
        gyr0, acc0 = gyr, acc
        # samples elements are (t, acc, gyr): samples[i+1][1:] unpacks (acc, gyr)
        acc1, gyr1 = samples[i + 1][1:] if i + 1 < len(samples) else (acc, gyr)
        w = 0.5 * (gyr0 + gyr1) - bg
        a0 = acc0 - ba
        a1 = acc1 - ba

        un_acc_0 = dR @ a0
        dR_new = dR @ so3_exp(w * dt)
        dR_old = dR
        un_acc_1 = dR_new @ a1
        un_acc = 0.5 * (un_acc_0 + un_acc_1)
        dp = dp + dv * dt + 0.5 * un_acc * dt * dt  # old dv
        dv = dv + un_acc * dt
        dR = dR_new

        a0_x = hat(a0)
        a1_x = hat(a1)
        JRbg_new = so3_exp(-w * dt) @ J_R_bg - right_jacobian(w * dt) * dt
        dR_avg = 0.5 * (dR_old + dR_new)
        # NOTE: un_acc_0 = dR*a0 depends on bg through the ACCUMULATED dR, so both
        # the old (dR, J_R_bg, a0) and the new (dR_new, JRbg_new, a1) terms appear
        bg_term = dR_old @ a0_x @ J_R_bg + dR_new @ a1_x @ JRbg_new

        J_p_bg = J_p_bg + J_v_bg * dt - 0.25 * bg_term * dt * dt
        J_p_ba = J_p_ba + J_v_ba * dt - 0.5 * dR_avg * dt * dt
        J_v_bg = J_v_bg - 0.5 * bg_term * dt
        J_v_ba = J_v_ba - dR_avg * dt
        J_R_bg = JRbg_new

        # --- discrete noise covariance with state-transition propagation
        # (VINS-style: Sigma' = F Sigma F^T + Q_dt; velocity noise must couple
        #  into the position block, otherwise info_p is absurdly large) ---
        F = np.eye(15)
        F[0:3, 0:3] = so3_exp(-w * dt)
        F[0:3, 9:12] = -right_jacobian(w * dt) * dt
        F[3:6, 0:3] = -0.5 * (dR_old @ a0_x + dR_new @ a1_x) * dt
        F[3:6, 9:12] = -0.5 * bg_term * dt
        F[3:6, 12:15] = -dR_avg * dt
        F[6:9, 3:6] = np.eye(3) * dt
        F[6:9, 9:12] = -0.25 * bg_term * dt * dt
        F[6:9, 12:15] = -0.5 * dR_avg * dt * dt
        Q = np.zeros((15, 15))
        # continuous noise densities sigma -> per-step variance = sigma^2 * dt
        Q[0:3, 0:3] = gyr_s2 * dt * np.eye(3)
        Q[3:6, 3:6] = acc_s2 * dt * np.eye(3)
        Q[6:9, 6:9] = 0.25 * acc_s2 * dt ** 3 * np.eye(3)
        Q[9:12, 9:12] = bg_s2 * dt * np.eye(3)
        Q[12:15, 12:15] = ba_s2 * dt * np.eye(3)
        cov15 = F @ cov15 @ F.T + Q
    # floor the covariance at the *practical* pre-integration accuracy: with
    # unestimated IMU biases the true prediction error is ~5 cm / 0.2 m/s /
    # 1e-2 rad over 0.1 s, far above the white-noise-only value. Without this
    # floor the preint info dominates the odometry info ~100x, the smoother
    # never moves the nodes and the output degenerates to the raw propagation.
    cov = cov15[0:9, 0:9]
    for kk in range(3):
        cov[kk, kk] = max(cov[kk, kk], (0.01 ** 2))
        cov[3 + kk, 3 + kk] = max(cov[3 + kk, 3 + kk], (0.2 ** 2))
        cov[6 + kk, 6 + kk] = max(cov[6 + kk, 6 + kk], (0.05 ** 2))
    return (dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov, bg, ba, t1 - samples[0][0])


# ---------------------------------------------------------------------------
# Part A: finite-difference validation
# ---------------------------------------------------------------------------


def validate_preint_jacobians():
    print("=" * 72)
    print("A2. pre-integration bias Jacobians (finite differences)")
    print("=" * 72)
    rng = np.random.default_rng(7)
    ok = True
    for trial in range(5):
        bg = rng.normal(0, 0.01, 3)
        ba = rng.normal(0, 0.05, 3)
        samples = []
        t = 0.0
        while t < 1.0:
            samples.append((t, rng.normal(0, 1.0, 3) + 3.0, rng.normal(0, 0.3, 3)))
            t += 0.005
        dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, *_ = preintegrate(samples, bg, ba)
        eps = 1e-5  # large enough for double-precision so3_log (rot ~ J*eps ~ 1e-6 rad)
        for k in range(3):
            bg_p = bg.copy()
            bg_p[k] += eps
            dR_p, dv_p, dp_p, *_ = preintegrate(samples, bg_p, ba)
            # convention: dR(b+db) = dR * Exp(J_R_bg db)  =>  Log(dR^T dR_p) = J_R_bg db
            # (note: Log(dR_p dR^T) would measure a similarity-transformed Jacobian)
            fd_R = so3_log(dR.T @ dR_p) / eps
            fd_v = (dv_p - dv) / eps
            fd_p = (dp_p - dp) / eps
            if (np.abs(fd_R - J_R_bg[:, k]) > 1e-4).any() or (np.abs(fd_v - J_v_bg[:, k]) > 1e-3).any() or (
                np.abs(fd_p - J_p_bg[:, k]) > 1e-3
            ).any():
                ok = False
                print(f"  [FAIL] trial {trial} axis {k}: dR fd={fd_R} ana={J_R_bg[:, k]}")
                print(f"         dv fd={fd_v} ana={J_v_bg[:, k]}")
                print(f"         dp fd={fd_p} ana={J_p_bg[:, k]}")
            ba_p = ba.copy()
            ba_p[k] += eps
            dR_p, dv_p, dp_p, *_ = preintegrate(samples, bg, ba_p)
            if (np.abs((dv_p - dv) / eps - J_v_ba[:, k]) > 1e-3).any() or (np.abs((dp_p - dp) / eps - J_p_ba[:, k]) > 1e-3).any():
                ok = False
                print(f"  [FAIL] trial {trial} axis {k} (ba): dv/ba, dp/ba mismatch")
    print("  pre-integration bias Jacobians:", "OK" if ok else "FAILED")
    return ok


def preint_residual(samples, g, x):
    """x = (Rk, pk, vk, Rk1, pk1, vk1, bg, ba) -> 9-dim residual (same as factor_graph.cpp)."""
    Rk, pk, vk, Rk1, pk1, vk1, bg, ba = x
    pi = preintegrate(samples, bg, ba)
    if pi is None:
        return np.zeros(9)
    dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov, bg0, ba0, dt = pi
    eR = so3_log(dR.T @ Rk.T @ Rk1)
    w_v = vk1 - vk - g * dt
    w_p = pk1 - pk - vk * dt - 0.5 * g * dt * dt
    ev = Rk.T @ w_v - dv
    ep = Rk.T @ w_p - dp
    return np.concatenate([eR, ev, ep])


def fd_jac(f, x, idxs, eps=1e-6):
    J = np.zeros((len(x), len(idxs)))
    for j, k in enumerate(idxs):
        xp = x.copy()
        xp[k] += eps
        xm = x.copy()
        xm[k] -= eps
        J[:, j] = (f(xp) - f(xm)) / (2 * eps)
    return J


def validate_preint_factor_jacobians():
    print("=" * 72)
    print("A3. pre-integration factor Jacobians wrt poses/velocities/bias")
    print("=" * 72)
    rng = np.random.default_rng(11)
    g = np.array([0.0, 0.0, 9.81])
    ok = True
    for trial in range(5):
        samples = []
        t = 0.0
        while t < 0.5:
            samples.append((t, rng.normal(0, 1.0, 3) + 3.0, rng.normal(0, 0.3, 3)))
            t += 0.005
        Rk = so3_exp(rng.normal(0, 0.05, 3))
        pk = rng.normal(0, 1, 3)
        vk = rng.normal(0, 0.5, 3)
        Rk1 = so3_exp(rng.normal(0, 0.05, 3))
        pk1 = rng.normal(0, 1, 3)
        vk1 = rng.normal(0, 0.5, 3)
        bg = rng.normal(0, 0.01, 3)
        ba = rng.normal(0, 0.05, 3)
        x0 = (Rk, pk, vk, Rk1, pk1, vk1, bg, ba)
        f = lambda x: preint_residual(samples, g, x)

        # analytic Jacobians (right perturbation, same as factor_graph.cpp)
        pi = preintegrate(samples, bg, ba)
        dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov, bg0, ba0, dt = pi
        eR = so3_log(dR.T @ Rk.T @ Rk1)
        Jri = inv_right_jacobian(eR)
        w_v = vk1 - vk - g * dt
        w_p = pk1 - pk - vk * dt - 0.5 * g * dt * dt
        Ja = np.zeros((9, 27))  # [Rk(3), pk(3), vk(3), Rk1(3), pk1(3), vk1(3), bg(3), ba(3)]
        Ja[0:3, 0:3] = -Jri @ Rk1.T @ Rk
        Ja[0:3, 9:12] = Jri
        Ja[0:3, 18:21] = -Jri @ (Rk1.T @ Rk @ dR) @ J_R_bg
        Ja[3:6, 0:3] = hat(Rk.T @ w_v)
        Ja[3:6, 6:9] = -Rk.T
        Ja[3:6, 15:18] = Rk.T
        Ja[3:6, 18:21] = -J_v_bg
        Ja[3:6, 21:24] = -J_v_ba
        Ja[6:9, 0:3] = hat(Rk.T @ w_p)
        Ja[6:9, 3:6] = -Rk.T
        Ja[6:9, 6:9] = -Rk.T * dt
        Ja[6:9, 12:15] = Rk.T
        Ja[6:9, 18:21] = -J_p_bg
        Ja[6:9, 21:24] = -J_p_ba

        # FD: rotation perturbations on the manifold, others Euclidean
        Jfd = np.zeros((9, 27))
        eps = 1e-5
        for j, (idx, Rname) in enumerate([(0, "Rk"), (3, "Rk1")]):
            R = Rk if idx == 0 else Rk1
            for k in range(3):
                ph = np.zeros(3)
                ph[k] = eps
                xp = list(x0)
                xp[idx] = R @ so3_exp(ph)
                xm = list(x0)
                xm[idx] = R @ so3_exp(-ph)
                Jfd[:, j * 9 + k] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
        for j in range(27):
            if j in (0, 1, 2, 9, 10, 11) or j >= 24:  # rotation blocks handled above; cols 24..26 unused
                continue
            xp = list(x0)
            xm = list(x0)
            if j < 18:
                idx = (j - 3) // 3 + 1  # pk/vk/Rk1/pk1/vk1 block index (1..5)
                sub = j - 3 - 3 * (idx - 1)
                xp[idx] = x0[idx].copy()
                xm[idx] = x0[idx].copy()
                xp[idx][sub] += eps
                xm[idx][sub] -= eps
            else:  # bias blocks
                idx = 6 if j < 21 else 7
                sub = j - (18 if j < 21 else 21)
                xp[idx] = x0[idx].copy()
                xm[idx] = x0[idx].copy()
                xp[idx][sub] += eps
                xm[idx][sub] -= eps
            Jfd[:, j] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
        err = np.abs(Ja - Jfd)
        if err.max() > 1e-4:
            ok = False
            print(f"  [FAIL] trial {trial}: max jacobian error {err.max():.3e} at {np.unravel_index(err.argmax(), err.shape)}")
            print("  Ja rows 0-2 (eR) cols 0-12:\n", np.round(Ja[0:3, 0:12], 3))
            print("  Jfd rows 0-2 (eR) cols 0-12:\n", np.round(Jfd[0:3, 0:12], 3))
            print("  Ja rows 3-5 (ev) cols 0-12:\n", np.round(Ja[3:6, 0:12], 3))
            print("  Jfd rows 3-5 (ev) cols 0-12:\n", np.round(Jfd[3:6, 0:12], 3))
    print("  pre-integration factor Jacobians:", "OK" if ok else "FAILED")
    return ok


def validate_odom_factor_jacobians():
    print("=" * 72)
    print("A4. LiDAR odometry factor Jacobians")
    print("=" * 72)
    rng = np.random.default_rng(13)
    ok = True
    for trial in range(5):
        Rk = so3_exp(rng.normal(0, 0.05, 3))
        pk = rng.normal(0, 1, 3)
        Rk1 = so3_exp(rng.normal(0, 0.05, 3))
        pk1 = rng.normal(0, 1, 3)
        Rrel = so3_exp(rng.normal(0, 0.02, 3))
        prel = rng.normal(0, 0.05, 3)

        def f(x):
            Rk_, pk_, Rk1_, pk1_ = x
            eR = so3_log(Rrel.T @ Rk_.T @ Rk1_)
            ep = Rrel.T @ Rk_.T @ (pk1_ - pk_) - prel
            return np.concatenate([eR, ep])

        x0 = (Rk, pk, Rk1, pk1)
        Ja = np.zeros((6, 18))
        eR = so3_log(Rrel.T @ Rk.T @ Rk1)
        Jri = inv_right_jacobian(eR)
        q = pk1 - pk
        Ja[0:3, 0:3] = -Jri @ Rk1.T @ Rk
        Ja[0:3, 9:12] = Jri
        Ja[3:6, 0:3] = Rrel.T @ hat(Rk.T @ q)  # d ep / d phi_k = Rrel^T [Rk^T q]x
        Ja[3:6, 3:6] = -Rrel.T @ Rk.T
        Ja[3:6, 12:15] = Rrel.T @ Rk.T
        Jfd = np.zeros((6, 18))
        eps = 1e-6
        for j in range(4):
            for k in range(3):
                if j == 0:  # Rk (manifold)
                    ph = np.zeros(3)
                    ph[k] = eps
                    xp = list(x0)
                    xp[0] = Rk @ so3_exp(ph)
                    xm = list(x0)
                    xm[0] = Rk @ so3_exp(-ph)
                    Jfd[:, k] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
                elif j == 1:
                    xp = list(x0)
                    xm = list(x0)
                    xp[1] = pk.copy()
                    xm[1] = pk.copy()
                    xp[1][k] += eps
                    xm[1][k] -= eps
                    Jfd[:, 3 + k] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
                elif j == 2:  # Rk1 manifold
                    ph = np.zeros(3)
                    ph[k] = eps
                    xp = list(x0)
                    xp[2] = Rk1 @ so3_exp(ph)
                    xm = list(x0)
                    xm[2] = Rk1 @ so3_exp(-ph)
                    Jfd[:, 9 + k] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
                else:
                    xp = list(x0)
                    xm = list(x0)
                    xp[3] = pk1.copy()
                    xm[3] = pk1.copy()
                    xp[3][k] += eps
                    xm[3][k] -= eps
                    Jfd[:, 12 + k] = (f(tuple(xp)) - f(tuple(xm))) / (2 * eps)
        err = np.abs(Ja - Jfd)
        if err.max() > 1e-4:
            ok = False
            print(f"  [FAIL] trial {trial}: max jacobian error {err.max():.3e}")
        else:
            print(f"  trial {trial}: max jacobian error {err.max():.3e}  OK")
    print("  odometry factor Jacobians:", "OK" if ok else "FAILED")
    return ok


def validate_schur():
    print("=" * 72)
    print("A5. Schur-complement marginalization (information form)")
    print("=" * 72)
    rng = np.random.default_rng(17)
    # random SPD information matrix A, solve system, check the marginal block
    A = rng.normal(0, 1, (12, 12))
    A = A @ A.T + np.eye(12)
    b = rng.normal(0, 1, 12)
    # full solution
    x_full = np.linalg.solve(A, b)
    # marginalize out block 0 (first 3 dims)
    Abb = A[0:3, 0:3]
    Abr = A[0:3, 3:12]
    Arb = A[3:12, 0:3]
    Arr = A[3:12, 3:12]
    Amarg = Arr - Arb @ np.linalg.solve(Abb, Abr)
    bmarg = b[3:12] - Arb @ np.linalg.solve(Abb, b[0:3])
    # the marginal solution must equal the full solution on the remaining dims
    x_marg = np.linalg.solve(Amarg, bmarg)
    err = np.abs(x_marg - x_full[3:12]).max()
    ok = err < 1e-9
    print(f"  marginal vs full solution max error: {err:.3e}  {'OK' if ok else 'FAILED'}")
    return ok


# ---------------------------------------------------------------------------
# Part B: synthetic sequence - ESKF frontend vs sliding-window factor graph
# ---------------------------------------------------------------------------

GRAV = np.array([0.0, 0.0, 9.81])


def make_sequence(dur=60.0, dt_imu=0.005, dt_kf=0.1, seed=0):
    """Ground-truth trajectory + synthetic IMU + noisy keyframe poses (simulated LIO)."""
    rng = np.random.default_rng(seed)
    n_imu = int(dur / dt_imu) + 1
    n_kf = int(dur / dt_kf) + 1
    t_imu = np.arange(n_imu) * dt_imu
    t_kf = np.arange(n_kf) * dt_kf

    # GT trajectory: circular + climbing + yaw oscillation
    R = 12.0
    w = 2 * np.pi / 40.0  # full circle every 40 s
    climb = 0.15
    p = np.stack([R * np.cos(w * t_kf), R * np.sin(w * t_kf), climb * t_kf], axis=1)
    v = np.stack([-R * w * np.sin(w * t_kf), R * w * np.cos(w * t_kf), climb * np.ones_like(t_kf)], axis=1)
    a = np.stack([-R * w * w * np.cos(w * t_kf), -R * w * w * np.sin(w * t_kf), np.zeros_like(t_kf)], axis=1)
    yaw = 0.3 * np.cos(0.5 * t_kf)
    roll = 0.1 * np.sin(0.3 * t_kf)
    pitch = 0.05 * np.cos(0.4 * t_kf)
    R_gt = np.zeros((n_kf, 3, 3))
    for i in range(n_kf):
        cy, sy = np.cos(yaw[i]), np.sin(yaw[i])
        cr, sr = np.cos(roll[i]), np.sin(roll[i])
        cp, sp = np.cos(pitch[i]), np.sin(pitch[i])
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
        R_gt[i] = Rz @ Ry @ Rx

    # true biases + noise scales
    bg_true = np.array([0.005, -0.003, 0.002])
    ba_true = np.array([0.05, -0.08, 0.03])
    sg = 0.02 / np.sqrt(dt_imu) * np.sqrt(dt_imu)  # per-sample std
    sa = 0.5 / np.sqrt(dt_imu) * np.sqrt(dt_imu)
    # per-sample std with the continuous sigma scaled by sqrt(dt)
    sg = 0.02 * np.sqrt(dt_imu)
    sa = 0.5 * np.sqrt(dt_imu)

    # IMU at the keyframe rate interpolated
    def interp(arr_t, arr_v, tq):
        return np.array([np.interp(tq, arr_t, arr_v[:, k]) for k in range(3)]).T

    p_i = interp(t_kf, p, t_imu)
    v_i = interp(t_kf, v, t_imu)
    a_i = interp(t_kf, a, t_imu)

    # body angular velocity from the GT attitude: R(t+dt) = R(t) Exp(w_b dt)
    # (Euler-angle derivatives are NOT the body rates; compute them numerically)
    yaw_i = np.interp(t_imu, t_kf, yaw)
    roll_i = np.interp(t_imu, t_kf, roll)
    pitch_i = np.interp(t_imu, t_kf, pitch)
    R_i = np.zeros((n_imu, 3, 3))
    for i in range(n_imu):
        cy, sy = np.cos(yaw_i[i]), np.sin(yaw_i[i])
        cr, sr = np.cos(roll_i[i]), np.sin(roll_i[i])
        cp, sp = np.cos(pitch_i[i]), np.sin(pitch_i[i])
        Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
        Rx = np.array([[1, 0, 0], [0, cr, -sr], [0, sr, cr]])
        Ry = np.array([[cp, 0, sp], [0, 1, 0], [-sp, 0, cp]])
        R_i[i] = Rz @ Ry @ Rx
    w_b = np.zeros((n_imu, 3))
    for i in range(n_imu - 1):
        w_b[i] = so3_log(R_i[i].T @ R_i[i + 1]) / dt_imu
    w_b[-1] = w_b[-2]

    acc_m = np.zeros_like(a_i)
    gyr_m = np.zeros_like(a_i)
    for i in range(n_imu):
        a_spec = R_i[i].T @ (a_i[i] - GRAV)  # specific force in body frame
        acc_m[i] = a_spec + ba_true + rng.normal(0, sa, 3)
        gyr_m[i] = w_b[i] + bg_true + rng.normal(0, sg, 3)

    # noisy keyframe poses (simulated LIO output; same noise as the odom factor)
    meas_R = np.zeros((n_kf, 3, 3))
    meas_p = np.zeros((n_kf, 3))
    meas_v = np.zeros((n_kf, 3))
    for i in range(n_kf):
        meas_R[i] = R_gt[i] @ so3_exp(rng.normal(0, 0.01, 3))
        meas_p[i] = p[i] + rng.normal(0, 0.05, 3)
        meas_v[i] = v[i] + rng.normal(0, 0.1, 3)
    return t_kf, t_imu, p, R_gt, v, meas_p, meas_R, meas_v, acc_m, gyr_m, bg_true, ba_true


def run_eskf(t_kf, t_imu, meas_p, meas_R, acc_m, gyr_m, dt_imu):
    """Frontend ESKF: IMU propagation (same F_x/cov_w as IMU_Processing.cpp) +
    keyframe pose updates (information-form gain, same as VoxelMapManager)."""
    n = len(t_kf)
    # state: [theta(3), p(3), v(3), bg(3), ba(3)]  (gravity known)
    x = np.zeros(15)
    P = np.eye(15) * 0.01
    P[9:15, 9:15] *= 1e-3
    R = np.eye(3)
    p = np.zeros(3)
    v = np.zeros(3)
    bg = np.zeros(3)
    ba = np.zeros(3)
    traj = np.zeros((n, 7))
    n_imu_per_kf = int((t_kf[1] - t_kf[0]) / dt_imu)

    for k in range(n):
        # ---- IMU propagation over [t_kf[k-1], t_kf[k]] ----
        if k > 0:
            i0 = (k - 1) * n_imu_per_kf
            i1 = k * n_imu_per_kf
            for i in range(i0, min(i1, len(t_imu) - 1)):
                dt = t_imu[i + 1] - t_imu[i]
                acc = acc_m[i] - ba
                w = gyr_m[i] - bg
                Exp_f = so3_exp(w * dt)
                # nominal
                acc_imu = R @ acc + GRAV
                p = p + v * dt + 0.5 * acc_imu * dt * dt
                v = v + acc_imu * dt
                R = R @ Exp_f
                # error-state Jacobian / noise (mirrors IMU_Processing.cpp)
                F = np.eye(15)
                F[0:3, 0:3] = so3_exp(-w * dt)
                F[0:3, 9:12] = -np.eye(3) * dt
                F[3:6, 6:9] = np.eye(3) * dt
                F[6:9, 0:3] = -R @ hat(acc) * dt
                F[6:9, 12:15] = -R * dt
                Q = np.zeros((15, 15))
                # continuous noise densities sigma -> per-step variance = sigma^2 * dt
                Q[0:3, 0:3] = (0.02 ** 2) * dt * np.eye(3)
                Q[6:9, 6:9] = R @ ((0.5 ** 2) * dt * np.eye(3)) @ R.T
                Q[9:12, 9:12] = (0.0001 ** 2) * dt * np.eye(3)
                Q[12:15, 12:15] = (0.0005 ** 2) * dt * np.eye(3)
                P = F @ P @ F.T + Q
        # ---- keyframe pose update (simulated LIO) ----
        Rm, pm = meas_R[k], meas_p[k]
        z = np.concatenate([so3_log(R.T @ Rm), pm - p])
        H = np.zeros((6, 15))
        H[0:3, 0:3] = np.eye(3)
        H[3:6, 3:6] = np.eye(3)
        Rm_cov = np.diag([0.01 ** 2] * 3 + [0.05 ** 2] * 3)
        # information-form gain (same as the iEKF in voxel_map.cpp)
        K = np.linalg.solve(H.T @ np.linalg.solve(Rm_cov, H) + np.linalg.inv(P), H.T @ np.linalg.solve(Rm_cov, np.eye(6)))
        dx = K @ z
        R = R @ so3_exp(dx[0:3])
        p = p + dx[3:6]
        v = v + dx[6:9]
        bg = bg + dx[9:12]
        ba = ba + dx[12:15]
        P = (np.eye(15) - K @ H) @ P
        traj[k] = [t_kf[k], p[0], p[1], p[2], *so3_log(R)]
    return traj


def run_factor_graph(t_kf, t_imu, meas_p, meas_R, meas_v, acc_m, gyr_m, dt_imu, window=25, marginalize=False, bias0=None,
                     freeze_bias=False, use_preint=True, verbose=False):
    """Sliding-window factor graph: odometry factors + IMU pre-integration
    factors, Gauss-Newton. `marginalize=True` keeps a Schur-complement prior of
    the dropped oldest keyframe (same as the C++ backend), otherwise the oldest
    keyframe is simply dropped."""
    n = len(t_kf)
    n_imu_per_kf = int((t_kf[1] - t_kf[0]) / dt_imu)
    # window nodes: list of dict(R, p, v); preint lists parallel
    win_R, win_p, win_v = [], [], []
    win_v_ref = []  # frontend velocity reference for the v prior
    win_preint = []  # preint[i] between node i-1 and i
    win_k = []  # global keyframe index of each window node (for the odom factor)
    bg = np.zeros(3) if bias0 is None else np.array(bias0[0:3])
    ba = np.zeros(3) if bias0 is None else np.array(bias0[3:6])
    # marginalized prior (fixed linearization point on the new first node + bias)
    have_prior = False
    prior_A = np.zeros((15, 15))
    prior_b = np.zeros(15)
    prior_R0 = np.eye(3)
    prior_p0 = np.zeros(3)
    prior_v0 = np.zeros(3)
    prior_bg = np.zeros(3)
    prior_ba = np.zeros(3)
    last_A = None
    last_b = None
    out = np.zeros((n, 7))
    out_t = np.zeros(n)
    bias_est = np.zeros((n, 6))
    kf_stats = []

    def optimize():
        nonlocal bg, ba, have_prior, last_A, last_b
        N = len(win_R)
        if N < 2:
            kf_stats.append(0.0)
            return
        dim = 9 * N + 6

        # weighted squared residuals of the current state (for the line search);
        # NOTE: must use the SAME robust weights (wf) as the A/b construction,
        # otherwise the GN step minimizes a different objective than the one
        # the line search evaluates and every step gets rejected.
        def state_cost(bg_t, ba_t):
            cost = 0.0
            if have_prior:
                r15 = np.concatenate([so3_log(win_R[0].T @ prior_R0), win_p[0] - prior_p0, win_v[0] - prior_v0,
                                      bg_t - prior_bg, ba_t - prior_ba])
                cost += r15 @ prior_A @ r15
            for i in range(1, N):
                Rk, pk, vk = win_R[i - 1], win_p[i - 1], win_v[i - 1]
                Rk1, pk1, vk1 = win_R[i], win_p[i], win_v[i]
                ka, kb = win_k[i - 1], win_k[i]
                Rrel = meas_R[ka].T @ meas_R[kb]
                prel = meas_R[ka].T @ (meas_p[kb] - meas_p[ka])
                eR = so3_log(Rrel.T @ Rk.T @ Rk1)
                ep = Rrel.T @ Rk.T @ (pk1 - pk) - prel
                r6 = np.concatenate([eR, ep])
                W6 = np.diag([1 / 0.01 ** 2] * 3 + [1 / 0.05 ** 2] * 3)
                maha6 = np.sqrt(r6 @ W6 @ r6)
                wf6 = 1.0 if maha6 < 1.5 else 1.5 / maha6
                cost += wf6 * (r6 @ W6 @ r6)
                pi = win_preint[i]
                if pi is not None and use_preint:
                    dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov, bg0, ba0, dt = pi
                    dbg = bg_t - bg0
                    dba = ba_t - ba0
                    dR_c = dR @ so3_exp(J_R_bg @ dbg)
                    dv_c = dv + J_v_bg @ dbg + J_v_ba @ dba
                    dp_c = dp + J_p_bg @ dbg + J_p_ba @ dba
                    eR = so3_log(dR_c.T @ Rk.T @ Rk1)
                    w_v = vk1 - vk - GRAV * dt
                    w_p = pk1 - pk - vk * dt - 0.5 * GRAV * dt * dt
                    ev = Rk.T @ w_v - dv_c
                    ep = Rk.T @ w_p - dp_c
                    r9 = np.concatenate([eR, ev, ep])
                    info = np.linalg.inv(cov + 1e-6 * np.eye(9))
                    maha9 = np.sqrt(r9 @ info @ r9)
                    wf9 = 1.0 if maha9 < 1.5 else 1.5 / maha9
                    cost += wf9 * (r9 @ info @ r9)
            for i in range(N):  # velocity prior (anchored at the frontend velocity)
                cost += 1e2 * np.dot(win_v[i] - win_v_ref[i], win_v[i] - win_v_ref[i])
            cost += 1e4 * np.dot(bg_t, bg_t) + 1e2 * np.dot(ba_t, ba_t)  # bias prior (bg tight, ba loose)
            return cost

        cur_cost = state_cost(bg, ba)
        for _ in range(12):
            A = np.zeros((dim, dim))
            b = np.zeros(dim)
            A[0:9, 0:9] += 1e4 * np.eye(9)  # gauge prior (sigma ~ 1 cm/1e-4 rad, anchors node 0)
            # bias prior: bg tight (sigma 0.01 rad/s, frontend estimate is good),
            # ba loose (sigma 0.1 m/s^2) - a too-loose bg prior lets the weakly
            # observable bias absorb all window errors (overfitting)
            A[9 * N : 9 * N + 3, 9 * N : 9 * N + 3] += 1e4 * np.eye(3)
            A[9 * N + 3 : 9 * N + 6, 9 * N + 3 : 9 * N + 6] += 1e2 * np.eye(3)
            for ni in range(N):  # velocity prior (frontend ESKF velocity, sigma ~ 0.1 m/s)
                A[9 * ni + 6 : 9 * ni + 9, 9 * ni + 6 : 9 * ni + 9] += 1e2 * np.eye(3)
            if have_prior:  # marginalized prior on node0 + bias (fixed linearization point)
                r15 = np.concatenate([so3_log(win_R[0].T @ prior_R0), win_p[0] - prior_p0, win_v[0] - prior_v0,
                                      bg - prior_bg, ba - prior_ba])
                J15 = np.eye(15)
                J15[0:3, 0:3] = -np.eye(3)
                # J: 15x15, rows = residual dims, cols = state perturbations (node0 9 + bias 6)
                Jc = J15[:, 0:9]   # cols 0..8  -> node0
                Jb = J15[:, 9:15]  # cols 9..14 -> bias
                A[0:9, 0:9] += Jc.T @ prior_A @ Jc
                A[0:9, 9 * N : 9 * N + 6] += Jc.T @ prior_A @ Jb
                A[9 * N : 9 * N + 6, 0:9] += Jb.T @ prior_A @ Jc
                A[9 * N : 9 * N + 6, 9 * N : 9 * N + 6] += Jb.T @ prior_A @ Jb
                b[0:9] += Jc.T @ (prior_A @ r15 - prior_b)
                b[9 * N : 9 * N + 6] += Jb.T @ (prior_A @ r15 - prior_b)
            for i in range(1, N):
                Rk, pk, vk = win_R[i - 1], win_p[i - 1], win_v[i - 1]
                Rk1, pk1, vk1 = win_R[i], win_p[i], win_v[i]
                # ---- odometry factor ----
                # NOTE: use the measurement of the GLOBAL keyframe the node
                # corresponds to (win_k[]); indexing meas_R by the window index
                # i is WRONG once the window slides (kf 11+ in the sim)
                ka, kb = win_k[i - 1], win_k[i]
                Rrel = meas_R[ka].T @ meas_R[kb]
                prel = meas_R[ka].T @ (meas_p[kb] - meas_p[ka])
                eR = so3_log(Rrel.T @ Rk.T @ Rk1)
                ep = Rrel.T @ Rk.T @ (pk1 - pk) - prel
                r = np.concatenate([eR, ep])
                Jri = inv_right_jacobian(eR)
                q = pk1 - pk
                J = np.zeros((6, 18))
                J[0:3, 0:3] = -Jri @ Rk1.T @ Rk
                J[0:3, 9:12] = Jri
                J[3:6, 0:3] = Rrel.T @ hat(Rk.T @ q)  # d ep / d phi_k = Rrel^T [Rk^T q]x
                J[3:6, 3:6] = -Rrel.T @ Rk.T
                J[3:6, 12:15] = Rrel.T @ Rk.T
                W = np.diag([1 / 0.01 ** 2] * 3 + [1 / 0.05 ** 2] * 3)
                maha = np.sqrt(r @ W @ r)
                wf = 1.0 if maha < 1.5 else 1.5 / maha
                sw = np.sqrt(wf)
                for c, gi in enumerate([i - 1, i]):
                    Jc = J[:, 9 * c : 9 * c + 9]
                    JcW = Jc.T @ W
                    A[9 * gi : 9 * gi + 9, 9 * gi : 9 * gi + 9] += sw * sw * (JcW @ Jc)
                    b[9 * gi : 9 * gi + 9] += sw * (JcW @ r)
                    Jd = J[:, 9 * (1 - c) : 9 * (1 - c) + 9]
                    gj = [i, i - 1][c]
                    if gj > gi:
                        JcWd = JcW @ Jd
                        A[9 * gi : 9 * gi + 9, 9 * gj : 9 * gj + 9] += sw * sw * JcWd
                        A[9 * gj : 9 * gj + 9, 9 * gi : 9 * gi + 9] += sw * sw * JcWd.T
                # ---- pre-integration factor ----
                pi = win_preint[i]
                if pi is not None and use_preint:
                    dR, dv, dp, J_R_bg, J_v_bg, J_v_ba, J_p_bg, J_p_ba, cov, bg0, ba0, dt = pi
                    dbg = bg - bg0
                    dba = ba - ba0
                    dR_c = dR @ so3_exp(J_R_bg @ dbg)
                    dv_c = dv + J_v_bg @ dbg + J_v_ba @ dba
                    dp_c = dp + J_p_bg @ dbg + J_p_ba @ dba
                    eR = so3_log(dR_c.T @ Rk.T @ Rk1)
                    w_v = vk1 - vk - GRAV * dt
                    w_p = pk1 - pk - vk * dt - 0.5 * GRAV * dt * dt
                    ev = Rk.T @ w_v - dv_c
                    ep = Rk.T @ w_p - dp_c
                    r = np.concatenate([eR, ev, ep])
                    Jri = inv_right_jacobian(eR)
                    J = np.zeros((9, 27))
                    J[0:3, 0:3] = -Jri @ Rk1.T @ Rk
                    J[0:3, 9:12] = Jri
                    J[0:3, 18:21] = -Jri @ (Rk1.T @ Rk @ dR) @ J_R_bg
                    J[3:6, 0:3] = hat(Rk.T @ w_v)
                    J[3:6, 6:9] = -Rk.T
                    J[3:6, 15:18] = Rk.T
                    J[3:6, 18:21] = -J_v_bg
                    J[3:6, 21:24] = -J_v_ba
                    J[6:9, 0:3] = hat(Rk.T @ w_p)
                    J[6:9, 3:6] = -Rk.T
                    J[6:9, 6:9] = -Rk.T * dt
                    J[6:9, 12:15] = Rk.T
                    J[6:9, 18:21] = -J_p_bg
                    J[6:9, 21:24] = -J_p_ba
                    info = np.linalg.inv(cov + 1e-6 * np.eye(9))
                    maha = np.sqrt(r @ info @ r)
                    wf = 1.0 if maha < 1.5 else 1.5 / maha
                    sw = np.sqrt(wf)
                    # node blocks (9 dims each)
                    for c, gi in enumerate([i - 1, i]):
                        Jc = J[:, 9 * c : 9 * c + 9]
                        JcW = Jc.T @ info
                        A[9 * gi : 9 * gi + 9, 9 * gi : 9 * gi + 9] += sw * sw * (JcW @ Jc)
                        b[9 * gi : 9 * gi + 9] += sw * (JcW @ r)
                        Jd = J[:, 9 * (1 - c) : 9 * (1 - c) + 9]
                        gj = [i, i - 1][c]
                        if gj > gi:
                            JcWd = JcW @ Jd
                            A[9 * gi : 9 * gi + 9, 9 * gj : 9 * gj + 9] += sw * sw * JcWd
                            A[9 * gj : 9 * gj + 9, 9 * gi : 9 * gi + 9] += sw * sw * JcWd.T
                    # bias block (6 dims only: bg+ba; offset 9*N, after all nodes)
                    gi = N
                    Jb = J[:, 18:24]
                    JbW = Jb.T @ info
                    A[9 * gi : 9 * gi + 6, 9 * gi : 9 * gi + 6] += sw * sw * (JbW @ Jb)
                    b[9 * gi : 9 * gi + 6] += sw * (JbW @ r)
                    for c, gi2 in enumerate([i - 1, i]):
                        Jn = J[:, 9 * c : 9 * c + 9]
                        JnW = Jn.T @ info
                        JnWJb = JnW @ Jb
                        A[9 * gi2 : 9 * gi2 + 9, 9 * gi : 9 * gi + 6] += sw * sw * JnWJb
                        A[9 * gi : 9 * gi + 6, 9 * gi2 : 9 * gi2 + 9] += sw * sw * JnWJb.T
            # ---- Levenberg-Marquardt step: accept only if the (robust) cost
            # decreases, otherwise increase the damping and re-solve ----
            D = np.sqrt(np.diag(A))
            D[D < 1e-9] = 1.0
            Asc = A / np.outer(D, D)
            lam = max(1e-8, 1e-6 * np.diag(Asc).max())
            for _lm in range(8):
                # NOTE: the GN step is delta = -(A^-1 b); b = J^T W r points
                # UPHILL, so the minus sign is essential (without it the
                # residuals double and the line search rejects every step)
                delta = -np.linalg.solve(Asc + lam * np.eye(dim), b / D) / D
                if not np.all(np.isfinite(delta)):
                    lam *= 10.0
                    continue
                # bias trust region: the bias is weakly observable, a full GN
                # step drives it to absurd values that wreck the preintegration
                bnorm = np.linalg.norm(delta[9 * N : 9 * N + 6])
                if bnorm > 0.02:
                    delta[9 * N : 9 * N + 6] *= 0.02 / bnorm
                if freeze_bias:
                    delta[9 * N : 9 * N + 6] *= 0.0
                for i in range(N):
                    win_R[i] = win_R[i] @ so3_exp(delta[9 * i : 9 * i + 3])
                    win_p[i] = win_p[i] + delta[9 * i + 3 : 9 * i + 6]
                    win_v[i] = win_v[i] + delta[9 * i + 6 : 9 * i + 9]
                bg_t = bg + delta[9 * N : 9 * N + 3]
                ba_t = ba + delta[9 * N + 3 : 9 * N + 6]
                new_cost = state_cost(bg_t, ba_t)
                if verbose and k in (10, 11) and _ <= 4:
                    print(f"  [DBG] kf {k} iter {_}: |delta|={np.linalg.norm(delta):.4f} "
                          f"dp_last={np.round(delta[-12:-6], 3)} cur={cur_cost:.3f} new={new_cost:.3f}")
                if new_cost < cur_cost:
                    bg, ba = bg_t, ba_t
                    cur_cost = new_cost
                    lam = max(lam * 0.3, 1e-12)
                    break
                for i in range(N):
                    win_R[i] = win_R[i] @ so3_exp(-delta[9 * i : 9 * i + 3])
                    win_p[i] = win_p[i] - delta[9 * i + 3 : 9 * i + 6]
                    win_v[i] = win_v[i] - delta[9 * i + 6 : 9 * i + 9]
                lam *= 10.0
            else:
                break  # no step decreased the cost
            if np.linalg.norm(delta) < 1e-6:
                break
        last_A = A
        last_b = b
        kf_stats.append(np.linalg.norm(delta))

    for k in range(n):
        # pre-integrate the IMU between the previous keyframe and this one
        pi = None
        if k > 0:
            i0 = (k - 1) * n_imu_per_kf
            i1 = k * n_imu_per_kf
            samples = []
            for i in range(i0, min(i1, len(t_imu) - 1)):
                samples.append((t_imu[i], acc_m[i], gyr_m[i]))
            if samples:
                pi = preintegrate(samples, bg, ba)
        win_R.append(meas_R[k].copy())
        win_p.append(meas_p[k].copy())
        win_v.append(meas_v[k].copy() if meas_v is not None else np.zeros(3))
        win_v_ref.append(meas_v[k].copy() if meas_v is not None else np.zeros(3))
        win_preint.append(pi)
        win_k.append(k)
        optimize()
        if len(win_R) > window:
            if marginalize and last_A is not None:
                # Schur-complement the oldest node out; keep a fixed-linearization
                # prior on the new first node pose+vel and the biases (15x15)
                # (last_A is from the optimize() just above, dimension 9*Nw+6)
                Nw = len(win_R)
                dimw = 9 * Nw + 6
                m = dimw - 9
                Abb = last_A[0:9, 0:9]
                Abr = last_A[0:9, 9:dimw]
                Arb = last_A[9:dimw, 0:9]
                Arr = last_A[9:dimw, 9:dimw]
                bb = last_b[0:9]
                br = last_b[9:dimw]
                Amarg = Arr - Arb @ np.linalg.solve(Abb, Abr)
                bmarg = br - Arb @ np.linalg.solve(Abb, bb)
                prior_A = np.zeros((15, 15))
                prior_A[0:9, 0:9] = Amarg[0:9, 0:9]
                prior_A[0:9, 9:15] = Amarg[0:9, m - 6 : m]
                prior_A[9:15, 0:9] = Amarg[m - 6 : m, 0:9]
                prior_A[9:15, 9:15] = Amarg[m - 6 : m, m - 6 : m]
                prior_b = np.concatenate([bmarg[0:9], bmarg[m - 6 : m]])
                prior_R0 = win_R[1].copy()
                prior_p0 = win_p[1].copy()
                prior_v0 = win_v[1].copy()
                prior_bg = bg.copy()
                prior_ba = ba.copy()
                have_prior = True
            win_R.pop(0)
            win_p.pop(0)
            win_v.pop(0)
            win_v_ref.pop(0)
            win_preint.pop(0)
            win_k.pop(0)
        out[k] = [t_kf[k], win_p[-1][0], win_p[-1][1], win_p[-1][2], *so3_log(win_R[-1])]
        out_t[k] = t_kf[k]
        bias_est[k] = np.concatenate([bg, ba])
    return out, bias_est


def align_traj(est, gt):
    """Umeyama (similarity) alignment, 6-DOF pose, returns aligned positions."""
    pe = est[:, 1:4]
    pg = gt[:, 1:4]
    me = pe.mean(0)
    mg = pg.mean(0)
    Pe = pe - me
    Pg = pg - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return R, s, me, mg


def rpe_rmse(est, gt, interval=1):
    de = np.diff(est[:, 1:4], axis=0)
    dg = np.diff(gt[:, 1:4], axis=0)
    err = np.linalg.norm(de - dg, axis=1)
    return np.sqrt(np.mean(err ** 2))


def run_sim(seed=0, window=25, dur=60.0):
    print("=" * 72)
    print(f"B. synthetic sequence: ESKF frontend vs sliding-window factor graph")
    print(f"   seed={seed}, window={window}, dur={dur}s")
    print("=" * 72)
    t_kf, t_imu, p_gt, R_gt, v_gt, meas_p, meas_R, meas_v, acc_m, gyr_m, bg_true, ba_true = make_sequence(seed=seed, dur=dur)

    # B1 frontend ESKF
    t0 = time.perf_counter()
    traj_eskf = run_eskf(t_kf, t_imu, meas_p, meas_R, acc_m, gyr_m, 0.005)
    t_eskf = time.perf_counter() - t0

    # B2 factor graph
    t0 = time.perf_counter()
    traj_fg, bias_fg = run_factor_graph(t_kf, t_imu, meas_p, meas_R, meas_v, acc_m, gyr_m, 0.005, window=window)
    t_fg = time.perf_counter() - t0

    gt = np.column_stack([t_kf, p_gt])

    def metrics(traj, name):
        R, s, me, mg = align_traj(traj, gt)
        pe = (traj[:, 1:4] - me) @ R.T
        pg = gt[:, 1:4] - mg
        ape = np.linalg.norm(pe - pg, axis=1)
        rpe = rpe_rmse(traj, gt)
        print(f"  {name:12s}: ATE RMSE {np.sqrt(np.mean(ape ** 2)) * 100:.2f} cm | "
              f"ATE mean {np.mean(ape) * 100:.2f} cm | max {np.max(ape) * 100:.2f} cm | RPE {rpe * 100:.2f} cm")
        return ape

    ape_eskf = metrics(traj_eskf, "ESKF")
    ape_fg = metrics(traj_fg, "factor-graph")

    # bias convergence (factor-graph estimate vs ground truth)
    bg_err = np.linalg.norm(bias_fg[-1, 0:3] - bg_true)
    ba_err = np.linalg.norm(bias_fg[-1, 3:6] - ba_true)
    print(f"\n  factor-graph bias estimate at end: bg_err {bg_err * 1000:.2f} mrad/s "
          f"(true {np.round(bg_true, 4)}), ba_err {ba_err * 1000:.1f} mm/s^2 (true {np.round(ba_true, 3)})")

    n_kf = len(t_kf)
    print(f"\n  per-keyframe runtime: ESKF {t_eskf / n_kf * 1000:.3f} ms | factor-graph {t_fg / n_kf * 1000:.3f} ms "
          f"({t_fg / t_eskf:.1f}x)")
    print(f"  factor-graph smoothing lag: {window} keyframes "
          f"({window * (t_kf[1] - t_kf[0]):.1f} s of data) -> output is delayed by the window")

    os.makedirs(OUT_DIR, exist_ok=True)
    txt = os.path.join(OUT_DIR, f"sim_compare_seed{seed}_w{window}.txt")
    with open(txt, "w") as f:
        f.write("ESKF_vs_factor_graph comparison (seed=%d, window=%d)\n" % (seed, window))
        f.write(f"ESKF ATE RMSE {np.sqrt(np.mean(ape_eskf ** 2)):.4f} m\n")
        f.write(f"FG   ATE RMSE {np.sqrt(np.mean(ape_fg ** 2)):.4f} m\n")
        f.write(f"ESKF RPE {rpe_rmse(traj_eskf, gt):.4f} m\n")
        f.write(f"FG   RPE {rpe_rmse(traj_fg, gt):.4f} m\n")
        f.write(f"runtime per keyframe: ESKF {t_eskf / n_kf * 1000:.4f} ms, FG {t_fg / n_kf * 1000:.4f} ms\n")
    print(f"  results written to {txt}")

    if HAS_MPL:
        fig, ax = plt.subplots(1, 2, figsize=(12, 4.5))
        ax[0].plot(p_gt[:, 0], p_gt[:, 1], "k-", lw=2, label="GT")
        ax[0].plot(traj_eskf[:, 1], traj_eskf[:, 2], "b--", lw=1, label="ESKF")
        ax[0].plot(traj_fg[:, 1], traj_fg[:, 2], "r-", lw=1, label="factor-graph")
        ax[0].set_title("trajectory (XY)")
        ax[0].legend()
        ax[1].plot(t_kf, ape_eskf * 100, "b--", label="ESKF")
        ax[1].plot(t_kf, ape_fg * 100, "r-", label="factor-graph")
        ax[1].set_title("APE vs time (cm)")
        ax[1].legend()
        fig.tight_layout()
        fig.savefig(os.path.join(OUT_DIR, f"sim_compare_seed{seed}_w{window}.png"))
        print(f"  plot saved to {os.path.join(OUT_DIR, f'sim_compare_seed{seed}_w{window}.png')}")
    return ape_eskf, ape_fg


def run_sweep(seed=0, dur=60.0):
    """Window-size / marginalization sensitivity: accuracy vs latency trade-off."""
    print("=" * 72)
    print("B2. window-size & marginalization sensitivity (seed=%d, dur=%.0fs)" % (seed, dur))
    print("=" * 72)
    t_kf, t_imu, p_gt, R_gt, v_gt, meas_p, meas_R, meas_v, acc_m, gyr_m, bg_true, ba_true = make_sequence(seed=seed, dur=dur)
    gt = np.column_stack([t_kf, p_gt])
    print(f"{'window':>8}{'marg':>6}{'ATE_rmse':>12}{'ATE_max':>12}{'RPE':>10}{'ms/kf':>10}")
    rows = []
    for window in (10, 25, 50):
        for marg in (False, True):
            t0 = time.perf_counter()
            traj, bias_fg = run_factor_graph(t_kf, t_imu, meas_p, meas_R, meas_v, acc_m, gyr_m, 0.005,
                                             window=window, marginalize=marg)
            dt_run = time.perf_counter() - t0
            R, s, me, mg = align_traj(traj, gt)
            pe = (traj[:, 1:4] - me) @ R.T
            pg = gt[:, 1:4] - mg
            e = np.linalg.norm(pe - pg, axis=1)
            rpe = rpe_rmse(traj, gt)
            ms = dt_run / len(t_kf) * 1000
            print(f"{window:>8}{str(marg):>6}{np.sqrt(np.mean(e ** 2)) * 100:>10.2f}cm"
                  f"{np.max(e) * 100:>10.2f}cm{rpe * 100:>8.2f}cm{ms:>10.2f}")
            rows.append((window, marg, np.sqrt(np.mean(e ** 2)), np.max(e), rpe, ms))
    os.makedirs(OUT_DIR, exist_ok=True)
    with open(os.path.join(OUT_DIR, f"sweep_seed{seed}.csv"), "w") as f:
        f.write("window,marginalize,ate_rmse_m,ate_max_m,rpe_m,ms_per_kf\n")
        for r in rows:
            f.write(f"{r[0]},{int(r[1])},{r[2]:.6f},{r[3]:.6f},{r[4]:.6f},{r[5]:.4f}\n")
    print("  ->", os.path.join(OUT_DIR, f"sweep_seed{seed}.csv"))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--validate", action="store_true", help="run Part A finite-difference validation")
    ap.add_argument("--sim", action="store_true", help="run Part B synthetic comparison")
    ap.add_argument("--sweep", action="store_true", help="run window/marginalization sensitivity")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--window", type=int, default=25)
    ap.add_argument("--dur", type=float, default=60.0, help="sequence duration in seconds (shorter = faster)")
    args = ap.parse_args()

    if not args.validate and not args.sim and not args.sweep:
        args.validate = True
        args.sim = True

    ok = True
    if args.validate:
        ok &= validate_preint_jacobians()
        ok &= validate_preint_factor_jacobians()
        ok &= validate_odom_factor_jacobians()
        ok &= validate_schur()
        print("\nPart A:", "ALL CHECKS PASSED" if ok else "SOME CHECKS FAILED")
    if args.sim:
        run_sim(seed=args.seed, window=args.window, dur=args.dur)
    if args.sweep:
        run_sweep(seed=args.seed, dur=args.dur)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
