# FAST-LIVO2 三项改进 — 评估指南（EVAL_GUIDE）

本指南说明如何在 Ubuntu 上编译、运行并对比三项改进（遮挡鲁棒、滑动窗口因子图后端、动态目标剔除）。

## 1. 构建

```bash
cd ~/catkin_ws/src
# 确保 fast_livo 是本仓库（含全部改进代码）
catkin_make -j4
source ~/catkin_ws/devel/setup.bash
```

依赖与官方版一致（PCL、OpenCV、Eigen、Sophus、vikit、evo 可选）。

## 2. 配置开关速查

所有改进默认关闭（`en: false`），原配置行为完全不变。改进版配置已生成：

| 文件 | 说明 |
|---|---|
| `config/avia_improved.yaml` | Livox Avia 全改进 |
| `config/great_campus01_improved.yaml` | GREAT campus-01（含 GNSS）全改进 |
| `config/NTU_VIRAL_improved.yaml` | NTU-VIRAL 全改进 |
| `launch/mapping_*_improved.launch` | 对应 launch（带 `seq_name:=` 参数） |

重新生成改进配置（如需改参数后）：
```bash
python3 scripts/make_improved_configs.py
```

各功能配置段：
- `occlusion:`（P1）——`en` 遮挡光线判定；`margin` 判定余量；`vio_en`/`vio_depth_ratio` VIO 深度一致性；`lio/robust_kernel_type`（0 无、1 Huber、2 Cauchy）与 `lio/robust_delta`、`lio/reject_gate_scale`。
- `dynamic_remove:`（P3）——`en`；`conflict_thresh` 冲突距离；`dynamic_ratio` 动态平面阈值；`max_idle_frames` 遗忘帧数；`pub_dyn_en` 发布 `/dyn_obj` 等。
- `factor_graph:`（P2）——`en`；`window_size` 窗口大小；`kf_dist`/`kf_rot_deg` 关键帧阈值；`marginalize` Schur 边缘化；`gnss_en` GNSS 位置因子；`thread_en` 独立线程；`robust_en`/`robust_delta` 因子鲁棒核。
- `evo/latency_en`——输出 `<seq>_latency.csv`。

## 3. 跑数（基线 vs 改进）

```bash
# 单序列（示例 NTU-VIRAL eee_01）
roslaunch fast_livo mapping_ouster_ntu.launch rviz:=false seq_name:=eee_01_base
# 另一个终端：
rosbag play ~/datasets/ntu_viral/eee_01.bag --clock

roslaunch fast_livo mapping_ntu_improved.launch rviz:=false seq_name:=eee_01_imp
rosbag play ~/datasets/ntu_viral/eee_01.bag --clock
```

批量对比（需先改 `run_eval.sh` 里的 `BAG_DIR` 指向你的数据集）：
```bash
./scripts/eval/run_eval.sh ntu    # NTU-VIRAL 9 序列
./scripts/eval/run_eval.sh great  # GREAT campus-01
```

## 4. 评估

脚本为纯 numpy 实现（Umeyama 对齐 + APE/RPE），无需 evo；装了 evo 则结果与
`evo_ape tum -a` 一致。

```bash
# P1 遮挡：基线 vs 改进
python3 scripts/eval/eval_occlusion.py \
    --gt  <gt.tum> \
    --base Log/result/<seq>_base.txt \
    --imp  Log/result/<seq>_imp.txt \
    --out  Log/eval/<seq>

# P2 因子图：前端 vs 后端 + 延迟统计
python3 scripts/eval/eval_graph.py \
    --gt      <gt.tum> \
    --front   Log/result/<seq>_imp.txt \
    --graph   Log/result/<seq>_imp_graph.txt \
    --latency Log/result/<seq>_imp_latency.csv \
    --out     Log/eval/<seq>

# P3 动态剔除统计
python3 scripts/eval/eval_dynamic.py \
    --dyn Log/result/<seq>_imp_dyn.csv \
    --out Log/eval/<seq>
```

输出：`Log/eval/<seq>/*.csv`（指标表）+ `*.png`（轨迹/误差/延迟图）。

## 5. 本机（Windows）数学验证

`scripts/sim/sim_filter_compare.py` 用有限差分验证因子图全部 Jacobian
（预积分偏置 Jacobian、位姿/速度/偏置因子 Jacobian、里程计因子 Jacobian、
Schur 边缘化），并给出合成数据上 ESKF 前端 vs 因子图后端的精度/耗时对比：

```bash
python scripts/sim/sim_filter_compare.py --validate   # Part A：数学验证
python scripts/sim/sim_filter_compare.py --sim        # Part B：精度/耗时对比
```

## 6. 已知说明

- 基线配置（原始 yaml）未改动，行为与官方一致。
- `dynamic_remove.en` 与 `occlusion.en` 一起用效果最佳（遮挡判定为动态统计提供证据）。
- 因子图后端输出滞后一个窗口（`window_size` 个关键帧），这是平滑的固有代价；
  前端 `/aft_mapped_to_init` 仍实时输出，二者对比见 `eval_graph.py` 延迟表。
