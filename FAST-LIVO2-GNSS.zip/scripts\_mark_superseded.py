#!/usr/bin/env python3
import io

p = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\campus01_MODES_REPORT.md"
t = io.open(p, encoding="utf-8", errors="replace").read()
i = t.find("\n")
io.open(p, "w", encoding="utf-8").write(
    "# >> SUPERSEDED << this report used the wrong reference trajectory (9.8 m) and a "
    "corrupted bag (ring field); all conclusions are void. See CAMPUS01_FINAL_REPORT.md"
    + t[i:]
)
print("done")
