#!/bin/bash
# A4: run the GNSS-only (single-RTK) and GNSS+IMU (RTK/IMU) baselines.
#
# Both modes run inside FAST-LIVO2 with LiDAR and camera disabled, so they are
# driven by GNSS epochs instead of LiDAR frames. They reuse the existing frame
# alignment, chi-square gating and online noise estimation, which is what makes
# them directly comparable with the LIVO / LIVO+RTK results.
#
# The config for each run is generated from the dataset's own yaml with sed
# (ASCII keys only, so the file stays UTF-8 clean - a previous PowerShell
# rewrite of a yaml silently re-encoded it and broke the launch).
#
# Usage:
#   run_gnss_modes.sh <campus01|campus02> <gnssonly|gnssimu> <tag> [rtk_bag] [dur_s]
export LANG=C.UTF-8
SEQ=$1; MODE=$2; TAG=$3; RTKBAG=${4:-}; DUROV=${5:-}
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo

case "$SEQ" in
  campus01) BAG=$HOME/datasets/GREAT/campus-01-full.bag; DUR=607; TOPIC=/gnss_rtk ;;
  campus02) BAG=$HOME/datasets/GREAT/campus-02.bag;      DUR=806; TOPIC=/gnss ;;
  *) echo "unknown $SEQ"; exit 1 ;;
esac
REF=$HOME/eval_great/${SEQ}_reference.tum
[ -n "$DUROV" ] && DUR=$DUROV

CFGBASE=config/great_${SEQ}.yaml
CFG=config/great_${SEQ}_${MODE}.yaml
cp -f "$CFGBASE" "$CFG"
sed -i 's/^  lidar_en: .*/  lidar_en: 0/' "$CFG"
sed -i 's/^  img_en: .*/  img_en: 0/'     "$CFG"
sed -i 's/^  gnss_en: .*/  gnss_en: true/' "$CFG"
sed -i "s|^  gnss_topic: .*|  gnss_topic: \"$TOPIC\"|" "$CFG"
sed -i "s/^  seq_name: .*/  seq_name: \"$TAG\"/" "$CFG"
if [ "$MODE" = "gnssimu" ]; then
  sed -i 's/^  imu_en: .*/  imu_en: true/' "$CFG"
else
  sed -i 's/^  imu_en: .*/  imu_en: false/' "$CFG"
fi
sed -i 's/^  pose_output_en: .*/  pose_output_en: true/' "$CFG" || true

RES=Log/result/${TAG}.txt
: > "$RES"
bash "$(dirname "$0")/kill_ros.sh"

roslaunch fast_livo mapping_great.launch rviz:=false seq_name:=$TAG cfg:=great_${SEQ}_${MODE} \
    > $HOME/mode_${TAG}.log 2>&1 &
MP=$!
sleep 8
if [ -n "$RTKBAG" ]; then
  rosbag play -q --queue 5000 -s 0 -u $DUR "$BAG" "$RTKBAG" > /dev/null 2>&1 &
else
  rosbag play -q --queue 5000 -s 0 -u $DUR "$BAG" > /dev/null 2>&1 &
fi
PP=$!
wait $PP 2>/dev/null || true

last=-1; stable=0
for i in $(seq 1 30); do
  sleep 3
  n=$(wc -l < "$RES" 2>/dev/null || echo 0)
  if [ "$n" = "$last" ]; then stable=$((stable+1)); else stable=0; fi
  last=$n
  [ "$stable" -ge 2 ] && break
done
kill -9 $MP 2>/dev/null || true
bash "$(dirname "$0")/kill_ros.sh"
echo "[$TAG] $(wc -l < "$RES") lines"
grep -aE 'SLAM|IMU Initials|Frame alignment|WITHHELD|health' $HOME/mode_${TAG}.log | head -6

python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main/scripts/eval/eval_unified.py \
    "$RES" "$REF" "$TAG" --config "$CFG"
cp "$RES" "$HOME/eval_great/final_${TAG}.txt" 2>/dev/null || true
