﻿#ifndef POSE_GRAPH_FACTORS_H
#define POSE_GRAPH_FACTORS_H

// Pose3 graph factors, separated from global_pose_graph.cpp so the analytic
// Jacobians can be finite-difference tested against GTSAM's Pose3 retraction.
//
// GTSAM Pose3 local tangent is [rotation, translation] and the translation
// perturbation is in the BODY frame: retract([0, v]) moves the translation by
// R*v. Therefore d(translation)/d(tangent) = [0, R], not [0, I].

#include <gtsam/geometry/Pose3.h>
#include <gtsam/linear/NoiseModel.h>
#include <gtsam/nonlinear/NonlinearFactor.h>

#include <Eigen/Dense>
#include <boost/optional.hpp>
#include <vector>

namespace fast_livo
{

inline Eigen::Matrix3d factorSkew(const Eigen::Vector3d &v)
{
  Eigen::Matrix3d m;
  m << 0.0, -v.z(), v.y(),
      v.z(), 0.0, -v.x(),
      -v.y(), v.x(), 0.0;
  return m;
}

// A scalar TDDD row: y - g . (p_j - p_i). g is the average DD line-of-sight
// difference in the graph ENU frame; y is the time-differenced DD phase minus
// the change of the geometric DD range. Pose3 carries the rotation as a state
// but this observation only constrains the two translations.
class TdddFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>
{
public:
  TdddFactor(gtsam::Key i, gtsam::Key j, const Eigen::Vector3d &g, double y,
             const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>(model, i, j), g_(g), y_(y) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    const Eigen::Vector3d d = Tj.translation() - Ti.translation();
    gtsam::Vector1 e;
    e << g_.dot(d) - y_;
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(1, 6);
      H1->block<1, 3>(0, 3) = -g_.transpose() * Ti.rotation().matrix();
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(1, 6);
      H2->block<1, 3>(0, 3) = g_.transpose() * Tj.rotation().matrix();
    }
    return e;
  }

private:
  Eigen::Vector3d g_;
  double y_;
};

// R4.5: all DD pairs of one interval in a single factor with their full
// covariance. DD rows sharing the reference satellite are correlated; adding
// them as independent scalar factors (the old TdddFactor) over-counts the
// reference-star information and makes the posterior over-confident.
class TdddBlockFactor
    : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>
{
public:
  TdddBlockFactor(gtsam::Key i, gtsam::Key j,
                  const std::vector<Eigen::Vector3d> &g,
                  const std::vector<double> &y,
                  const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>(model, i, j),
        g_(g), y_(y) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    const int m = static_cast<int>(g_.size());
    const Eigen::Vector3d d = Tj.translation() - Ti.translation();
    gtsam::Vector e(m);
    for (int k = 0; k < m; ++k) e(k) = g_[k].dot(d) - y_[k];
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(m, 6);
      const Eigen::Matrix3d Ri = Ti.rotation().matrix();
      for (int k = 0; k < m; ++k)
        H1->block<1, 3>(k, 3) = -g_[k].transpose() * Ri;
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(m, 6);
      const Eigen::Matrix3d Rj = Tj.rotation().matrix();
      for (int k = 0; k < m; ++k)
        H2->block<1, 3>(k, 3) = g_[k].transpose() * Rj;
    }
    return e;
  }

private:
  std::vector<Eigen::Vector3d> g_;
  std::vector<double> y_;
};

// R4.3/R4.5: trapezoidal motion model linking two poses and two ENU velocity
// nodes. This is what lets Doppler correct the position trajectory; without it
// the velocity subgraph is disconnected from the poses.
class PoseVelFactor
    : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3,
                                       gtsam::Vector3, gtsam::Vector3>
{
public:
  PoseVelFactor(gtsam::Key pi, gtsam::Key pj, gtsam::Key vi, gtsam::Key vj,
                double dt, const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3, gtsam::Vector3,
                                 gtsam::Vector3>(model, pi, pj, vi, vj),
        dt_(dt) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      const gtsam::Vector3 &vi, const gtsam::Vector3 &vj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none,
      boost::optional<gtsam::Matrix &> H3 = boost::none,
      boost::optional<gtsam::Matrix &> H4 = boost::none) const override
  {
    const gtsam::Vector3 e =
        (Tj.translation() - Ti.translation()) - 0.5 * (vi + vj) * dt_;
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(3, 6);
      H1->block<3, 3>(0, 3) = -Ti.rotation().matrix();
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(3, 6);
      H2->block<3, 3>(0, 3) = Tj.rotation().matrix();
    }
    if (H3) *H3 = -0.5 * dt_ * gtsam::Matrix::Identity(3, 3);
    if (H4) *H4 = -0.5 * dt_ * gtsam::Matrix::Identity(3, 3);
    return e;
  }

private:
  double dt_;
};

// R4.5b: TDDD block with the DD epoch vs keyframe time offsets folded in via
// the velocity nodes:
//   p_e1 ~= p_i + v_i*dt1,  p_e2 ~= p_j + v_j*dt2
//   residual_k = g_k . (p_e2 - p_e1) - y_k
// Without this, a 0.2 s DD/keyframe offset at 1 m/s appears as a 0.2 m/s
// TDDD-vs-Doppler inconsistency.
class TdddBlockVelFactor
    : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3,
                                       gtsam::Vector3, gtsam::Vector3>
{
public:
  TdddBlockVelFactor(gtsam::Key pi, gtsam::Key pj, gtsam::Key vi,
                     gtsam::Key vj, double dt1, double dt2,
                     const Eigen::Vector3d &lever,
                     const std::vector<Eigen::Vector3d> &g,
                     const std::vector<double> &y,
                     const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3, gtsam::Vector3,
                                 gtsam::Vector3>(model, pi, pj, vi, vj),
        dt1_(dt1), dt2_(dt2), lever_(lever), g_(g), y_(y) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      const gtsam::Vector3 &vi, const gtsam::Vector3 &vj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none,
      boost::optional<gtsam::Matrix &> H3 = boost::none,
      boost::optional<gtsam::Matrix &> H4 = boost::none) const override
  {
    const int m = static_cast<int>(g_.size());
    const Eigen::Matrix3d Ri = Ti.rotation().matrix();
    const Eigen::Matrix3d Rj = Tj.rotation().matrix();
    // Antenna positions: the DD phase is measured at the antenna, while the
    // graph nodes are body origins. The lever is now inside the factor, so the
    // optimized rotations participate in the Jacobian.
    const Eigen::Vector3d d =
        (Tj.translation() + Rj * lever_) - (Ti.translation() + Ri * lever_) +
        vj * dt2_ - vi * dt1_;
    gtsam::Vector e(m);
    for (int k = 0; k < m; ++k) e(k) = g_[k].dot(d) - y_[k];
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(m, 6);
      const Eigen::Matrix3d lever_skew =
          factorSkew(lever_);
      for (int k = 0; k < m; ++k)
      {
        H1->block<1, 3>(k, 0) = g_[k].transpose() * Ri * lever_skew;
        H1->block<1, 3>(k, 3) = -g_[k].transpose() * Ri;
      }
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(m, 6);
      const Eigen::Matrix3d lever_skew =
          factorSkew(lever_);
      for (int k = 0; k < m; ++k)
      {
        H2->block<1, 3>(k, 0) = -g_[k].transpose() * Rj * lever_skew;
        H2->block<1, 3>(k, 3) = g_[k].transpose() * Rj;
      }
    }
    if (H3)
    {
      *H3 = gtsam::Matrix::Zero(m, 3);
      for (int k = 0; k < m; ++k)
        H3->block<1, 3>(k, 0) = -dt1_ * g_[k].transpose();
    }
    if (H4)
    {
      *H4 = gtsam::Matrix::Zero(m, 3);
      for (int k = 0; k < m; ++k)
        H4->block<1, 3>(k, 0) = dt2_ * g_[k].transpose();
    }
    return e;
  }

private:
  double dt1_, dt2_;
  Eigen::Vector3d lever_;
  std::vector<Eigen::Vector3d> g_;
  std::vector<double> y_;
};

// R5.3: joint boundary prior on pose + velocity. A block-diagonal pair of
// priors loses P_pose,vel even though PoseVelFactor creates exactly that
// correlation inside the boundary node.
class BoundaryJointFactor
    : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Vector3>
{
public:
  BoundaryJointFactor(gtsam::Key pose, gtsam::Key vel, const gtsam::Pose3 &T0,
                      const gtsam::Vector3 &v0,
                      const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Vector3>(model, pose, vel),
        T0_(T0), v0_(v0) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &T, const gtsam::Vector3 &v,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    gtsam::Vector e(9);
    gtsam::Matrix3 Hr;
    e.segment<3>(0) = gtsam::Rot3::Logmap(T0_.rotation().inverse() * T.rotation(),
                                          Hr);
    e.segment<3>(3) = T.translation() - T0_.translation();
    e.segment<3>(6) = v - v0_;
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(9, 6);
      H1->block<3, 3>(0, 0) = Hr;
      H1->block<3, 3>(3, 3) = T.rotation().matrix();
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(9, 3);
      H2->block<3, 3>(6, 0) = gtsam::Matrix::Identity(3, 3);
    }
    return e;
  }

private:
  gtsam::Pose3 T0_;
  gtsam::Vector3 v0_;
};

// Position-only relative constraint on two Pose3 nodes (the rotation is left to
// the LIVO/static factors). Kept for the GNSS transition rows, which are
// displacement observations, not body-frame relative poses.
class RelPosFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>
{
public:
  RelPosFactor(gtsam::Key i, gtsam::Key j, const gtsam::Point3 &d,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>(model, i, j), d_(d) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    const gtsam::Vector3 e = Tj.translation() - Ti.translation() - d_;
    if (H1)
    {
      *H1 = gtsam::Matrix::Zero(3, 6);
      H1->block<3, 3>(0, 3) = -Ti.rotation().matrix();
    }
    if (H2)
    {
      *H2 = gtsam::Matrix::Zero(3, 6);
      H2->block<3, 3>(0, 3) = Tj.rotation().matrix();
    }
    return e;
  }

private:
  gtsam::Point3 d_;
};

class AbsPosFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3>
{
public:
  AbsPosFactor(gtsam::Key i, const gtsam::Point3 &z,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3>(model, i), z_(z) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &T,
      boost::optional<gtsam::Matrix &> H = boost::none) const override
  {
    const gtsam::Vector3 e = T.translation() - z_;
    if (H)
    {
      *H = gtsam::Matrix::Zero(3, 6);
      H->block<3, 3>(0, 3) = T.rotation().matrix();
    }
    return e;
  }

private:
  gtsam::Point3 z_;
};

// P0-B: XY and Z are separate factors so a vertical outlier cannot dilute the
// horizontal constraint through a shared 3D robust kernel.
class AbsPosXYFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3>
{
public:
  AbsPosXYFactor(gtsam::Key i, const Eigen::Vector2d &z,
                 const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3>(model, i), z_(z) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &T,
      boost::optional<gtsam::Matrix &> H = boost::none) const override
  {
    gtsam::Vector2 e;
    e << T.x() - z_.x(), T.y() - z_.y();
    if (H)
    {
      *H = gtsam::Matrix::Zero(2, 6);
      H->block<2, 3>(0, 3) = T.rotation().matrix().topRows<2>();
    }
    return e;
  }

private:
  Eigen::Vector2d z_;
};

class AbsPosZFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3>
{
public:
  AbsPosZFactor(gtsam::Key i, double z, const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3>(model, i), z_(z) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &T,
      boost::optional<gtsam::Matrix &> H = boost::none) const override
  {
    gtsam::Vector1 e;
    e << T.z() - z_;
    if (H)
    {
      *H = gtsam::Matrix::Zero(1, 6);
      H->block<1, 3>(0, 3) = T.rotation().matrix().row(2);
    }
    return e;
  }

private:
  double z_;
};

// A1: absolute GNSS antenna position at the true RTK epoch, evaluated on the
// Pose3 geodesic between the two bracketing keyframes:
//   Delta = Ti^-1 * Tj,  xi = Log(Delta),
//   T(alpha) = Ti * Exp(alpha * xi),
//   predicted antenna = T(alpha) * lever,
//   residual = predicted - z_antenna.
// The epoch is never snapped to one keyframe, so a fix sampled between two
// keyframes is modelled at its own time and each RTK epoch contributes exactly
// one factor. The factor needs no velocity node, unlike the TDDD/PoseVel rows.
//
// Jacobians (right/body perturbation, GTSAM tangent order [rot, trans]):
//   Hp = d(predicted)/d(T(alpha) tangent) = [-R(alpha) * skew(lever), R(alpha)]
//   Jj = alpha * Jr(alpha*xi) * Jr^-1(xi)
//   Ji = Ad(Exp(-alpha*xi)) - Jj * Ad(Delta^-1)
// Both reduce to the expected endpoint behaviour: Jj(0) = 0, Jj(1) = I,
// Ji(0) = I, Ji(1) = 0.
class InterpolatedAbsPosFactor
    : public gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>
{
public:
  InterpolatedAbsPosFactor(gtsam::Key i, gtsam::Key j, double alpha,
                           const gtsam::Point3 &z_antenna,
                           const gtsam::Point3 &lever_body,
                           const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3, gtsam::Pose3>(model, i, j),
        alpha_(alpha),
        z_(z_antenna),
        lever_(lever_body) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &Ti, const gtsam::Pose3 &Tj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    const gtsam::Pose3 delta = Ti.between(Tj);
    const gtsam::Vector6 xi = gtsam::Pose3::Logmap(delta);
    const gtsam::Vector6 axi = alpha_ * xi;
    const gtsam::Pose3 T_alpha = Ti.compose(gtsam::Pose3::Expmap(axi));
    const Eigen::Matrix3d R_alpha = T_alpha.rotation().matrix();
    const Eigen::Vector3d lever(lever_);
    const gtsam::Vector3 predicted =
        T_alpha.translation() + R_alpha * lever;
    const gtsam::Vector3 e = predicted - gtsam::Vector3(z_);

    if (H1 || H2)
    {
      // d(predicted)/d(T(alpha) tangent)
      Eigen::Matrix<double, 3, 6> Hp;
      Hp.block<3, 3>(0, 0) = -R_alpha * factorSkew(lever);
      Hp.block<3, 3>(0, 3) = R_alpha;
      // Jr^-1(xi) = derivative of Log at xi; Jr(alpha*xi) likewise.
      const Eigen::Matrix<double, 6, 6> Jr_inv =
          gtsam::Pose3::ExpmapDerivative(xi).inverse();
      const Eigen::Matrix<double, 6, 6> Jr_alpha =
          gtsam::Pose3::ExpmapDerivative(axi);
      const Eigen::Matrix<double, 6, 6> Jj = alpha_ * (Jr_alpha * Jr_inv);
      if (H2) *H2 = Hp * Jj;
      if (H1)
      {
        const Eigen::Matrix<double, 6, 6> Ad_D_inv =
            gtsam::Pose3::Expmap(-axi).AdjointMap();
        const Eigen::Matrix<double, 6, 6> Ad_delta_inv =
            gtsam::Pose3::Expmap(-xi).AdjointMap();
        *H1 = Hp * (Ad_D_inv - Jj * Ad_delta_inv);
      }
    }
    return e;
  }

private:
  double alpha_;
  gtsam::Point3 z_;
  gtsam::Point3 lever_;
};

// Unary rotation-only prior on a Pose3 node. The translation component is left
// completely free; this exists solely to fix the global orientation gauge of a
// graph whose rotation observations are all relative.
class AbsRotFactor : public gtsam::NoiseModelFactorN<gtsam::Pose3>
{
public:
  AbsRotFactor(gtsam::Key i, const gtsam::Rot3 &R,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Pose3>(model, i), R_(R) {}

  gtsam::Vector evaluateError(
      const gtsam::Pose3 &T,
      boost::optional<gtsam::Matrix &> H = boost::none) const override
  {
    gtsam::Matrix3 Hr;
    const gtsam::Vector3 e =
        gtsam::Rot3::Logmap(R_.inverse() * T.rotation(), Hr);
    if (H)
    {
      *H = gtsam::Matrix::Zero(3, 6);
      H->block<3, 3>(0, 0) = Hr;
    }
    return e;
  }

private:
  gtsam::Rot3 R_;
};

// R4.3: random-walk smoothness between two consecutive ENU velocity nodes.
class VelDiffFactor : public gtsam::NoiseModelFactorN<gtsam::Vector3, gtsam::Vector3>
{
public:
  VelDiffFactor(gtsam::Key i, gtsam::Key j,
                const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Vector3, gtsam::Vector3>(model, i, j) {}

  gtsam::Vector evaluateError(
      const gtsam::Vector3 &vi, const gtsam::Vector3 &vj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    if (H1) *H1 = -gtsam::Matrix::Identity(3, 3);
    if (H2) *H2 = gtsam::Matrix::Identity(3, 3);
    return gtsam::Vector3(vj - vi);
  }
};

// R4.3: Doppler epoch interpolated between the two surrounding keyframe
// velocity nodes. w is the weight on the earlier node.
class InterpVelFactor : public gtsam::NoiseModelFactorN<gtsam::Vector3, gtsam::Vector3>
{
public:
  InterpVelFactor(gtsam::Key i, gtsam::Key j, double w,
                  const gtsam::Vector3 &z,
                  const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Vector3, gtsam::Vector3>(model, i, j),
        w_(w), z_(z) {}

  gtsam::Vector evaluateError(
      const gtsam::Vector3 &vi, const gtsam::Vector3 &vj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override
  {
    if (H1) *H1 = w_ * gtsam::Matrix::Identity(3, 3);
    if (H2) *H2 = (1.0 - w_) * gtsam::Matrix::Identity(3, 3);
    return gtsam::Vector3(w_ * vi + (1.0 - w_) * vj - z_);
  }

private:
  double w_;
  gtsam::Vector3 z_;
};

// Weak absolute velocity prior. The random-walk chain has a 3D gauge; this
// removes the rank deficiency with a deliberately huge sigma (10 m/s). It is
// not a measurement, only numerical regularization.
class AbsVelFactor : public gtsam::NoiseModelFactorN<gtsam::Vector3>
{
public:
  AbsVelFactor(gtsam::Key i, const gtsam::Vector3 &z,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Vector3>(model, i), z_(z) {}

  gtsam::Vector evaluateError(
      const gtsam::Vector3 &v,
      boost::optional<gtsam::Matrix &> H = boost::none) const override
  {
    if (H) *H = gtsam::Matrix::Identity(3, 3);
    return gtsam::Vector3(v - z_);
  }

private:
  gtsam::Vector3 z_;
};

}  // namespace fast_livo

#endif  // POSE_GRAPH_FACTORS_H
