/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with RTK/GNSS tight-coupling support.

Developer: Chunran Zheng <zhengcr@connect.hku.hk>
For commercial use, please contact me at <zhengcr@connect.hku.hk> or
Prof. Fu Zhang at <fuzhang@hku.hk>.
This file is subject to the terms and conditions outlined in the 'LICENSE' file,
which is included as part of this source code package.
*/
#ifndef LIV_MAPPER_H
#define LIV_MAPPER_H

#include "IMU_Processing.h"
#include "vio.h"
#include "preprocess.h"
#include "gnss_processing.h"
#include "gnss_alignment_state.h"
#include "gnss_epoch_pairer.h"
#include <fast_livo/GnssQuality.h>
#include "factor_graph.h"
#include "rtk_tight.h"
#include "fusion_supervisor.h"
#include <cv_bridge/cv_bridge.h>
#include <image_transport/image_transport.h>
#include <nav_msgs/Path.h>
#include <nav_msgs/Odometry.h>
#include <sensor_msgs/NavSatFix.h>
#include <geometry_msgs/TwistWithCovarianceStamped.h>   // R3-L2: GNSS velocity
#include <geometry_msgs/PointStamped.h>                 // P5b: online graph ENU fix
#include <geometry_msgs/Vector3Stamped.h>               // P6d: graph correction
#include <vikit/camera_loader.h>
#include <mutex>
#include <array>
#include <deque>
#include <Eigen/Geometry>

class LIVMapper
{
public:
  LIVMapper(ros::NodeHandle &nh);
  ~LIVMapper();
  void initializeSubscribersAndPublishers(ros::NodeHandle &nh, image_transport::ImageTransport &it);
  void initializeComponents();
  void initializeFiles();
  void run();
  void gravityAlignment();
  void handleFirstFrame();
  void stateEstimationAndMapping();
  void handleVIO();
  void handleLIO();
  void handleGNSS();
  // Phase 2: front-end RTK double-difference tight coupling (see rtk_tight.h).
  void rtk_cbk(const fast_livo::RtkDD::ConstPtr &msg);
  void handleRTK();
  bool updateStateWithRTK(const fast_livo::RtkDD &msg);
  void clampAuxState();
  // A3: maintain the report-level static hold offset (see the members below).
  void updateStaticReportOffset();
  // R4-1 (A3-1b): keep the report hold past the IMU release while GNSS says
  // the antenna has not moved (see the members below for the contract).
  bool gnssHoldVetoShouldHold();
  bool tryAlignGnssYaw(const GnssMeasureGroup &gnss_meas);
  bool refitEnuWorld();   // E4: periodic refit of the locked ENU<->world fit
  void savePCD();
  void processImu();

  bool sync_packages(LidarMeasureGroup &meas);
  void prop_imu_once(StatesGroup &imu_prop_state, const double dt, V3D acc_avr, V3D angvel_avr);
  void propagateStateToTime(double target_time, StatesGroup &state_inout);
  void imu_prop_callback(const ros::TimerEvent &e);
  void transformLidar(const Eigen::Matrix3d rot, const Eigen::Vector3d t, const PointCloudXYZI::Ptr &input_cloud, PointCloudXYZI::Ptr &trans_cloud);
  void pointBodyToWorld(const PointType &pi, PointType &po);
  void RGBpointBodyLidarToIMU(PointType const *const pi, PointType *const po);
  void RGBpointBodyToWorld(PointType const *const pi, PointType *const po);
  void standard_pcl_cbk(const sensor_msgs::PointCloud2::ConstPtr &msg);
  void livox_pcl_cbk(const livox_ros_driver::CustomMsg::ConstPtr &msg_in);
  void imu_cbk(const sensor_msgs::Imu::ConstPtr &msg_in);
  void img_cbk(const sensor_msgs::ImageConstPtr &msg_in);
  void gnss_cbk(const sensor_msgs::NavSatFix::ConstPtr &msg);
  // A2.1: per-epoch quality, published by the PVT relay from the SAME callback
  // as the NavSatFix. Matched by exact ROS nanosecond stamp.
  void gnss_quality_cbk(const fast_livo::GnssQuality::ConstPtr &msg);
  void drainGnssPairs(const ros::WallTimerEvent &event);
  void flushGnssPairs();
  void processGnssFix(const sensor_msgs::NavSatFix::ConstPtr &msg,
                      const fast_livo::GnssQualityRecord *quality);
  // P6d: slow output-level correction from the 1 Hz graph (LIO frame).
  void onlineGraphCorrectionCallback(const geometry_msgs::Vector3Stamped::ConstPtr &msg);
  // P6d-2: 1 Hz graph global pose + 20 Hz EKF relative motion.
  void globalGraphOdomCallback(const nav_msgs::Odometry::ConstPtr &msg);
  // R3 stage 4 (L2): doppler velocity epochs (separate topic/message type).
  void gnss_vel_cbk(const geometry_msgs::TwistWithCovarianceStamped::ConstPtr &msg);
  void publish_img_rgb(const image_transport::Publisher &pubImage, VIOManagerPtr vio_manager);
  void publish_frame_world(const ros::Publisher &pubLaserCloudFullRes, VIOManagerPtr vio_manager);
  void publish_visual_sub_map(const ros::Publisher &pubSubVisualMap);
  void publish_effect_world(const ros::Publisher &pubLaserCloudEffect, const std::vector<PointToPlane> &ptpl_list);
  void publish_odometry(const ros::Publisher &pubOdomAftMapped);
  void publish_mavros(const ros::Publisher &mavros_pose_publisher);
  void publish_path(const ros::Publisher pubPath);
  void readParameters(ros::NodeHandle &nh);
  // R6 P0-C: periodic RSS/buffer/map-size instrumentation (debug/mem_log_every_n,
  // default 0 = off). Written to Log/result/<seq>_mem.csv.
  void logMemoryStats();
  void logStateDiagnostic();
  template <typename T> void set_posestamp(T &out);
  template <typename T> void pointBodyToWorld(const Eigen::Matrix<T, 3, 1> &pi, Eigen::Matrix<T, 3, 1> &po);
  template <typename T> Eigen::Matrix<T, 3, 1> pointBodyToWorld(const Eigen::Matrix<T, 3, 1> &pi);
  cv::Mat getImageFromMsg(const sensor_msgs::ImageConstPtr &img_msg);

  // Improvement 1/3: dynamic-object output + per-frame statistics
  void publishDynClouds();
  void logDynamicStats();

  // Improvement 2: factor-graph backend integration
  void tryPushGraphKeyframe();
  void tryPushOnlineGraphKeyframe();
  void pollGraphResult();
  void publishSmoothedOdom(const fast_livo::GraphResult &gr);

  // GNSS EKF update
  bool updateStateWithGNSS(const GnssMeasureGroup &gnss_meas);

  // A4: GNSS-only (single-RTK) and GNSS+IMU (RTK/IMU) modes. Both run without
  // LiDAR and camera, driven by GNSS epochs instead of LiDAR frames.
  bool runGnssInertial();
  void writeGnssModeRow(double stamp, const V3D &pos);

  std::mutex mtx_buffer, mtx_buffer_imu_prop;
  std::condition_variable sig_buffer;

  SLAM_MODE slam_mode_;
  std::unordered_map<VOXEL_LOCATION, VoxelOctoTree *> voxel_map;

  string root_dir;
  string runtime_log_dir_;
  string lid_topic, imu_topic, seq_name, img_topic, gnss_topic;
  string gnss_quality_topic = "/gnss/quality";
  string gnss_quality_source_ = "ublox";
  V3D extT;
  M3D extR;

  int feats_down_size = 0, max_iterations = 0;

  double res_mean_last = 0.05;
  double gyr_cov = 0, acc_cov = 0, inv_expo_cov = 0;
  double scale_cov = 1e-6;
  double blind_rgb_points = 0.0;
  double last_timestamp_lidar = -1.0, last_timestamp_imu = -1.0, last_timestamp_img = -1.0;
  double filter_size_surf_min = 0;
  double filter_size_pcd = 0;
  double _first_lidar_time = 0.0;
  double match_time = 0, solve_time = 0, solve_const_H_time = 0;

  bool lidar_map_inited = false, pcd_save_en = false, img_save_en = false, pub_effect_point_en = false, pose_output_en = false, ros_driver_fix_en = false, hilti_en = false;
  int img_save_interval = 1, pcd_save_interval = -1, pcd_save_type = 0;
  int pub_scan_num = 1;

  StatesGroup imu_propagate, latest_ekf_state;

  bool new_imu = false, state_update_flg = false, imu_prop_enable = true, ekf_finish_once = false;
  deque<sensor_msgs::Imu> prop_imu_buffer;
  sensor_msgs::Imu newest_imu;
  double latest_ekf_time;
  nav_msgs::Odometry imu_prop_odom;
  ros::Publisher pubImuPropOdom;
  double imu_time_offset = 0.0;
  double lidar_time_offset = 0.0;
  double gnss_time_offset = 0.0;   // R3-WP10a
  double gnss_vel_time_offset = 0.0;  // R5.5: unify PVT/velocity/DD time bases
  double rtk_time_offset = 0.0;

  // R3-WP10a: fix-type noise table (mirrors GnssProcess::setSigmaTable)
  double gnss_sigma_fixed = 1.2, gnss_sigma_float = 2.5;
  double gnss_sigma_dgps = 3.0, gnss_sigma_single = 5.0;
  // R3-WP10a: reported-covariance vs fix-status sanity check (default off; warn only)
  bool gnss_status_sanity_check = false;
  bool gnss_status_sanity_warn_only = true;
  bool gnss_status_sanity_warned_ = false;
  // R3-WP7: what drives the chi-square gate: "table" (fix-type sigma table, restores
  // the absolute scale) or "adaptive" (the online innovation scale, the old behaviour)
  std::string gnss_gate_sigma_mode = "table";

  bool gravity_align_en = false, gravity_align_finished = false;

  // Improvement 1 (VIO side)
  bool vio_occlusion_en_ = false;
  // WP8f: renamed from vio_occlusion_depth_ratio_ - this is an absolute metre
  // threshold (consumed as vio_manager->occlusion_depth_thresh), not a ratio.
  // The legacy yaml key is still accepted; see readParameters().
  double vio_occlusion_depth_thresh_m_ = 0.5;
  int vio_robust_kernel_type_ = 0;
  double vio_robust_delta_ = 2.0;
  // R6 T3-2: prune the visual sparse map outside the LIO map-sliding cube.
  // Default off; enabling it bounds the RSS growth measured on c03 (feat_map).
  bool vio_visual_prune_en_ = false;
  int vio_visual_prune_margin_ = 20;       // extra voxels beyond the LIO cube
  int vio_visual_prune_min_voxels_ = 20000; // only prune once the map is large

  bool sync_jump_flag = false;

  bool lidar_pushed = false, imu_en, gravity_est_en, flg_reset = false, ba_bg_est_en = true;
  // ZUPT configuration (yaml "zupt" section)
  bool zupt_enable_ = false;
  double zupt_static_deg_ = 0.6;
  double zupt_move_deg_ = 1.2;
  double zupt_acc_move_ = 0.3;
  double zupt_settle_s_ = 0.3;
  // A3: report-level static hold. On a static platform scan-to-map registration
  // is unobservable along the planes and walks the pose (measured ~0.15-0.3 m/s:
  // 30 m over 100 s on campus-02, 4-5 m over 25 s on campus-01). Freezing the
  // ESTIMATOR state does not work: the EKF then disagrees with the map it is
  // registering against, and the estimate collapses (measured: 4x under-motion
  // afterwards, 145 m error). Instead the EKF and its map keep their own
  // consistent (walking) pose, and only the REPORTED pose is held constant
  // while the platform is confidently stationary. At release the accumulated
  // walk becomes a constant rigid offset on every later reported pose, so the
  // trajectory stays continuous and no motion is lost. A constant offset is
  // absorbed by any global alignment; the arbitrary walk path is not.
  bool zupt_hold_pos_en_ = true;
  bool zupt_rep_active_ = false;   // once-ever latch: a hold has engaged
  bool zupt_rep_holding_ = false;  // LIVE: the report hold is active NOW (T1-4 freeze reads this)
  V3D zupt_rep_hold_ = V3D::Zero();
  V3D report_offset_ = V3D::Zero();
  double zupt_release_vel_ = 0.25;   // m/s, forwarded to ImuProcess
  double zupt_hold_max_s_ = 300.0;   // s, backstop release

  // ---- R4-1 (A3-1b): GNSS-assisted static-hold release --------------------
  // The IMU-only release tests cannot separate campus-02's extreme slow start
  // from the estimator's own drift: within 0.5 s of the static lock the dual-
  // window specific-force test already sees >= 0.04 m/s^2 (EVAL_PROTOCOL 7.5),
  // so the hold releases immediately and the 0.3 m/s static walk lands in the
  // reported trajectory (30 m over the first 100 s - c02's dominant error).
  // The fix extends the REPORT hold past the IMU release while the GNSS says
  // the antenna has not moved: displacement of the latest fix from the fix
  // nearest the hold lock, compared against a per-dataset threshold calibrated
  // from the RTK's own static epoch-to-epoch noise (measured, r48 script:
  // c01 fixed 1 Hz -> max 3 mm over 0-22 s => 0.3 m threshold; c02 float 30 s
  // -> 0.24-0.77 m per 30 s while static => 2.0 m threshold, ~15x below one
  // 30 s step of real walking motion). No yaw/alignment involved, so it works
  // while the fusion is withheld (campus-02). Defaults preserve history:
  // with the veto off, or when no fix has been seen, the hold is exactly the
  // IMU-only behaviour. Stale fixes or a too-long veto fall back to release.
  bool zupt_hold_veto_gnss_en_ = false;
  double zupt_hold_veto_thresh_ = 2.0; // m, horizontal displacement that means "moved"
  double zupt_hold_veto_stale_s_ = 45.0; // s, fixes older than this -> fall back
  double zupt_hold_veto_max_s_ = 300.0;  // s, backstop on the vetoed hold itself
  double zupt_hold_veto_min_hold_s_ = 10.0; // s: an IMU hold SHORTER than this is
                                            // not credible - only then may the
                                            // veto extend it (c01's 25.7 s hold
                                            // is credible and must stay untouched)
  bool gnss_hold_veto_done_ = false;     // motion confirmed / given up: never hold again
  bool gnss_hold_veto_eligible_ = false; // IMU released early (< min_hold_s): veto may hold
  bool gnss_hold_prev_imu_ = false;      // previous frame's IMU-hold state (edge detect)
  bool gnss_hold_ref_set_ = false;
  double gnss_hold_ref_t_ = 0.0;         // fix time the displacement is measured from
  double gnss_hold_lock_t_ = -1.0;       // LIO time the report hold first engaged
  double gnss_hold_veto_last_fix_t_ = -1.0; // last accepted fix time (staleness)
  V3D gnss_hold_ref_enu_ = V3D::Zero();
  double gnss_hold_disp_ = 0.0;          // latest |enu - ref| (horizontal, m)
  bool dense_map_en = false;
  int img_en = 1, imu_int_frame = 3;
  bool normal_en = true;
  bool exposure_estimate_en = false;
  double exposure_time_init = 0.0;
  bool inverse_composition_en = false;
  bool raycast_en = false;
  int lidar_en = 1;
  // P1 acceptance: keep the LiDAR-frame timing / IMU propagation but skip the
  // LiDAR and VIO measurement updates. This yields a true GNSS/IMU-only run
  // inside the normal pipeline (no map update, no camera/LiDAR factors).
  bool lio_update_en = true;
  double lio_off_after_s = -1.0;
  bool is_first_frame = false;
  int grid_size, patch_size, grid_n_width, grid_n_height, patch_pyrimid_level;
  double outlier_threshold;
  double plot_time;
  int frame_cnt;
  double img_time_offset = 0.0;
  deque<PointCloudXYZI::Ptr> lid_raw_data_buffer;
  deque<double> lid_header_time_buffer;
  deque<sensor_msgs::Imu::ConstPtr> imu_buffer;
  deque<sensor_msgs::Imu> imu_history_buffer;  // IMU history for GNSS propagation
  deque<cv::Mat> img_buffer;
  deque<double> img_time_buffer;
  vector<pointWithVar> _pv_list;
  vector<double> extrinT;
  vector<double> extrinR;
  vector<double> cameraextrinT;
  vector<double> cameraextrinR;
  vector<double> gnssextrinT;
  double IMG_POINT_COV;

  // GNSS related
  bool gnss_en = false;
  bool gnss_origin_set = false;
  // ENU frame origin (WGS84). Published with the online-graph fix so the
  // graph can rotate satellite ECEF vectors into its own ENU frame for TDDD.
  double gnss_origin_lat_ = 0.0;
  double gnss_origin_lon_ = 0.0;
  double gnss_origin_alt_ = 0.0;
  bool gnss_yaw_aligned = false;      // Whether ENU-world yaw alignment is done
  V3D gnss_extT;  // GNSS antenna lever arm w.r.t. IMU
  // Phase 2: position-domain GNSS updates can be disabled while the existing
  // NavSatFix stream is still used for ENU<->world alignment.
  bool gnss_position_update_en = true;
  // R1 (P0-1) stop-gap: the correction is applied at the LIO state epoch. Until
  // the state history/replay path (R2b) exists, only accept observations whose
  // timestamp is within this tolerance of that epoch; otherwise the residual
  // belongs to a different state and must be rejected, not applied as if it
  // were current. 0 disables the guard (pre-P0 behaviour, not for experiments).
  double gnss_time_sync_tol = 0.05;   // s
  double rtk_time_sync_tol = 0.05;    // s
  // Stage B: horizontal LIO scale state (index 19). Off by default; enable via
  // gnss/state_scale_en for the c02 experiment.
  bool gnss_state_scale_en = false;
  bool rtk_tight_en = false;
  std::string rtk_topic = "/rtk/dd";
  RtkTight rtk_tight_;
  std::deque<fast_livo::RtkDD> rtk_buffer_;
  ros::Subscriber sub_rtk;
  double last_rtk_timeout_t_ = -1.0;
  // P2: soft-weight/hysteresis supervisor for the four-source ESKF.
  FusionSupervisor fusion_sup_;
  FusionSupervisorConfig fusion_sup_cfg_;
  FusionLivoHealth livo_health_;
  M3D enu_R_world;                     // Rotation from ENU (with U negated) to world frame
  V3D enu_t_world = V3D::Zero();       // Translation from ENU (U negated) to world frame
  // ENU<->world alignment by 2D Procrustes over accumulated (GNSS, LIO) pairs.
  // Replaces the old endpoint-displacement yaw, which is unreliable when the LIO
  // displacement over a short baseline is itself degraded, and which silently
  // assumed the two origins coincide (they do not, in general).
  deque<V3D> align_enu_hist_, align_world_hist_;
  // E4: periodic refit of the locked ENU<->world transform (opt-in via
  // gnss/refit_interval_dist; 0 disables the refit and preserves the
  // historical one-shot lock semantics exactly).
  double gnss_refit_interval_dist = 0.0;
  double refit_travel_ = 0.0;        // horizontal GNSS travel since last refit
  V3D refit_last_enu_ = V3D::Zero();
  bool refit_has_last_ = false;
  // Minimum pairs for a 2D fit (4 DOF: yaw + 2D translation). The real gate is
  // the SPAN below, which is rate-independent; a sample-count threshold alone
  // would silently depend on the GNSS output rate (8 samples = 8 s at 1 Hz but
  // 240 s at 30 s).
  int gnss_align_min_samples = 4;
  double gnss_align_max_resid = 5.0;   // m, fit residual gate (diagnostic only currently)
  double align_resid_last = 0.0;       // diagnostics
  // Minimum horizontal displacement before the frame fit is trusted. Rate
  // independent; 50 m gives a reliable fitted yaw (a 5 m baseline does not).
  double gnss_yaw_align_min_dist = 50.0;

  // ---- A2: convergence-based alignment freeze ----------------------------
  // The fit is recomputed every epoch and only frozen once it STOPS CHANGING
  // (|dyaw| below tolerance for `settle` consecutive epochs) and a real span
  // has been covered. Freezing on the first crossing of a span threshold made
  // the result depend on which epochs happened to fall inside the degraded
  // startup window (measured run-to-run spread: 3.1-8.7 deg on identical data).
  double align_yaw_prev_ = 0.0;          // previous epoch's fitted yaw
  int align_stable_count_ = 0;           // consecutive epochs within tolerance
  double gnss_align_yaw_tol_deg = 0.35;  // deg, convergence tolerance
  int gnss_align_settle = 10;            // epochs required within tolerance
  double gnss_align_drop_scale = 3.0;    // robust refit gate: drop > scale*median
  int align_dropped_last_ = 0;           // diagnostics
  double gnss_align_force_dist = 150.0;  // m, lock anyway to bound the wait
  // P2-01 (EXP-P2-001): the forced early lock additionally requires this many
  // consecutive within-tolerance fits. 0 (default) reproduces the historical
  // predicate exactly (see include/yaw_accept_policy.h); candidate arms set
  // 2-3. campus-02 locked FORCED at stable_count == 1, 43.8 deg off.
  int gnss_align_forced_min_stable = 0;
  // Fit-quality gate on the alignment residual. A large residual means the LIO
  // and the GNSS disagree by metres across the alignment window, so the fitted
  // yaw is not trustworthy (campus-02: 8 m residual over a 167 m span). Locking
  // on such a fit would apply a bogus yaw to real updates. When the gate fails
  // the fusion stays OFF and says so, instead of silently degrading.
  bool gnss_align_resid_gate = true;
  // R4-2b: fit the ENU->world alignment on the reported pose (see LIVMapper.cpp).
  bool align_use_report_pos_ = false;
  int align_badfit_count_ = 0;
  // P1-4: relative-displacement alignment. Fit yaw+scale on consecutive
  // GNSS/LIO displacement vectors (translation-free, so slow absolute drift
  // does not enter the fit), then derive the translation from the median
  // absolute residual. Diagnostic by default; enabling it uses the relative
  // yaw/translation for the lock. The absolute residual gate still applies.
  bool gnss_align_relative_en = false;
  double gnss_align_rel_min_disp = 1.0;  // m, ignore near-static displacement pairs
  // Validate absolute vs relative alignment candidates against the DD code
  // before locking. A bad Procrustes yaw produces a large robust DD code RMS
  // and is rejected; no per-sequence yaw constant is involved.
  bool gnss_align_dd_score_en = true;
  double gnss_align_dd_max_rms = 6.0;    // m, max robust DD code RMS to lock

  // ---- T1-4: slow-varying alignment state (docs/T1_4_DESIGN.md) -----------
  // After the Procrustes lock, the ENU->world yaw + horizontal translation
  // become the mean of a slow random-walk state co-estimated from the same
  // GNSS innovations as the trajectory (parallel priors, P_xa = 0 - the
  // discarded posterior cross term is logged). Everything lives in the
  // INTERNAL frame; the report-layer hold offset never enters. All off by
  // default; when enabled the FORCED early lock is disabled (a wrong-but-early
  // prior is worse than a late lock the filter can still converge from).
  bool gnss_align_state_en = false;
  // Random-walk rates. 0 = AUTO (default): derived ONLINE from the filter's
  // own adaptive sigma so the closed-loop time constant tau = sigma*sqrt(dt)/q
  // equals gnss_align_tau_s on ANY dataset:
  //     q_pos   = sig_h * sqrt(dt_g) / tau          [m/sqrt(s)]
  //     q_yaw   = q_pos / span_at_lock              [rad/sqrt(s)]
  // One global constant (tau), everything else data-derived - no per-sequence
  // values. >0 reproduces historical arms explicitly (c01 Q-sweep batch used
  // q_pos 0.01/0.03/0.1 and q_yaw 0.05/0.15/0.5 with sigma_yaw0 1.0).
  double gnss_align_q_pos = 0.0;          // m/sqrt(s); 0 = auto
  double gnss_align_q_yaw_deg = 0.0;      // deg/sqrt(s); 0 = auto
  double gnss_align_tau_s = 150.0;        // s, target closed-loop time constant
  // Redesign guards (EVAL_PROTOCOL 26.3): the alignment state's authority must
  // not grow with the data's badness. (a) the auto q is capped at
  // drift_rate*sqrt(tau) - the transform can be re-fit no faster than the LIO
  // physically drifts; (b') P is capped at K_max/(1-K_max)*R_eff every epoch
  // so K_a <= K_max holds structurally; (c) the per-epoch translation fold is
  // capped at drift_rate*dt (see the filter unit). drift_rate is the one
  // global physical constant (LIO drift slope, EVAL_PROTOCOL 16.1).
  double gnss_align_drift_rate = 0.004;   // m/s, LIO drift slope (3.5-5.3 mm/s measured)
  double gnss_align_kmax = 0.1;           // K_a ceiling (authority share per epoch)
  double align_q_pos_last_ = 0.0;         // diagnostics (auto-derived rates)
  double align_q_yaw_last_ = 0.0;
  double align_fold_t_total_ = 0.0;       // cumulative |dt_fold| (m), criterion (2)
  double align_span_lock_ = 1.0;          // GNSS span at lock (yaw lever scale)
  // P_a0 yaw at lock, degrees. 0 = AUTO (default): derive from the settle
  // tolerance that certified the lock - the lock only happens after
  // gnss_align_settle consecutive fits within gnss_align_yaw_tol_deg, so that
  // tolerance IS the data-independent bound on the locked yaw uncertainty.
  // >0 = explicit override for reproducing historical arms; per-sequence
  // values here would be dataset tuning and are not the method default.
  double gnss_align_sigma_yaw0_deg = 0.0;
  double gnss_align_max_dyaw_deg = 0.5;   // per-epoch clamp on dpsi
  double gnss_align_max_dt_m = 0.2;       // per-epoch clamp on the translation
  double align_psi_ = 0.0;                // folded base yaw (rad)
  double align_cross_last_ = 0.0;         // |K_x H_a P_a| of the discarded cross term
  GnssAlignState align_state_;

  // ---- A2: anchor-windowed relative GNSS update --------------------------
  // An absolute ENU->world update needs the fitted translation, which is only
  // valid at fit time; afterwards the entire LIO drift sits inside the
  // innovation, and the filter answers by inflating sigma (ignoring the fix)
  // instead of correcting the state. Referencing each fix to a sliding anchor
  // cancels the translation identically, so the innovation measures only the
  // drift accumulated over the anchor window - a bounded, meaningful quantity.
  bool gnss_anchor_set_ = false;
  V3D gnss_anchor_enu_ = V3D::Zero();    // measured antenna ENU at the anchor
  V3D gnss_anchor_world_ = V3D::Zero();  // predicted antenna world at the anchor
  double gnss_anchor_time_ = 0.0;
  double gnss_rel_max_dist = 30.0;       // m, anchor window length
  double gnss_rel_max_dt = 30.0;         // s, anchor window length
  // A2: A/B switch + safety clamp for the fusion model. `relative_update`
  // selects the anchored displacement model (above) over the absolute one;
  // `max_corr` (m, 0 = off) caps how far one epoch may move the position, so a
  // single bad fix can never yank the trajectory.
  bool gnss_relative_update = true;
  double gnss_max_corr = 0.0;
  // A2: make the position prior honest before the update. The LIO reports a few
  // cm of position sigma while its real drift is metres; with an over-confident
  // prior the GNSS gain collapses and the fusion is inert.
  //
  // DEFAULT OFF. Setting the prior sigma to the ONLINE INNOVATION SCALE is
  // circular and destroys the chi-square test: campus-02 disagrees with the GNSS
  // by ~20 m, so sigma_h becomes 20 m, S = 2*sigma_h^2, and gamma = res^2/S ~ 0.5
  // for ANY innovation - the gate can no longer reject anything, while the ~0.5
  // gain drags the trajectory by half of a 20 m bogus correction (~10 m error).
  // It helps campus-01 (gain 1% -> 50%, 2D -21%) because there the disagreement
  // really is GNSS-level noise. Use only when the LIO-GNSS disagreement is known
  // to be small; the general fix is a bounded, physically-based drift prior (A3).
  bool gnss_inflate_prior = false;

  // ---- R3 P1-3 (A3-2): bounded physical drift prior ------------------------
  // The honest version of what inflate_prior tried to do. P1-2 (EVAL_PROTOCOL 14)
  // located the fusion's limiter in the per-epoch GAIN (~5e-4, set by the
  // ~0.03 m position prior vs the ~4 m adaptive sigma), not in the gate. The
  // fix grows the position prior with the drift a pure LIO accumulates between
  // absolute corrections, as an exact ACCOUNT (see gnss_processing.h):
  //   acc += b*dt per inter-fix interval (capped), an accepted epoch pays |dx|,
  //   sigma_used = max(a, acc), b from the LIO's OWN measured drift rate.
  // Unlike inflate_prior this cannot self-amplify (no innovation feedback: the
  // pay-down uses the APPLIED correction, not the residual), it self-balances
  // in steady state (gain rises only until gain*res pays the accrual), and -
  // critically - it is applied ONLY to the update's S/K/Joseph covariance,
  // NEVER to the chi-square gate's S, which keeps the raw prior. The
  // accepted/rejected epoch set therefore stays byte-identical to the
  // historical gate (EVAL_PROTOCOL 14.4: widening the gate's acceptance
  // measurably hurts). The first instantiation (vA: reset the drift clock on
  // every accept) was measured to under-engage by construction - sporadic
  // transient accepts capped the sigma at ~b*13 s - and was replaced by this
  // account before the decisive A/B (mechanism pair kept as p13vA_*).
  // Default OFF: every quantity is then bit-identical to the previous behaviour.
  bool gnss_prior_drift_en = false;
  double gnss_prior_drift_a = 0.0;   // m, floor at a freshly corrected state
  double gnss_prior_drift_b = 0.004; // m/s, c01 pure-LIVO post-alignment drift
                                     // measured 3.5-5.3 mm/s (p12_livo_r1/r2
                                     // vs reference, 70-200 s slope)
  double gnss_prior_drift_max = 0.8; // m, cap (gain stays bounded on long
                                     // uncorrected stretches, e.g. c03)
  // D3 (2026-10-28): let the chi-square gate use the same drift-inflated prior
  // as the gain (consistent S). P1-3 deliberately kept the gate on the raw
  // prior (EVAL_PROTOCOL 14.4); that was measured with the joint 3-DOF gate,
  // where the vertical row dominated. Default false = history-preserving.
  bool gnss_prior_drift_gate = false;
  double gnss_drift_acc_ = 0.0;      // current drift account (m)
  double gnss_drift_last_t_ = -1.0;  // last fix time seen (for the accrual dt)

  // ---- P0-2 adaptive observation noise -----------------------------------
  // Per-channel sigma estimated online from the innovation history (robust
  // median/MAD scale), replacing per-dataset sigma calibration and the manual
  // vertical on/off switch.
  deque<double> gnss_res_h_hist_, gnss_res_u_hist_;
  int gnss_sigma_window = 30;      // samples in the robust scale estimate
  double gnss_sigma_floor = 0.3;   // m, never trust a fix below this
  double gnss_sigma_ceil = 50.0;   // m, never fully discard a channel
  double gnss_sigma_h = -1.0;      // current estimate (<=0 -> fall back to the table)
  double gnss_sigma_u = -1.0;
  // ---- optional GNSS quality-factor weighting ----------------------------
  // The residual-derived sigma above measures "how large is the LIO-GNSS
  // disagreement".  It is not a quality estimate: a low-quality fix whose
  // innovation happens to be small still looks trustworthy.  When enabled,
  // combine that scale with quality information actually available in the
  // data: the NavSatFix receiver covariance (always), the fix-status table
  // (always) and DOP (only when a source fills hdop/vdop; the NavSatFix path
  // leaves the 99 sentinel).  C/N0 is not present in the current GNSS
  // messages and is therefore not used here.  Disabled by default so the
  // historical results remain bit-compatible; enable via gnss/quality_en.
  bool gnss_quality_en = false;
  double gnss_quality_cov_weight = 0.5;   // weight on the receiver covariance
  double gnss_quality_fix_weight = 0.5;   // weight on the fix-status table ratio
  // Reference fix status for q_fix: the factor is 1 at this status, <1 for a
  // better status (Fixed gets a boost) and >1 for a worse one (Single gets a
  // penalty). Default 2 = GNSS_PHASE_FLOAT. Set 5 to make Fixed the baseline
  // and reproduce the one-sided "penalty only" behaviour.
  int gnss_quality_fix_ref_status = 2;
  double gnss_quality_dop_weight = 0.5;   // weight on the DOP ratio (if valid)
  double gnss_quality_dop_ref = 2.0;      // DOP reference (q = 1 at this DOP)
  double gnss_quality_factor_min = 0.5;   // clamp on each quality factor
  double gnss_quality_factor_max = 3.0;
  // Health counters (make a silently-inert fusion visible)
  int gnss_eval_count = 0, gnss_ok_count = 0, gnss_rej_count = 0;
  int gnss_time_reject_count = 0, rtk_time_reject_count = 0;

  // ---- P0-A systematic-bias detector -------------------------------------
  // Distinguishes a persistent innovation DIRECTION (alignment/scale bias)
  // from zero-mean noise. The adaptive sigma deliberately measures |residual|
  // magnitude; it cannot tell a 3 m bias from 3 m of scatter, and the chi-square
  // gate then treats the bias as noise. This detector keeps a short history of
  // the horizontal residual VECTOR, takes its component-wise median, and asks
  // both how large it is and how consistently the individual residuals point
  // the same way. Diagnostic by default; gnss/bias_guard can hold updates while
  // a persistent bias is present (safe fallback, not a correction).
  deque<Eigen::Vector2d> gnss_res_xy_hist_;
  double gnss_bias_thresh = 1.0;    // m, median horizontal bias to flag
  int gnss_bias_window = 30;        // fixes in the detector window
  double gnss_bias_sign_min = 0.7;  // fraction of residuals agreeing in direction
  int gnss_bias_persist = 10;       // consecutive flagged fixes before active
  bool gnss_bias_guard = false;     // hold updates while bias is active
  int gnss_bias_count_ = 0;         // consecutive flagged fixes
  bool gnss_bias_active_ = false;   // hysteresis state
  int gnss_bias_hold_count_ = 0;    // epochs held by the guard
  double gnss_bias_mag_last_ = 0.0; // diagnostics
  double gnss_bias_sign_last_ = 0.0;
  int gnss_bias_n_last_ = 0;

  // ---- R3 stage 4 (L2): GNSS velocity (doppler) observations -----------------
  // Off by default: the whole 6-row observation model only engages when
  // gnss/use_velocity is true AND a velocity epoch was matched to the fix.
  bool gnss_use_velocity = false;
  string gnss_vel_topic = "/gnss_vel";
  double gnss_vel_sigma = 0.2;        // m/s, per axis (NOT the receiver's V-RMS: it
                                      // is 10-80x optimistic on Float epochs, see
                                      // docs/EVAL_PROTOCOL.md 11.1)
  bool gnss_vel_use_vertical = false; // U velocity is much worse than horizontal
  int gnss_vel_min_status = 5;        // 5 = RTK fixed only; 2 would allow Float,
                                      // which was measured ~10x worse
  double gnss_vel_max_dt = 0.05;      // s, fix<->velocity stamp match tolerance
  deque<GnssVelGroup> gnss_vel_buffer;
  int gnss_vel_used_count = 0, gnss_vel_matched_count = 0;
  double gnss_vel_res_last = 0.0;     // diagnostics
  double gnss_vel_lever_last = 0.0;   // |R*(omega x p_lever)| from the last update
  // R3 stage 1 (WP1): how often the per-evaluation diagnostics print. 1 = every
  // fix (needed to build p50/p95 statisticics of the innovation terms); <= 0 turns
  // them off. The default 10 reproduces the historical behaviour exactly.
  int gnss_health_every_n = 10;
  deque<GnssMeasureGroup> gnss_buffer;
  // A4 mode scratch: Process2 asserts a non-null cloud, and VIO mode does not
  // touch it beyond that, so one empty cloud is reused.
  PointCloudXYZI::Ptr gnss_mode_dummy_cloud_;
  std::ofstream fout_gnss_mode_;
  bool gnss_mode_file_open_ = false;
  double gnss_outlier_thresh = 7.815;  // chi-square threshold (3 DOF, 95% = 7.815)
  double gnss_horiz_sigma = -1.0;      // measured horizontal sigma (m), <=0 -> fix table
  double gnss_vert_sigma = -1.0;       // measured vertical sigma (m), <=0 -> fix table
  int gnss_update_count = 0;
  bool gnss_outlier_rejection = true;
  bool gnss_use_vertical = true;        // fuse GNSS vertical (U) channel or horizontal-only
  // D1 (2026-10-27): channel-split chi-square gate. "joint" = historical 3-DOF
  // test (default until the A/B promotes the split); "split" gates horizontal
  // (2-DOF, chi2(2,0.95)=5.991) and vertical (1-DOF, chi2(1,0.95)=3.841 with
  // the gate sigma floored) separately. With the fix-status table sigma the
  // joint test is decided by the vertical channel alone (e1e2_n3 REPORT.md A2:
  // 293/349 rejects were RTK-fixed epochs, vertical disagreement 7-18 m vs a
  // 1.2/2.5 m table).
  std::string gnss_vertical_gate = "joint";
  double gnss_vertical_gate_floor = 10.0;  // m, floor on the split-mode vertical gate sigma

  PointCloudXYZI::Ptr visual_sub_map;
  PointCloudXYZI::Ptr feats_undistort;
  PointCloudXYZI::Ptr feats_down_body;
  PointCloudXYZI::Ptr feats_down_world;
  PointCloudXYZI::Ptr pcl_w_wait_pub;
  PointCloudXYZI::Ptr pcl_wait_pub;
  PointCloudXYZRGB::Ptr pcl_wait_save;
  PointCloudXYZI::Ptr pcl_wait_save_intensity;

  ofstream fout_pre, fout_out, fout_visual_pos, fout_lidar_pos, fout_points, fout_gnss_pos;

  pcl::VoxelGrid<PointType> downSizeFilterSurf;

  V3D euler_cur;

  LidarMeasureGroup LidarMeasures;
  StatesGroup _state;
  StatesGroup  state_propagat;

  nav_msgs::Path path;
  nav_msgs::Odometry odomAftMapped;
  geometry_msgs::Quaternion geoQuat;
  geometry_msgs::PoseStamped msg_body_pose;

  PreprocessPtr p_pre;
  ImuProcessPtr p_imu;
  VoxelMapManagerPtr voxelmap_manager;
  VIOManagerPtr vio_manager;
  GnssProcessPtr p_gnss;

  ros::Publisher plane_pub;
  ros::Publisher voxel_pub;
  ros::Subscriber sub_pcl;
  ros::Subscriber sub_imu;
  ros::Subscriber sub_img;
  ros::Subscriber sub_gnss;
  ros::Subscriber sub_gnss_vel;   // R3-L2: doppler velocity topic
  ros::Subscriber sub_gnss_quality;  // A2.1: exact-stamp quality records
  using GnssPairer = fast_livo::GnssEpochPairer<sensor_msgs::NavSatFix::ConstPtr>;
  std::unique_ptr<GnssPairer> gnss_pairer_;
  double gnss_quality_wait_sec_ = 0.2;
  int gnss_quality_capacity_ = 1000;
  ros::WallTimer gnss_quality_timer_;
  ros::Time gnss_pair_clock_;
  ros::Publisher pubLaserCloudFullRes;
  ros::Publisher pubNormal;
  ros::Publisher pubSubVisualMap;
  ros::Publisher pubLaserCloudEffect;
  ros::Publisher pubLaserCloudMap;
  ros::Publisher pubOdomAftMapped;
  ros::Publisher pubPath;
  ros::Publisher pubLaserCloudDyn;
  ros::Publisher pubLaserCloudDynRmed;
  ros::Publisher pubLaserCloudDynDbg;
  ros::Publisher pubSmoothedOdom;   // Improvement 2: factor-graph smoothed odometry
  ros::Publisher pubSmoothedPath;
  image_transport::Publisher pubImage;
  ros::Publisher mavros_pose_publisher;
  ros::Timer imu_prop_timer;

  // Improvement 2: sliding-window factor-graph backend
  fast_livo::GraphConfig graph_cfg_;
  std::unique_ptr<fast_livo::FactorGraph> graph_;

  // P5b: bounded-history GTSAM position graph (separate online_graph_node).
  // The main node only publishes 1 Hz keyframe poses and raw ENU fixes.
  bool online_graph_en_ = false;
  int online_graph_window_ = 1500;
  double online_graph_last_kf_t_ = -1.0;
ros::Publisher pubOnlineGraphKeyframe;
ros::Publisher pubOnlineGraphFix;
ros::Publisher pubOnlineGraphVel;

  // P6d: slow output-level graph correction. The graph keyframe input never
  // includes graph_offset_, so this is not a closed loop back into the graph.
  bool graph_feedback_en_ = false;
  double graph_feedback_max_step_ = 0.01;   // m per LiDAR frame
  double graph_feedback_max_offset_ = 2.0;  // m, reject larger corrections
  double graph_feedback_max_age_ = 1.5;     // s, keyframe timestamp age
  double graph_feedback_gain_ = 1.0;
  V3D graph_offset_ = V3D::Zero();
  V3D graph_corr_target_ = V3D::Zero();
  double graph_corr_stamp_ = 0.0;
  bool graph_corr_valid_ = false;
  std::mutex graph_corr_mtx_;
  ros::Subscriber subOnlineGraphCorrection;
  ros::Publisher pubGraphOffset;
  void updateGraphOffset(double t);

  // P6d-2: high-rate global pose = latest 1 Hz graph global pose + EKF relative
  // motion since that graph keyframe. The EKF state and graph keyframes are
  // never modified by this path.
  bool graph_fusion_en_ = false;
  double graph_fusion_max_age_ = 3.0;   // s, anchor staleness
  double graph_fusion_blend_s_ = 0.3;   // s, anchor-to-anchor output blend
  int graph_fusion_path_len_ = 5000;    // high-rate global path length
  double graph_fusion_relative_max_error_ = 1.0;  // m, EKF-relative trust
  double graph_fusion_static_speed_ = 0.15;       // m/s, graph-static hold
  std::string graph_fusion_mode_ = "auto";        // auto|graph_vel|ekf_rel
  struct GraphKeyframe
  {
    double t = 0.0;
    V3D p = V3D::Zero();
    M3D R = M3D::Identity();
  };
  struct GraphAnchor
  {
    bool valid = false;
    uint64_t seq = 0;
    double t = 0.0;
    V3D p_G = V3D::Zero();
    Eigen::Quaterniond q_G = Eigen::Quaterniond::Identity();
    M3D R_G = M3D::Identity();
    V3D p_k = V3D::Zero();
    M3D R_k = M3D::Identity();
    bool use_velocity = false;
    V3D v_G = V3D::Zero();
    std::array<double, 36> cov{};
  };
  std::deque<GraphKeyframe, Eigen::aligned_allocator<GraphKeyframe>> graph_kf_hist_;
  GraphAnchor graph_anchor_pending_;
  GraphAnchor graph_anchor_cur_;
  GraphAnchor graph_anchor_prev_;
  uint64_t graph_anchor_seq_ = 0;
  uint64_t graph_anchor_seen_seq_ = 0;
  bool graph_anchor_has_cur_ = false;
  bool graph_anchor_has_prev_ = false;
  double graph_blend_start_t_ = -1.0;
  std::mutex graph_fusion_mtx_;
  ros::Subscriber subGlobalGraphOdom;
  ros::Publisher pubGlobalOdom;
  ros::Publisher pubGlobalPath;
  nav_msgs::Path global_path_;
  int global_path_counter_ = 0;
  void updateGraphFusion(double t);
  bool graph_has_prev_kf_ = false;
  M3D graph_prev_kf_R_ = M3D::Identity();
  V3D graph_prev_kf_pos_ = V3D::Zero();
  int frames_since_kf_ = 0;
  double graph_last_written_stamp_ = -1.0;
  GnssMeasureGroup last_valid_gnss_;  // most recent successful GNSS fix (for the graph)
  // R3 P1-1 third layer: when graph_v_ref_pos_frames_ > 0, the graph's velocity
  // reference is the position-implied velocity over that many keyframes instead
  // of the filter's velocity, which transiently leads the position increments
  // during acceleration (EVAL_PROTOCOL 15.6) and shows up in the pre-int
  // residual as phantom motion.
  int graph_v_ref_pos_frames_ = 0;
  std::deque<std::pair<double, V3D>> graph_pos_hist_;  // (stamp, position)

  // Improvement 1/3: latency & dynamic statistics logging
  bool latency_en_ = false;
  std::ofstream fout_latency_, fout_dyn_;
  std::ofstream fout_lambda_;
  // R6 P0-C: memory/buffer growth log (off by default)
  std::ofstream fout_mem_;
  bool state_diagnostic_en_ = false;
  std::ofstream fout_state_diagnostic_;
  bool gnss_pair_diagnostic_en_ = false;
  std::ofstream fout_gnss_pair_diagnostic_;
  int mem_log_every_n_ = 0;
  long mem_frame_count_ = 0;
  nav_msgs::Odometry smoothed_odom_;
  nav_msgs::Path smoothed_path_;

  int frame_num = 0;
  double aver_time_consu = 0;
  double aver_time_icp = 0;
  double aver_time_map_inre = 0;
  bool colmap_output_en = false;
};
#endif
