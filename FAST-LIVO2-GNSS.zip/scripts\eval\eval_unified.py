#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Unified evaluation + run registry (A1).

One protocol for every dataset/segment so results are comparable:
  * same reference, same ENU handling, SE(3) Umeyama alignment
  * scopes: full, steady (t>150 s)
  * APE (3D/2D) + translation RPE at several dt
  * appends one line per run to Log/result/registry.csv together with a hash of
    the config used, so run-to-run distributions accumulate for free.

T0-1 segment scopes (appended 2026-09, printed in addition to full/steady --
the historical numbers are untouched so old and new scopes stay comparable):
  * the reference is scanned for stationary segments (median-filtered horizontal
    speed < --static-speed); the Umeyama frame compromise over drift + static
    segments (a c02 static segment can sit 15 m off under the global fit while
    the estimator itself moved <1 cm) is what these scopes remove
  * movfit        : Umeyama fit on MOVING samples only, evaluated on them
  * stat@movfit   : the same transform, evaluated on static samples
                    (frame scatter of the static parts -- what slow-varying
                    alignment estimation would have to absorb)
  * steady-loc    : local fit on t>=150 s (no startup compromise in the frame)
  * static-loc    : per-segment local fit, pooled (self-motion quality; should
                    return to the self-displacement magnitude)
  * --win A:B     : local fit on an explicit window (e.g. startup 0:150)

Usage:
  eval_unified.py <traj.txt> <reference.tum> <tag> [--config <yaml>]
                  [--segment-start S --segment-dur D]
                  [--static-speed V] [--static-min-dur S] [--win A:B]...

The measured noise floor of this pipeline (same input, same binary) is:
  ~0.12 m at 60 s, ~0.5 m at 120 s, ~2.5 m at 607 s  (see docs/EVAL_PROTOCOL.md)
=> only compare differences that exceed the band for the segment length used.
"""
import sys, os, hashlib, datetime
import numpy as np

def load_tum(p):
    t, x = [], []
    for l in open(p):
        q = l.split()
        if len(q) >= 4:
            try:
                t.append(float(q[0])); x.append([float(q[1]), float(q[2]), float(q[3])])
            except ValueError:
                pass
    return np.array(t), np.array(x)

def umeyama(src, dst):
    ms, md = src.mean(0), dst.mean(0)
    H = (src - ms).T @ (dst - md)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1, 1, d]) @ U.T
    return R, md - R @ ms

def static_segments(rt, rp, thr, k, min_dur, gap):
    """Stationary segments of the REFERENCE: median-filtered horizontal
    consecutive-sample speed below thr. Robust to the vertical RTK spikes and
    to isolated horizontal jumps (median over +-k samples)."""
    if len(rt) < 3:
        return []
    v = np.linalg.norm(np.diff(rp[:, :2], axis=0), axis=1) / np.maximum(np.diff(rt), 1e-6)
    vv = np.array([np.median(v[max(0, i - k):i + k + 1]) for i in range(len(v))])
    stat = np.empty(len(rt), bool)
    stat[:-1] = vv < thr
    stat[-1] = vv[-1] < thr
    segs, i = [], 0
    while i < len(rt):
        if stat[i]:
            j = i
            while j + 1 < len(rt) and stat[j + 1]:
                j += 1
            segs.append([rt[i], rt[j]])
            i = j + 1
        else:
            i += 1
    merged = []
    for s in segs:
        if merged and s[0] - merged[-1][1] <= gap:
            merged[-1][1] = s[1]
        else:
            merged.append(s)
    return [(a, b) for a, b in merged if b - a >= min_dur]

def fit_eval(p, rpm, mfit, meval):
    """SE(3) fit on the paired samples mfit, APE evaluated on meval. `rpm` is
    the reference matched to the trajectory timeline (rp[irall]), so both masks
    are trajectory-length. Returns (metrics, e3, e2) or (None, None, None)."""
    if mfit.sum() < 3 or meval.sum() < 3:
        return None, None, None
    R, tr = umeyama(p[mfit], rpm[mfit])
    al = (R @ p.T).T + tr
    e3 = np.linalg.norm(al[meval] - rpm[meval], axis=1)
    e2 = np.linalg.norm(al[meval][:, :2] - rpm[meval][:, :2], axis=1)
    m = dict(n=int(meval.sum()), r3=float(np.sqrt((e3 ** 2).mean())),
             r2=float(np.sqrt((e2 ** 2).mean())))
    return m, e3, e2

def score(t, p, rt, rp, tmin):
    """Returns (metrics, aligned_trajectory). RPE must use the ALIGNED
    trajectory: comparing raw poses is meaningless because the estimate and the
    reference live in different frames (this bug produced 60 s RPE of ~68 m)."""
    sel = (t - t[0]) >= tmin
    idx = np.where(sel)[0]
    if len(idx) < 20:
        return None, None
    ir = np.array([int(np.argmin(np.abs(rt - x))) for x in t[sel]])
    R, tr = umeyama(p[idx], rp[ir])
    al = (R @ p.T).T + tr
    ok = np.abs(rt[ir] - t[sel]) < 0.25
    if ok.sum() < 20:
        return None, None
    e3 = np.linalg.norm(al[sel][ok] - rp[ir][ok], axis=1)
    e2 = np.linalg.norm(al[sel][ok][:, :2] - rp[ir][ok][:, :2], axis=1)
    return dict(n=int(ok.sum()), r3=float(np.sqrt((e3**2).mean())),
                r2=float(np.sqrt((e2**2).mean())), mx=float(e3.max()),
                mean3=float(e3.mean())), al

def rpe(t, al, rt, rp, dts, tmin=0.0, tol=0.15, irall=None):
    sel = (t - t[0]) >= tmin
    if irall is None:
        irall = np.array([int(np.argmin(np.abs(rt - x))) for x in t])
    ok = np.abs(rt[irall] - t) < 0.25
    out = {}
    for dt in dts:
        et = []
        for i in range(len(t)):
            if not ok[i] or not sel[i]:
                continue
            j = int(np.argmin(np.abs(t - (t[i] + dt))))
            if j == i or abs(t[j] - (t[i] + dt)) > tol:
                continue
            et.append(np.linalg.norm((al[j] - al[i]) - (rp[irall[j]] - rp[irall[i]])))
        if et:
            out[dt] = (float(np.mean(et)), float(np.sqrt((np.array(et)**2).mean())))
    return out

# T0-1 columns appended to the right of the historical ones. Old rows (written
# before this extension) simply end earlier; csv.DictReader-based tools read
# the missing fields as empty.
NEW_COLS = ["n_mov", "r3_mov", "r2_mov", "n_stat_gf", "r3_stat_gf", "r2_stat_gf",
            "n_stdyloc", "r3_stdyloc", "r2_stdyloc", "r2_statloc", "segs"]

def extend_registry_header(reg):
    """Extend an existing registry's header line in place with NEW_COLS so new
    rows stay column-aligned (one-time migration; keeps one file per result dir)."""
    try:
        with open(reg) as f:
            lines = f.readlines()
        if not lines or not lines[0].startswith("utc,"):
            return
        if lines[0].rstrip("\n").endswith("," + NEW_COLS[-1]):
            return
        lines[0] = lines[0].rstrip("\n") + "," + ",".join(NEW_COLS) + "\n"
        with open(reg, "w") as f:
            f.writelines(lines)
    except OSError:
        pass

def main():
    a = sys.argv[1:]
    if len(a) < 3:
        print(__doc__); return 1
    traj, ref, tag = a[0], a[1], a[2]
    cfg = None; seg = None
    static_speed = 0.10; static_min_dur = 5.0
    wins = []
    i = 3
    while i < len(a):
        if a[i] == "--config": cfg = a[i+1]; i += 2
        elif a[i] == "--segment-start": seg = (float(a[i+1]), None); i += 2
        elif a[i] == "--segment-dur": seg = (seg[0] if seg else 0.0, float(a[i+1])); i += 2
        elif a[i] == "--static-speed": static_speed = float(a[i+1]); i += 2
        elif a[i] == "--static-min-dur": static_min_dur = float(a[i+1]); i += 2
        elif a[i] == "--win":
            if ":" in a[i+1]:
                w0, w1 = a[i+1].split(":"); wins.append((float(w0 or 0), float(w1)))
            i += 2
        else: i += 1

    t, p = load_tum(traj)
    rt, rp = load_tum(ref)
    if len(t) < 20 or len(rt) < 20:
        print("!! not enough poses (%d traj, %d ref)" % (len(t), len(rt))); return 1
    if seg:
        m = (t >= t[0] + seg[0]) & (t <= t[0] + seg[0] + (seg[1] or 1e9))
        t, p = t[m], p[m]
        if len(t) < 20:
            print("!! segment has too few poses"); return 1

    irall = np.array([int(np.argmin(np.abs(rt - x))) for x in t])
    full, al_full = score(t, p, rt, rp, 0.0)
    steady, _ = score(t, p, rt, rp, 150.0)
    rpe_d = rpe(t, al_full, rt, rp, [1, 10, 60, 120], irall=irall) if al_full is not None else {}
    # Config hash: normalize away the fields the run scripts rewrite (seq_name
    # / gnss_en / gnss_topic) so that runs of the SAME algorithmic configuration
    # group together in the registry.
    chash = "-"
    if cfg and os.path.exists(cfg):
        keep = []
        for line in open(cfg, encoding='utf-8', errors='ignore'):
            s = line.split('#')[0]
            if any(s.strip().startswith(k) for k in ("seq_name:", "gnss_en:", "gnss_topic:")):
                continue
            keep.append(s)
        chash = hashlib.md5("".join(keep).encode()).hexdigest()[:10]
    segstr = "-" if not seg else "%g+%g" % (seg[0], seg[1] or 0)

    print("== %s ==" % tag)
    if full:
        print("  full   : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f 3D_mean=%.4f 3D_max=%.4f"
              % (full['n'], full['r3'], full['r2'], full['mean3'], full['mx']))
    if steady:
        print("  steady : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
              % (steady['n'], steady['r3'], steady['r2']))
    if rpe_d:
        print("  RPE    : " + " | ".join("%ds %.3f/%.3f" % (d, v[0], v[1]) for d, v in sorted(rpe_d.items())))

    # ---- T0-1 segment scopes (parallel output; full/steady above stay untouched,
    # so the historical registry columns keep their meaning).
    seg_new = {}
    segs_out = []
    try:
        okall = np.abs(rt[irall] - t) < 0.25
        rpm = rp[irall]
        segs = static_segments(rt, rp, static_speed, 2, static_min_dur, 2.0)
        stat_ref = np.zeros(len(rt), bool)
        for a0, b0 in segs:
            stat_ref |= (rt >= a0) & (rt <= b0)
        statm = stat_ref[irall] & okall
        movm = ~stat_ref[irall] & okall
        if segs:
            print("  static segments (ref): " +
                  " ".join("[%.1f-%.1f s]" % (a0 - rt[0], b0 - rt[0]) for a0, b0 in segs) +
                  "  (%d segs, %.1f s, %.1f%% of ref)" %
                  (len(segs), sum(b0 - a0 for a0, b0 in segs),
                   100.0 * sum(b0 - a0 for a0, b0 in segs) / max(rt[-1] - rt[0], 1e-9)))
        else:
            print("  static segments (ref): none detected (speed thr %.2f m/s)" % static_speed)
        if movm.sum() >= 20 and \
                np.linalg.norm(rpm[movm][:, :2].max(0) - rpm[movm][:, :2].min(0)) >= 2.0:
            m, _, _ = fit_eval(p, rpm, movm, movm)
            if m:
                seg_new.update(n_mov=m["n"], r3_mov=m["r3"], r2_mov=m["r2"])
                print("  movfit  : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f  (Umeyama fit on moving only)"
                      % (m["n"], m["r3"], m["r2"]))
            m, _, _ = fit_eval(p, rpm, movm, statm)
            if m:
                seg_new.update(n_stat_gf=m["n"], r3_stat_gf=m["r3"], r2_stat_gf=m["r2"])
                print("  stat@movfit: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f  (same transform, static samples)"
                      % (m["n"], m["r3"], m["r2"]))
        sel = okall & ((t - t[0]) >= 150.0)
        m, _, _ = fit_eval(p, rpm, sel, sel)
        if m:
            seg_new.update(n_stdyloc=m["n"], r3_stdyloc=m["r3"], r2_stdyloc=m["r2"])
            print("  steady-loc: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f  (local fit on t>=150 s)"
                  % (m["n"], m["r3"], m["r2"]))
        pool, nseg = [], 0
        for a0, b0 in segs:
            mseg = okall & (rt[irall] >= a0) & (rt[irall] <= b0)
            m, e3, e2 = fit_eval(p, rpm, mseg, mseg)
            if m:
                nseg += 1
                pool.append(e2)
                print("    static-loc [%.1f-%.1f s]: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                      % (a0 - rt[0], b0 - rt[0], m["n"], m["r3"], m["r2"]))
        if pool:
            e2 = np.concatenate(pool)
            seg_new["r2_statloc"] = float(np.sqrt((e2 ** 2).mean()))
            print("  static-loc pooled: n=%d 2D_RMSE=%.4f  (%d segs, per-seg local fits)"
                  % (e2.size, seg_new["r2_statloc"], nseg))
        for a0, b0 in wins:
            mwin = okall & ((t - t[0]) >= a0) & ((t - t[0]) <= b0)
            m, _, _ = fit_eval(p, rpm, mwin, mwin)
            if m:
                print("  win %.0f:%.0f: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f  (local fit)"
                      % (a0, b0, m["n"], m["r3"], m["r2"]))
        segs_out = segs
    except Exception as e:
        print("  !! T0-1 segment scopes failed: %s" % e)

    print("  cfg=%s segment=%s" % (chash, segstr))

    reg = os.path.join(os.path.dirname(os.path.abspath(traj)), "registry.csv")
    new = not os.path.exists(reg)
    if not new:
        extend_registry_header(reg)
    with open(reg, "a") as f:
        if new:
            f.write("utc,tag,cfg_hash,segment,n_full,r3_full,r2_full,mx_full,n_steady,r3_steady,r2_steady,"
                    "rpe1,rpe10,rpe60,rpe120," + ",".join(NEW_COLS) + "\n")
        def g(s, k):
            return ("%.4f" % s[k]) if s else ""
        def g2(k):
            v = seg_new.get(k)
            if v is None:
                return ""
            return str(v) if isinstance(v, int) else ("%.4f" % v)
        segs_str = "-"; 
        if segs_out:
            segs_str = ";".join("%.1f+%.1f" % (a0, b0) for a0, b0 in segs_out)
        f.write("%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n" % (
            datetime.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%S"), tag, chash, segstr,
            full['n'] if full else "", g(full, 'r3'), g(full, 'r2'), g(full, 'mx'),
            steady['n'] if steady else "", g(steady, 'r3'), g(steady, 'r2'),
            "%.4f" % rpe_d[1][0] if 1 in rpe_d else "", "%.4f" % rpe_d[10][0] if 10 in rpe_d else "",
            "%.4f" % rpe_d[60][0] if 60 in rpe_d else "", "%.4f" % rpe_d[120][0] if 120 in rpe_d else "",
            g2("n_mov"), g2("r3_mov"), g2("r2_mov"),
            g2("n_stat_gf"), g2("r3_stat_gf"), g2("r2_stat_gf"),
            g2("n_stdyloc"), g2("r3_stdyloc"), g2("r2_stdyloc"), g2("r2_statloc"), segs_str))
    print("  -> appended to %s" % reg)
    return 0

if __name__ == "__main__":
    sys.exit(main())
