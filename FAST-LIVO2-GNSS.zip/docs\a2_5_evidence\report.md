# A2.5 本轮改动与结果（2026-11-05）

> 范围：针对 `fast-livo2.zip` 审查意见的 **P0（初始拟合污染）** 与
> **P1/P2（SPD、anchor 语义、trace 可维护性）** 所做的全部代码改动、测试与实验。
> 不包含 A3 静态锚，也未改变 A1/A2.2–A2.4 的默认行为。

## 0. 摘要

- 新增 `include/graph_fit.h`：把原初始拟合抽成可测试的加权 2D 相似拟合，
  并加入 Huber IRLS 与“既有拟合在给定权重下的 RMS”工具；
- `solve()` 支持 Pass 1 / 固定 mask / Pass 2 两遍拟合，带样本数、覆盖率、
  scale/yaw 变化、**accepted 样本 RMS 增益** 四类护栏，不通过就回退 Pass 1；
- 创新协方差检查改为“有限性 + 对称性 + 对角为正 + LLT 解方程”，不再用
  determinant 判 SPD，也不显式求逆；
- trace 增加 `anchor_update`，并区分 `innovation_gated` 与 `innovation_invalid`；
- 默认配置：`fit_robust_en=false`、`fit_two_pass_en=false`，A1/B3 回归通过；
- 实验结论：加护栏后 F3 在两个数据集上都以 `no_gain` 回退，TUM 与 F1 逐字节
  相同；不加护栏时 Pass 2 的 0.06% scale 变化会在 2 km 轨迹上放大为约 1 m
  ATE 退化；Huber Pass 1 自身也会改变 scale，因此 F4 同样不启用。

## 1. 元信息

| 项 | 值 |
|---|---|
| 分支 | `fix/a2-quality-channel` |
| HEAD | `68da087`（A2.5） |
| 基线 | `16cda87`（`fix/r4-backend`） |
| 上游阶段 | A1 `b7ba7cc`；A2.1 `5166a5f`；A2.2 `a005245`；A2.3 `118a30b`；A2.4 `1033039` |
| 算法二进制 | `libonline_graph.so` `0c6b9aac…`；`online_graph_node` `705fa3ee…` |
| 测试 | 13 个自测全部 PASS |
| 证据 | `docs/a2_5_evidence/`（报告、评估、fit 诊断、TUM 哈希、trace、SHA256SUMS） |

本轮的 ZIP 快照停在 `1033039`，因此包内没有 A2.5；本报告对应本地仓库
`68da087`。源码提交祖先关系需以本地 Git 输出为准（ZIP 无 `.git`）。

## 2. 审查问题与处理对照

| 审查项 | 处理 | 证据 |
|---|---|---|
| P0：A2.4 预测依赖全样本初始拟合 | 实现两遍拟合 + 固定 mask + 四类护栏；默认关闭 | §3、§6 |
| P1：determinant 判 SPD 不充分 | 对称性 + 对角为正 + LLT；`LLT::solve` | §3.5、§4 |
| P1：静态/分类拒绝历元的 anchor 语义 | 拆分 `anchor_update`；分类拒绝不更新，静态可更新 | §3.4 |
| P1：重复 `static_skip` 分支 | `1033039` 中不存在（逐行检索 `static_skip`） | §3.6 |
| P2：trace 可维护性 | `anchor_update`、`innovation_invalid`、`fit_*` 诊断 | §3.4、§3.6 |
| A1 2×2 证据缺失 | 位于 `docs/a1_evidence/` 与 `04_执行记录/03_A0-A4优化/A1/` | §9 |
| 无 Git 元数据 | 本地审计见 §1；ZIP 无法证明祖先关系 | §1 |

## 3. 代码改动

### 3.1 `include/graph_fit.h`（新增）

- `fitSimilarity2D(lio, enu, weights, options)`：加权 2D 相似变换
  `enu ≈ s·Rz(yaw)·lio + tr`，垂直通道取均值差；**无权重时与 A2.5 之前的
  公式逐项一致**（pass-1 行为不变）；
- `fitSimilarity2DRobust(...)`：Huber IRLS，`c = k·1.4826·MAD`，下限 0.2 m，
  默认 k=1.5、3 次迭代；
- `similarityFitRms(fit, lio, enu, weights)`：评估既有拟合在指定权重下的
  XY RMS，用于“第二遍是否真的更好”的判断；
- 退化 LIO 轨迹（无方向）返回 `valid=false`，不返回随机 yaw。

### 3.2 两遍拟合流程（`src/global_pose_graph.cpp`）

```text
Pass 1: 全部拟合样本 -> fit1（可选 Huber）
        fit1.scale/yaw -> 创新筛选（固定 mask）
        mask: accepted / rejected / anchor_update（每 fix 一条记录）
护栏:   样本数 / 覆盖率 / scale 变化 / yaw 变化 / accepted-RMS 增益
Pass 2: 只用 accepted 样本（关键帧样本需两侧 fix 都 accepted）-> fit2
        通过则用 fit2；否则回退 fit1，记录 fit_fb
```

关键实现点：

- 关联结果（`assoc_epochs`）在拟合前构建一次，筛选只考虑 **A1 关联有效** 的
  历元，避免 out-of-range/重复历元移动 anchor；
- 因子循环直接使用筛选得到的 **固定 mask**，不再用 fit2 重算创新检验，
  保证“筛选依据”和“因子决策”一致；
- 关键帧拟合样本只有在夹住它的两个 fix 都被接受时才参与第二遍；
- 两遍拟合要求 `rtk_innovation_gate_en && rtk_interp_en`，否则记录
  `fit_fb=innovation_off/interp_off`，不强行二次拟合。

### 3.3 护栏与回退

| 检查 | 回退原因 |
|---|---|
| accepted < max(20, 50%·n) | `too_few` |
| accepted 最大时间缺口 / 跨度 > 0.5 | `gap` |
| 参与二遍的关键帧样本不足 | `too_few_fit_samples` |
| fit2 无效 | `fit2_invalid` |
| \|scale2−scale1\| > 0.05 | `scale_delta` |
| \|yaw2−yaw1\| > 5° | `yaw_delta` |
| accepted 样本 RMS 改善 < 1% | **`no_gain`** |

`no_gain` 是本轮新增的关键护栏：Pass 2 必须在 accepted 样本上真正降低 RMS，
否则不允许仅凭“排除粗差”就改变全局 scale。原因见 §6.4。

### 3.4 anchor 语义与 trace

- `anchor_accepted`：创新通过且未被分类门控拒绝的历元；静态历元可以是
  anchor（真实观测），分类拒绝/创新拒绝的历元永远不是；
- 首个 anchor 只由质量合格、未分类门控的历元初始化；
- trace 新增 `anchor_update`（1 = 该历元移动了预测 anchor）；
- `innov_gamma=-1` 明确表示“未计算”（首个 anchor、质量不合格、关联无效），
  不是数值异常；
- 协方差非有限/非 SPD 时决策为 `innovation_invalid`，与普通
  `innovation_gated` 区分。

### 3.5 创新协方差 SPD 检查

`include/gnss_innovation.h`：

```cpp
if (!r.allFinite() || !S.allFinite()) reject;
if ((S - S.transpose()).norm() > tol || S.diagonal().minCoeff() <= 0) reject;
LLT<S> llt(S);
if (llt.info() != Success) reject;
x = llt.solve(r);
gamma = r.dot(x);
```

不再使用 `determinant() > 0`，也不显式求逆。新增测试：非对称矩阵、
两个负特征值（det>0）、病态 SPD、零协方差。

### 3.6 文件清单

| 文件 | 改动 |
|---|---|
| `include/graph_fit.h` | 新增：加权/鲁棒相似拟合、RMS 评估 |
| `include/global_pose_graph.h` | A2.5 参数、`FitDiagnostics`、`anchor_update` |
| `include/gnss_innovation.h` | LLT SPD 检查、求解代替求逆 |
| `src/global_pose_graph.cpp` | 关联预计算、Pass1/筛选/Pass2、护栏、trace、优先级 |
| `src/online_graph_node.cpp` | 读取 A2.5 参数与诊断 |
| `launch/mapping_great.launch` | A2.5 参数（默认关闭） |
| `test/graph_fit_selftest.cpp` | 新增 12 项拟合测试 |
| `test/gnss_innovation_selftest.cpp` | 增补 SPD 测试（共 11 项） |
| `CMakeLists.txt` | 注册 `graph_fit_selftest` |

复核提到的“重复 `static_skip` 分支”在 `1033039`/`68da087` 中均不存在：
插值分支只有一份 `else if (static_skip) ++rtk_skip_static;`。

## 4. 测试

| 测试 | 结果 |
|---|---|
| `graph_fit_selftest`（12 项） | PASS：精确恢复、yaw override、scale 关闭、25 m 单粗差 plain vs Huber、零权重、退化轨迹、空输入、干净数据 Huber 不变 |
| `gnss_innovation_selftest`（11 项） | PASS：χ² 边界、各向异性、1.01% 高斯拒绝率、非对称/负特征值/病态/零协方差 |
| `gnss_quality_classifier_selftest`（24 项） | PASS |
| 其余 10 个自测 | PASS |
| F3/F4 逐历元决策唯一性 | `verify_trace.py` 全部 PASS |

## 5. 实验

| 臂 | 初始拟合 | 创新门控 | 二次拟合 |
|---|---|---|---|
| F0 | 原始 | 关 | 无（= A1） |
| F1 | 原始 | 开 | 无（= B3） |
| F3 | 原始 | 开 | accepted-only（带护栏） |
| F4 | Huber | 开 | accepted-only（带护栏） |

运行方式（同输入 harness，c01 606 s / c02 805 s，1x）：

```bash
# F3
run_arm.sh c01 F3 1 1 1.0 12201 606 '' 1 '' 0 0 0 0 1 1 0
# F4
run_arm.sh c01 F4 1 1 1.0 12202 606 '' 1 '' 0 0 0 0 1 1 1
# F0/F1 回归
run_arm.sh c01 A1R 1 1 1.0 12101 606 '' 1 '' 0 0 0 0 0 0 0
run_arm.sh c01 B3R 1 1 1.0 12103 606 '' 1 '' 0 0 0 0 1 0 0
```

## 6. 结果

### 6.1 回归

| 回归 | c01 | c02 |
|---|---|---|
| A1R vs A1 | **逐字节相同** | 最大位置差 1e-11 m |
| B3R vs B3 | **逐字节相同** | 最大位置差 1.0e-9 m |

c02 的差异来自拟合求和的浮点重排，量级远低于评估噪声；c01 恰好逐字节一致。
说明 A2.5 重构未改变默认路径行为。

### 6.2 F0/F1/F3/F4（加护栏）

| 数据 | 臂 | ATE RMSE | 绝对 2D | 去 bias 2D | RPE1 | RPE10 |
|---|---|---:|---:|---:|---:|---:|
| c01 | F0 | 0.706 | 0.509 | 0.442 | 0.101 | 0.516 |
| c01 | F1 | 0.710 | 0.511 | 0.443 | 0.101 | 0.518 |
| c01 | F3 | **0.710（与 F1 逐字节相同）** | 0.511 | 0.443 | 0.101 | 0.518 |
| c01 | F4 | 1.398 | 0.586 | 0.471 | 0.100 | 0.511 |
| c02 | F0 | 1.010 | 4.049 | 0.690 | 0.186 | 0.886 |
| c02 | F1 | 1.001 | 4.048 | 0.689 | 0.186 | 0.886 |
| c02 | F3 | **1.001（与 F1 逐字节相同）** | 4.048 | 0.689 | 0.186 | 0.886 |
| c02 | F4 | 1.010 | 4.047 | 0.698 | 0.188 | 0.897 |

### 6.3 拟合诊断（最终窗口）

| 数据 | 臂 | pass | n / acc | scale1 | scale2 | yaw1→yaw2 | rms1 | rms1(accepted) | rms2 | fallback |
|---|---|---|---:|---:|---:|---|---:|---:|---:|---|
| c01 | F3 | 1 | 605 / 594 | 1.00007 | 0.99949 | 0.001→0.001 | 1.648 | 1.205 | 1.197 | **no_gain** |
| c02 | F3 | 1 | 803 / 787 | 0.99953 | 0.99915 | 0.003→0.002 | 2.088 | 1.836 | 1.833 | **no_gain** |
| c01 | F4 | 1 | 605 / 594 | 0.99934（robust） | 0.99949 | 0.000→0.001 | 1.014 | 1.203 | 1.197 | no_gain |
| c02 | F4 | 1 | 803 / 787 | 0.99948（robust） | 0.99915 | 0.002→0.002 | 0.966 | 1.837 | 1.833 | no_gain |

- F3 的 Pass 2 只把 accepted 样本 RMS 改善 **0.7%（c01）/ 0.2%（c02）**，
  低于 1% 门槛，回退 Pass 1；
- F4 的 Pass 2 同样回退，但 `fit_used` 是 **Huber Pass 1**，其 scale 已经
  偏离原拟合。

### 6.4 无护栏对照（已归档 `*_noguard.tum`）

| 数据 | 臂 | scale2 | ATE | 绝对 2D | 去 bias 2D | RPE10 |
|---|---|---:|---:|---:|---:|---:|
| c01 | F3 noguard | 0.99949 | 1.385 | 0.588 | 0.473 | 0.510 |
| c02 | F3 noguard | 0.99915 | 1.007 | 4.048 | 0.693 | 0.898 |

c01 的 0.00058 scale 变化在约 2 km 轨迹上约 1.2 m，ATE 0.710→1.385。
这是全局尺度杠杆，不是局部粗差效应；0.05 的 `scale_delta` 阈值完全拦不住它，
所以必须有 `no_gain` 护栏。

### 6.5 创新门控行为（F3/F4 不变）

| 数据 | 拒绝 | 误拒绝 (≤0.5 m) | 被拒中位误差 | 保留侧最大误差 |
|---|---:|---:|---:|---:|
| c01 | 7/398（1.8%） | 0/171 | 4.313 m | 3.103 m |
| c02 | 10/528（1.9%） | 0/335 | 15.696 m | 3.197 m |

F3/F4 的门控决策与 F1 相同，说明拟合变化没有改变“哪些历元被拒绝”。

## 7. 结论与验收

1. **P0 依赖真实存在**：创新预测确实使用全样本拟合的 scale/yaw/fit_rms；
2. **但本数据上的污染很小**：被拒绝的 7/10 个粗差对初始拟合的影响低于
   1% RMS 增益门槛，F3 正确回退，与 F1 逐字节相同；
3. **不能无护栏地二次拟合**：0.06% 的 scale 变化在长轨迹上约 1 m，c01 ATE
   从 0.710 退化到 1.385；
4. **Huber Pass 1 本身不可用**：c01 scale 从 1.00007 改到 0.99934，ATE 1.398；
   c02 也从 1.001 退到 1.010。若未来启用，需要再加 plain-vs-robust 护栏；
5. **默认值保持关闭**：`fit_robust_en=false`、`fit_two_pass_en=false`。
   A2.5 交付的是可验证、可回退的护栏与诊断，而不是默认开启的算法改动；
6. **A2 可以在此冻结**：创新门控仍默认关闭，初始拟合保持 Pass 1；A3 静态锚
   尚未开始。

审查清单对照：

| 要求 | 结果 |
|---|---|
| P0 拆出拟合与创新筛选依赖 | 已实现（Pass 1 / mask / Pass 2 / 护栏） |
| P0 新增 Pass 1 / Pass 2 流程 | 已实现并实验 |
| P0 参数与诊断字段 | `fit_*` 10 个字段，日志与 Stats |
| P1 SPD 检查 | LLT + 对称性 + 对角检查，测试覆盖 |
| P1 factor/anchor 接受状态 | `anchor_update`，分类/创新拒绝不更新 |
| P1 清理重复分支 | `1033039` 中不存在 |
| P2 trace 可维护性 | `anchor_update`、`innovation_invalid`、`gamma=-1` 语义 |
| A1 2×2 证据 | `docs/a1_evidence/`（ZIP 中已有，路径见 §9） |
| 版本审计 | 本地 Git：`68da087`，祖先链见 §1 |

## 8. 复现

```bash
# 构建（Windows 源码 -> WSL catkin 工作区）
wsl -d Ubuntu-20.04 -- bash .../06_exec/optimization/sync_and_build.sh

# 测试
~/catkin_ws/devel/lib/fast_livo/graph_fit_selftest
~/catkin_ws/devel/lib/fast_livo/gnss_innovation_selftest

# F3/F4（c01；c02 用 805 s 和对应端口）
bash run_arm.sh c01 F3 1 1 1.0 12201 606 '' 1 '' 0 0 0 0 1 1 0
bash run_arm.sh c01 F4 1 1 1.0 12202 606 '' 1 '' 0 0 0 0 1 1 1

# 评估
python3 eval_ate.py --ref .../campus01_reference.tum \
  --arm F1=.../runs/c01_B3R.tum --arm F3=.../runs/c01_F3.tum
python3 tools/fit_diag.py .../runs/c01_F3_node.log
```

## 9. 证据与提交

- 提交：`68da087`（A2.5）；工作区干净；
- 证据目录：`docs/a2_5_evidence/`
  - `README.md` / 本报告
  - `c01_fit_eval.md`、`c02_fit_eval.md`（无护栏对照）
  - `c01_guard_eval.md`、`c02_guard_eval.md`（加护栏）
  - `fit_diag.txt`
  - `tum_hashes.txt`（A1/B3/A1R/B3R/F3/F4/noguard）
  - `trace_c01_F3.csv` … `trace_c02_F4.csv`
  - `graph_fit_selftest.log`、`gnss_innovation_selftest.log`
  - `scripts/`（fit_diag、eval_ate、run_arm）
  - `SHA256SUMS`
- A1 2×2 证据：`docs/a1_evidence/`（report、ablation_c01/02、eval、residuals、
  SHA256SUMS）与 `04_执行记录/03_A0-A4优化/A1/`。

## 10. 限制

- 同输入 harness 是后端重放，不含前端 LIVO；
- 两遍拟合的护栏阈值（1%、5%、5°、0.5）是首轮工程值，尚未跨数据集标定；
- F4 的 Huber 只在 Pass 1 使用，Pass 2 用加权最小二乘；
- `h_acc/v_acc` 仍未映射到 sigma；
- 真实 bag 全链路尚未验证；A2.5 结论只覆盖当前两套同输入数据。
