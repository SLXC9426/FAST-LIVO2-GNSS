#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Does the local 1 Hz base file cover campus-02?

The RTK->bag converter (scripts/dev/rtk_flt_to_bag_c02.py) maps GREAT-PVT epochs,
which are labelled in GPS seconds-of-week, to bag time as
    bag_time = GPS_TOW + OFFSET,   OFFSET = 604800*2129 + 315964800 - 18
so the mapping is exact and reversible. This prints the GPST window of each
campus sequence next to the two local 1 Hz files' spans.
"""
OFFSET = 604800 * 2129 + 315964800 - 18      # 1603583982
BASE = ("WUH2301H.20O", 1 * 3600 + 45 * 60, 2 * 3600 + 44 * 60 + 59)
ROVER = ("SEPT3010.20O", 1 * 3600 + 20, 3 * 3600)

SEQS = [
    ("campus-01 bag", 1603764571.80, 1603765177.90),
    ("campus-02 bag", 1603765328.60, 1603766135.15),
]


def hms(s):
    return "%02d:%02d:%06.3f" % (int(s // 3600), int(s % 3600 // 60), s % 60)


def tow_of(unix):
    """GPS seconds-of-week and the time of day it falls on."""
    tow = unix - OFFSET
    return tow, tow % 86400.0


print("OFFSET = %d" % OFFSET)
print()
for name, u0, u1 in SEQS:
    t0, d0 = tow_of(u0)
    t1, d1 = tow_of(u1)
    print("%-14s TOW %9.1f .. %9.1f   = %s .. %s GPST" % (name, t0, t1, hms(d0), hms(d1)))
print()
for name, a, b in (BASE, ROVER):
    print("%-14s %s .. %s GPST" % (name, hms(a), hms(b)))
print()
for name, u0, u1 in SEQS:
    _, d0 = tow_of(u0)
    _, d1 = tow_of(u1)
    a, b = BASE[1], BASE[2]
    ok = (d0 >= a) and (d1 <= b)
    print("%-14s inside %s: %s   (margin %.1f min before, %.1f min after)"
          % (name, BASE[0], "YES" if ok else "NO", (d0 - a) / 60.0, (b - d1) / 60.0))
