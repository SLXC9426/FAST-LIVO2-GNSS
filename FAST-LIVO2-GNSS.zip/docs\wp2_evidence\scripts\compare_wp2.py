#!/usr/bin/env python3
"""WP2 same-input comparison for the corrected Pose3 online graph.

Compares:
  online_pose3_scaleoff  (new, Pose3)
  online_full_scaleoff   (old Point3 online baseline)
  offline_static_cauchy  (offline graph arm)
against the campus-02 reference.

Outputs wp2_pose3_compare.md next to this script.
"""
from __future__ import annotations

import math
from pathlib import Path

import numpy as np

ROOT = Path("/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main")
OUT = ROOT / "06_exec" / "r5_backend" / "wp2_sameinput"
OLD = ROOT / "06_exec" / "results" / "wp2_sameinput"
REF = (ROOT / "01_文档" / "02_改进与精度汇总" / "阶段1_离线图修复_2026-10-30"
       / "data" / "campus02_reference.tum")

ARMS = {
    "online_pose3": OUT / "online_pose3_scaleoff.tum",
    "online_point3": OLD / "online_full_scaleoff.tum",
    "offline_static_cauchy": OLD / "offline_static_cauchy.tum",
}


def load_tum(path: Path):
    t, p, q = [], [], []
    for line in path.open(errors="ignore"):
        s = line.split()
        if len(s) < 8:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
            q.append([float(s[4]), float(s[5]), float(s[6]), float(s[7])])
        except ValueError:
            pass
    return np.asarray(t), np.asarray(p), np.asarray(q)


def quat_to_R(q):
    x, y, z, w = q
    n = math.sqrt(x * x + y * y + z * z + w * w)
    x, y, z, w = x / n, y / n, z / n, w / n
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def match(ta, tb, tol=0.1):
    ia, ib = [], []
    for i, t in enumerate(ta):
        j = int(np.argmin(np.abs(tb - t)))
        if abs(tb[j] - t) <= tol:
            ia.append(i)
            ib.append(j)
    return np.asarray(ia), np.asarray(ib)


def umeyama(src, dst):
    """Rigid Umeyama: dst ~= R src + t."""
    mu_s = src.mean(axis=0)
    mu_d = dst.mean(axis=0)
    H = (dst - mu_d).T @ (src - mu_s)
    U, S, Vt = np.linalg.svd(H)
    R = Vt.T @ np.diag([1.0, 1.0, np.sign(np.linalg.det(Vt.T @ U.T))]) @ U.T
    t = mu_d - R @ mu_s
    return R, t


def ate(traj_p, ref_t, ref_p, tol=0.25):
    ia, ib = match(traj_p[:, 0] if traj_p.ndim > 1 else [], ref_t)
    # caller passes (N,3) positions and separate times below
    return ia, ib


def stats(values):
    v = np.asarray(values, dtype=float)
    return float(np.median(v)), float(np.percentile(v, 95)), float(np.sqrt(np.mean(v ** 2)))


def main() -> int:
    rt, rp, rq = load_tum(REF)
    rows = []
    for name, path in ARMS.items():
        if not path.is_file():
            print("MISSING", name, path)
            continue
        t, p, q = load_tum(path)
        ia, ib = match(t, rt, 0.25)
        pos = p[ia]
        ref = rp[ib]
        R, tr = umeyama(pos, ref)
        aligned = (R @ pos.T).T + tr
        e = np.linalg.norm(aligned - ref, axis=1)
        med, p95, rmse = stats(e)
        # orientation vs reference: not available in the reference, so compare
        # against the old online arm below.
        rows.append(dict(arm=name, n=len(t), matched=len(ia),
                         ate_med=med, ate_p95=p95, ate_rmse=rmse))

    base = next((r for r in rows if r["arm"] == "online_point3"), None)
    new = next((r for r in rows if r["arm"] == "online_pose3"), None)
    off = next((r for r in rows if r["arm"] == "offline_static_cauchy"), None)
    lines = ["# WP2 同输入对照：Pose3 后端", ""]
    lines += ["| arm | n | matched | ATE median | ATE p95 | ATE RMSE |",
              "|---|---:|---:|---:|---:|---:|"]
    for r in rows:
        lines.append(f"| {r['arm']} | {r['n']} | {r['matched']} | "
                     f"{r['ate_med']:.3f} | {r['ate_p95']:.3f} | {r['ate_rmse']:.3f} |")

    # Pairwise position/orientation differences.
    if new is not None and base is not None:
        tn, pn, qn = load_tum(ARMS["online_pose3"])
        tb, pb, qb = load_tum(ARMS["online_point3"])
        ia, ib = match(tn, tb, 0.1)
        dp = np.linalg.norm(pn[ia] - pb[ib], axis=1)
        ang = []
        for a, b in zip(qn[ia], qb[ib]):
            R = quat_to_R(a).T @ quat_to_R(b)
            c = np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)
            ang.append(math.degrees(math.acos(c)))
        lines += ["", "## Pose3 vs Point3 同输入", "",
                  f"- 位置差 median/p95/max：{np.median(dp):.3f} / "
                  f"{np.percentile(dp, 95):.3f} / {dp.max():.3f} m",
                  f"- 姿态差 median/p95/max：{np.median(ang):.3f} / "
                  f"{np.percentile(ang, 95):.3f} / {max(ang):.3f} deg"]

    if new is not None and off is not None:
        tn, pn, qn = load_tum(ARMS["online_pose3"])
        to, po, qo = load_tum(ARMS["offline_static_cauchy"])
        ia, ib = match(tn, to, 0.1)
        dp = np.linalg.norm(pn[ia] - po[ib], axis=1)
        lines += ["", "## Pose3 vs 离线图（static+Cauchy, no TDDD）", "",
                  f"- 位置差 median/p95/max：{np.median(dp):.3f} / "
                  f"{np.percentile(dp, 95):.3f} / {dp.max():.3f} m"]

    out = OUT / "wp2_pose3_compare.md"
    out.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("\n".join(lines))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
