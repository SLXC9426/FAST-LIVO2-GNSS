#include "gnss_epoch_pairer.h"
#include <cstdio>
#include <limits>

int main() {
  using Join=fast_livo::GnssEpochPairer<int>;
  int failures=0;
  auto check=[&](bool ok,const char *name){ std::printf("%s %s\n",ok?"PASS":"FAIL",name); if(!ok)++failures; };
  fast_livo::GnssQualityRecord q; q.valid=true; q.num_sv=17;
  for(bool quality_first:{false,true}) {
    Join j;
    if(quality_first) j.addQuality(100,q,0); else j.addFix(100,7,0);
    if(quality_first) j.addFix(100,7,.1); else j.addQuality(100,q,.1);
    const auto r=j.drain(.1);
    check(r.size()==1 && r[0].matched && r[0].fix==7 && r[0].quality.num_sv==17,"both arrival orders preserve exact epoch");
    check(r.size()==1 && r[0].fix_arrival==(quality_first?.1:0.) &&
        r[0].quality_arrival==(quality_first?0.:.1) && r[0].drain_time==.1 &&
        r[0].pending_fixes==1 && r[0].pending_quality==1,"receive timing preserves both arrival orders");
    j.addFix(100,8,.12); j.addQuality(100,q,.12);
    check(j.drain(.4).empty(),"completed epoch cannot be emitted twice");
  }
  {
    Join j; j.addFix(100,1,0); j.addFix(200,2,.01); j.addQuality(200,q,.02);
    check(j.drain(.1).empty(),"later match cannot overtake earlier pending fix");
    const auto r=j.drain(.3);
    check(r.size()==2 && !r[0].matched && r[1].matched && r[0].stamp==100,"timeout releases UNKNOWN then exact later match in order");
    check(r.size()==2 && std::isnan(r[0].quality_arrival) && r[0].drain_time==.3 &&
        r[0].pending_fixes==2 && r[1].pending_fixes==1 &&
        r[1].quality_arrival==.02 && r[1].drain_time==.3,"timeout overshoot and head-of-line delay remain observable");
    j.addQuality(100,q,.31);
    check(j.drain(.4).empty() && j.counters().late_quality==1,"late quality never triggers another update");
  }
  {
    Join j; j.addFix(100,1,0); j.addQuality(101,q,.01);
    const auto r=j.drain(.3);
    check(r.size()==1 && !r[0].matched,"one-nanosecond mismatch is never substituted");
    j.drain(6.);
    check(j.pendingQuality()==0,"orphan quality expires without a sensor clock");
    j.reset(); j.addFix(1,2,7.); j.addQuality(1,q,7.01);
    check(j.drain(7.02).size()==1 && j.counters().resets==1,"explicit replay reset accepts earlier sensor epochs");
  }
  {
    Join j(.2,1); j.addFix(1,1,0); j.addFix(2,2,0); j.addQuality(1,q,0); j.addQuality(2,q,0);
    check(j.counters().overflow==2 && j.pending()==1 && j.pendingQuality()==1,"bounded buffers account for refused admissions");
  }
  try { Join j(std::numeric_limits<double>::quiet_NaN()); check(false,"NaN wait rejected"); }
  catch(const std::invalid_argument &) { check(true,"NaN wait rejected"); }
  return failures?1:0;
}
