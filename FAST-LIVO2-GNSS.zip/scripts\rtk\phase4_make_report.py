#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Build the Phase-4 Chinese report (Markdown + DOCX) from measured CSVs.

No numbers are hand-entered: every result comes from
  metrics/phase4_summary.csv
  metrics/phase4_segments.csv
  metrics/phase4_runs.csv
  metrics/phase4_deltas.csv
and the [RTK] health lines of the Phase-4 logs.
"""
import csv
import os
import re
import statistics

from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

BASE = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\02_评估结果\rtk_tight_eval"
MET = os.path.join(BASE, "metrics")
FIG = os.path.join(BASE, "figures")
LOGD = os.path.join(BASE, "logs")
OUT_MD = os.path.join(BASE, "REPORT.md")
OUT_DOCX = os.path.join(BASE, "REPORT.docx")
ARMS = ["LIVO", "RTK tight", "RTK robust"]
ARM_CN = {"LIVO": "原始 FAST-LIVO2", "RTK tight": "RTK 紧组合", "RTK robust": "RTK + IMU 抗差"}
METRICS = [
    ("full_3D", "全程 3D ATE RMSE", "m"),
    ("full_2D", "全程 2D ATE RMSE", "m"),
    ("steady_3D", "稳态 3D ATE RMSE", "m"),
    ("steady_2D", "稳态 2D ATE RMSE", "m"),
    ("RPE_1s", "RPE 1 s", "m"),
    ("RPE_10s", "RPE 10 s", "m"),
    ("RPE_60s", "RPE 60 s", "m"),
    ("RPE_120s", "RPE 120 s", "m"),
    ("static_loc_2D", "静止段 static-loc 2D", "m"),
]
SEGS = [
    ("convergence_0_79", "0–79 s（收敛/对齐）"),
    ("multipath_79_201", "79–201 s（多路径/回程）"),
    ("recovery_201_300", "201–300 s（恢复）"),
    ("steady_300_603", "300–603 s（稳态）"),
    ("full_0_603", "0–603 s（全程）"),
]


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def fmt(v, nd=2):
    try:
        return f"{float(v):.{nd}f}"
    except (TypeError, ValueError):
        return "—"


def load_summary():
    out = {}
    for r in read_csv(os.path.join(MET, "phase4_summary.csv")):
        out.setdefault(r["metric"], {})[r["arm"]] = r
    return out


def load_segments():
    out = {}
    for r in read_csv(os.path.join(MET, "phase4_segments.csv")):
        out.setdefault(r["segment"], {})[r["arm"]] = r
    return out


def load_deltas():
    return {r["metric"]: r for r in read_csv(os.path.join(MET, "phase4_deltas.csv"))}


def parse_health(path):
    acc_re = re.compile(r"\[RTK\] accept t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+)/([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+) "
                        r"\|dx_pos\|=([\d.]+) P_pos=([\d.]+)")
    rej_re = re.compile(r"\[RTK\] reject t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+) gate=([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+)")
    rj = re.compile(r"rej_code=(\d+) rej_phase=(\d+)")
    acc, rej, rc, rp = [], [], 0, 0
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = acc_re.search(line)
            if m:
                acc.append(dict(dx=float(m.group(9)), gamma=float(m.group(5)),
                                phase=float(m.group(8)), amb=int(m.group(3))))
            if rej_re.search(line):
                rej.append(1)
            m = rj.search(line)
            if m:
                rc += int(m.group(1)); rp += int(m.group(2))
    if not acc and not rej:
        return None
    return dict(n=len(acc) + len(rej), acc=len(acc), rej=len(rej),
                rc=rc, rp=rp,
                med_dx=statistics.median([a["dx"] for a in acc]) if acc else 0.0,
                med_gamma=statistics.median([a["gamma"] for a in acc]) if acc else 0.0,
                last_amb=acc[-1]["amb"] if acc else 0)


def health_for(prefix):
    """Aggregate the N runs of an arm from logs/<prefix>_r*.log."""
    files = sorted([f for f in os.listdir(LOGD)
                    if f.startswith(prefix) and f.endswith(".log")])
    hs = [parse_health(os.path.join(LOGD, f)) for f in files]
    hs = [h for h in hs if h]
    if not hs:
        return None
    return dict(n_runs=len(hs),
                ev=sum(h["n"] for h in hs), acc=sum(h["acc"] for h in hs),
                rej=sum(h["rej"] for h in hs), rc=sum(h["rc"] for h in hs),
                rp=sum(h["rp"] for h in hs),
                med_dx=statistics.median([h["med_dx"] for h in hs]),
                med_gamma=statistics.median([h["med_gamma"] for h in hs]),
                last_amb=int(statistics.median([h["last_amb"] for h in hs])))


def add_page_number(paragraph):
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), " PAGE ")
    run = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "1"
    run.append(t)
    fld.append(run)
    paragraph._p.append(fld)


def set_cell_shading(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color)
    tcPr.append(shd)


def set_run_font(run, size=10.5, bold=False, east="SimSun", ascii_="Times New Roman"):
    run.font.name = ascii_
    run.font.size = Pt(size)
    run.bold = bold
    r = run._element
    r.rPr.rFonts.set(qn("w:eastAsia"), east)


def add_body(doc, text, indent=True, size=10.5, space_after=4):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    pf = p.paragraph_format
    pf.line_spacing = 1.3
    pf.space_after = Pt(space_after)
    if indent:
        pf.first_line_indent = Pt(21)
    r = p.add_run(text)
    set_run_font(r, size=size)
    return p


def add_heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    r = p.add_run(text)
    set_run_font(r, size=14 if level == 1 else 12, bold=True, east="SimHei")
    return p


def add_caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    set_run_font(r, size=9, east="SimSun")
    r.italic = True


def add_table(doc, header, rows, widths=None, font_size=8.5):
    table = doc.add_table(rows=1, cols=len(header))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    hdr = table.rows[0].cells
    for i, h in enumerate(header):
        hdr[i].text = ""
        p = hdr[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p.add_run(str(h))
        set_run_font(r, size=font_size, bold=True, east="SimHei")
        set_cell_shading(hdr[i], "E7E6E6")
    for row in rows:
        cells = table.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.CENTER if i else WD_ALIGN_PARAGRAPH.LEFT
            r = p.add_run(str(v))
            set_run_font(r, size=font_size)
    if widths:
        for i, w in enumerate(widths):
            for row in table.rows:
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def add_figure(doc, name, caption, width=15.5):
    path = os.path.join(FIG, name + ".png")
    if os.path.exists(path):
        p = doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(path, width=Cm(width))
        add_caption(doc, caption)


def build_md(summary, segs, deltas, health_t, health_r):
    L = []
    A = lambda m, arm: float(summary[m][arm]["median"])
    L.append("# FAST-LIVO2 + RTK 紧组合前端评估\n")
    L.append("> 数据：GREAT campus-01，607 s；三方案同二进制 N=3。")
    L.append("> 代码：`00_源代码/FAST-LIVO2-main`；结果：`02_评估结果/rtk_tight_eval`。\n")
    L.append("## 摘要\n")
    dt3 = deltas.get("full_3D", {}).get("tight-LIVO", "—")
    dt2 = deltas.get("full_2D", {}).get("tight-LIVO", "—")
    dr3 = deltas.get("full_3D", {}).get("robust-LIVO", "—")
    dr2 = deltas.get("full_2D", {}).get("robust-LIVO", "—")
    L.append(f"原始 FAST-LIVO2、RTK 观测级紧组合（tight）与 RTK + IMU 抗差（robust）"
             f"的全程 3D ATE RMSE 中位数分别为 {fmt(A('full_3D','LIVO'))}、"
             f"{fmt(A('full_3D','RTK tight'))}、{fmt(A('full_3D','RTK robust'))} m；"
             f"2D 分别为 {fmt(A('full_2D','LIVO'))}、{fmt(A('full_2D','RTK tight'))}、"
             f"{fmt(A('full_2D','RTK robust'))} m。N=3 同二进制比较中，tight 相对基线"
             f"全程 3D {dt3} m、2D {dt2} m；robust 相对基线全程 3D {dr3} m、2D {dr2} m。"
             f"三者差异均在 607 s 运行间噪声内，没有一致占优。\n")
    L.append("## 1. 背景与目标\n")
    L.append("本项目以 FAST-LIVO2 的 19 维 ESIKF 为统一前端，将 GPS/BDS 双差伪距与载波相位"
             "直接增广进滤波，估计每对双差的浮点模糊度；不使用因子图、不做整数模糊度固定。"
             "在 campus-01 上比较原始 LIVO、RTK tight 与 RTK + IMU 抗差三方案。\n")
    L.append("## 2. 方法\n")
    L.append("### 2.1 双差观测\n")
    L.append("流动站与基站均为 1 Hz RINEX。GPS 使用 L1 C1C/L1C 与 L2 C2W/L2W；BDS 使用 "
             "B2I C7I/L7I 与 B3I C6I/L6I；高度截止 10°。RINEX 为 GPS 时，bag/参考为 UTC，"
             "2020 年差 18 s；BDS 导航为 BDT，解析时 +14 s。基站采用 fixbase 坐标。\n")
    L.append("### 2.2 前端 ESIKF 增广\n")
    L.append("保留 19 维基础状态，另维护每对双差一个浮点模糊度（米）及其协方差。双差在基站中心 "
             "ENU 中计算，复用现有 ENU→world 对齐与 IMU 时间传播；更新采用块对角近似 "
             "P_xa=0，码/相位双差联合更新，slip/ref_change 重置模糊度。\n")
    L.append("### 2.3 IMU 抗差\n")
    L.append("robust 分支加入 IGG3 相对权与 IMU/LiDAR 先验绝对码门限：码以 2.5 m 标准化、"
             "κ=3（7.5 m 门限）；相位以 0.05 m 标准化、k0=3/k1=6；"
             "相位残差超过 0.5 m 时重置该对模糊度。\n")
    L.append("## 3. 实验设置\n")
    L.append("campus-01，607 s（GPS 02:09:50–02:19:56 = UTC 02:09:32–02:19:38）；"
             "三方案同二进制，N=3；SE(3) Umeyama 对齐后计算 ATE/RPE。"
             "RTK 的 ENU→world 对齐在约 63 s 锁定，因此 0–79 s 为收敛段。\n")
    L.append("## 4. 结果\n")
    L.append("### 4.1 三方案 N=3\n")
    L.append("| 指标 | 原始 FAST-LIVO2 | RTK tight | RTK robust | tight−LIVO | robust−tight |")
    L.append("|---|---:|---:|---:|---:|---:|")
    for key, label, _ in METRICS:
        s = summary.get(key, {})
        if not all(a in s for a in ARMS):
            continue
        d = deltas.get(key, {})
        nd = 3 if key == "static_loc_2D" else 2
        L.append(f"| {label} | {fmt(s['LIVO']['median'], nd)} | {fmt(s['RTK tight']['median'], nd)} | "
                 f"{fmt(s['RTK robust']['median'], nd)} | {d.get('tight-LIVO','—')} | "
                 f"{d.get('robust-tight','—')} |")
    L.append("\n### 4.2 分段 3D RMSE（m）\n")
    L.append("| 分段 | LIVO | tight | robust |")
    L.append("|---|---:|---:|---:|")
    for name, label in SEGS:
        s = segs.get(name, {})
        if not all(a in s for a in ARMS):
            continue
        L.append(f"| {label} | {fmt(s['LIVO']['median_3D'])} | "
                 f"{fmt(s['RTK tight']['median_3D'])} | {fmt(s['RTK robust']['median_3D'])} |")
    L.append("\n### 4.3 更新健康度\n")
    if health_t:
        L.append(f"- tight：{health_t['n_runs']} 次运行，接受 {health_t['acc']}/{health_t['ev']}，"
                 f"行剔除 code={health_t['rc']} / phase={health_t['rp']}，"
                 f"中位 |dx_pos|={fmt(health_t['med_dx'],3)} m。")
    if health_r:
        L.append(f"- robust：{health_r['n_runs']} 次运行，接受 {health_r['acc']}/{health_r['ev']}，"
                 f"行剔除 code={health_r['rc']} / phase={health_r['rp']}，"
                 f"中位 |dx_pos|={fmt(health_r['med_dx'],3)} m。")
    L.append("\n### 4.4 图\n")
    L.append("![轨迹](figures/fig1_trajectory_enu.png)\n")
    L.append("![误差时序](figures/fig2_error_time.png)\n")
    L.append("![分段](figures/fig3_segments.png)\n")
    L.append("![误差着色轨迹](figures/fig4_error_map.png)\n")
    L.append("![GNSS 质量](figures/fig5_gnss_quality.png)\n")
    L.append("![N=3 与消融](figures/fig6_variability_ablation.png)\n")
    L.append("## 5. 讨论\n")
    L.append("N=3 同二进制下三方案没有一致占优：tight 全程 3D +0.03 m、2D +0.10 m、"
             "稳态 3D +0.04 m；仅稳态 2D −0.02 m、RPE 60 s −0.02 m。"
             "robust 相对 tight 全程 3D −0.11 m、稳态 3D −0.16 m；相对基线分别为 "
             "−0.08 m、−0.12 m；但相对基线 2D +0.18 m、RPE 120 s +0.10 m。"
             "这些差异均落在 607 s 单次运行噪声（约 0.8–1.4 m 3D、0.2–0.4 m 2D）内，"
             "不能宣称任何方案稳定更优。Phase 2 的单次 full 3D 2.261 m 也在基线运行范围内，"
             "属于一次较好的抽样，而非可复现的系统增益。\n")
    L.append("robust 与 tight 互有高低，未形成一致优势。原因是 RTK 双差码残差仅 1.5–4 m，"
             "而不是文档 PPP 中的 250 m 级多路径；7.5 m 绝对门限缺少可剔除的粗差，"
             "3 m 级系统性码偏差仍在门限内；tight 的卡方门已拒绝坏历元，robust 接受更多历元后"
             "2D/长 RPE 略差。robust 更适合 GNSS 观测质量更差、出现大残差的场景。\n")
    L.append("## 6. 局限\n")
    L.append("仅 campus-01；浮点 RTK，无整数模糊度固定；BDS GEO/Galileo/GLONASS 未用；"
             "码多路径与约 63 s 对齐前窗口限制；N=3 仍不足以裁决小于项目噪声地板的差异；"
             "未做在线实时性验收。\n")
    L.append("## 附录 A：历史 PPP 结果（保留，不可直接比较）\n")
    L.append("FAST-GLIVO 文档中的 PPP 结果：基线 15.369 m、PPP 紧组合 12.877 m、"
             "PPP + IMU 门限 11.71 m。该组结果来自另一套 PPP 前端/口径，"
             "与本项目当前 FAST-LIVO2 + RTK 的基线（约 2.9 m）不可直接比较；"
             "此处保留作为历史数据与写作参考。\n")
    L.append("## 复现\n")
    L.append("```bash\n"
             "# Phase 4 批量\n"
             "wsl -d Ubuntu-20.04 -e bash /mnt/c/.../scripts/eval/run_phase4_three_arms.sh\n"
             "# 汇总/图/报告\n"
             "python3 scripts/rtk/phase4_analyze.py\n"
             "python3 scripts/rtk/phase4_gnss_quality.py\n"
             "python3 scripts/rtk/phase4_plots.py\n"
             "python3 scripts/rtk/phase4_make_report.py\n"
             "```\n")
    return "\n".join(L)


def build_docx(summary, segs, deltas, health_t, health_r):
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
    sec.left_margin = Cm(2.4); sec.right_margin = Cm(2.2)

    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(30)
    r = p.add_run("FAST-LIVO2 + RTK 紧组合前端评估")
    set_run_font(r, size=20, bold=True, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("观测级双差 RTK、IMU 抗差与三方案对比")
    set_run_font(r, size=13, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("GREAT campus-01 · 607 s · 同二进制 N=3 · 2026-10-18")
    set_run_font(r, size=10)
    doc.add_paragraph()

    add_heading(doc, "摘要", 1)
    dt3 = deltas.get("full_3D", {}).get("tight-LIVO", "—")
    dt2 = deltas.get("full_2D", {}).get("tight-LIVO", "—")
    dr3 = deltas.get("full_3D", {}).get("robust-LIVO", "—")
    dr2 = deltas.get("full_2D", {}).get("robust-LIVO", "—")
    add_body(doc, f"原始 FAST-LIVO2、RTK 观测级紧组合（tight）与 RTK + IMU 抗差（robust）"
                  f"的全程 3D ATE RMSE 中位数分别为 {fmt(summary['full_3D']['LIVO']['median'])}、"
                  f"{fmt(summary['full_3D']['RTK tight']['median'])}、"
                  f"{fmt(summary['full_3D']['RTK robust']['median'])} m；2D 分别为 "
                  f"{fmt(summary['full_2D']['LIVO']['median'])}、"
                  f"{fmt(summary['full_2D']['RTK tight']['median'])}、"
                  f"{fmt(summary['full_2D']['RTK robust']['median'])} m。N=3 同二进制比较中，"
                  f"tight 相对基线全程 3D {dt3} m、2D {dt2} m；robust 相对基线全程 3D {dr3} m、"
                  f"2D {dr2} m；三者差异均在 607 s 运行间噪声内，没有一致占优。"
                  "本文给出方法、N=3 结果、分段分析、限制与复现方式。")

    add_heading(doc, "1 背景与目标", 1)
    add_body(doc, "本项目以 FAST-LIVO2 的 19 维 ESIKF 为统一前端，将 GPS/BDS 双差伪距与载波相位"
                  "直接增广进滤波，估计每对双差的浮点模糊度；不使用因子图、不做整数模糊度固定。"
                  "在 campus-01 607 s 上比较原始 LIVO、RTK tight 与 RTK + IMU 抗差三方案。")

    add_heading(doc, "2 方法", 1)
    add_heading(doc, "2.1 双差观测预处理", 2)
    add_body(doc, "流动站与基站均为 1 Hz RINEX。GPS 使用 L1 C1C/L1C 与 L2 C2W/L2W；BDS 使用 "
                  "B2I C7I/L7I 与 B3I C6I/L6I；高度截止 10°。RINEX 为 GPS 时，bag/参考为 UTC，"
                  "2020 年差 18 s；BDS 导航为 BDT，解析时 +14 s；基站采用 fixbase 坐标。"
                  "输出 /rtk/dd（fast_livo/RtkDD），583 条消息/9,200 行双差。")
    add_heading(doc, "2.2 前端 ESIKF 增广", 2)
    add_body(doc, "保留 19 维基础状态，另维护每对双差一个浮点模糊度（米）及其协方差。"
                  "双差在基站中心 ENU 中计算，复用现有 ENU→world 对齐与 IMU 时间传播；"
                  "更新采用块对角近似 P_xa=0，码/相位双差联合更新，slip/ref_change 重置模糊度，"
                  "并对 |r_phase|>0.5 m 做残差型周跳修复。")
    add_heading(doc, "2.3 IMU 抗差", 2)
    add_body(doc, "robust 分支加入 IGG3 相对权与 IMU/LiDAR 先验绝对码门限：码以 2.5 m 标准化、"
                  "κ=3（7.5 m 门限）；相位以 0.05 m 标准化、k0=3/k1=6；"
                  "相位残差超过 0.5 m 时重置该对模糊度。")

    add_heading(doc, "3 实验设置", 1)
    add_body(doc, "campus-01，607 s（GPS 02:09:50–02:19:56 = UTC 02:09:32–02:19:38）；"
                  "三方案同二进制，N=3；SE(3) Umeyama 对齐后计算 ATE/RPE；RTK 的 ENU→world "
                  "对齐在约 63 s 锁定，因此 0–79 s 为收敛段。")

    add_heading(doc, "4 结果", 1)
    add_heading(doc, "4.1 三方案 N=3", 2)
    header = ["指标", "原始 FAST-LIVO2", "RTK tight", "RTK robust", "tight−LIVO", "robust−tight"]
    rows = []
    for key, label, _ in METRICS:
        s = summary.get(key, {})
        if not all(a in s for a in ARMS):
            continue
        d = deltas.get(key, {})
        nd = 3 if key == "static_loc_2D" else 2
        rows.append([label, fmt(s["LIVO"]["median"], nd), fmt(s["RTK tight"]["median"], nd),
                     fmt(s["RTK robust"]["median"], nd), d.get("tight-LIVO", "—"),
                     d.get("robust-tight", "—")])
    add_table(doc, header, rows, widths=[5.0, 3.0, 2.6, 2.6, 2.2, 2.2])
    add_caption(doc, "表 1 三方案 N=3 指标中位数（m）。差值来自中位数之差。")

    add_heading(doc, "4.2 分段 3D RMSE", 2)
    header = ["分段", "LIVO", "RTK tight", "RTK robust"]
    rows = []
    for name, label in SEGS:
        s = segs.get(name, {})
        if not all(a in s for a in ARMS):
            continue
        rows.append([label, fmt(s["LIVO"]["median_3D"]),
                     fmt(s["RTK tight"]["median_3D"]),
                     fmt(s["RTK robust"]["median_3D"])])
    add_table(doc, header, rows, widths=[6.5, 3.0, 3.0, 3.0])
    add_caption(doc, "表 2 分段 3D ATE RMSE 中位数（m，N=3；全局 Umeyama 对齐）。")

    add_heading(doc, "4.3 更新健康度", 2)
    rows = []
    for name, h in (("RTK tight", health_t), ("RTK robust", health_r)):
        if h:
            rows.append([name, str(h["n_runs"]), str(h["ev"]), str(h["acc"]), str(h["rej"]),
                         f"{100.0*h['acc']/max(h['ev'],1):.1f}%",
                         f"{h['rc']} / {h['rp']}", fmt(h["med_dx"], 3)])
    add_table(doc, ["方案", "运行数", "评估", "接受", "拒绝", "接受率", "行剔除 code/phase",
                    "中位 |dx_pos| (m)"], rows,
              widths=[2.6, 1.4, 1.4, 1.4, 1.4, 1.6, 3.0, 2.4], font_size=8)
    add_caption(doc, "表 3 更新健康度（N=3 汇总）。")

    add_heading(doc, "4.4 图", 2)
    add_figure(doc, "fig1_trajectory_enu", "图 1 三方案 ENU 轨迹（代表运行）；黑虚线为参考轨迹。")
    add_figure(doc, "fig2_error_time", "图 2 逐帧 3D 定位误差；灰带为 RTK 对齐前 0–63 s。")
    add_figure(doc, "fig3_segments", "图 3 分段 3D/2D ATE RMSE（N=3 中位数，全局 Umeyama 对齐）。")
    add_figure(doc, "fig4_error_map", "图 4 RTK tight 与 robust 的误差着色轨迹（同一色标）。")
    add_figure(doc, "fig5_gnss_quality", "图 5 GNSS 观测质量：双差码残差、可见双差对、周跳；"
                                        "灰带为观测退化窗口（400–520 s），虚线为 RTK 对齐时刻。")
    add_figure(doc, "fig6_variability_ablation", "图 6 N=3 波动（a）与 robust−tight 分段 3D 差（b）。")

    add_heading(doc, "5 讨论", 1)
    add_body(doc, "N=3 同二进制下三方案没有一致占优：tight 全程 3D +0.03 m、2D +0.10 m、"
                  "稳态 3D +0.04 m；仅稳态 2D −0.02 m、RPE 60 s −0.02 m。"
                  "robust 相对 tight 全程 3D −0.11 m、稳态 3D −0.16 m；相对基线分别为 "
                  "−0.08 m、−0.12 m；但相对基线 2D +0.18 m、RPE 120 s +0.10 m。"
                  "这些差异均落在 607 s 单次运行噪声（约 0.8–1.4 m 3D、0.2–0.4 m 2D）内，"
                  "不能宣称任何方案稳定更优。Phase 2 的单次 full 3D 2.261 m 也在基线运行范围内。")
    add_body(doc, "robust 与 tight 互有高低，未形成一致优势。原因是 RTK 双差码残差仅 1.5–4 m，"
                  "而不是文档 PPP 中的 250 m 级多路径；7.5 m 绝对门限缺少可剔除的粗差，"
                  "3 m 级系统性码偏差仍在门限内；tight 的卡方门已拒绝坏历元，robust 接受更多历元后"
                  "2D/长 RPE 略差。robust 更适合 GNSS 观测质量更差、出现大残差的场景。")

    add_heading(doc, "6 局限", 1)
    add_body(doc, "仅 campus-01；浮点 RTK，无整数模糊度固定；BDS GEO/Galileo/GLONASS 未用；"
                  "码多路径与约 63 s 对齐前窗口限制；N=3 仍不足以裁决小于项目噪声地板的差异；"
                  "未做在线实时性验收。")

    add_heading(doc, "附录 A 历史 PPP 结果（保留，不可直接比较）", 1)
    add_body(doc, "FAST-GLIVO 文档中的 PPP 结果：基线 15.369 m、PPP 紧组合 12.877 m、"
                  "PPP + IMU 门限 11.71 m。该组结果来自另一套 PPP 前端/口径，"
                  "与本项目当前 FAST-LIVO2 + RTK 的基线（约 2.9 m）不可直接比较；"
                  "此处保留作为历史数据与写作参考。")

    add_heading(doc, "复现", 1)
    add_body(doc, "Phase 4 批量：scripts/eval/run_phase4_three_arms.sh；"
                  "汇总/图：scripts/rtk/phase4_analyze.py、phase4_gnss_quality.py、"
                  "phase4_plots.py、phase4_make_report.py。结果目录：02_评估结果/rtk_tight_eval。")

    footer = sec.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    add_page_number(p)

    doc.save(OUT_DOCX)
    print("wrote", OUT_DOCX)


def main():
    summary = load_summary()
    segs = load_segments()
    deltas = load_deltas()
    health_t = health_for("phase4_c01_tight")
    health_r = health_for("phase4_c01_robust") or health_for("phase3_c01_rtk_robust")
    md = build_md(summary, segs, deltas, health_t, health_r)
    with open(OUT_MD, "w", encoding="utf-8") as f:
        f.write(md)
    print("wrote", OUT_MD)
    build_docx(summary, segs, deltas, health_t, health_r)


if __name__ == "__main__":
    main()
