# A2.5：初始拟合抗粗差（两遍拟合 + Huber）

分支：`fix/a2-quality-channel`（A2.4 之后）
目标：切断 A2.4 创新门控对“被全部 RTK 样本污染的初始拟合”的依赖，而不是单纯
降低 `fit_rms`。

## 1. 问题（P0）

`src/global_pose_graph.cpp` 的顺序是：先用全部 `fx` 估计 yaw/scale/translation，
再由 `fit_rms` 得到 `sig_rtk_xy`，最后才跑 A2.4 创新检验。创新预测使用
`scale * Rz(yaw) * disp_lio`，检验协方差使用 `sig_rtk_xy`。因此一个 26–29 m
粗差会先污染拟合，再去检验“它自己是否应被拒绝”——独立性弱于文档表述。

## 2. 实现

### 2.1 拟合模块

新增 `include/graph_fit.h`（header-only，Eigen）：

- `fitSimilarity2D()`：加权 2D 相似变换，**与 A2.5 之前的公式逐项一致**
  （无权重时即旧实现）；
- `fitSimilarity2DRobust()`：Huber IRLS，`c = k * 1.4826 * MAD`，下限 0.2 m，
  默认 k=1.5、3 次迭代；
- 退化 LIO 轨迹（无方向）返回 `valid=false`，不返回随机 yaw。

### 2.2 两遍拟合

```text
Pass 1: 全部样本 -> fit1（可选 Huber）
        fit1.scale / yaw -> 创新筛选（固定 mask）
        mask: 每个固定历元 accepted / rejected / anchor_update
健康检查: 样本数、accepted 比例、最大时间缺口、scale/yaw 变化
Pass 2: 只用 accepted 样本（关键帧样本需两侧 fix 都 accepted）-> fit2
        通过检查则用 fit2，否则回退 fit1 并记录 fallback
```

关键点：

- **固定 mask**：筛选只做一次（用 fit1 参数）；因子循环直接复用 mask，不再用
  fit2 重算，避免“筛选依据”和“因子决策”不一致；
- 关键帧拟合样本只有在夹住它的两个 fix 都被接受时才参与第二遍；
- 被拒绝历元不更新 anchor；静态历元仍是真实观测，可更新 anchor；
- 分类门控拒绝的历元不更新 anchor（即使创新通过）；
- 两遍拟合要求 `rtk_innovation_gate_en && rtk_interp_en`，否则记录
  `fit_fb=innovation_off/interp_off`，不强行二次拟合。

### 2.3 健康检查与回退

| 检查 | 回退原因 |
|---|---|
| accepted < max(20, 50%·n) | `too_few` |
| accepted 最大时间缺口 / 跨度 > 0.5 | `gap` |
| 参与二遍的关键帧样本不足 | `too_few_fit_samples` |
| fit2 无效 | `fit2_invalid` |
| \|scale2−scale1\| > 0.05 | `scale_delta` |
| \|yaw2−yaw1\| > 5° | `yaw_delta` |

### 2.4 诊断字段

节点日志新增：

```
fit_pass fit_n fit_acc fit_s1 fit_s2 fit_y1 fit_y2 fit_r1 fit_r2 fit_fb
```

`Stats::FitDiagnostics` 同步保存这些值。

### 2.5 P1 修复（同批）

- `gnss_innovation.h`：SPD 检查改为“有限性 + 对称性 + 对角为正 + LLT”，
  用 `LLT::solve` 求 `S^-1 r`，不再显式求逆；新增非对称、负特征值、病态矩阵测试；
- trace 新增 `anchor_update`，并区分 `innovation_gated` 与
  `innovation_invalid`（协方差非有限/非 SPD）；
- 决策优先级统一为 `assoc_invalid → quality → static → class_gated →
  innovation_gated/invalid → factor`；
- 复核提到的重复 `static_skip` 分支在 `1033039` 中不存在（已逐行核对），
  本次未改。

## 3. 测试

- `graph_fit_selftest`（新增）：精确恢复、frontend yaw override、scale 关闭、
  25 m 单粗差（plain vs Huber）、零权重剔除、退化轨迹、空输入、干净数据
  Huber 不变；
- `gnss_innovation_selftest` 增补 3 项协方差测试；
- 全部 13 个自测 PASS。

## 4. 实验

| 臂 | 初始拟合 | 创新门控 | 二次拟合 |
|---|---|---|---|
| F0 | 原始 | 关 | 无（= A1） |
| F1 | 原始 | 开 | 无（= B3） |
| F3 | 原始 | 开 | accepted-only |
| F4 | Huber | 开 | accepted-only |

回归：F0/F1 必须与 A1/B3 的 TUM **逐文件相同**。

### 4.1 回归

| 回归 | 结果 |
|---|---|
| A1R vs A1 | c01 **逐字节相同**；c02 最大位置差 1e-11 m（浮点重排） |
| B3R vs B3 | c01 **逐字节相同**；c02 最大位置差 1.0e-9 m |

说明：拟合函数重排了求和顺序，c02 出现 1e-11~1e-9 m 的浮点差异，量级远低于
任何评估噪声；c01 恰好逐字节一致。

### 4.2 F0/F1/F3/F4（F3/F4 为加护栏后的结果）

| 数据 | 臂 | ATE RMSE | 绝对 2D | 去 bias 2D | RPE1 | RPE10 |
|---|---|---:|---:|---:|---:|---:|
| c01 | F0（A1） | 0.706 | 0.509 | 0.442 | 0.101 | 0.516 |
| c01 | F1（B3） | 0.710 | 0.511 | 0.443 | 0.101 | 0.518 |
| c01 | F3 | **0.710（与 F1 逐字节相同）** | 0.511 | 0.443 | 0.101 | 0.518 |
| c01 | F4 | 1.398 | 0.586 | 0.471 | 0.100 | 0.511 |
| c02 | F0（A1） | 1.010 | 4.049 | 0.690 | 0.186 | 0.886 |
| c02 | F1（B3） | 1.001 | 4.048 | 0.689 | 0.186 | 0.886 |
| c02 | F3 | **1.001（与 F1 逐字节相同）** | 4.048 | 0.689 | 0.186 | 0.886 |
| c02 | F4 | 1.010 | 4.047 | 0.698 | 0.188 | 0.897 |

拟合诊断（最终窗口）：

| 数据 | 臂 | pass | n / acc | scale1 | scale2 | yaw1→yaw2 | rms1 | rms1(accepted) | rms2 | fallback |
|---|---|---|---:|---:|---:|---|---:|---:|---:|---|
| c01 | F3 | 1 | 605 / 594 | 1.00007 | 0.99949 | 0.001→0.001 | 1.648 | 1.205 | 1.197 | **no_gain** |
| c02 | F3 | 1 | 803 / 787 | 0.99953 | 0.99915 | 0.003→0.002 | 2.088 | 1.836 | 1.833 | **no_gain** |
| c01 | F4 | 1 | 605 / 594 | 0.99934（robust） | 0.99949 | 0.000→0.001 | 1.014 | 1.203 | 1.197 | no_gain |
| c02 | F4 | 1 | 803 / 787 | 0.99948（robust） | 0.99915 | 0.002→0.002 | 0.966 | 1.837 | 1.833 | no_gain |

### 4.3 未加护栏的对照（已归档 `*_noguard.tum`）

| 数据 | 臂 | scale2 | ATE | 结论 |
|---|---|---:|---:|---|
| c01 | F3 noguard | 0.99949 | 1.385 | scale −0.00058 被 2 km 轨迹放大，ATE 0.71→1.39 |
| c02 | F3 noguard | 0.99915 | 1.007 | 基本持平（RPE10 0.886→0.898） |

这一组对照说明：**二次拟合即使只改 0.06% 的 scale，也会在长轨迹上产生约 1 m
的几何变化**；因此护栏不是可选项。

### 4.4 结论

1. P0 依赖真实存在，但在本数据上被拒绝的 7/10 个粗差对初始拟合的污染很小：
   pass2 只把 accepted 样本的 RMS 降低约 0.7%，低于 1% 的 `fit_min_rms_gain`
   门槛，F3 正确回退到 pass1，与 F1 **逐字节相同**；
2. 没有护栏时，pass2 的 scale 变化（c01 −0.00058）会把 ATE 从 0.710 推到 1.385；
   这是“全局尺度杠杆”，不是局部粗差效应；
3. F4 的 robust pass1 本身就把 c01 scale 从 1.00007 改到 0.99934，即使 pass2 回退，
   ATE 仍退化到 1.398；c02 也略差（1.001→1.010）。因此 robust 初始拟合在
   本数据上不可用，需要 plain-vs-robust 的第二道护栏后才能考虑；
4. **默认保持两项都关闭**：`fit_robust_en=false`、`fit_two_pass_en=false`。
   A2.5 交付的是“可验证、可回退”的护栏与诊断，不是默认开启的算法改动；
5. 创新门控仍然把粗差排除在**因子**之外；初始拟合保持 pass1。A2.4 的统计
   独立性因此没有被“二次拟合”进一步削弱，但也没有被完全消除——若未来在
   污染更重的数据上启用 F3，必须先确认 accepted 样本的 RMS 有实质下降。

## 5. 明确未改

- RTK 因子 sigma、Cauchy、静态规则、A1 时间关联；
- 分类门控默认值（仍关闭）；
- 创新门控默认值（仍关闭）；
- `h_acc/v_acc` 仍未映射到 sigma。

## 6. 限制

- 同输入 harness 仍是后端重放，不含前端 LIVO；
- 两遍拟合的健康阈值是首轮工程值，尚未跨数据集标定；
- F4 的 Huber 拟合只在 pass 1 使用，pass 2 用加权最小二乘。
