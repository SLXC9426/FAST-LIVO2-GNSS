#ifndef GNSS_EPOCH_PAIRER_H_
#define GNSS_EPOCH_PAIRER_H_

#include "gnss_quality_cache.h"
#include <algorithm>
#include <cmath>
#include <map>
#include <limits>
#include <stdexcept>
#include <vector>

namespace fast_livo {

// Single-threaded exact-stamp join. `now` is monotonic receive time, independent
// of sensor time and /clock. No waiting or filter mutation occurs in this class.
template <typename Fix> class GnssEpochPairer {
 public:
  struct Ready {
    uint64_t stamp; Fix fix; GnssQualityRecord quality; bool matched;
    // Read-only timing support, all on the caller's monotonic receive clock.
    double fix_arrival, quality_arrival, drain_time;
    size_t pending_fixes, pending_quality;
  };
  struct Counters {
    uint64_t matched=0, timeout=0, late_quality=0, duplicate=0;
    uint64_t overflow=0, out_of_order=0, expired_quality=0, resets=0;
  };
  explicit GnssEpochPairer(double wait_sec=.2, size_t capacity=1000)
      : wait_(wait_sec), capacity_(capacity) {
    if (!std::isfinite(wait_) || wait_<=0 || capacity_==0)
      throw std::invalid_argument("invalid GNSS pairing wait/capacity");
  }
  void addFix(uint64_t stamp, const Fix &fix, double now) {
    if (released_ && stamp<=last_) { ++counts_.out_of_order; return; }
    if (fixes_.count(stamp)) { ++counts_.duplicate; return; }
    if (fixes_.size()>=capacity_) {
      // Admission is refused explicitly, never silently evict an older fix.
      ++counts_.overflow; return;
    }
    fixes_.emplace(stamp, Pending{fix,now});
  }
  void addQuality(uint64_t stamp, const GnssQualityRecord &quality, double now) {
    if (released_ && stamp<=last_) { ++counts_.late_quality; return; }
    if (quality_.count(stamp)) { ++counts_.duplicate; return; }
    if (quality_.size()>=capacity_) { ++counts_.overflow; return; }
    quality_.emplace(stamp, Quality{quality,now});
  }
  std::vector<Ready> drain(double now) {
    std::vector<Ready> ready;
    while (!fixes_.empty()) {
      const auto it=fixes_.begin();
      const auto q=quality_.find(it->first);
      const bool matched=q!=quality_.end();
      if (!matched && now-it->second.arrival<wait_) break;
      Ready r{it->first,it->second.fix,GnssQualityRecord{},matched,
          it->second.arrival, matched?q->second.arrival:std::numeric_limits<double>::quiet_NaN(),
          now,fixes_.size(),quality_.size()};
      if (matched) { r.quality=q->second.record; quality_.erase(q); ++counts_.matched; }
      else ++counts_.timeout;
      last_=it->first; released_=true;
      ready.push_back(r); fixes_.erase(it);
    }
    // Quality-first records get a longer retention interval than fix waits.
    for (auto it=quality_.begin(); it!=quality_.end();) {
      if ((released_ && it->first<=last_) || now-it->second.arrival>=5.) {
        ++counts_.expired_quality; it=quality_.erase(it);
      } else ++it;
    }
    return ready;
  }
  void reset() {
    fixes_.clear(); quality_.clear(); released_=false; last_=0;
    ++counts_.resets;
  }
  const Counters &counters() const { return counts_; }
  size_t pending() const { return fixes_.size(); }
  size_t pendingQuality() const { return quality_.size(); }
 private:
  struct Pending { Fix fix; double arrival; };
  struct Quality { GnssQualityRecord record; double arrival; };
  double wait_; size_t capacity_; bool released_=false; uint64_t last_=0;
  Counters counts_;
  std::map<uint64_t,Pending> fixes_;
  std::map<uint64_t,Quality> quality_;
};
}  // namespace fast_livo
#endif
