#!/usr/bin/env python3
"""Summarize the A2.1 quality columns of an association trace."""
import csv
import sys


def main() -> int:
    for path in sys.argv[1:]:
        with open(path, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        n = len(rows)
        if n == 0:
            print(f"{path}: empty")
            continue
        rtklib = sum(1 for r in rows if r["q_source"] == "rtklib")
        has_pdop = sum(1 for r in rows if r["has_p_dop"] == "1")
        has_h = sum(1 for r in rows if r["has_h_acc"] == "1")
        has_v = sum(1 for r in rows if r["has_v_acc"] == "1")
        q_valid = sum(1 for r in rows if r["q_valid"] == "1")
        nsat = sum(int(float(r["nsat"])) for r in rows) / n
        pdop = sum(float(r["pdop"]) for r in rows) / n
        print(f"{path}: rows={n} rtklib={rtklib} "
              f"coverage={100.0 * rtklib / n:.1f}% has_pdop={has_pdop} "
              f"q_valid={q_valid} mean_nsat={nsat:.1f} mean_pdop={pdop:.2f} "
              f"has_h_acc={has_h} has_v_acc={has_v}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
