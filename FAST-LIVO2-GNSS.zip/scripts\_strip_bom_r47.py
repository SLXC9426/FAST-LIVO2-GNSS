#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""R4-7 (P3-3): strip UTF-8 BOM from the three flagged files (byte-level, no
behaviour change). Run once."""
import io

FILES = ["CMakeLists.txt", "include/common_lib.h", "GNSS_INTEGRATION_GUIDE.md"]
for p in FILES:
    b = open(p, "rb").read()
    if b.startswith(b"\xef\xbb\xbf"):
        open(p, "wb").write(b[3:])
        print("stripped BOM: %s (%d bytes)" % (p, len(b) - 3))
    else:
        print("no BOM: %s" % p)
