#!/usr/bin/env python3
import numpy as np

for tag, p in [
    ("E/GREAT", "/mnt/e/GREAT数据集/campus-01/Lidar/data/1603764571917030144.bin"),
    ("old", "/home/slxc9426/datasets/GREAT/Lidar/data/1603764571917030144.bin"),
]:
    raw = np.fromfile(p, dtype=np.uint8)
    n = len(raw) // 22
    pts = raw[: n * 22].reshape(n, 22)
    t = pts[:, 18:22].copy().view(np.float32).ravel()
    ring = pts[:, 16].astype(np.uint32) | (pts[:, 17].astype(np.uint32) << 8)
    x = pts[:, 0:4].copy().view(np.float32).ravel()
    print(tag, "n=", n, "time min %.6f max %.6f" % (t.min(), t.max()),
          "rings:", len(np.unique(ring)), "x0:", x[0])
