"""Fast experiment: 15 s sequence (~150 keyframes), three bias strategies.
Each run takes ~10-30 s, so hypotheses can be tested quickly.

Strategy A: bias estimated from zero (current behaviour)
Strategy B: bias initialised at the ground-truth value (upper bound of the
            smoother if bias estimation were perfect)
Strategy C: bias frozen at zero (no bias estimation at all)
"""
import sys
sys.path.insert(0, r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\scripts\sim")
import numpy as np
from sim_filter_compare import make_sequence, run_factor_graph, align_traj, rpe_rmse

DUR = 15.0
WINDOW = 10

t_kf, t_imu, p_gt, R_gt, v_gt, meas_p, meas_R, meas_v, acc_m, gyr_m, bg_true, ba_true = make_sequence(seed=0, dur=DUR)
gt = np.column_stack([t_kf, p_gt])
true_bias = np.concatenate([bg_true, ba_true])


def eval_one(name, bias0, freeze_bias=False, use_preint=True):
    traj, bias_est = run_factor_graph(t_kf, t_imu, meas_p, meas_R, meas_v, acc_m, gyr_m, 0.005,
                                      window=WINDOW, bias0=bias0, freeze_bias=freeze_bias,
                                      use_preint=use_preint)
    R, s, me, mg = align_traj(traj, gt)
    pe = (traj[:, 1:4] - me) @ R.T
    pg = gt[:, 1:4] - mg
    e = np.linalg.norm(pe - pg, axis=1)
    bg_e = np.linalg.norm(bias_est[-1, 0:3] - bg_true)
    ba_e = np.linalg.norm(bias_est[-1, 3:6] - ba_true)
    print(f"  {name:34s}: ATE rmse {np.sqrt(np.mean(e**2))*100:7.2f} cm | max {np.max(e)*100:7.2f} cm | "
          f"RPE {rpe_rmse(traj, gt)*100:6.2f} cm | bg_err {bg_e*1000:6.1f} mrad | ba_err {ba_e*1000:7.0f} mm/s2")
    return traj, bias_est


print(f"fast bias experiment: dur={DUR}s window={WINDOW} (per-run ~10-30 s)")
eval_one("A: bias estimated from 0", None)
eval_one("D: bias init at truth, FROZEN", true_bias, freeze_bias=True)
eval_one("E: ODOM ONLY (no preint)", None, use_preint=False)
traj_e, _ = eval_one("F: odom only + weak v prior", None, use_preint=False)
# odom-only: is the output exactly the measurements?
print("  [E] out vs meas max diff:", np.abs(traj_e[:, 1:4] - meas_p).max())
