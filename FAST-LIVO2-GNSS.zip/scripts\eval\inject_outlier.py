#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inject a position outlier into one NavSatFix epoch of a rosbag.

Why this exists: "the chi-square gate rejects outliers" is a claim that cannot be
falsified without a deliberately corrupted fix. Before this tool there was no way
to produce one, which is why the question stayed open across two review rounds
(see RTK紧组合改动方案 WP7 verification (c) and 执行清单 1.5).

The injected epoch keeps its timestamp, its fix status and its reported
position_covariance: only the position moves. That is the point - the gate must
reject a bad position that still looks like a good fix, so changing the reported
quality would invalidate the test.

Usage:
  inject_outlier.py <bag> <topic> <idx|time> <delta_m> <out.bag>
                    [--axis enu|e|n|u] [--dry-run]

  <idx|time>  which epoch to corrupt. A value with a decimal point or an
              absolute value >= 100000 is read as an absolute timestamp in
              seconds (the bag's own clock); anything else is a 0-based index
              into the topic's message order. Use the explicit forms idx=N or
              t=N to remove all ambiguity.
  <delta_m>   displacement in metres, applied per selected axis. The default
              axis set is all three (enu), so the total 3-D displacement is
              delta_m * sqrt(3); pass --axis e (or n) for a horizontal-only test
              with a well-defined magnitude.
  --axis      enu (default) | e | n | u
  --dry-run   report the change without writing a bag

The output bag contains ONLY <topic>. That is deliberate: the evaluation
workflow plays the main recording and the GNSS bag together
(segment_run.sh <seq> gnss <start> <dur> <tag> <rtk_bag>), so the injected bag
only has to carry the fixes. Copying a 20 GB main bag to change one fix would be
pointless.

Latitude/longitude are converted with the local ellipsoidal radii of curvature
(meridional for latitude, prime-vertical for longitude times cos(lat)), so the
requested metres are the metres actually applied - longitude degrees per metre
vary with latitude.

Example - WP7's falsification test on campus-01, 0-200 s:
  python3 scripts/eval/inject_outlier.py campus01_rtk1hz.bag /gnss_rtk idx=100 30 \\
      /tmp/c01_fix_out30.bag
  python3 scripts/eval/inject_outlier.py campus01_rtk1hz.bag /gnss_rtk idx=100 0.5 \\
      /tmp/c01_fix_out05.bag
  # then, with the same segment and binary:
  segment_run.sh campus01 gnss 0 200 wp7_reject30 /tmp/c01_fix_out30.bag
  segment_run.sh campus01 gnss 0 200 wp7_accept05 /tmp/c01_fix_out05.bag
Expect: the 30 m epoch to be rejected by the gate (and counted in
`rejected=` of the [GNSS] health line), the 0.5 m epoch to be accepted.
"""
import sys
import math
import rosbag

A = 6378137.0
F = 1.0 / 298.257223563
E2 = F * (2.0 - F)
DEG = 180.0 / math.pi

AXES = {'enu': (1.0, 1.0, 1.0), 'e': (1.0, 0.0, 0.0),
        'n': (0.0, 1.0, 0.0), 'u': (0.0, 0.0, 1.0)}


def enu_offset_to_lla(lat, lon, d_east, d_north, d_up):
    """Local ENU offset (metres) -> (dlat_deg, dlon_deg, dalt_m).

    Uses the radii of curvature at the given latitude, which is what makes the
    longitude conversion latitude-dependent.
    """
    m_rad, n_rad = _radii(lat)
    if abs(n_rad) < 1.0:
        raise ValueError("latitude %.4f deg is too close to the pole for a "
                         "longitude offset (%d m)" % (lat, d_east))
    return d_north / m_rad * DEG, d_east / n_rad * DEG, d_up


def _radii(lat):
    """(meridional, prime-vertical) radii of curvature in metres per radian."""
    phi = math.radians(lat)
    s = math.sin(phi)
    denom = 1.0 - E2 * s * s
    return (A * (1.0 - E2) / (denom ** 1.5),      # metres per radian latitude
            A / math.sqrt(denom) * math.cos(phi))  # metres per radian longitude


def lla_offset_to_enu(lat, dlat_deg, dlon_deg, dalt_m):
    """Inverse of enu_offset_to_lla, so the printout is a real round trip."""
    m_rad, n_rad = _radii(lat)
    return math.radians(dlon_deg) * n_rad, math.radians(dlat_deg) * m_rad, dalt_m


def parse_selector(s):
    """Return ('idx', int) or ('time', float) from the <idx|time> argument."""
    if s.startswith('idx='):
        return 'idx', int(s[4:])
    if s.startswith('t='):
        return 'time', float(s[2:])
    v = float(s)
    # Timestamps in these bags are ~1.6e9 s; sample indices are small integers.
    if '.' in s or 'e' in s.lower() or abs(v) >= 100000.0:
        return 'time', v
    return 'idx', int(v)


def main():
    a = sys.argv[1:]
    if len(a) < 5:
        print(__doc__)
        return 1
    bag_path, topic, sel, delta_m, out_path = a[0], a[1], a[2], float(a[3]), a[4]
    axis, dry_run = 'enu', False
    i = 5
    while i < len(a):
        if a[i] == '--axis':
            axis = a[i + 1]; i += 2
        elif a[i] == '--dry-run':
            dry_run = True; i += 1
        else:
            i += 1
    if axis not in AXES:
        sys.stderr.write("unknown --axis %r (expected one of %s)\n"
                         % (axis, ', '.join(sorted(AXES))))
        return 1
    k_e, k_n, k_u = AXES[axis]
    mode, target = parse_selector(sel)

    # Pass 1: read the topic, locate the target epoch.
    tgt_i, tgt_t, tgt_stamp = None, None, None
    with rosbag.Bag(bag_path) as b:
        topics = b.get_type_and_topic_info().topics
        info = topics.get(topic)
        if info is None:
            sys.stderr.write("topic %r not in %s\navailable: %s\n"
                             % (topic, bag_path, ', '.join(sorted(topics))))
            return 1
        n = 0
        for _, msg, t in b.read_messages(topics=[topic]):
            hit = (n == target) if mode == 'idx' else abs(t.to_sec() - target) < 1e-6
            if hit:
                tgt_i, tgt_t, tgt_stamp = n, t.to_sec(), msg.header.stamp.to_sec()
                lat0, lon0, alt0 = msg.latitude, msg.longitude, msg.altitude
                break
            n += 1
        total = info.message_count
    if tgt_i is None:
        sys.stderr.write("no epoch matched %r (mode=%s); topic has %d messages\n"
                         % (sel, mode, total))
        return 1

    dlat, dlon, dalt = enu_offset_to_lla(lat0, lon0,
                                        delta_m * k_e, delta_m * k_n, delta_m * k_u)
    lat1, lon1, alt1 = lat0 + dlat, lon0 + dlon, alt0 + dalt

    print("bag        : %s" % bag_path)
    print("topic      : %s  (%d epochs)" % (topic, total))
    print("selected   : idx=%d  bag_time=%.6f  header_stamp=%.6f"
          % (tgt_i, tgt_t, tgt_stamp))
    print("delta_m    : %+.4f m   axis=%s" % (delta_m, axis))
    print("before     : lat=%.10f lon=%.10f alt=%.4f" % (lat0, lon0, alt0))
    print("after      : lat=%.10f lon=%.10f alt=%.4f" % (lat1, lon1, alt1))
    print("applied    : dlat=%+.9f deg  dlon=%+.9f deg  dalt=%+.6f m" % (dlat, dlon, dalt))
    # Round-trip the applied offset back to metres so the printout is evidence,
    # not a restatement of the input.
    print("-> applied ENU offset (round-tripped): dE=%+.4f dN=%+.4f dU=%+.4f m"
          % lla_offset_to_enu(lat0, dlat, dlon, dalt))

    if dry_run:
        print("--dry-run: no bag written")
        return 0

    # Pass 2: copy the topic, perturbing only the target epoch.
    written = 0
    with rosbag.Bag(bag_path) as src, rosbag.Bag(out_path, 'w') as dst:
        for _, msg, t in src.read_messages(topics=[topic]):
            if written == tgt_i:
                msg.latitude = lat1
                msg.longitude = lon1
                msg.altitude = alt1
            dst.write(topic, msg, t)
            written += 1
    print("wrote      : %s  (%d epochs, 1 injected)" % (out_path, written))
    return 0


if __name__ == '__main__':
    sys.exit(main())
