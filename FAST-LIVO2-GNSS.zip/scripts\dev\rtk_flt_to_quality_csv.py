#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GREAT-PVT .flt -> per-epoch quality CSV (no ROS required).

The .flt columns are:
  0 TOW | 1-3 XYZ (ECEF m) | 4-6 Vxyz (ECEF m/s) | 7-9 XYZ-RMS |
  10-12 V-RMS | 13 NSat | 14 PDOP | 15 sigma0 | 16 AmbStatus |
  17 Ratio | 18 BL | 19 Quality (optional trailing fields)

The existing rtk_flt_to_bag.py only keeps TOW/XYZ/velocity/status and writes a
constant cm-level covariance, so NSat, PDOP, sigma0 and the per-epoch XYZ-RMS
never reach the estimator. This tool keeps them for offline quality-aware
experiments and for building a sidecar CSV next to a new bag.

Usage:
  python3 rtk_flt_to_quality_csv.py <in.flt> <out.csv>
"""
import csv
import sys

OFFSET = 604800 * 2129 + 315964800 - 18


def parse_flt(path):
    rows = []
    with open(path, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            v = line.split()
            if len(v) < 17:
                continue
            def fnum(i, default="0"):
                return float(v[i]) if i < len(v) else float(default)
            rows.append({
                "tow": fnum(0),
                "x": fnum(1), "y": fnum(2), "z": fnum(3),
                "vx": fnum(4), "vy": fnum(5), "vz": fnum(6),
                "x_rms": fnum(7), "y_rms": fnum(8), "z_rms": fnum(9),
                "vx_rms": fnum(10), "vy_rms": fnum(11), "vz_rms": fnum(12),
                "nsat": int(fnum(13)), "pdop": fnum(14), "sigma0": fnum(15),
                "status": v[16],
                "ratio": fnum(17) if len(v) > 17 else "",
                "bl": fnum(18) if len(v) > 18 else "",
                "quality": int(fnum(19)) if len(v) > 19 else "",
            })
    return rows


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    src, out = sys.argv[1], sys.argv[2]
    rows = parse_flt(src)
    if not rows:
        print("!! no epochs parsed from", src)
        return 1
    fields = ["tow", "t_unix", "x", "y", "z", "vx", "vy", "vz",
              "x_rms", "y_rms", "z_rms", "vx_rms", "vy_rms", "vz_rms",
              "nsat", "pdop", "sigma0", "status", "ratio", "bl", "quality"]
    with open(out, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            r["t_unix"] = r["tow"] + OFFSET
            w.writerow(r)

    tow = [r["tow"] for r in rows]
    dt = (tow[-1] - tow[0]) / max(len(tow) - 1, 1)
    status = {}
    for r in rows:
        status[r["status"]] = status.get(r["status"], 0) + 1
    print(f"epochs={len(rows)} TOW {tow[0]:.1f}..{tow[-1]:.1f} "
          f"({dt:.3f}s, {1.0 / max(dt, 1e-9):.2f} Hz)")
    print(f"status={status}")
    for key in ("nsat", "pdop", "sigma0", "x_rms", "y_rms", "z_rms"):
        vals = [r[key] for r in rows if r[key] != ""]
        if vals:
            print(f"{key}: min={min(vals):.4g} median={sorted(vals)[len(vals) // 2]:.4g} "
                  f"max={max(vals):.4g}")
    print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
