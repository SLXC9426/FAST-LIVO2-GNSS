import sys
sys.path.insert(0, r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\scripts")
from _eval_campus import load_tum, interp, umeyama
import numpy as np

REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\campus01_reference.tum"
RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"
rt, rp = load_tum(REF)
for name in ("great_campus01_baseline", "great_campus01_occ_only", "great_campus01_robust_only"):
    try:
        ft, fp = load_tum(f"{RES}\\{name}.txt")
    except Exception:
        print(name, "MISSING")
        continue
    t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
    m = (rt >= t0) & (rt <= t1)
    p_f = interp(ft, fp, rt[m])
    p_g = rp[m]
    e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
    print(f"{name:32s}: n={m.sum():4d} span={t1-t0:5.0f}s APE_rmse={np.sqrt(np.mean(e**2)):7.2f}m APE_max={np.max(e):7.2f}m")
