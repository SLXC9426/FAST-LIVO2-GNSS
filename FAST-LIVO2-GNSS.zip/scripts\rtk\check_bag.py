import rosbag

BAG = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.bag"
b = rosbag.Bag(BAG)
topic, m, t = next(b.read_messages(topics=["/rtk/dd"]))
print("topic", topic, "bag_t", t.to_sec(), "stamp", m.header.stamp.to_sec())
print("t_gps", m.t_gps, "n", m.n)
print("sys", list(m.sys[:5]))
print("freq", list(m.freq[:5]))
print("ref_sat", list(m.ref_sat[:5]))
print("sat", list(m.sat[:5]))
print("dd_code", [round(x, 3) for x in m.dd_code[:5]])
print("dd_phase", [round(x, 3) for x in m.dd_phase[:5]])
print("sigma_code", [round(x, 3) for x in m.sigma_code[:5]])
print("slip bytes", list(m.slip[:5]), "ref_change", list(m.ref_change[:5]))
b.close()
