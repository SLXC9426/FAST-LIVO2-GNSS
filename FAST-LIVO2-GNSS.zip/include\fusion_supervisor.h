#ifndef FUSION_SUPERVISOR_H
#define FUSION_SUPERVISOR_H
/**
 * P2 fusion supervisor: dataset-agnostic soft weights + time-based hysteresis.
 *
 * Design rules:
 *  - GNSS fixed quality uses DIMENSIONLESS ratios (n_fixed/n_pairs, ratio,
 *    normalized chi-square) plus a physical minimum pair count; it does not
 *    depend on the satellite count of a particular dataset.
 *  - LIVO health is normalised against its OWN running mean (EMA), so LiDAR
 *    type, camera resolution and scene texture do not need per-dataset
 *    thresholds. Only physical minima remain.
 *  - All mode hysteresis and logging use SECONDS, not epoch counts, so 1 Hz
 *    and 10 Hz GNSS streams behave the same.
 */
#include <algorithm>
#include <cmath>
#include <cstdio>

enum class FusionMode
{
  FIXED = 0,
  FLOAT = 1,
  REJECT = 2
};

inline const char *fusionModeName(FusionMode m)
{
  switch (m)
  {
    case FusionMode::FIXED: return "FIXED";
    case FusionMode::FLOAT: return "FLOAT";
    default: return "REJECT";
  }
}

struct FusionLivoHealth
{
  int eff_features = 0;
  int matched_points = 0;
  int vio_points = 0;
  bool vio_enabled = true;
  bool zupt_static = false;
  bool report_hold = false;
  bool align_locked = false;
};

struct FusionSupervisorInput
{
  bool rtk_available = false;
  bool gnss_valid = false;
  int fix_status = -1;
  int n_pairs = 0;
  int n_fixed = 0;
  double fixed_streak_s = 0.0;
  double ratio = 0.0;
  double gamma = 0.0;
  double gate = 0.0;
  bool rtk_accepted = false;
  double t = -1.0; ///< epoch time (s); drives seconds-based hysteresis
  FusionLivoHealth livo;
};

struct FusionSupervisorConfig
{
  bool en = false;

  // Fixed-DD quality: dimensionlessness + physical minima.
  double fixed_ratio_min = 0.20;  // n_fixed / n_pairs
  // The absolute count is the physical requirement (n_fixed_abs_good=8); the
  // fraction is a secondary guard. c01's DD stream is ~42% fixed and c02's is
  // ~66%; requiring 60% kept c01 in FLOAT almost permanently. 40% still means
  // roughly 8 fixed pairs in a 20-pair epoch.
  double fixed_ratio_good = 0.60;
  int n_fixed_abs_min = 4;        // physical minimum usable pairs
  int n_fixed_abs_good = 8;
  double ratio_min = 1.5;         // standard LAMBDA ratio
  double ratio_good = 3.0;
  double streak_min_s = 1.0;
  double streak_good_s = 5.0;
  double gamma_margin_good = 0.5; // (gate-gamma)/gate for q_gamma=1

  // LIVO quality: current / running mean, plus physical minima.
  double livo_ratio_min = 0.20;
  double livo_ratio_good = 0.70;
  int livo_feat_abs_min = 10;
  int livo_match_abs_min = 5;
  int livo_vio_abs_min = 3;
  double livo_warmup_s = 5.0;
  double livo_q_min = 0.15;
  double livo_ema_tau_s = 20.0;

  // Mode thresholds / time hysteresis (seconds).
  double fixed_q_min = 0.55;
  double fixed_q_exit = 0.35;
  // A fixed epoch that failed the RTK residual/consensus gate must not keep
  // the supervisor in FIXED mode (otherwise a persistent wrong fix re-enters
  // FIXED every few seconds and retries the bad integer).
  double fixed_q_reject_cap = 0.30;
  double reject_q_max = 0.10;
  double fixed_enter_s = 2.0;
  double fixed_exit_s = 3.0;
  double reject_enter_s = 3.0;
  // After a DD outage the stream is re-entered in REJECT (soft weight). Resume
  // FLOAT only after this many seconds of accepted epochs, so one lucky epoch
  // cannot immediately re-enable full RTK weight.
  double reject_recover_s = 1.0;

  // Weights: dimensionless.
  double w_rtk_max = 1.0;
  double w_rtk_floor = 0.25;
  double w_gnss_max = 1.0;
  double log_every_s = 10.0;
  // If no /rtk/dd message arrives for this long, the supervisor switches to
  // REJECT (LIVO-only) until the stream returns.
  double rtk_timeout_s = 1.5;
};

struct FusionSupervisorOutput
{
  FusionMode mode = FusionMode::FLOAT;
  double w_rtk = 0.0;
  double w_gnss = 0.0;
  bool use_fixed_phase = false;
  double q_fix = 0.0;
  double q_dd = 0.0;
  double q_livo = 1.0;
};

class FusionSupervisor
{
public:
  FusionSupervisor() = default;

  void setConfig(const FusionSupervisorConfig &cfg)
  {
    cfg_ = cfg;
    reset();
  }
  const FusionSupervisorConfig &config() const { return cfg_; }

  void reset()
  {
    mode_ = FusionMode::FLOAT;
    fixed_good_s_ = fixed_bad_s_ = reject_s_ = recover_s_ = 0.0;
    last_t_ = -1.0;
    log_s_ = 0.0;
    updates_ = 0;
    ema_feat_ = ema_match_ = ema_vio_ = 0.0;
    ema_count_ = 0;
    livo_time_s_ = 0.0;
    out_ = FusionSupervisorOutput();
  }

  const FusionSupervisorOutput &output() const { return out_; }
  int updates() const { return updates_; }

  void update(const FusionSupervisorInput &in)
  {
    ++updates_;
    last_ratio_ = in.ratio;
    last_n_fixed_ = in.n_fixed;
    last_streak_s_ = in.fixed_streak_s;
    last_gamma_ = in.gamma;
    double dt = 1.0;
    if (last_t_ > 0.0 && in.t > last_t_)
      dt = std::max(0.01, std::min(2.0, in.t - last_t_));
    last_t_ = in.t;

    updateLivoEma(in.livo, dt);

    double q_fix = fixedQuality(in);
    if (in.rtk_available && !in.rtk_accepted)
      q_fix = std::min(q_fix, cfg_.fixed_q_reject_cap);
    const double q_dd = ddQuality(in);
    const double q_livo = livoQuality(in.livo);
    out_.q_fix = q_fix;
    out_.q_dd = q_dd;
    out_.q_livo = q_livo;

    // Position-domain fallback (no DD stream): alignment + fix validity only.
    if (!in.rtk_available)
    {
      const bool ok = in.gnss_valid && in.livo.align_locked;
      mode_ = ok ? FusionMode::FLOAT : FusionMode::REJECT;
      out_.mode = mode_;
      out_.w_rtk = 0.0;
      out_.w_gnss = ok ? std::min(cfg_.w_gnss_max, 0.4 + 0.6 * q_livo) : 0.0;
      out_.use_fixed_phase = false;
      log(dt);
      return;
    }

    if (!in.livo.align_locked)
    {
      mode_ = FusionMode::REJECT;
      fixed_good_s_ = fixed_bad_s_ = reject_s_ = recover_s_ = 0.0;
      setWeights(in, q_fix, q_dd, q_livo);
      log(dt);
      return;
    }

    // DD availability is a hard gate. A single bad epoch does not switch the
    // whole system to LIVO-only: RtkTight already has its own robust/chi-square
    // gate, and the FLOAT weight can be lowered continuously.
    if (in.n_pairs < cfg_.n_fixed_abs_min)
    {
      mode_ = FusionMode::REJECT;
      fixed_good_s_ = fixed_bad_s_ = 0.0;
      setWeights(in, q_fix, q_dd, q_livo);
      log(dt);
      return;
    }

    // Leave REJECT only after the DD stream has produced accepted epochs for
    // reject_recover_s seconds. Before that the soft weight stays at the floor,
    // so a single first epoch after an outage cannot yank the state.
    if (mode_ == FusionMode::REJECT)
    {
      recover_s_ = in.rtk_accepted ? recover_s_ + dt : 0.0;
      if (recover_s_ >= cfg_.reject_recover_s)
      {
        mode_ = FusionMode::FLOAT;
        fixed_good_s_ = 0.0; // require a fresh FIXED dwell after recovery
      }
    }
    else
    {
      recover_s_ = 0.0;
    }

    // Time-based Fixed <-> Float hysteresis (no dataset/rate dependence).
    fixed_good_s_ = (q_fix >= cfg_.fixed_q_min && q_livo >= cfg_.livo_q_min)
                        ? fixed_good_s_ + dt : 0.0;
    fixed_bad_s_ = (q_fix < cfg_.fixed_q_exit || q_livo < cfg_.livo_q_min)
                       ? fixed_bad_s_ + dt : 0.0;

    if (mode_ != FusionMode::FIXED && fixed_good_s_ >= cfg_.fixed_enter_s)
      mode_ = FusionMode::FIXED;

    if (mode_ == FusionMode::FIXED && fixed_bad_s_ >= cfg_.fixed_exit_s)
      mode_ = FusionMode::FLOAT;

    setWeights(in, q_fix, q_dd, q_livo);
    log(dt);
  }

private:
  static double clamp01(double v) { return std::max(0.0, std::min(1.0, v)); }

  static double ramp(double v, double lo, double hi)
  {
    if (hi <= lo) return v >= hi ? 1.0 : 0.0;
    return clamp01((v - lo) / (hi - lo));
  }

  void updateLivoEma(const FusionLivoHealth &h, double dt)
  {
    const double alpha = std::max(0.01, std::min(1.0, dt / std::max(1.0, cfg_.livo_ema_tau_s)));
    if (ema_count_ == 0)
    {
      ema_feat_ = h.eff_features;
      ema_match_ = h.matched_points;
      ema_vio_ = h.vio_points;
    }
    else
    {
      ema_feat_ = (1.0 - alpha) * ema_feat_ + alpha * h.eff_features;
      ema_match_ = (1.0 - alpha) * ema_match_ + alpha * h.matched_points;
      ema_vio_ = (1.0 - alpha) * ema_vio_ + alpha * h.vio_points;
    }
    ++ema_count_;
    livo_time_s_ += dt;
  }

  double fixedQuality(const FusionSupervisorInput &in) const
  {
    const double fixed_ratio = (double)in.n_fixed / std::max(1, in.n_pairs);
    const double q_ratio_pairs = std::min(
        ramp(fixed_ratio, cfg_.fixed_ratio_min, cfg_.fixed_ratio_good),
        ramp((double)in.n_fixed, cfg_.n_fixed_abs_min, cfg_.n_fixed_abs_good));
    const double q_ratio = in.ratio > 0.0
                               ? ramp(in.ratio, cfg_.ratio_min, cfg_.ratio_good)
                               : 0.5;
    const double q_gamma = in.gate > 1e-9
                               ? clamp01(((in.gate - in.gamma) / in.gate) /
                                         std::max(cfg_.gamma_margin_good, 1e-6))
                               : 0.5;
    const double q_streak = ramp(in.fixed_streak_s, cfg_.streak_min_s,
                                 cfg_.streak_good_s);
    return std::min(std::min(q_ratio_pairs, q_ratio),
                    std::min(q_gamma, q_streak));
  }

  double ddQuality(const FusionSupervisorInput &in) const
  {
    const double q_pairs = ramp((double)in.n_pairs, cfg_.n_fixed_abs_min,
                                cfg_.n_fixed_abs_good);
    const double q_gate = in.gate > 1e-9
                              ? clamp01(((in.gate - in.gamma) / in.gate) / 0.2)
                              : 0.5;
    double q = std::min(q_pairs, q_gate);
    if (!in.rtk_accepted && in.n_pairs >= cfg_.n_fixed_abs_min)
      q = std::min(q, 0.5);
    return q;
  }

  double livoQuality(const FusionLivoHealth &h) const
  {
    if (ema_count_ < 5 || livo_time_s_ < cfg_.livo_warmup_s)
      return 0.6; // neutral-positive until the running mean is meaningful

    auto relative = [&](int cur, double ema, int abs_min) {
      if (cur < abs_min) return 0.0;
      if (ema <= 0.5) return 0.5;
      return ramp((double)cur / ema, cfg_.livo_ratio_min, cfg_.livo_ratio_good);
    };
    const double q_feat = relative(h.eff_features, ema_feat_, cfg_.livo_feat_abs_min);
    const double q_match = relative(h.matched_points, ema_match_, cfg_.livo_match_abs_min);
    const double q_vio = relative(h.vio_points, ema_vio_, cfg_.livo_vio_abs_min);

    double q = std::min(q_feat, q_match); // LIO is the core health source
    if (h.vio_enabled && q_vio > 0.2)
      q = 0.7 * q + 0.3 * q_vio;           // VIO is optional corroboration

    if (h.zupt_static || h.report_hold) q = std::max(q, 0.8);
    return clamp01(q);
  }

  void setWeights(const FusionSupervisorInput &in, double q_fix, double q_dd,
                  double q_livo)
  {
    out_.mode = mode_;
    if (!in.gnss_valid)
    {
      out_.w_rtk = 0.0;
      out_.w_gnss = 0.0;
      out_.use_fixed_phase = false;
      return;
    }

    if (mode_ == FusionMode::REJECT)
    {
      out_.w_rtk = 0.0;
      out_.w_gnss = 0.0;
      out_.use_fixed_phase = false;
      return;
    }

    if (!in.rtk_available)
    {
      out_.w_rtk = 0.0;
      out_.use_fixed_phase = false;
      out_.w_gnss = clamp01(0.4 + 0.6 * q_livo);
      out_.w_gnss = std::min(out_.w_gnss, cfg_.w_gnss_max);
      return;
    }

    if (mode_ == FusionMode::FIXED)
    {
      out_.w_rtk = std::min(cfg_.w_rtk_max,
                            std::max(cfg_.w_rtk_floor,
                                     clamp01(q_fix * (0.3 + 0.7 * q_livo))));
      out_.w_gnss = 0.0;
      out_.use_fixed_phase = true;
    }
    else
    {
      out_.w_rtk = std::min(cfg_.w_rtk_max,
                            std::max(cfg_.w_rtk_floor,
                                     clamp01(0.5 * q_dd * (0.3 + 0.7 * q_livo))));
      out_.use_fixed_phase = false;
      out_.w_gnss = (out_.w_rtk > 0.05)
                        ? 0.0
                        : std::min(cfg_.w_gnss_max, clamp01((1.0 - q_dd) * q_livo));
    }
  }

  void log(double dt)
  {
    if (cfg_.log_every_s <= 0.0) return;
    log_s_ += dt;
    if (log_s_ < cfg_.log_every_s) return;
    log_s_ = 0.0;
    std::printf("[SUP] mode=%s w_rtk=%.2f w_gnss=%.2f ratio=%.2f n_fixed=%d "
                "streak=%.1f gamma=%.1f livo=%.2f\n",
                fusionModeName(out_.mode), out_.w_rtk, out_.w_gnss,
                last_ratio_, last_n_fixed_, last_streak_s_, last_gamma_,
                out_.q_livo);
    std::fflush(stdout);
  }

  FusionSupervisorConfig cfg_;
  FusionMode mode_ = FusionMode::FLOAT;
  FusionSupervisorOutput out_;
  double fixed_good_s_ = 0.0;
  double fixed_bad_s_ = 0.0;
  double reject_s_ = 0.0;
  double recover_s_ = 0.0;
  double last_t_ = -1.0;
  double log_s_ = 0.0;
  int updates_ = 0;

  double ema_feat_ = 0.0, ema_match_ = 0.0, ema_vio_ = 0.0;
  int ema_count_ = 0;
  double livo_time_s_ = 0.0;

  // Snapshot for the log (set at the start of update()).
  double last_ratio_ = 0.0, last_streak_s_ = 0.0, last_gamma_ = 0.0;
  int last_n_fixed_ = 0;
};

#endif // FUSION_SUPERVISOR_H
