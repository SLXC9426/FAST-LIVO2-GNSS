#!/usr/bin/env python3
"""Check VLP-16 time field vs azimuth ordering in official urban bag.
Q1: does time increase monotonically with azimuth (full 360 deg)?
Q2: where is the azimuth discontinuity relative to time=0?
Q3: ring 0 points: time range per ring?
"""
import rosbag, genpy, numpy as np
import sensor_msgs.point_cloud2 as pc2

BAG = "/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag"
b = rosbag.Bag(BAG)
n = 0
for topic, msg, t in b.read_messages(topics=["/points_raw"], start_time=genpy.Time(1603774014.0), end_time=genpy.Time(1603774016.0)):
    n += 1
    if n > 1:
        break
    pts = list(pc2.read_points(msg, field_names=("x", "y", "z", "ring", "time"), skip_nans=True))
    a = np.array(pts, dtype=float)
    az = np.degrees(np.arctan2(a[:, 1], a[:, 0])) % 360.0
    tm = a[:, 4]
    ring = a[:, 3].astype(int)
    print("frame stamp:", msg.header.stamp.to_sec(), "npts:", len(a))
    # sort by time, check azimuth monotonicity
    order = np.argsort(tm)
    az_sorted = az[order]
    diffs = np.diff(az_sorted)
    wraps = np.sum(diffs < -180)
    print("azimuth sorted-by-time: starts %.1f ends %.1f, wrap count %d" % (az_sorted[0], az_sorted[-1], wraps))
    # time range of first/last azimuth
    t_first = tm[order][0]
    print("time min %.1f max %.1f (us)" % (tm.min(), tm.max()))
    # discontinuity point: largest negative jump
    j = np.argmin(diffs)
    print("azimuth wrap at time %.1f us (az %.1f -> %.1f)" % (tm[order[j]], az_sorted[j], az_sorted[j + 1]))
    # ring 0 time range
    for r in [0, 5, 10, 15]:
        m = ring == r
        if m.sum():
            print("ring %d: n=%d time %.1f ~ %.1f" % (r, m.sum(), tm[m].min(), tm[m].max()))
    # azimuth at time=0 and time=50ms
    i0 = np.argmin(np.abs(tm - 0))
    i50 = np.argmin(np.abs(tm - 50000))
    print("az at t=0: %.1f deg, az at t=50ms: %.1f deg" % (az[i0], az[i50]))
b.close()
