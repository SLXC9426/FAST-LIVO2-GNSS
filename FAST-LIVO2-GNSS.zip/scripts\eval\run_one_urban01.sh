#!/usr/bin/env bash
# run one mode on urban-01, then report trajectory lines
# usage: bash run_one.sh <mode> <start> <dur>
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
MODE=$1
START=${2:--s 60}
DUR=${3:--u 400}
BAG=/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag

roslaunch fast_livo mapping_great_urban01.launch mode:=$MODE rviz:=false > /tmp/ur_$MODE.log 2>&1 &
LPID=$!
sleep 20
/opt/ros/noetic/bin/rosbag play $START $DUR $BAG --clock > /tmp/ur_play_$MODE.log 2>&1
sleep 8
kill $LPID 2>/dev/null
sleep 4
N=$(wc -l < Log/result/great_urban01_$MODE.txt 2>/dev/null || echo 0)
echo "$MODE: trajectory lines = $N"
