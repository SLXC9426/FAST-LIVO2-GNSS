import numpy as np
import pandas as pd
from rtk_preprocess import (_dd_geom, _dd_jac, load_flt_pos, gps_sow,
                            ecef_to_geodetic, ecef_to_enu, WAVELEN)

CSV = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
FLT = "/home/slxc9426/great_pvt/result/FIXBASE-RTK.flt"
BASE = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
T0 = 1603764590.0
T1 = 1603764616.0


def solve(rows, use_code=True, use_phase=True, systems=("G", "C"), x0=None):
    sel = [r for r in rows if T0 <= r["t_gps"] <= T1 and r["sys"] in systems]
    if len(sel) < 10:
        return None
    clean = [r for r in sel if r["slip"] == 0]
    if len(clean) >= 10:
        sel = clean
    # fixed reference per (sys, freq)
    refs = {}
    for key in sorted(set((r["sys"], r["freq"]) for r in sel)):
        counts = {}
        for r in sel:
            if (r["sys"], r["freq"]) == key:
                counts[r["ref_sat"]] = counts.get(r["ref_sat"], 0) + 1
        refs[key] = max(counts, key=counts.get)
    sel = [r for r in sel if r["ref_sat"] == refs[(r["sys"], r["freq"])]]
    pairs = sorted(set((r["sys"], r["freq"], r["sat"]) for r in sel))
    ai = {p: i for i, p in enumerate(pairs)}
    n_amb = len(pairs)
    x = np.array(x0, dtype=float)
    amb = np.zeros(n_amb)
    for p, i in ai.items():
        amb[i] = np.median([r["dd_phase"] - _dd_geom(r, x, BASE)
                            for r in sel if (r["sys"], r["freq"], r["sat"]) == p])
    for it in range(15):
        n = 3 + n_amb
        A = np.zeros((n, n)); b = np.zeros(n)
        for r in sel:
            g = _dd_geom(r, x, BASE)
            j = _dd_jac(r, x)
            idx = ai[(r["sys"], r["freq"], r["sat"])]
            if use_code:
                res = r["dd_code"] - g
                w = 1.0 / max(r["sigma_code"], 0.2) ** 2
                h = np.zeros(n); h[:3] = j
                A += w * np.outer(h, h); b += w * h * res
            if use_phase:
                res = r["dd_phase"] - g - amb[idx]
                w = 1.0 / 0.015 ** 2
                h = np.zeros(n); h[:3] = j; h[3 + idx] = 1.0
                A += w * np.outer(h, h); b += w * h * res
        dx = np.linalg.solve(A + np.eye(n) * 1e-8, b)
        x += dx[:3]; amb += dx[3:]
        if np.linalg.norm(dx[:3]) < 1e-5:
            break
    rc, rp = [], []
    per_band = {}
    for r in sel:
        g = _dd_geom(r, x, BASE)
        idx = ai[(r["sys"], r["freq"], r["sat"])]
        rc.append(r["dd_code"] - g)
        rp.append(r["dd_phase"] - g - amb[idx])
        per_band.setdefault((r["sys"], r["freq"]), []).append(r["dd_phase"] - g - amb[idx])
    rc = np.array(rc); rp = np.array(rp)
    return {
        "n": len(sel), "n_amb": n_amb, "x": x,
        "code_rms": float(np.sqrt(np.mean(rc ** 2))),
        "phase_rms": float(np.sqrt(np.mean(rp ** 2))),
        "per_band": {k: float(np.sqrt(np.mean(np.square(v)))) for k, v in per_band.items()},
        "sel": sel, "ai": ai, "amb": amb,
    }


def main():
    d = pd.read_csv(CSV)
    rows = d.to_dict("records")
    sow = gps_sow(T0 + 13.0)
    ts, flt = load_flt_pos(FLT, sow)
    lat, lon, alt = ecef_to_geodetic(BASE)
    flt_enu = ecef_to_enu(flt, BASE, lat, lon)
    print(f"reference FIXBASE-RTK sow={ts:.1f} ECEF={flt}")
    variants = [
        ("all", True, True, ("G", "C")),
        ("gps", True, True, ("G",)),
        ("bds", True, True, ("C",)),
        ("phase_all", False, True, ("G", "C")),
        ("phase_gps", False, True, ("G",)),
        ("phase_bds", False, True, ("C",)),
        ("code_all", True, False, ("G", "C")),
    ]
    allres = None
    for name, uc, up, sy in variants:
        r = solve(rows, uc, up, sy, x0=flt)
        if r is None:
            print(f"{name}: too few rows")
            continue
        if name == "all":
            allres = r
        enu = ecef_to_enu(r["x"], BASE, lat, lon)
        de = enu - flt_enu
        print(f"{name:10s} n={r['n']:4d} amb={r['n_amb']:2d} "
              f"code={r['code_rms']:.3f} phase={r['phase_rms']:.3f} "
              f"dE={de[0]:+.3f} dN={de[1]:+.3f} dU={de[2]:+.3f} "
              f"hor={np.linalg.norm(de[:2]):.3f} 3d={np.linalg.norm(de):.3f}")
        print("           per-band phase:", {f"{k[0]}-{k[1]}": round(v, 3) for k, v in r["per_band"].items()})

    if allres is not None:
        for pair in [("G", "L1", "G02"), ("G", "L1", "G15"),
                     ("C", "B2I", "C06"), ("C", "B3I", "C06")]:
            idx = allres["ai"].get(pair)
            if idx is None:
                continue
            vals = []
            for r in allres["sel"]:
                if (r["sys"], r["freq"], r["sat"]) == pair:
                    res = r["dd_phase"] - _dd_geom(r, allres["x"], BASE) - allres["amb"][idx]
                    vals.append((r["t_gps"], res))
            vals.sort()
            if len(vals) > 8:
                arr = np.array([v for _, v in vals])
                d = np.diff(arr)
                print(f"\nphase residual {pair}: n={len(vals)} "
                      f"mean={arr.mean():+.3f} std={arr.std():.3f} "
                      f"diff_std={d.std():.3f} first={vals[0][1]:+.3f} last={vals[-1][1]:+.3f}")
                print("  " + " ".join(f"{t-T0:.0f}:{v:+.3f}" for t, v in vals[:15]))
                print("  ... " + " ".join(f"{t-T0:.0f}:{v:+.3f}" for t, v in vals[-8:]))

        print("\nfloat DD ambiguity fractional parts (static, nearest-integer residual):")
        for pair, idx in sorted(allres["ai"].items(), key=lambda kv: kv[1]):
            a = allres["amb"][idx]
            wl = WAVELEN[(pair[0], pair[1])]
            cyc = a / wl
            frac = cyc - round(cyc)
            print(f"  {pair[0]}-{pair[1]} {pair[2]}: {a:+.4f} m = {cyc:+.4f} cyc, "
                  f"frac={frac:+.4f}")


if __name__ == "__main__":
    main()
