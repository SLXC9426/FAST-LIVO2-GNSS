#!/usr/bin/env python3
import rosbag
import numpy as np

b = rosbag.Bag("/home/slxc9426/datasets/GREAT/GREAT.bag")
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    data = np.frombuffer(msg.data, dtype=np.uint8)
    print("msg.data bytes:", len(data), "row_step:", msg.row_step, "point_step:", msg.point_step)
    # point 0: x(0-3) y(4-7) z(8-11) intensity(12-15) ring(16-17) time(18-21)
    b0 = data[:22]
    print("point0 bytes:", b0.tolist())
    print("  x:", np.frombuffer(b0[0:4], dtype=np.float32)[0])
    print("  ring:", b0[16] | (b0[17] << 8))
    print("  time f32:", np.frombuffer(b0[18:22], dtype=np.float32)[0])
    # last point
    bN = data[-22:]
    print("last point time f32:", np.frombuffer(bN[18:22], dtype=np.float32)[0])
    break
b.close()
