#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""WP8i: is the added fabs actually reachable?

The keyframe GNSS attach test changed from
    t_lio - t_fix < 0.5          (old)
    |t_lio - t_fix| < 0.5        (new, WP8i)
Those differ only when t_lio - t_fix <= -0.5, i.e. when the attached fix is more
than 0.5 s AHEAD of the LIO state.

`last_valid_gnss_` is the most recent fix that was ACCEPTED, and fixes are only
processed while t_fix < t_lio + 0.5 (the drain condition in run()). At the moment
of acceptance, t_lio - t_fix = -dt_g, and afterwards t_lio only grows, so the
difference is bounded below by min(-dt_g) over accepted epochs. This script
reports that bound from the DT records, i.e. whether the fabs can ever change the
outcome.

Usage: wp8i_reachability.py <gnss_poses.txt> [...]
"""
import sys


for path in sys.argv[1:]:
    dts = []
    for ln in open(path, errors='replace'):
        if not ln.startswith('DT'):
            continue
        p = ln.split()
        if len(p) == 9:
            try:
                dts.append(float(p[3]))       # dt_g = t_lio - t_g
            except ValueError:
                pass
    if not dts:
        print('%-44s no DT records' % path)
        continue
    lo, hi = min(dts), max(dts)
    print('%-44s n=%-5d dt_g = t_lio - t_g in [%+.4f, %+.4f] s' % (path.split('/')[-1], len(dts), lo, hi))
    print('%-44s => t_lio - t_fix at acceptance is in [%+.4f, %+.4f] s' % ('', -hi, -lo))
    print('%-44s => old test and |.| test differ iff diff <= -0.5: %s'
          % ('', 'REACHABLE' if -hi <= -0.5 else 'NOT reachable -> fabs is a no-op here'))
