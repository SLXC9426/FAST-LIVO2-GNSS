#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Report a RINEX observation file's header keys, epoch count, interval and span.

Usage: rinex_summary.py <obs_file>
"""
import sys

path = sys.argv[1]
header_keys = ("INTERVAL", "TIME OF FIRST OBS", "TIME OF LAST OBS", "MARKER NAME",
               "RINEX VERSION", "SYS / # / OBS TYPES")
first = last = None
n_epoch = 0
with open(path, encoding="utf-8", errors="ignore") as f:
    in_header = True
    for line in f:
        if in_header:
            if any(k in line for k in header_keys):
                print("HDR:", line.rstrip())
            if "END OF HEADER" in line:
                in_header = False
            continue
        if line.startswith(">"):
            n_epoch += 1
            stamp = line[1:].strip()
            if first is None:
                first = stamp
            last = stamp
print("epochs: %d" % n_epoch)
print("first : %s" % first)
print("last  : %s" % last)
