/*
A2.4 self-test: chi-square innovation test.

Pins:
  - the statistic is r^T S^-1 r;
  - a 25 m gross error is rejected with a metre-level covariance;
  - the rejection fraction of a correct 3D Gaussian matches chi2(3, 0.99);
  - anisotropy matters (the same residual along a tight axis is worse);
  - a non-SPD covariance is a rejection, not a silent accept;
  - the prediction sigma grows with travelled distance and is capped.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/gnss_innovation_selftest
*/
#include "gnss_innovation.h"

#include <cmath>
#include <cstdio>
#include <random>
#include <string>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok)
{
  std::printf("%s  %-58s\n", ok ? "ok  " : "FAIL", name.c_str());
  if (!ok) ++g_failures;
}

}  // namespace

int main()
{
  using fast_livo::GnssInnovationParams;
  using fast_livo::evaluateGnssInnovation;
  using fast_livo::gnssPredictionSigma;

  const GnssInnovationParams p;

  // ---- basic statistic -----------------------------------------------------
  {
    const auto r = evaluateGnssInnovation(
        Eigen::Vector3d::Zero(), Eigen::Matrix3d::Identity(), p);
    check("zero residual -> gamma 0", r.valid && !r.reject && r.gamma == 0.0);
  }
  {
    const auto r = evaluateGnssInnovation(
        Eigen::Vector3d(25.0, 0.0, 0.0), Eigen::Matrix3d::Identity(), p);
    check("25 m outlier rejected", r.valid && r.reject && r.gamma > 600.0);
  }
  {
    // 3.3 m with S = diag(1,1,1): gamma = 10.89 < 11.345 -> accept.
    const auto a = evaluateGnssInnovation(
        Eigen::Vector3d(3.3, 0.0, 0.0), Eigen::Matrix3d::Identity(), p);
    // 3.4 m -> 11.56 -> reject.
    const auto b = evaluateGnssInnovation(
        Eigen::Vector3d(3.4, 0.0, 0.0), Eigen::Matrix3d::Identity(), p);
    check("chi2 boundary separates 3.3 m and 3.4 m",
          !a.reject && b.reject);
  }

  // ---- anisotropy ----------------------------------------------------------
  {
    Eigen::Matrix3d tight = Eigen::Matrix3d::Zero();
    tight.diagonal() << 0.25, 4.0, 4.0;
    Eigen::Matrix3d loose = Eigen::Matrix3d::Zero();
    loose.diagonal() << 4.0, 0.25, 0.25;
    const Eigen::Vector3d r(3.0, 0.0, 0.0);
    const auto a = evaluateGnssInnovation(r, tight, p);
    const auto b = evaluateGnssInnovation(r, loose, p);
    check("residual along a tight axis is penalised more",
          a.gamma > b.gamma && std::fabs(a.gamma - 36.0) < 1e-9);
  }

  // ---- Gaussian rejection fraction ----------------------------------------
  {
    std::mt19937 rng(20261105u);
    std::normal_distribution<double> n(0.0, 1.0);
    int rejected = 0;
    const int N = 200000;
    for (int i = 0; i < N; ++i)
    {
      const Eigen::Vector3d r(n(rng), n(rng), n(rng));
      if (evaluateGnssInnovation(r, Eigen::Matrix3d::Identity(), p).reject)
        ++rejected;
    }
    const double frac = static_cast<double>(rejected) / N;
    check("3D Gaussian rejection fraction ~ 1%",
          frac > 0.008 && frac < 0.016);
    std::printf("      sample rejection fraction = %.4f\n", frac);
  }

  // ---- invalid covariance --------------------------------------------------
  {
    const auto r = evaluateGnssInnovation(
        Eigen::Vector3d(0.1, 0.0, 0.0), Eigen::Matrix3d::Zero(), p);
    check("zero covariance is rejected", !r.valid && r.reject);
  }
  {
    // Non-symmetric but det > 0: LLT alone would accept the lower triangle.
    Eigen::Matrix3d S = Eigen::Matrix3d::Identity();
    S(0, 1) = 2.0;
    const auto r = evaluateGnssInnovation(Eigen::Vector3d(0.1, 0.0, 0.0), S, p);
    check("non-symmetric covariance is rejected", !r.valid && r.reject);
  }
  {
    // Two negative eigenvalues -> det = 1 > 0, but not SPD.
    Eigen::Matrix3d S = Eigen::Matrix3d::Identity();
    S(0, 0) = -1.0;
    S(1, 1) = -1.0;
    const auto r = evaluateGnssInnovation(Eigen::Vector3d(0.1, 0.0, 0.0), S, p);
    check("negative-eigenvalue covariance is rejected", !r.valid && r.reject);
  }
  {
    // Ill-conditioned but SPD: gamma must be huge, not NaN.
    Eigen::Matrix3d S = Eigen::Matrix3d::Identity();
    S(0, 0) = 1e-12;
    const auto r = evaluateGnssInnovation(Eigen::Vector3d(1.0, 0.0, 0.0), S, p);
    check("ill-conditioned SPD covariance rejects, no NaN",
          r.valid && r.reject && std::isfinite(r.gamma));
  }

  // ---- prediction sigma ----------------------------------------------------
  {
    const double s0 = gnssPredictionSigma(0.0, p);
    const double s10 = gnssPredictionSigma(10.0, p);
    const double sbig = gnssPredictionSigma(1e6, p);
    check("sigma grows with distance", s10 > s0 && s0 == p.sigma0);
    check("sigma is capped", std::fabs(sbig - p.sigma_ceil) < 1e-9);
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: GNSS innovation chi-square test\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
