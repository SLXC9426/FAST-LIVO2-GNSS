import sys

sys.path.insert(0, r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\scripts")
from _eval_campus import load_tum, interp, umeyama
import numpy as np

rt, rp = load_tum(r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\urban01_reference.tum")
ft, fp = load_tum(r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result\great_urban01_baseline_d05.txt")
t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
m = (rt >= t0) & (rt <= t1)
p_f = interp(ft, fp, rt[m])
p_g = rp[m]
e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
path = np.sum(np.linalg.norm(np.diff(fp, axis=0), axis=1))
print(f"baseline(dept=0.5): n={m.sum()} span={t1-t0:.0f}s APE_rmse={np.sqrt(np.mean(e**2)):.1f}m "
      f"path_len={path:.0f}m (ref 3254m)")
