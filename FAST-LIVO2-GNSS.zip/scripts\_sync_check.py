#!/usr/bin/env python3
"""Check LiDAR frame stamp vs IMU time grid alignment (hardware sync sanity)."""
import rosbag, genpy, numpy as np

BAG = "/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag"
b = rosbag.Bag(BAG)

# collect IMU stamps around 1603774014.5~1603774015.0
imu_ts = []
for topic, msg, t in b.read_messages(topics=["/imu_raw"], start_time=genpy.Time(1603774014.0), end_time=genpy.Time(1603774015.5)):
    ts = msg.header.stamp.to_sec()
    if ts == 0:
        ts = t.to_sec()
    imu_ts.append(ts)
imu_ts = np.array(imu_ts)

# LiDAR stamps 0.5s
lid_ts = []
for topic, msg, t in b.read_messages(topics=["/points_raw"], start_time=genpy.Time(1603774014.0), end_time=genpy.Time(1603774015.5)):
    lid_ts.append(msg.header.stamp.to_sec())
lid_ts = np.array(lid_ts)

print("IMU stamps:", len(imu_ts), "dt:", np.median(np.diff(imu_ts)))
print("LiDAR stamps:", len(lid_ts))
for ls in lid_ts:
    d = np.abs(imu_ts - ls)
    i = np.argmin(d)
    print(f"  lidar {ls:.6f}: nearest IMU {imu_ts[i]:.6f}, diff {d[i]*1000:.3f} ms")
b.close()
