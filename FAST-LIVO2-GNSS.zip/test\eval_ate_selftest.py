"""Contract tests for the active evaluator, leaving frozen evidence untouched."""
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path
import numpy as np

sys.dont_write_bytecode = True
SOURCE = Path(__file__).resolve().parents[1]
PROJECT = SOURCE.parents[1]

def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

ev = module('active_eval', PROJECT / '04_执行记录/03_A0-A4优化/eval_ate.py')
independent = module('independent_eval', SOURCE / 'scripts/eval/compare_runs.py')

class AlignmentContract(unittest.TestCase):
    def setUp(self):
        self.src = np.random.default_rng(17).normal(size=(50,3))

    def test_known_rotations_and_translation(self):
        for angle in [-2.1, -.5, .3, 1.4]:
            c,s = np.cos(angle), np.sin(angle)
            R = np.array([[c,-s,0],[s,c,0],[0,0,1]])
            dst = self.src @ R.T + [4,-2,1]
            r,t = ev.umeyama(self.src,dst)
            np.testing.assert_allclose(self.src @ r.T+t, dst, atol=1e-12)

    def test_independent_noisy_reference(self):
        dst = self.src[:,[1,2,0]] + np.random.default_rng(19).normal(0,.02,self.src.shape)
        for points in [dst, dst * [-1,1,1]]:
            r,t = ev.umeyama(self.src,points)
            ri,ti = independent.umeyama3d(self.src,points)
            np.testing.assert_allclose(r,ri,atol=1e-12)
            np.testing.assert_allclose(t,ti,atol=1e-12)
            self.assertAlmostEqual(np.linalg.det(r),1.,places=12)

    def test_invalid_inputs(self):
        for a,b in [(self.src[:2],self.src[:2]), (self.src,self.src[:3]),
                    (self.src,self.src * np.nan)]:
            with self.assertRaises(ValueError): ev.umeyama(a,b)
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder)/'empty.tum'; p.write_text('')
            with self.assertRaises(ValueError): ev.load_tum(p)

    def test_sparse_and_reused_reference_matches(self):
        ia,ib = ev.match(np.array([1.,1.01,9.]),np.array([1.,2.]))
        np.testing.assert_array_equal(ia,[0,1]); np.testing.assert_array_equal(ib,[0,0])
        self.assertEqual(len(ev.match(np.array([1.]),np.array([]))[0]),0)
        result=ev.evaluate('none',np.arange(3.),np.zeros((3,3)),np.arange(9.,12.),np.zeros((3,3)),[])
        self.assertEqual(result['matched'],0)
        self.assertNotIn('ate',result)

    def test_saved_baselines(self):
        expected={'01':(1.0661083981050623,.6910521233203581),
                  '02':(1.1266253193295312,.8667375778011581)}
        for c,values in expected.items():
            tr,pr=ev.load_tum(PROJECT/f'01_项目文档/02_精度与改进/阶段1_离线图修复/data/campus{c}_reference.tum')
            for arm,value in zip(['A0','A1'],values):
                t,p=ev.load_tum(PROJECT/f'04_执行记录/03_A0-A4优化/runs/c{c}_{arm}.tum')
                result=ev.evaluate(arm,t,p,tr,pr,[])
                self.assertAlmostEqual(result['ate']['rmse'],value,places=6)

if __name__=='__main__': unittest.main(verbosity=2)
