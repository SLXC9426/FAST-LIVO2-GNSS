#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive the bounded-drift-prior A/B configs (R3 P1-3, route A3-2).

P1-2 (EVAL_PROTOCOL 14) located the fusion's limiter in the per-epoch GAIN
(~5e-4, set by the ~0.03 m position prior vs the ~4 m adaptive sigma), not in
the gate's absolute scale. P1-3 grows the position prior with the drift a pure
LIO accumulates since the last accepted GNSS update:

    sigma_drift = min(a + b*tau, max),  b calibrated on c01 pure-LIVO
                                        (3.5-5.3 mm/s over 70-200 s, see
                                        .tmp_check/p13_calib_b.py)

The chi-square gate keeps the RAW prior, so the accepted/rejected epoch set is
unchanged; only the gain's S/K and the Joseph covariance see the drift term.

One knob block per arm, everything else byte-identical to the base config, so
each arm carries its own cfg_hash in the registry.

Usage:  make_prior_configs.py
Writes  config/great_campus01_driftprior.yaml and config/great_campus02_driftprior.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

BLOCK = """\
{i}# R3 P1-3 (A3-2): bounded physical drift prior, an exact drift ACCOUNT:
{i}# accrue b*dt per fix interval (capped at max), an accepted epoch pays the
{i}# account down by the correction it actually applied, sigma = max(a, acc).
{i}# b = 0.004 m/s from the measured pure-LIVO post-alignment drift rate on c01
{i}# (3.5-5.3 mm/s). Only the gain's S/K and the Joseph covariance see the drift
{i}# term - the chi-square gate keeps the raw prior, so the accepted/rejected
{i}# epoch set is unchanged (EVAL_PROTOCOL 14.4). Defaults a=0/b=0.004/max=0.8.
{i}prior_drift_en: true
{i}prior_drift_a: 0.0
{i}prior_drift_b: 0.004
{i}prior_drift_max: 0.8
"""

# (base config, output name)
TARGETS = [
    ("great_campus01.yaml", "great_campus01_driftprior.yaml"),
    ("great_campus02.yaml", "great_campus02_driftprior.yaml"),
]


def derive(base_name, out_name):
    base = os.path.join(HERE, os.pardir, "config", base_name)
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()

    out = []
    inserted = False
    key_re = re.compile(r"^(\s*)relative_update:")
    for ln in lines:
        m = key_re.match(ln)
        if m and not inserted:
            out.append(BLOCK.format(i=m.group(1)))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor line 'relative_update:' not found in %s" % base)

    dst = os.path.join(HERE, os.pardir, "config", out_name)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s (from %s)" % (os.path.normpath(dst), base_name))


if __name__ == "__main__":
    for base, out in TARGETS:
        derive(base, out)
