#!/usr/bin/env python3
import rosbag
import numpy as np
import sensor_msgs.point_cloud2 as pc2

b = rosbag.Bag("/home/slxc9426/datasets/GREAT/GREAT.bag")
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    f = {x.name: x.datatype for x in msg.fields}
    pts = list(pc2.read_points(msg, field_names=("ring", "time"), skip_nans=True))
    a = np.array(pts[:8000], dtype=float)
    print("fields:", f, "stamp:", msg.header.stamp.to_sec())
    print("ring unique:", np.unique(a[:, 0].astype(int)).tolist()[:18])
    print("time: %.3f ~ %.3f (us)" % (a[:, 1].min(), a[:, 1].max()))
    break
b.close()
