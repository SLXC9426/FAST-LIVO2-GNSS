#!/bin/bash
# Three-mode re-run for campus-01/02: pure LIVO / LIVO+RTK / single-RTK.
#
# One process at a time; every run evaluated by eval_unified.py (T0-1 segment
# scopes included) and appended to the registry. The current binary is the
# accumulated build with ALL new switches at their defaults (off) - the fusion
# arm therefore reproduces historical behaviour.
#
#   LIVO        : segment_run <seq> livo   (gnss_en false)
#   LIVO+RTK    : segment_run <seq> gnss   (fusion; historical stream)
#   single-RTK  : run_gnss_modes <seq> gnssonly (lidar/img/imu off, GNSS-driven)
#
# Usage: run_three_modes.sh [summary] [tag_prefix]
# tag_prefix defaults to rerun3; pass a new prefix to keep past results intact.
export LANG=C.UTF-8
SUM=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/three_modes/three_modes_summary.txt}
TAGP=${2:-rerun3}
HERE="$(cd "$(dirname "$0")" && pwd)"
SEG=$HERE/segment_run.sh
GNSSMODES=$HERE/run_gnss_modes.sh
G=$HOME/datasets/GREAT
mkdir -p "$(dirname "$SUM")"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

: > "$SUM"
echo "=== three-mode re-run: LIVO / LIVO+RTK / single-RTK | c01+c02 | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum $HOME/catkin_ws/devel/lib/liblaser_mapping.so | cut -c1-8)" | tee -a "$SUM"

# ---- campus-01 (607 s; RTK stream: 1 Hz) ----
echo "" | tee -a "$SUM"
echo "############ campus-01 ############" | tee -a "$SUM"
echo "--- c01 LIVO ---" | tee -a "$SUM"
bash "$SEG" campus01 livo 0 607 ${TAGP}_c01_livo "$G/campus01_rtk1hz.bag" "" great_campus01 2>&1 | tee -a "$SUM"
echo "--- c01 LIVO+RTK ---" | tee -a "$SUM"
bash "$SEG" campus01 gnss 0 607 ${TAGP}_c01_gnss "$G/campus01_rtk1hz.bag" "" great_campus01 2>&1 | tee -a "$SUM"
echo "--- c01 single-RTK ---" | tee -a "$SUM"
bash "$GNSSMODES" campus01 gnssonly ${TAGP}_c01_gnssonly "$G/campus01_rtk1hz.bag" 607 2>&1 | tee -a "$SUM"

# ---- campus-02 (806 s; RTK stream: historical 30 s /gnss) ----
echo "" | tee -a "$SUM"
echo "############ campus-02 ############" | tee -a "$SUM"
echo "--- c02 LIVO ---" | tee -a "$SUM"
bash "$SEG" campus02 livo 0 806 ${TAGP}_c02_livo "$G/gnss_c02_trim.bag" "" great_campus02 2>&1 | tee -a "$SUM"
echo "--- c02 LIVO+RTK ---" | tee -a "$SUM"
bash "$SEG" campus02 gnss 0 806 ${TAGP}_c02_gnss "$G/gnss_c02_trim.bag" "" great_campus02 2>&1 | tee -a "$SUM"
echo "--- c02 single-RTK ---" | tee -a "$SUM"
bash "$GNSSMODES" campus02 gnssonly ${TAGP}_c02_gnssonly "$G/gnss_c02_trim.bag" 806 2>&1 | tee -a "$SUM"

# ---- comparison table ----
{
  echo ""
  echo "=== comparison (from the eval blocks above; RMSE in m) ==="
  printf "%-18s %-8s %-8s %-8s %-8s %-8s\n" tag n full2D steady2D movfit2D statgf2D
  for tag in ${TAGP}_c01_livo ${TAGP}_c01_gnss ${TAGP}_c01_gnssonly ${TAGP}_c02_livo ${TAGP}_c02_gnss ${TAGP}_c02_gnssonly; do
    blk=$(awk "/^== $tag ==/,/cfg=/" "$SUM")
    n=$(echo "$blk" | awk '/^  full/{print $3}' | sed 's/n=//')
    f2=$(echo "$blk" | awk '/^  full/{print $5}' | sed 's/2D_RMSE=//')
    s2=$(echo "$blk" | awk '/^  steady/{print $5}' | sed 's/2D_RMSE=//')
    m2=$(echo "$blk" | awk '/^  movfit/{print $5}' | sed 's/2D_RMSE=//')
    g2=$(echo "$blk" | awk '/^  stat@movfit/{print $4}' | sed 's/2D_RMSE=//')
    printf "%-18s %-8s %-8s %-8s %-8s %-8s\n" "$tag" "$n" "$f2" "$s2" "$m2" "$g2"
  done
} | tee -a "$SUM"
echo "THREE_MODES_DONE $(date +%T)" | tee -a "$SUM"
