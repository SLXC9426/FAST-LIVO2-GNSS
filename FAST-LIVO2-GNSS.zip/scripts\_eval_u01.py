import sys

sys.path.insert(0, r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\scripts")
from _eval_campus import load_tum, interp, umeyama
import numpy as np

REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\urban01_reference.tum"
RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"
rt, rp = load_tum(REF)
ft, fp = load_tum(f"{RES}\\great_urban01_baseline.txt")
t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
m = (rt >= t0) & (rt <= t1)
p_f = interp(ft, fp, rt[m])
p_g = rp[m]
e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
de = np.diff(p_f, axis=0)
dg = np.diff(p_g, axis=0)
print(
    f"urban-01 baseline: n={m.sum()} span={t1-t0:.0f}s "
    f"APE_rmse={np.sqrt(np.mean(e**2)):.2f}m mean={np.mean(e):.2f} max={np.max(e):.2f} "
    f"RPE={np.sqrt(np.mean((de-dg)**2)):.2f}m"
)
