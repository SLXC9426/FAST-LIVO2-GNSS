#!/usr/bin/env python3
"""Summarize an A1 association trace CSV.

Reports per-status counts, the alpha distribution of accepted epochs, bracket
span, and whether any fix timestamp fed more than one factor (the CSV is keyed
by t_fix, so a duplicate would already collapse; the check is explicit).
"""
import argparse
import csv
from collections import Counter

import numpy as np


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path")
    ap.add_argument("--segments", default="", help="a-b,c-d relative to first t")
    args = ap.parse_args()

    rows = []
    with open(args.csv_path, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    if not rows:
        print("empty trace")
        return 1

    t = np.array([float(r["t_fix"]) for r in rows])
    alpha = np.array([float(r["alpha"]) for r in rows])
    bracket = np.array([float(r["bracket_dt"]) for r in rows])
    status = Counter(r["status"] for r in rows)
    factor = np.array([int(r["factor"]) for r in rows])
    quality = np.array([int(r["quality"]) for r in rows])

    print(f"epochs={len(rows)} unique_t={len(set(t.tolist()))}")
    print("status:", dict(status))
    print(f"quality_ok={int(quality.sum())} factors={int(factor.sum())}")
    if len(set(t.tolist())) != len(rows):
        print("WARNING: duplicate t_fix rows (map key should prevent this)")

    acc = factor == 1
    if acc.any():
        print(f"alpha(accepted): min={alpha[acc].min():.3f} "
              f"med={np.median(alpha[acc]):.3f} max={alpha[acc].max():.3f}")
        print(f"bracket(accepted): min={bracket[acc].min():.3f} "
              f"med={np.median(bracket[acc]):.3f} max={bracket[acc].max():.3f}")
        # A factor is duplicated if the same t_fix appears with factor=1 twice;
        # the unique-t check above already covers the CSV contract.
        print(f"duplicate_factor_times="
              f"{len(t[acc]) - len(set(t[acc].tolist()))}")

    if args.segments:
        t0 = t.min()
        for chunk in args.segments.split(","):
            a, b = (float(x) for x in chunk.split("-"))
            sel = (t - t0 >= a) & (t - t0 <= b)
            if sel.sum() == 0:
                continue
            print(f"  {a:g}-{b:g}s: epochs={int(sel.sum())} "
                  f"factors={int(factor[sel].sum())} "
                  f"rate={factor[sel].sum() / sel.sum():.3f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
