# GREAT-Dataset urban-01 + FAST-LIVO2 多模式评估指南

## 1. 数据下载（百度网盘，来自官方 README Table 4）

urban-01 采集于 **2020/10/27**（与 campus-01 同一天、同一平台），
因此外参与 GPS 周（2129）与 campus-01 完全一致，可直接复用现有配置。

| 数据 | 百度网盘链接（提取码） |
|---|---|
| IMU | https://pan.baidu.com/s/1RqmO6hvUjjzmxf8PSNW91g?pwd=k2en |
| Image | https://pan.baidu.com/s/1zLSAq8vQu7v2qqrb66xqtA?pwd=3ctu |
| LiDAR | https://pan.baidu.com/s/1sm6jqp9ljC-99sGfZ9lO6Q?pwd=73qp |
| Reference Solution | https://pan.baidu.com/s/1IMN91SmwA3JouKgTq8w8Qw?pwd=7c5x |
| GNSS 原始观测（可选） | https://pan.baidu.com/s/1lfi47Mj37Rv-_JwSjNV0rg?pwd=6647 |
| Sensor Parameters | https://pan.baidu.com/s/1RPcRsjTcZSf8sOk7GaWiow?pwd=jift |

下载解压后目录结构（与 campus-01 相同）：

```
urban-01/
  IMU/        MEMS_imu_data.txt, Tactical_imu_data.txt
  Image/      img0/, img1/ (data/ + timestamps.txt)
  Lidar/      data/ + timestamps.txt
  GNSS/       gnss.pos（可选，需 GREAT-PVT 处理原始观测）
  groundtruth.txt（或 Reference_Solution/ 下）
```

## 2. 生成配置矩阵

urban-01 与 campus-01 同日采集 → `config/great_campus01.yaml` 的外参/IMU 参数
直接适用。运行一次生成 6 种模式的配置与 launch：

```bash
cd ~/catkin_ws/src/fast_livo
python3 scripts/make_urban01_configs.py
```

生成：
- `config/great_urban01_{baseline,occlusion,dynamic,graph,improved,improved_gnss}.yaml`
- `config/camera_great_urban01.yaml`
- `launch/mapping_great_urban01.launch`（`mode:=` 参数选模式）

## 3. 编译（若尚未）

```bash
cd ~/catkin_ws && catkin_make -j4 && source devel/setup.bash
```

## 4. 转 bag + 真值

```bash
cd ~/catkin_ws/src/fast_livo/Log/GREAT
# 战术级 IMU（200Hz，推荐）；若无该文件脚本自动回退 MEMS
python rawdata2bag_great.py raw_synced /path/to/urban-01 -n urban-01 --imu tactical

# 真值 → TUM（IE 8.9 双向平滑解，格式与 campus-01 相同）
python groundtruth2tum.py /path/to/urban-01/groundtruth.txt /path/to/urban-01/urban-01_reference.tum
```

## 5. 一键多模式评估

```bash
cd ~/catkin_ws/src/fast_livo
DATA=/path/to/urban-01 ./scripts/eval/run_urban01.sh
# 只跑部分模式：
# DATA=/path/to/urban-01 MODES="baseline improved" ./scripts/eval/run_urban01.sh
```

脚本依次：转 bag（如缺）→ 对每个模式 `roslaunch ... mode:=<m>` +
`rosbag play` → evo 风格 APE/RPE（纯 numpy）→ 因子图轨迹/延迟分析 →
动态剔除统计 → 汇总表（`Log/eval/urban01_<mode>/metrics.txt`）。

输出：
- 前端轨迹 `Log/result/great_urban01_<mode>.txt`（TUM）
- 因子图轨迹 `..._graph.txt`、延迟 `..._latency.csv`、动态统计 `..._dyn.csv`
- 汇总表与图 `Log/eval/urban01_<mode>/`

## 6. 模式矩阵说明

| 模式 | P1 遮挡 | P2 因子图 | P3 动态剔除 | GNSS |
|---|---|---|---|---|
| baseline | – | – | – | – |
| occlusion | ✓ | – | – | – |
| dynamic | – | – | ✓ | – |
| graph | – | ✓ | – | – |
| improved | ✓ | ✓ | ✓ | – |
| improved_gnss | ✓ | ✓ | ✓ | ✓（需 GNSS/gnss.pos） |

`improved_gnss` 的 gnss.pos 需用 GREAT-PVT 处理 `GNSS_RAW_DATA` 中 urban-01
的观测文件（参考 campus-01 的做法，见 `Log/GREAT/README_GREAT_campus01.md`）。

## 7. 注意事项

- 车辆起步前静止 3~5 s 让 LIO 初始化（脚本默认 `-s 5` 跳过；若轨迹正常可去掉）。
- urban-01 为城市峡谷场景：VLP-16 匹配退化程度与 campus-01 不同，
  `lio.dept_err/beam_err`（0.2/0.5）可能需要微调——若轨迹发散，
  参考 campus-01 的调试记录（增大观测噪声、开启 map_sliding）。
- 动态目标（行人/车辆）在 urban 场景常见，`improved` 模式的动态剔除
  统计（`_dyn.csv`）可直观对比。
- 因子图后端输出滞后一个窗口（25 关键帧），`_latency.csv` 记录了前端
  与后端的端到端延迟对比。

## 8. P1（遮挡/鲁棒核）在 GREAT 数据集上的已知限制（campus-01 实测）

在 campus-01（VLP-16，LiDAR 匹配退化，dept_err/beam_err 已放大到 0.2/0.5）
上实测：

| 组件 | 结果 |
|---|---|
| P2 因子图后端 | APE RMSE 1.42 → 1.22 m（**−14%，有效**） |
| P1 遮挡判定 | 轨迹发散（误杀退化匹配的点，可用点骤减） |
| P1 Huber 鲁棒核 | 轨迹发散（退化匹配残差大 → 权重削减 → 更信任有漂移的 IMU） |
| P3 动态剔除 | 见 `_dyn.csv` 统计（需 `pub_dyn_en: false` 保证实时性） |

**原因**：遮挡判定与鲁棒核的假设是"点云稠密、匹配质量高、异常点是少数"
（Livox / Ouster 场景）。VLP-16 稀疏 + 匹配退化时，正常点也频繁满足
"残差大 / 位于平面后方"的条件，导致大量误杀，估计退化为纯 IMU 积分
（漂移）。**因此 GREAT（VLP-16）系列建议 P1 保持关闭**，P1 在
NTU-VIRAL（Ouster）/ avia 等高密度点云数据集上再启用。
