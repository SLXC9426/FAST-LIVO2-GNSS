# R3 交接文档 3（P1-3 有界物理漂移先验：机制成立、精度不兑现）

> 面向"接手继续做的人（或下一个会话的我）"。本轮只做了一件事：`R3_NEXT_STEPS` P1-3（路线图 A3-2）。
> 结论是**负结果但机制完全定位**，且它把 P2-1 的归因问题顺手解掉了大半。
> 技术记录一律以 `docs/EVAL_PROTOCOL.md` §16 为准；证据在仓库**上一级** `p1_3_driftprior/`。
> 上一轮交接见 `docs/R3_HANDOVER_2.md`。

## 1. 一句话状态

P1-3 已完成（**判据未达成**）：漂移记账先验把每历元增益限幅真实解除（总修正预算 0.04-0.13 → **0.390 m**，
每历元 |dx| 放大 ~4-10 倍，门控接受集合不变），但 c01 0-200 s 的 2D 只动 +0.019 m（≪ 0.106 m 判据线，
off 臂自身极差就有 0.105）⇒ **未分辨**。链条 P1-2→P1-3 闭环：**门限不是限幅项（§14），增益也不是——
被预算挡住的修正目标值主要是 RTK 的局部误差**。默认保持关闭，代码留作可证伪工具。

| 项 | 内容 | 状态 | 判定 |
|---|---|---|---|
| P1-3 | 有界物理漂移先验（A3-2），vA→vB 两版实现，n=3/臂 A/B + 注入/c02 双护栏 | ✅ | **判据未达成**（协议 §16.3/16.4）|

## 2. 必须随结果一起引用的结论（防误用清单）

1. **"增益是限幅项"这句话现在只对了一半**：增益确实是修正预算的限幅项（解除后预算 2-7 倍），
   但**不是 c01 段 2D 精度的限幅项**（精度不动）。引用 P1-2 的"限幅项是每历元增益"时必须带上本条修正。
2. **机制数字**：接受/拒绝 off 49-51/78-80 vs on 50/79（不变）；mean|dx| 0.0008-0.0026 → 0.0078 m；
   估算总修正 0.040-0.127 → 0.390 m；max drift_sigma 0.267 m ≈ b×65 s（暂态设计值）。
3. **b 的来源**：纯 LIVO（p12_livo_r1/r2）对参考 SE(3) 对齐后 70-200 s 误差斜率 3.5-5.3 mm/s，
   取 0.004 m/s。校准脚本 `.tmp_check/p13_calib_b.py`。**不是**从 GNSS 新息来的（那是 inflate_prior 的循环论证）。
4. **同窗证据**：65-130 s 窗口 LIO-vs-参考只有 0.37-0.56 m，而 LIO-vs-GNSS 分歧 3.5-7 m
   ⇒ 该窗口的融合分歧主体是 **RTK 局部质量**，不是 LIO 漂移。这是"解除增益也不兑现"的直接解释。
5. **护栏数字**：注入 +30 m@141 → γ=594.09 拒（历史 587.58 同量级 ⇒ 门 S 实质未变）；
   c02 WITHHELD（fit residual 7.38 m > 5 m 门，0 接受，2D 7.57）。
6. **vA（锚点重置语义）是被机制检查否定的**：零星接受的历元（|dx| 1-19 mm）每次清零 tau，
   sigma 构造性上界 ~0.05 m ⇒ 过不了判据线。vA 的 registry 行（utc 08:04-08:11，cfg `9b8d26642b`）
   与 vB 行（utc 08:25 起，cfg `593cf6c146`）以 cfg_hash 区分；vA 轨迹留档 `p13vA_*.txt`。

## 3. 新增的可复用资产

**代码**（默认=历史行为，关闭时逐位不变）：
- `gnss/prior_drift_en/a/b/max`（默认 false/0/0.004/0.8）；
- `gnss_processing.h` 三个纯函数 `gnssDriftGrow/Pay/SigmaOf`（记账模型，可独立单测）；
- `updateStateWithGNSS`：`P_upd`（=P_use+漂移方差）只进 llt_S/K/Joseph，`llt_gate` 保持 `P_use`；
  接受路径按 `|dx_pos|` 支付账户；健康行带 `drift_sigma=`（仅开启时）。

**测试**：`gnss_processing_selftest` 第 7 节（grow/pay/sigma_of 契约 + "65 s 未修正、2 mm/次支付 ⇒ acc=0.13 m"记账场景）。

**配置**：`scripts/make_prior_configs.py` → `great_campus01_driftprior.yaml` / `great_campus02_driftprior.yaml`。

**证据目录** `p1_3_driftprior/`：run_ab.sh / run_guard.sh / mechanism.sh、ab_summary.txt / guard_summary.txt、
8 个 seg 日志 + 2 个 vA 轨迹 + 注入 poses；`.tmp_check/p13_calib_b.py`（b 校准）。
registry 追加 11 行（vA 3 行 + vB 6 行 + 护栏 2 行）。

## 4. 对下一步的影响

1. **P2-1 的"分解"实际已完成大半**：0.25 m 差距的四个候选，④（WP7 少修正）被本轮直接排除
   （多修 0.26 m 精度不动），①（LIO 漂移）确认不是来源；剩 **②（A3 释放常量偏移）+ ③（对齐拟合残差 0.48-0.54 m）**，
   两者都不是滤波器能修的 ⇒ **进 L3（进程耦合）的触发条件大概率不满足**，阶段 6 决策门可以直接依据
   §16.6 收口。
2. **WP10b 第三条否定证据**：门方向（§14）和先验方向（§16）放大融合强度在 c01 上都无法兑换精度。
3. **P2-2（速度观测诚实先验）**：本项目的记账机制是位置块的；速度若要做应复用同一"按施加量支付"的
   记账语义（不是重置语义），但鉴于位置上的负结果，优先级进一步下降。
4. **漂移记账的适用边界**：只在"LIO 真实漂移率 > RTK 局部质量"的场景可能兑现（长程/长期无修正，
   如 c03 类）。c03 观测是 groundtruth，只能作健壮性证据（P2-3 未做，仍开放）。

## 5. 环境与流程坑（本轮新增）

1. **F 盘没了**：`PROGRESS.md` 里的数据集路径 `F:\GREAT数据集` 已失效（F: 不存在）；
   数据实际在 WSL `~/datasets/GREAT/`（campus-0X bag、rtk bag、注入 bag 都在）。PROGRESS 待更新。
2. **后台跑 A/B 时不要在两次运行之间改 WSL 侧文件**：vA 的 seg 日志被 vB 的 run_ab 用同名重定向覆盖
   （`> ~/seg_${TAG}.log` 截断）——vA 只存活于 registry 行 + 轨迹 txt；证据目录里的 vB 日志是补拷的。
3. **cmd → wsl 的 `$var` 展开坑又烧了一次**（for 循环 + `$E` 变量全部字面传递）：
   凡循环/变量一律写成脚本文件（本轮 mechanism.sh/run_ab.sh 都是脚本，只有临时修补踩了坑）。
4. **自检抓了写文档的人自己的算术错**：test 7 的记账场景断言先写错（0.24，正确 0.13）——
   先写断言再推敲期望值，自检的价值之一。

## 6. 怎么复算（速查）

```bash
# 0) 同步 + 编译 + 三个自检（20 项因子图 / 7 节 GnssProcess / ENU 往返）
wsl -d Ubuntu-20.04 -e bash <repo>/scripts/dev/sync_to_wsl.sh
wsl -d Ubuntu-20.04 -e bash -c "~/catkin_ws/devel/lib/fast_livo/gnss_processing_selftest"

# 1) b 校准（秒级）
wsl -d Ubuntu-20.04 -e bash -c "python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/.tmp_check/p13_calib_b.py"

# 2) A/B（约 25 min）+ 机制表
wsl -d Ubuntu-20.04 -e bash -c "bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/p1_3_driftprior/run_ab.sh"
wsl -d Ubuntu-20.04 -e bash -c "bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/p1_3_driftprior/mechanism.sh p13_off_r1 p13_on_r1"

# 3) 护栏（约 12 min）
wsl -d Ubuntu-20.04 -e bash -c "bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/p1_3_driftprior/run_guard.sh"
```

## 7. 一句话提醒

本轮是**第三个否定结论**（门 sigma 不是限幅项 → 增益也不是 c01 段精度的限幅项 → 0.25 m 差距的
可修来源已排除，只剩对齐拟合残差与 RTK 局部质量这两个非滤波器项）。引用 P1-2 的"限幅项是增益"
时必须带上 §16.4 的修正；引用 0.390 m 预算时必须带上"精度未兑现"。
