#ifndef GRAPH_FIT_MASK_H_
#define GRAPH_FIT_MASK_H_
#include <algorithm>
#include <cmath>
#include <vector>
namespace fast_livo {
// Exact endpoint uses only itself. True interpolation requires both measured
// endpoints; an untested or rejected epoch is never evidence for pass 2.
inline bool acceptedFitSample(const std::vector<double> &times,
                              const std::vector<char> &accepted, double t) {
  if(times.empty() || times.size()!=accepted.size() || !std::isfinite(t)) return false;
  for(size_t i=0;i<times.size();++i)
    if(!std::isfinite(times[i]) || (i && times[i]<=times[i-1])) return false;
  const auto it=std::lower_bound(times.begin(),times.end(),t);
  if(it!=times.end() && *it==t) return accepted[it-times.begin()]!=0;
  if(it==times.begin() || it==times.end()) return false;
  const size_t b=it-times.begin();
  return accepted[b-1] && accepted[b];
}
}
#endif
