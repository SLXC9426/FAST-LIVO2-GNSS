#!/usr/bin/env python3
"""A3 baseline: static-anchor observability on the campus-02 startup segment.

This does NOT change the graph. It mirrors the frozen A2 logic
(static detector, nearest-fix assignment, per-axis median anchor) and reports
what the data actually provides: LIO displacement/attitude, GNSS quality,
anchor spread, current strong/weak decision, and sliding-window stability.

Run from WSL:
  python3 tools/static_anchor_baseline.py --start 0 --end 120
"""
import argparse
import csv
import math
import re
from collections import Counter
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path("/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main")
LIO = ROOT / "03_实验记录/对比实验/gv1/oracle/gv1_campus02_livo_r1_base.tum"
RTK = ROOT / ("01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/"
              "data/campus02_rtk1hz.tum")
REF = ROOT / ("01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/"
              "data/campus02_reference.tum")
QUAL = ROOT / ("01_文档/02_改进与精度汇总/阶段0_评估契约_2026-10-30/"
               "FIXBASE-RTK-c02-1hz_quality.csv")
GTUM = ROOT / "06_exec/optimization/runs/c02_A1.tum"
GLOG = ROOT / "06_exec/optimization/runs/c02_A1_node.log"
OUT = ROOT / "06_exec/optimization/A3"
FIG = OUT / "figures"


def load_tum(path):
    t, p, q = [], [], []
    for line in path.open(errors="ignore"):
        s = line.split()
        if len(s) < 8:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
            q.append([float(s[4]), float(s[5]), float(s[6]), float(s[7])])
        except ValueError:
            pass
    return np.asarray(t), np.asarray(p), np.asarray(q)


def quat_to_R(q):
    x, y, z, w = q / np.linalg.norm(q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def median_vec(v):
    return np.array([np.median(v[:, k]) for k in range(3)])


def geometric_median(v, iters=200, eps=1e-10):
    y = np.median(v, axis=0)
    for _ in range(iters):
        d = np.maximum(np.linalg.norm(v - y, axis=1), 1e-9)
        w = 1.0 / d
        y_new = (v * w[:, None]).sum(0) / w.sum()
        if np.linalg.norm(y_new - y) < eps:
            return y_new
        y = y_new
    return y


def static_runs(t, p, thresh, win, gap):
    n = len(t)
    speed = np.zeros(n)
    dt = np.diff(t)
    speed[1:] = np.linalg.norm(np.diff(p, axis=0), axis=1) / np.maximum(dt, 1e-9)
    stat = np.zeros(n, bool)
    for i in range(n):
        a, b = max(0, i - win), min(n - 1, i + win)
        stat[i] = np.median(speed[a:b + 1]) < thresh
    runs = []
    i = 0
    while i < n:
        if not stat[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and stat[j + 1]:
            j += 1
        if runs and i - runs[-1][1] <= gap:
            runs[-1] = (runs[-1][0], j)
        else:
            runs.append((i, j))
        i = j + 1
    return speed, stat, runs


def load_quality(path):
    out = {}
    with path.open(encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            try:
                t = int(round(float(r["t_unix"])))
            except (KeyError, ValueError):
                continue
            out[t] = {
                "status": (r.get("status") or "").strip(),
                "nsat": float(r.get("nsat") or 0.0),
                "pdop": float(r.get("pdop") or 0.0),
            }
    return out


def parse_frozen_log(path):
    line = ""
    for l in path.open(errors="ignore"):
        if "ONLINE GRAPH" in l:
            line = l

    def g(key):
        m = re.search(rf"\b{key}=([-\d.]+)", line)
        return float(m.group(1)) if m else float("nan")

    m = re.search(r"tr=([-\d.]+),([-\d.]+),([-\d.]+)", line)
    tr = np.array([float(x) for x in m.groups()]) if m else np.zeros(3)
    return dict(scale=g("scale"), yaw_deg=g("yaw"), fit=g("fit"),
                tr=tr, rtk=g("rtk"), rtk_i=g("rtk_i"))


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--end", type=float, default=120.0)
    ap.add_argument("--lever", default="-0.05,-0.325,0.165")
    ap.add_argument("--thresh", type=float, default=0.20)
    ap.add_argument("--win", type=int, default=3)
    ap.add_argument("--gap", type=int, default=2)
    ap.add_argument("--sig-anchor", type=float, default=0.3)
    ap.add_argument("--anchor-weak", type=float, default=10.0)
    ap.add_argument("--anchor-consistency", type=float, default=1.0)
    args = ap.parse_args()
    lever = np.array([float(x) for x in args.lever.split(",")])

    t, p, q = load_tum(LIO)
    rt, rp, _ = load_tum(RTK)
    gt, gp, _ = load_tum(GTUM)
    reft, refp, _ = load_tum(REF)
    quality = load_quality(QUAL)
    frozen = parse_frozen_log(GLOG)

    t0 = t[0] + args.start
    t1 = t[0] + args.end
    speed, stat, runs = static_runs(t, p, args.thresh, args.win, args.gap)
    # static run containing t0 (fallback: the window itself)
    run = None
    for a, b in runs:
        if t[a] <= t0 <= t[b]:
            run = (a, b)
            break
    if run is None:
        run = (int(np.searchsorted(t, t0)), int(np.searchsorted(t, t1)))
    a, b = run
    trun = t[a:b + 1]
    prun = p[a:b + 1]
    Rrun = np.array([quat_to_R(x) for x in q[a:b + 1]])

    # frozen alignment
    yaw = math.radians(frozen["yaw_deg"])
    cy, sy = math.cos(yaw), math.sin(yaw)
    Rz = np.array([[cy, -sy, 0], [sy, cy, 0], [0, 0, 1]])
    scale = frozen["scale"]
    p0 = (Rz @ (scale * prun.T)).T + frozen["tr"]

    # LIO displacement / attitude
    net = prun[-1] - prun[0]
    exc = np.linalg.norm(prun - prun[0], axis=1)
    path = np.linalg.norm(np.diff(prun, axis=0), axis=1).sum()
    speed_run = speed[a:b + 1]
    rel = []
    for R in Rrun:
        c = np.clip((np.trace(Rrun[0].T @ R) - 1.0) / 2.0, -1.0, 1.0)
        rel.append(math.degrees(math.acos(c)))
    rel = np.asarray(rel)
    yaw_run = np.degrees(np.arctan2(Rrun[:, 1, 0], Rrun[:, 0, 0]))
    yaw_dev = yaw_run - yaw_run[0]

    # unique nearest fix per keyframe (mirror the graph, over all keyframes up
    # to the run end so earlier consumption is respected)
    used = np.zeros(len(rt), bool)
    assign = {}
    for i in range(0, b + 1):
        j = int(np.argmin(np.abs(rt - t[i])))
        if abs(rt[j] - t[i]) < 0.6 and not used[j]:
            used[j] = True
            assign[i] = j

    qvec, qstatus, qnsat, qpdop = [], [], [], []
    for i in range(a, b + 1):
        if i not in assign:
            continue
        j = assign[i]
        st = quality.get(int(round(rt[j])), {})
        qvec.append(rp[j] - Rz @ Rrun[i - a] @ lever)
        qstatus.append(st.get("status", "unknown"))
        qnsat.append(st.get("nsat", 0.0))
        qpdop.append(st.get("pdop", 0.0))
    qvec = np.asarray(qvec) if qvec else np.zeros((0, 3))
    fixed_mask = np.array([s == "Fixed" for s in qstatus], dtype=bool)
    qfixed = qvec[fixed_mask] if len(qvec) else np.zeros((0, 3))
    lag_last = float(rt[assign[b]] - t[b]) if b in assign else 0.0

    def anchor_stats(v):
        if len(v) == 0:
            return (np.zeros(3), np.zeros(3), 0.0, 0.0, 0.0)
        med = median_vec(v)
        gm = geometric_median(v)
        d = np.linalg.norm(v - med, axis=1)
        mad = np.median(np.abs(d - np.median(d)))
        return (med, gm, float(np.median(d)), float(np.percentile(d, 95)),
                1.4826 * mad, float(d.max()))

    anchor_med, anchor_gm, med_abs, p95, robust_sigma, max_abs = anchor_stats(qvec)
    anchor_fixed, anchor_fixed_gm, med_fixed, p95_fixed, sig_fixed, max_fixed = \
        anchor_stats(qfixed)
    lio_med = median_vec(p0)
    gap = float(np.linalg.norm(anchor_med - lio_med))
    gap_fixed = float(np.linalg.norm(anchor_fixed - lio_med))

    # Stable core: skip the initial settling transient (through 12 s inclusive) and the motion
    # onset at the end (~1 s). The figure shows both clearly.
    qtimes = np.array([t[i] for i in range(a, b + 1) if i in assign])
    core_sel = ((qtimes >= trun[0] + 13.0) & (qtimes <= trun[-1] - 1.0)
                if len(qtimes) else np.zeros(0, bool))
    qcore = qvec[core_sel] if len(qvec) else np.zeros((0, 3))
    fcore = qvec[core_sel & fixed_mask] if len(qvec) else np.zeros((0, 3))
    anchor_core, anchor_core_gm, med_core, p95_core, sig_core, max_core = \
        anchor_stats(qcore)
    anchor_core_f, _, med_core_f, p95_core_f, sig_core_f, max_core_f = \
        anchor_stats(fcore)
    gap_core = float(np.linalg.norm(anchor_core - lio_med))

    # Conservative core: one more second off the end. The nearest-fix
    # assignment is ~0.4 s late in this dataset, so the last retained
    # keyframe can still see a fix after motion onset.
    core2_sel = ((qtimes >= trun[0] + 13.0) & (qtimes <= trun[-1] - 2.0)
                 if len(qtimes) else np.zeros(0, bool))
    qcore2 = qvec[core2_sel] if len(qvec) else np.zeros((0, 3))
    fcore2 = qvec[core2_sel & fixed_mask] if len(qvec) else np.zeros((0, 3))
    anchor_core2, _, med_core2, p95_core2, sig_core2, max_core2 = \
        anchor_stats(qcore2)
    anchor_core2_f, _, med_core2_f, p95_core2_f, sig_core2_f, max_core2_f = \
        anchor_stats(fcore2)
    current_sig = args.sig_anchor if gap <= args.anchor_consistency else args.anchor_weak
    fixed_sig = args.sig_anchor if gap_fixed <= args.anchor_consistency else args.anchor_weak
    fixed_ratio = (sum(1 for s in qstatus if s == "Fixed") /
                   max(1, len(qstatus)))

    # sliding-window anchor stability
    win_s = 10.0
    win_anchors = []
    for w0 in np.arange(trun[0], trun[-1] - win_s + 1e-9, win_s):
        sel = (trun >= w0) & (trun < w0 + win_s)
        if sel.sum() < 3:
            continue
        idx = np.where(sel)[0]
        vals = []
        for k in idx:
            i = a + int(k)
            if i in assign:
                vals.append(rp[assign[i]] - Rz @ Rrun[int(k)] @ lever)
        if len(vals) >= 3:
            win_anchors.append((w0 - t[0], median_vec(np.asarray(vals))))
    win_a = np.asarray([x[1] for x in win_anchors]) if win_anchors else np.zeros((0, 3))
    win_t = np.asarray([x[0] for x in win_anchors]) if win_anchors else np.zeros(0)
    win_dev = (np.linalg.norm(win_a - anchor_med, axis=1) if len(win_a)
               else np.zeros(0))
    win_rng = ((win_a.max(0) - win_a.min(0)) if len(win_a) else np.zeros(3))

    # GNSS quality in the run
    st_counts = Counter(qstatus)
    nsat = np.asarray([x for x in qnsat if x > 0]) if any(x > 0 for x in qnsat) else np.zeros(0)
    pdop = np.asarray([x for x in qpdop if x > 0]) if any(x > 0 for x in qpdop) else np.zeros(0)

    # RTK local stability over the static part only: the detector end can be a
    # fraction of a second late, and the first motion epoch would otherwise
    # dominate the "net displacement" numbers.
    static_end = trun[-1] - 1.0
    rsel = (rt >= trun[0]) & (rt <= static_end)
    rprun = rp[rsel]
    rtk_net = np.linalg.norm(rprun[-1] - rprun[0]) if len(rprun) > 1 else 0.0
    rtk_exc = np.max(np.linalg.norm(rprun - rprun[0], axis=1)) if len(rprun) else 0.0
    # net over the full detected segment (includes the late motion epoch), used
    # only to explain why the raw segment net is much larger than the static part
    rfsel = (rt >= trun[0]) & (rt <= trun[-1])
    rfull = rp[rfsel]
    rtk_run_net = np.linalg.norm(rfull[-1] - rfull[0]) if len(rfull) > 1 else 0.0
    fixed_t = [rt[assign[i]] for i in range(a, b + 1)
               if i in assign and rt[assign[i]] <= static_end and
               quality.get(int(round(rt[assign[i]])), {}).get("status") == "Fixed"]
    fixed_p = [rp[assign[i]] for i in range(a, b + 1)
               if i in assign and rt[assign[i]] <= static_end and
               quality.get(int(round(rt[assign[i]])), {}).get("status") == "Fixed"]
    if len(fixed_p) > 1:
        fixed_p = np.asarray(fixed_p)
        rtk_fixed_net = np.linalg.norm(fixed_p[-1] - fixed_p[0])
        rtk_fixed_exc = np.max(np.linalg.norm(fixed_p - fixed_p[0], axis=1))
    else:
        rtk_fixed_net = rtk_fixed_exc = 0.0

    # deviation of each anchor sample from the robust anchor (outlier vs drift)
    qdev = np.linalg.norm(qvec - anchor_med, axis=1) if len(qvec) else np.zeros(0)
    qdev_fixed = (np.linalg.norm(qfixed - anchor_fixed, axis=1)
                  if len(qfixed) else np.zeros(0))
    frac_05 = float(np.mean(qdev <= 0.5)) if len(qdev) else 0.0
    frac_05_fixed = float(np.mean(qdev_fixed <= 0.5)) if len(qdev_fixed) else 0.0

    # reference displacement in the same window: is the segment really static?
    refsel = (reft >= trun[0]) & (reft <= static_end)
    refprun = refp[refsel]
    reftrun = reft[refsel]
    ref_net = np.linalg.norm(refprun[-1] - refprun[0]) if len(refprun) > 1 else 0.0
    ref_exc = np.max(np.linalg.norm(refprun - refprun[0], axis=1)) if len(refprun) else 0.0
    dref = (np.linalg.norm(refprun - refprun[0], axis=1)
            if len(refprun) else np.zeros(0))

    # onset must be measured on the full window, not the static part (the
    # static part is cut before the motion starts).
    full = (reft >= trun[0] - 1) & (reft <= trun[-1] + 1)
    full_t, full_p = reft[full], refp[full]
    dref_full = (np.linalg.norm(full_p - full_p[0], axis=1)
                 if len(full_p) else np.zeros(0))

    def onset(limit):
        idx = np.where(dref_full > limit)[0]
        return float(full_t[idx[0]] - full_t[0]) if len(idx) else float("nan")

    ref_speed = (np.linalg.norm(np.diff(refprun, axis=0), axis=1) /
                 np.maximum(np.diff(reftrun), 1e-9)) if len(refprun) > 1 else np.zeros(0)
    qdev_t = (trun[[i - a for i in range(a, b + 1) if i in assign]]
              if len(qdev) else np.zeros(0))
    qdev_max_t = float(qdev_t[int(np.argmax(qdev))] - t[0]) if len(qdev) else float("nan")

    # frozen graph output in the same window
    gsel = (gt >= trun[0]) & (gt <= trun[-1])
    gprun = gp[gsel]
    gnet = np.linalg.norm(gprun[-1] - gprun[0]) if len(gprun) > 1 else 0.0
    gexc = np.max(np.linalg.norm(gprun - gprun[0], axis=1)) if len(gprun) else 0.0
    # static-loc error vs reference (2D, nearest match)
    gerr = []
    for i in np.where(gsel)[0]:
        k = int(np.argmin(np.abs(reft - gt[i])))
        if abs(reft[k] - gt[i]) <= 0.11:
            gerr.append(np.linalg.norm((gp[i] - refp[k])[:2]))
    gerr = np.asarray(gerr)

    # ---- report ----------------------------------------------------------
    OUT.mkdir(parents=True, exist_ok=True)
    FIG.mkdir(parents=True, exist_ok=True)
    lines = []
    add = lines.append

    add("# A3 基线：campus-02 启动段静态锚可观测性\n")
    add(f"- 窗口：{args.start:g}–{args.end:g} s（相对 LIO 首帧）")
    add("- 冻结代码：`a2-freeze` / `68da087`；冻结图输出 `c02_A1.tum`")
    add("- 输入：`gv1_campus02_livo_r1_base.tum`、`campus02_rtk1hz.tum`、"
        "`FIXBASE-RTK-c02-1hz_quality.csv`")
    add(f"- 冻结初始拟合：scale={frozen['scale']:.5f}、yaw={frozen['yaw_deg']:.3f}°、"
        f"tr=({frozen['tr'][0]:.3f},{frozen['tr'][1]:.3f},{frozen['tr'][2]:.3f})、"
        f"fit_rms={frozen['fit']:.3f} m\n")

    add("## 1. 静态检测（与 `global_pose_graph.cpp` 同规则）\n")
    add(f"- 检测阈值 `detect_thresh={args.thresh}`、`detect_win={args.win}`、"
        f"相邻静态段合并间隔 `{args.gap}` 帧")
    add(f"- 检测到的静态段：{[(round(t[x]-t[0],1), round(t[y]-t[0],1)) for x,y in runs if t[x] < t0+300]}")
    add(f"- 本窗口静态段：{trun[0]-t[0]:.1f}–{trun[-1]-t[0]:.1f} s，"
        f"{len(trun)} 帧")
    add(f"- LIO 速度：中位 {np.median(speed_run):.4f} m/s，P95 "
        f"{np.percentile(speed_run,95):.4f}，最大 {speed_run.max():.4f}\n")

    add("## 2. LIO 位移与姿态\n")
    add(f"- 净位移：{np.linalg.norm(net):.3f} m（E {net[0]:.3f}, N {net[1]:.3f}, "
        f"U {net[2]:.3f}）")
    add(f"- 相对首帧最大偏移：{exc.max():.3f} m；路径长度：{path:.3f} m")
    add(f"- 相对首帧旋转：最大 {rel.max():.3f}°，末帧 {rel[-1]:.3f}°")
    add(f"- yaw 偏差范围：{yaw_dev.min():+.3f}° … {yaw_dev.max():+.3f}°\n")

    add("## 3. GNSS 质量（窗口内参与锚估计的 fix）\n")
    add(f"- 样本数：{len(qvec)}；状态计数：{dict(st_counts)}；Fixed 比例："
        f"{fixed_ratio:.3f}")
    if len(nsat):
        add(f"- nsat：中位 {np.median(nsat):.0f}，P95 {np.percentile(nsat,95):.0f}")
    if len(pdop):
        add(f"- PDOP：中位 {np.median(pdop):.3f}，P95 {np.percentile(pdop,95):.3f}")
    add(f"- RTK 局部净位移（全质量样本）：{rtk_net:.3f} m；最大偏移："
        f"{rtk_exc:.3f} m")
    add(f"- RTK 局部净位移（仅 Fixed）：{rtk_fixed_net:.3f} m；最大偏移："
        f"{rtk_fixed_exc:.3f} m")
    add(f"- 相对稳健 anchor：全样本 ≤0.5 m 占 {frac_05*100:.1f}%（最大 "
        f"{qdev.max() if len(qdev) else 0:.3f} m @ t={qdev_max_t:.1f}s）；"
        f"仅 Fixed 占 {frac_05_fixed*100:.1f}%（最大 "
        f"{qdev_fixed.max() if len(qdev_fixed) else 0:.3f} m）")
    add(f"- 参考轨迹在静止部分（截至 t={static_end-t[0]:.1f}s）净位移："
        f"{ref_net:.3f} m；最大偏移：{ref_exc:.3f} m")
    add(f"- 参考运动起始：偏移超过 0.5 m 在 t={onset(0.5):.1f}s，超过 1.0 m 在 "
        f"t={onset(1.0):.1f}s；参考速度中位 "
        f"{np.median(ref_speed) if len(ref_speed) else float('nan'):.3f} m/s，"
        f"最大 {ref_speed.max() if len(ref_speed) else float('nan'):.3f} m/s")
    add(f"- **结论：0–{static_end-t[0]:.1f}s 是真正的静止段**，检测器在 "
        f"{trun[-1]-t[0]:.1f}s 结束，只比参考运动起点晚 "
        f"{(trun[-1]-t[0]) - onset(0.5):.1f}s；RTK 在检测段（0–"
        f"{trun[-1]-t[0]:.1f}s）的净位移 {rtk_run_net:.2f} m 来自边界运动历元，"
        f"不是静止段内的漂移。\n")

    add("## 4. Anchor 估计（当前逻辑 vs 几何中值；全样本 vs 仅 Fixed）\n")
    add("| 项 | 全质量样本（Fixed+Float） | 仅 Fixed |")
    add("|---|---:|---:|")
    for k, name in enumerate(["E", "N", "U"]):
        add(f"| {name} 逐轴中值 (m) | {anchor_med[k]:.3f} | "
            f"{anchor_fixed[k]:.3f} |")
    add(f"| 几何中值差 (m) | {np.linalg.norm(anchor_med-anchor_gm):.3f} | "
        f"{np.linalg.norm(anchor_fixed-anchor_fixed_gm):.3f} |")
    add(f"| 样本数 | {len(qvec)} | {len(qfixed)} |")
    add(f"| 中位 \\|q−anchor\\| (m) | {med_abs:.3f} | {med_fixed:.3f} |")
    add(f"| P95 \\|q−anchor\\| (m) | {p95:.3f} | {p95_fixed:.3f} |")
    add(f"| 最大 \\|q−anchor\\| (m) | {max_abs:.3f} | {max_fixed:.3f} |")
    add(f"| 稳健 σ (m) | {robust_sigma:.3f} | {sig_fixed:.3f} |")
    add(f"| 与 LIO 中值距离 (m) | {gap:.3f} | {gap_fixed:.3f} |")
    add(f"| 当前判据 → σ (m) | {('强' if gap <= args.anchor_consistency else '弱')}"
        f" {current_sig:g} | "
        f"{('强' if gap_fixed <= args.anchor_consistency else '弱')} "
        f"{fixed_sig:g} |")
    add("")
    add(f"- 当前代码会使用全质量样本、σ={current_sig:g} m 的锚，"
        f"`sig_anchor={args.sig_anchor}`，`static_anchor_weak={args.anchor_weak}`")
    add(f"- 仅 Fixed 的锚与全样本锚相差 "
        f"{np.linalg.norm(anchor_fixed-anchor_med):.3f} m")

    add("\n### 稳定核（去掉启动 ~13 s 与末端 ~1 s）\n")
    add("| 项 | 全样本 | 仅 Fixed |")
    add("|---|---:|---:|")
    add(f"| 样本数 | {len(qcore)} | {len(fcore)} |")
    for k, name in enumerate(["E", "N", "U"]):
        add(f"| {name} 中值 (m) | {anchor_core[k]:.3f} | "
            f"{anchor_core_f[k]:.3f} |")
    add(f"| 中位 \\|q−anchor\\| (m) | {med_core:.3f} | {med_core_f:.3f} |")
    add(f"| P95 \\|q−anchor\\| (m) | {p95_core:.3f} | {p95_core_f:.3f} |")
    add(f"| 最大 \\|q−anchor\\| (m) | {max_core:.3f} | {max_core_f:.3f} |")
    add(f"| 稳健 σ (m) | {sig_core:.3f} | {sig_core_f:.3f} |")
    add(f"| 与 LIO 中值距离 (m) | {gap_core:.3f} | — |")
    add(f"| 与全段锚差 (m) | {np.linalg.norm(anchor_core-anchor_med):.3f} | "
        f"{np.linalg.norm(anchor_core_f-anchor_fixed):.3f} |")
    add("")

    add(f"\n### 保守核（末端再提前 1 s，{trun[0]-t[0]+13:.0f}–{trun[-1]-t[0]-2:.1f} s）\n")
    add("| 项 | 全样本 | 仅 Fixed |")
    add("|---|---:|---:|")
    add(f"| 样本数 | {len(qcore2)} | {len(fcore2)} |")
    add(f"| 中位 \\|q−anchor\\| (m) | {med_core2:.3f} | {med_core2_f:.3f} |")
    add(f"| P95 \\|q−anchor\\| (m) | {p95_core2:.3f} | {p95_core2_f:.3f} |")
    add(f"| 最大 \\|q−anchor\\| (m) | {max_core2:.3f} | {max_core2_f:.3f} |")
    add(f"| 稳健 σ (m) | {sig_core2:.3f} | {sig_core2_f:.3f} |")
    add(f"| 与全段锚差 (m) | {np.linalg.norm(anchor_core2-anchor_med):.3f} | "
        f"{np.linalg.norm(anchor_core2_f-anchor_fixed):.3f} |")
    add("")

    add("## 5. 滑动窗口稳定性（10 s 窗口逐轴中值）\n")
    if len(win_a):
        add(f"- 窗口数：{len(win_a)}；相对全窗口 anchor 的最大偏移："
            f"{win_dev.max():.3f} m")
        add(f"- 各轴窗口中值范围：E {win_rng[0]:.3f}、N {win_rng[1]:.3f}、"
            f"U {win_rng[2]:.3f} m")
    else:
        add("- 窗口不足，无法评估")
    add("")

    add("## 6. 冻结图输出在静态段的表现\n")
    add(f"- 图输出（`c02_A1.tum`）净位移：{gnet:.3f} m；最大偏移：{gexc:.3f} m")
    if len(gerr):
        add(f"- 相对参考的静态 2D 误差：中位 {np.median(gerr):.3f} m，"
            f"P95 {np.percentile(gerr,95):.3f} m，RMSE "
            f"{np.sqrt(np.mean(gerr**2)):.3f} m")
    add("")

    add("## 7. 对 A3 观测模型的含义（只给读数，不定参数）\n")
    add(f"1. 0–{static_end-t[0]:.1f}s 是真正的静止段；检测器在 "
        f"{trun[-1]-t[0]:.1f}s 结束，只比参考运动起点晚 "
        f"{(trun[-1]-t[0]) - onset(0.5):.1f}s。检测规则本身在本段可用，"
        f"但需要处理末端 1–2 个历元；")
    add(f"2. 静止段内 LIO 自身净位移 {np.linalg.norm(net):.2f} m、姿态变化 "
        f"{rel.max():.2f}°，说明“LIO 静止”不成立，静态锚不能以 LIO 位置为真值；")
    add(f"3. RTK 在静止部分有慢漂移：仅 Fixed 的净位移 {rtk_fixed_net:.2f} m"
        f"（参考 {ref_net:.2f} m），但相对中值的 P95 只有 {p95_fixed:.2f} m、"
        f"稳健 σ {sig_fixed:.2f} m；说明短窗稳定、长窗有趋势，"
        f"单锚在 {static_end-trun[0]:.0f} s 上仍有约 {rtk_fixed_net:.1f} m 的"
        f"窗口依赖；")
    add(f"4. 当前 anchor 与 LIO 中值差 {gap:.2f} m，按现有规则使用 "
        f"{'强' if gap <= args.anchor_consistency else '弱'}锚；冻结图静态段"
        f"相对参考仍有 {np.sqrt(np.mean(gerr**2)) if len(gerr) else float('nan'):.2f} m "
        f"RMSE，说明“与 LIO 一致”不能作为锚可信的判据；")
    add(f"5. 全样本与仅 Fixed 的锚只差 "
        f"{np.linalg.norm(anchor_fixed-anchor_med):.3f} m，说明偏差是 RTK 共性"
        f"偏差，不是 Float 样本造成的；A3 的观测模型应使用 Fixed-only 几何中值"
        f"+ 稳健离散度，并显式记录绝对偏差风险，而不是继续用 LIO 距离判强弱；")
    add(f"6. 当前强锚把静态段放到 RTK 的绝对位置上（相对参考 3.35 m）；"
        f"这个量级远大于 RTK 段内漂移（{rtk_fixed_net:.2f} m），"
        f"因此 A3 的锚只能解决“段内如何估计”，不能单独消除 RTK 绝对偏差；"
        f"评估必须把绝对 bias 与段内形状分开。")
    add(f"7. 稳定核（{trun[0]-t[0]+13:.0f}–{static_end-t[0]:.1f}s，{len(qcore)} 样本，"
        f"Fixed {len(fcore)}）的锚与全段锚只差 "
        f"{np.linalg.norm(anchor_core-anchor_med):.3f} m，P95 {p95:.3f}→"
        f"{p95_core:.3f} m、σ {sig_core:.3f} m；但核内最大偏离仍有 "
        f"{max_core:.3f} m：{static_end-t[0]:.1f}s 的关键帧按最近邻取到更晚的 fix"
        f"（末端关键帧的最近 fix 晚约 {lag_last:.1f}s），已进入运动。末端 "
        f"{trun[-1]-t[0]:.1f}s 取到更晚的 fix，偏离 "
        f"{qdev.max() if len(qdev) else 0:.2f} m。末端再提前 1 s"
        f"（{trun[0]-t[0]+13:.0f}–{trun[-1]-t[0]-2:.1f}s）后，P95 "
        f"{p95_core2:.3f} m、最大 {max_core2:.3f} m、σ {sig_core2:.3f} m。"
        f"因此 A3.1 的末端裁剪至少 2 s，或改用 A1 插值关联；只裁 1 s 仍会把"
        f"起步污染留在核内。当前 σ=0.3 m 在核内偏保守，但 116 s 的 "
        f"{rtk_fixed_net:.2f} m 慢漂移仍大于 0.3 m，单锚不能覆盖整个长静态段。")

    report = OUT / "baseline_c02_static.md"
    report.write_text("\n".join(lines) + "\n", encoding="utf-8")

    # per-keyframe CSV
    with (OUT / "baseline_c02_static.csv").open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["t_rel", "speed", "static", "lio_e", "lio_n", "lio_u",
                    "p0_e", "p0_n", "p0_u", "graph_e", "graph_n", "graph_u"])
        for k, i in enumerate(range(a, b + 1)):
            gi = np.where(gsel)[0]
            gx = gp[gi[k]] if k < len(gi) else np.full(3, np.nan)
            w.writerow([t[i] - t[0], speed[i], int(stat[i]),
                        p[i, 0], p[i, 1], p[i, 2],
                        p0[k, 0], p0[k, 1], p0[k, 2],
                        gx[0], gx[1], gx[2]])

    # figure
    fig, ax = plt.subplots(2, 2, figsize=(13, 10))
    ax = ax.ravel()
    ax[0].plot(prun[:, 0], prun[:, 1], color="0.6", label="LIO raw")
    ax[0].plot(gprun[:, 0], gprun[:, 1], color="C0", label="frozen graph")
    ax[0].scatter(rprun[:, 0], rprun[:, 1], s=8, color="C3", label="RTK fix")
    ax[0].set_title("Static window XY")
    ax[0].set_xlabel("E (m)")
    ax[0].set_ylabel("N (m)")
    ax[0].axis("equal")
    ax[0].legend(fontsize=8)

    ax[1].plot(trun - t[0], speed_run, color="C0")
    ax[1].axhline(args.thresh, color="C3", ls="--", label="threshold")
    ax[1].set_title("LIO speed")
    ax[1].set_xlabel("t (s)")
    ax[1].set_ylabel("m/s")
    ax[1].legend(fontsize=8)

    if len(qvec):
        qs = trun[[i - a for i in range(a, b + 1) if i in assign]]
        ax[2].plot(qs - t[0], qvec[:, 0], ".", ms=3, label="E")
        ax[2].plot(qs - t[0], qvec[:, 1], ".", ms=3, label="N")
        ax[2].plot(qs - t[0], qvec[:, 2], ".", ms=3, label="U")
        ax[2].axhline(anchor_med[0], color="C0", ls="--", lw=0.8)
        ax[2].axhline(anchor_med[1], color="C1", ls="--", lw=0.8)
        ax[2].axhline(anchor_med[2], color="C2", ls="--", lw=0.8)
        ax[2].set_title("Anchor samples q = p_rtk - R*l")
        ax[2].set_xlabel("t (s)")
        ax[2].set_ylabel("m")
        ax[2].legend(fontsize=8)

    ax[3].plot(trun - t[0], rel, color="C0", label="rotation from first")
    ax[3].set_title("LIO attitude drift")
    ax[3].set_xlabel("t (s)")
    ax[3].set_ylabel("deg")
    if len(win_t):
        axb = ax[3].twinx()
        axb.plot(win_t, win_dev, "o-", color="C3", ms=3,
                 label="10 s anchor offset")
        axb.set_ylabel("anchor offset (m)", color="C3")
    ax[3].legend(fontsize=8)
    fig.tight_layout()
    fig.savefig(FIG / "c02_static_overview.png", dpi=150)
    plt.close(fig)

    print(f"wrote {report}")
    print(f"wrote {OUT/'baseline_c02_static.csv'}")
    print(f"wrote {FIG/'c02_static_overview.png'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
