#include "static_anchor_validity.h"

#include <algorithm>
#include <cmath>
#include <iomanip>
#include <sstream>
#include <set>

namespace fast_livo
{
namespace
{

double median(std::vector<double> v)
{
  if (v.empty()) return 0.0;
  const size_t n = v.size();
  std::sort(v.begin(), v.end());
  if (n % 2 == 1) return v[n / 2];
  return 0.5 * (v[n / 2 - 1] + v[n / 2]);
}

// Same linear-interpolation convention as numpy.percentile (the baseline used
// numpy), so the C++ trace and the A3 baseline report are comparable.
double percentile(std::vector<double> v, double p)
{
  if (v.empty()) return 0.0;
  std::sort(v.begin(), v.end());
  if (v.size() == 1) return v[0];
  const double pos = (p / 100.0) * static_cast<double>(v.size() - 1);
  const size_t lo = static_cast<size_t>(std::floor(pos));
  const size_t hi = std::min(lo + 1, v.size() - 1);
  const double frac = pos - static_cast<double>(lo);
  return v[lo] + frac * (v[hi] - v[lo]);
}

// GnssQualityClass::GOOD is not an independent non-fixed class:
// classifyGnssQuality() emits GOOD only for carr_soln>=2 with good geometry,
// and FIXED for carr_soln>=2 otherwise. The union is the carrier-fixed family.
bool isCarrierFixed(GnssQualityClass c)
{
  return c == GnssQualityClass::FIXED || c == GnssQualityClass::GOOD;
}

// Displacement of a least-squares line fit over the trimmed fix-time span.
// This is a trend measure, not an endpoint difference: an isolated endpoint
// outlier is left to the max-deviation check, while a slow monotone drift is
// captured even when the per-epoch residuals stay small.
double slowDrift(const std::vector<const StaticAnchorSample *> &v)
{
  if (v.size() < 3) return 0.0;
  const double span = v.back()->fix_time - v.front()->fix_time;
  if (span <= 1e-9) return 0.0;

  const double n = static_cast<double>(v.size());
  double t_mean = 0.0;
  Eigen::Vector3d q_mean = Eigen::Vector3d::Zero();
  for (size_t i = 0; i < v.size(); ++i)
  {
    t_mean += v[i]->fix_time;
    q_mean += v[i]->q;
  }
  t_mean /= n;
  q_mean /= n;

  double denom = 0.0;
  Eigen::Vector3d num = Eigen::Vector3d::Zero();
  for (size_t i = 0; i < v.size(); ++i)
  {
    const double dt = v[i]->fix_time - t_mean;
    denom += dt * dt;
    num += dt * (v[i]->q - q_mean);
  }
  if (denom <= 1e-18) return 0.0;
  return (num / denom).norm() * span;
}

std::string fixed3(double x)
{
  std::ostringstream os;
  os << std::fixed << std::setprecision(3) << x;
  return os.str();
}

}  // namespace

const char *staticAnchorValidityStateName(StaticAnchorValidityState s)
{
  switch (s)
  {
    case StaticAnchorValidityState::VALID: return "STATIC_ANCHOR_VALID";
    case StaticAnchorValidityState::WEAK: return "STATIC_ANCHOR_WEAK";
    case StaticAnchorValidityState::UNAVAILABLE:
      return "STATIC_ANCHOR_UNAVAILABLE";
  }
  return "STATIC_ANCHOR_UNAVAILABLE";
}

const char *staticAnchorRejectReasonName(StaticAnchorRejectReason r)
{
  switch (r)
  {
    case StaticAnchorRejectReason::NONE: return "NONE";
    case StaticAnchorRejectReason::INSUFFICIENT_SAMPLES:
      return "INSUFFICIENT_SAMPLES";
    case StaticAnchorRejectReason::LOW_FIXED_RATIO:
      return "LOW_FIXED_RATIO";
    case StaticAnchorRejectReason::RTK_DISPLACEMENT_TOO_LARGE:
      return "RTK_DISPLACEMENT_TOO_LARGE";
    case StaticAnchorRejectReason::RTK_DISPERSION_TOO_LARGE:
      return "RTK_DISPERSION_TOO_LARGE";
    case StaticAnchorRejectReason::RTK_SLOW_DRIFT:
      return "RTK_SLOW_DRIFT";
    case StaticAnchorRejectReason::TRIMMED_WINDOW_TOO_SHORT:
      return "TRIMMED_WINDOW_TOO_SHORT";
    case StaticAnchorRejectReason::INVALID_CONFIGURATION: return "INVALID_CONFIGURATION";
    case StaticAnchorRejectReason::INVALID_SAMPLE: return "INVALID_SAMPLE";
    case StaticAnchorRejectReason::INVALID_STATISTICS: return "INVALID_STATISTICS";
  }
  return "NONE";
}

StaticAnchorValidityResult evaluateStaticAnchorValidity(
    const StaticAnchorValidityParams &params,
    int segment_id,
    double window_t0,
    double run_start,
    double run_end,
    const std::vector<StaticAnchorSample> &samples)
{
  StaticAnchorValidityResult out;
  out.segment_id = segment_id;
  const double config_values[] = {params.trim_start_sec, params.trim_end_sec,
      params.reference_onset_sec, params.fallback_end_trim_sec,
      params.min_fixed_ratio, params.max_rtk_net_displacement,
      params.max_rtk_p95, params.max_rtk_deviation, params.max_slow_drift};
  bool config_ok = std::isfinite(window_t0) && std::isfinite(run_start) &&
      std::isfinite(run_end) && params.min_samples >= 0 &&
      params.trim_start_sec >= 0 && params.trim_end_sec >= 0 &&
      params.fallback_end_trim_sec >= 0 && params.min_fixed_ratio >= 0 &&
      params.min_fixed_ratio <= 1 && params.max_rtk_net_displacement >= 0 &&
      params.max_rtk_p95 >= 0 && params.max_rtk_deviation >= 0 &&
      params.max_slow_drift >= 0;
  for (double v : config_values) config_ok = config_ok && std::isfinite(v);
  if (!config_ok) {
    out.reject_reason = StaticAnchorRejectReason::INVALID_CONFIGURATION;
    out.reason = "nonfinite_or_out_of_range_configuration";
    return out;
  }
  std::set<double> seen_fix_times;
  for (const auto &s : samples) {
    if (!std::isfinite(s.kf_time) || !std::isfinite(s.fix_time) ||
        !s.q.allFinite() || !s.lio_position.allFinite() ||
        !seen_fix_times.insert(s.fix_time).second) {
      out.reject_reason = StaticAnchorRejectReason::INVALID_SAMPLE;
      out.reason = "nonfinite_or_duplicate_candidate";
      return out;
    }
  }
  out.raw_start = run_start - window_t0;
  out.raw_end = run_end - window_t0;
  out.raw_sample_count = static_cast<int>(samples.size());
  out.reference_onset_available = params.reference_onset_sec >= 0.0;

  // ---- trim window -------------------------------------------------------
  const double start_t = run_start + params.trim_start_sec;
  double end_t = run_end;
  if (out.reference_onset_available)
  {
    const double onset_t = run_start + params.reference_onset_sec;
    end_t = std::min(run_end, onset_t - params.trim_end_sec);
    out.trim_basis = "reference_onset";
  }
  else
  {
    end_t = run_end - params.fallback_end_trim_sec;
    out.trim_basis = "fallback_end_trim";
  }
  out.trimmed_start = start_t - window_t0;
  out.trimmed_end = end_t - window_t0;

  if (!std::isfinite(start_t) || !std::isfinite(end_t) || end_t <= start_t)
  {
    out.trim_basis = "invalid_window";
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::TRIMMED_WINDOW_TOO_SHORT;
    out.reason = "window_start=" + fixed3(start_t - window_t0) +
                 ";end=" + fixed3(end_t - window_t0);
    return out;
  }

  // Select by the associated fix's own timestamp. The keyframe-time span is
  // reported separately; it is not the selection key.
  std::vector<const StaticAnchorSample *> selected;
  std::vector<int> selected_idx;  // A3.2: index into the caller's samples
  for (size_t i = 0; i < samples.size(); ++i)
  {
    const double t = samples[i].fix_time;
    if (t >= start_t && t <= end_t)
    {
      selected.push_back(&samples[i]);
      selected_idx.push_back(static_cast<int>(i));
    }
  }
  out.trimmed_sample_count = static_cast<int>(selected.size());
  if (selected.empty())
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::INSUFFICIENT_SAMPLES;
    out.reason = "trimmed_samples=0";
    return out;
  }

  double kf_min = selected.front()->kf_time, kf_max = kf_min;
  double fix_min = selected.front()->fix_time, fix_max = fix_min;
  for (size_t i = 0; i < selected.size(); ++i)
  {
    kf_min = std::min(kf_min, selected[i]->kf_time);
    kf_max = std::max(kf_max, selected[i]->kf_time);
    fix_min = std::min(fix_min, selected[i]->fix_time);
    fix_max = std::max(fix_max, selected[i]->fix_time);
  }
  out.trimmed_kf_start = kf_min - window_t0;
  out.trimmed_kf_end = kf_max - window_t0;
  out.trimmed_fix_start = fix_min - window_t0;
  out.trimmed_fix_end = fix_max - window_t0;

  // ---- quality composition (trimmed set) ---------------------------------
  std::vector<const StaticAnchorSample *> fixed;
  for (size_t i = 0; i < selected.size(); ++i)
  {
    switch (selected[i]->quality_class)
    {
      case GnssQualityClass::GOOD:
        ++out.good_count;
        ++out.fixed_count;
        fixed.push_back(selected[i]);
        out.estimation_indices.push_back(selected_idx[i]);
        break;
      case GnssQualityClass::FIXED:
        ++out.fixed_count;
        fixed.push_back(selected[i]);
        out.estimation_indices.push_back(selected_idx[i]);
        break;
      case GnssQualityClass::FLOAT:
        ++out.float_count;
        break;
      default:
        ++out.other_count;
        break;
    }
  }
  out.fixed_ratio = static_cast<double>(out.fixed_count) /
                    static_cast<double>(out.trimmed_sample_count);

  if (fixed.empty())
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::LOW_FIXED_RATIO;
    out.reason = "fixed_count=0";
    return out;
  }
  if (fixed.size() < 2)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::INSUFFICIENT_SAMPLES;
    out.reason = "fixed_count=1";
    return out;
  }

  // ---- statistics on carrier-fixed samples -------------------------------
  // Computed before the count/ratio checks so every rejected row still carries
  // the candidate-q diagnostics the reviewer needs (e.g. LOW_FIXED_RATIO).
  std::sort(fixed.begin(), fixed.end(),
            [](const StaticAnchorSample *a, const StaticAnchorSample *b) {
              return a->fix_time < b->fix_time;
            });

  std::vector<double> xs, ys, zs;
  xs.reserve(fixed.size());
  ys.reserve(fixed.size());
  zs.reserve(fixed.size());
  for (size_t i = 0; i < fixed.size(); ++i)
  {
    xs.push_back(fixed[i]->q.x());
    ys.push_back(fixed[i]->q.y());
    zs.push_back(fixed[i]->q.z());
  }
  const Eigen::Vector3d center(median(xs), median(ys), median(zs));

  std::vector<double> dev;
  dev.reserve(fixed.size());
  for (size_t i = 0; i < fixed.size(); ++i)
    dev.push_back((fixed[i]->q - center).norm());

  out.rtk_net_displacement = (fixed.back()->q - fixed.front()->q).norm();
  out.rtk_robust_p95 = percentile(dev, 95.0);
  out.rtk_max_deviation = *std::max_element(dev.begin(), dev.end());
  const double dev_med = median(dev);
  std::vector<double> abs_dev;
  abs_dev.reserve(dev.size());
  for (size_t i = 0; i < dev.size(); ++i)
    abs_dev.push_back(std::fabs(dev[i] - dev_med));
  out.rtk_robust_sigma = 1.4826 * median(abs_dev);
  out.rtk_slow_drift = slowDrift(fixed);

  // LIO net over the same trimmed samples, ordered by keyframe time. This is
  // diagnostic only; the gate never uses LIO as a static truth.
  std::vector<const StaticAnchorSample *> kf_order = selected;
  std::sort(kf_order.begin(), kf_order.end(),
            [](const StaticAnchorSample *a, const StaticAnchorSample *b) {
              return a->kf_time < b->kf_time;
            });
  out.lio_net_displacement =
      (kf_order.back()->lio_position - kf_order.front()->lio_position).norm();
  const double statistics[] = {out.rtk_net_displacement, out.rtk_robust_p95,
      out.rtk_max_deviation, out.rtk_robust_sigma, out.rtk_slow_drift,
      out.lio_net_displacement};
  for (double value : statistics) {
    if (!std::isfinite(value)) {
      out.reject_reason = StaticAnchorRejectReason::INVALID_STATISTICS;
      out.reason = "nonfinite_statistics";
      return out;
    }
  }

  if (params.min_samples > 0 && out.trimmed_sample_count < params.min_samples)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::INSUFFICIENT_SAMPLES;
    out.reason = "trimmed_samples=" + std::to_string(out.trimmed_sample_count) +
                 "<" + std::to_string(params.min_samples);
    return out;
  }
  if (params.min_fixed_ratio > 0.0 &&
      out.fixed_ratio < params.min_fixed_ratio)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::LOW_FIXED_RATIO;
    out.reason = "fixed_ratio=" + fixed3(out.fixed_ratio) + "<" +
                 fixed3(params.min_fixed_ratio);
    return out;
  }

  // ---- hard checks -------------------------------------------------------
  if (params.max_rtk_net_displacement > 0.0 &&
      out.rtk_net_displacement > params.max_rtk_net_displacement)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::RTK_DISPLACEMENT_TOO_LARGE;
    out.reason = "rtk_net=" + fixed3(out.rtk_net_displacement) + ">" +
                 fixed3(params.max_rtk_net_displacement);
    return out;
  }
  if (params.max_rtk_p95 > 0.0 && out.rtk_robust_p95 > params.max_rtk_p95)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::RTK_DISPERSION_TOO_LARGE;
    out.reason = "rtk_p95=" + fixed3(out.rtk_robust_p95) + ">" +
                 fixed3(params.max_rtk_p95);
    return out;
  }
  if (params.max_rtk_deviation > 0.0 &&
      out.rtk_max_deviation > params.max_rtk_deviation)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::RTK_DISPERSION_TOO_LARGE;
    out.reason = "rtk_max_deviation=" + fixed3(out.rtk_max_deviation) + ">" +
                 fixed3(params.max_rtk_deviation);
    return out;
  }
  if (params.max_slow_drift > 0.0 &&
      out.rtk_slow_drift > params.max_slow_drift)
  {
    out.state = StaticAnchorValidityState::UNAVAILABLE;
    out.reject_reason = StaticAnchorRejectReason::RTK_SLOW_DRIFT;
    out.reason = "rtk_slow_drift=" + fixed3(out.rtk_slow_drift) + ">" +
                 fixed3(params.max_slow_drift);
    return out;
  }

  // ---- certification completeness ---------------------------------------
  std::vector<std::string> missing;
  if (params.min_samples <= 0) missing.push_back("min_samples");
  if (params.min_fixed_ratio <= 0.0) missing.push_back("min_fixed_ratio");
  if (params.max_rtk_net_displacement <= 0.0)
    missing.push_back("max_rtk_net_displacement");
  if (params.max_rtk_p95 <= 0.0) missing.push_back("max_rtk_p95");
  if (params.max_rtk_deviation <= 0.0)
    missing.push_back("max_rtk_deviation");
  if (params.max_slow_drift <= 0.0) missing.push_back("max_slow_drift");
  out.thresholds_complete = missing.empty();

  std::string weak;
  if (!out.reference_onset_available)
    weak = "reference_onset_unavailable";
  if (!out.thresholds_complete)
  {
    if (!weak.empty()) weak += ";";
    weak += "thresholds_unset:";
    for (size_t i = 0; i < missing.size(); ++i)
    {
      if (i) weak += ";";
      weak += missing[i];
    }
  }

  if (!weak.empty())
  {
    out.state = StaticAnchorValidityState::WEAK;
    out.reject_reason = StaticAnchorRejectReason::NONE;
    out.reason = weak;
    return out;
  }

  out.state = StaticAnchorValidityState::VALID;
  out.reject_reason = StaticAnchorRejectReason::NONE;
  out.reason.clear();
  return out;
}

}  // namespace fast_livo
