# RtkTight：固定相位 + TDCP（2026-10-30）

## 1. 目标

把前端 `RtkTight` 从“浮点双差”升级为：

- **固定相位**：使用 `RtkDD.dd_phase_fixed` / `fix_valid` 的整数固定相位作为
  cm 级绝对距离观测（GREAT-MSF `.ins` 反算；原 MVP 已实现）；
- **TDCP**：相邻 DD 历元的载波相位时间差分，提供 mm 级**相对位移**约束，
  不依赖整数固定，直接约束沿轨/动态。

TDCP 是 FAST-LIVOG 的核心观测之一；固定相位是绝对基准，TDCP 是相对形状。

## 2. 实现

### 2.1 TDCP 观测

对同一 `sys/freq/ref/sat` 的相邻两历元：

```
y = (Φ_dd(t2) - Φ_dd(t1)) - (ρ_dd(t2,p2) - ρ_dd(t1,p1))
r = y
H = g_cur = u_ref(t2,p2) - u_sat(t2,p2)
```

注意：`y` 已经用了**前后两个实际后验位置**算 DD 几何差，所以残差就是 `y`，
雅可比只取**当前历元**的几何导数。第一版在 `y` 之后又减了一次
`g·(p2-p1)`，把几何差减了两遍，`tdcp_rms` 变成 3–4 m，鲁棒核把大部分行
零掉；修正后 `tdcp_rms=0.02–0.06 m`。

- 整数模糊度和共模大气在时间差分中消掉；
- `p1` 是上一历元的**后验**天线位置（固定锚点），`p2` 是当前状态；
- 当前历元 `slip/ref_change=1` 时跳过该对；
- 每历元至少 `tdcp_min_pairs=4` 对才更新；
- `dt` 在 `(0.2, tdcp_max_dt=2.0]` s 内。

### 2.2 更新方式

主 DD code/phase 更新得到 `dx1, P1` 后，TDCP 作为**第二次标量 ESIKF 更新**：

```
r_t = y                        (y 已含真实前/后位置几何差)
H_t = g_cur . d p_ant/dx       (g_cur = 当前历元 u_ref - u_sat，含杆臂/尺度)
S_t = H_t P1 H_t^T + R_t
K_t = P1 H_t^T S_t^-1
dx  = dx1 + K_t r_t
P   = (I-KH) P1 (I-KH)^T + K R K^T
```

- 上一历元后验作固定锚点；`tdcp_prev_sigma=0.05 m` 作为锚点不确定度地板
  （当前实现是常数，未投影上一历元协方差）；
- `R_t = 2σ_phase² + σ_prev²`；
- IGG3 逐行鲁棒 + 卡方整体门；
- TDCP 不影响浮点/固定模糊度状态。

### 2.3 配置

```yaml
rtk:
  fixed_phase_en: true          # 原有
  tdcp_en: true
  tdcp_sigma_scale: 1.0
  tdcp_prev_sigma: 0.05
  tdcp_min_pairs: 4
  tdcp_max_dt: 2.0
  tdcp_robust_en: true
  tdcp_robust_k0: 3.0
  tdcp_robust_k1: 6.0
```

日志 `[RTK] accept/reject` 新增 `tdcp=<rows> tdcp_rms=<m>`。

## 3. 首轮结果（c01，180 s）

| 臂 | full 3D | full 2D | steady 3D | steady 2D | movfit 2D | stat@movfit 2D |
|---|---:|---:|---:|---:|---:|---:|
| 固定相位基线（MVP，180 s） | 1.08–1.10 | 0.79–0.82 | 0.23–0.25 | 0.23–0.25 | — | — |
| 固定相位 + TDCP（修正后） | 1.122 | 0.851 | 0.242 | 0.240 | 0.822 | 1.143 |

- TDCP 在 67 次接受中 25 次 `tdcp>0`，`tdcp_rms=0.02–0.06 m`；
- 固定相位在 22 次接受中 `fixed>0`（把 `fixed_phase_max_code_rms` 从 3 m
  放宽到 5 m 后激活；c01 的码残差本身约 3 m，旧门限把固定相位挡掉了）；
- 180 s 的 full 2D 0.851、3D 1.122，与固定相位基线 0.79–0.82 / 1.08–1.10
  **基本持平，没有明显增益**；steady 0.24 不变；
- 之前一次 1.085/0.706 的运行是 TDCP 双计 bug + `fixed=0` + 有利 LIO 跑次的
  组合，不能作为 TDCP 的结果。

### 3.1 全量 607 s

| 臂 | full 3D | full 2D | steady 3D | steady 2D | movfit 2D | stat@movfit 2D |
|---|---:|---:|---:|---:|---:|---:|
| 固定相位基线（MVP，607 s） | 2.31 | 1.83–1.89 | 1.65 | 1.31 | — | — |
| 固定相位 + TDCP（修正后） | **2.229** | **1.598** | **1.633** | **0.895** | 1.659 | 1.697 |

- TDCP 在 209 次接受中 83 次生效；`tdcp_rms=0.02–0.06 m`；
- 固定相位 22 次生效（仍不稳定，见限制）；
- full 2D 改善 0.23–0.29 m，full 3D 改善 0.08 m；steady 2D 从 1.31 降到 0.895；
- 3D 仍由垂直主导（2.23），TDCP 是水平/沿轨杠杆，不是垂直杠杆。

## 4. 已知限制

1. **固定相位来源是 GREAT-MSF `.ins` 反算**，不是内部整数固定；横向受
   `.ins` 约 0.5 m 精度限制，且存在“用 GREAT-MSF 固定解生成观测、再声称优于它”
   的循环依赖。论文口径应把固定相位定位为“外部固定解辅助”，或改用 TDCP 为主。
2. **TDCP 锚点协方差是常数 0.05 m**，没有投影上一历元后验协方差；严格做法是
   `σ_prev² = g^T P_prev g`。当前版本在上一历元后验很准时偏保守。
3. **顺序更新**：TDCP 在主 DD 更新之后，忽略 DD/TDCP 的交叉相关；联合更新
   更严格，但顺序更新在 1 Hz 下近似成立。
4. **角度/杆臂**：TDCP 的 `H_att`/尺度项与 DD 行一致；`tdcp_prev_sigma` 未包含
   姿态/杆臂不确定度。
5. **c02**：P4 已证明 c02 的 LIO 有 ~8.6% 尺度/漂移，DD 紧组合只能追漂移；
   固定相位 + TDCP 在 c02 上预计仍受此限制，需先做尺度校正。

## 5. 下一步

1. c01 607 s 全量结果，确认 TDCP 的 full/steady 增益。
2. `sigma_prev` 用 `g^T P_prev g`，并把上一历元姿态/杆臂协方差纳入。
3. 固定相位做内部整数固定（LAMBDA/部分固定），去掉 GREAT-MSF `.ins` 循环依赖。
4. c02 先在 LIO 加尺度状态，再开固定相位/TDCP。
5. 与在线图 TDDD 做同输入 A/B：前端 TDCP 与图 TDDD 是否重复计数、谁更稳。
