#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Self-displacement of the estimator during REFERENCE-static segments (T2-0).

The wander census (改进方案 T2-0) needs the appearance rate of the static-plane
walk, which is bimodal across runs (measured: some runs stay at 0.007-0.013 m,
others walk 30 m/100 s). This tool measures, per run, how far the ESTIMATOR'S
OWN trajectory moves while the REFERENCE says stationary, and splits runs into
wandered / clean so the census can report the sampling ratio that decides
whether T2-1/T2-2 are worth building.

Static segments come from the reference itself (same detection as eval_unified
T0-1: median-filtered horizontal speed). Caveat recorded in the plan: the
output trajectory is post report-level-hold, so runs where the hold fully
masked the walk read as clean here too -- that is the intended measure (same
bimodal split as the plan), not a defect.

Usage:
  static_displacement.py --ref <ref.tum> <traj> [--thr M] [--static-speed V] [--min-dur S]
  static_displacement.py --ref <ref.tum> <traj1> <traj2> ... [--thr M]   (census table)

Wander criterion: net OR max excursion > --thr (default 0.5 m; the measured
modes differ by 3 orders of magnitude, the exact threshold is not critical).
Path length is REPORTED but NOT part of the criterion: at 20 Hz the pose jitter
accumulates to tens of metres over a 100 s static window even on clean runs
(measured: net 0.02 m with path 15 m), so it carries no wander signal.
"""
import sys
import os
import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eval_unified import load_tum, static_segments  # noqa: E402


def pair(t, rt):
    ir = np.array([int(np.argmin(np.abs(rt - x))) for x in t])
    ok = np.abs(rt[ir] - t) < 0.25
    return ir, ok


def segment_displacement(p, m):
    """Horizontal self-motion of paired samples inside one static segment."""
    q = p[m][:, :2]
    if len(q) < 10:
        return None
    net = float(np.linalg.norm(q[-1] - q[0]))
    exc = float(np.linalg.norm(q - q[0], axis=1).max())
    path = float(np.linalg.norm(np.diff(q, axis=0), axis=1).sum())
    return dict(n=len(q), net=net, exc=exc, path=path)


def analyse(traj, ref, thr, static_speed, min_dur):
    t, p = load_tum(traj)
    rt, rp = load_tum(ref)
    if len(t) < 20 or len(rt) < 20:
        raise SystemExit("!! not enough poses (%s traj / %s ref)" % (len(t), len(rt)))
    ir, ok = pair(t, rt)
    segs = static_segments(rt, rp, static_speed, 2, min_dur, 2.0)
    rows, worst = [], 0.0
    for a, b in segs:
        m = ok & (rt[ir] >= a) & (rt[ir] <= b)
        d = segment_displacement(p, m)
        if d is None:
            continue
        rows.append((a - rt[0], b - rt[0], d))
        worst = max(worst, d["net"], d["exc"])
    return rows, worst, len(segs)


def main():
    a = sys.argv[1:]
    thr, static_speed, min_dur = 0.5, 0.10, 5.0
    ref, paths = None, []
    i = 0
    while i < len(a):
        if a[i] == "--ref":
            ref = a[i + 1]; i += 2
        elif a[i] == "--thr":
            thr = float(a[i + 1]); i += 2
        elif a[i] == "--static-speed":
            static_speed = float(a[i + 1]); i += 2
        elif a[i] == "--min-dur":
            min_dur = float(a[i + 1]); i += 2
        else:
            paths.append(a[i]); i += 1
    if not ref or not paths:
        print(__doc__)
        return 1
    batch = len(paths) > 1

    if not batch:
        rows, worst, nseg = analyse(paths[0], ref, thr, static_speed, min_dur)
        print("== %s ==" % os.path.basename(paths[0]))
        if not rows:
            print("  no usable static segment (%d detected)" % nseg)
            return 0
        for a0, b0, d in rows:
            print("  seg [%6.1f-%6.1f s] n=%-5d net=%.4f m  max-exc=%.4f m  path=%.4f m  speed=%.4f m/s"
                  % (a0, b0, d["n"], d["net"], d["exc"], d["path"],
                     d["path"] / max(b0 - a0, 1e-9)))
        print("  WANDER: %s  (max metric %.4f m vs thr %.2f m)"
              % ("YES" if worst > thr else "NO", worst, thr))
        return 0

    # census table over many runs of one arm
    print("census: wander if net OR max-excursion > %.2f m in any reference-static segment "
          "(path is informational)" % thr)
    print("%-46s %8s %8s %8s  %s" % ("run", "net", "exc", "path", "WANDER"))
    nw = 0
    for tr in paths:
        try:
            rows, worst, _ = analyse(tr, ref, thr, static_speed, min_dur)
        except SystemExit as e:
            print("%-46s %s" % (os.path.basename(tr), e))
            continue
        w = worst > thr
        nw += int(w)
        if rows:
            d = max(rows, key=lambda r: max(r[2]["net"], r[2]["exc"]))[2]
            print("%-46s %8.4f %8.4f %8.4f  %s"
                  % (os.path.basename(tr), d["net"], d["exc"], d["path"], "YES" if w else "no"))
        else:
            print("%-46s %8s %8s %8s  (no static segment)" % (os.path.basename(tr), "-", "-", "-"))
    print("census result: %d/%d runs wandered (%.0f%%)"
          % (nw, len(paths), 100.0 * nw / max(len(paths), 1)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
