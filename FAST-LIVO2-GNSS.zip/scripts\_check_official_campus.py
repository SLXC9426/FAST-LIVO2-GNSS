#!/usr/bin/env python3
import rosbag
import numpy as np
import sensor_msgs.point_cloud2 as pc2

b = rosbag.Bag("/mnt/e/GREAT数据集/campus-01/campus-01.bag")
print("start:", b.get_start_time(), "end:", b.get_end_time())
info = b.get_type_and_topic_info()
for t, v in sorted(info.topics.items()):
    print(t, v.msg_type, v.message_count)
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    f = {x.name: x.datatype for x in msg.fields}
    pts = list(pc2.read_points(msg, field_names=("ring", "time"), skip_nans=True))
    a = np.array(pts[:4000], dtype=float)
    print("fields:", f, "stamp:", msg.header.stamp.to_sec())
    print("ring raw first5:", a[:5, 0].tolist())
    print("time: %.3f ~ %.3f" % (a[:, 1].min(), a[:, 1].max()))
    break
b.close()
