#pragma once
// P2-01 (EXP-P2-001): single decision point for the FORCED early-lock policy
// of the frontend ENU<->world heading alignment.
//
// History (LIVMapper.cpp tryAlignGnssYaw): with the slow-alignment state off,
// crossing gnss_align_force_dist (150 m) of GNSS span bypassed the stability
// requirement entirely. campus-02 locked that way at stable_count == 1 with a
// 1.416 m local fit residual, 43.804 deg away from the GNSS-implied heading
// (five-round audit, INDEPENDENT_AUDIT.json fit.c02), and the bogus yaw then
// entered the backend through yaw_override (global_pose_graph.cpp:689-695).
//
// The forced path stays (it still bounds the wait when the estimate never
// settles), but it now requires its own stability floor: `forced_min_stable`
// consecutive fits within gnss_align_yaw_tol_deg. This header is
// dependency-free so the truth table is unit-testable on its own
// (test/yaw_accept_policy_selftest.cpp).
#include <algorithm>

namespace yaw_accept
{

// Historical predicate, kept verbatim for equivalence checking:
//   forced = (!align_state_en) && (span_gnss >= force_dist)
inline bool forcedLockAllowedLegacy(int stable_count, double span_gnss,
                                    double force_dist, bool align_state_en)
{
  (void)stable_count;
  return !align_state_en && span_gnss >= force_dist;
}

// P2-01 forced policy: the legacy span rule plus a stability floor.
// `forced_min_stable <= 0` reduces to the legacy predicate exactly, so the
// C0 default (parameter gnss/align_forced_min_stable unset or 0) keeps the
// historical lock behavior bit-for-bit.
inline bool forcedLockAllowed(int stable_count, double span_gnss,
                              double force_dist, bool align_state_en,
                              int forced_min_stable)
{
  if (align_state_en) return false;          // slow state owns the lock (T1-4)
  if (span_gnss < force_dist) return false;  // not enough geometry yet
  return stable_count >= std::max(0, forced_min_stable);
}

// Full acceptance gate: converged (settle consecutive fits) OR forced.
// Mirrors `if (align_stable_count_ < gnss_align_settle && !forced) return false;`
inline bool lockAllowed(int stable_count, int settle, double span_gnss,
                        double force_dist, bool align_state_en,
                        int forced_min_stable)
{
  if (stable_count >= settle) return true;
  return forcedLockAllowed(stable_count, span_gnss, force_dist,
                           align_state_en, forced_min_stable);
}

} // namespace yaw_accept
