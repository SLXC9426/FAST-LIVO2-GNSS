import sys
import numpy as np

REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\campus01_reference.tum"
RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"


def load_tum(p):
    d = np.loadtxt(p)
    return d[:, 0], d[:, 1:4]


def interp(rt, rp, qt):
    return np.array([np.interp(qt, rt, rp[:, k]) for k in range(3)]).T


def umeyama(est, gt):
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg


def eval_seq(name):
    rt, rp = load_tum(REF)
    try:
        ft, fp = load_tum(f"{RES}\\{name}.txt")
    except Exception as ex:
        return None
    t0, t1 = max(rt[0], ft[0]), min(rt[-1], ft[-1])
    m = (rt >= t0) & (rt <= t1)
    if m.sum() < 10:
        return None
    p_f = interp(ft, fp, rt[m])
    p_g = rp[m]
    e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
    de = np.diff(p_f, axis=0)
    dg = np.diff(p_g, axis=0)
    rpe = np.linalg.norm(de - dg, axis=1)
    # also unaligned (only translation) for reference
    e_unal = np.linalg.norm(p_f - p_g - (p_f[0] - p_g[0]), axis=1)
    n = len(rt[m])
    return dict(
        name=name, n=n, t0=t0, t1=t1,
        ape_rmse=np.sqrt(np.mean(e ** 2)), ape_mean=np.mean(e), ape_max=np.max(e),
        rpe=np.sqrt(np.mean(rpe ** 2)), ape_unal=np.sqrt(np.mean(e_unal ** 2)),
    )


names = ["great_campus01_baseline", "great_campus01_occlusion", "great_campus01_dynamic",
         "great_campus01_graph", "great_campus01_improved"]
rows = [eval_seq(n) for n in names]
rows = [r for r in rows if r]
print(f"{'mode':<30}{'frames':>8}{'span_s':>8}{'APE_RMSE':>10}{'APE_mean':>10}{'APE_max':>10}{'RPE':>8}")
for r in rows:
    print(f"{r['name'].replace('great_campus01_',''):<30}{r['n']:>8}{r['t1']-r['t0']:>8.0f}"
          f"{r['ape_rmse']:>10.2f}{r['ape_mean']:>10.2f}{r['ape_max']:>10.2f}{r['rpe']:>8.2f}")
print("\n(all in meters; Umeyama similarity alignment like evo_ape -a)")
