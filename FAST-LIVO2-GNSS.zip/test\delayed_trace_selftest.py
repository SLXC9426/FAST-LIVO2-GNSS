import importlib.util,unittest
from pathlib import Path
p=Path(__file__).resolve().parents[1]/'scripts/eval/replay_sensor_bags.py'
s=importlib.util.spec_from_file_location('replay',p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
class DelayedReview(unittest.TestCase):
 def test_joined_invalid_quality_is_not_missing_record(self):
  rows=[dict(stamp_ns='1',reason='matched')]
  self.assertTrue(m.delayed_trace_matches_output(rows,[dict(stamp_ns=1,quality_valid=False)],{1:False}))
  self.assertFalse(m.delayed_trace_matches_output(rows,[dict(stamp_ns=1,quality_valid=True)],{1:False}))
  self.assertFalse(m.delayed_trace_matches_output(rows,[dict(stamp_ns=1,quality_valid=False)],{}))
 def test_timeout_and_valid_match(self):
  rows=[dict(stamp_ns='1',reason='matched'),dict(stamp_ns='2',reason='timeout')]
  fixes=[dict(stamp_ns=1,quality_valid=True),dict(stamp_ns=2,quality_valid=False)]
  self.assertTrue(m.delayed_trace_matches_output(rows,fixes,{1:True,2:True}))
  fixes[1]['quality_valid']=True
  self.assertFalse(m.delayed_trace_matches_output(rows,fixes,{1:True,2:True}))
 def test_duplicates_missing_epochs_and_unknown_reason(self):
  rows=[dict(stamp_ns='1',reason='matched')];fixes=[dict(stamp_ns=1,quality_valid=True)]
  for r,f in [(rows*2,fixes),(rows,fixes*2),(rows,[]),([dict(stamp_ns='1',reason='other')],fixes)]:
   self.assertFalse(m.delayed_trace_matches_output(r,f,{1:True}))
if __name__=='__main__':unittest.main(verbosity=2)
