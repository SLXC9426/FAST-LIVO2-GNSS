#!/usr/bin/env python3
"""Build the A1 2x2 attribution table from one campus' runs.

Arms:
  A0  = nearest placement, keyframe static rule (baseline)
  A1T = interpolated placement, keyframe static rule (time only)
  A1S = nearest placement, bracket static rule (static rule only)
  A1  = interpolated placement, bracket static rule (both)
"""
import argparse
import csv
import re
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import eval_ate as ev  # noqa: E402


def last_log_line(path: Path) -> str:
    line = ""
    if path.is_file():
        for l in path.open(errors="ignore"):
            if "ONLINE GRAPH" in l:
                line = l
    return line


def field(line: str, key: str) -> float:
    m = re.search(rf"\b{key}=([-\d.]+)", line)
    return float(m.group(1)) if m else float("nan")


def trace_counts(path: Path) -> dict:
    c = {}
    if path.is_file():
        with path.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                c[r["decision"]] = c.get(r["decision"], 0) + 1
    return c


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--runs", required=True)
    ap.add_argument("--ref", required=True)
    ap.add_argument("--prefix", required=True)
    ap.add_argument("--arms", default="A0,A1T,A1S,A1")
    ap.add_argument("--segments", default="")
    ap.add_argument("--out", default="")
    args = ap.parse_args()

    runs = Path(args.runs)
    tr, pr = ev.load_tum(Path(args.ref))
    segments = []
    if args.segments:
        for chunk in args.segments.split(","):
            a, b = chunk.split("-")
            segments.append((float(a), float(b)))

    lines = ["| arm | rtk factors | static skip | quality skip | assoc skip | "
             "no assignment | jump rejected | ATE RMSE | abs 2D | "
             "bias-removed 2D | RPE1 | RPE10 |",
             "|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|"]
    for arm in args.arms.split(","):
        tum = runs / f"{args.prefix}_{arm}.tum"
        if not tum.is_file():
            lines.append(f"| {arm} | missing | | | | | | | | | |")
            continue
        t, p = ev.load_tum(tum)
        r = ev.evaluate(arm, t, p, tr, pr, segments)
        log = last_log_line(runs / f"{args.prefix}_{arm}_node.log")
        tc = trace_counts(runs / f"{args.prefix}_{arm}_assoc.csv")
        if "ate" not in r:
            lines.append(f"| {arm} | {field(log,'rtk'):.0f} | ... not enough matches |")
            continue
        a = r["abs"]
        lines.append(
            f"| {arm} | {field(log,'rtk'):.0f} | "
            f"{field(log,'rtk_skip_static'):.0f} | "
            f"{field(log,'rtk_skip_quality'):.0f} | "
            f"{field(log,'rtk_skip_assoc'):.0f} | "
            f"{tc.get('no_assignment', 0)} | "
            f"{tc.get('jump_rejected', 0)} | "
            f"{r['ate']['rmse']:.3f} | {a['rmse2d']:.3f} | "
            f"{a['rmse2d_bc']:.3f} | {r['rpe1']['rmse']:.3f} | "
            f"{r['rpe10']['rmse']:.3f} |")

    text = "\n".join(lines) + "\n"
    print(text)
    if args.out:
        Path(args.out).write_text(text, encoding="utf-8")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
