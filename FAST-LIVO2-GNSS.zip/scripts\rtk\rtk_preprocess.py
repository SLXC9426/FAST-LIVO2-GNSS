#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""RTK double-difference preprocessing for the GREAT campus-01 sequence.

Phase 1 scope
-------------
* Parse RINEX 3 observation files (rover 1 Hz, base 1 Hz, GPS + BDS).
* Parse broadcast ephemerides (GPS + BDS) from the mixed RINEX 3 nav file.
* Compute satellite ECEF positions and clocks.
* Form double differences (code + carrier phase) with one reference satellite
  per constellation and frequency.
* Write a per-epoch/per-pair CSV for the ESIKF and a validation summary.

The script deliberately uses only GPS and BDS:
  GPS L1  C1C/L1C and L2 C2W/L2W
  BDS B2I C7I/L7I and B3I C6I/L6I
Galileo has no common signal code between this rover and base; GLONASS is
FDMA and deferred.

Time bases
----------
RINEX observation epochs are GPS time.  The bag, reference trajectory and the
C++ filter use UTC.  In 2020 GPS-UTC = 18 s, read from the RINEX header.
Double differences are time-tagged with UTC seconds (`t_unix`), while the
satellite orbits are evaluated in GPS time.

Output
------
`<out>.csv` columns:
  t_unix, t_gps_sow, sys, freq, ref_sat, sat,
  dd_code, dd_phase, los_e, los_n, los_u,
  elev_ref, elev_sat, sigma_code, sigma_phase,
  slip, gf_jump, doppler_res, snr
All code/phase values are metres (phase already multiplied by the wavelength).
"""
import argparse
import calendar
import csv
import math
import os
import re
from dataclasses import dataclass, field
from datetime import datetime, timedelta

import numpy as np

# ---------------------------------------------------------------------------
# constants
# ---------------------------------------------------------------------------
C_LIGHT = 299792458.0
OMEGA_E = 7.2921151467e-5
MU_GPS = 3.986005e14
MU_BDS = 3.986004418e14

FREQS = {
    # sys, band: (frequency Hz, code obs, phase obs, doppler obs)
    ("G", "L1"): (1575.42e6, "C1C", "L1C", "D1C"),
    ("G", "L2"): (1227.60e6, "C2W", "L2W", "D2W"),
    ("C", "B2I"): (1207.14e6, "C7I", "L7I", "D7I"),
    ("C", "B3I"): (1268.52e6, "C6I", "L6I", "D6I"),
}
WAVELEN = {k: C_LIGHT / v[0] for k, v in FREQS.items()}

# BDS GEO satellites use a different orbit model; exclude them in the first
# implementation.  C06..C29 are MEO/IGSO and use the GPS-like Kepler model.
BDS_GEO = {"C01", "C02", "C03", "C04", "C05"}

# GPS-UTC leap seconds (2020).  Read from the observation header; this is the
# fallback for files without the header field.
DEFAULT_LEAP = 18
GPS_EPOCH_UNIX = calendar.timegm(datetime(1980, 1, 6).timetuple())


def gps_sow(t_gps):
    """GPS seconds of week from a GPS-clock numeric time."""
    return (t_gps - GPS_EPOCH_UNIX) % 604800.0

FLOAT_RE = re.compile(r"[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?")


# ---------------------------------------------------------------------------
# containers
# ---------------------------------------------------------------------------
@dataclass
class ObsValue:
    value: float
    lli: int = 0
    snr: int = 0


@dataclass
class ObsEpoch:
    t_gps: float          # GPS clock seconds (naive GPS time as Unix-like number)
    t_unix: float         # UTC seconds
    sats: dict = field(default_factory=dict)   # sat -> {obs code: ObsValue}


@dataclass
class Eph:
    sys: str
    prn: str
    toe_gps: float        # GPS seconds
    toe_sow: float        # seconds of week in the satellite's own time system
    af0: float
    af1: float
    af2: float
    iode: float
    crs: float
    delta_n: float
    m0: float
    cuc: float
    e: float
    cus: float
    sqrt_a: float
    toe_field: float
    cic: float
    omega0: float
    cis: float
    i0: float
    crc: float
    omega: float
    omega_dot: float
    idot: float
    week: float
    sv_accuracy: float
    health: float
    tgd: float
    iodc: float


# ---------------------------------------------------------------------------
# RINEX observation parsing
# ---------------------------------------------------------------------------
def parse_obs_header(path):
    """Return (types_by_sys, leap_seconds)."""
    types = {}
    cur = None
    n = 0
    leap = DEFAULT_LEAP
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "END OF HEADER" in line:
                break
            if "LEAP SECONDS" in line:
                try:
                    leap = int(line[:6])
                except ValueError:
                    pass
            if "SYS / # / OBS TYPES" not in line:
                continue
            if line[0] != " ":
                sysname = line[0]
                try:
                    n = int(line[3:6])
                except ValueError:
                    continue
                cur = sysname
                types.setdefault(cur, [])
                parts = line[7:60].split()
            else:
                if cur is None:
                    continue
                parts = line[7:60].split()
            types[cur].extend(parts)
            if len(types[cur]) >= n:
                types[cur] = types[cur][:n]
                cur = None
    return types, leap


def _parse_float(field):
    m = FLOAT_RE.search(field)
    if not m:
        return float("nan")
    try:
        return float(m.group(0))
    except ValueError:
        return float("nan")


def _parse_epoch(line):
    """RINEX 3 observation epoch line -> datetime or None."""
    p = line[1:].split()
    if len(p) < 7:
        return None
    try:
        y, mo, d, h, mi = (int(p[i]) for i in range(5))
        sec = float(p[5])
        flag = int(p[6])
    except ValueError:
        return None
    if flag != 0:
        return None
    whole = int(math.floor(sec))
    frac = sec - whole
    if whole >= 60:
        whole = 59
        frac = 0.999999999
    return datetime(y, mo, d, h, mi, whole) + timedelta(seconds=frac)


def parse_obs_file(path, systems=("G", "C"), tlim_gps=None):
    """Parse a RINEX 3 observation file.

    tlim_gps: optional (start, end) numeric GPS seconds.  Epochs outside are
    parsed for structure but not stored.
    """
    types, leap = parse_obs_header(path)
    needed = {}
    for s in systems:
        wanted = set()
        for (fs, band), (freq, code, phase, dopp) in FREQS.items():
            if fs == s:
                wanted.update([code, phase, dopp])
        needed[s] = [t for t in types.get(s, []) if t in wanted]
    # Field position must be the index in the FULL observation-type list, not
    # in the filtered list: the line contains every type in header order.
    idx = {s: {t: types[s].index(t) for t in needed[s]} for s in needed}

    epochs = []
    with open(path, "r", errors="replace") as f:
        lines = f.readlines()
    i = 0
    nlines = len(lines)
    while i < nlines:
        line = lines[i]
        if not line.startswith(">"):
            i += 1
            continue
        dt = _parse_epoch(line)
        if dt is None:
            i += 1
            continue
        parts = line[1:].split()
        try:
            nsat = int(parts[7])
        except (IndexError, ValueError):
            i += 1
            continue
        t_gps = calendar.timegm(dt.timetuple()) + dt.microsecond * 1e-6
        t_unix = t_gps - leap
        keep = True
        if tlim_gps is not None:
            keep = (t_gps >= tlim_gps[0] - 1e-6) and (t_gps <= tlim_gps[1] + 1e-6)
        epoch = ObsEpoch(t_gps=t_gps, t_unix=t_unix)
        i += 1
        for _ in range(nsat):
            if i >= nlines:
                break
            sline = lines[i].rstrip("\n")
            i += 1
            if len(sline) < 3:
                continue
            sysname = sline[0]
            if sysname not in needed:
                continue
            sat = sline[:3]
            if not sat[1:3].isdigit():
                continue
            obs = {}
            for code, k in idx[sysname].items():
                field = sline[3 + 16 * k: 3 + 16 * (k + 1)]
                val = _parse_float(field)
                if not math.isfinite(val) or val == 0.0:
                    continue
                # LLI/SNR are unreliable in these files (5-decimal phase fields
                # consume the columns), so keep them only as diagnostics.
                obs[code] = ObsValue(val)
            if obs:
                epoch.sats[sat] = obs
        if keep and epoch.sats:
            epochs.append(epoch)
    return epochs, leap


# ---------------------------------------------------------------------------
# RINEX navigation parsing
# ---------------------------------------------------------------------------
def _nav_values(line, start, n=4, width=19):
    out = []
    for k in range(n):
        field = line[start + k * width: start + (k + 1) * width]
        out.append(_parse_float(field))
    return out


def parse_nav_file(path, systems=("G", "C")):
    """Return dict sat -> list[Eph] for GPS and BDS navigation records."""
    ephs = {}
    with open(path, "r", errors="replace") as f:
        lines = f.readlines()
    i = 0
    while i < len(lines) and "END OF HEADER" not in lines[i]:
        i += 1
    i += 1
    while i < len(lines):
        line = lines[i].rstrip("\n")
        if len(line) < 23 or line[0] not in systems or not line[1:3].isdigit():
            i += 1
            continue
        sysname = line[0]
        prn = line[:3]
        head = line[:23].split()
        try:
            dt = datetime(int(head[1]), int(head[2]), int(head[3]),
                          int(head[4]), int(head[5]), int(float(head[6])))
        except (IndexError, ValueError):
            i += 1
            continue
        v1 = _nav_values(line, 23, 3)
        block = []
        for k in range(7):
            i += 1
            if i >= len(lines):
                break
            block.append(lines[i].rstrip("\n"))
        if len(block) < 7:
            break
        vals = []
        for bl in block:
            vals.extend(_nav_values(bl, 4, 4))
        # vals layout: IODE, Crs, delta_n, M0, Cuc, e, Cus, sqrtA, Toe, Cic,
        # Omega0, Cis, i0, Crc, omega, OmegaDot, IDOT, codes, week, L2P,
        # SV accuracy, health, TGD, IODC, transmission time, fit interval
        if len(vals) < 24:
            i += 1
            continue
        # GPS: nav epoch is GPS time.  BDS: nav epoch is BDT = GPS - 14 s.
        t_gps = calendar.timegm(dt.timetuple()) + (14.0 if sysname == "C" else 0.0)
        # seconds of week in the satellite's own system (Sunday=0)
        dow = (dt.weekday() + 1) % 7
        toe_sow = dow * 86400.0 + dt.hour * 3600.0 + dt.minute * 60.0 + dt.second
        eph = Eph(
            sys=sysname, prn=prn, toe_gps=t_gps, toe_sow=toe_sow,
            af0=v1[0], af1=v1[1], af2=v1[2],
            iode=vals[0], crs=vals[1], delta_n=vals[2], m0=vals[3],
            cuc=vals[4], e=vals[5], cus=vals[6], sqrt_a=vals[7],
            toe_field=vals[8], cic=vals[9], omega0=vals[10], cis=vals[11],
            i0=vals[12], crc=vals[13], omega=vals[14], omega_dot=vals[15],
            idot=vals[16], week=vals[18], sv_accuracy=vals[20],
            health=vals[21], tgd=vals[22], iodc=vals[23],
        )
        ephs.setdefault(prn, []).append(eph)
        i += 1
    for prn in ephs:
        ephs[prn].sort(key=lambda e: e.toe_gps)
    return ephs


def select_eph(ephs, sat, t_gps, max_age=7200.0):
    arr = ephs.get(sat)
    if not arr:
        return None
    best = min(arr, key=lambda e: abs(e.toe_gps - t_gps))
    if abs(best.toe_gps - t_gps) > max_age:
        return None
    return best


# ---------------------------------------------------------------------------
# satellite orbit
# ---------------------------------------------------------------------------
def sat_pos_clock(eph, t_gps):
    """Broadcast GPS/BDS (MEO/IGSO) satellite position and clock at t_gps."""
    tk = t_gps - eph.toe_gps
    if tk > 302400.0:
        tk -= 604800.0
    elif tk < -302400.0:
        tk += 604800.0
    mu = MU_BDS if eph.sys == "C" else MU_GPS
    A = eph.sqrt_a * eph.sqrt_a
    n0 = math.sqrt(mu / (A * A * A))
    n = n0 + eph.delta_n
    M = eph.m0 + n * tk
    E = M
    for _ in range(12):
        E_new = M + eph.e * math.sin(E)
        if abs(E_new - E) < 1e-14:
            E = E_new
            break
        E = E_new
    sinE = math.sin(E)
    cosE = math.cos(E)
    v = math.atan2(math.sqrt(max(0.0, 1.0 - eph.e * eph.e)) * sinE, cosE - eph.e)
    phi = v + eph.omega
    two_phi = 2.0 * phi
    du = eph.cus * math.sin(two_phi) + eph.cuc * math.cos(two_phi)
    dr = eph.crs * math.sin(two_phi) + eph.crc * math.cos(two_phi)
    di = eph.cis * math.sin(two_phi) + eph.cic * math.cos(two_phi)
    u = phi + du
    r = A * (1.0 - eph.e * cosE) + dr
    inc = eph.i0 + di + eph.idot * tk
    xp = r * math.cos(u)
    yp = r * math.sin(u)
    Omega = eph.omega0 + (eph.omega_dot - OMEGA_E) * tk - OMEGA_E * eph.toe_sow
    cosO, sinO = math.cos(Omega), math.sin(Omega)
    cosi, sini = math.cos(inc), math.sin(inc)
    X = xp * cosO - yp * cosi * sinO
    Y = xp * sinO + yp * cosi * cosO
    Z = yp * sini
    # relativistic clock term (metres -> seconds); satellite clock is common
    # in DD, but this is needed for the single-difference diagnostics.
    dt_sat = (eph.af0 + eph.af1 * tk + eph.af2 * tk * tk
              - 2.0 * math.sqrt(mu * A) * eph.e * sinE / (C_LIGHT * C_LIGHT))
    return np.array([X, Y, Z]), dt_sat


# ---------------------------------------------------------------------------
# geodesy
# ---------------------------------------------------------------------------
WGS84_A = 6378137.0
WGS84_F = 1.0 / 298.257223563
WGS84_E2 = WGS84_F * (2.0 - WGS84_F)


def ecef_to_geodetic(xyz):
    x, y, z = xyz
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1.0 - WGS84_E2))
    for _ in range(8):
        N = WGS84_A / math.sqrt(1.0 - WGS84_E2 * math.sin(lat) ** 2)
        alt = p / math.cos(lat) - N
        lat = math.atan2(z, p * (1.0 - WGS84_E2 * N / (N + alt)))
    N = WGS84_A / math.sqrt(1.0 - WGS84_E2 * math.sin(lat) ** 2)
    alt = p / math.cos(lat) - N
    return lat, lon, alt


def enu_matrix(lat, lon):
    sl, cl = math.sin(lat), math.cos(lat)
    so, co = math.sin(lon), math.cos(lon)
    return np.array([
        [-so, co, 0.0],
        [-sl * co, -sl * so, cl],
        [cl * co, cl * so, sl],
    ])


def ecef_to_enu(xyz, ref_xyz, ref_lat, ref_lon):
    return enu_matrix(ref_lat, ref_lon) @ (np.asarray(xyz) - np.asarray(ref_xyz))


def los_enu(sat_xyz, rec_xyz, rec_lat, rec_lon):
    d = np.asarray(sat_xyz) - np.asarray(rec_xyz)
    r = np.linalg.norm(d)
    if r < 1.0:
        return None, 0.0
    e = enu_matrix(rec_lat, rec_lon) @ (d / r)
    return e, r


# ---------------------------------------------------------------------------
# diagnostics
# ---------------------------------------------------------------------------
def closest_epoch(epochs, t_gps):
    if not epochs:
        return None
    return min(epochs, key=lambda e: abs(e.t_gps - t_gps))


def load_flt_pos(path, sow):
    """Return the ECEF position in a GREAT-PVT .flt file at the given GPS sow."""
    best = None
    with open(path, "r", errors="replace") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            p = line.split()
            try:
                ts = float(p[0])
            except (ValueError, IndexError):
                continue
            if best is None or abs(ts - sow) < abs(best[0] - sow):
                best = (ts, np.array([float(p[1]), float(p[2]), float(p[3])]))
    if best is None:
        raise RuntimeError(f"no epoch in {path}")
    return best[0], best[1]


def test_dd(rover_path, base_path, nav_path, flt_path, t_gps_str):
    """Check double-difference code/phase residuals using the GREAT-PVT solution.

    The .flt solution supplies a rover ECEF close to the truth, so the DD
    geometric range can be compared directly with the DD observations.  This is
    the strongest orbit/observation check before the C++ integration.
    """
    dt = datetime.strptime(t_gps_str, "%Y-%m-%d %H:%M:%S")
    t0 = calendar.timegm(dt.timetuple())
    tlim = (t0 - 2, t0 + 2)
    rv, leap = parse_obs_file(rover_path, ("G", "C"), tlim)
    bb, _ = parse_obs_file(base_path, ("G", "C"), tlim)
    rover = closest_epoch(rv, t0)
    base = closest_epoch(bb, t0)
    if rover is None or base is None:
        print("no epoch")
        return
    print(f"rover epoch GPS {rover.t_gps:.0f} UTC {rover.t_unix:.0f}; "
          f"base epoch GPS {base.t_gps:.0f} UTC {base.t_unix:.0f}")

    sow = gps_sow(rover.t_gps)
    ts, rover_ecef = load_flt_pos(flt_path, sow)
    print(f"flt epoch sow={ts:.1f}, rover ECEF={rover_ecef}")
    base_ecef = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
    lat, lon, alt = ecef_to_geodetic(base_ecef)
    nav = parse_nav_file(nav_path, ("G", "C"))

    for sysname in ("G", "C"):
        for band in [b for (s, b) in FREQS if s == sysname]:
            freq, code, phase, dopp = FREQS[(sysname, band)]
            wl = WAVELEN[(sysname, band)]
            sats = []
            for sat in sorted(set(rover.sats) & set(base.sats)):
                if not sat.startswith(sysname) or sat in BDS_GEO:
                    continue
                ro = rover.sats[sat]
                bo = base.sats[sat]
                if not all(k in ro for k in (code, phase)) or not all(k in bo for k in (code, phase)):
                    continue
                eph = select_eph(nav, sat, base.t_gps)
                if eph is None:
                    continue
                pos, dts = sat_pos_clock(eph, base.t_gps)
                elos, rho_b = los_enu(pos, base_ecef, lat, lon)
                if elos is None:
                    continue
                elev = math.degrees(math.asin(max(-1.0, min(1.0, elos[2]))))
                if elev < 10.0:
                    continue
                rho_r = np.linalg.norm(pos - rover_ecef)
                sats.append((sat, ro, bo, pos, rho_b, rho_r, elev))
            if len(sats) < 3:
                print(f"\n{sysname} {band}: only {len(sats)} usable sats")
                continue
            ref = max(sats, key=lambda x: x[6])
            print(f"\n{sysname} {band}: ref={ref[0]} elev={ref[6]:.1f}, "
                  f"{len(sats)} sats")
            # Single-difference diagnostics: sd_res should be the common
            # receiver-clock difference plus (small) atmospheric/orbit terms.
            for sat, ro, bo, pos, rho_b, rho_r, elev in sats:
                sd = ro[code].value - bo[code].value - (rho_r - rho_b)
                print(f"  {sat} el={elev:5.1f}: sd_res={sd:14.3f} "
                      f"(code_r={ro[code].value:.1f} code_b={bo[code].value:.1f} "
                      f"rho_r-rho_b={rho_r-rho_b:.1f})")
            code_res = []
            for sat, ro, bo, pos, rho_b, rho_r, elev in sats:
                if sat == ref[0]:
                    continue
                ddc = (ro[code].value - bo[code].value) - (ref[1][code].value - ref[2][code].value)
                ddp = (ro[phase].value * wl - bo[phase].value * wl) - \
                      (ref[1][phase].value * wl - ref[2][phase].value * wl)
                ddg = (rho_r - rho_b) - (ref[5] - ref[4])
                rc = ddc - ddg
                rp = ddp - ddg
                code_res.append(rc)
                print(f"  {sat} el={elev:5.1f}: dd_code={ddc:14.3f} "
                      f"dd_geom={ddg:14.3f} code_res={rc:8.3f} "
                      f"phase_amb={rp:12.3f}")
            if code_res:
                print(f"  code residual RMS={np.sqrt(np.mean(np.square(code_res))):.3f} m")
    return


def build_dd_rows(rover_epochs, base_epochs, nav, base_ecef, min_elev=10.0):
    """Form double-difference rows for every epoch / constellation / frequency."""
    base_by_t = {round(e.t_gps, 3): e for e in base_epochs}
    lat, lon, alt = ecef_to_geodetic(base_ecef)
    rows = []
    prev_gf = {}          # (sys, sat) -> last geometry-free phase (m)
    prev_phase = {}       # (sys, sat, band) -> (t, phase_m, doppler_hz)
    prev_ref = {}         # (sys, band) -> ref sat
    prev_seen = {}        # (sys, sat) -> last t_gps
    for ep in rover_epochs:
        bep = base_by_t.get(round(ep.t_gps, 3))
        if bep is None:
            continue
        for sysname in ("G", "C"):
            for band in [b for (s, b) in FREQS if s == sysname]:
                freq, code, phase, dopp = FREQS[(sysname, band)]
                wl = WAVELEN[(sysname, band)]
                cand = []
                for sat in sorted(set(ep.sats) & set(bep.sats)):
                    if not sat.startswith(sysname) or sat in BDS_GEO:
                        continue
                    ro, bo = ep.sats[sat], bep.sats[sat]
                    if code not in ro or phase not in ro or code not in bo or phase not in bo:
                        continue
                    eph = select_eph(nav, sat, ep.t_gps)
                    if eph is None:
                        continue
                    pos, _ = sat_pos_clock(eph, ep.t_gps)
                    elos, rho_b = los_enu(pos, base_ecef, lat, lon)
                    if elos is None:
                        continue
                    elev = math.degrees(math.asin(max(-1.0, min(1.0, elos[2]))))
                    if elev < min_elev:
                        continue
                    cand.append((sat, ro, bo, pos, rho_b, elev))
                if len(cand) < 3:
                    continue
                # Reference satellite with hysteresis: keep the previous ref if
                # it is still valid and not much lower than the best.
                best = max(cand, key=lambda x: x[5])
                key = (sysname, band)
                ref = best
                old = prev_ref.get(key)
                if old is not None:
                    for c in cand:
                        if c[0] == old and c[5] >= best[5] - 5.0:
                            ref = c
                            break
                ref_change = 1 if (old is not None and ref[0] != old) else 0
                prev_ref[key] = ref[0]

                # Geometry-free cycle-slip state for this satellite.
                gf_now = None
                if sysname == "G":
                    if "L1C" in ep.sats.get(ref[0], {}) and "L2W" in ep.sats.get(ref[0], {}):
                        pass
                    l1 = ep.sats.get(ref[0], {}).get("L1C")
                    l2 = ep.sats.get(ref[0], {}).get("L2W")
                    if l1 and l2:
                        gf_now = l1.value * WAVELEN[("G", "L1")] - l2.value * WAVELEN[("G", "L2")]
                # (the per-satellite GF is computed inside the pair loop below)

                for sat, ro, bo, pos, rho_b, elev in cand:
                    if sat == ref[0]:
                        continue
                    ddc = (ro[code].value - bo[code].value) - \
                          (ref[1][code].value - ref[2][code].value)
                    ddp = (ro[phase].value * wl - bo[phase].value * wl) - \
                          (ref[1][phase].value * wl - ref[2][phase].value * wl)

                    # per-satellite geometry-free slip indicator
                    slip = 0
                    gf_jump = float("nan")
                    if sysname == "G":
                        l1, l2 = ro.get("L1C"), ro.get("L2W")
                        if l1 and l2:
                            gf = l1.value * WAVELEN[("G", "L1")] - l2.value * WAVELEN[("G", "L2")]
                            old_gf = prev_gf.get((sysname, sat))
                            if old_gf is not None:
                                gf_jump = gf - old_gf
                                if abs(gf_jump) > 0.05:
                                    slip = 1
                            prev_gf[(sysname, sat)] = gf
                    else:
                        l7, l6 = ro.get("L7I"), ro.get("L6I")
                        if l7 and l6:
                            gf = l7.value * WAVELEN[("C", "B2I")] - l6.value * WAVELEN[("C", "B3I")]
                            old_gf = prev_gf.get((sysname, sat))
                            if old_gf is not None:
                                gf_jump = gf - old_gf
                                if abs(gf_jump) > 0.05:
                                    slip = 1
                            prev_gf[(sysname, sat)] = gf

                    # Doppler/phase-rate consistency (one frequency is enough).
                    doppler_res = float("nan")
                    if dopp in ro:
                        cur = (ep.t_gps, ro[phase].value * wl, ro[dopp].value)
                        old = prev_phase.get((sysname, sat, band))
                        if old is not None:
                            dtp = cur[0] - old[0]
                            if dtp > 0.0:
                                pred = 0.5 * (cur[2] + old[2]) * dtp * wl
                                # RINEX receiver Doppler is positive for a
                                # receding satellite, so d(phase)/dt = -D.
                                doppler_res = (cur[1] - old[1]) + pred
                                if abs(doppler_res) > 0.10:
                                    slip = 1
                        prev_phase[(sysname, sat, band)] = cur

                    # A satellite that just reappeared is a new ambiguity.
                    last = prev_seen.get((sysname, sat))
                    if last is not None and ep.t_gps - last > 1.5:
                        slip = 1
                    prev_seen[(sysname, sat)] = ep.t_gps
                    if ref_change:
                        slip = 1

                    sin_el = max(math.sin(math.radians(max(elev, 10.0))), 0.1)
                    sigma_code = 2.0 * max(0.3 / sin_el, 0.3)
                    sigma_phase = 0.015
                    rows.append({
                        "t_unix": ep.t_unix, "t_gps": ep.t_gps,
                        "sys": sysname, "freq": band,
                        "ref_sat": ref[0], "sat": sat,
                        "dd_code": ddc, "dd_phase": ddp,
                        "sat_x": pos[0], "sat_y": pos[1], "sat_z": pos[2],
                        "ref_x": ref[3][0], "ref_y": ref[3][1], "ref_z": ref[3][2],
                        "elev_sat": elev, "elev_ref": ref[5],
                        "sigma_code": sigma_code, "sigma_phase": sigma_phase,
                        "slip": slip, "ref_change": ref_change,
                        "gf_jump": gf_jump, "doppler_res": doppler_res,
                    })
    return rows


def write_dd_csv(rows, path):
    cols = ["t_unix", "t_gps", "sys", "freq", "ref_sat", "sat",
            "dd_code", "dd_phase", "sat_x", "sat_y", "sat_z",
            "ref_x", "ref_y", "ref_z", "elev_sat", "elev_ref",
            "sigma_code", "sigma_phase", "slip", "ref_change",
            "gf_jump", "doppler_res"]
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in cols})
    print(f"wrote {path} ({len(rows)} rows)")


def _dd_geom(row, rover_ecef, base_ecef):
    sat = np.array([row["sat_x"], row["sat_y"], row["sat_z"]])
    ref = np.array([row["ref_x"], row["ref_y"], row["ref_z"]])
    rr_s = np.linalg.norm(sat - rover_ecef)
    rr_r = np.linalg.norm(ref - rover_ecef)
    rb_s = np.linalg.norm(sat - base_ecef)
    rb_r = np.linalg.norm(ref - base_ecef)
    return (rr_s - rb_s) - (rr_r - rb_r)


def _dd_jac(row, rover_ecef):
    sat = np.array([row["sat_x"], row["sat_y"], row["sat_z"]])
    ref = np.array([row["ref_x"], row["ref_y"], row["ref_z"]])
    us = (sat - rover_ecef) / max(np.linalg.norm(sat - rover_ecef), 1e-6)
    ur = (ref - rover_ecef) / max(np.linalg.norm(ref - rover_ecef), 1e-6)
    # d(dd_geom)/d(rover) = (rover-ref)/|...| - (rover-sat)/|...| = ur - us
    return ur - us


def solve_code_positions(rows, base_ecef):
    """Per-epoch code-only DD least squares (3 unknowns)."""
    by_t = {}
    for r in rows:
        by_t.setdefault(r["t_gps"], []).append(r)
    out = {}
    for t, rr in sorted(by_t.items()):
        x = np.array(base_ecef, dtype=float)
        for _ in range(20):
            H, b, w = [], [], []
            for r in rr:
                g = _dd_geom(r, x, base_ecef)
                res = r["dd_code"] - g
                H.append(_dd_jac(r, x))
                b.append(res)
                w.append(1.0 / max(r["sigma_code"], 0.2) ** 2)
            H = np.array(H); b = np.array(b); w = np.array(w)
            A = (H * w[:, None]).T @ H
            rhs = (H * w[:, None]).T @ b
            try:
                dx = np.linalg.solve(A + np.eye(3) * 1e-6, rhs)
            except np.linalg.LinAlgError:
                break
            # simple line search on the weighted cost
            cost0 = float(np.sum(w * b * b))

            def cost(xx):
                bb = np.array([r["dd_code"] - _dd_geom(r, xx, base_ecef) for r in rr])
                return float(np.sum(w * bb * bb))
            step = 1.0
            for _ls in range(10):
                xn = x + step * dx
                if cost(xn) <= cost0 or step < 1e-3:
                    x = xn
                    break
                step *= 0.5
            if np.linalg.norm(step * dx) < 1e-4:
                break
        out[t] = x
    return out


def solve_static_float(rows, base_ecef, t0, t1, flt_path):
    """Static-window float RTK: 3 position + one ambiguity per DD pair."""
    sel = [r for r in rows if t0 <= r["t_gps"] <= t1]
    if len(sel) < 20:
        raise RuntimeError(f"static window has only {len(sel)} rows")
    clean = [r for r in sel if r["slip"] == 0]
    if len(clean) >= 20:
        sel = clean
    # Fix one reference satellite per constellation/frequency for the window.
    refs = {}
    for key in sorted(set((r["sys"], r["freq"]) for r in sel)):
        counts = {}
        for r in sel:
            if (r["sys"], r["freq"]) == key:
                counts[r["ref_sat"]] = counts.get(r["ref_sat"], 0) + 1
        refs[key] = max(counts, key=counts.get)
    sel = [r for r in sel if r["ref_sat"] == refs[(r["sys"], r["freq"])]]
    pairs = sorted(set((r["sys"], r["freq"], r["sat"]) for r in sel))
    amb_idx = {p: i for i, p in enumerate(pairs)}
    n_amb = len(pairs)
    print(f"static float: {len(sel)} rows, {n_amb} ambiguities, refs={refs}")

    # Initial position from code-only solutions inside the window.
    code_pos = solve_code_positions(sel, base_ecef)
    x = np.median(np.array(list(code_pos.values())), axis=0)
    amb = np.zeros(n_amb)
    for p, i in amb_idx.items():
        vals = [r["dd_phase"] - _dd_geom(r, x, base_ecef)
                for r in sel if (r["sys"], r["freq"], r["sat"]) == p]
        amb[i] = np.median(vals)
    print(f"initial position (code median): {x}")

    for it in range(12):
        n = 3 + n_amb
        A = np.zeros((n, n))
        bvec = np.zeros(n)
        for r in sel:
            g = _dd_geom(r, x, base_ecef)
            j = _dd_jac(r, x)
            idx = amb_idx[(r["sys"], r["freq"], r["sat"])]
            # code row
            res = r["dd_code"] - g
            w = 1.0 / max(r["sigma_code"], 0.2) ** 2
            h = np.zeros(n); h[:3] = j
            A += w * np.outer(h, h); bvec += w * h * res
            # phase row
            res = r["dd_phase"] - g - amb[idx]
            w = 1.0 / max(r["sigma_phase"], 1e-3) ** 2
            h = np.zeros(n); h[:3] = j; h[3 + idx] = 1.0
            A += w * np.outer(h, h); bvec += w * h * res
        try:
            dx = np.linalg.solve(A + np.eye(n) * 1e-8, bvec)
        except np.linalg.LinAlgError:
            print("normal equations singular")
            break
        x += dx[:3]
        amb += dx[3:]
        step = np.linalg.norm(dx[:3])
        print(f"  iter {it:2d}: |dx_pos|={step:.4f} m")
        if step < 1e-4:
            break

    # Residuals after the fit.
    rc, rp = [], []
    for r in sel:
        g = _dd_geom(r, x, base_ecef)
        idx = amb_idx[(r["sys"], r["freq"], r["sat"])]
        rc.append(r["dd_code"] - g)
        rp.append(r["dd_phase"] - g - amb[idx])
    rc = np.array(rc); rp = np.array(rp)
    print(f"static float residuals: code RMS={np.sqrt(np.mean(rc**2)):.3f} m, "
          f"phase RMS={np.sqrt(np.mean(rp**2)):.3f} m")

    # Compare with GREAT-PVT at the static window centre.
    t_mid = 0.5 * (t0 + t1)
    sow = gps_sow(t_mid)
    ts, flt_ecef = load_flt_pos(flt_path, sow)
    lat, lon, alt = ecef_to_geodetic(base_ecef)
    enu_x = ecef_to_enu(x, base_ecef, lat, lon)
    enu_f = ecef_to_enu(flt_ecef, base_ecef, lat, lon)
    d = enu_x - enu_f
    print(f"static float vs .flt (sow={ts:.1f}): dE={d[0]:+.3f} dN={d[1]:+.3f} "
          f"dU={d[2]:+.3f} |hor|={np.linalg.norm(d[:2]):.3f} |3d|={np.linalg.norm(d):.3f} m")
    return {
        "n": len(sel), "n_amb": n_amb,
        "code_rms": float(np.sqrt(np.mean(rc**2))),
        "phase_rms": float(np.sqrt(np.mean(rp**2))),
        "dE": float(d[0]), "dN": float(d[1]), "dU": float(d[2]),
        "hor": float(np.linalg.norm(d[:2])), "d3": float(np.linalg.norm(d)),
        "flt_sow": float(ts),
        "rover_ecef": [float(v) for v in x],
        "flt_ecef": [float(v) for v in flt_ecef],
    }


def load_flt_epochs(path):
    """Return [(sow, ECEF, status), ...] from a GREAT-PVT .flt file."""
    out = []
    with open(path, "r", errors="replace") as f:
        for line in f:
            if line.startswith("#") or not line.strip():
                continue
            p = line.split()
            if len(p) < 17:
                continue
            try:
                out.append((float(p[0]),
                            np.array([float(p[1]), float(p[2]), float(p[3])]),
                            p[16]))
            except (ValueError, IndexError):
                continue
    return out


def validate_with_flt(rows, flt_path, base_ecef, fixed_only=True):
    """Trajectory-level DD validation using the GREAT-PVT 1/30 s positions."""
    flt = load_flt_epochs(flt_path)
    if fixed_only:
        fixed = [x for x in flt if x[2] == "Fixed"]
        if len(fixed) >= 5:
            flt = fixed
    by_t = {}
    for r in rows:
        by_t.setdefault(round(r["t_gps"], 3), []).append(r)
    epochs = []
    for t, rr in sorted(by_t.items()):
        sow = gps_sow(t)
        fs, fpos, status = min(flt, key=lambda x: abs(x[0] - sow))
        # .flt is 30 s sampled; only compare exact epochs, never a 1 Hz epoch
        # against a position 0.5-1 s away (the rover moves ~10 m/s).
        if abs(fs - sow) > 0.05:
            continue
        epochs.append((t, rr, fpos, fs))

    # Raw phase residual per pair (the ambiguity is a constant).  A bad .flt
    # fix produces a large common jump at one epoch; reject such epochs with a
    # per-pair median/MAD test before computing the metrics.
    pair_vals = {}
    code_by_epoch = {}
    for ei, (t, rr, fpos, fs) in enumerate(epochs):
        for r in rr:
            key = (r["sys"], r["freq"], r["sat"], r["ref_sat"])
            g = _dd_geom(r, fpos, base_ecef)
            pair_vals.setdefault(key, []).append((ei, r["dd_phase"] - g))
            code_by_epoch.setdefault(ei, []).append(r["dd_code"] - g)
    pair_med = {k: float(np.median([v for _, v in vals])) for k, vals in pair_vals.items()}
    score_sys = {}
    for key, vals in pair_vals.items():
        med = pair_med[key]
        for ei, val in vals:
            score_sys.setdefault((ei, key[0]), []).append(abs(val - med))
    bad = {ei for (ei, sysname), vals in score_sys.items()
           if np.median(vals) > 2.0}
    good = [ei for ei in range(len(epochs)) if ei not in bad]
    if not good:
        good = list(range(len(epochs)))
        bad = set()

    code_res = []
    phase_by_pair = {}
    phase_by_band = {}
    for ei in good:
        t, rr, fpos, fs = epochs[ei]
        for r in rr:
            key = (r["sys"], r["freq"], r["sat"], r["ref_sat"])
            g = _dd_geom(r, fpos, base_ecef)
            code_res.append(r["dd_code"] - g)
            phase_by_pair.setdefault(key, []).append(r["dd_phase"] - g)
    code_res = np.array(code_res)
    phase_all = []
    for key, vals in phase_by_pair.items():
        if len(vals) < 2:
            continue
        arr = np.array(vals) - np.median(vals)
        phase_all.append(arr)
        phase_by_band.setdefault((key[0], key[1]), []).append(arr)
    if phase_all:
        pa = np.concatenate(phase_all)
        phase_rms = float(np.sqrt(np.mean(pa ** 2)))
        phase_mad = float(np.median(np.abs(pa - np.median(pa))))
    else:
        phase_rms = float("nan")
        phase_mad = float("nan")
    band_rms = {}
    for k, v in phase_by_band.items():
        a = np.concatenate(v)
        band_rms[f"{k[0]}-{k[1]}"] = float(np.sqrt(np.mean(a ** 2)))
    out = {
        "flt_path": flt_path,
        "flt_epochs_used": len(good),
        "flt_epochs_rejected": len(bad),
        "flt_rejected_sow": [float(epochs[i][3]) for i in sorted(bad)],
        "flt_fixed_only": bool(fixed_only),
        "code_rms": float(np.sqrt(np.mean(code_res ** 2))) if len(code_res) else float("nan"),
        "code_mad": float(np.median(np.abs(code_res - np.median(code_res)))) if len(code_res) else float("nan"),
        "code_max": float(np.max(np.abs(code_res))) if len(code_res) else float("nan"),
        "phase_rms_after_amb": phase_rms,
        "phase_mad_after_amb": phase_mad,
        "phase_band_rms": band_rms,
    }
    print(f"flt validation ({len(good)} good epochs, {len(bad)} rejected, "
          f"fixed_only={fixed_only}): code RMS={out['code_rms']:.3f} m "
          f"(MAD={out['code_mad']:.3f} m), "
          f"phase RMS after per-pair ambiguity={phase_rms:.4f} m, "
          f"phase MAD={phase_mad:.4f} m")
    if bad:
        print("  rejected .flt sow:", out["flt_rejected_sow"])
    print("  phase band RMS:", {k: round(v, 4) for k, v in band_rms.items()})
    return out


def run_phase1(rover_path, base_paths, nav_path, flt_path, out_csv, out_json):
    """Full 607 s DD generation + static float validation."""
    # Window: GPS 02:09:50 .. 02:19:56 = UTC 02:09:32 .. 02:19:38.
    t0 = calendar.timegm(datetime(2020, 10, 27, 2, 9, 50).timetuple())
    t1 = calendar.timegm(datetime(2020, 10, 27, 2, 19, 56).timetuple())
    print(f"window GPS {t0}..{t1} (607 s), UTC {t0-18}..{t1-18}")
    rv, leap = parse_obs_file(rover_path, ("G", "C"), (t0, t1))
    base_epochs = []
    for bp in base_paths:
        bb, _ = parse_obs_file(bp, ("G", "C"), (t0, t1))
        base_epochs.extend(bb)
    base_epochs.sort(key=lambda e: e.t_gps)
    print(f"rover epochs={len(rv)}, base epochs={len(base_epochs)}, leap={leap}")
    nav = parse_nav_file(nav_path, ("G", "C"))
    print(f"ephemerides: {len(nav)} satellites")
    base_ecef = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
    rows = build_dd_rows(rv, base_epochs, nav, base_ecef)
    write_dd_csv(rows, out_csv)
    flt_val = validate_with_flt(rows, flt_path, base_ecef)
    # static segment: first 27 GPS epochs (rover stationary)
    static = solve_static_float(rows, base_ecef, t0 + 0.0, t0 + 26.0, flt_path)
    meta = {
        "window_gps": [t0, t1], "window_utc": [t0 - leap, t1 - leap],
        "leap_seconds": leap, "n_rover_epochs": len(rv),
        "n_base_epochs": len(base_epochs), "n_dd_rows": len(rows),
        "base_ecef": [float(v) for v in base_ecef],
        "flt_validation": flt_val,
        "static_float": static,
    }
    os.makedirs(os.path.dirname(os.path.abspath(out_json)), exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as f:
        import json
        json.dump(meta, f, indent=2)
    print(f"wrote {out_json}")
    return meta


def test_epoch(rover_path, base_path, nav_path, t_gps_str, systems=("G", "C")):
    """Print parsed observations and base-code geometry residuals for one epoch."""
    dt = datetime.strptime(t_gps_str, "%Y-%m-%d %H:%M:%S")
    t0 = calendar.timegm(dt.timetuple())
    tlim = (t0 - 1, t0 + 1)
    rv, leap = parse_obs_file(rover_path, systems, tlim)
    bb, _ = parse_obs_file(base_path, systems, tlim)
    nav = parse_nav_file(nav_path, systems)
    if not rv or not bb:
        print("no epoch parsed")
        return
    rover = rv[0]
    base = bb[0]
    print(f"epoch GPS {rover.t_gps:.0f} = UTC {rover.t_unix:.0f} (leap {leap})")
    print(f"rover sats: {sorted(rover.sats)}")
    print(f"base  sats: {sorted(base.sats)}")
    base_ecef = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
    lat, lon, alt = ecef_to_geodetic(base_ecef)
    print(f"base geodetic: lat={math.degrees(lat):.9f} lon={math.degrees(lon):.9f} alt={alt:.3f}")

    for sysname, band in (("G", "L1"), ("C", "B2I")):
        freq, code, phase, dopp = FREQS[(sysname, band)]
        print(f"\n--- {sysname} {band} {code}/{phase} ---")
        rows = []
        for sat, obs in sorted(base.sats.items()):
            if not sat.startswith(sysname):
                continue
            if code not in obs or phase not in obs:
                continue
            eph = select_eph(nav, sat, base.t_gps)
            if eph is None:
                print(f"  {sat}: no ephemeris")
                continue
            pos, dts = sat_pos_clock(eph, base.t_gps)
            elos, rho = los_enu(pos, base_ecef, lat, lon)
            if elos is None:
                continue
            elev = math.degrees(math.asin(max(-1.0, min(1.0, elos[2]))))
            # code = rho + c*(dt_rx - dt_sat) + tropo + noise
            # estimate the common c*dt_rx below; report rho + c*dt_sat here.
            rows.append((sat, obs[code].value, rho, dts * C_LIGHT, elev))
            print(f"  {sat}: code={obs[code].value:.3f} rho={rho:.3f} "
                  f"c*dtsat={dts*C_LIGHT:.3f} elev={elev:.1f}")
        if len(rows) >= 4:
            # robust common receiver clock (median), then residual after
            # removing it.  Troposphere is not modelled, so expect a few metres.
            common = np.median([c - rho + cdt for _, c, rho, cdt, _ in rows])
            res = [c - rho + cdt - common for _, c, rho, cdt, _ in rows]
            print(f"  common c*dt_rx (median) = {common:.3f} m")
            print(f"  code residual after clock: median={np.median(res):.3f} "
                  f"std={np.std(res):.3f} max={np.max(np.abs(res)):.3f} m")


# ---------------------------------------------------------------------------
# main
# ---------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--test-epoch", action="store_true")
    ap.add_argument("--test-dd", action="store_true")
    ap.add_argument("--run", action="store_true")
    ap.add_argument("--rover", default="/home/slxc9426/great_pvt/obs/campus-day.20O")
    ap.add_argument("--base", default="/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02/base_0200.rnx")
    ap.add_argument("--base2", default="/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02/base_0215.rnx")
    ap.add_argument("--nav", default="/home/slxc9426/great_pvt/gnss/brdm3010.20p")
    ap.add_argument("--flt", default="/home/slxc9426/great_pvt/result/FIXBASE-RTK.flt")
    ap.add_argument("--time", default="2020-10-27 02:10:00")
    ap.add_argument("--out-csv",
                    default="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv")
    ap.add_argument("--out-json",
                    default="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_meta.json")
    args = ap.parse_args()
    if args.test_epoch:
        test_epoch(args.rover, args.base, args.nav, args.time)
    elif args.test_dd:
        test_dd(args.rover, args.base, args.nav, args.flt, args.time)
    elif args.run:
        run_phase1(args.rover, [args.base, args.base2], args.nav, args.flt,
                   args.out_csv, args.out_json)
    else:
        ap.print_help()


if __name__ == "__main__":
    main()
