/*
Self-test for the sliding-window factor graph (R3 stage 2: WP4 + WP5).

Why this exists
---------------
WP4 fixes a class of bug, not a single instance: the line-search objective
(state_cost) was a hand-written duplicate of the A/b construction and had drifted
- it was missing the GNSS position factors, the Schur marginalized prior and the
node0 gauge. A term present in A/b but missing from the cost makes the
Gauss-Newton direction non-descent for the cost that is actually evaluated, so
steps get rejected and the backend silently stops making progress. Reviewing two
lists of terms by eye is what failed the first time, so the checks below are
arithmetic, not visual.

What it checks
--------------
1. stateCost() equals an INDEPENDENT sum of the documented terms, evaluated at a
   state read back from the graph, with the GNSS, bias-prior and node0-gauge terms
   all non-zero: GNSS position factor (with a lever arm), per-node velocity prior,
   both bias priors, and the node0 gauge (rotation, translation and velocity
   parts). The independent sum is written out here from data the test itself
   supplied, so it cannot inherit a mistake from stateCost(). No IMU is pushed, so
   pre-integration factors are absent from both sides by construction
   (preintegrate() returns dt=0), which is what makes an exact comparison possible.
2. The Schur marginalized prior contributes to stateCost(). Two graphs with
   identical keyframes and identical window contents are built, one with
   marginalize=true (prior active) and one with false (no prior). Their costs must
   be equal at the prior's own linearization point and must DIFFER once the biases
   are moved off it - which is only possible if the prior term is present.
3. A GNSS-dominated increment is accepted (WP4's acceptance criterion). With the
   objective missing the GNSS term the step that improves the GNSS residual is
   rejected and the node does not move at all.
4. WP5: the five parallel arrays keep the same length as the window across several
   window slides on the marginalize=false path, which used to slide only window_
   and silently re-attach every factor to the wrong node.

No gtest dependency (the project has none). Build target: factor_graph_selftest.
Run: ./devel/lib/fast_livo/factor_graph_selftest
Exit code 0 = all checks pass, 1 = at least one failed.
*/

#include "factor_graph.h"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <vector>

using namespace fast_livo;

namespace
{

int g_fail = 0;
int g_checks = 0;

void check(bool ok, const char *what)
{
  g_checks++;
  if (!ok)
  {
    g_fail++;
    std::printf("   FAIL  %s\n", what);
  }
  else
  {
    std::printf("   ok    %s\n", what);
  }
}

void checkClose(double got, double want, double tol, const char *what)
{
  const double diff = std::fabs(got - want);
  const double scale = std::max(1.0, std::fabs(want));
  g_checks++;
  if (diff / scale > tol)
  {
    g_fail++;
    std::printf("   FAIL  %s: got %.12g want %.12g (diff %.3g, rel %.3g)\n",
                what, got, want, diff, diff / scale);
  }
  else
  {
    std::printf("   ok    %s: %.12g (rel diff %.3g)\n", what, got, diff / scale);
  }
}

// A keyframe whose odometry factor is exactly consistent with the previous one,
// so the odometry residual is zero and the window starts at its optimum.
GraphKeyframe makeKf(double stamp, const Eigen::Matrix3d &R, const Eigen::Vector3d &p,
                     const Eigen::Vector3d &v, const Eigen::Matrix3d &R_rel,
                     const Eigen::Vector3d &p_rel, bool have_gnss,
                     const Eigen::Vector3d &gnss, double gnss_sigma)
{
  GraphKeyframe kf;
  kf.stamp = stamp;
  kf.R = R;
  kf.p = p;
  kf.v = v;
  kf.R_rel = R_rel;
  kf.p_rel = p_rel;
  kf.have_gnss = have_gnss;
  kf.gnss_pos = gnss;
  kf.gnss_sigma = gnss_sigma;
  return kf;
}

GraphConfig baseConfig()
{
  GraphConfig cfg;
  cfg.en = true;
  cfg.window_size = 2;
  cfg.gnss_en = true;
  cfg.robust_en = false;   // keeps the independent sum below free of Huber weights
  cfg.robust_delta = 1.5;
  cfg.thread_en = false;
  cfg.odom_rot_sigma = 0.01;
  cfg.odom_pos_sigma = 0.05;
  cfg.gnss_pos_sigma = 0.5;
  return cfg;
}

} // namespace

// ---------------------------------------------------------------------------
// Test 1: stateCost() == independent sum of all terms
// ---------------------------------------------------------------------------
static void testObjectiveTerms()
{
  std::printf("=== 1. objective equals the independently summed terms ===\n");

  GraphConfig cfg = baseConfig();
  cfg.max_gn_iter = 1;   // move a little, so the GNSS residual stays large
  const Eigen::Vector3d lever(0.3, -0.2, 0.15);
  cfg.lever = lever;

  FactorGraph fg(cfg);
  fg.setGravity(Eigen::Vector3d(0, 0, 9.81));

  const Eigen::Vector3d p0(10.0, -4.0, 2.0);
  const Eigen::Vector3d v0(1.0, 0.5, -0.2);
  // The graph anchors each node's velocity prior at the velocity the frontend
  // reported when the keyframe was pushed (Node::v_ref = kf.v), so this is what
  // the independent sum has to use. Nothing in a keyframe-only graph couples v,
  // so the term evaluates to ~0 here; it is still compared exactly, and giving it
  // a magnitude would need pre-integration factors, which this test deliberately
  // leaves out so that BOTH sides of the comparison are computable.
  const Eigen::Vector3d v_ref = v0;
  Eigen::Matrix3d R0 = fg_so3::Exp(Eigen::Vector3d(0.3, -0.1, 0.2));
  const Eigen::Vector3d gnss = p0 + R0 * lever + Eigen::Vector3d(100.0, -60.0, 30.0);
  const double gsigma = 0.5;

  fg.pushKeyframe(makeKf(0.0, R0, p0, v0, Eigen::Matrix3d::Identity(),
                         Eigen::Vector3d::Zero(), true, gnss, gsigma));
  fg.optimizeOnce();

  GraphResult res;
  const bool have = fg.getLatest(res);
  check(have, "graph produced a result");
  if (!have) return;

  // Every input below is chosen by the test, so the expected cost is exact.
  const Eigen::Vector3d bg_t(0.01, 0.02, 0.03);
  const Eigen::Vector3d ba_t(0.1, 0.2, 0.3);
  const Eigen::Vector3d dth(0.001, -0.002, 0.0005);     // linearization offset
  const Eigen::Matrix3d R0_lin = res.R * fg_so3::Exp(dth);
  const Eigen::Vector3d p0_lin = res.p + Eigen::Vector3d(0.4, -0.3, 0.2);
  const Eigen::Vector3d v0_lin = res.v + Eigen::Vector3d(-0.2, 0.1, 0.05);

  const double got = fg.stateCost(bg_t, ba_t, R0_lin, p0_lin, v0_lin);

  // ---- independent sum (no IMU pushed, so the pre-integration terms are absent
  //      in both the A/b assembly and stateCost: preintegrate() returns dt=0) ----
  // GNSS position factor: w * |p + R*lever - z|^2, w = 1/sigma^2, no robust weight
  const Eigen::Vector3d r_gnss = res.p + res.R * lever - gnss;
  const double w_gnss = 1.0 / (gsigma * gsigma);
  const double c_gnss = w_gnss * r_gnss.squaredNorm();
  // velocity prior: 1e2 * |v - v_ref|^2
  const double c_v = 1e2 * (res.v - v_ref).squaredNorm();
  // bias priors: 1e4*|bg|^2 + 1e2*|ba|^2
  const double c_bias = 1e4 * bg_t.squaredNorm() + 1e2 * ba_t.squaredNorm();
  // node0 gauge: 1e4 * (|dtheta|^2 + |dp|^2 + |dv|^2), measured from the
  // iteration's linearization point. With R0_lin = R*Exp(dth) the rotation part
  // is exactly |dth| (Log(Exp(-dth)) = -dth for a small dth).
  const double c_gauge = 1e4 * (dth.squaredNorm() +
                                (res.p - p0_lin).squaredNorm() +
                                (res.v - v0_lin).squaredNorm());

  const double want_all = c_gnss + c_v + c_bias + c_gauge;
  std::printf("   (terms: gnss=%.6g v=%.6g bias=%.6g gauge=%.6g)\n",
              c_gnss, c_v, c_bias, c_gauge);
  check(c_gnss > 1.0, "GNSS term in the independent sum is non-trivial");
  check(c_gauge > 1e3, "node0 gauge term in the independent sum is non-trivial");

  checkClose(got, want_all, 1e-9, "stateCost == gnss + v-prior + bias-priors + gauge");

  // Sharpness: each significant term is orders of magnitude above the tolerance,
  // so omitting any one of them from stateCost() would break the equality above
  // unmistakably rather than sitting inside the noise.
  const double tol_abs = 1e-9 * std::max(1.0, std::fabs(want_all));
  std::printf("   comparison tolerance %.6g;  term sizes: gnss=%.6g gauge=%.6g bias=%.6g\n",
              tol_abs, c_gnss, c_gauge, c_bias);
  check(c_gnss > 1e4 * tol_abs, "GNSS term far above the tolerance (sharp check)");
  check(c_gauge > 1e4 * tol_abs, "gauge term far above the tolerance (sharp check)");
  check(c_bias > 1e4 * tol_abs, "bias-prior term far above the tolerance (sharp check)");
  std::printf("\n");
}

// ---------------------------------------------------------------------------
// Test 2: the Schur marginalized prior contributes to the objective (WP4)
//          and the parallel arrays stay consistent (WP5)
// ---------------------------------------------------------------------------
static void testSchurPriorAndArrays()
{
  std::printf("=== 2. Schur prior present in stateCost; side arrays stay consistent ===\n");

  GraphConfig cfgA = baseConfig();   // marginalize = true (default)
  GraphConfig cfgB = baseConfig();
  cfgB.marginalize = false;

  FactorGraph fgA(cfgA), fgB(cfgB);
  fgA.setGravity(Eigen::Vector3d(0, 0, 9.81));
  fgB.setGravity(Eigen::Vector3d(0, 0, 9.81));

  // Identical keyframe sequence for both. Until A marginalizes, A and B run the
  // exact same optimizations on the exact same inputs, so their states match.
  const int n_kf = 3;                      // window_size = 2 -> one slide
  Eigen::Matrix3d R = fg_so3::Exp(Eigen::Vector3d(0.05, 0.02, -0.03));
  Eigen::Vector3d p(0.0, 0.0, 0.0);
  Eigen::Matrix3d R_prev = Eigen::Matrix3d::Identity();
  Eigen::Vector3d p_prev(0.0, 0.0, 0.0);
  const Eigen::Vector3d v(1.0, 0.0, 0.0);
  for (int i = 0; i < n_kf; i++)
  {
    if (i > 0)
    {
      R = R_prev * fg_so3::Exp(Eigen::Vector3d(0.02, 0.0, 0.0));
      p = p_prev + Eigen::Vector3d(0.5, 0.1, 0.0);
    }
    const Eigen::Matrix3d R_rel = R_prev.transpose() * R;
    const Eigen::Vector3d p_rel = R_prev.transpose() * (p - p_prev);
    GraphKeyframe kf = makeKf(0.1 * i, R, p, v, R_rel, p_rel, false,
                              Eigen::Vector3d::Zero(), 0.5);
    fgA.pushKeyframe(kf);
    fgB.pushKeyframe(kf);
    fgA.optimizeOnce();
    fgB.optimizeOnce();
    R_prev = R;
    p_prev = p;
  }

  check(fgA.windowSize() == 2, "A: window slid to window_size");
  check(fgB.windowSize() == 2, "B: window slid to window_size");
  check(fgA.sideArraysConsistent(), "A (marginalize=true): parallel arrays consistent");
  check(fgB.sideArraysConsistent(),
        "B (marginalize=false): parallel arrays consistent after the slide");

  // Right after marginalization the prior residual is zero (its linearization
  // point is the state itself), so A and B must agree exactly...
  const Eigen::Vector3d bg_at_prior(0.0, 0.0, 0.0);
  const Eigen::Vector3d ba_at_prior(0.0, 0.0, 0.0);
  // ...and both must be evaluable at the same arguments. A and B share the same
  // window content and the same states at this point (A's prior only appeared
  // during the last marginalization, after the last optimization).
  const double costA0 = fgA.stateCost(bg_at_prior, ba_at_prior,
                                      Eigen::Matrix3d::Identity(), Eigen::Vector3d::Zero(),
                                      Eigen::Vector3d::Zero());
  const double costB0 = fgB.stateCost(bg_at_prior, ba_at_prior,
                                      Eigen::Matrix3d::Identity(), Eigen::Vector3d::Zero(),
                                      Eigen::Vector3d::Zero());

  // Now move the biases off the prior's linearization point. The only term in the
  // objective that couples the nodes to the biases (with no IMU pushed, so there
  // are no pre-integration factors) is the Schur prior, so A's cost must change
  // and B's must not. If the prior term were missing from stateCost, A would not
  // react either and this check fails.
  const double costA1 = fgA.stateCost(Eigen::Vector3d(0.05, -0.03, 0.02),
                                      Eigen::Vector3d(0.2, 0.1, -0.15),
                                      Eigen::Matrix3d::Identity(), Eigen::Vector3d::Zero(),
                                      Eigen::Vector3d::Zero());
  const double costB1 = fgB.stateCost(Eigen::Vector3d(0.05, -0.03, 0.02),
                                      Eigen::Vector3d(0.2, 0.1, -0.15),
                                      Eigen::Matrix3d::Identity(), Eigen::Vector3d::Zero(),
                                      Eigen::Vector3d::Zero());

  const double dA = costA1 - costA0;
  const double dB = costB1 - costB0;
  std::printf("   costA: %.9g -> %.9g  (delta %.9g)\n", costA0, costA1, dA);
  std::printf("   costB: %.9g -> %.9g  (delta %.9g)\n", costB0, costB1, dB);
  std::printf("   deltaA - deltaB = %.9g   <- the Schur prior's contribution\n", dA - dB);
  checkClose(costA0, costB0, 1e-9,
             "at the prior point, cost(with prior) == cost(without prior)");
  // Note: BOTH graphs react to moving the biases, because both contain the bias
  // priors (1e4*|bg|^2 + 1e2*|ba|^2). Only the Schur prior makes the two graphs
  // react by DIFFERENT amounts, so that difference is what proves the term is
  // present. If stateCost() were still missing the prior term, dA and dB would be
  // equal (both exactly the bias-prior difference).
  check(std::fabs(dB) > 1e-6, "both graphs react to the biases via the bias priors");
  check(std::fabs(dA - dB) > 1e-6,
        "the prior graph reacts by a different amount (Schur prior present)");
  std::printf("\n");
}

// ---------------------------------------------------------------------------
// Test 3: a GNSS-dominated increment is accepted (WP4 acceptance criterion)
// ---------------------------------------------------------------------------
static void testGnssDominatedIncrement()
{
  std::printf("=== 3. GNSS-dominated increment is accepted ===\n");

  GraphConfig cfg = baseConfig();
  cfg.window_size = 3;
  const Eigen::Vector3d lever(0.0, 0.0, 0.0);
  cfg.lever = lever;

  FactorGraph fg(cfg);
  fg.setGravity(Eigen::Vector3d(0, 0, 9.81));

  // Two keyframes with a perfectly consistent odometry factor, and a GNSS fix on
  // the newest node 50 m away with a tight sigma. The odometry factor resists the
  // move, so only a cost function that CONTAINS the GNSS term will accept the
  // step that reduces the GNSS residual.
  const Eigen::Matrix3d R0 = Eigen::Matrix3d::Identity();
  const Eigen::Vector3d p0(0.0, 0.0, 0.0);
  const Eigen::Matrix3d R1 = Eigen::Matrix3d::Identity();
  const Eigen::Vector3d p1(1.0, 0.0, 0.0);
  const Eigen::Vector3d v(2.0, 0.0, 0.0);
  const Eigen::Vector3d gnss = p1 + Eigen::Vector3d(50.0, 0.0, 0.0);
  const double gsigma = 0.05;

  fg.pushKeyframe(makeKf(0.0, R0, p0, v, Eigen::Matrix3d::Identity(),
                         Eigen::Vector3d::Zero(), false, Eigen::Vector3d::Zero(), 0.5));
  fg.pushKeyframe(makeKf(0.1, R1, p1, v, R0.transpose() * R1, R0.transpose() * (p1 - p0),
                         true, gnss, gsigma));
  fg.optimizeOnce();

  GraphResult res;
  const bool have = fg.getLatest(res);
  check(have, "graph produced a result");
  if (!have) return;

  const double d_before = (p1 - gnss).norm();
  const double d_after = (res.p - gnss).norm();
  std::printf("   |p1 - gnss|: %.6f m before -> %.6f m after   (moved %.6f m)\n",
              d_before, d_after, (res.p - p1).norm());
  check(d_after < d_before - 5.0,
        "the newest node moved towards the GNSS measurement (GNSS term in the cost)");
  check(d_after > 0.0, "it did not teleport exactly onto the measurement");
  std::printf("\n");
}

// ---------------------------------------------------------------------------
// Test 4: the marginalize=false path survives several window slides (WP5)
// ---------------------------------------------------------------------------
static void testSlidesWithoutMarginalization()
{
  std::printf("=== 4. marginalize=false across several slides (WP5) ===\n");

  GraphConfig cfg = baseConfig();
  cfg.window_size = 2;
  cfg.marginalize = false;

  FactorGraph fg(cfg);
  fg.setGravity(Eigen::Vector3d(0, 0, 9.81));

  Eigen::Matrix3d R_prev = Eigen::Matrix3d::Identity();
  Eigen::Vector3d p_prev(0.0, 0.0, 0.0);
  const Eigen::Vector3d v(1.0, 0.0, 0.0);
  const int n_kf = 6;                       // 4 slides
  for (int i = 0; i < n_kf; i++)
  {
    const Eigen::Matrix3d R = R_prev * fg_so3::Exp(Eigen::Vector3d(0.03, 0.0, 0.0));
    const Eigen::Vector3d p = p_prev + Eigen::Vector3d(0.5, 0.05, 0.0);
    const Eigen::Matrix3d R_rel = R_prev.transpose() * R;
    const Eigen::Vector3d p_rel = R_prev.transpose() * (p - p_prev);
    // a GNSS fix on every other node, so node_gnss_ is exercised too
    const bool hg = (i % 2 == 0);
    fg.pushKeyframe(makeKf(0.1 * i, R, p, v, R_rel, p_rel, hg,
                           p + Eigen::Vector3d(1.0, 0.0, 0.0), 0.5));
    fg.optimizeOnce();
    R_prev = R;
    p_prev = p;
  }

  std::printf("   window=%d after %d keyframes (window_size=2)\n", fg.windowSize(), n_kf);
  check(fg.windowSize() == 2, "window stayed at window_size");
  check(fg.sideArraysConsistent(),
        "all five parallel arrays still match the window after 4 slides");
  std::printf("\n");
}

// ---------------------------------------------------------------------------
// Test 5 (R3 P1-1 third layer): one inconsistent odometry measurement must not
// walk the anchor across marginalizations.
//
// Setup: a pure-odometry chain (no GNSS, no pre-integration) starting ~360 m
// from the world origin, with ONE link whose measured translation is +0.2 m
// longer than the nodes actually are (a measurement outlier - the analogue of
// the real run's acceleration-phase disagreement). The optimizer compromises
// over that link; after the two affected nodes are marginalized the system is
// consistent again, so with a correctly-signed marginalized prior the
// published-minus-pushed offset must DECAY back toward the baked-in constant.
// A wrongly-signed prior linear term amplifies it instead, and the offset walks
// link by link - the failure mode EVAL_PROTOCOL 15.5 was hunting.
//
// (An earlier draft of this test put a constant GNSS offset on every node and
// called the resulting growth a walk: wrong - a common-mode translation is
// invisible to the relative factors, so the chain legitimately converges toward
// the GNSS positions, and the growth measured that transient.)
// ---------------------------------------------------------------------------
static void testMarginalizeFixedPoint()
{
  std::printf("=== 5. an odometry outlier must not walk the anchor ===\n");

  GraphConfig cfg = baseConfig();
  cfg.window_size = 3;
  cfg.marginalize = true;
  cfg.gnss_en = false;
  const Eigen::Vector3d lever(0.0, 0.0, 0.0);
  cfg.lever = lever;

  FactorGraph fg(cfg);
  fg.setGravity(Eigen::Vector3d(0, 0, 9.81));

  Eigen::Matrix3d R_prev = Eigen::Matrix3d::Identity();
  Eigen::Vector3d p_prev(300.0, 200.0, -15.0);
  const Eigen::Vector3d v(5.0, 0.0, 0.0);
  const int n_kf = 15;
  const int outlier_kf = 5;   // this link's measured translation is +0.2 m long

  std::printf("   published-minus-pushed offset per keyframe (x, y):\n");
  std::vector<double> off_x;
  for (int i = 0; i < n_kf; i++)
  {
    const Eigen::Matrix3d R = R_prev;
    const Eigen::Vector3d p = p_prev + Eigen::Vector3d(0.5, 0.0, 0.0);
    const Eigen::Matrix3d R_rel = R_prev.transpose() * R;
    Eigen::Vector3d p_rel = R_prev.transpose() * (p - p_prev);
    if (i == outlier_kf) p_rel += Eigen::Vector3d(0.2, 0.0, 0.0);  // the outlier link
    fg.pushKeyframe(makeKf(0.1 * i, R, p, v, R_rel, p_rel, false,
                           Eigen::Vector3d::Zero(), 0.5));
    fg.optimizeOnce();
    R_prev = R;
    p_prev = p;

    GraphResult res;
    if (fg.getLatest(res))
      off_x.push_back(res.p(0) - p(0));
  }

  for (size_t i = 0; i < off_x.size(); i++)
    std::printf("     kf %2zu: %+9.5f\n", i, off_x[i]);

  // after the outlier link has been marginalized out (kf >= 8), the offset must
  // be STABLE: the prior must neither correct it (nothing left to correct) nor
  // amplify it.
  double max_walk = 0.0;
  for (size_t i = 9; i < off_x.size(); i++)
    max_walk = std::max(max_walk, std::fabs(off_x[i] - off_x[8]));
  std::printf("   max anchor walk after the outlier left the window: %.6f m\n", max_walk);
  check(max_walk < 0.02,
        "the anchor does not walk across marginalizations (fixed point holds)");
  std::printf("\n");
}

int main()
{
  std::printf("=== factor_graph self-test (R3 stage 2: WP4 + WP5) ===\n\n");
  testObjectiveTerms();
  testSchurPriorAndArrays();
  testGnssDominatedIncrement();
  testSlidesWithoutMarginalization();
  testMarginalizeFixedPoint();

  std::printf("=== %d checks, %d failed ===\n", g_checks, g_fail);
  std::printf("%s\n", g_fail == 0 ? "ALL PASS" : "FAILED");
  return g_fail == 0 ? 0 : 1;
}
