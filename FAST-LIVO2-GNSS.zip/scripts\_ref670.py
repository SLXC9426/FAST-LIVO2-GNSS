#!/usr/bin/env python3
import io

p = r"D:\BaiduNetdiskDownload\Urban-01\urban01_reference.tum"
lines = io.open(p, encoding="utf-8", errors="replace").read().strip().splitlines()
for t0, t1 in [(1603774685, 1603774705), (1603774705, 1603774725)]:
    sel = [l for l in lines if t0 <= float(l.split()[0]) <= t1]
    if sel:
        print("t0", t0, "->", t1, "n:", len(sel))
        for l in sel[::60][:4]:
            v = l.split()
            print("   ", v[0], v[1], v[2], v[3])
    else:
        print("t0", t0, "->", t1, "n: 0")
