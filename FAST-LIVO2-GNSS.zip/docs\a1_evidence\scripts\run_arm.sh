#!/bin/bash
# One A0/A1 ablation arm: replay the same LIO TUM + RTK TUM into the current
# online_graph_node and keep TUM, node log, feed log and the association trace.
#
#   run_arm.sh <c01|c02> <arm> <rtk_interp 0|1> <scale_fit 0|1> <speed> <port> \
#              [duration] [start_offset] [static_rule_bracket 0|1]
#
# Examples (2x2 ablation):
#   run_arm.sh c02 A0   0 1 1.0 11341   # nearest + keyframe static rule
#   run_arm.sh c02 A1T  1 1 1.0 11342   # interp  + keyframe static rule
#   run_arm.sh c02 A1S  0 1 1.0 11343   # nearest + bracket static rule
#   run_arm.sh c02 A1   1 1 1.0 11344   # interp  + bracket static rule
#
# The harness is the WP2 same-input one (feed_online_graph.py): it replaces the
# live FAST-LIVO frontend with recorded LIO poses and RTK fixes. It cannot test
# the frontend, but it is the exact input layer that A1-A4 modify.
set -eo pipefail  # ROS setup.bash reads unset vars; do not use -u
export LANG=C.UTF-8

CAMPUS=${1:?campus c01|c02}
ARM=${2:?arm name}
INTERP=${3:?rtk_interp 0|1}
SCALE=${4:-1}
SPEED=${5:-1.0}
PORT=${6:-11341}
STATIC_RULE=${9:-1}   # 1 = A1 bracket rule, 0 = A0 nearest-keyframe rule
QUALITY_CSV=${10:-}   # A2.1: optional RTKLIB quality table for the offline channel

ROOT="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main"
OUT="$ROOT/06_exec/optimization/runs"
mkdir -p "$OUT"

DATA="$ROOT/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data"
STATUS="$ROOT/01_文档/02_改进与精度汇总/阶段0_评估契约_2026-10-30/v2_epoch_errors.csv"
case "$CAMPUS" in
  c01)
    LIVO="$ROOT/03_实验记录/对比实验/gv1/oracle/gv1_campus01_livo_r1_base.tum"
    RTK="$DATA/campus01_rtk1hz.tum"
    DUR=606
    BASE="[-2267749.9279,5009154.2407,3221290.6333]"
    ;;
  c02)
    LIVO="$ROOT/03_实验记录/对比实验/gv1/oracle/gv1_campus02_livo_r1_base.tum"
    RTK="$DATA/campus02_rtk1hz.tum"
    DUR=805
    BASE="[-2267750.14853585,5009154.50747098,3221294.38263863]"
    ;;
  *) echo "unknown campus: $CAMPUS" >&2; exit 2 ;;
esac

DUR=${7:-$DUR}   # optional short-segment override (screening only)
START_OFF=${8:-} # optional start offset from the first LIO pose (s)
EXTRA=()
if [ -n "$START_OFF" ]; then
  T0=$(awk -v off="$START_OFF" 'NR==1{printf "%.6f", $1+off; exit}' "$LIVO")
  EXTRA+=(--start "$T0")
fi
if [ -n "$QUALITY_CSV" ]; then
  EXTRA+=(--quality-csv "$QUALITY_CSV")
fi

for f in "$LIVO" "$RTK"; do
  [ -f "$f" ] || { echo "missing input: $f" >&2; exit 2; }
done

TAG="${CAMPUS}_${ARM}"
TUM="$OUT/${TAG}.tum"
TRACE="$OUT/${TAG}_assoc.csv"
NODE_LOG="$OUT/${TAG}_node.log"
FEED_LOG="$OUT/${TAG}_feed.log"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"
export ROS_MASTER_URI="http://127.0.0.1:${PORT}"
export ROS_HOSTNAME="127.0.0.1"
export ROS_IP="127.0.0.1"
export ROS_HOME="/tmp/ros_${TAG}"
mkdir -p "$ROS_HOME"

cleanup() {
  [ -n "${NODE_PID:-}" ] && kill "$NODE_PID" 2>/dev/null || true
  [ -n "${CORE_PID:-}" ] && kill "$CORE_PID" 2>/dev/null || true
  wait 2>/dev/null || true
}
trap cleanup EXIT

: > "$TRACE"
roscore -p "$PORT" > "$OUT/${TAG}_roscore.log" 2>&1 &
CORE_PID=$!
for _ in $(seq 1 30); do
  rostopic list >/dev/null 2>&1 && break
  sleep 0.5
done

"$HOME/catkin_ws/devel/lib/fast_livo/online_graph_node" \
  _output:="$TUM" \
  _assoc_trace:="$TRACE" \
  _window:=1500 \
  _tddd_en:=false \
  _quality_gate_en:=true \
  _quality_min_status:=2 \
  _cauchy_xy_en:=true \
  _lambda_weight_en:=true \
  _scale_fit_en:="$([ "$SCALE" = "1" ] && echo true || echo false)" \
  _sig_rigid:=0.01 \
  _sig_anchor:=0.3 \
  _rtk_interp_en:="$([ "$INTERP" = "1" ] && echo true || echo false)" \
  _rtk_static_rule_bracket:="$([ "$STATIC_RULE" = "1" ] && echo true || echo false)" \
  _rtk_interp_max_bracket_dt:=1.5 \
  _rtk_interp_model_sigma:=0.10 \
  _cov_en:=false \
  _fixed_lag_en:=false \
  _vel_en:=false \
  _base_ecef:="$BASE" \
  > "$NODE_LOG" 2>&1 &
NODE_PID=$!
sleep 3

echo "arm=$ARM campus=$CAMPUS interp=$INTERP static_rule=$STATIC_RULE " \
     "scale=$SCALE speed=$SPEED dur=$DUR quality_csv=${QUALITY_CSV:-none}" \
     > "$OUT/${TAG}_meta.txt"
# The graph algorithm lives in libonline_graph.so; the node executable is a thin
# ROS wrapper whose hash does not change when the graph code does.
sha256sum "$HOME/catkin_ws/devel/lib/fast_livo/online_graph_node" \
          "$HOME/catkin_ws/devel/lib/libonline_graph.so" \
          >> "$OUT/${TAG}_meta.txt"

python3 "$ROOT/06_exec/wsl/feed_online_graph.py" \
  --livo "$LIVO" \
  --rtk "$RTK" \
  --status-csv "$STATUS" \
  --duration "$DUR" \
  --speed "$SPEED" "${EXTRA[@]}" > "$FEED_LOG" 2>&1

sleep 8
echo "--- node tail ---"
tail -6 "$NODE_LOG"
wc -l "$TUM" "$TRACE" 2>/dev/null || true
