"""Seal explicit execution assets before launching; never overwrite run evidence."""
import argparse,hashlib,json,os
from pathlib import Path
import shutil,subprocess,time
def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for block in iter(lambda:f.read(8*1024*1024),b''):h.update(block)
    return h.hexdigest()
def seal(out,assets,command,references=()):
    out=Path(out).resolve()
    if out.exists():raise FileExistsError(out)
    roots=[Path(p).resolve() for p in assets]
    for p in roots:
        if not p.exists() or p==out or p in out.parents:raise ValueError('missing asset or output inside asset')
    out.mkdir(parents=True);mapping={};records=[]
    # Preserve full relative ancestry for scripts resolving sibling resources.
    for root in roots:
        files=sorted(p for p in root.rglob('*') if p.is_file()) if root.is_dir() else [root]
        for p in files:
            if p.is_symlink():raise ValueError('explicitly resolve symlink assets')
            relative=Path(*p.parts[1:])
            target=out/'assets'/relative;target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(p,target);mapping[str(p)]=str(target)
            records.append(dict(original=str(p),sealed=str(target),sha256=digest(target)))
    refs={str(Path(p).resolve()):dict(path=str(Path(p).resolve()),sha256=digest(p),bytes=Path(p).stat().st_size,mtime_ns=Path(p).stat().st_mtime_ns) for p in references}
    actual=[]
    for arg in command:
        key=str(Path(arg).resolve())
        if key in mapping:actual.append(mapping[key]);continue
        # File arguments must be explicit sealed assets; Python executables are
        # recorded as tools instead of copied runtime installations.
        if Path(arg).is_file() and arg!=command[0] and key not in refs:raise ValueError('unsealed file argument: '+arg)
        actual.append(arg)
    tool=Path(shutil.which(command[0]) or command[0])
    manifest=dict(command=actual,assets=records,references=list(refs.values()),tools=dict(executable=str(tool),sha256=digest(tool)),status='SEALED')
    (out/'seal.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    return actual,manifest
def execute(out,assets,command,references=()):
    actual,manifest=seal(out,assets,command,references);out=Path(out)
    env=dict(os.environ)
    libraries={str(Path(x['sealed']).parent) for x in manifest['assets'] if '.so' in Path(x['sealed']).name}
    if libraries:env['LD_LIBRARY_PATH']=os.pathsep.join(sorted(libraries))+os.pathsep+env.get('LD_LIBRARY_PATH','')
    started=time.monotonic()
    with (out/'process.log').open('w') as log:
        rc=subprocess.run(actual,stdout=log,stderr=subprocess.STDOUT,env=env).returncode
    intact=all(digest(r['sealed'])==r['sha256'] for r in manifest['assets'])
    references_unchanged=all(Path(r['path']).stat().st_size==r['bytes'] and Path(r['path']).stat().st_mtime_ns==r['mtime_ns'] for r in manifest['references'])
    result=dict(exit_code=rc,assets_intact=intact,elapsed_sec=time.monotonic()-started,
        process='PASS' if rc==0 else 'FAILED',coverage='NOT_EVALUATED',pairing='NOT_EVALUATED',accuracy='NOT_EVALUATED',
        references_metadata_unchanged=references_unchanged,status='PROCESS_ONLY_PASS' if rc==0 and intact and references_unchanged else 'FAILED',seal_sha256=digest(out/'seal.json'))
    (out/'result.json').write_text(json.dumps(result,indent=2),encoding='utf-8');return result
def review(original,expected,received,quality_ok,coverage_ok,process_ok,reason,out):
    out=Path(out)
    if out.exists():raise FileExistsError(out)
    checks=dict(input_counts=expected==received,quality=bool(quality_ok),coverage=bool(coverage_ok),process=bool(process_ok))
    status='FAILED'
    if bool(reason.strip()) and all(checks[k] for k in ['input_counts','quality','coverage']):
        if process_ok is None:status='DATA_REVIEWED_PASS'
        elif process_ok:status='REVIEWED_PASS'
    receipt=dict(original_manifest_sha256=digest(original),reviewer_sha256=digest(__file__),reason=reason,checks=checks,status=status)
    out.write_text(json.dumps(receipt,indent=2),encoding='utf-8');return receipt
def verify_receipt(original,receipt,allow_data_only=False):
    r=json.loads(Path(receipt).read_text(encoding='utf-8'))
    valid=all(r['checks'][k] for k in ['input_counts','quality','coverage'])
    scope=(r['status']=='REVIEWED_PASS' and r['checks']['process']) or (allow_data_only and r['status']=='DATA_REVIEWED_PASS')
    return r['original_manifest_sha256']==digest(original) and valid and scope and bool(r['reason'].strip())
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);p.add_argument('--asset',action='append',required=True,type=Path);p.add_argument('--reference',action='append',default=[],type=Path);p.add_argument('command',nargs=argparse.REMAINDER)
    a=p.parse_args();command=a.command[1:] if a.command[:1]==['--'] else a.command
    if not command:p.error('execution command required')
    r=execute(a.out,a.asset,command,a.reference);raise SystemExit(0 if r['status']=='PROCESS_ONLY_PASS' else 1)
