#!/usr/bin/env bash
# ============================================================================
# run_eval.sh - before/after comparison of the three FAST-LIVO2 improvements
#
# Usage (on Ubuntu, after catkin_make):
#   ./scripts/eval/run_eval.sh ntu        # NTU-VIRAL: 9 sequences, baseline vs improved
#   ./scripts/eval/run_eval.sh great      # GREAT campus-01 (with GNSS)
#   ./scripts/eval/run_eval.sh all
#
# Requirements: roslaunch, rosbag, evo (pip install evo)
#   The dataset bags must be reachable via the BAG_DIR variable below.
#
# Outputs (per sequence, per mode):
#   Log/result/<seq>.txt              - frontend trajectory (baseline & improved)
#   Log/result/<seq>_graph.txt        - factor-graph smoothed trajectory (improved)
#   Log/result/<seq>_latency.csv      - frontend vs backend latency
#   Log/result/<seq>_dyn.csv          - dynamic-point statistics (improved)
#   Log/eval/*.png / *.csv            - comparison tables & plots
# ============================================================================
set -e

ROOT="$(cd "$(dirname "$0")/../.." && pwd)"
BAG_DIR="${BAG_DIR:-$HOME/datasets}"   # <-- point this at your bag files

MODE="${1:-ntu}"

# ---------------------------------------------------------------- NTU-VIRAL
if [ "$MODE" = "ntu" ] || [ "$MODE" = "all" ]; then
  for seq in eee_01 eee_02 eee_03 nya_01 nya_02 nya_03 sbs_01 sbs_02 sbs_03; do
    echo "== NTU-VIRAL $seq =="
    # baseline (original config)
    roslaunch fast_livo mapping_ouster_ntu.launch rviz:=false seq_name:=${seq}_base 2>/dev/null &
    LPID=$!
    rosbag play "$BAG_DIR/ntu_viral/${seq}.bag" --clock
    wait $LPID || true
    # improved (occlusion + factor-graph + dynamic removal)
    roslaunch fast_livo mapping_ntu_improved.launch rviz:=false seq_name:=${seq}_imp 2>/dev/null &
    LPID=$!
    rosbag play "$BAG_DIR/ntu_viral/${seq}.bag" --clock
    wait $LPID || true
    # evaluate (evo must be installed)
    python3 "$ROOT/scripts/eval/eval_occlusion.py" \
        --gt  "$BAG_DIR/ntu_viral/${seq}_gt.tum" \
        --base "$ROOT/Log/result/${seq}_base.txt" \
        --imp  "$ROOT/Log/result/${seq}_imp.txt" \
        --out "$ROOT/Log/eval/${seq}"
    python3 "$ROOT/scripts/eval/eval_graph.py" \
        --gt  "$BAG_DIR/ntu_viral/${seq}_gt.tum" \
        --front "$ROOT/Log/result/${seq}_imp.txt" \
        --graph "$ROOT/Log/result/${seq}_imp_graph.txt" \
        --latency "$ROOT/Log/result/${seq}_imp_latency.csv" \
        --out "$ROOT/Log/eval/${seq}"
    python3 "$ROOT/scripts/eval/eval_dynamic.py" \
        --dyn "$ROOT/Log/result/${seq}_imp_dyn.csv" \
        --out "$ROOT/Log/eval/${seq}"
  done
fi

# ---------------------------------------------------------------- GREAT
if [ "$MODE" = "great" ] || [ "$MODE" = "all" ]; then
  echo "== GREAT campus-01 =="
  roslaunch fast_livo mapping_great.launch rviz:=false seq_name:=great_campus01_base 2>/dev/null &
  LPID=$!
  rosbag play "$BAG_DIR/great/campus-01.bag" --clock
  wait $LPID || true
  roslaunch fast_livo mapping_great_improved.launch rviz:=false seq_name:=great_campus01_imp 2>/dev/null &
  LPID=$!
  rosbag play "$BAG_DIR/great/campus-01.bag" --clock
  wait $LPID || true
  python3 "$ROOT/scripts/eval/eval_occlusion.py" \
      --gt  "$ROOT/Log/GREAT/campus01_reference.tum" \
      --base "$ROOT/Log/result/great_campus01_base.txt" \
      --imp  "$ROOT/Log/result/great_campus01_imp.txt" \
      --out "$ROOT/Log/eval/great_campus01"
  python3 "$ROOT/scripts/eval/eval_graph.py" \
      --gt  "$ROOT/Log/GREAT/campus01_reference.tum" \
      --front "$ROOT/Log/result/great_campus01_imp.txt" \
      --graph "$ROOT/Log/result/great_campus01_imp_graph.txt" \
      --latency "$ROOT/Log/result/great_campus01_imp_latency.csv" \
      --out "$ROOT/Log/eval/great_campus01"
  python3 "$ROOT/scripts/eval/eval_dynamic.py" \
      --dyn "$ROOT/Log/result/great_campus01_imp_dyn.csv" \
      --out "$ROOT/Log/eval/great_campus01"
fi

echo "Done. Summary tables in $ROOT/Log/eval/"
