#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the campus-03 DD stream (GPS 02:40:00-02:59:59).

The c03 bag runs 1253 s (UTC 10:39:41.8-11:00:35.7); the rover RINEX ends at
03:00:00 GPS = 02:59:42 UTC, so the DD stream covers the first ~1200 s.  The
last ~53 s is pure LIVO and is evaluated as such.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rtk_preprocess import (parse_obs_file, parse_nav_file, build_dd_rows,
                            write_dd_csv)

ROVER = "/home/slxc9426/great_pvt/obs/campus-day.20O"
NAV = "/home/slxc9426/great_pvt/gnss/brdm3010.20p"
BASE = "/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02"
BASES = [os.path.join(BASE, f) for f in
         ("base_0200.rnx", "base_0215.rnx", "base_0230.rnx", "base_0245.rnx")]
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw"
CSV = os.path.join(OUT, "c03_dd_gps_bds.csv")
META = os.path.join(OUT, "c03_dd_meta.json")

# c03 bag start UTC 1603766381.8 -> first integer GPS epoch 1603766400
# (UTC 02:39:42).  Base 02:45 file ends 02:59:59 GPS; rover ends 03:00:00.
T0 = 1603766400
T1 = 1603767599
BASE_ECEF = (-2267749.9279, 5009154.2407, 3221290.6333)


def main():
    print(f"c03 window GPS {T0}..{T1} ({T1-T0+1} s), UTC {T0-18}..{T1-18}")
    rv, leap = parse_obs_file(ROVER, ("G", "C"), (T0, T1))
    base_epochs = []
    for bp in BASES:
        bb, _ = parse_obs_file(bp, ("G", "C"), (T0, T1))
        base_epochs.extend(bb)
    base_epochs.sort(key=lambda e: e.t_gps)
    print(f"rover epochs={len(rv)}, base epochs={len(base_epochs)}, leap={leap}")
    nav = parse_nav_file(NAV, ("G", "C"))
    print(f"ephemerides={len(nav)} sats")
    rows = build_dd_rows(rv, base_epochs, nav, BASE_ECEF)
    write_dd_csv(rows, CSV)
    meta = dict(window_gps=[T0, T1], window_utc=[T0 - leap, T1 - leap],
                leap_seconds=leap, n_rover_epochs=len(rv),
                n_base_epochs=len(base_epochs), n_dd_rows=len(rows),
                base_ecef=list(BASE_ECEF), base_files=BASES,
                note="DD ends at 02:59:59 GPS; bag continues ~53 s as pure LIVO")
    with open(META, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print("wrote", META)


if __name__ == "__main__":
    main()
