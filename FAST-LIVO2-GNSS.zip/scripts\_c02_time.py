#!/usr/bin/env python3
import rosbag
import numpy as np
import sensor_msgs.point_cloud2 as pc2

b = rosbag.Bag("/mnt/e/GREAT数据集/campus-02/campus-02.bag")
n = 0
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    n += 1
    if n > 6:
        break
    pts = list(pc2.read_points(msg, field_names=("time",), skip_nans=True))
    a = np.array(pts, dtype=float)
    print("frame %d npts %d time %.1f ~ %.1f us" % (n, len(a), a.min(), a.max()))
b.close()
