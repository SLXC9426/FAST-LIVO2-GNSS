#!/bin/bash
# Original FAST-LIVO2 LIVO baseline, full length, campus-01/02.
export LANG=C.UTF-8
HERE="$(dirname "$0")"
OUT=$HOME/orig_livo_summary.txt
: > "$OUT"
bash "$HERE/kill_ros.sh"
for seq in campus01:c01_orig_livo campus02:c02_orig_livo; do
  S=${seq%%:*}; T=${seq##*:}
  echo "=== $S / $T ===" | tee -a "$OUT"
  bash "$HERE/run_orig_livo.sh" "$S" "$T" 2>&1 | tee -a "$OUT"
done
echo ORIG_LIVO_DONE | tee -a "$OUT"
