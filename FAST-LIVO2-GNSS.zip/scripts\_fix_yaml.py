#!/usr/bin/env python3
import io

p = "/home/slxc9426/catkin_ws/src/fast_livo/config/great_campus01_fulltight.yaml"
t = io.open(p, encoding="utf-8").read()
t = t.replace("  gnss:\n    yaw_align_min_dist: 20.0", "gnss:\n  yaw_align_min_dist: 20.0")
io.open(p, "w", encoding="utf-8").write(t)
print(t[-120:])
