/*
A2.2 self-test: unified GNSS quality classifier.

Both channels normalise to GnssQualityInput; these tests pin the decision table
and the RTKLIB -> carr_soln adapter. A2.2 only classifies: no factor, sigma or
gate is exercised here.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/gnss_quality_classifier_selftest
*/
#include "gnss_quality.h"

#include <cstdio>
#include <string>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok)
{
  std::printf("%s  %-58s\n", ok ? "ok  " : "FAIL", name.c_str());
  if (!ok) ++g_failures;
}

fast_livo::GnssQualityInput make(bool valid, int fix_type, int carr, int nsat,
                                 double pdop)
{
  fast_livo::GnssQualityInput in;
  in.has_record = true;
  in.source = "ublox";
  in.valid = valid;
  in.fix_type = fix_type;
  in.carr_soln = carr;
  in.num_sv = nsat;
  in.p_dop = pdop;
  in.has_p_dop = pdop > 0.0;
  return in;
}

}  // namespace

int main()
{
  using fast_livo::GnssQualityClass;
  using fast_livo::GnssQualityInput;
  using fast_livo::GnssQualityParams;
  using fast_livo::GnssQualityVerdict;
  using fast_livo::classifyGnssQuality;

  const GnssQualityParams p;  // 8/5.0 hard-ish, 12/3.0 good

  // ---- missing record ------------------------------------------------------
  {
    GnssQualityInput in;
    const auto v = classifyGnssQuality(in, p);
    check("no record -> UNKNOWN, unusable",
          v.cls == GnssQualityClass::UNKNOWN && !v.usable &&
              v.reason == "no_quality_record");
  }

  // ---- invalid solutions ---------------------------------------------------
  {
    auto v = classifyGnssQuality(make(false, 3, 0, 20, 1.5), p);
    check("invalid flag -> INVALID", v.cls == GnssQualityClass::INVALID &&
                                         !v.usable && v.reason == "invalid_flag");
  }
  {
    auto v = classifyGnssQuality(make(true, 0, 0, 0, 0.0), p);
    check("fix_type 0 -> INVALID/no_fix",
          v.cls == GnssQualityClass::INVALID && v.reason == "no_fix");
  }
  {
    auto v = classifyGnssQuality(make(true, 1, 0, 20, 1.5), p);
    check("DR-only -> INVALID/fix_type",
          v.cls == GnssQualityClass::INVALID && v.reason == "fix_type");
  }

  // ---- class ladder --------------------------------------------------------
  {
    auto v = classifyGnssQuality(make(true, 3, 2, 19, 1.5), p);
    check("fixed + good geometry -> GOOD",
          v.cls == GnssQualityClass::GOOD && v.usable && v.reason.empty());
  }
  {
    auto v = classifyGnssQuality(make(true, 3, 2, 10, 4.0), p);
    check("fixed + mediocre geometry -> FIXED",
          v.cls == GnssQualityClass::FIXED && v.usable);
  }
  {
    auto v = classifyGnssQuality(make(true, 3, 1, 19, 1.5), p);
    check("carrier float -> FLOAT",
          v.cls == GnssQualityClass::FLOAT && v.usable);
  }
  {
    auto v = classifyGnssQuality(make(true, 3, 0, 19, 1.5), p);
    check("SPP without carrier -> DEGRADED/no_carrier",
          v.cls == GnssQualityClass::DEGRADED && v.usable &&
              v.reason == "no_carrier");
  }

  // ---- geometry gates only when known -------------------------------------
  {
    auto v = classifyGnssQuality(make(true, 3, 2, 5, 1.5), p);
    check("few satellites -> DEGRADED/few_sats",
          v.cls == GnssQualityClass::DEGRADED && v.reason == "few_sats");
  }
  {
    auto v = classifyGnssQuality(make(true, 3, 1, 19, 6.0), p);
    check("high PDOP -> DEGRADED/pdop_high",
          v.cls == GnssQualityClass::DEGRADED && v.reason == "pdop_high");
  }
  {
    auto in = make(true, 3, 2, 5, 6.0);
    const auto v = classifyGnssQuality(in, p);
    check("both bad -> few_sats wins the reason",
          v.cls == GnssQualityClass::DEGRADED && v.reason == "few_sats");
  }
  {
    // pdop unknown: has_p_dop false with a zero value must not reject.
    auto in = make(true, 3, 2, 19, 0.0);
    in.has_p_dop = false;
    const auto v = classifyGnssQuality(in, p);
    check("unknown PDOP is not treated as high PDOP",
          v.cls == GnssQualityClass::GOOD && v.reason.empty());
  }
  {
    // num_sv unknown (0) must not reject either.
    const auto v = classifyGnssQuality(make(true, 3, 2, 0, 1.5), p);
    check("unknown satellite count is not treated as few",
          v.cls == GnssQualityClass::GOOD && v.reason.empty());
  }
  {
    // Boundaries are inclusive: nsat == min and pdop == max pass.
    const auto v = classifyGnssQuality(make(true, 3, 1, 8, 5.0), p);
    check("min nsat / max pdop boundaries pass",
          v.cls == GnssQualityClass::FLOAT && v.usable);
  }

  // ---- RTKLIB adapter ------------------------------------------------------
  {
    check("rtklib Fixed -> carr 2",
          fast_livo::rtklibStatusToCarrSoln("Fixed") == 2);
    check("rtklib Float -> carr 1",
          fast_livo::rtklibStatusToCarrSoln("Float") == 1);
    check("rtklib DGPS/Single -> carr 0",
          fast_livo::rtklibStatusToCarrSoln("DGPS") == 0 &&
              fast_livo::rtklibStatusToCarrSoln("Single") == 0);
    check("rtklib validity list",
          fast_livo::rtklibStatusIsValid("Fixed") &&
              fast_livo::rtklibStatusIsValid("Float") &&
              fast_livo::rtklibStatusIsValid("Single") &&
              !fast_livo::rtklibStatusIsValid(""));
  }
  {
    // Same normalised input from either source must classify identically.
    auto ubx = make(true, 3, 2, 19, 1.5);
    ubx.source = "ublox";
    auto rtk = ubx;
    rtk.source = "rtklib";
    const auto a = classifyGnssQuality(ubx, p);
    const auto b = classifyGnssQuality(rtk, p);
    check("online/offline share the classifier",
          a.cls == b.cls && a.usable == b.usable && a.reason == b.reason);
  }

  // ---- A2.3 gate policy ----------------------------------------------------
  {
    fast_livo::GnssQualityGatePolicy pol;  // invalid only
    check("gate: INVALID always dropped",
          fast_livo::shouldGateGnssQualityClass(
              GnssQualityClass::INVALID, pol));
    check("gate: FIXED/GOOD never dropped",
          !fast_livo::shouldGateGnssQualityClass(
              GnssQualityClass::FIXED, pol) &&
              !fast_livo::shouldGateGnssQualityClass(
                  GnssQualityClass::GOOD, pol));
    check("gate: UNKNOWN/DEGRADED/FLOAT off by default",
          !fast_livo::shouldGateGnssQualityClass(
              GnssQualityClass::UNKNOWN, pol) &&
              !fast_livo::shouldGateGnssQualityClass(
                  GnssQualityClass::DEGRADED, pol) &&
              !fast_livo::shouldGateGnssQualityClass(
                  GnssQualityClass::FLOAT, pol));
    pol.reject_degraded = true;
    pol.reject_float = true;
    pol.reject_unknown = true;
    check("gate: opt-in classes are dropped",
          fast_livo::shouldGateGnssQualityClass(
              GnssQualityClass::DEGRADED, pol) &&
              fast_livo::shouldGateGnssQualityClass(
                  GnssQualityClass::FLOAT, pol) &&
              fast_livo::shouldGateGnssQualityClass(
                  GnssQualityClass::UNKNOWN, pol));
  }

  // ---- class names ---------------------------------------------------------
  {
    check("class names are stable",
          std::string(fast_livo::gnssQualityClassName(
              GnssQualityClass::DEGRADED)) == "degraded" &&
              std::string(fast_livo::gnssQualityClassName(
                  GnssQualityClass::GOOD)) == "good");
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: unified GNSS quality classification\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
