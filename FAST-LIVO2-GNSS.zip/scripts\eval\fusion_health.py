#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Fusion health extraction from a node log (T0-3).

An inert or absent fusion must be visible in the report, not discovered later
from the APE numbers (a WITHHELD alignment and a silently 0-gain fusion produce
very similar trajectories to pure LIVO, and only the log tells them apart).
The estimator already prints everything needed (LIVMapper.cpp); this tool turns
those prints into the report block:

  alignment: LOCKED (samples=65 dropped=0, settled=10, yaw=+22.2 deg, fit_resid=0.54 m)
  fusion: evaluated=530 accepted=184 rejected=345 (accept 34.7%)
  gate:   gamma 2.359/7.815 (2.80 sigma, mode=table) | gate_sigma=table/2.50 m | sigma_h=4.35 m
  gain:   P_pos_eff=0.0316 m | |dx_pos| median=0.0063 m | |res| median=2.93 m
  verdict: ACTIVE

verdict is one of:
  NO GNSS ACTIVITY   no alignment/health/update lines at all (pure-LIVO arm or gnss_en off)
  WITHHELD->OFF      alignment attempted but never locked (fit residual over gate)
  LOCKED/NO ACCEPT   locked but every evaluated epoch was rejected
  ACTIVE             locked and at least one epoch accepted

Assumes ONE run per log (run_full_eval.sh / segment_run.sh truncate per run).
Multiple logs may be passed (one report block each).

Usage:
  fusion_health.py <run.log> [<run2.log> ...] [--expect-active]

--expect-active exits 1 if any log's verdict is not ACTIVE (run-level gate).
"""
import glob
import re
import sys

RE_ORIGIN = re.compile(r"\[GNSS\] Origin set: lat=")
RE_LOCKED = re.compile(
    r"\[GNSS\] Frame alignment LOCKED \(2D Procrustes, robust refit"
    r"(, FORCED)?(, relative)?\)")
RE_LOCK_SAMPLES = re.compile(r"samples = (\d+) \(dropped (\d+)\), GNSS span = ([\d.]+) m, "
                             r"LIO span = ([\d.]+) m, settled = (\d+)")
RE_LOCK_YAW = re.compile(r"yaw_offset = ([-\d.]+) deg")
RE_LOCK_RESID = re.compile(r"horizontal fit residual RMS = ([\d.]+) m")
RE_WITHHELD = re.compile(r"\[GNSS\] alignment WITHHELD: fit residual ([\d.]+) m > ([\d.]+) m gate "
                         r"\(samples=(\d+), GNSS span=([\d.]+) m")
RE_HEALTH = re.compile(r"\[GNSS\] health: evaluated=(\d+) accepted=(\d+) rejected=(\d+) \| "
                       r"sigma_h=([\d.]+) sigma_u=([\d.]+) m \| med\|r_h\|=([\d.]+) \(ratio ([\d.]+)\) \| "
                       r"gate_sigma=(\S+)/([\d.]+) m")
RE_REJECT = re.compile(r"\[GNSS\] Outlier rejected, t=(\S+) gamma=(\S+)")
RE_UPDATE = re.compile(r"\[GNSS\] update: \|res\|=([\d.]+) \|dx_pos\|=([\d.]+) P_pos_eff=([\d.]+) m")
RE_GATELINE = re.compile(r"\[GNSS\] update: gate t=(\S+) gamma=(\S+) gate=([\d.]+) "
                         r"\(equiv (\S+) sigma, mode=(\S+)\)")
RE_VEL = re.compile(r"\[GNSS\] update: vel \|res_v\|=([\d.]+) m/s \|dx_vel\|=([\d.]+) "
                    r"P_vel_eff=([\d.]+) sigma_v=([\d.]+) gain_v=([\d.]+)")
RE_ANCHOR = re.compile(r"\[GNSS\] anchor set at t=")
RE_VETO_ARM = re.compile(r"\[ZUPT\] hold veto armed: GNSS reference fix at t=")
RE_VETO_RELEASE = re.compile(r"\[ZUPT\] hold veto RELEASED by GNSS motion: disp=")
RE_RTK_ACCEPT = re.compile(
    r"\[RTK\] accept t=([\d.]+) pairs=(\d+) fixed=(\d+) amb=(\d+) slips=(\d+) gamma=([\d.]+)/([\d.]+) "
    r"\|r_code\|=([\d.]+) \|r_phase\|=([\d.]+) \|dx_pos\|=([\d.]+) P_pos=([\d.]+)")
RE_RTK_REJECT = re.compile(
    r"\[RTK\] reject t=([\d.]+) pairs=(\d+) fixed=(\d+) amb=(\d+) slips=(\d+) gamma=([\d.]+) gate=([\d.]+) "
    r"\|r_code\|=([\d.]+) \|r_phase\|=([\d.]+)")
RE_SUP = re.compile(
    r"\[SUP\] mode=(\w+) w_rtk=([\d.]+) w_gnss=([\d.]+) ratio=([\d.]+) "
    r"n_fixed=(\d+) streak=([\d.]+) gamma=([\d.]+) livo=([\d.]+)")


def median(xs):
    s = sorted(xs)
    n = len(s)
    if not n:
        return None
    return s[n // 2] if n % 2 else 0.5 * (s[n // 2 - 1] + s[n // 2])


def parse(path):
    f = dict(origin=0, locked=None, withheld=[], anchor=0, veto_arm=0, veto_release=0,
             health=[], update=[], gate=[], vel=[], rtk_acc=[], rtk_rej=[], sup=[])
    with open(path, encoding="utf-8", errors="replace") as fh:
        for line in fh:
            if RE_ORIGIN.search(line):
                f["origin"] += 1
                continue
            m = RE_LOCKED.search(line)
            if m:
                f["locked"] = dict(forced=bool(m.group(1)), samples=None, yaw=None, resid=None)
                continue
            m = RE_LOCK_SAMPLES.search(line)
            if m and f["locked"] is not None and f["locked"]["samples"] is None:
                f["locked"].update(samples=int(m.group(1)), dropped=int(m.group(2)),
                                   span_g=float(m.group(3)), span_l=float(m.group(4)),
                                   settled=int(m.group(5)))
                continue
            m = RE_LOCK_YAW.search(line)
            if m and f["locked"] is not None:
                f["locked"]["yaw"] = float(m.group(1))
                continue
            m = RE_LOCK_RESID.search(line)
            if m and f["locked"] is not None:
                f["locked"]["resid"] = float(m.group(1))
                continue
            m = RE_WITHHELD.search(line)
            if m:
                f["withheld"].append(dict(resid=float(m.group(1)), gate=float(m.group(2)),
                                          samples=int(m.group(3))))
                continue
            if RE_ANCHOR.search(line):
                f["anchor"] += 1
            elif RE_VETO_ARM.search(line):
                f["veto_arm"] += 1
            elif RE_VETO_RELEASE.search(line):
                f["veto_release"] += 1
            m = RE_RTK_ACCEPT.search(line)
            if m:
                f["rtk_acc"].append(dict(t=float(m.group(1)), pairs=int(m.group(2)),
                                         fixed=int(m.group(3)), amb=int(m.group(4)),
                                         slips=int(m.group(5)), gamma=float(m.group(6)),
                                         gate=float(m.group(7)), code=float(m.group(8)),
                                         phase=float(m.group(9)), dx=float(m.group(10)),
                                         ppos=float(m.group(11))))
                f["first_t"] = min(f.get("first_t", f["rtk_acc"][-1]["t"]), f["rtk_acc"][-1]["t"])
                continue
            m = RE_RTK_REJECT.search(line)
            if m:
                f["rtk_rej"].append(dict(t=float(m.group(1)), pairs=int(m.group(2)),
                                         fixed=int(m.group(3)), amb=int(m.group(4)),
                                         slips=int(m.group(5)), gamma=float(m.group(6)),
                                         gate=float(m.group(7)), code=float(m.group(8)),
                                         phase=float(m.group(9))))
                continue
            m = RE_SUP.search(line)
            if m:
                f["sup"].append(dict(mode=m.group(1), w_rtk=float(m.group(2)),
                                     w_gnss=float(m.group(3)), ratio=float(m.group(4)),
                                     n_fixed=int(m.group(5)), streak=float(m.group(6)),
                                     gamma=float(m.group(7)), livo=float(m.group(8))))
                continue
            m = RE_HEALTH.search(line)
            if m:
                f["health"].append(dict(ev=int(m.group(1)), ok=int(m.group(2)), rej=int(m.group(3)),
                                        sig_h=float(m.group(4)), sig_u=float(m.group(5)),
                                        med_r=float(m.group(6)), ratio=float(m.group(7)),
                                        gmode=m.group(8), gsig=float(m.group(9))))
                continue
            m = RE_REJECT.search(line)
            if m:
                f["rej_lines"] = f.get("rej_lines", 0) + 1
                try:
                    t0 = float(m.group(1))
                    f["first_t"] = min(f.get("first_t", t0), t0)
                except ValueError:
                    pass
                continue
            m = RE_UPDATE.search(line)
            if m:
                f["update"].append(dict(res=float(m.group(1)), dx=float(m.group(2)),
                                        ppos=float(m.group(3))))
                continue
            m = RE_GATELINE.search(line)
            if m:
                f["gate"].append(dict(gamma=m.group(2), gate=float(m.group(3)),
                                      equiv=m.group(4), mode=m.group(5)))
                try:
                    t0 = float(m.group(1))
                    f["first_t"] = min(f.get("first_t", t0), t0)
                except ValueError:
                    pass
                continue
            m = RE_VEL.search(line)
            if m:
                f["vel"].append(dict(res_v=float(m.group(1)), pvel=float(m.group(3)),
                                     gain_v=float(m.group(5))))
    return f


def report(path, f):
    out = ["== %s ==" % path]
    has_rtk = bool(f["rtk_acc"] or f["rtk_rej"])
    if has_rtk:
        acc = len(f["rtk_acc"])
        rej = len(f["rtk_rej"])
        last = (f["rtk_acc"] or f["rtk_rej"])[-1]
        out.append("rtk:    accepted=%d rejected=%d (accept %.1f%%) | last t=%.1f "
                   "pairs=%d fixed=%d amb=%d slips=%d gamma=%.1f/%.1f |r_code|=%.2f "
                   "|r_phase|=%.2f |dx_pos|=%.3f P_pos=%.3f"
                   % (acc, rej, 100.0 * acc / max(acc + rej, 1), last["t"],
                      last["pairs"], last.get("fixed", 0), last["amb"], last["slips"], last["gamma"],
                      last["gate"], last["code"], last["phase"],
                      last.get("dx", float("nan")), last.get("ppos", float("nan"))))
    if f["sup"]:
        modes = {}
        for s in f["sup"]:
            modes[s["mode"]] = modes.get(s["mode"], 0) + 1
        last = f["sup"][-1]
        out.append("sup:    %s | last w_rtk=%.2f w_gnss=%.2f ratio=%.2f n_fixed=%d "
                   "streak=%.1f gamma=%.1f livo=%.2f"
                   % (", ".join("%s=%d" % (k, v) for k, v in sorted(modes.items())),
                      last["w_rtk"], last["w_gnss"], last["ratio"], last["n_fixed"],
                      last["streak"], last["gamma"], last["livo"]))
    if f["locked"] is not None:
        L = f["locked"]
        det = []
        if L.get("samples") is not None:
            det.append("samples=%d dropped=%d, settled=%s" % (L["samples"], L["dropped"], L["settled"]))
        if L.get("yaw") is not None:
            det.append("yaw=%+.1f deg" % L["yaw"])
        if L.get("resid") is not None:
            det.append("fit_resid=%.2f m" % L["resid"])
        out.append("alignment: LOCKED%s (%s)" % (" FORCED" if L["forced"] else "", ", ".join(det)))
    elif f["withheld"]:
        w = f["withheld"][-1]
        out.append("alignment: WITHHELD (%d gate message(s), last: fit residual %.2f m > %.2f m, "
                   "samples=%d) -> fusion OFF" % (len(f["withheld"]), w["resid"], w["gate"], w["samples"]))
    elif f["origin"]:
        out.append("alignment: NONE (GNSS received, never attempted/locked)")
    else:
        out.append("alignment: NO GNSS ACTIVITY (pure-LIVO arm or gnss_en off)")

    if f["health"]:
        h = f["health"][-1]
        acc = 100.0 * h["ok"] / h["ev"] if h["ev"] else 0.0
        # first TIMESTAMPED post-lock evidence (earliest gate/reject line):
        # bounds the lock moment from above at gnss_health_every_n granularity.
        eng = ""
        if f.get("first_t") is not None:
            eng = " | engaged by t=%.1f s" % f["first_t"]
        out.append("fusion: evaluated=%d accepted=%d rejected=%d (accept %.1f%%)%s%s"
                   % (h["ev"], h["ok"], h["rej"], acc, eng,
                      " [%d health lines]" % len(f["health"])))
    elif f.get("rej_lines"):
        out.append("fusion: (no health lines) rejected>=%d from outlier lines" % f["rej_lines"])
    elif f["update"]:
        out.append("fusion: (no health lines) %d update line(s)" % len(f["update"]))
    elif has_rtk:
        out.append("fusion: RTK DD updates active (see rtk line)")
    else:
        out.append("fusion: no update activity")

    if f["gate"]:
        g = f["gate"][-1]
        gs = ""
        if f["health"]:
            gs = " | gate_sigma=%s/%.2f m" % (f["health"][-1]["gmode"], f["health"][-1]["gsig"])
        out.append("gate:   last gamma=%s/%.3f (%s sigma, mode=%s)%s"
                   % (g["gamma"], g["gate"], g["equiv"], g["mode"], gs))
    elif f["health"]:
        h = f["health"][-1]
        out.append("gate:   gate_sigma=%s/%.2f m" % (h["gmode"], h["gsig"]))

    if f["update"]:
        us = f["update"]
        med_dx = median([u["dx"] for u in us])
        med_res = median([u["res"] for u in us])
        # update lines are printed every gnss_health_every_n-th evaluated epoch,
        # so these medians describe the sampled subset, not every accepted epoch.
        extra = " | |dx_pos| median=%.4f m [n=%d sampled] | |res| median=%.3f m" % (
            med_dx, len(us), med_res)
        if f["vel"]:
            vs = f["vel"][-1]
            extra += " | last vel: P_vel_eff=%.4f gain_v=%.3f" % (vs["pvel"], vs["gain_v"])
        out.append("gain:   P_pos_eff last=%.4f m%s" % (us[-1]["ppos"], extra))

    notes = []
    if f["anchor"]:
        notes.append("anchor set x%d" % f["anchor"])
    if f["veto_arm"]:
        notes.append("hold-veto armed x%d" % f["veto_arm"])
    if f["veto_release"]:
        notes.append("hold-veto released x%d" % f["veto_release"])
    if notes:
        out.append("aux:     " + ", ".join(notes))

    if has_rtk and f["locked"] is not None:
        acc = len(f["rtk_acc"])
        rej = len(f["rtk_rej"])
        if acc > 0:
            out.append("verdict: RTK ACTIVE (accepted=%d rejected=%d)" % (acc, rej))
        else:
            out.append("verdict: RTK REJECTING (0 accepted, %d rejected)" % rej)
    elif f["locked"] is not None:
        h = f["health"][-1] if f["health"] else None
        if h is None and not f["update"]:
            out.append("verdict: LOCKED (no health/update lines captured)")
        elif h and h["ok"] == 0 and h["ev"] > 0:
            out.append("verdict: LOCKED/NO ACCEPT (every evaluated epoch rejected)")
        else:
            out.append("verdict: ACTIVE")
    elif f["withheld"]:
        out.append("verdict: WITHHELD->OFF")
    elif f["origin"] or f["update"]:
        out.append("verdict: NO LOCK (updates without a lock should not happen)")
    else:
        out.append("verdict: NO GNSS ACTIVITY")
    return out


def main():
    a = sys.argv[1:]
    expect = False
    paths = []
    i = 0
    while i < len(a):
        if a[i] == "--expect-active":
            expect = True
        else:
            paths.extend(sorted(glob.glob(a[i])) or [a[i]])
        i += 1
    if not paths:
        print(__doc__)
        return 1
    bad = []
    for p in paths:
        try:
            lines = report(p, parse(p))
        except OSError as e:
            lines = ["== %s ==\n!! cannot read: %s" % (p, e)]
        print("\n".join(lines))
        if any(l.startswith("verdict: ") and "ACTIVE" not in l for l in lines):
            bad.append(p)
        print("")
    if expect and bad:
        print("!! %d/%d log(s) not ACTIVE: %s" % (len(bad), len(paths), ", ".join(bad)))
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
