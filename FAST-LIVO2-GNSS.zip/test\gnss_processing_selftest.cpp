/*
Self-test for GnssProcess: the noise table that gives the chi-square gate its
absolute scale, and the ENU frame conventions the two observation paths share.

Why this exists (R3: EVAL_PROTOCOL section 12.2, R3_NEXT_STEPS P0-2):
WP7 decoupled the chi-square gate from the adaptive sigma, and the whole point of
that change is that the gate now uses a PHYSICAL, absolute scale taken from the
fix-type table (LIVMapper.cpp:2864 -> getHorizontalCov/getVerticalCov). That makes
the table load-bearing: if a default moves, the gate silently changes scale and the
rejection behaviour changes with it. R3_NEXT_STEPS P1-2 and the deferred WP10b both
propose re-calibrating exactly these numbers, so they need a pin to move against.

The second half checks something the L2 (doppler) work added and that nothing
verified: GnssProcess::ecefToEnuVector rotates an ECEF vector with a hand-written
copy of the ECEF->ENU rotation, while positions go through wgs84ToEnu. If the two
ever disagree, a velocity observation is expressed in a different frame than the
position it is compared against - a systematic error that grows with speed.

Every assertion below is on production code (the real gnss_proc library), so it
cannot drift away from the implementation the way a second copy would.

WHAT THIS DOES NOT COVER - and why (documented, not silently skipped):
the WP2 "synthetic regression guard" from the plan asks for bit-identical
residual/Jacobian between the old and the new time-consistent update path, plus a
falsification where writing state_prop back into _state must fail. There is no new
path: stage 1 measured the residual time misalignment as 0 m, so WP2 was decided
against (EVAL_PROTOCOL section 9.6). The invariant that guard was meant to protect
- "state_prop forms the innovation only, the correction always lands on the current
state" - lives inside LIVMapper::updateStateWithGNSS, which cannot be instantiated
without a ROS parameter server (readParameters() calls exit() on missing values).
It is therefore protected by the run-level checker scripts/eval/gnss_time_consistency.py
instead of by a unit test here.

Standalone: no gtest and no ROS node. Built as the `gnss_processing_selftest`
target against the real gnss_proc library and run manually:

    ./devel/lib/fast_livo/gnss_processing_selftest

Exit code 0 = all checks met, 1 = at least one failure.
*/

#include "gnss_processing.h"
#include "gnss_alignment_state.h"

#include <cmath>
#include <cstdio>
#include <cstring>
#include <vector>

namespace
{

int g_failures = 0;

void check(bool ok, const char *what, double got, double want, double tol)
{
  if (!ok)
  {
    std::printf("  FAIL %-52s got %.9g  want %.9g  (tol %.1e)\n", what, got, want, tol);
    g_failures++;
  }
}

void check(bool ok, const char *what)
{
  if (!ok)
  {
    std::printf("  FAIL %s\n", what);
    g_failures++;
  }
}

// Independent geodetic -> ECEF, written from the definition using the class's own
// published constants. Used as the reference frame for the rotation cross-check:
// the point of the test is that the two production paths agree with each other,
// so the reference must not come from either of them.
V3D geodeticToEcef(double lat_deg, double lon_deg, double alt)
{
  const double lat = lat_deg * M_PI / 180.0;
  const double lon = lon_deg * M_PI / 180.0;
  const double sl = std::sin(lat), cl = std::cos(lat);
  const double so = std::sin(lon), co = std::cos(lon);
  const double N = GnssProcess::WGS84_A / std::sqrt(1.0 - GnssProcess::WGS84_E2 * sl * sl);
  return V3D((N + alt) * cl * co,
             (N + alt) * cl * so,
             (N * (1.0 - GnssProcess::WGS84_E2) + alt) * sl);
}

struct Origin
{
  const char *name;
  double lat, lon, alt;
};

// The GREAT campus sites are mid-latitude; the rest keep the checks honest for a
// frame whose origin is far from where the local tangent plane behaves simply.
const Origin kOrigins[] = {
    {"GREAT campus-01     ", 30.5, 114.3, 30.0},
    {"midlat-N           ", 45.0, 90.0, 0.0},
    {"midlat-S           ", -33.9, 151.2, 50.0},
    {"equator  lon=+120  ", 0.0, 120.0, 0.0},
    {"highlat-N          ", 70.0, 20.0, 0.0},
    {"nearpole-S         ", -89.9, -30.0, 0.0},
};

} // namespace

int main()
{
  // ---------------------------------------------------------------------------
  std::printf("=== (1) fix-type noise table: the gate's absolute scale ===\n");
  // These are the values calibrated against GREAT campus-02 and hard-coded before
  // R3-WP10a parameterised them. Changing any of them changes how many fix epochs
  // the gate accepts (EVAL_PROTOCOL 12.2: the c01 anchor-relative innovation median
  // is 2.5 m, so the 1.2 m table value is what makes the gate reject ~65% there).
  {
    GnssProcess gp;
    struct Row { int code; const char *name; double h; };
    const Row rows[] = {
        {GNSS_RTK_FIXED,   "RTK fixed (5)  ", 1.2},
        {GNSS_PHASE_FIX,   "phase fix (4)  ", 1.2},  // same bucket as fixed, by design
        {GNSS_PHASE_FLOAT, "phase float (2)", 2.5},
        {GNSS_DGPS,        "DGPS (1)       ", 3.0},
        {GNSS_SINGLE,      "single (0)     ", 5.0},
        {GNSS_NO_FIX,      "no fix (-1)    ", 100.0}, // invalid -> effectively excluded
        {3,                "unknown code 3 ", 100.0},
    };
    for (const Row &r : rows)
    {
      const double h = gp.getHorizontalCov(r.code);
      const double v = gp.getVerticalCov(r.code);
      check(std::fabs(h - r.h) < 1e-12, r.name, h, r.h, 1e-12);
      check(std::fabs(v - 1.8 * r.h) < 1e-12, "  vertical = 1.8 x horizontal", v, 1.8 * r.h, 1e-12);
      std::printf("  %s horizontal %6.2f m   vertical %6.2f m\n", r.name, h, v);
    }
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (2) table plumbing: yaml override and sigma override ===\n");
  {
    GnssProcess gp;
    // setSigmaTable is what gnss/sigma_fixed|float|dgps|single drives (WP10a).
    gp.setSigmaTable(2.0, 3.5, 4.0, 6.0);
    check(std::fabs(gp.getHorizontalCov(GNSS_RTK_FIXED) - 2.0) < 1e-12, "setSigmaTable fixed", gp.getHorizontalCov(GNSS_RTK_FIXED), 2.0, 1e-12);
    check(std::fabs(gp.getHorizontalCov(GNSS_PHASE_FLOAT) - 3.5) < 1e-12, "setSigmaTable float", gp.getHorizontalCov(GNSS_PHASE_FLOAT), 3.5, 1e-12);
    check(std::fabs(gp.getHorizontalCov(GNSS_DGPS) - 4.0) < 1e-12, "setSigmaTable dgps", gp.getHorizontalCov(GNSS_DGPS), 4.0, 1e-12);
    check(std::fabs(gp.getHorizontalCov(GNSS_SINGLE) - 6.0) < 1e-12, "setSigmaTable single", gp.getHorizontalCov(GNSS_SINGLE), 6.0, 1e-12);

    // gnss/horiz_sigma|vert_sigma (<= 0 = off) replaces the whole table; the
    // documented contract is that a non-positive value keeps the table.
    check(!gp.hasSigmaOverride(), "no override reported before it is set");
    gp.setSigmaOverride(0.3, 0.6);
    check(gp.hasSigmaOverride(), "override reported once set");
    check(std::fabs(gp.getHorizontalCov(GNSS_SINGLE) - 0.3) < 1e-12, "override beats the table (h)", gp.getHorizontalCov(GNSS_SINGLE), 0.3, 1e-12);
    check(std::fabs(gp.getVerticalCov(GNSS_SINGLE) - 0.6) < 1e-12, "override beats the table (v)", gp.getVerticalCov(GNSS_SINGLE), 0.6, 1e-12);
    gp.setSigmaOverride(-1.0, -1.0);
    check(!gp.hasSigmaOverride(), "override cleared by a non-positive value");
    check(std::fabs(gp.getHorizontalCov(GNSS_SINGLE) - 6.0) < 1e-12, "table restored after clearing", gp.getHorizontalCov(GNSS_SINGLE), 6.0, 1e-12);
    std::printf("  table plumbing OK (setSigmaTable, setSigmaOverride, hasSigmaOverride)\n");
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (3) fix status acceptance ===\n");
  {
    GnssProcess gp;
    // The project's codes are NOT the ROS NavSatFix statuses (WP10a): 5 = Q-flag
    // Fixed, 2 = everything else, 4 = extra phase-fixed code. Single point (0) is
    // accepted - report P1-8 flags that, and WP10b would raise the floor via
    // gnss/min_fix_status; this pin records today's contract.
    for (int code : {0, 1, 2, 4, 5})
      check(gp.isFixValid(code) && gp.isFixGoodEnoughForInit(code), "status accepted", (double)code, 0.0, 0.0);
    for (int code : {-1, -2})
      check(!gp.isFixValid(code) && !gp.isFixGoodEnoughForInit(code), "status rejected", (double)code, -1.0, 0.0);
    std::printf("  accepted 0/1/2/4/5, rejected -1/-2\n");
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (4) ECEF->ENU rotation: velocity path vs position path ===\n");
  // A velocity is a free vector, so ecefToEnuVector applies only the rotation while
  // wgs84ToEnu applies the same rotation to an ECEF difference. Both must therefore
  // map the same ECEF delta to the same ENU vector, or the L2 velocity rows compare
  // antenna velocity against the state in a rotated frame.
  {
    const double kEnuOffset[][3] = {
        {0.0, 0.0, 0.0},       {10.0, 0.0, 0.0},      {0.0, 10.0, 0.0},
        {0.0, 0.0, 10.0},      {-100.0, 250.0, 0.0},  {250.0, -100.0, 3000.0},
        {1000.0, 1000.0, 100.0}, {-100000.0, 100000.0, 1000.0},
    };
    double max_frame = 0.0, max_phys = 0.0;
    for (const Origin &o : kOrigins)
    {
      GnssProcess gp;
      gp.setOrigin(o.lat, o.lon, o.alt);
      const V3D ecef0 = geodeticToEcef(o.lat, o.lon, o.alt);

      for (const auto &d : kEnuOffset)
      {
        double lat = 0.0, lon = 0.0, alt = 0.0;
        gp.enuToWgs84(d[0], d[1], d[2], lat, lon, alt);

        const V3D d_ecef = geodeticToEcef(lat, lon, alt) - ecef0;
        double ve = 0.0, vn = 0.0, vu = 0.0;
        gp.ecefToEnuVector(d_ecef(0), d_ecef(1), d_ecef(2), ve, vn, vu);

        double pe = 0.0, pn = 0.0, pu = 0.0;
        gp.wgs84ToEnu(lat, lon, alt, pe, pn, pu);

        // (a) the two paths must agree with each other (frame consistency)
        const double df = std::sqrt((ve - pe) * (ve - pe) + (vn - pn) * (vn - pn) + (vu - pu) * (vu - pu));
        // (b) and both must reproduce the ENU offset they were built from
        const double dp = std::sqrt((ve - d[0]) * (ve - d[0]) + (vn - d[1]) * (vn - d[1]) + (vu - d[2]) * (vu - d[2]));
        if (df > max_frame) max_frame = df;
        if (dp > max_phys) max_phys = dp;

        const double kFrameTol = 1e-4;   // metres - a broken rotation gives metres here
        const double kPhysTol = 1e-3;    // metres - same tolerance as the WP6 round trip
        char what[160];
        std::snprintf(what, sizeof(what), "%s offset(%.0f,%.0f,%.0f) frame agreement",
                      o.name, d[0], d[1], d[2]);
        check(df <= kFrameTol, what, df, 0.0, kFrameTol);
        std::snprintf(what, sizeof(what), "%s offset(%.0f,%.0f,%.0f) physical ENU",
                      o.name, d[0], d[1], d[2]);
        check(dp <= kPhysTol, what, dp, 0.0, kPhysTol);
      }
    }
    std::printf("  max |velocity-path - position-path| = %.6g m  (tol 1e-4 m)\n", max_frame);
    std::printf("  max |ENU recovered  - ENU requested| = %.6g m  (tol 1e-3 m)\n", max_phys);
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (5) a velocity observation, end to end in ENU ===\n");
  // The form the L2 rows actually use: two antenna positions 0.1 s apart while
  // driving east at 10 m/s. The ENU velocity from the position path and from the
  // ECEF-difference rotation must both be (10, 0, 0) - the check that the velocity
  // observation is expressed in the same frame as the position it is fused with.
  {
    GnssProcess gp;
    gp.setOrigin(30.5, 114.3, 30.0);
    const V3D ecef0 = geodeticToEcef(30.5, 114.3, 30.0);

    const double kDt = 0.1, kSpeed = 10.0;
    double lat0 = 0.0, lon0 = 0.0, alt0 = 0.0, lat1 = 0.0, lon1 = 0.0, alt1 = 0.0;
    gp.enuToWgs84(0.0, 0.0, 0.0, lat0, lon0, alt0);
    gp.enuToWgs84(kSpeed * kDt, 0.0, 0.0, lat1, lon1, alt1);

    double e0 = 0.0, n0 = 0.0, u0 = 0.0, e1 = 0.0, n1 = 0.0, u1 = 0.0;
    gp.wgs84ToEnu(lat0, lon0, alt0, e0, n0, u0);
    gp.wgs84ToEnu(lat1, lon1, alt1, e1, n1, u1);

    const V3D d_ecef = geodeticToEcef(lat1, lon1, alt1) - geodeticToEcef(lat0, lon0, alt0);
    double ve = 0.0, vn = 0.0, vu = 0.0;
    gp.ecefToEnuVector(d_ecef(0), d_ecef(1), d_ecef(2), ve, vn, vu);

    const double pos_v_e = (e1 - e0) / kDt, pos_v_n = (n1 - n0) / kDt;
    check(std::fabs(ve / kDt - kSpeed) < 1e-6, "ECEF-difference rotation gives east 10 m/s", ve / kDt, kSpeed, 1e-6);
    check(std::fabs(vn / kDt) < 1e-6, "ECEF-difference rotation gives north 0 m/s", vn / kDt, 0.0, 1e-6);
    check(std::fabs(vu / kDt) < 1e-6, "ECEF-difference rotation gives up 0 m/s", vu / kDt, 0.0, 1e-6);
    check(std::fabs(pos_v_e - kSpeed) < 1e-6, "position path gives east 10 m/s", pos_v_e, kSpeed, 1e-6);
    check(std::fabs(pos_v_n) < 1e-6, "position path gives north 0 m/s", pos_v_n, 0.0, 1e-6);
    std::printf("  east 10 m/s -> velocity path (%.9f, %.9f, %.9f), position path (%.9f, %.9f)\n",
                ve / kDt, vn / kDt, vu / kDt, pos_v_e, pos_v_n);
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (6) no origin set: silent zeros, not garbage ===\n");
  // gnss_cbk sets the origin from the first accepted fix; before that every
  // conversion must return zeros, because callers use the values unconditionally.
  {
    GnssProcess gp;
    check(!gp.isOriginSet(), "a fresh process reports no origin");
    double e = 1.0, n = 2.0, u = 3.0;
    gp.wgs84ToEnu(30.5, 114.3, 30.0, e, n, u);
    check(e == 0.0 && n == 0.0 && u == 0.0, "wgs84ToEnu without origin returns zeros");
    gp.ecefToEnuVector(1.0, 2.0, 3.0, e, n, u);
    check(e == 0.0 && n == 0.0 && u == 0.0, "ecefToEnuVector without origin returns zeros");
    double lat = 1.0, lon = 2.0, alt = 3.0;
    gp.enuToWgs84(1.0, 2.0, 3.0, lat, lon, alt);
    check(lat == 0.0 && lon == 0.0 && alt == 0.0, "enuToWgs84 without origin returns zeros");
    std::printf("  unset origin -> zeros for all four conversions\n");
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (7) bounded physical drift account (R3 P1-3 / A3-2) ===\n");
  // The P1-3 prior feeds the update's S/K from a drift ACCOUNT: gnssDriftGrow
  // accrues b*dt per inter-fix interval (capped at sigma_max), gnssDriftPay
  // pays an accepted epoch's account down by the correction it applied, and
  // gnssDriftSigmaOf applies the floor a. Contracts pinned here:
  //  - grow is monotonically non-decreasing in dt and capped, and a negative dt
  //    (out-of-order fix) must act as 0 - a negative contribution would SHRINK
  //    the account below what the propagation already knows;
  //  - pay never goes below 0 and never credits more than was applied;
  //  - sigma_of is max(a, acc) - the freshly-corrected floor.
  {
    const double b = 0.004, smax = 0.8, a = 0.0;
    check(std::fabs(gnssDriftGrow(0.0, b, 0.0, smax) - 0.0) < 1e-12,
          "grow over dt=0 accrues nothing", gnssDriftGrow(0.0, b, 0.0, smax), 0.0, 1e-12);
    check(std::fabs(gnssDriftGrow(0.0, b, 100.0, smax) - 0.4) < 1e-12,
          "grow over 100 s at b=0.004 accrues 0.4 m", gnssDriftGrow(0.0, b, 100.0, smax), 0.4, 1e-12);
    check(std::fabs(gnssDriftGrow(0.7, b, 100.0, smax) - smax) < 1e-12,
          "grow is capped at sigma_max", gnssDriftGrow(0.7, b, 100.0, smax), smax, 1e-12);
    check(gnssDriftGrow(0.1, b, -3.0, smax) == gnssDriftGrow(0.1, b, 0.0, smax),
          "negative dt is clamped, the account never shrinks by accident");
    bool mono = true;
    for (int k = 1; k < 40; k++)
      if (gnssDriftGrow(0.0, b, 2.5 * k, smax) < gnssDriftGrow(0.0, b, 2.5 * (k - 1), smax))
        mono = false;
    check(mono, "grow is monotonically non-decreasing in dt");
    check(std::fabs(gnssDriftGrow(0.0, b, 1000.0, 0.0) - 4.0) < 1e-12,
          "sigma_max=0 disables the cap", gnssDriftGrow(0.0, b, 1000.0, 0.0), 4.0, 1e-12);
    check(std::fabs(gnssDriftPay(0.4, 0.019) - 0.381) < 1e-12,
          "pay subtracts exactly what was applied", gnssDriftPay(0.4, 0.019), 0.381, 1e-12);
    check(gnssDriftPay(0.4, 0.5) == 0.0, "an overpay zeroes the account, never negative");
    check(gnssDriftPay(0.0, 0.01) == 0.0, "paying an empty account stays at zero");
    check(std::fabs(gnssDriftSigmaOf(0.381, 0.05) - 0.381) < 1e-12,
          "sigma_of keeps the account above the floor", gnssDriftSigmaOf(0.381, 0.05), 0.381, 1e-12);
    check(std::fabs(gnssDriftSigmaOf(0.01, 0.05) - 0.05) < 1e-12,
          "sigma_of enforces the freshly-corrected floor", gnssDriftSigmaOf(0.01, 0.05), 0.05, 1e-12);
    // the transient scenario the account exists for: 65 s uncorrected while a
    // ~5e-4 gain applies 2 mm per accepted epoch. Exact bookkeeping: each cycle
    // accrues 4 mm and pays 2 mm -> acc = 65*2 mm = 0.13 m, far above the ~0.05
    // m ceiling the vA reset-to-anchor semantics could never exceed.
    double acc = 0.0;
    for (int k = 0; k < 65; k++) acc = gnssDriftPay(gnssDriftGrow(acc, b, 1.0, smax), 0.002);
    check(std::fabs(acc - 0.13) < 1e-9, "65 accrue/pay cycles net 65*2 mm", acc, 0.13, 1e-9);
    check(acc > 0.1, "account stays far above the vA reset ceiling (~0.05 m)");
    std::printf("  grow/pay/sigma_of pinned; 65 s uncorrected at |dx|=2 mm -> acc=%.3f m\n", acc);
  }

  // ---------------------------------------------------------------------------
  std::printf("\n=== (8) T1-4 alignment-state filter: H_a / update / clamps / freeze ===\n");
  // The alignment-state unit (include/gnss_alignment_state.h) is exercised here
  // because LIVMapper cannot be instantiated outside ROS (see the note at the
  // top). Pins, each with the falsification that must fail:
  //  (a) H_a structure: yaw lever k^ x (R enu), translation only in the
  //      horizontal position rows, vertical row zero, velocity rows yaw-only,
  //      anchored mode zeroes the translation columns;
  //  (b) the update algebra on a hand-checkable case (P=I, S=10I -> da=res/10,
  //      posterior 0.9I);
  //  (c) the per-epoch clamps;
  //  (d) a FROZEN epoch (report hold) leaves P bitwise unchanged - the review
  //      fix for "freezing Q alone cannot freeze the state" (T1_4_DESIGN 10.1);
  //  (e) the random-walk accrual and its frozen time bookkeeping;
  //  (f) the corrected steady state P_ss = q*sigma*sqrt(dt) (T1_4_DESIGN 10.2 -
  //      the first draft had a dimensional error and overestimated the
  //      tracking capability 10x).
  {
    using Eigen::MatrixXd;
    using Eigen::VectorXd;
    using Eigen::Vector3d;

    // (a) H_a structure
    {
      const Vector3d v_pos(3.0, 4.0, 5.0), v_vel(1.0, 2.0, 3.0);
      const MatrixXd H6 = GnssAlignState::haMatrix(v_pos, true, v_vel, true);
      check(H6.rows() == 6 && H6.cols() == 3, "H_a is n_obs x 3 (6x3 with velocity)");
      check(H6(0, 0) == -4.0 && H6(0, 1) == 1.0 && H6(0, 2) == 0.0, "H_a pos E row", H6(0, 0), -4.0, 1e-12);
      check(H6(1, 0) == 3.0 && H6(1, 1) == 0.0 && H6(1, 2) == 1.0, "H_a pos N row", H6(1, 0), 3.0, 1e-12);
      check(H6(2, 0) == 0.0 && H6(2, 1) == 0.0 && H6(2, 2) == 0.0, "H_a vertical row is zero");
      check(H6(3, 0) == -2.0 && H6(3, 1) == 0.0 && H6(3, 2) == 0.0, "H_a vel E row (yaw only)", H6(3, 0), -2.0, 1e-12);
      check(H6(4, 0) == 1.0 && H6(4, 1) == 0.0 && H6(4, 2) == 0.0, "H_a vel N row (yaw only)", H6(4, 0), 1.0, 1e-12);
      check(H6(5, 0) == 0.0 && H6(5, 1) == 0.0 && H6(5, 2) == 0.0, "H_a vel vertical row is zero");
      const MatrixXd H3a = GnssAlignState::haMatrix(v_pos, false, v_vel, false);
      check(H3a(0, 1) == 0.0 && H3a(1, 2) == 0.0, "anchored mode zeroes the translation columns");
      check(H3a(0, 0) == -4.0 && H3a(1, 0) == 3.0, "anchored mode keeps the yaw lever", H3a(0, 0), -4.0, 1e-12);
    }

    // (b) update algebra on a hand-checkable case
    GnssAlignState f;
    f.initAtLock(1.0, 1.0, 0.0); // P = I
    {
      const MatrixXd H_a = MatrixXd::Identity(3, 3);
      const MatrixXd S = 10.0 * MatrixXd::Identity(3, 3); // H P H' + R with R = 9I
      VectorXd res(3);
      res << 1.0, 2.0, 3.0;
      const Vector3d da = f.update(H_a, S, res, 0.0, 0.0, 0.0, 0.0, 0.0, false);
      check(std::fabs(da(0) - 0.1) < 1e-12, "update da(0) = res/10", da(0), 0.1, 1e-12);
      check(std::fabs(da(1) - 0.2) < 1e-12, "update da(1) = res/10", da(1), 0.2, 1e-12);
      check(std::fabs(da(2) - 0.3) < 1e-12, "update da(2) = res/10", da(2), 0.3, 1e-12);
      check(std::fabs(f.P(0, 0) - 0.9) < 1e-12, "posterior P(0,0) = 0.9 I", f.P(0, 0), 0.9, 1e-12);
      check(std::fabs(f.P(1, 2)) < 1e-15, "posterior stays diagonal in the orthogonal case");
    }

    // (c) clamps, K-CONSISTENT (redesign): the posterior must reflect the
    // correction actually applied - the fold-rate cap binds often on degraded
    // datasets, and an unscaled posterior would collapse as if the full
    // correction had been taken.
    {
      GnssAlignState g;
      g.initAtLock(1.0, 1.0, 0.0);
      const MatrixXd H_a = MatrixXd::Identity(3, 3);
      const MatrixXd S = 10.0 * MatrixXd::Identity(3, 3);
      VectorXd res(3);
      res << 1.0, 2.0, 3.0; // raw da = (0.1, 0.2, 0.3)
      const Vector3d da = g.update(H_a, S, res, 0.05, 0.25, 0.0, 0.0, 0.0, false);
      check(std::fabs(da(0) - 0.05) < 1e-12, "yaw clamp |dpsi| <= 0.05 rad", da(0), 0.05, 1e-12);
      const double n = std::sqrt(da(1) * da(1) + da(2) * da(2));
      check(std::fabs(n - 0.25) < 1e-12, "translation clamp |dt| <= 0.25 m", n, 0.25, 1e-12);
      check(std::fabs(da(1) - 0.2 * 0.25 / std::sqrt(0.13)) < 1e-12, "clamp preserves the direction", da(1), 0.2 * 0.25 / std::sqrt(0.13), 1e-12);
      // K-consistent posterior: rows scaled by s0 = 0.5, sT = 0.25/sqrt(0.13)
      const double sT = 0.25 / std::sqrt(0.13);
      check(std::fabs(g.P(0, 0) - 0.95) < 1e-12, "posterior reflects the clamped yaw step", g.P(0, 0), 0.95, 1e-12);
      check(std::fabs(g.P(1, 1) - (1.0 - 0.1 * sT)) < 1e-12, "posterior reflects the clamped translation step", g.P(1, 1), 1.0 - 0.1 * sT, 1e-12);
    }

    // (c2) fold-rate cap (redesign (c)): |dt_fold| <= rate*dt even when the
    // absolute step cap would allow far more.
    {
      GnssAlignState h2;
      h2.initAtLock(1.0, 1.0, 0.0);
      const MatrixXd H_a = MatrixXd::Identity(3, 3);
      const MatrixXd S = 10.0 * MatrixXd::Identity(3, 3);
      VectorXd res(3);
      res << 0.0, 0.2, 0.3; // K_a = 0.1 I -> raw translation step |dt| = 0.0361 m
      const Vector3d da = h2.update(H_a, S, res, 10.0, 10.0, 0.0, 0.004, 1.0, false);
      const double n = std::sqrt(da(1) * da(1) + da(2) * da(2));
      check(std::fabs(n - 0.004) < 1e-12, "fold-rate cap limits |dt| to rate*dt", n, 0.004, 1e-12);
      check(std::fabs(da(1) - 0.02 * 0.004 / std::sqrt(0.0004 + 0.0009)) < 1e-12, "fold-rate cap preserves direction", da(1), 0.02 * 0.004 / std::sqrt(0.0004 + 0.0009), 1e-12);
      // a huge innovation still cannot be swallowed: the cap is the mechanism
      VectorXd res_big(3);
      res_big << 0.0, 20.0, 30.0;
      const Vector3d da_big = h2.update(H_a, S, res_big, 10.0, 10.0, 0.0, 0.004, 1.0, false);
      check(std::sqrt(da_big(1) * da_big(1) + da_big(2) * da_big(2)) <= 0.004 + 1e-12,
            "a 36 m innovation still folds <= rate*dt (circularity impossible)");
    }

    // (c3) authority cap (redesign (b')): P <= kmax/(1-kmax)*R_eff, so
    // K = P/(P+R) <= kmax holds structurally (the c03 failure: 8 m^2 of prior
    // against 0.09 m^2 of R gave K_a0 = 0.99).
    {
      GnssAlignState k;
      k.initAtLock(20.0 * M_PI / 180.0, 2.83, 0.0); // the c03 lock state: P(1,1)=8.0
      check(std::fabs(k.P(1, 1) - 8.0089) < 1e-3, "init P(1,1) = resid^2 (uncapped)", k.P(1, 1), 8.0089, 1e-3);
      const double kmax = 0.1, r_eff = 0.09; // c03-class adaptive noise scale
      k.capAuthority(kmax / (1.0 - kmax), r_eff);
      const double cap = kmax / (1.0 - kmax) * r_eff;
      check(std::fabs(k.P(1, 1) - cap) < 1e-12, "authority cap limits P(1,1)", k.P(1, 1), cap, 1e-12);
      const double K = k.P(1, 1) / (k.P(1, 1) + r_eff);
      check(std::fabs(K - kmax) < 1e-12, "resulting K equals kmax exactly", K, kmax, 1e-12);
      // on a c01-class scale the cap must NOT bind (P stays far below it)
      GnssAlignState m;
      m.initAtLock(1.0 * M_PI / 180.0, 0.52, 0.0);
      const double p_before = m.P(1, 1);
      m.capAuthority(kmax / (1.0 - kmax), 4.35 * 4.35);
      check(std::fabs(m.P(1, 1) - p_before) < 1e-15, "cap does not bind on a c01-class scale", m.P(1, 1), p_before, 1e-15);
    }

    // (d) frozen epoch: P bitwise unchanged, da exactly zero
    {
      GnssAlignState h;
      h.initAtLock(0.7, 1.3, 0.0);
      h.propagate(1.0, 1e-4, 1e-4, false); // give P a non-trivial, known state
      unsigned char before[sizeof(Eigen::Matrix3d)];
      std::memcpy(before, h.P.data(), sizeof(before));
      h.propagate(2.0, 1e-4, 1e-4, true); // frozen epoch advances last_t only
      const MatrixXd H_a = MatrixXd::Identity(3, 3);
      const MatrixXd S = MatrixXd::Identity(3, 3);
      VectorXd res(3);
      res << 100.0, 200.0, 300.0; // a huge innovation must change nothing
      const Vector3d da = h.update(H_a, S, res, 10.0, 10.0, 10.0, 10.0, 1.0, true);
      check(da(0) == 0.0 && da(1) == 0.0 && da(2) == 0.0, "frozen update returns exactly zero");
      unsigned char after[sizeof(Eigen::Matrix3d)];
      std::memcpy(after, h.P.data(), sizeof(after));
      check(std::memcmp(before, after, sizeof(before)) == 0,
            "FROZEN epoch leaves P bitwise unchanged (review 10.1)");
      // and the post-freeze walk does not include the frozen span:
      const double p0 = h.P(1, 1);
      h.propagate(3.0, 1e-2, 1e-2, false); // dt = 1 s (2->3), NOT 2 s (1->3)
      check(std::fabs(h.P(1, 1) - (p0 + 1e-2)) < 1e-15,
            "frozen time contributes no process noise after release", h.P(1, 1), p0 + 1e-2, 1e-15);
    }

    // (e) unfrozen accrual
    {
      GnssAlignState k;
      k.initAtLock(0.0, 0.0, 10.0); // P = 0
      k.propagate(12.5, 4e-4, 9e-3, false);
      check(std::fabs(k.P(0, 0) - 4e-4 * 2.5) < 1e-18, "yaw Q accrues q*dt", k.P(0, 0), 4e-4 * 2.5, 1e-18);
      check(std::fabs(k.P(1, 1) - 9e-3 * 2.5) < 1e-18, "position Q accrues q*dt", k.P(1, 1), 9e-3 * 2.5, 1e-18);
      check(std::fabs(k.last_t - 12.5) < 1e-18, "last_t advances to the evaluated epoch");
    }

    // (f) steady state of the corrected math: P_ss = q*sigma*sqrt(dt)
    // scalar walk P' = P - P^2/(P+R) + Q iterated to convergence; the exact
    // root is (Q + sqrt(Q^2 + 4*Q*R))/2 = 0.28005 for q=0.01, sigma=28, dt=1
    // (the closed form q*sigma = 0.28 is the design-doc approximation).
    {
      const double Q = 1e-4, R = 28.0 * 28.0;
      double P = 1.0; // sigma_t0 = 1 m
      for (int i = 0; i < 20000; i++)
      {
        const double K = P / (P + R);
        P = (1.0 - K) * P + Q;
      }
      check(std::fabs(P - 0.28005) < 1e-3, "scalar walk converges to the corrected P_ss", P, 0.28005, 1e-3);
      std::printf("  steady state P_ss = %.5f m^2 (closed form 0.28005; first draft wrongly said 2.8)\n", P);
    }
    std::printf("  alignment-state unit pinned (H_a, algebra, clamps, freeze, walk)\n");
  }

  std::printf("\n%s (%d failure%s)\n", g_failures == 0 ? "ALL PASS" : "FAILED",
              g_failures, g_failures == 1 ? "" : "s");
  return g_failures == 0 ? 0 : 1;
}
