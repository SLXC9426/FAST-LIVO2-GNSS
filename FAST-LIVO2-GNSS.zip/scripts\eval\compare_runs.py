#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Per-epoch comparison of several runs against one reference.

The aggregate APE in eval_unified.py tells you that a run is worse, not where.
This tool aligns each trajectory to the reference (2D similarity: yaw +
translation, or full SE(3) with --se3) and prints the error in time buckets, so
the epoch where a fusion starts to diverge is visible directly. It also reports
each trajectory's own extent and path length, which exposes a trajectory that
tracked a different part of the route.

Usage:
  compare_runs.py <reference.tum> <traj> [<traj> ...] [--se3] [--buckets N]
"""
import sys
import numpy as np


def load_tum(p):
    t, x = [], []
    for l in open(p):
        q = l.split()
        if len(q) >= 4:
            try:
                t.append(float(q[0]))
                x.append([float(q[1]), float(q[2]), float(q[3])])
            except ValueError:
                pass
    return np.array(t), np.array(x)


def umeyama2d(src, dst):
    ms, md = src[:, :2].mean(0), dst[:, :2].mean(0)
    H = (src[:, :2] - ms).T @ (dst[:, :2] - md)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R2 = Vt.T @ np.diag([1, d]) @ U.T
    R = np.eye(3)
    R[:2, :2] = R2
    return R, np.array([md[0], md[1], 0.0]) - R @ np.array([ms[0], ms[1], 0.0])


def umeyama3d(src, dst):
    ms, md = src.mean(0), dst.mean(0)
    H = (src - ms).T @ (dst - md)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1, 1, d]) @ U.T
    return R, md - R @ ms


def main():
    a = sys.argv[1:]
    if len(a) < 2:
        print(__doc__)
        return 1
    ref = a[0]
    trajs = []
    se3 = False
    nb = 10
    i = 1
    while i < len(a):
        if a[i] == "--se3":
            se3 = True; i += 1
        elif a[i] == "--buckets":
            nb = int(a[i + 1]); i += 2
        else:
            trajs.append(a[i]); i += 1

    rt, rp = load_tum(ref)
    print("reference: %d poses, t %.3f..%.3f" % (len(rt), rt[0], rt[-1]))
    align = umeyama3d if se3 else umeyama2d

    for p in trajs:
        t, x = load_tum(p)
        if len(t) < 20:
            print("%-28s !! only %d poses" % (p.split('/')[-1], len(t)))
            continue
        ir = np.array([int(np.argmin(np.abs(rt - v))) for v in t])
        ok = np.abs(rt[ir] - t) < 0.25
        R, tr = align(x[ok], rp[ir][ok])
        al = (R @ x.T).T + tr
        e3 = np.linalg.norm(al[ok] - rp[ir][ok], axis=1)
        e2 = np.linalg.norm(al[ok][:, :2] - rp[ir][ok][:, :2], axis=1)
        plen = np.sum(np.linalg.norm(np.diff(x[:, :2], axis=0), axis=1))
        span = np.linalg.norm(x[:, :2].max(0) - x[:, :2].min(0))
        print("\n%-28s n=%d  span=%.1fm path=%.1fm  paired=%d/%d" %
              (p.split('/')[-1], len(t), span, plen, ok.sum(), len(t)))
        print("   APE 3D %.4f  2D %.4f  (2D mean %.3f max %.3f)" %
              (np.sqrt((e3 ** 2).mean()), np.sqrt((e2 ** 2).mean()), e2.mean(), e2.max()))

        # time buckets
        t0, t1 = t[ok][0], t[ok][-1]
        edges = np.linspace(t0, t1, nb + 1)
        row = []
        for k in range(nb):
            m = (t[ok] >= edges[k]) & (t[ok] < edges[k + 1])
            row.append("%.2f" % np.sqrt((e2[m] ** 2).mean()) if m.sum() else "  - ")
        print("   2D per %gs: %s" % (round((t1 - t0) / nb), " ".join(row)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
