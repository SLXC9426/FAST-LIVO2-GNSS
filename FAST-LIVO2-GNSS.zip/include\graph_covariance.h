#ifndef GRAPH_COVARIANCE_H
#define GRAPH_COVARIANCE_H

// Coordinate transforms for the graph's marginal covariances.
//
// GTSAM Pose3 uses the local/body tangent order [rotation, translation]. ROS
// PoseWithCovariance uses [x,y,z,roll,pitch,yaw] expressed in header.frame_id
// (ENU for the online graph). The transform is not just a block swap:
//   delta_p_enu   = R_enu_body * delta_p_body
//   delta_theta_enu = R_enu_body * delta_theta_body
// so both the diagonal and cross blocks must be rotated.
//
// Velocity nodes are ENU; nav_msgs/Odometry expects the twist in the child
// (body) frame, hence P_body = R_body_enu * P_enu * R_enu_body.

#include <Eigen/Dense>

namespace fast_livo
{

inline Eigen::Matrix<double, 6, 6> poseCovarianceToEnu(
    const Eigen::Matrix<double, 6, 6> &P_local,
    const Eigen::Matrix3d &R_enu_body)
{
  const Eigen::Matrix3d &R = R_enu_body;
  Eigen::Matrix<double, 6, 6> P;
  // P_local order: [rot, trans]. Output order: [trans, rot].
  P.block<3, 3>(0, 0) = R * P_local.block<3, 3>(3, 3) * R.transpose();
  P.block<3, 3>(0, 3) = R * P_local.block<3, 3>(3, 0) * R.transpose();
  P.block<3, 3>(3, 0) = R * P_local.block<3, 3>(0, 3) * R.transpose();
  P.block<3, 3>(3, 3) = R * P_local.block<3, 3>(0, 0) * R.transpose();
  return P;
}

inline Eigen::Matrix3d velocityCovarianceToBody(
    const Eigen::Matrix3d &P_enu, const Eigen::Matrix3d &R_enu_body)
{
  return R_enu_body.transpose() * P_enu * R_enu_body;
}

// R5.3: the joint boundary prior stores pose covariance in the GTSAM body
// tangent [rot, trans_body] and velocity in ENU. BoundaryJointFactor's residual
// is [rot, t_enu, v_enu], so the position block (and the pose-velocity cross
// block) must be rotated into ENU before constructing the Gaussian noise model:
//   A = diag(I3, R_enu_body, I3),  P_residual = A P_joint A^T.
inline Eigen::Matrix<double, 9, 9> boundaryJointCovarianceToEnu(
    const Eigen::Matrix<double, 6, 6> &cov_pose,
    const Eigen::Matrix<double, 3, 3> &cov_vel,
    const Eigen::Matrix<double, 6, 3> &cov_pose_vel,
    const Eigen::Matrix3d &R_enu_body)
{
  Eigen::Matrix<double, 9, 9> P = Eigen::Matrix<double, 9, 9>::Zero();
  P.block<6, 6>(0, 0) = cov_pose;
  P.block<3, 3>(6, 6) = cov_vel;
  P.block<6, 3>(0, 6) = cov_pose_vel;
  P.block<3, 6>(6, 0) = cov_pose_vel.transpose();

  Eigen::Matrix<double, 9, 9> A = Eigen::Matrix<double, 9, 9>::Identity();
  A.block<3, 3>(3, 3) = R_enu_body;
  return A * P * A.transpose();
}

}  // namespace fast_livo

#endif  // GRAPH_COVARIANCE_H
