# A0/A1 evaluation

reference: `/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data/campus02_reference.tum`

| arm | rows | matched | ATE med/p95/RMSE (m) | abs 2D RMSE | abs 3D RMSE | abs p95 | 2D RMSE after constant-bias removal | RPE1 RMSE | RPE10 RMSE |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| A0 | 805 | 805 | 1.055 / 2.872 / 1.508 | 4.210 | 4.281 | 5.760 | 0.997 | 0.190 | 0.972 |
| A1 | 805 | 805 | 0.604 / 1.912 / 1.010 | 4.049 | 4.093 | 5.014 | 0.690 | 0.186 | 0.886 |

## Segment absolute 2D / 3D / bias-removed 2D RMSE (m)

| arm | 0-115s | 150-270s | 270-420s |
|---|---|---|---|
| A0 | 4.244 / 4.249 / 0.336 | 4.721 / 4.795 / 1.367 | 3.590 / 3.832 / 0.934 |
| A1 | 3.361 / 3.368 / 0.667 | 4.081 / 4.105 / 0.499 | 4.164 / 4.322 / 0.463 |

- A0 median ENU bias: E -0.331, N 3.966, U -0.173 m

- A1 median ENU bias: E -0.165, N 4.021, U -0.177 m
