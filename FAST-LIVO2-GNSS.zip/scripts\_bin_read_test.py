#!/usr/bin/env python3
import numpy as np

p = "/home/slxc9426/datasets/GREAT/Lidar/data/1603764571917030144.bin"
npdt = np.dtype([('x', np.float32), ('y', np.float32), ('z', np.float32),
                 ('intensity', np.float32), ('ring', np.uint16), ('time', np.float32)])
scan = np.fromfile(p, dtype=npdt)
print("dtype itemsize:", npdt.itemsize, "npts:", len(scan))
print("time:", scan['time'][:5], "min", scan['time'].min(), "max", scan['time'].max())
print("ring:", np.unique(scan['ring'])[:16], "n:", len(np.unique(scan['ring'])))
t_min = float(np.min(scan['time']))
t2 = (scan['time'] - t_min) * 1e6
print("converted time:", t2.min(), t2.max())
