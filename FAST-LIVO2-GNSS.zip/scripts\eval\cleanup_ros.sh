#!/usr/bin/env bash
# Safe ROS cleanup: run as a script file so pkill -f patterns do not match
# the invoking shell's own command line.
for pat in 'bin/roslaunch' 'bin/rosbag' 'fastlivo_mapping' 'bin/roscore' 'bin/rosmaster' 'bin/rostopic'; do
  pkill -f "$pat" 2>/dev/null
done
sleep 1
echo done
