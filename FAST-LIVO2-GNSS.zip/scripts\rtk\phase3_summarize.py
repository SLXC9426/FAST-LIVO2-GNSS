#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 3: tight vs robust RTK comparison + health extraction."""
import csv
import os
import re
import statistics

REG = "/home/slxc9426/catkin_ws/src/fast_livo/Log/result/registry.csv"
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/metrics"
BASE_TAGS = ["phase0_c01_livo", "phase0_c01_livo_r2", "phase0_c01_livo_r3"]
TIGHT = "phase2_c01_rtk_full1"
ROBUST = "phase3_c01_rtk_robust_full1"
TIGHT90 = "phase3_c01_rtk_tight90"
ROBUST90 = "phase3_c01_rtk_robust90"
LOGS = {
    "tight": "/home/slxc9426/seg_phase2_c01_rtk_full1.log",
    "robust": "/home/slxc9426/seg_phase3_c01_rtk_robust_full1.log",
}
FIELDS = [
    ("r3_full", "full_3D"), ("r2_full", "full_2D"),
    ("r3_steady", "steady_3D"), ("r2_steady", "steady_2D"),
    ("rpe1", "RPE_1s"), ("rpe10", "RPE_10s"),
    ("rpe60", "RPE_60s"), ("rpe120", "RPE_120s"),
    ("r2_statloc", "static_loc_2D"),
]


def parse_health(path):
    acc_re = re.compile(r"\[RTK\] accept t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+)/([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+) "
                        r"\|dx_pos\|=([\d.]+) P_pos=([\d.]+)")
    rej_re = re.compile(r"\[RTK\] reject t=([\d.]+) pairs=(\d+) amb=(\d+) slips=(\d+) "
                        r"gamma=([\d.]+) gate=([\d.]+) \|r_code\|=([\d.]+) \|r_phase\|=([\d.]+)")
    rj_code = re.compile(r"rej_code=(\d+) rej_phase=(\d+)")
    acc, rej, rc, rp = [], [], 0, 0
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            m = acc_re.search(line)
            if m:
                acc.append(dict(t=float(m.group(1)), pairs=int(m.group(2)),
                                amb=int(m.group(3)), slips=int(m.group(4)),
                                gamma=float(m.group(5)), gate=float(m.group(6)),
                                code=float(m.group(7)), phase=float(m.group(8)),
                                dx=float(m.group(9)), ppos=float(m.group(10))))
            m = rej_re.search(line)
            if m:
                rej.append(dict(t=float(m.group(1)), gamma=float(m.group(5)),
                                code=float(m.group(7)), phase=float(m.group(8))))
            m = rj_code.search(line)
            if m:
                rc += int(m.group(1)); rp += int(m.group(2))
    return acc, rej, rc, rp


def main():
    rows = list(csv.DictReader(open(REG, newline="")))
    by = {r["tag"]: r for r in rows}
    base = [by[t] for t in BASE_TAGS if t in by]
    t, r = by.get(TIGHT), by.get(ROBUST)
    if not base or t is None or r is None:
        raise SystemExit("missing registry rows")

    out = [("metric", "baseline_median", "tight", "robust", "robust-tight",
            "robust-baseline")]
    print("metric                 base_med   tight   robust   r-t     r-b")
    for key, label in FIELDS:
        b = statistics.median([float(x[key]) for x in base if x.get(key)])
        tv, rv = float(t[key]), float(r[key])
        out.append((label, f"{b:.4f}", f"{tv:.4f}", f"{rv:.4f}",
                    f"{rv-tv:+.4f}", f"{rv-b:+.4f}"))
        print(f"{label:22s} {b:8.4f} {tv:8.4f} {rv:8.4f} {rv-tv:+8.4f} {rv-b:+8.4f}")
    with open(os.path.join(OUT, "phase3_rtk_comparison.csv"), "w", newline="",
              encoding="utf-8") as f:
        csv.writer(f).writerows(out)

    lines = []
    for name, path in LOGS.items():
        acc, rej, rc, rp = parse_health(path)
        n = len(acc) + len(rej)
        s = (f"{name}: evaluated={n} accepted={len(acc)} rejected={len(rej)} "
             f"acceptance={100.0*len(acc)/max(n,1):.1f}% | "
             f"row rejections code={rc} phase={rp} | "
             f"median accepted |dx_pos|={statistics.median([a['dx'] for a in acc]):.3f} m "
             f"max={max(a['dx'] for a in acc):.3f} m | "
             f"final n_amb={acc[-1]['amb']} slips={sum(a['slips'] for a in acc)}")
        lines.append(s); print(s)

    t90, r90 = by.get(TIGHT90), by.get(ROBUST90)
    if t90 and r90:
        s = (f"90s tight: 3D={float(t90['r3_full']):.4f} 2D={float(t90['r2_full']):.4f} "
             f"RPE1={float(t90['rpe1']):.4f} | robust: 3D={float(r90['r3_full']):.4f} "
             f"2D={float(r90['r2_full']):.4f} RPE1={float(r90['rpe1']):.4f} | "
             f"delta 3D={float(r90['r3_full'])-float(t90['r3_full']):+.4f} "
             f"2D={float(r90['r2_full'])-float(t90['r2_full']):+.4f}")
        lines.append(s); print(s)
    with open(os.path.join(OUT, "phase3_rtk_health.txt"), "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
