#!/usr/bin/env bash
# Quick freeze diagnosis: run urban-01 with different lidar_time_offset,
# report effective feature num and end position.
# usage: bash run_toff.sh <mode: toff-100|toff-50|toff+50|toff+100>
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
MODE=$1
BAG=/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag
rm -f Log/result/great_urban01_$MODE.txt

roslaunch fast_livo mapping_great_urban01.launch mode:=$MODE rviz:=false > /tmp/ur_$MODE.log 2>&1 &
LPID=$!
sleep 18
/opt/ros/noetic/bin/rosbag play -s 170 -u 60 --clock $BAG > /tmp/ur_play_$MODE.log 2>&1
sleep 5
kill $LPID 2>/dev/null
sleep 2

echo "==== $MODE ===="
grep -o 'effective feature num: [0-9]*' /tmp/ur_$MODE.log | awk '{s+=$4; n++} END {if (n>0) printf "mean eff feat: %.1f (n=%d)\n", s/n, n}'
N=$(wc -l < Log/result/great_urban01_$MODE.txt 2>/dev/null || echo 0)
if [ "$N" -gt 1 ]; then
  tail -1 Log/result/great_urban01_$MODE.txt
fi
