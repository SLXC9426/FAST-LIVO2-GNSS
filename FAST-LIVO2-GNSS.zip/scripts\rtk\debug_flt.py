import numpy as np
import pandas as pd
from rtk_preprocess import load_flt_epochs, gps_sow, _dd_geom

CSV = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
FLT = "/home/slxc9426/great_pvt/result/FIXBASE-RTK.flt"
BASE = np.array([-2267749.9279, 5009154.2407, 3221290.6333])

d = pd.read_csv(CSV)
rows = d.to_dict("records")
flt = [x for x in load_flt_epochs(FLT) if x[2] == "Fixed"]
by_t = {}
for r in rows:
    by_t.setdefault(round(r["t_gps"], 3), []).append(r)

for sow, pos, status in flt:
    # find row group with the same sow
    cand = [t for t in by_t if abs(gps_sow(t) - sow) < 0.05]
    if not cand:
        continue
    t = cand[0]
    rr = by_t[t]
    print(f"\nsow={sow:.0f} t={t:.0f} pos={pos}")
    for r in rr:
        if r["sys"] == "G" and r["freq"] == "L1":
            g = _dd_geom(r, pos, BASE)
            print(f"  {r['sat']} ref={r['ref_sat']} dd_phase={r['dd_phase']:10.3f} "
                  f"geom={g:10.3f} raw_res={r['dd_phase']-g:10.3f} "
                  f"slip={r['slip']} gf={r['gf_jump']:.4f}")
