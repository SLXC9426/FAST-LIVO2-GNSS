#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarise the GNSS/EKF time-base misalignment from gnss_poses.txt DT records.

R3 stage 1 (WP1). The gate question is whether the residual fed to the EKF is
formed from a measurement and a state at the same time. Three quantities decide
it, so the report splits the population rather than pooling it:

  fwd=1  t_g > t_lio : Step 1 carries the state forward to t_g, so the residual
                       IS formed at t_g. |dp_prop| should then equal the distance
                       the state travelled, |v|*|dt_g| - printed side by side so
                       the agreement is checked rather than assumed. |v|*|dt_g|
                       here is NOT an innovation error; it is how far the state
                       had to be carried.
  fwd=0  t_g <= t_lio: propagateStateToTime returns immediately, state_prop ==
                       _state, and the residual compares a measurement at t_g
                       against a state at t_lio. THIS is the misalignment the
                       review's P0-2 describes, and only this subset's
                       |v|*|dt_g| enters the innovation as an error.

Usage:
  gnss_dt_stats.py <gnss_poses.txt> [more.txt ...]          # report (WP1)
  gnss_dt_stats.py --check <gnss_poses.txt> [more.txt ...]  # gate, exit 1 on failure

The --check mode exists because the WP2 decision (EVAL_PROTOCOL 9.6: do not build a
time-consistent update path, the residual misalignment measured 0 m) rests on
properties of these records that a future change could silently invalidate. It
asserts, per epoch:

  A1  fwd=1: |dp_prop| matches |v|*|dt_g|      -> the state really was carried to t_g
      (tolerance absorbs the 0.5*a*dt^2 term of the propagation step; the measured
      worst case is 1.71% relative / 6.6 mm, published in EVAL_PROTOCOL 9.2)
  A2  fwd=0: dt_g == 0 and dp_prop == 0        -> nothing to propagate, nothing stale
  A3  no stale fix at all: every dt_g <= 0     -> t_g is never earlier than t_lio.
      If this ever fires, the WP2 premise is real and the decision must be revisited.
  A4  dt_g >= -0.5 s                           -> the forward drain window is bounded

Exit code 0 = all assertions hold (or no records at all, which is reported as such),
1 = at least one assertion failed.
"""
import sys
import math


def pct(vals, q):
    """Linear-interpolation percentile (numpy 'linear' convention), q in [0,100]."""
    if not vals:
        return float('nan')
    s = sorted(vals)
    if len(s) == 1:
        return s[0]
    pos = (len(s) - 1) * q / 100.0
    lo = int(math.floor(pos))
    hi = min(lo + 1, len(s) - 1)
    return s[lo] * (1.0 - (pos - lo)) + s[hi] * (pos - lo)


def line(label, vals, unit, width=15):
    if not vals:
        print("   %-*s (no samples)" % (width, label))
        return
    print("   %-*s n=%-5d mean=%9.4f  p50=%9.4f  p90=%9.4f  p95=%9.4f  max=%9.4f %s"
          % (width, label, len(vals), sum(vals) / len(vals), pct(vals, 50),
             pct(vals, 90), pct(vals, 95), max(vals), unit))


def load(path):
    recs = []
    with open(path) as f:
        for ln in f:
            if not ln.startswith('DT'):
                continue
            p = ln.split()
            if len(p) != 9:
                continue
            try:
                recs.append({'dt': float(p[3]), 'v': float(p[4]), 'vdt': float(p[5]),
                             'fwd': int(p[6]), 'dp': float(p[7]), 'dv': float(p[8])})
            except ValueError:
                continue
    return recs


def run_checks(recs):
    """Time-consistency assertions on one log. Returns the number of failures."""
    if not recs:
        print("   no DT records: cannot check. Expected for a livo arm (gnss_en false);")
        print("   for a gnss arm it means no fix reached the update (alignment not locked,")
        print("   or every fix rejected) - the log then supports no conclusion either way.")
        return 0

    fails = 0
    f1 = [x for x in recs if x['fwd'] == 1]
    f0 = [x for x in recs if x['fwd'] == 0]

    # A1 - the propagated state really carried the state to t_g. Split in two,
    # because |dp_prop| is |v|*|dt_g| PLUS the quadratic term of the propagation
    # step (0.5*a*dt^2), which is negligible at the 0.05 s fix age of a segment run
    # but reaches ~0.14 m at the 0.45 s age seen over a full sequence:
    #   A1a (sensitive)  |dt_g| <= 0.1 s: relative agreement within 5%, the band the
    #                    published 1.71% worst case lives in. Catches a missing or
    #                    mangled propagation immediately (0 vs |v|*|dt_g|).
    #   A1b (order)      all epochs: the distance lies between half the
    #                    constant-velocity distance and it plus the physically
    #                    possible 0.5*a_max*dt^2 (a_max = 5 m/s^2).
    a1_fails = 0
    worst = None          # largest absolute mismatch, all epochs
    worst_short = (0.0, None)   # largest relative mismatch, |dt_g| <= 0.1 s
    for x in f1:
        scale = abs(x['vdt'])
        d = abs(x['dp'] - x['vdt'])
        if worst is None or d > worst[0]:
            worst = (d, x)
        if abs(x['dt']) <= 0.1:
            rel = d / max(scale, 1e-9)
            if rel > worst_short[0]:
                worst_short = (rel, x)
            # A relative band alone is meaningless when the state barely moves
            # (at |v| ~ 0.01 m/s the whole propagation distance is sub-millimetre),
            # hence the absolute floor.
            if d > max(0.05 * scale, 0.01):
                a1_fails += 1
        lo = 0.5 * scale
        hi = scale + 0.5 * 5.0 * x['dt'] * x['dt'] + 0.01
        if x['dp'] < lo or x['dp'] > hi:
            a1_fails += 1
    if worst:
        d, x = worst
        print("   [A1] fwd=1 %d ep: |dp_prop| vs |v|*|dt_g|, worst |d|=%.4f m "
              "(%.2f%% at dt_g=%+.4f |v|=%.3f)"
              % (len(f1), d, 100.0 * d / max(abs(x['vdt']), 1e-9), x['dt'], x['v']))
        if worst_short[1] is not None:
            xs = worst_short[1]
            print("        |dt_g|<=0.1 s subset: worst %.2f%% at dt_g=%+.4f |v|=%.3f "
                  "(quadratic term negligible there)"
                  % (100.0 * worst_short[0], xs['dt'], xs['v']))
        print("        -> %s" % ("PASS" if a1_fails == 0 else "FAIL (%d epochs out of band)" % a1_fails))
    else:
        print("   [A1] fwd=1: no epochs")
    fails += a1_fails

    # A2 - a fix at/behind the state time must not be propagated at all.
    bad2 = [x for x in f0 if abs(x['dt']) > 1e-9 or abs(x['dp']) > 1e-9]
    if f0:
        print("   [A2] fwd=0 %d ep: dt_g==0 and |dp_prop|==0 -> %s%s"
              % (len(f0), "PASS" if not bad2 else "FAIL",
                 "" if not bad2 else "  (%d violations, worst dt_g=%+.6g |dp|=%.6g)"
                 % (len(bad2), max(bad2, key=lambda x: abs(x['dt']))['dt'],
                    max(bad2, key=lambda x: abs(x['dp']))['dp'])))
    else:
        print("   [A2] fwd=0: no epochs")
    fails += len(bad2)

    # A3 - the decision gate. A fix older than the LIO state is the case WP2 was
    # written about; the project decided against building it because this never
    # happens. If it starts happening, that decision is void.
    stale = [x for x in recs if x['dt'] > 1e-9]
    if stale:
        s = min(stale, key=lambda x: -x['dt'])
        print("   [A3] stale fixes (t_g earlier than t_lio): %d of %d -> FAIL"
              % (len(stale), len(recs)))
        print("        worst dt_g=%+.4f s at |v|=%.3f m/s (=%.3f m of stale innovation)"
              % (s['dt'], s['v'], s['v'] * s['dt']))
        print("        WP2 was decided against on the finding that this never happens;")
        print("        if it does, re-open EVAL_PROTOCOL 9.6 and re-measure.")
        fails += len(stale)
    else:
        print("   [A3] stale fixes: none of %d -> PASS (the WP2 decision still holds)" % len(recs))

    # A4 - the forward window is bounded by the run() drain condition
    # (t_fix < last_lio_update_time + 0.5), so |dt_g| can never exceed it.
    bad4 = [x for x in recs if x['dt'] < -0.5 - 1e-6]
    print("   [A4] dt_g >= -0.5 s (drain window) -> %s%s"
          % ("PASS" if not bad4 else "FAIL",
             "" if not bad4 else "  (%d violations, min dt_g=%+.4f)"
             % (len(bad4), min(x['dt'] for x in bad4))))
    fails += len(bad4)

    print("   %s" % ("ALL CHECKS PASS" if fails == 0 else "CHECK FAILED (%d)" % fails))
    return fails


def main():
    args = [a for a in sys.argv[1:]]
    do_check = '--check' in args
    args = [a for a in args if a != '--check']
    if not args:
        print(__doc__)
        return 1
    rc = 0
    for path in args:
        r = load(path)
        print("=== %s" % path)
        if do_check:
            if run_checks(r) != 0:
                rc = 1
            print()
            continue
        if not r:
            print("   no DT records. Every fix either never reached the EKF update")
            print("   (frame alignment not locked - pre-lock fixes return early), or")
            print("   the log predates the WP1 diagnostic.")
            print()
            continue
        f1 = [x for x in r if x['fwd'] == 1]
        f0 = [x for x in r if x['fwd'] == 0]
        n = len(r)
        print("   records=%d" % n)
        print("   fwd=1  t_g >  t_lio : %4d (%.1f%%)  state carried forward to t_g"
              % (len(f1), 100.0 * len(f1) / n))
        print("   fwd=0  t_g <= t_lio : %4d (%.1f%%)  no propagation -> residual is"
              % (len(f0), 100.0 * len(f0) / n))
        print("                                     stale by |dt_g|")
        print()
        print("   [all records]")
        line('dt_g', [x['dt'] for x in r], 's')
        line('|v|_lio', [x['v'] for x in r], 'm/s')
        line('|v|*|dt_g|', [x['vdt'] for x in r], 'm')
        print()
        if f1:
            print("   [fwd=1: propagation ran]  |dp_prop| vs |v|*|dt_g| - if they")
            print("    agree, the state really was carried to t_g")
            line('|v|*|dt_g|', [x['vdt'] for x in f1], 'm')
            line('|dp_prop|', [x['dp'] for x in f1], 'm')
            line('|dv_prop|', [x['dv'] for x in f1], 'm/s')
            worst = max(f1, key=lambda x: abs(x['dp'] - x['vdt']))
            print("       worst |dp_prop| vs |v|*|dt_g| mismatch: %.4f m (at dt_g=%+.4f, |v|=%.3f)"
                  % (abs(worst['dp'] - worst['vdt']), worst['dt'], worst['v']))
        print()
        if f0:
            print("   [fwd=0: NO propagation]  <- this is the population P0-2 is about")
            line('dt_g', [x['dt'] for x in f0], 's')
            line('|v|*|dt_g|', [x['vdt'] for x in f0], 'm')
        else:
            print("   [fwd=0] none: every fix was carried to its own timestamp, so the")
            print("   residual misalignment measured here is ZERO.")
        print()
    return rc


if __name__ == '__main__':
    sys.exit(main())
