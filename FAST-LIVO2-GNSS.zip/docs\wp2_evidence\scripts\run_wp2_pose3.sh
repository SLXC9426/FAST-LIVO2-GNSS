#!/bin/bash
# WP2 same-input comparison: offline LIO TUM + RTK TUM -> Pose3 online graph.
# Mirrors the original run_sameinput_full.sh, but uses the current Pose3 node
# and disables Marginals/fixed-lag/velocity (no velocity input in this harness).
set -o pipefail
export LANG=C.UTF-8
ROOT="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main"
OUT="$ROOT/06_exec/r5_backend/wp2_sameinput"
mkdir -p "$OUT"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"
export ROS_MASTER_URI="http://127.0.0.1:11320"
export ROS_HOSTNAME="127.0.0.1"
export ROS_IP="127.0.0.1"
export ROS_HOME="/tmp/ros_wp2_pose3"
mkdir -p "$ROS_HOME"

cleanup() {
  [ -n "${NODE_PID:-}" ] && kill "$NODE_PID" 2>/dev/null
  [ -n "${CORE_PID:-}" ] && kill "$CORE_PID" 2>/dev/null
  wait 2>/dev/null
}
trap cleanup EXIT

roscore -p 11320 > "$OUT/roscore_pose3.log" 2>&1 &
CORE_PID=$!
for _ in $(seq 1 20); do
  rostopic list >/dev/null 2>&1 && break
  sleep 0.5
done

stdbuf -oL -eL "$HOME/catkin_ws/devel/lib/fast_livo/online_graph_node" \
  _output:="$OUT/online_pose3_scaleoff.tum" \
  _window:=1500 \
  _tddd_en:=false \
  _quality_gate_en:=true \
  _quality_min_status:=2 \
  _cauchy_xy_en:=true \
  _lambda_weight_en:=true \
  _scale_fit_en:=false \
  _sig_rigid:=0.01 \
  _sig_anchor:=0.3 \
  _cov_en:=false \
  _fixed_lag_en:=false \
  _vel_en:=false \
  _base_ecef:="[-2267750.14853585,5009154.50747098,3221294.38263863]" \
  > "$OUT/node_pose3.log" 2>&1 &
NODE_PID=$!
sleep 3

python3 "$ROOT/06_exec/wsl/feed_online_graph.py" \
  --livo "$ROOT/03_实验记录/对比实验/gv1/oracle/gv1_campus02_livo_r1_base.tum" \
  --rtk "$ROOT/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data/campus02_rtk1hz.tum" \
  --status-csv "$ROOT/01_文档/02_改进与精度汇总/阶段0_评估契约_2026-10-30/v2_epoch_errors.csv" \
  --duration 805 \
  --speed 1.0 > "$OUT/feed_pose3.log" 2>&1

sleep 8
echo "--- node tail ---"
tail -20 "$OUT/node_pose3.log"
echo "--- output ---"
ls -l "$OUT/online_pose3_scaleoff.tum" 2>/dev/null || echo "NO OUTPUT TUM"
