// P5a-2 prototype: fixed-lag position graph with the validated v2 factors.
//
// Reads a TUM trajectory (8 cols) and an RTK TUM (4 cols), builds the
// P1a+P1b+P4a factor set in ENU, solves it in a sliding window with GTSAM,
// and writes a TUM of the causal estimates. This is a standalone replay tool
// (no ROS); it is the numerical/latency prototype for the online graph.
//
// Build:
//   cmake -S . -B build -DCMAKE_BUILD_TYPE=Release && cmake --build build -j
// Run:
//   ./build/gpg_cpp --livo traj.tum --rtk rtk.tum --out out.tum --window 200
//
#include <gtsam/geometry/Point3.h>
#include <gtsam/linear/LossFunctions.h>
#include <gtsam/linear/NoiseModel.h>
#include <gtsam/nonlinear/LevenbergMarquardtOptimizer.h>
#include <gtsam/nonlinear/Marginals.h>
#include <gtsam/nonlinear/NonlinearFactorGraph.h>
#include <gtsam/nonlinear/Values.h>
#include <boost/make_shared.hpp>

#include <Eigen/Dense>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <map>
#include <numeric>
#include <sstream>
#include <string>
#include <vector>

namespace {

struct Pose {
  double t = 0;
  Eigen::Vector3d p = Eigen::Vector3d::Zero();
  Eigen::Matrix3d R = Eigen::Matrix3d::Identity();
};

struct Fix {
  double t = 0;
  Eigen::Vector3d p = Eigen::Vector3d::Zero();
};

std::vector<Pose> loadTum8(const std::string &path) {
  std::vector<Pose> out;
  std::ifstream f(path);
  std::string line;
  while (std::getline(f, line)) {
    if (line.empty() || line[0] == '#') continue;
    std::istringstream ss(line);
    Pose q;
    double qx, qy, qz, qw;
    if (!(ss >> q.t >> q.p.x() >> q.p.y() >> q.p.z() >> qx >> qy >> qz >> qw))
      continue;
    Eigen::Quaterniond quat(qw, qx, qy, qz);
    q.R = quat.normalized().toRotationMatrix();
    out.push_back(q);
  }
  return out;
}

std::vector<Fix> loadTum4(const std::string &path) {
  std::vector<Fix> out;
  std::ifstream f(path);
  std::string line;
  while (std::getline(f, line)) {
    if (line.empty() || line[0] == '#') continue;
    std::istringstream ss(line);
    Fix q;
    if (!(ss >> q.t >> q.p.x() >> q.p.y() >> q.p.z())) continue;
    out.push_back(q);
  }
  return out;
}

Eigen::Vector3d interpFix(const std::vector<Fix> &rtk, double t) {
  if (rtk.empty()) return Eigen::Vector3d::Zero();
  auto it = std::lower_bound(rtk.begin(), rtk.end(), t,
                             [](const Fix &a, double v) { return a.t < v; });
  if (it == rtk.begin()) return it->p;
  if (it == rtk.end()) return rtk.back().p;
  const Fix &b = *it;
  const Fix &a = *(it - 1);
  const double dt = b.t - a.t;
  if (dt <= 0) return b.p;
  const double w = (t - a.t) / dt;
  return (1.0 - w) * a.p + w * b.p;
}

double median(std::vector<double> v) {
  if (v.empty()) return 0.0;
  std::sort(v.begin(), v.end());
  const size_t n = v.size();
  return (n % 2) ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
}

Eigen::Vector3d medianVec(std::vector<Eigen::Vector3d> v) {
  if (v.empty()) return Eigen::Vector3d::Zero();
  Eigen::Vector3d out;
  for (int k = 0; k < 3; ++k) {
    std::vector<double> a;
    a.reserve(v.size());
    for (const auto &x : v) a.push_back(x(k));
    out(k) = median(a);
  }
  return out;
}

class RelPosFactor : public gtsam::NoiseModelFactorN<gtsam::Point3,
                                                     gtsam::Point3> {
 public:
  RelPosFactor(gtsam::Key i, gtsam::Key j, const gtsam::Point3 &d,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Point3, gtsam::Point3>(model, i, j),
        d_(d) {}
  gtsam::Vector evaluateError(
      const gtsam::Point3 &pi, const gtsam::Point3 &pj,
      boost::optional<gtsam::Matrix &> H1 = boost::none,
      boost::optional<gtsam::Matrix &> H2 = boost::none) const override {
    const gtsam::Vector3 e = pj - pi - d_;
    if (H1) *H1 = -gtsam::Matrix::Identity(3, 3);
    if (H2) *H2 = gtsam::Matrix::Identity(3, 3);
    return e;
  }

 private:
  gtsam::Point3 d_;
};

class AbsPosFactor : public gtsam::NoiseModelFactorN<gtsam::Point3> {
 public:
  AbsPosFactor(gtsam::Key i, const gtsam::Point3 &z,
               const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Point3>(model, i), z_(z) {}
  gtsam::Vector evaluateError(
      const gtsam::Point3 &p,
      boost::optional<gtsam::Matrix &> H = boost::none) const override {
    const gtsam::Vector3 e = p - z_;
    if (H) *H = gtsam::Matrix::Identity(3, 3);
    return e;
  }

 private:
  gtsam::Point3 z_;
};

// Horizontal-only RTK factor: matches the offline graph's horizontal Huber,
// so a bad vertical residual cannot downweight a good horizontal measurement.
class AbsPosXYFactor : public gtsam::NoiseModelFactorN<gtsam::Point3> {
 public:
  AbsPosXYFactor(gtsam::Key i, const gtsam::Point2 &z,
                 const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Point3>(model, i), z_(z) {}
  gtsam::Vector evaluateError(
      const gtsam::Point3 &p,
      boost::optional<gtsam::Matrix &> H = boost::none) const override {
    gtsam::Vector e(2);
    e << p.x() - z_.x(), p.y() - z_.y();
    if (H) {
      *H = gtsam::Matrix::Zero(2, 3);
      (*H)(0, 0) = 1.0;
      (*H)(1, 1) = 1.0;
    }
    return e;
  }

 private:
  gtsam::Point2 z_;
};

class AbsPosZFactor : public gtsam::NoiseModelFactorN<gtsam::Point3> {
 public:
  AbsPosZFactor(gtsam::Key i, double z,
                const gtsam::SharedNoiseModel &model)
      : gtsam::NoiseModelFactorN<gtsam::Point3>(model, i), z_(z) {}
  gtsam::Vector evaluateError(
      const gtsam::Point3 &p,
      boost::optional<gtsam::Matrix &> H = boost::none) const override {
    gtsam::Vector e(1);
    e << p.z() - z_;
    if (H) {
      *H = gtsam::Matrix::Zero(1, 3);
      (*H)(0, 2) = 1.0;
    }
    return e;
  }

 private:
  double z_;
};

struct FactorSpec {
  enum Type { REL, ABS, ABS_XY, ABS_Z } type = REL;
  int i = -1, j = -1;  // REL: i,j; ABS: i
  Eigen::Vector3d d = Eigen::Vector3d::Zero();
  gtsam::SharedNoiseModel noise;
};

}  // namespace

int main(int argc, char **argv) {
  std::string livo_path, rtk_path, out_path;
  int window = 200;
  double lever_x = -0.05, lever_y = -0.325, lever_z = 0.165;
  double sig_rigid = 0.005, sig_anchor = 0.3;
  double detect_thresh = 0.20;
  int detect_win = 3;
  double trans_sigma_xy = 0.2, trans_sigma_z = 1.0;
  int trans_kf = 8;
  double sig_odom_z = 0.10, sig_rtk_z = 2.0;
  double window_prior = 0.0;
  bool rtk_split = false;
  bool marg_prior = false;
  bool global_mode = false;
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    auto next = [&]() { return std::string(argv[++i]); };
    if (a == "--livo") livo_path = next();
    else if (a == "--rtk") rtk_path = next();
    else if (a == "--out") out_path = next();
    else if (a == "--window") window = std::stoi(next());
    else if (a == "--lever") { lever_x = std::stod(next()); lever_y = std::stod(next()); lever_z = std::stod(next()); }
    else if (a == "--sig-rigid") sig_rigid = std::stod(next());
    else if (a == "--sig-anchor") sig_anchor = std::stod(next());
    else if (a == "--sig-odom-z") sig_odom_z = std::stod(next());
    else if (a == "--sig-rtk-z") sig_rtk_z = std::stod(next());
    else if (a == "--window-prior") window_prior = std::stod(next());
    else if (a == "--rtk-split") rtk_split = true;
    else if (a == "--marg-prior") marg_prior = true;
    else if (a == "--no-marg-prior") marg_prior = false;
    else if (a == "--global") global_mode = true;
  }
  if (livo_path.empty() || rtk_path.empty() || out_path.empty()) {
    std::cerr << "usage: gpg_cpp --livo traj.tum --rtk rtk.tum --out out.tum "
                 "[--window 200]\n";
    return 1;
  }

  const auto poses = loadTum8(livo_path);
  const auto rtk = loadTum4(rtk_path);
  if (poses.size() < 20 || rtk.size() < 2) {
    std::cerr << "not enough poses\n";
    return 1;
  }

  // 1 s keyframes (same as the offline graph).
  std::vector<Pose> kf;
  kf.push_back(poses.front());
  for (size_t i = 1; i < poses.size(); ++i) {
    if (poses[i].t - kf.back().t >= 1.0) kf.push_back(poses[i]);
  }
  const int n = static_cast<int>(kf.size());

  // Initial 2D fit (LIO world -> ENU) using the in-bounds RTK samples.
  double sx = 0, sy = 0, rx = 0, ry = 0;
  int nfit = 0;
  for (int i = 0; i < n; ++i) {
    if (kf[i].t < rtk.front().t || kf[i].t > rtk.back().t) continue;
    const Eigen::Vector3d r = interpFix(rtk, kf[i].t);
    sx += kf[i].p.x(); sy += kf[i].p.y();
    rx += r.x(); ry += r.y();
    ++nfit;
  }
  if (nfit < 20) {
    std::cerr << "not enough LIO/RTK overlap\n";
    return 1;
  }
  const double mx = sx / nfit, my = sy / nfit;
  const double mrx = rx / nfit, mry = ry / nfit;
  double sc = 0, sd = 0;
  for (int i = 0; i < n; ++i) {
    if (kf[i].t < rtk.front().t || kf[i].t > rtk.back().t) continue;
    const Eigen::Vector3d r = interpFix(rtk, kf[i].t);
    const double lx = kf[i].p.x() - mx, ly = kf[i].p.y() - my;
    const double ex = r.x() - mrx, ey = r.y() - mry;
    sc += lx * ey - ly * ex;
    sd += lx * ex + ly * ey;
  }
  const double yaw = std::atan2(sc, sd);
  const double cy = std::cos(yaw), syaw = std::sin(yaw);
  Eigen::Matrix3d Rz;
  Rz << cy, -syaw, 0, syaw, cy, 0, 0, 0, 1;
  Eigen::Vector3d tr;
  tr << mrx - (cy * mx - syaw * my), mry - (syaw * mx + cy * my), 0;
  double fit_sq = 0;
  for (int i = 0; i < n; ++i) {
    if (kf[i].t < rtk.front().t || kf[i].t > rtk.back().t) continue;
    const Eigen::Vector3d r = interpFix(rtk, kf[i].t);
    const Eigen::Vector3d q = Rz * kf[i].p + tr;
    fit_sq += (q.head<2>() - r.head<2>()).squaredNorm();
  }
  const double fit_rms = std::sqrt(fit_sq / nfit);
  const double sig_rtk_xy =
      std::min(5.0, std::max(1.0, 6.0 - 0.6 * fit_rms));
  const double sig_odom =
      std::min(0.5, std::max(0.05, 0.05 + 0.06 * (fit_rms - 2.0)));

  std::vector<Eigen::Vector3d> p0(n);
  for (int i = 0; i < n; ++i) p0[i] = Rz * kf[i].p + tr;

  // Nearest unique RTK fix per keyframe.
  std::vector<int> ir(n, -1);
  std::vector<bool> ok(n, false);
  std::vector<bool> used(rtk.size(), false);
  for (int i = 0; i < n; ++i) {
    int best = -1;
    double bd = 1e9;
    for (size_t j = 0; j < rtk.size(); ++j) {
      const double d = std::fabs(rtk[j].t - kf[i].t);
      if (d < bd) { bd = d; best = static_cast<int>(j); }
    }
    if (best >= 0 && bd < 0.6 && !used[best]) {
      used[best] = true;
      ir[i] = best;
      ok[i] = true;
    }
  }

  // Static detection: LIO 3D speed, median over +-detect_win, threshold.
  std::vector<double> speed(n, 0.0);
  for (int i = 1; i < n; ++i) {
    const double dt = kf[i].t - kf[i - 1].t;
    speed[i] = (kf[i].p - kf[i - 1].p).norm() / std::max(dt, 1e-9);
  }
  std::vector<bool> stat(n, false);
  for (int i = 0; i < n; ++i) {
    std::vector<double> v;
    for (int j = std::max(0, i - detect_win);
         j <= std::min(n - 1, i + detect_win); ++j)
      v.push_back(speed[j]);
    stat[i] = median(v) < detect_thresh;
  }
  // Merge runs separated by <=2 frames.
  std::vector<std::pair<int, int>> runs;
  for (int i = 0; i < n;) {
    if (!stat[i]) { ++i; continue; }
    int j = i;
    while (j + 1 < n && stat[j + 1]) ++j;
    if (!runs.empty() && i - runs.back().second <= 2) runs.back().second = j;
    else runs.push_back({i, j});
    i = j + 1;
  }
  std::vector<bool> member(n, false);
  std::vector<int> run_of(n, -1);
  std::vector<Eigen::Vector3d> anchor(runs.size());
  std::vector<bool> has_anchor(runs.size(), false);
  for (size_t k = 0; k < runs.size(); ++k) {
    for (int i = runs[k].first; i <= runs[k].second; ++i) {
      member[i] = true;
      run_of[i] = static_cast<int>(k);
    }
    std::vector<Eigen::Vector3d> bases;
    for (int i = runs[k].first; i <= runs[k].second; ++i) {
      if (!ok[i]) continue;
      const Eigen::Vector3d lever_w =
          Rz * kf[i].R * Eigen::Vector3d(lever_x, lever_y, lever_z);
      bases.push_back(rtk[ir[i]].p - lever_w);
    }
    if (!bases.empty()) {
      anchor[k] = medianVec(bases);
      has_anchor[k] = true;
    }
  }

  const Eigen::Vector3d lever(lever_x, lever_y, lever_z);
  const auto noise_xyz = [](double sx, double sy, double sz) {
    return gtsam::noiseModel::Diagonal::Sigmas(gtsam::Vector3(sx, sy, sz));
  };
  const auto robust_noise = [](double sx, double sy, double sz) {
    return gtsam::noiseModel::Robust::Create(
        gtsam::noiseModel::mEstimator::Huber::Create(3.0),
        gtsam::noiseModel::Diagonal::Sigmas(gtsam::Vector3(sx, sy, sz)));
  };

  const auto robust_noise2 = [](double sx, double sy) {
    return gtsam::noiseModel::Robust::Create(
        gtsam::noiseModel::mEstimator::Huber::Create(3.0),
        gtsam::noiseModel::Diagonal::Sigmas(gtsam::Vector2(sx, sy)));
  };
  const auto noise_z = [](double sz) {
    return gtsam::noiseModel::Isotropic::Sigma(1, sz);
  };

  std::vector<FactorSpec> factors;
  const auto add_rel = [&](int i, int j, const Eigen::Vector3d &d,
                           const gtsam::SharedNoiseModel &noise) {
    FactorSpec f;
    f.type = FactorSpec::REL;
    f.i = i; f.j = j; f.d = d; f.noise = noise;
    factors.push_back(f);
  };
  const auto add_abs = [&](int i, const Eigen::Vector3d &z,
                           const gtsam::SharedNoiseModel &noise) {
    FactorSpec f;
    f.type = FactorSpec::ABS;
    f.i = i; f.d = z; f.noise = noise;
    factors.push_back(f);
  };
  const auto add_abs_xy = [&](int i, const Eigen::Vector2d &z,
                              const gtsam::SharedNoiseModel &noise) {
    FactorSpec f;
    f.type = FactorSpec::ABS_XY;
    f.i = i; f.d = Eigen::Vector3d(z.x(), z.y(), 0.0); f.noise = noise;
    factors.push_back(f);
  };
  const auto add_abs_z = [&](int i, double z,
                             const gtsam::SharedNoiseModel &noise) {
    FactorSpec f;
    f.type = FactorSpec::ABS_Z;
    f.i = i; f.d = Eigen::Vector3d(0.0, 0.0, z); f.noise = noise;
    factors.push_back(f);
  };

  const auto odom_noise = noise_xyz(sig_odom, sig_odom, sig_odom_z);
  for (int i = 0; i + 1 < n; ++i) {
    add_rel(i, i + 1, Rz * (kf[i + 1].p - kf[i].p), odom_noise);
    if (member[i] && member[i + 1])
      add_rel(i, i + 1, Eigen::Vector3d::Zero(),
              noise_xyz(sig_rigid, sig_rigid, sig_rigid));
  }
  // Absolute RTK, split into horizontal (Huber) and vertical (Gaussian)
  // factors to match the offline graph; static runs are anchored instead.
  for (int i = 0; i < n; ++i) {
    if (ok[i] && !member[i]) {
      const Eigen::Vector3d lever_w = Rz * kf[i].R * lever;
      const Eigen::Vector3d z = rtk[ir[i]].p - lever_w;
      if (rtk_split) {
        add_abs_xy(i, Eigen::Vector2d(z.x(), z.y()),
                   robust_noise2(sig_rtk_xy, sig_rtk_xy));
        add_abs_z(i, z.z(), noise_z(sig_rtk_z));
      } else {
        add_abs(i, z, robust_noise(sig_rtk_xy, sig_rtk_xy, sig_rtk_z));
      }
    }
  }
  for (size_t k = 0; k < runs.size(); ++k) {
    if (has_anchor[k])
      add_abs(runs[k].first, anchor[k],
              noise_xyz(sig_anchor, sig_anchor, sig_anchor));
  }
  // P1b: local RTK-relative factors after each static->moving boundary.
  for (const auto &r : runs) {
    const int b = r.second;
    for (int j = 1; j <= trans_kf; ++j) {
      const int i0 = b + j - 1, i1 = b + j;
      if (i1 >= n || member[i1]) break;
      if (!ok[i0] || !ok[i1] || ir[i0] == ir[i1]) continue;
      const Eigen::Vector3d lw0 = Rz * kf[i0].R * lever;
      const Eigen::Vector3d lw1 = Rz * kf[i1].R * lever;
      const Eigen::Vector3d d =
          (rtk[ir[i1]].p - lw1) - (rtk[ir[i0]].p - lw0);
      add_rel(i0, i1, d, noise_xyz(trans_sigma_xy, trans_sigma_xy,
                                   trans_sigma_z));
    }
  }
  // Gauge: only on node 0, unless node 0 is a static run with an anchor.
  if (!(member[0] && has_anchor[run_of[0]]))
    add_abs(0, p0[0], noise_xyz(0.01, 0.01, 0.01));

  std::cout << "keyframes=" << n << " fit_rms=" << fit_rms
            << " sig_rtk_xy=" << sig_rtk_xy << " sig_odom=" << sig_odom
            << " runs=" << runs.size() << " factors=" << factors.size()
            << " window=" << window << "\n";
  for (size_t k = 0; k < runs.size(); ++k) {
    std::cout << "  static run " << kf[runs[k].first].t - kf[0].t << "-"
              << kf[runs[k].second].t - kf[0].t << " s";
    if (has_anchor[k])
      std::cout << " anchor=(" << anchor[k].x() << "," << anchor[k].y()
                << "," << anchor[k].z() << ")";
    std::cout << "\n";
  }

  if (global_mode) {
    gtsam::NonlinearFactorGraph graph;
    for (const auto &f : factors) {
      if (f.type == FactorSpec::REL) {
        graph.add(boost::make_shared<RelPosFactor>(
            f.i, f.j, gtsam::Point3(f.d.x(), f.d.y(), f.d.z()), f.noise));
      } else if (f.type == FactorSpec::ABS_XY) {
        graph.add(boost::make_shared<AbsPosXYFactor>(
            f.i, gtsam::Point2(f.d.x(), f.d.y()), f.noise));
      } else if (f.type == FactorSpec::ABS_Z) {
        graph.add(boost::make_shared<AbsPosZFactor>(f.i, f.d.z(), f.noise));
      } else {
        graph.add(boost::make_shared<AbsPosFactor>(
            f.i, gtsam::Point3(f.d.x(), f.d.y(), f.d.z()), f.noise));
      }
    }
    gtsam::Values values;
    for (int i = 0; i < n; ++i)
      values.insert(i, gtsam::Point3(p0[i].x(), p0[i].y(), p0[i].z()));
    const auto t0 = std::chrono::steady_clock::now();
    gtsam::LevenbergMarquardtOptimizer opt(graph, values);
    const gtsam::Values result = opt.optimize();
    const auto t1 = std::chrono::steady_clock::now();
    std::ofstream gf(out_path);
    gf << std::setprecision(12);
    for (int i = 0; i < n; ++i) {
      const gtsam::Point3 q = result.at<gtsam::Point3>(i);
      Eigen::Quaterniond quat(kf[i].R);
      gf << kf[i].t << " " << q.x() << " " << q.y() << " " << q.z()
         << " " << quat.x() << " " << quat.y() << " " << quat.z()
         << " " << quat.w() << "\n";
    }
    std::cout << "global solve ms="
              << std::chrono::duration<double, std::milli>(t1 - t0).count()
              << "\n";
    std::cout << "wrote " << out_path << "\n";
    return 0;
  }

  std::map<int, Eigen::Vector3d> est;
  for (int i = 0; i < n; ++i) est[i] = p0[i];
  std::map<int, Eigen::Vector3d> marg_mean;
  std::map<int, Eigen::Matrix3d> marg_cov;
  std::vector<Eigen::Vector3d> out(n);
  std::vector<double> times;
  for (int cur = 0; cur < n; ++cur) {
    const int start = std::max(0, cur - window + 1);
    gtsam::NonlinearFactorGraph graph;
    for (const auto &f : factors) {
      if (f.type == FactorSpec::REL) {
        if (f.i >= start && f.i <= cur && f.j >= start && f.j <= cur)
          graph.add(boost::make_shared<RelPosFactor>(
              f.i, f.j, gtsam::Point3(f.d.x(), f.d.y(), f.d.z()), f.noise));
      } else if (f.type == FactorSpec::ABS_XY) {
        if (f.i >= start && f.i <= cur)
          graph.add(boost::make_shared<AbsPosXYFactor>(
              f.i, gtsam::Point2(f.d.x(), f.d.y()), f.noise));
      } else if (f.type == FactorSpec::ABS_Z) {
        if (f.i >= start && f.i <= cur)
          graph.add(boost::make_shared<AbsPosZFactor>(
              f.i, f.d.z(), f.noise));
      } else {
        if (f.i >= start && f.i <= cur)
          graph.add(boost::make_shared<AbsPosFactor>(
              f.i, gtsam::Point3(f.d.x(), f.d.y(), f.d.z()), f.noise));
      }
    }
    if (start > 0 && window_prior > 0.0) {
      graph.add(boost::make_shared<AbsPosFactor>(
          start, gtsam::Point3(est[start].x(), est[start].y(), est[start].z()),
          noise_xyz(window_prior, window_prior, window_prior)));
    }
    // Marginalization prior: the information of the factors dropped when the
    // window slid, carried as the 3x3 marginal covariance of the new oldest
    // node from the previous window.
    if (marg_prior && start > 0 && marg_cov.count(start)) {
      graph.add(boost::make_shared<AbsPosFactor>(
          start,
          gtsam::Point3(marg_mean[start].x(), marg_mean[start].y(),
                        marg_mean[start].z()),
          gtsam::noiseModel::Gaussian::Covariance(marg_cov[start])));
    }
    gtsam::Values values;
    for (int i = start; i <= cur; ++i)
      values.insert(i, gtsam::Point3(est[i].x(), est[i].y(), est[i].z()));
    const auto t0 = std::chrono::steady_clock::now();
    gtsam::LevenbergMarquardtOptimizer opt(graph, values);
    const gtsam::Values result = opt.optimize();
    if (marg_prior && cur >= window - 1 && start + 1 <= cur) {
      try {
        gtsam::Marginals marginals(graph, result);
        const int next_start = start + 1;
        Eigen::Matrix3d cov = marginals.marginalCovariance(next_start);
        cov += Eigen::Matrix3d::Identity() * 1e-9;
        const gtsam::Point3 q = result.at<gtsam::Point3>(next_start);
        marg_cov[next_start] = cov;
        marg_mean[next_start] = Eigen::Vector3d(q.x(), q.y(), q.z());
      } catch (const std::exception &e) {
        std::cerr << "marginal prior skipped: " << e.what() << "\n";
      }
    }
    const auto t1 = std::chrono::steady_clock::now();
    times.push_back(
        std::chrono::duration<double, std::milli>(t1 - t0).count());
    for (int i = start; i <= cur; ++i) {
      const gtsam::Point3 q = result.at<gtsam::Point3>(i);
      est[i] = Eigen::Vector3d(q.x(), q.y(), q.z());
    }
    out[cur] = est[cur];
  }

  std::ofstream f(out_path);
  f << std::setprecision(12);
  for (int i = 0; i < n; ++i) {
    Eigen::Quaterniond quat(kf[i].R);
    f << kf[i].t << " " << out[i].x() << " " << out[i].y() << " "
      << out[i].z() << " " << quat.x() << " " << quat.y() << " "
      << quat.z() << " " << quat.w() << "\n";
  }
  std::sort(times.begin(), times.end());
  if (!times.empty()) {
    const double mean =
        std::accumulate(times.begin(), times.end(), 0.0) / times.size();
    std::cout << "solve ms mean=" << mean << " p50=" << times[times.size() / 2]
              << " p95=" << times[static_cast<size_t>(0.95 * times.size())]
              << " max=" << times.back() << "\n";
  }
  std::cout << "wrote " << out_path << "\n";
  return 0;
}
