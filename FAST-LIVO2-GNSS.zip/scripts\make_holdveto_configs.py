#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive the GNSS-assisted static-hold release (hold-veto) A/B configs (R4-1 / A3-1b).

The IMU-only release cannot separate campus-02's extreme slow start from the
estimator's own drift: it releases within 0.5 s of the lock and the 0.3 m/s
static walk lands in the reported trajectory (30 m over the first 100 s, c02's
dominant error). The veto extends the REPORT hold past the IMU release while
GNSS says the antenna has not moved.

The threshold is a PHYSICAL quantity calibrated from each dataset's RTK static
epoch noise (.tmp_check/r48_rtk_static_noise.py), not a tuning knob:
  campus-01 (RTK fixed, 1 Hz): static |d| max 3 mm over 0-22 s  -> 0.3 m
  campus-02 (float, 30 s):     static |d| 0.24-0.77 m per 30 s  -> 2.0 m
                               (~15x below one 30 s step of real walking motion)

One knob block per arm, everything else byte-identical to the base config.

Usage:  make_holdveto_configs.py
Writes  config/great_campus01_holdveto.yaml and config/great_campus02_holdveto.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

# (base config, output name, threshold m, threshold rationale)
TARGETS = [
    ("great_campus01.yaml", "great_campus01_holdveto.yaml", "0.3",
     "RTK fixed 1 Hz: static epoch-to-epoch |d| max 3 mm -> 100x margin"),
    ("great_campus02.yaml", "great_campus02_holdveto.yaml", "2.0",
     "RTK float 30 s: static |d| 0.24-0.77 m per 30 s -> ~15x below one 30 s "
     "step of real walking motion"),
]


def derive(base_name, out_name, thresh, why):
    base = os.path.join(HERE, os.pardir, "config", base_name)
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()

    out = []
    inserted = False
    key_re = re.compile(r"^(\s*)hold_max_s:")
    for ln in lines:
        out.append(ln)
        m = key_re.match(ln)
        if m and not inserted:
            i = m.group(1)
            out.append("%s# R4-1 (A3-1b): GNSS-assisted static-hold release. The report\n" % i)
            out.append("%s# hold is extended past the IMU release while the GNSS says the\n" % i)
            out.append("%s# antenna has not moved (displacement from the reference fix <\n" % i)
            out.append("%s# the threshold). Threshold calibrated from this dataset's RTK\n" % i)
            out.append("%s# static epoch noise: %s\n" % (i, why))
            out.append("%shold_veto_gnss: true\n" % i)
            out.append("%shold_veto_thresh: %s\n" % (i, thresh))
            out.append("%shold_veto_stale_s: 45.0   # s without fixes -> fall back to IMU-only\n" % i)
            out.append("%shold_veto_max_s: 300.0    # s backstop on the vetoed hold itself\n" % i)
            inserted = True
    if not inserted:
        sys.exit("anchor line 'hold_max_s:' not found in %s" % base)

    dst = os.path.join(HERE, os.pardir, "config", out_name)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s (from %s, thresh=%s)" % (os.path.normpath(dst), base_name, thresh))


if __name__ == "__main__":
    for base, out, th, why in TARGETS:
        derive(base, out, th, why)
