import csv
import importlib.util
from pathlib import Path
import tempfile
import unittest
import numpy as np

SOURCE=Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('provenance',SOURCE/'scripts/eval/quality_provenance.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

class QualityProvenance(unittest.TestCase):
    def test_same_solution_and_single_bad_epoch(self):
        with tempfile.TemporaryDirectory() as folder:
            p=Path(folder); rng=np.random.default_rng(7); x=rng.normal(size=(20,3))
            # Orthogonal cyclic permutation and arbitrary translation.
            y=x[:,[1,2,0]]+[5,8,-2]
            def write(corrupt=False):
                with (p/'q.csv').open('w',newline='') as stream:
                    w=csv.writer(stream);w.writerow(['t_unix','x','y','z'])
                    for i,v in enumerate(x):w.writerow([str(1000+i),*(v+([30,0,0] if corrupt and i==7 else [0,0,0]))])
            (p/'rtk.tum').write_text('\n'.join(f'{1000+i} {v[0]} {v[1]} {v[2]}' for i,v in enumerate(y)))
            write();self.assertLess(mod.verify_quality_positions(p/'rtk.tum',p/'q.csv')['max_position_error_m'],1e-9)
            write(True)
            with self.assertRaisesRegex(ValueError,'provenance mismatch'):mod.verify_quality_positions(p/'rtk.tum',p/'q.csv')
    def test_existing_mixed_inputs_are_rejected(self):
        project=SOURCE.parents[1]
        for c in ['01','02']:
            with self.assertRaisesRegex(ValueError,'provenance mismatch'):
                mod.verify_quality_positions(project/f'01_项目文档/02_精度与改进/阶段1_离线图修复/data/campus{c}_rtk1hz.tum',
                    project/f'01_项目文档/02_精度与改进/阶段0_评估契约/data/FIXBASE-RTK-c{c}-1hz_quality.csv')
if __name__=='__main__':unittest.main(verbosity=2)
