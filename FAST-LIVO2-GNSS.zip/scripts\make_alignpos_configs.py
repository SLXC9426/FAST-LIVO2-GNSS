#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive the alignment-sample-source A/B configs (R4-2b, EVAL_PROTOCOL 17.2).

The runtime ENU->world fit samples _state.pos_end (the INTERNAL pose), which
carries the ~0.3 m/s static walk that the report-level hold exists to hide: a
50 s window of that walk stretches ~15 m and is exactly the 5-8 m "fit
residual" that withheld the alignment forever on c02/c03. The flag
gnss/align_use_report_pos samples the REPORTED pose (internal + hold offset)
instead; offline replay on the archived reported trajectories puts the fit
residual median at 0.22-0.27 m on both datasets (r42_align_triage.py).

One knob per arm, everything else byte-identical to the base config. On c02
the flag is stacked on the R4-1 hold-veto config (the veto keeps the report
pinned through the ambiguous start, which is what makes the sampled window
clean there - the two changes are designed to work together).

Usage:  make_alignpos_configs.py
Writes  config/great_campus0X_alignpos.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

BLOCK = """\
{i}# R4-2b (EVAL_PROTOCOL 17.2): fit the ENU->world alignment on the REPORTED
{i}# pose (internal + hold offset) instead of the internal one, so the static
{i}# walk the hold hides from the output cannot poison the fit. Measured offline
{i}# (r42_align_triage.py): fit-residual median 0.22-0.27 m vs the 5-8 m that
{i}# kept the alignment withheld. Default off = internal-pose sampling.
{i}align_use_report_pos: true
"""

TARGETS = [
    "great_campus01.yaml",
    # c02's decisive arm: the align flag stacked on the R4-1 hold-veto config -
    # the veto keeps the report pinned through the ambiguous start, which is
    # what makes the sampled window clean there (the two act together).
    "great_campus02_holdveto.yaml",
    "great_campus02.yaml",
    "great_campus03.yaml",
]


def derive(base_name):
    base = os.path.join(HERE, os.pardir, "config", base_name)
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()

    out = []
    inserted = False
    key_re = re.compile(r"^(\s*)outlier_rejection:")
    for ln in lines:
        m = key_re.match(ln)
        if m and not inserted:
            out.append(BLOCK.format(i=m.group(1)))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor line 'outlier_rejection:' not found in %s" % base)

    dst = os.path.join(HERE, os.pardir, "config",
                       base_name.replace(".yaml", "_alignpos.yaml"))
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s (from %s)" % (os.path.normpath(dst), base_name))


if __name__ == "__main__":
    for base in TARGETS:
        derive(base)
