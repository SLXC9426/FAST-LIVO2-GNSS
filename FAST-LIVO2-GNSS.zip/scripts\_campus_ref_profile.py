#!/usr/bin/env python3
"""Reference distance profile for campus (gnss.pos based TUM)."""
import numpy as np

p = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/campus01_reference.tum"
lines = open(p).read().strip().splitlines()
t = np.array([float(l.split()[0]) for l in lines])
xy = np.array([[float(l.split()[1]), float(l.split()[2])] for l in lines])
d = np.sqrt(np.sum(np.diff(xy, axis=0) ** 2, axis=1))
cum = np.concatenate([[0.0], np.cumsum(d)])
t0 = t[0]
print("ref start:", t0, "end:", t[-1], "dur:", t[-1] - t0)
print("total cum: %.1f m, max dist: %.1f m" % (cum[-1], np.max(np.linalg.norm(xy - xy[0], axis=1))))
for dt in [50, 100, 150, 200, 250, 300, 350, 400, 450, 500, 550, 606]:
    i = np.argmin(np.abs(t - (t0 + dt)))
    print("t=%3d: pos=(%.1f, %.1f) dist_from_start=%.1f cum=%.1f" %
          (dt, xy[i, 0], xy[i, 1], np.linalg.norm(xy[i] - xy[0]), cum[i]))
