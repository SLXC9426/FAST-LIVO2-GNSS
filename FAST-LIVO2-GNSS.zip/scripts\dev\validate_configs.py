#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Validate the FAST-LIVO2 yaml configs parse and contain the expected keys.

Why this exists: a config was once rewritten with a Windows PowerShell
`Set-Content` round-trip, which silently re-encoded the file so the Chinese
comments became invalid UTF-8. roslib then failed with a bare
"RLException: error loading <rosparam> tag" and the launch died, while
`rosbag play` kept running forever (the launch script waits for the bag), so a
broken config looked like a hung run. Checking the YAML first turns that into an
immediate, explicit failure.

Usage: validate_configs.py [config_dir]
"""
import os
import sys
import yaml

EXPECTED = ["common", "extrin_calib", "imu", "lio", "gnss", "local_map", "zupt", "evo"]


def main():
    d = sys.argv[1] if len(sys.argv) > 1 else "config"
    files = sorted(f for f in os.listdir(d) if f.startswith("great_") and f.endswith(".yaml"))
    bad = 0
    for f in files:
        p = os.path.join(d, f)
        try:
            with open(p, encoding="utf-8") as fh:
                cfg = yaml.safe_load(fh)
        except Exception as e:
            # A parse error means roslib will fail the launch outright.
            print("FAIL %-34s %s" % (f, e))
            bad += 1
            continue
        missing = [k for k in EXPECTED if k not in cfg]
        main_cfg = f in ("great_campus01.yaml", "great_campus02.yaml", "great_campus03.yaml")
        if missing and main_cfg:
            print("FAIL %-34s missing sections: %s" % (f, ", ".join(missing)))
            bad += 1
        else:
            z = cfg.get("zupt") or {}
            g = cfg.get("gnss") or {}
            note = ("  [missing: %s]" % ",".join(missing)) if missing else ""
            print("OK   %-34s zupt.hold_pos=%-5s release_vel=%-5s | gnss.relative_update=%-5s inflate_prior=%s%s"
                  % (f, z.get("hold_pos"), z.get("release_vel"),
                     g.get("relative_update"), g.get("inflate_prior"), note))
    print("%d/%d ok" % (len(files) - bad, len(files)))
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
