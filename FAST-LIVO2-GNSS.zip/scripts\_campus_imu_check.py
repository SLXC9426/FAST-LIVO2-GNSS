#!/usr/bin/env python3
"""Manually integrate campus tactical IMU and compare with GNSS reference."""
import numpy as np

# load IMU (t, gx, gy, gz, ax, ay, az) - GPS seconds
rows = []
with open("/home/slxc9426/datasets/GREAT/IMU/Tactical_imu_data.txt") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "ime" in line:
            continue
        v = line.split()
        rows.append([float(x) for x in v])
a = np.array(rows)
t = a[:, 0]
OFFSET = 604800 * 2129 + 315964800 - 18
t_unix = t + OFFSET
gyr = a[:, 1:4]
acc = a[:, 4:7]
print("IMU rows:", len(a), "t: %.2f ~ %.2f (GPS s)" % (t.min(), t.max()))
print("acc mean (first 100, static?):", acc[:100].mean(0).round(4))
print("acc std over whole:", acc.std(0).round(4))
# acceleration magnitude excluding gravity: |acc - mean_gravity|
g0 = acc[:200].mean(0)
print("gravity est:", g0.round(4), "|g|:", np.linalg.norm(g0))

# simple integration 0-400s (t_unix 1603764571 -> 1603764971)
t0, t1 = 1603764571.0, 1603764971.0
m = (t_unix >= t0) & (t_unix <= t1)
ts, as_, gs = t_unix[m], acc[m], gyr[m]
# remove gravity using initial estimate
a_body = as_ - g0
# rotate to world with yaw from gyro (2D simplification, ignore roll/pitch)
dt = np.diff(ts)
yaw = np.cumsum(gs[:-1, 2] * dt)
aw = np.zeros_like(a_body[:-1])
aw[:, 0] = a_body[:-1, 0] * np.cos(yaw) - a_body[:-1, 1] * np.sin(yaw)
aw[:, 1] = a_body[:-1, 0] * np.sin(yaw) + a_body[:-1, 1] * np.cos(yaw)
v = np.cumsum(aw * dt[:, None], axis=0)
p = np.cumsum(v * dt[:, None], axis=0)
print("IMU integration 0-400s: final pos (%.0f, %.0f), path len %.0f m" %
      (p[-1, 0], p[-1, 1], np.sum(np.linalg.norm(v * dt[:, None], axis=1))))
print("acc abs max per axis:", np.abs(as_).max(0).round(3))
# acc during motion: std in a 10s window at t=100s
i100 = np.argmin(np.abs(t_unix - 1603764671))
print("acc std @ t=100s window:", acc[i100:i100 + 2000].std(0).round(4))
print("acc mean @ t=100s window:", acc[i100:i100 + 2000].mean(0).round(4))
