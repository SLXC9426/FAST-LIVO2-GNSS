#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Summarize the Phase 0 pure-LIVO baseline runs (N=3).

Reads the project registry, selects the phase0_c01_livo* rows, and writes a
median/range table used as the G0 reference for the RTK A/B.
"""
import csv
import os
import statistics

REG = "/home/slxc9426/catkin_ws/src/fast_livo/Log/result/registry.csv"
OUTDIR = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/metrics"
PREFIX = "phase0_c01_livo"

FIELDS = [
    ("n_full", "n_full"),
    ("r3_full", "full_3D"),
    ("r2_full", "full_2D"),
    ("mx_full", "full_3D_max"),
    ("n_steady", "n_steady"),
    ("r3_steady", "steady_3D"),
    ("r2_steady", "steady_2D"),
    ("rpe1", "RPE_1s_mean"),
    ("rpe10", "RPE_10s_mean"),
    ("rpe60", "RPE_60s_mean"),
    ("rpe120", "RPE_120s_mean"),
    ("r3_mov", "movfit_3D"),
    ("r2_mov", "movfit_2D"),
    ("r3_stat_gf", "stat@movfit_3D"),
    ("r2_stat_gf", "stat@movfit_2D"),
    ("r2_statloc", "static-loc_2D"),
]


def main():
    rows = []
    with open(REG, newline="") as f:
        for row in csv.DictReader(f):
            if row["tag"].startswith(PREFIX):
                rows.append(row)
    rows.sort(key=lambda r: r["tag"])
    if len(rows) < 2:
        raise SystemExit(f"need >=2 {PREFIX} rows, found {len(rows)}")

    print(f"selected {len(rows)} baseline runs:")
    print("  " + ", ".join(r["tag"] for r in rows))

    out_rows = []
    for key, label in FIELDS:
        vals = []
        for r in rows:
            try:
                vals.append(float(r[key]))
            except (KeyError, ValueError):
                pass
        if not vals:
            continue
        med = statistics.median(vals)
        lo, hi = min(vals), max(vals)
        out_rows.append((label, med, lo, hi, hi - lo, vals))
        print(f"  {label:18s} median={med:8.4f}  min={lo:8.4f}  max={hi:8.4f}  range={hi-lo:8.4f}")

    os.makedirs(OUTDIR, exist_ok=True)
    csv_path = os.path.join(OUTDIR, "phase0_baseline_summary.csv")
    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "median", "min", "max", "range", "runs"])
        for label, med, lo, hi, rng, vals in out_rows:
            w.writerow([label, f"{med:.4f}", f"{lo:.4f}", f"{hi:.4f}", f"{rng:.4f}",
                        ";".join(f"{v:.4f}" for v in vals)])
    print("wrote " + csv_path)


if __name__ == "__main__":
    main()
