#ifndef RTK_TIME_ASSOCIATION_H_
#define RTK_TIME_ASSOCIATION_H_

// A1: RTK epoch <-> keyframe time association.
//
// The A0 backend picks one "unique nearest fix" per keyframe with a 0.6 s
// tolerance. That both uses an RTK position sampled at a different instant than
// the keyframe and can leave a keyframe without any absolute observation when a
// neighbouring keyframe consumed the epoch. Here every RTK epoch is instead
// bracketed by the two keyframes that surround it, so the factor can be
// evaluated at the epoch's own time (see InterpolatedAbsPosFactor).
//
// This header is Eigen/ROS/GTSAM free on purpose: the association rules can be
// unit-tested without constructing a graph.

#include <cmath>
#include <cstddef>
#include <vector>

namespace fast_livo
{

enum class FixAssocStatus
{
  OK = 0,
  DUPLICATE_EPOCH,     // same timestamp as the previous fix (re-publication)
  BEFORE_RANGE,        // earlier than the first keyframe and not extrapolated
  AFTER_RANGE,         // later than the last keyframe and not extrapolated
  BRACKET_TOO_WIDE,    // t(key_j) - t(key_i) > max_bracket_dt
  ALPHA_OUT_OF_RANGE,  // alpha outside [min_alpha, max_alpha]
  BAD_KEYFRAME_TIME,   // keyframe times are not strictly increasing
  PRE_REJECTED         // dropped before association (addFix jump gate)
};

inline const char *fixAssocStatusName(FixAssocStatus s)
{
  switch (s)
  {
    case FixAssocStatus::OK: return "ok";
    case FixAssocStatus::DUPLICATE_EPOCH: return "duplicate";
    case FixAssocStatus::BEFORE_RANGE: return "before_range";
    case FixAssocStatus::AFTER_RANGE: return "after_range";
    case FixAssocStatus::BRACKET_TOO_WIDE: return "bracket_too_wide";
    case FixAssocStatus::ALPHA_OUT_OF_RANGE: return "alpha_out_of_range";
    case FixAssocStatus::BAD_KEYFRAME_TIME: return "bad_keyframe_time";
    case FixAssocStatus::PRE_REJECTED: return "pre_rejected";
  }
  return "unknown";
}

// One RTK epoch and the two keyframes that bracket it. The factor evaluates the
// Pose3 geodesic at alpha, so alpha is in [0,1] for a normal (non-extrapolated)
// association and slightly outside it when extrapolation is allowed.
struct FixAssociation
{
  int fix_index = -1;
  int key_i = -1;
  int key_j = -1;
  double alpha = 0.0;
  double dt = 0.0;  // t_fix - t_key_i (negative when extrapolated at the start)
  FixAssocStatus status = FixAssocStatus::BAD_KEYFRAME_TIME;
  bool valid = false;
};

struct RtkInterpParams
{
  // Maximum span of the bracketing keyframe interval. A wider bracket means the
  // constant-twist interpolation assumption is not credible; drop the epoch.
  double max_bracket_dt = 1.5;
  // Allowed extrapolation past the first/last keyframe, seconds. 0 = none.
  double max_extrapolation = 0.0;
  // Guards against floating-point alpha outliers; the bracket test normally
  // keeps alpha in [0,1] already.
  double min_alpha = 0.0;
  double max_alpha = 1.0;
  // Fixes closer than this in time are one epoch (duplicate publication) and
  // must not produce two factors.
  double duplicate_dt = 1e-6;
};

// Index b of the keyframe interval [b, b+1] that contains t. At an exact
// keyframe time the earlier interval is returned (alpha = 1), matching
// associateRtkEpochs. Returns -1 when t is outside [first, last] or when the
// keyframe times are not strictly increasing. Used by the nearest-placement
// ablation arm to apply the same epoch-level static rule as the interpolated
// arm.
inline int findKeyframeBracket(const std::vector<double> &keyframe_t, double t)
{
  const int n = static_cast<int>(keyframe_t.size());
  if (n < 2) return -1;
  for (int i = 1; i < n; ++i)
    if (!(keyframe_t[i] > keyframe_t[i - 1])) return -1;
  if (t < keyframe_t.front() || t > keyframe_t.back()) return -1;
  int lo = 0, hi = n - 2;
  while (lo < hi)
  {
    const int mid = (lo + hi + 1) / 2;
    if (keyframe_t[mid] < t)
      lo = mid;
    else
      hi = mid - 1;
  }
  return lo;
}

// Associates every fix epoch to its bracketing keyframes.
//
// `keyframe_t` must be strictly increasing. `fix_t` is expected to be
// non-decreasing; duplicate timestamps are reported once and then dropped.
// `out` receives one record per accepted epoch plus one record per rejected
// epoch (except duplicates) so the caller can trace why an epoch was skipped.
// Returns the number of valid associations (also the size of the accepted
// subset). On non-monotonic keyframe times no association is valid and every
// fix is reported as BAD_KEYFRAME_TIME.
inline std::size_t associateRtkEpochs(const std::vector<double> &keyframe_t,
                                      const std::vector<double> &fix_t,
                                      const RtkInterpParams &params,
                                      std::vector<FixAssociation> &out)
{
  out.clear();
  const int n = static_cast<int>(keyframe_t.size());
  if (n < 2 || fix_t.empty()) return 0;

  bool monotonic = true;
  for (int i = 1; i < n; ++i)
  {
    if (!(keyframe_t[i] > keyframe_t[i - 1]))
    {
      monotonic = false;
      break;
    }
  }
  if (!monotonic)
  {
    out.reserve(fix_t.size());
    for (std::size_t k = 0; k < fix_t.size(); ++k)
    {
      FixAssociation a;
      a.fix_index = static_cast<int>(k);
      a.status = FixAssocStatus::BAD_KEYFRAME_TIME;
      out.push_back(a);
    }
    return 0;
  }

  const double t_first = keyframe_t.front();
  const double t_last = keyframe_t.back();
  std::size_t valid = 0;
  int seg = 0;  // current bracket is [seg, seg+1]
  bool have_prev = false;
  double prev_t = 0.0;

  out.reserve(fix_t.size());
  for (std::size_t k = 0; k < fix_t.size(); ++k)
  {
    const double t = fix_t[k];
    FixAssociation a;
    a.fix_index = static_cast<int>(k);

    if (have_prev && std::fabs(t - prev_t) <= params.duplicate_dt)
    {
      a.status = FixAssocStatus::DUPLICATE_EPOCH;
      out.push_back(a);
      continue;
    }
    prev_t = t;
    have_prev = true;

    bool extrapolated = false;
    if (t < t_first)
    {
      if (params.max_extrapolation <= 0.0 ||
          (t_first - t) > params.max_extrapolation)
      {
        a.status = FixAssocStatus::BEFORE_RANGE;
        out.push_back(a);
        continue;
      }
      seg = 0;
      extrapolated = true;
    }
    else if (t > t_last)
    {
      if (params.max_extrapolation <= 0.0 ||
          (t - t_last) > params.max_extrapolation)
      {
        a.status = FixAssocStatus::AFTER_RANGE;
        out.push_back(a);
        continue;
      }
      seg = n - 2;
      extrapolated = true;
    }
    else
    {
      // Advance to the bracket that contains t. At t == keyframe_t[i] the
      // previous interval is kept (alpha = 1); both endpoints are equivalent,
      // and this keeps the rule deterministic.
      while (seg + 2 < n && t > keyframe_t[seg + 1]) ++seg;
    }

    const double span = keyframe_t[seg + 1] - keyframe_t[seg];
    if (span > params.max_bracket_dt)
    {
      a.status = FixAssocStatus::BRACKET_TOO_WIDE;
      out.push_back(a);
      continue;
    }
    const double alpha = (t - keyframe_t[seg]) / span;
    // min/max alpha bound the normal interpolation interval. An explicitly
    // allowed extrapolation is governed by max_extrapolation instead, so its
    // alpha may legitimately fall outside [min_alpha, max_alpha].
    if (!extrapolated &&
        (alpha < params.min_alpha || alpha > params.max_alpha))
    {
      a.status = FixAssocStatus::ALPHA_OUT_OF_RANGE;
      out.push_back(a);
      continue;
    }

    a.key_i = seg;
    a.key_j = seg + 1;
    a.alpha = alpha;
    a.dt = t - keyframe_t[seg];
    a.status = FixAssocStatus::OK;
    a.valid = true;
    out.push_back(a);
    ++valid;
  }
  return valid;
}

}  // namespace fast_livo

#endif  // RTK_TIME_ASSOCIATION_H_
