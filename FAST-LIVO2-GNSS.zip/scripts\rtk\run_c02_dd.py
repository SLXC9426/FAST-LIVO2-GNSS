#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Generate the campus-02 DD stream (GPS 02:22:27-02:35:52).

The c02 bag runs 806 s (UTC 10:22:08.30-10:35:35.15); the existing GREAT-MSF
campus-02 TCRTK .ins covers SOW 181468-182153 (GPS 02:24:28-02:42:33), i.e.
~11.4 minutes of the bag with ~90% fixed epochs.  The first ~2 minutes of the
bag are float-only in this stream, which is expected for the N=1 P2 check.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rtk_preprocess import (parse_obs_file, parse_nav_file, build_dd_rows,
                            write_dd_csv)

ROVER = "/home/slxc9426/great_pvt/obs/campus-day.20O"
NAV = "/home/slxc9426/great_pvt/gnss/brdm3010.20p"
BASE = "/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02"
BASES = [os.path.join(BASE, f) for f in
         ("base_0200.rnx", "base_0215.rnx", "base_0230.rnx", "base_0245.rnx")]
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw"
CSV = os.path.join(OUT, "c02_dd_gps_bds.csv")
META = os.path.join(OUT, "c02_dd_meta.json")

# c02 bag start UTC 1603765328.30 -> GPS 1603765346.30; bag end GPS 1603766153.15.
T0 = 1603765347
T1 = 1603766152
# c02 GREAT-MSF TC-RTK uses the WUH2 coordinate below (c02 XML), which differs
# from the c01/FAST-LIVO2 base by ~3.75 m in Z.  Keep the c02 DD generation, the
# fixed-phase derivation and RtkTight::base_ecef on THIS coordinate.
BASE_ECEF = (-2267750.14853585, 5009154.50747098, 3221294.38263863)


def main():
    print(f"c02 window GPS {T0}..{T1} ({T1-T0+1} s), UTC {T0-18}..{T1-18}")
    rv, leap = parse_obs_file(ROVER, ("G", "C"), (T0, T1))
    base_epochs = []
    for bp in BASES:
        bb, _ = parse_obs_file(bp, ("G", "C"), (T0, T1))
        base_epochs.extend(bb)
    base_epochs.sort(key=lambda e: e.t_gps)
    print(f"rover epochs={len(rv)}, base epochs={len(base_epochs)}, leap={leap}")
    if not rv:
        raise SystemExit("no rover epochs in c02 window")
    if not base_epochs:
        raise SystemExit("no base epochs in c02 window")
    nav = parse_nav_file(NAV, ("G", "C"))
    print(f"ephemerides={len(nav)} sats")
    rows = build_dd_rows(rv, base_epochs, nav, BASE_ECEF)
    write_dd_csv(rows, CSV)
    meta = dict(window_gps=[T0, T1], window_utc=[T0 - leap, T1 - leap],
                leap_seconds=leap, n_rover_epochs=len(rv),
                n_base_epochs=len(base_epochs), n_dd_rows=len(rows),
                base_ecef=list(BASE_ECEF), base_files=BASES,
                note="c02 GREAT-MSF .ins covers GPS 02:24:28-02:42:33; "
                     "first ~2 min of this DD stream are float-only")
    with open(META, "w", encoding="utf-8") as f:
        json.dump(meta, f, indent=2)
    print("wrote", CSV, META)


if __name__ == "__main__":
    main()
