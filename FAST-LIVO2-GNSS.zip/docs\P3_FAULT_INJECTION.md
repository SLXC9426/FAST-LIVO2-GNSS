# P3: 故障注入验证（错误固定 / DD 中断 / 位置异常）

## 目标

P2 只验证了正常数据上的四源融合。P3 用可控故障回答三个问题：

1. 外部 RTK 整数固定错误时，固定相位更新会不会把状态拉走？
2. DD 流中断（GNSS 遮挡）时，系统是否退化为 LIVO-only，恢复时是否跳变？
3. 位置域 NavSatFix 出现大 outlier 时，卡方门是否拒绝？

所有故障都注入到已有数据上，LIVO 输入本身不变，因此轨迹差异只能来自
GNSS/RTK 处理链。

## 注入方法

### 错误固定：`scripts/rtk/inject_dd_fault.py --mode fixed_bias`

在 `[t0,t1]` 内对每个双差对执行：

- `fix_valid[i] = 1`（让外部固定相位进入固定相位支路）；
- `dd_phase_fixed[i] += bias`（公共偏差，单位 m）；
- `dd_phase`、`dd_code` 保持干净，隔离“整数错”而不是“观测错”。

本次 c01：`t0=1603764772`、`t1=1603764802`（run 200–230 s）、
`bias=1.0 m`（约 5 个 L1 波长），31 个 DD 历元受影响。

### DD 中断：`--mode drop`

同一窗口内删除全部 `/rtk/dd` 消息（31 条），模拟 30 s GNSS 遮挡。

### 位置异常：`scripts/eval/inject_outlier.py`

只改一个 NavSatFix 历元的位置，保留时间戳、fix status 和
`position_covariance`。本次在 `t=1603764772` 注入东向 `+30 m`，
输出只含 `/gnss_rtk` 的 bag。

### 命令

```bash
SRC=~/datasets/GREAT/campus01_rtk1hz.bag
DD=.../c01_dd_greatmsf.bag
python3 scripts/rtk/inject_dd_fault.py --in "$DD" \
    --out ~/p3_bags/c01_dd_bad1m.bag --mode fixed_bias --bias 1.0 \
    --t0 1603764772 --t1 1603764802
python3 scripts/rtk/inject_dd_fault.py --in "$DD" \
    --out ~/p3_bags/c01_dd_drop30.bag --mode drop \
    --t0 1603764772 --t1 1603764802
python3 scripts/eval/inject_outlier.py "$SRC" /gnss_rtk t=1603764772 30 \
    ~/p3_bags/c01_fix_out30.bag --axis e
```

## 1. 1.0 m 错误固定

### 第一版：发现一个被接受的坏历元

修复前（`p3_c01_bad1m`）在故障窗口内大部分固定历元被卡方门拒绝，但
`t=1603764790` 出现：

```
[RTK] accept t=1603764790.00 pairs=13 fixed=11 ... gamma=34.9/38.9
      |r_phase|=2.10 |dx_pos|=1.000 ... rej_phase=7
```

`rej_phase=7` 表示 11 个固定对里 7 个已被逐对门剔除，剩下 4 个仍带着
**同一个** 1 m 公共偏差；逐对 IGG3 无法区分“4 个好对”和“4 个同向坏对”，
全局卡方又因为 LIO 先验还比较松而通过。`|dx_pos|=1.000` 是 `max_corr=1.0`
截断后的值，说明原本的修正量大于 1 m。轨迹因此出现一次米级跳变，随后被
浮点 DD 拉回。

### 修复：固定对一致性门 + 失败后退出 FIXED

`RtkTight::Config` 新增：

- `fixed_consensus_en`（默认 true）；
- `fixed_consensus_min_frac`（默认 0.5）；
- `fixed_consensus_min_pairs`（默认 4）。

在固定相位 IGG3 之后、全局卡方之前：

```
n_fixed_used = n_fixed - rej_phase
n_fixed_need = max(fixed_consensus_min_pairs,
                   ceil(fixed_consensus_min_frac * n_fixed))
n_fixed_used < n_fixed_need  ->  整个固定解历元丢弃
```

监督器同时新增 `fixed_q_reject_cap`（默认 0.30）：只要本历元 RTK 更新被拒绝，
`q_fix` 就被压到 0.30 以下，FIXED 状态在 `fixed_exit_s` 后退出，不会每 2 s
重新进入 FIXED 再试一次坏整数。

### 结果

| 运行 | 固定窗口行为 | full 3D | steady 3D | fault win 200–235 s |
|---|---|---|---|---|
| 干净 P2（`p2_adapt2_c01_full`） | 正常 | 2.10 | 1.33 | 0.1573 |
| 错误固定 v1（无一致性门） | 1 个历元接受 1 m 修正 | 1.7284 | 0.8411 | 0.1631 |
| 错误固定 v2（一致性门） | 固定解全部拒绝/忽略 | 1.5821 | 0.8397 | 0.1559 |
| 错误固定 v3（最终代码） | 固定解全部拒绝/忽略 | 1.6482 | 0.8982 | 0.1609 |
| 错误固定 0.5 m | 固定解全部拒绝/忽略 | 1.7671 | 0.8875 | 0.1592 |

v2/v3 故障窗口内不再出现 `fixed=...` 的 `accept`；固定历元要么被
`gamma > gate` 拒绝，要么被 `fixed_consensus` 拒绝。窗口 RMSE 与干净运行
同水平（0.1559–0.1609 vs 0.1573），说明没有残留跳变。v2/v3 的
full/steady 差异来自 LIO 初始化和运行间非确定性，不是故障处理差异。

一致性门在干净数据的初始收敛段也会触发（例如 `t=1603764665`，
`used=3/7 need=4`）：此时 LIO 与 RTK 仍有米级帧差，逐对门已剔除多数固定对，
整历元丢弃比用 3 个幸存对强拉更安全。v2 的 full/steady 不差于 v1
（1.5821/0.8397 vs 1.7284/0.8411），说明该门没有牺牲正常收敛。

0.5 m 偏差也做了同样的 30 s 注入：故障窗口内没有任何 `fixed>0` 的 accept，
窗口 RMSE 0.1592、最大相邻步长 0.488 m（真实运动时刻），没有跳变。但该
窗口的 LIO 状态本身有约 1.5 m 帧差，固定相位残差约 2 m 主要来自这个帧差，
而不是 0.5 m 偏差；因此这不是“最小可检测偏差”的严格实验，只说明在当前
状态下 0.5 m 偏差没有进入状态。

## 2. DD 中断 30 s

`c01_dd_drop30.bag` 删除 200–230 s 的 31 条 DD 消息。监督器的
`rtk_timeout_s=1.5` 超时路径在 `handleRTK()` 每个 LIO 帧检查：

- 中断期间：`[SUP] mode=REJECT w_rtk=0.00 ... n_fixed=0 ratio=0.00`，
  RTK/GNSS 权重都为 0，系统为 LIVO-only；
- 恢复第一个 DD 历元：监督器仍是 REJECT，RTK 以 `w=1e-3` 软权重处理，
  修正量可忽略；
- 连续 accepted 达 `reject_recover_s=1.0 s` 后进入 FLOAT，`use_fixed_phase=false`，
  只使用浮点 DD；FIXED 需要重新积累 `fixed_enter_s=2 s` 的好质量。

| 运行 | full 3D | steady 3D | win 200–235 s | win 230–300 s |
|---|---|---|---|---|
| 干净 P2 | 2.10 | 1.33 | 0.1573 | 0.3000 |
| DD 中断 30 s | 1.9042 | 0.9913 | 0.1595 | 0.3031 |

full/steady 的差异来自 30 s LIVO-only 期间的自然漂移；故障窗口和恢复后窗口
与干净运行几乎相同。轨迹最大相邻步长在中断运行/干净运行分别为
0.617 m / 0.600 m，且都出现在同一时刻（真实快速运动），没有恢复跳变。

## 3. NavSatFix +30 m 异常

`great_campus01_p2_pos.yaml` 关闭 RTK DD（`rtk.enable: false`），打开
`position_update_en: true`，只用 NavSatFix 位置域更新。在 200 s 注入
东向 +30 m 的单历元 outlier，协方差保持不变。

c01 的 `p2_pos` 配置原先使用 `gate_sigma_mode: table`，实测在 LIO/GNSS
存在米级帧差时几乎全部历元被拒（`evaluated=160 accepted=22 rejected=137`）。
这与“门太松”相反，是 table 协方差相对 LIO 先验过紧。改用 c02 已在用的
`gate_sigma_mode: adaptive` 后，正常历元接受率为 98.1%，门限由在线 innovation
尺度估计，不依赖数据集。

注入历元的日志：

```
[GNSS] Outlier rejected, t=200.1 gamma=14.6389 > 7.815
       (gate_sigma_mode=adaptive, fix_status=5)
```

| 运行 | evaluated/accepted/rejected | full 3D | steady 3D | win 195–210 s |
|---|---|---|---|---|
| 干净对照 | 480 / 469 / 10 | 1.8001 | 0.8967 | 0.1434 |
| NavSatFix +30 m | 480 / 471 / 8 | 1.5231 | 0.7707 | 0.1403 |

干净对照在 `t=200.1` 没有拒绝记录；注入运行恰好在 `t=200.1` 产生
`gamma=14.64 > 7.815` 的拒绝。200 s 附近两种运行的最大相邻步长分别为
0.443 m 和 0.460 m，且都出现在真实快速运动的同一时刻（`t≈1603764775.1`），
没有 30 m 级跳变。full/steady 的差异来自两次运行的初始对齐和 LIO 非确定性，
不是 outlier 的影响；窗口指标 0.1403 vs 0.1434 也说明该历元没有改变局部轨迹。

`|dx_pos|` 中位数为 0，说明该位置域配置的增益很小
（`P_pos_eff=0.0316 m`，LIO 协方差很紧）；因此本项主要验证“门拒绝坏历元”，
而不是“位置域融合带来精度增益”。

## 复现清单

| 测试 | tag | 注入 bag | 配置 |
|---|---|---|---|
| 错误固定 v1（修复前） | `p3_c01_bad1m` | `c01_dd_bad1m.bag` | `great_campus01_p2` |
| 错误固定 v2（一致性门） | `p3_c01_bad1m_v2` | `c01_dd_bad1m.bag` | `great_campus01_p2` |
| 错误固定 v3（最终代码） | `p3_c01_bad1m_v3` | `c01_dd_bad1m.bag` | `great_campus01_p2` |
| 错误固定 0.5 m | `p3_c01_bad05` | `c01_dd_bad05.bag` | `great_campus01_p2` |
| DD 中断 30 s | `p3_c01_drop30` | `c01_dd_drop30.bag` | `great_campus01_p2` |
| NavSatFix +30 m | `p3_c01_fix30_v2` | `c01_fix_out30.bag` | `great_campus01_p2_pos` |
| 位置域干净对照 | `p3_c01_pos_clean` | 无 | `great_campus01_p2_pos` |

运行命令模板：

```bash
cd ~/catkin_ws/src/fast_livo
FORCE=1 bash scripts/eval/segment_run_rtk.sh campus01 rtk 0 300 <tag> \
    ~/datasets/GREAT/campus01_rtk1hz.bag <fault.bag> '' <config>
```

轨迹和日志分别在 `Log/result/<tag>.txt`、`~/seg_<tag>.log`；
`eval_unified.py` 的窗口指标用 `--win 200:235` 复现。

## 局限

- P3 目前只在 campus-01 上做了单次确定性注入；c02/c03 未做故障注入。
- 故障窗口没有独立真值，窗口指标使用局部 fit；结论主要看“是否接受坏观测”
  和“相邻步长是否跳变”，而不是绝对精度。
- 一致性门针对**公共模**整数错误；当偏差小于状态协方差（例如 0.2–0.5 m）
  时仍可能通过。后续可增加“固定解 vs 浮点解”同历元一致性检验。
- 一致性门失败时当前实现是整历元拒绝，而不是同历元回退浮点相位；这会损失
  一个历元的相位信息，但避免了坏固定进入状态。监督器会在秒级退出 FIXED。
- 1.0 m 注入是较大故障；0.5 m 注入未进入状态，但由于同期 LIO 帧差约 1.5 m，
  不能据此给出最小可检测偏差。0.2 m 及“帧差已收敛时的 0.5 m”尚未测试。

## 相关代码/配置

- `include/rtk_tight.h`：`fixed_consensus_*`
- `src/rtk_tight.cpp`：固定对一致性门
- `include/fusion_supervisor.h`：`fixed_q_reject_cap`、`reject_recover_s`
- `src/LIVMapper.cpp`：参数读取、RTK 超时、supervisor 更新
- `config/great_campus01_p2.yaml`、`great_campus01_p2_pos.yaml`
- `scripts/rtk/inject_dd_fault.py`、`scripts/eval/inject_outlier.py`
