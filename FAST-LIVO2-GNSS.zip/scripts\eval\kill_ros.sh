#!/bin/bash
# Kill leftover ROS processes. The patterns live in THIS file (not in the
# invoking command line) so that `pkill -f` cannot match and kill its own shell
# - a trap that silently aborted the first version of segment_run.sh.
# Kill roslaunch first: if the node is killed while its launch is alive,
# respawn=true immediately restarts it and the orphan accumulates between runs.
pkill -9 -f 'roslaunch'        2>/dev/null
pkill -9 -f 'fastlivo_mapping' 2>/dev/null
pkill -9 -f 'online_graph_node' 2>/dev/null
pkill -9 -f 'rosbag/play'      2>/dev/null
pkill -9 -f 'rosmaster'        2>/dev/null
pkill -9 -f '/rosout'          2>/dev/null
sleep 2
exit 0
