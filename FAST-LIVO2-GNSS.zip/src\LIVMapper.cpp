/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.

Developer: Chunran Zheng <zhengcr@connect.hku.hk>

For commercial use, please contact me at <zhengcr@connect.hku.hk> or
Prof. Fu Zhang at <fuzhang@hku.hk>.

This file is subject to the terms and conditions outlined in the 'LICENSE' file,
which is included as part of this source code package.
*/

#include "LIVMapper.h"

#include "yaw_accept_policy.h"

#include <algorithm>
#include <cmath>
#include <chrono>
#include <cstdlib>
#include <fstream>
#include <filesystem>
#include <utility>

#include <fast_livo/OnlineGraphFix.h>
#include <fast_livo/OnlineGraphKeyframe.h>
#include <fast_livo/OnlineGraphVel.h>
#include "online_graph_vel_utils.h"

namespace
{
double gnssReceiveTime()
{
  return std::chrono::duration<double>(
      std::chrono::steady_clock::now().time_since_epoch()).count();
}
// Robust scale estimate of a residual magnitude sample: 1.4826 * median(|r|).
// This is the standard MAD-style sigma estimator about a known zero mean. Note
// it is deliberately NOT centred on the sample median: the LIO-vs-GNSS
// disagreement is largely a slowly varying offset, and centring would measure
// only the local scatter (~0.1 m) instead of the disagreement magnitude (~7 m),
// which would keep the chi-square gate closed for ever.
double robustSigma(const std::deque<double> &v)
{
  const int n = (int)v.size();
  if (n < 4) return -1.0;
  std::vector<double> s(v.begin(), v.end());
  for (size_t i = 0; i < s.size(); i++) s[i] = fabs(s[i]);
  std::nth_element(s.begin(), s.begin() + n / 2, s.end());
  return 1.4826 * s[n / 2];
}

// 2D Procrustes fit of the map ENU(E,N) -> world(x,y) over the selected
// samples. `keep[i]==0` excludes sample i. Fills the fitted yaw, the
// least-squares translation (vertical component forced to zero, see the caller)
// and the horizontal residual RMS. `resid_all[i]` receives the per-sample
// horizontal residual of the fit (0 for excluded samples) so the caller can run
// one robust refit pass. Returns false when the kept set is degenerate.
bool fitEnuWorld2D(const std::deque<V3D> &enu, const std::deque<V3D> &world,
                   const std::vector<char> &keep, double &yaw_out, V3D &t_out,
                   double &resid_out, std::vector<double> &resid_all)
{
  const int n = (int)enu.size();
  int m = 0;
  V3D mu_e = V3D::Zero(), mu_w = V3D::Zero();
  for (int i = 0; i < n; i++)
  {
    if (!keep[i]) continue;
    mu_e += enu[i];
    mu_w += world[i];
    m++;
  }
  if (m < 3) return false;
  mu_e /= (double)m;
  mu_w /= (double)m;

  double sc = 0.0, ss = 0.0, see = 0.0;
  for (int i = 0; i < n; i++)
  {
    if (!keep[i]) continue;
    const double ae = enu[i](0) - mu_e(0), an = enu[i](1) - mu_e(1);
    const double bx = world[i](0) - mu_w(0), by = world[i](1) - mu_w(1);
    sc += ae * bx + an * by;
    ss += ae * by - an * bx;
    see += ae * ae + an * an;
  }
  if (see < 1e-6) return false;   // samples not spread out -> yaw undetermined

  yaw_out = std::atan2(ss, sc);
  const double cy = std::cos(yaw_out), sy = std::sin(yaw_out);
  M3D R = M3D::Identity();
  R(0, 0) = cy;  R(0, 1) = -sy;
  R(1, 0) = sy;  R(1, 1) = cy;
  t_out = mu_w - R * mu_e;
  t_out(2) = 0.0;

  resid_all.assign(n, 0.0);
  double s2 = 0.0;
  for (int i = 0; i < n; i++)
  {
    if (!keep[i]) continue;
    const V3D r = R * enu[i] + t_out - world[i];
    const double rh = std::sqrt(r(0) * r(0) + r(1) * r(1));
    resid_all[i] = rh;
    s2 += rh * rh;
  }
  resid_out = std::sqrt(s2 / (double)m);
  return true;
}
} // namespace

LIVMapper::LIVMapper(ros::NodeHandle &nh)
    : extT(0, 0, 0),
      extR(M3D::Identity())
{
  extrinT.assign(3, 0.0);
  extrinR.assign(9, 0.0);
  cameraextrinT.assign(3, 0.0);
  cameraextrinR.assign(9, 0.0);

  p_pre.reset(new Preprocess());
  p_imu.reset(new ImuProcess());

  readParameters(nh);
  VoxelMapConfig voxel_config;
  loadVoxelConfig(nh, voxel_config);

  visual_sub_map.reset(new PointCloudXYZI());
  feats_undistort.reset(new PointCloudXYZI());
  feats_down_body.reset(new PointCloudXYZI());
  feats_down_world.reset(new PointCloudXYZI());
  pcl_w_wait_pub.reset(new PointCloudXYZI());
  pcl_wait_pub.reset(new PointCloudXYZI());
  pcl_wait_save.reset(new PointCloudXYZRGB());
  pcl_wait_save_intensity.reset(new PointCloudXYZI());
  voxelmap_manager.reset(new VoxelMapManager(voxel_config, voxel_map));
  vio_manager.reset(new VIOManager());
  p_gnss.reset(new GnssProcess());
  root_dir = ROOT_DIR;
  initializeFiles();
  initializeComponents();
  path.header.stamp = ros::Time::now();
  path.header.frame_id = "camera_init";
}

LIVMapper::~LIVMapper() 
{
  if (graph_) graph_->stop();
}

void LIVMapper::readParameters(ros::NodeHandle &nh)
{
  nh.param<string>("debug/runtime_log_dir", runtime_log_dir_, string(ROOT_DIR) + "Log/");
  if (runtime_log_dir_.empty()) throw std::invalid_argument("empty runtime_log_dir");
  if (runtime_log_dir_.back() != '/') runtime_log_dir_ += '/';
  nh.param<bool>("debug/state_diagnostic_en", state_diagnostic_en_, false);
  nh.param<bool>("debug/gnss_pair_diagnostic_en", gnss_pair_diagnostic_en_, false);
  nh.param<string>("common/lid_topic", lid_topic, "/livox/lidar");
  nh.param<string>("common/imu_topic", imu_topic, "/livox/imu");
  nh.param<bool>("common/ros_driver_bug_fix", ros_driver_fix_en, false);
  nh.param<int>("common/img_en", img_en, 1);
  nh.param<int>("common/lidar_en", lidar_en, 1);
  nh.param<bool>("common/lio_update_en", lio_update_en, true);
  nh.param<double>("common/lio_off_after_s", lio_off_after_s, -1.0);
  nh.param<string>("common/img_topic", img_topic, "/left_camera/image");

  nh.param<bool>("vio/normal_en", normal_en, true);
  nh.param<bool>("vio/inverse_composition_en", inverse_composition_en, false);
  nh.param<int>("vio/max_iterations", max_iterations, 5);
  nh.param<double>("vio/img_point_cov", IMG_POINT_COV, 100);
  nh.param<bool>("vio/raycast_en", raycast_en, false);
  nh.param<bool>("vio/exposure_estimate_en", exposure_estimate_en, true);
  nh.param<double>("vio/inv_expo_cov", inv_expo_cov, 0.2);
  nh.param<int>("vio/grid_size", grid_size, 5);
  nh.param<int>("vio/grid_n_height", grid_n_height, 17);
  nh.param<int>("vio/patch_pyrimid_level", patch_pyrimid_level, 3);
  nh.param<int>("vio/patch_size", patch_size, 8);
  nh.param<double>("vio/outlier_threshold", outlier_threshold, 1000);
  // Improvement 1 (VIO side): depth-consistency occlusion check + robust photometric kernel
  nh.param<bool>("occlusion/vio_en", vio_occlusion_en_, false);
  // WP8f: renamed from occlusion/vio_depth_ratio - the value is an absolute
  // metre threshold (consumed as vio_manager->occlusion_depth_thresh), not a
  // ratio. The legacy key is still read so the existing configs that set it keep
  // their value; the new key wins when both are present.
  if (nh.hasParam("occlusion/vio_depth_thresh_m"))
    nh.param<double>("occlusion/vio_depth_thresh_m", vio_occlusion_depth_thresh_m_, 0.5);
  else
    nh.param<double>("occlusion/vio_depth_ratio", vio_occlusion_depth_thresh_m_, 0.5);
  nh.param<int>("vio/robust_kernel_type", vio_robust_kernel_type_, 0);
  nh.param<double>("vio/robust_delta", vio_robust_delta_, 2.0);
  // R6 T3-2: bound the visual sparse map by the LIO map-sliding cube.
  nh.param<bool>("vio/visual_map_prune_en", vio_visual_prune_en_, false);
  nh.param<int>("vio/visual_map_prune_margin", vio_visual_prune_margin_, 20);
  nh.param<int>("vio/visual_map_prune_min_voxels", vio_visual_prune_min_voxels_, 20000);

  // Improvement 2: sliding-window factor-graph backend
  nh.param<bool>("factor_graph/en", graph_cfg_.en, false);
  // P5b: bounded-history GTSAM position graph, default off.
  nh.param<bool>("online_graph/en", online_graph_en_, false);
  nh.param<int>("online_graph/window", online_graph_window_, 1500);
  // P6d: slow output-level graph correction, default off.
  nh.param<bool>("graph_feedback/en", graph_feedback_en_, false);
  nh.param<double>("graph_feedback/max_step", graph_feedback_max_step_, 0.01);
  nh.param<double>("graph_feedback/max_offset", graph_feedback_max_offset_, 2.0);
  nh.param<double>("graph_feedback/max_age", graph_feedback_max_age_, 1.5);
  nh.param<double>("graph_feedback/gain", graph_feedback_gain_, 1.0);
  // P6d-2: 1 Hz graph global pose + 20 Hz EKF relative motion, default off.
  nh.param<bool>("graph_fusion/en", graph_fusion_en_, false);
  nh.param<double>("graph_fusion/max_age", graph_fusion_max_age_, 3.0);
  nh.param<double>("graph_fusion/blend_s", graph_fusion_blend_s_, 0.3);
  nh.param<int>("graph_fusion/path_len", graph_fusion_path_len_, 5000);
  nh.param<double>("graph_fusion/relative_max_error",
                   graph_fusion_relative_max_error_, 1.0);
  nh.param<double>("graph_fusion/static_speed", graph_fusion_static_speed_, 0.15);
  nh.param<std::string>("graph_fusion/mode", graph_fusion_mode_, "auto");
  nh.param<int>("factor_graph/window_size", graph_cfg_.window_size, 25);
  nh.param<double>("factor_graph/kf_dist", graph_cfg_.kf_dist, 1.0);
  nh.param<double>("factor_graph/kf_rot_deg", graph_cfg_.kf_rot_deg, 10.0);
  nh.param<int>("factor_graph/kf_min_frames", graph_cfg_.kf_min_frames, 10);
  nh.param<double>("factor_graph/odom_rot_sigma", graph_cfg_.odom_rot_sigma, 0.01);
  nh.param<double>("factor_graph/odom_pos_sigma", graph_cfg_.odom_pos_sigma, 0.05);
  nh.param<double>("factor_graph/imu_gyr_sigma", graph_cfg_.imu_gyr_sigma, 0.02);
  nh.param<double>("factor_graph/imu_acc_sigma", graph_cfg_.imu_acc_sigma, 0.5);
  nh.param<double>("factor_graph/imu_bg_sigma", graph_cfg_.imu_bg_sigma, 0.0001);
  nh.param<double>("factor_graph/imu_ba_sigma", graph_cfg_.imu_ba_sigma, 0.0005);
  nh.param<bool>("factor_graph/marginalize", graph_cfg_.marginalize, true);
  nh.param<bool>("factor_graph/gnss_en", graph_cfg_.gnss_en, true);
  nh.param<double>("factor_graph/gnss_pos_sigma", graph_cfg_.gnss_pos_sigma, 0.5);
  nh.param<bool>("factor_graph/robust_en", graph_cfg_.robust_en, true);
  nh.param<double>("factor_graph/robust_delta", graph_cfg_.robust_delta, 1.5);
  nh.param<bool>("factor_graph/thread_en", graph_cfg_.thread_en, true);
  nh.param<int>("factor_graph/max_gn_iter", graph_cfg_.max_gn_iter, 8);
  // R3 P1-1: the per-link factor diagnostics behind the drift diagnosis
  // (EVAL_PROTOCOL 15). Off by default; set N to print every N-th link.
  nh.param<int>("factor_graph/diag_link_every_n", graph_cfg_.diag_link_every_n, 0);
  // R3 P1-1 third layer: the per-node velocity anchor weight (default = the
  // historical hard-coded 1e2).
  nh.param<double>("factor_graph/v_prior_weight", graph_cfg_.v_prior_weight, 100.0);
  // R3 P1-1 third layer: anchor the graph's velocity reference to the
  // position-implied velocity over this many keyframes (0 = the filter's
  // velocity, the historical behaviour). See EVAL_PROTOCOL 15.6 for why.
  nh.param<int>("factor_graph/v_ref_pos_frames", graph_v_ref_pos_frames_, 0);

  // Improvement 1/3: latency & dynamic statistics logging
  nh.param<bool>("evo/latency_en", latency_en_, false);
  // R6 P0-C: 0 = off; >0 logs memory/buffer sizes every N main-loop iterations
  // (100 iterations ≈ 2.5 s at the c03 loop rate). Output: Log/result/<seq>_mem.csv.
  nh.param<int>("debug/mem_log_every_n", mem_log_every_n_, 0);

  nh.param<double>("time_offset/exposure_time_init", exposure_time_init, 0.0);
  nh.param<double>("time_offset/img_time_offset", img_time_offset, 0.0);
  nh.param<double>("time_offset/imu_time_offset", imu_time_offset, 0.0);
  nh.param<double>("time_offset/lidar_time_offset", lidar_time_offset, 0.0);
  // R3-WP10a: GNSS had no time offset while LiDAR/IMU/camera all did, even though
  // the tightly-coupled update is sensitive to a 0.1 s level delay (5 m/s -> 0.5 m).
  // Same sign convention as the IMU offset above: the stamp is reduced by it.
  // GREAT is GPS-disciplined so the default stays 0.
  nh.param<double>("time_offset/gnss_time_offset", gnss_time_offset, 0.0);
  // R5.5: all observations must enter the estimator on one time axis. These
  // existed only for PVT before; velocity and RTK DD were on raw header stamps.
  nh.param<double>("time_offset/gnss_vel_time_offset", gnss_vel_time_offset, 0.0);
  nh.param<double>("time_offset/rtk_time_offset", rtk_time_offset, 0.0);
  nh.param<bool>("uav/imu_rate_odom", imu_prop_enable, false);
  nh.param<bool>("uav/gravity_align_en", gravity_align_en, false);

  nh.param<string>("evo/seq_name", seq_name, "01");
  nh.param<bool>("evo/pose_output_en", pose_output_en, false);
  nh.param<double>("imu/gyr_cov", gyr_cov, 1.0);
  nh.param<double>("imu/acc_cov", acc_cov, 1.0);
  nh.param<double>("imu/scale_cov", scale_cov, 1e-6);
  nh.param<int>("imu/imu_int_frame", imu_int_frame, 3);
  nh.param<bool>("imu/imu_en", imu_en, false);
  nh.param<bool>("imu/gravity_est_en", gravity_est_en, true);
  nh.param<bool>("imu/ba_bg_est_en", ba_bg_est_en, true);

  nh.param<double>("preprocess/blind", p_pre->blind, 0.01);
  nh.param<double>("preprocess/filter_size_surf", filter_size_surf_min, 0.5);
  nh.param<bool>("preprocess/hilti_en", hilti_en, false);
  nh.param<int>("preprocess/lidar_type", p_pre->lidar_type, AVIA);
  nh.param<int>("preprocess/scan_line", p_pre->N_SCANS, 6);
  nh.param<int>("preprocess/point_filter_num", p_pre->point_filter_num, 3);
  nh.param<bool>("preprocess/feature_extract_enabled", p_pre->feature_enabled, false);

  nh.param<int>("pcd_save/interval", pcd_save_interval, -1);
  nh.param<bool>("pcd_save/pcd_save_en", pcd_save_en, false);
  nh.param<int>("pcd_save/type", pcd_save_type, 0);
  nh.param<bool>("image_save/img_save_en", img_save_en, false);
  nh.param<int>("image_save/interval", img_save_interval, 1);

  nh.param<bool>("pcd_save/colmap_output_en", colmap_output_en, false);
  nh.param<double>("pcd_save/filter_size_pcd", filter_size_pcd, 0.5);
  nh.param<vector<double>>("extrin_calib/extrinsic_T", extrinT, vector<double>());
  nh.param<vector<double>>("extrin_calib/extrinsic_R", extrinR, vector<double>());
  nh.param<vector<double>>("extrin_calib/Pcl", cameraextrinT, vector<double>());
  nh.param<vector<double>>("extrin_calib/Rcl", cameraextrinR, vector<double>());
  nh.param<double>("debug/plot_time", plot_time, -10);
  nh.param<int>("debug/frame_cnt", frame_cnt, 6);

  // ZUPT parameters
  nh.param<bool>("zupt/enable", zupt_enable_, false);
  nh.param<double>("zupt/static_deg", zupt_static_deg_, 0.6);
  nh.param<double>("zupt/move_deg", zupt_move_deg_, 1.2);
  nh.param<double>("zupt/acc_move", zupt_acc_move_, 0.3);
  nh.param<double>("zupt/settle_s", zupt_settle_s_, 0.3);
  // A3: static position hold and its IMU-only release tests
  nh.param<bool>("zupt/hold_pos", zupt_hold_pos_en_, true);
  nh.param<double>("zupt/release_vel", zupt_release_vel_, 0.25);
  nh.param<double>("zupt/hold_max_s", zupt_hold_max_s_, 300.0);
  // R4-1 (A3-1b): extend the report hold past the IMU release while GNSS says
  // the antenna has not moved. Threshold is per-dataset calibrated from the
  // RTK's own static epoch noise (see LIVMapper.h); defaults keep history.
  nh.param<bool>("zupt/hold_veto_gnss", zupt_hold_veto_gnss_en_, false);
  nh.param<double>("zupt/hold_veto_thresh", zupt_hold_veto_thresh_, 2.0);
  nh.param<double>("zupt/hold_veto_stale_s", zupt_hold_veto_stale_s_, 45.0);
  nh.param<double>("zupt/hold_veto_max_s", zupt_hold_veto_max_s_, 300.0);
  nh.param<double>("zupt/hold_veto_min_hold_s", zupt_hold_veto_min_hold_s_, 10.0);

  // GNSS parameters
  nh.param<bool>("common/gnss_en", gnss_en, false);
  nh.param<string>("common/gnss_topic", gnss_topic, "/gnss/fix");
  // A2.1: quality side-channel published by the PVT relay. Empty = disabled,
  // and the old NavSatFix-only chain is unchanged.
  nh.param<string>("common/gnss_quality_topic", gnss_quality_topic,
                   gnss_quality_topic);
  nh.param<string>("gnss/quality_source", gnss_quality_source_, "ublox");
  nh.param<double>("gnss/quality_wait_sec", gnss_quality_wait_sec_, 0.2);
  nh.param<int>("gnss/quality_capacity", gnss_quality_capacity_, 1000);
  if (!std::isfinite(gnss_quality_wait_sec_) || gnss_quality_wait_sec_ <= 0.0 ||
      gnss_quality_capacity_ <= 0)
    throw std::invalid_argument("invalid gnss quality_wait_sec/quality_capacity");
  // Phase 2: keep the NavSatFix path for ENU<->world alignment only.
  nh.param<bool>("gnss/position_update_en", gnss_position_update_en, true);
  // R1 (P0-1): reject observations that are not contemporaneous with the LIO
  // state epoch (see LIVMapper.h). 0 restores the unguarded pre-P0 behaviour.
  nh.param<double>("gnss/time_sync_tol", gnss_time_sync_tol, 0.05);
  nh.param<bool>("gnss/state_scale_en", gnss_state_scale_en, false);
  nh.param<vector<double>>("extrin_calib/gnss_T", gnssextrinT, vector<double>());
  // 0 = derive from the observation dimension (3 rows -> 7.815, 6 rows with the
  // velocity model -> 12.592, both 95%). A value > 0 overrides the automatic
  // choice; the previous default of 7.815 made the gate silently too tight as
  // soon as the velocity rows were enabled.
  nh.param<double>("gnss/outlier_threshold", gnss_outlier_thresh, 0.0);
  nh.param<bool>("gnss/outlier_rejection", gnss_outlier_rejection, true);
  // R3-WP10a: fix-type noise table (defaults = the previously hard-coded values)
  nh.param<double>("gnss/sigma_fixed", gnss_sigma_fixed, 1.2);
  nh.param<double>("gnss/sigma_float", gnss_sigma_float, 2.5);
  nh.param<double>("gnss/sigma_dgps", gnss_sigma_dgps, 3.0);
  nh.param<double>("gnss/sigma_single", gnss_sigma_single, 5.0);
  // R3-WP10a: the reported covariance vs the fix status sanity check. Default OFF,
  // and even when on it only warns (status_sanity_warn_only defaults true): the
  // original idea ("status==2 with a cm-level covariance means RTK") fires on every
  // campus-02 Float epoch, because that bag writes cm-level covariance for all
  // epochs and status 2 for all non-Fixed ones - so acting on it would reintroduce
  // exactly the failure documented in EVAL_PROTOCOL 6.3b.
  nh.param<bool>("gnss/status_sanity_check", gnss_status_sanity_check, false);
  nh.param<bool>("gnss/status_sanity_warn_only", gnss_status_sanity_warn_only, true);
  // R3-WP7: what drives the chi-square gate. table = fix-type sigma table (absolute
  // scale, restores the gate's meaning), adaptive = the online innovation scale
  // (which makes gamma ~1 for any innovation). See the note in updateStateWithGNSS.
  nh.param<std::string>("gnss/gate_sigma_mode", gnss_gate_sigma_mode, std::string("table"));
  // R3 stage 1 (WP1): rate of the percent-evaluated diagnostics line.
  nh.param<int>("gnss/health_every_n", gnss_health_every_n, 10);
  // R3 stage 4 (L2): doppler velocity observations (see the header for why the
  // sigma is a configured value rather than the receiver's reported V-RMS).
  nh.param<bool>("gnss/use_velocity", gnss_use_velocity, false);
  nh.param<std::string>("gnss/vel_topic", gnss_vel_topic, "/gnss_vel");
  nh.param<double>("gnss/vel_sigma", gnss_vel_sigma, 0.2);
  nh.param<bool>("gnss/vel_use_vertical", gnss_vel_use_vertical, false);
  nh.param<int>("gnss/vel_min_status", gnss_vel_min_status, 5);
  nh.param<double>("gnss/vel_max_dt", gnss_vel_max_dt, 0.05);
  nh.param<bool>("gnss/use_vertical", gnss_use_vertical, true);
  // D1: channel-split gate ("joint" keeps the historical 3-DOF test; see
  // LIVMapper.h for the rationale). The INFO line below makes the mode visible
  // in every run log so an A/B can be audited.
  nh.param<std::string>("gnss/vertical_gate", gnss_vertical_gate, "joint");
  nh.param<double>("gnss/vertical_gate_floor", gnss_vertical_gate_floor, 10.0);
  ROS_INFO("[GNSS] vertical_gate=%s (vertical gate sigma floor %.1f m) use_vertical=%d",
           gnss_vertical_gate.c_str(), gnss_vertical_gate_floor,
           (int)gnss_use_vertical);
  nh.param<double>("gnss/horiz_sigma", gnss_horiz_sigma, -1.0);
  nh.param<double>("gnss/vert_sigma", gnss_vert_sigma, -1.0);
  nh.param<int>("gnss/align_min_samples", gnss_align_min_samples, 4);
  nh.param<double>("gnss/align_max_resid", gnss_align_max_resid, 5.0);
  // P0-2 adaptive observation noise
  nh.param<int>("gnss/sigma_window", gnss_sigma_window, 30);
  nh.param<double>("gnss/sigma_floor", gnss_sigma_floor, 0.3);
  nh.param<double>("gnss/sigma_ceil", gnss_sigma_ceil, 50.0);
  // Optional quality-factor weighting of the residual-derived sigma.  The
  // baseline path is unchanged while quality_en is false.
  nh.param<bool>("gnss/quality_en", gnss_quality_en, false);
  nh.param<double>("gnss/quality_cov_weight", gnss_quality_cov_weight, 0.5);
  nh.param<double>("gnss/quality_fix_weight", gnss_quality_fix_weight, 0.5);
  nh.param<int>("gnss/quality_fix_ref_status", gnss_quality_fix_ref_status, 2);
  nh.param<double>("gnss/quality_dop_weight", gnss_quality_dop_weight, 0.5);
  nh.param<double>("gnss/quality_dop_ref", gnss_quality_dop_ref, 2.0);
  nh.param<double>("gnss/quality_factor_min", gnss_quality_factor_min, 0.5);
  nh.param<double>("gnss/quality_factor_max", gnss_quality_factor_max, 3.0);
  // min horizontal displacement before the ENU-world yaw alignment completes.
  // With 5 m the alignment window is too short on degraded matching (campus-01
  // LIO moves only 0.3 m while GNSS moves 5.1 m -> yaw_offset = 19 deg of
  // noise -> every GNSS fix is rejected by the chi-square gate and the tight
  // coupling never engages). A larger window (e.g. 20 m) makes the heading
  // from the displacement reliable enough to lock the yaw.
  // Minimum horizontal displacement before the frame fit is trusted. This is a
  // physical "long enough baseline" criterion (rate independent), not a
  // per-dataset tuning value: a short baseline gives a noisy fitted yaw.
  nh.param<double>("gnss/yaw_align_min_dist", gnss_yaw_align_min_dist, 50.0);
  // E4: refit the locked ENU<->world transform every N metres of GNSS travel.
  // 0 (default) keeps the historical one-shot lock.
  nh.param<double>("gnss/refit_interval_dist", gnss_refit_interval_dist, 0.0);
  // A2: convergence-based freeze of the frame fit, and anchor-windowed updates
  nh.param<double>("gnss/align_yaw_tol_deg", gnss_align_yaw_tol_deg, 0.35);
  nh.param<int>("gnss/align_settle", gnss_align_settle, 10);
  nh.param<double>("gnss/align_drop_scale", gnss_align_drop_scale, 3.0);
  nh.param<double>("gnss/align_force_dist", gnss_align_force_dist, 150.0);
  // P2-01 (EXP-P2-001): forced early lock requires this many consecutive
  // within-tolerance fits. 0 (default) = historical behavior (span crossing
  // alone unlocks), so the C0 default stays bit-identical; candidates set 2-3.
  nh.param<int>("gnss/align_forced_min_stable", gnss_align_forced_min_stable, 0);
  nh.param<bool>("gnss/align_resid_gate", gnss_align_resid_gate, true);
  // R4-2b (EVAL_PROTOCOL 17.2): sample the alignment fit on the REPORTED pose
  // (internal + hold offset) instead of the internal one, so the static walk
  // the hold hides from the output cannot poison the fit. Default off.
  nh.param<bool>("gnss/align_use_report_pos", align_use_report_pos_, false);
  // P1-4: relative-displacement alignment (see tryAlignGnssYaw).
  nh.param<bool>("gnss/align_relative_en", gnss_align_relative_en, false);
  nh.param<double>("gnss/align_rel_min_disp", gnss_align_rel_min_disp, 1.0);
  nh.param<bool>("gnss/align_dd_score_en", gnss_align_dd_score_en, true);
  nh.param<double>("gnss/align_dd_max_rms", gnss_align_dd_max_rms, 6.0);
  // T1-4 (docs/T1_4_DESIGN.md): slow-varying alignment state. All defaults
  // reproduce history exactly (state absent); enabling also disables the
  // FORCED early lock (a wrong early prior is worse than a late lock).
  nh.param<bool>("gnss/align_state_en", gnss_align_state_en, false);
  nh.param<double>("gnss/align_q_pos", gnss_align_q_pos, 0.0);       // 0 = auto
  nh.param<double>("gnss/align_q_yaw_deg", gnss_align_q_yaw_deg, 0.0); // 0 = auto
  nh.param<double>("gnss/align_tau_s", gnss_align_tau_s, 150.0);
  // Redesign guards (EVAL_PROTOCOL 26.3): drift_rate is the single global
  // physical constant (LIO drift slope); kmax is the per-epoch authority share
  // ceiling for the alignment state.
  nh.param<double>("gnss/align_drift_rate", gnss_align_drift_rate, 0.004);
  nh.param<double>("gnss/align_kmax", gnss_align_kmax, 0.1);
  // 0 = auto: sigma_yaw0 is derived at lock from the settle tolerance that
  // certified it (data-independent); >0 is an explicit override kept for
  // reproducing historical arms only.
  nh.param<double>("gnss/align_sigma_yaw0_deg", gnss_align_sigma_yaw0_deg, 0.0);
  nh.param<double>("gnss/align_max_dyaw_deg", gnss_align_max_dyaw_deg, 0.5);
  nh.param<double>("gnss/align_max_dt_m", gnss_align_max_dt_m, 0.2);
  nh.param<double>("gnss/rel_max_dist", gnss_rel_max_dist, 30.0);
  nh.param<double>("gnss/rel_max_dt", gnss_rel_max_dt, 30.0);
  nh.param<bool>("gnss/relative_update", gnss_relative_update, true);
  nh.param<double>("gnss/max_corr", gnss_max_corr, 0.0);
  nh.param<bool>("gnss/inflate_prior", gnss_inflate_prior, false);
  // R3 P1-3 (A3-2): bounded physical drift prior (see LIVMapper.h for the design
  // and why it must not touch the chi-square gate). Defaults reproduce history.
  nh.param<bool>("gnss/prior_drift_en", gnss_prior_drift_en, false);
  nh.param<double>("gnss/prior_drift_a", gnss_prior_drift_a, 0.0);
  nh.param<double>("gnss/prior_drift_b", gnss_prior_drift_b, 0.004);
  nh.param<double>("gnss/prior_drift_max", gnss_prior_drift_max, 0.8);
  // D3: gate/gain consistency switch (see LIVMapper.h).
  nh.param<bool>("gnss/prior_drift_gate", gnss_prior_drift_gate, false);
  // P0-A: systematic-bias detector (diagnostic unless bias_guard is enabled).
  nh.param<double>("gnss/bias_thresh", gnss_bias_thresh, 1.0);
  nh.param<int>("gnss/bias_window", gnss_bias_window, 30);
  nh.param<double>("gnss/bias_sign_min", gnss_bias_sign_min, 0.7);
  nh.param<int>("gnss/bias_persist", gnss_bias_persist, 10);
  nh.param<bool>("gnss/bias_guard", gnss_bias_guard, false);

  // Phase 2: RTK double-difference tight coupling. Off by default; the existing
  // position-domain GNSS path is untouched when this block is disabled.
  nh.param<bool>("rtk/enable", rtk_tight_en, false);
  nh.param<std::string>("rtk/topic", rtk_topic, "/rtk/dd");
  nh.param<double>("rtk/time_sync_tol", rtk_time_sync_tol, 0.05);
  // D0/A-main: one global backend. The in-process FactorGraph and the separate
  // online graph both consume frontend poses; enabling both double-counts the
  // information the review flagged. The A-main configuration is frontend LIVO
  // only, with GNSS observations entering the online graph.
  if (online_graph_en_ && graph_cfg_.en)
    ROS_WARN("[MODE] both FactorGraph and online_graph are enabled; D0 requires a single backend");
  if (online_graph_en_ && !graph_cfg_.en && !gnss_position_update_en && !rtk_tight_en)
    ROS_INFO("[MODE] A-main: frontend LIVO only; GNSS observations -> online graph");
  std::vector<double> rtk_base_ecef;
  nh.param<std::vector<double>>("rtk/base_ecef", rtk_base_ecef, std::vector<double>());
  RtkTight::Config rtk_cfg;
  if (rtk_base_ecef.size() == 3)
    rtk_cfg.base_ecef = Eigen::Vector3d(rtk_base_ecef[0], rtk_base_ecef[1], rtk_base_ecef[2]);
  nh.param<double>("rtk/sigma_code_min", rtk_cfg.sigma_code_min, 1.0);
  nh.param<double>("rtk/sigma_code_scale", rtk_cfg.sigma_code_scale, 2.0);
  nh.param<double>("rtk/sigma_phase_min", rtk_cfg.sigma_phase_min, 0.03);
  // Optional elevation-dependent quality weighting for the DD per-pair sigmas.
  nh.param<bool>("rtk/quality_elev_en", rtk_cfg.quality_elev_en, false);
  nh.param<double>("rtk/quality_elev_weight", rtk_cfg.quality_elev_weight, 0.5);
  nh.param<double>("rtk/quality_elev_ref_deg", rtk_cfg.quality_elev_ref_deg, 30.0);
  nh.param<double>("rtk/quality_elev_min", rtk_cfg.quality_elev_min, 0.7);
  nh.param<double>("rtk/quality_elev_max", rtk_cfg.quality_elev_max, 3.0);
  nh.param<double>("rtk/phase_slip_thresh", rtk_cfg.phase_slip_thresh, 0.5);
  nh.param<bool>("rtk/robust_en", rtk_cfg.robust_en, false);
  nh.param<double>("rtk/robust_kappa_code", rtk_cfg.robust_kappa_code, 3.0);
  nh.param<double>("rtk/robust_sigma_code_abs", rtk_cfg.robust_sigma_code_abs, 2.5);
  nh.param<double>("rtk/robust_k0_code", rtk_cfg.robust_k0_code, 1.5);
  nh.param<double>("rtk/robust_k1_code", rtk_cfg.robust_k1_code, 3.0);
  nh.param<double>("rtk/robust_sigma_phase_abs", rtk_cfg.robust_sigma_phase_abs, 0.05);
  nh.param<double>("rtk/robust_k0_phase", rtk_cfg.robust_k0_phase, 3.0);
  nh.param<double>("rtk/robust_k1_phase", rtk_cfg.robust_k1_phase, 6.0);
  nh.param<double>("rtk/init_amb_var", rtk_cfg.init_amb_var, 4.0);
  nh.param<double>("rtk/prior_sigma_pos", rtk_cfg.prior_sigma_pos, 1.0);
  nh.param<bool>("rtk/coarse_acq_en", rtk_cfg.coarse_acq_en, false);
  nh.param<double>("rtk/coarse_acq_max_align_resid",
                   rtk_cfg.coarse_acq_max_align_resid, 1.0);
  nh.param<double>("rtk/coarse_acq_code_sigma", rtk_cfg.coarse_acq_code_sigma, 3.0);
  nh.param<double>("rtk/coarse_acq_prior_sigma", rtk_cfg.coarse_acq_prior_sigma, 20.0);
  nh.param<double>("rtk/coarse_acq_exit_code_rms", rtk_cfg.coarse_acq_exit_code_rms, 2.0);
  nh.param<double>("rtk/coarse_acq_exit_s", rtk_cfg.coarse_acq_exit_s, 5.0);
  nh.param<double>("rtk/gate_chi2", rtk_cfg.gate_chi2, 0.0);
  nh.param<double>("rtk/max_corr", rtk_cfg.max_corr, 5.0);
  nh.param<int>("rtk/health_every_n", rtk_cfg.health_every_n, 10);
  nh.param<bool>("rtk/verbose", rtk_cfg.verbose, true);
  // GREAT-MSF-aided fixed phase (MVP): the DD message may carry an externally
  // integer-fixed phase. When disabled (default), the message fields are ignored
  // and the existing float-ambiguity path is unchanged.
  nh.param<bool>("rtk/fixed_phase_en", rtk_cfg.fixed_phase_en, false);
  nh.param<double>("rtk/sigma_fixed_phase", rtk_cfg.sigma_fixed_phase, 0.02);
  nh.param<double>("rtk/fixed_phase_gate", rtk_cfg.fixed_phase_gate, 0.10);
  nh.param<bool>("rtk/fixed_phase_code_gate_en",
                 rtk_cfg.fixed_phase_code_gate_en, true);
  nh.param<double>("rtk/fixed_phase_max_code_rms",
                   rtk_cfg.fixed_phase_max_code_rms, 3.0);
  nh.param<int>("rtk/fixed_warmup_epochs", rtk_cfg.fixed_warmup_epochs, 30);
  nh.param<double>("rtk/sigma_fixed_phase_tight", rtk_cfg.sigma_fixed_phase_tight, 0.05);
  nh.param<double>("rtk/fixed_phase_gate_tight", rtk_cfg.fixed_phase_gate_tight, 0.5);
  nh.param<double>("rtk/prior_sigma_pos_tight", rtk_cfg.prior_sigma_pos_tight, 0.5);
  nh.param<bool>("rtk/per_pair_sigma", rtk_cfg.per_pair_sigma, true);
  nh.param<double>("rtk/sigma_fixed_floor", rtk_cfg.sigma_fixed_floor, 0.03);
  nh.param<double>("rtk/sigma_fixed_ceiling", rtk_cfg.sigma_fixed_ceiling, 1.0);
  nh.param<int>("rtk/min_fixed_pairs", rtk_cfg.min_fixed_pairs, 5);
  nh.param<int>("rtk/fixed_min_streak", rtk_cfg.fixed_min_streak, 2);
  nh.param<double>("rtk/fixed_warmup_s", rtk_cfg.fixed_warmup_s, 30.0);
  nh.param<double>("rtk/fixed_min_streak_s", rtk_cfg.fixed_min_streak_s, 2.0);
  nh.param<bool>("rtk/fixed_settle_en", rtk_cfg.fixed_settle_en, false);
  nh.param<double>("rtk/fixed_settle_rms", rtk_cfg.fixed_settle_rms, 0.5);
  nh.param<double>("rtk/fixed_settle_s", rtk_cfg.fixed_settle_s, 5.0);
  nh.param<bool>("rtk/frame_offset_en", rtk_cfg.frame_offset_en, false);
  nh.param<int>("rtk/frame_offset_min_pairs", rtk_cfg.frame_offset_min_pairs, 8);
  nh.param<double>("rtk/frame_offset_min", rtk_cfg.frame_offset_min, 0.25);
  nh.param<double>("rtk/frame_offset_max", rtk_cfg.frame_offset_max, 10.0);
  nh.param<double>("rtk/frame_offset_max_vertical",
                   rtk_cfg.frame_offset_max_vertical, 1.0);
  nh.param<double>("rtk/frame_offset_max_resid", rtk_cfg.frame_offset_max_resid, 0.5);
  nh.param<double>("rtk/frame_offset_window_s", rtk_cfg.frame_offset_window_s, 60.0);
  nh.param<bool>("rtk/fixed_robust_en", rtk_cfg.fixed_robust_en, true);
  nh.param<double>("rtk/fixed_robust_k0", rtk_cfg.fixed_robust_k0, 3.0);
  nh.param<double>("rtk/fixed_robust_k1", rtk_cfg.fixed_robust_k1, 6.0);
  nh.param<bool>("rtk/fixed_consensus_en", rtk_cfg.fixed_consensus_en, true);
  nh.param<double>("rtk/fixed_consensus_min_frac", rtk_cfg.fixed_consensus_min_frac, 0.5);
  nh.param<int>("rtk/fixed_consensus_min_pairs", rtk_cfg.fixed_consensus_min_pairs, 4);
  // TDCP: time-differenced DD phase relative update (fixed-anchor formulation).
  nh.param<bool>("rtk/tdcp_en", rtk_cfg.tdcp_en, false);
  nh.param<double>("rtk/tdcp_sigma_scale", rtk_cfg.tdcp_sigma_scale, 1.0);
  nh.param<double>("rtk/tdcp_prev_sigma", rtk_cfg.tdcp_prev_sigma, 0.05);
  nh.param<int>("rtk/tdcp_min_pairs", rtk_cfg.tdcp_min_pairs, 4);
  nh.param<double>("rtk/tdcp_max_dt", rtk_cfg.tdcp_max_dt, 2.0);
  nh.param<bool>("rtk/tdcp_robust_en", rtk_cfg.tdcp_robust_en, true);
  nh.param<double>("rtk/tdcp_robust_k0", rtk_cfg.tdcp_robust_k0, 3.0);
  nh.param<double>("rtk/tdcp_robust_k1", rtk_cfg.tdcp_robust_k1, 6.0);
  rtk_tight_.setConfig(rtk_cfg);
  rtk_tight_.setUseScale(gnss_state_scale_en);

  // P2: dataset-agnostic soft-weight/hysteresis supervisor. Default OFF so
  // every existing config keeps its current behaviour.
  nh.param<bool>("fusion_supervisor/en", fusion_sup_cfg_.en, false);
  nh.param<double>("fusion_supervisor/fixed_ratio_min", fusion_sup_cfg_.fixed_ratio_min, 0.20);
  nh.param<double>("fusion_supervisor/fixed_ratio_good", fusion_sup_cfg_.fixed_ratio_good, 0.60);
  nh.param<int>("fusion_supervisor/n_fixed_abs_min", fusion_sup_cfg_.n_fixed_abs_min, 4);
  nh.param<int>("fusion_supervisor/n_fixed_abs_good", fusion_sup_cfg_.n_fixed_abs_good, 8);
  nh.param<double>("fusion_supervisor/ratio_min", fusion_sup_cfg_.ratio_min, 1.5);
  nh.param<double>("fusion_supervisor/ratio_good", fusion_sup_cfg_.ratio_good, 3.0);
  nh.param<double>("fusion_supervisor/streak_min_s", fusion_sup_cfg_.streak_min_s, 1.0);
  nh.param<double>("fusion_supervisor/streak_good_s", fusion_sup_cfg_.streak_good_s, 5.0);
  nh.param<double>("fusion_supervisor/gamma_margin_good", fusion_sup_cfg_.gamma_margin_good, 0.5);
  nh.param<double>("fusion_supervisor/livo_ratio_min", fusion_sup_cfg_.livo_ratio_min, 0.20);
  nh.param<double>("fusion_supervisor/livo_ratio_good", fusion_sup_cfg_.livo_ratio_good, 0.70);
  nh.param<int>("fusion_supervisor/livo_feat_abs_min", fusion_sup_cfg_.livo_feat_abs_min, 10);
  nh.param<int>("fusion_supervisor/livo_match_abs_min", fusion_sup_cfg_.livo_match_abs_min, 5);
  nh.param<int>("fusion_supervisor/livo_vio_abs_min", fusion_sup_cfg_.livo_vio_abs_min, 3);
  nh.param<double>("fusion_supervisor/livo_warmup_s", fusion_sup_cfg_.livo_warmup_s, 5.0);
  nh.param<double>("fusion_supervisor/livo_ema_tau_s", fusion_sup_cfg_.livo_ema_tau_s, 20.0);
  nh.param<double>("fusion_supervisor/livo_q_min", fusion_sup_cfg_.livo_q_min, 0.15);
  nh.param<double>("fusion_supervisor/fixed_q_min", fusion_sup_cfg_.fixed_q_min, 0.55);
  nh.param<double>("fusion_supervisor/fixed_q_exit", fusion_sup_cfg_.fixed_q_exit, 0.35);
  nh.param<double>("fusion_supervisor/fixed_q_reject_cap",
                   fusion_sup_cfg_.fixed_q_reject_cap, 0.30);
  nh.param<double>("fusion_supervisor/reject_q_max", fusion_sup_cfg_.reject_q_max, 0.10);
  nh.param<double>("fusion_supervisor/fixed_enter_s", fusion_sup_cfg_.fixed_enter_s, 2.0);
  nh.param<double>("fusion_supervisor/fixed_exit_s", fusion_sup_cfg_.fixed_exit_s, 3.0);
  nh.param<double>("fusion_supervisor/reject_enter_s", fusion_sup_cfg_.reject_enter_s, 3.0);
  nh.param<double>("fusion_supervisor/reject_recover_s", fusion_sup_cfg_.reject_recover_s, 1.0);
  nh.param<double>("fusion_supervisor/w_rtk_max", fusion_sup_cfg_.w_rtk_max, 1.0);
  nh.param<double>("fusion_supervisor/w_rtk_floor", fusion_sup_cfg_.w_rtk_floor, 0.25);
  nh.param<double>("fusion_supervisor/w_gnss_max", fusion_sup_cfg_.w_gnss_max, 1.0);
  nh.param<double>("fusion_supervisor/log_every_s", fusion_sup_cfg_.log_every_s, 10.0);
  nh.param<double>("fusion_supervisor/rtk_timeout_s", fusion_sup_cfg_.rtk_timeout_s, 1.5);
  fusion_sup_.setConfig(fusion_sup_cfg_);

  nh.param<double>("publish/blind_rgb_points", blind_rgb_points, 0.01);
  nh.param<int>("publish/pub_scan_num", pub_scan_num, 1);
  nh.param<bool>("publish/pub_effect_point_en", pub_effect_point_en, false);
  nh.param<bool>("publish/dense_map_en", dense_map_en, false);

  p_pre->blind_sqr = p_pre->blind * p_pre->blind;
}

void LIVMapper::initializeComponents() 
{
  downSizeFilterSurf.setLeafSize(filter_size_surf_min, filter_size_surf_min, filter_size_surf_min);
  extT << VEC_FROM_ARRAY(extrinT);
  extR << MAT_FROM_ARRAY(extrinR);

  voxelmap_manager->extT_ << VEC_FROM_ARRAY(extrinT);
  voxelmap_manager->extR_ << MAT_FROM_ARRAY(extrinR);

  if (!vk::camera_loader::loadFromRosNs("laserMapping", vio_manager->cam)) throw std::runtime_error("Camera model not correctly specified.");

  vio_manager->grid_size = grid_size;
  vio_manager->patch_size = patch_size;
  vio_manager->outlier_threshold = outlier_threshold;
  vio_manager->setImuToLidarExtrinsic(extT, extR);
  vio_manager->setLidarToCameraExtrinsic(cameraextrinR, cameraextrinT);
  vio_manager->state = &_state;
  vio_manager->state_propagat = &state_propagat;
  vio_manager->max_iterations = max_iterations;
  vio_manager->img_point_cov = IMG_POINT_COV;
  vio_manager->normal_en = normal_en;
  vio_manager->inverse_composition_en = inverse_composition_en;
  vio_manager->raycast_en = raycast_en;
  vio_manager->grid_n_width = grid_n_width;
  vio_manager->grid_n_height = grid_n_height;
  vio_manager->patch_pyrimid_level = patch_pyrimid_level;
  vio_manager->exposure_estimate_en = exposure_estimate_en;
  vio_manager->colmap_output_en = colmap_output_en;
  // Improvement 1 (VIO side)
  vio_manager->occlusion_check_en = vio_occlusion_en_;
  vio_manager->occlusion_depth_thresh = vio_occlusion_depth_thresh_m_;
  vio_manager->robust_kernel_type = vio_robust_kernel_type_;
  vio_manager->robust_delta = vio_robust_delta_;
  vio_manager->initializeVIO();

  p_imu->set_extrinsic(extT, extR);
  p_imu->set_gyr_cov_scale(V3D(gyr_cov, gyr_cov, gyr_cov));
  p_imu->set_acc_cov_scale(V3D(acc_cov, acc_cov, acc_cov));

  // ZUPT (zero-velocity update): freeze position/velocity during stationary
  // periods (LiDAR matching degenerates when the platform stands still).
  // Thresholds are read in readParameters() from the "zupt" yaml section.
  p_imu->set_zupt_params(zupt_enable_, zupt_static_deg_, zupt_move_deg_,
                         zupt_acc_move_, zupt_settle_s_);
  p_imu->set_zupt_hold_params(zupt_hold_pos_en_, zupt_release_vel_, zupt_hold_max_s_);
  p_imu->set_scale_cov(scale_cov);
  p_imu->set_inv_expo_cov(inv_expo_cov);
  p_imu->set_gyr_bias_cov(V3D(0.0001, 0.0001, 0.0001));
  p_imu->set_acc_bias_cov(V3D(0.0001, 0.0001, 0.0001));
  p_imu->set_imu_init_frame_num(imu_int_frame);

  if (!imu_en) p_imu->disable_imu();
  if (!gravity_est_en) p_imu->disable_gravity_est();
  if (!ba_bg_est_en) p_imu->disable_bias_est();
  if (!exposure_estimate_en) p_imu->disable_exposure_est();

  // GNSS initialization
  if (gnss_en && !gnssextrinT.empty())
  {
    gnss_extT << VEC_FROM_ARRAY(gnssextrinT);
    p_gnss->setGnssExtrinsic(gnss_extT);
  }
  // Calibrated GNSS sigma override (yaml): when the dataset's per-epoch
  // covariance is unreliable, use the sigma measured against the reference.
  p_gnss->setSigmaOverride(gnss_horiz_sigma, gnss_vert_sigma);
  // R3-WP10a: the fix-type noise table is now a yaml parameter set, so recalibrating
  // for a different dataset does not need a rebuild. The defaults passed here are the
  // values that used to be hard-coded, so an unset config is a no-op.
  p_gnss->setSigmaTable(gnss_sigma_fixed, gnss_sigma_float, gnss_sigma_dgps,
                        gnss_sigma_single);

  // R3-WP7: gnss/inflate_prior is a diagnostic switch, off in every config. Turning
  // it on replaces the position prior with the online innovation scale, which makes
  // gamma ~1 for any innovation and so disables the chi-square gate (campus-02 was
  // dragged ~10 m by a bogus correction, EVAL_PROTOCOL 6.3b). It is also the reason
  // WP7 decouples gating from weighting, so make it loud if anyone enables it.
  if (gnss_inflate_prior)
    ROS_WARN("[GNSS] gnss/inflate_prior is TRUE: the position prior is being replaced "
             "by the online innovation scale. That makes the chi-square gate accept "
             "any innovation (gamma ~ 1 for every epoch) and dragged campus-02 by "
             "~10 m (EVAL_PROTOCOL 6.3b). Diagnostic use only - do not ship it.");

  // Improvement 2: factor-graph backend
  if (graph_cfg_.en)
  {
    graph_cfg_.lever = gnss_extT;
    graph_.reset(new fast_livo::FactorGraph(graph_cfg_));
    std::cout << CYAN << "[ FG ] sliding-window factor-graph backend enabled (window " << graph_cfg_.window_size
              << ", thread " << (graph_cfg_.thread_en ? "on" : "off") << ", marginalize " << (graph_cfg_.marginalize ? "on" : "off") << ")"
              << RESET << std::endl;
  }

  // P5b: the bounded-history GTSAM graph runs in the separate
  // `online_graph_node` process (the ROS node must not link GTSAM: the
  // installed GTSAM and this package's -march=native Eigen flags are ABI
  // incompatible and abort at startup). Here we only publish 1 Hz keyframe
  // poses and raw ENU fixes on /online_graph/*.
  if (online_graph_en_)
  {
    std::cout << CYAN << "[ ONLINE GRAPH ] publishers enabled; run "
              << "`rosrun fast_livo online_graph_node` (window "
              << online_graph_window_ << ")" << RESET << std::endl;
  }

  // Initialize ENU to world rotation as identity. Both frames are z-up (the IMU
  // initialisation gives gravity (0,0,-g)), so U is used without a sign flip.
  // Yaw alignment will be done once sufficient GNSS movement is detected.
  enu_R_world = M3D::Identity();

  // A4: with both LiDAR and camera off but GNSS on, the estimator runs in one of
  // the GNSS-driven baseline modes instead of the LiDAR-frame pipeline.
  if (!lidar_en && !img_en && gnss_en)
    slam_mode_ = imu_en ? GNSS_IMU : GNSS_ONLY;
  else
    slam_mode_ = (img_en && lidar_en && gnss_en) ? LIVO_GNSS : (img_en && lidar_en) ? LIVO : imu_en ? ONLY_LIO : ONLY_LO;
}

void LIVMapper::initializeFiles() 
{
  for (const auto &subdir : {"result", "pcd", "image", "Colmap/sparse/0"})
    std::filesystem::create_directories(runtime_log_dir_ + subdir);
  if (state_diagnostic_en_) {
    fout_state_diagnostic_.open(runtime_log_dir_ + "result/" + seq_name + "_state.csv", std::ios::out);
    if (!fout_state_diagnostic_) throw std::runtime_error("cannot open state diagnostic");
    fout_state_diagnostic_ << "stamp,raw_x,raw_y,raw_z,metric_x,metric_y,metric_z,reported_x,reported_y,reported_z,hold_x,hold_y,hold_z,graph_x,graph_y,graph_z,vx,vy,vz,qx,qy,qz,qw,scale,holding,imu_static,lambda_min,pos_cov_trace,latest_imu_stamp,latest_lidar_stamp\n";
  }
  if (gnss_pair_diagnostic_en_) {
    fout_gnss_pair_diagnostic_.open(runtime_log_dir_ + "result/" + seq_name + "_gnss_pair.csv", std::ios::out);
    if (!fout_gnss_pair_diagnostic_) throw std::runtime_error("cannot open GNSS pair diagnostic");
    fout_gnss_pair_diagnostic_ << "stamp_ns,reason,fix_arrival,quality_arrival,drain_time,process_start,process_end,pending_fixes,pending_quality\n" << std::flush;
  }
  if (pcd_save_en && colmap_output_en)
  {
      const std::string folderPath = std::string(ROOT_DIR) + "/scripts/colmap_output.sh";
      
      std::string chmodCommand = "chmod +x " + folderPath;
      
      int chmodRet = system(chmodCommand.c_str());  
      if (chmodRet != 0) {
          std::cerr << "Failed to set execute permissions for the script." << std::endl;
          return;
      }

      int executionRet = system(folderPath.c_str());
      if (executionRet != 0) {
          std::cerr << "Failed to execute the script." << std::endl;
          return;
      }
  }
  if(colmap_output_en) fout_points.open(runtime_log_dir_ + "Colmap/sparse/0/points3D.txt", std::ios::out);
  if(pcd_save_en) fout_lidar_pos.open(runtime_log_dir_ + "pcd/lidar_poses.txt", std::ios::out);
  if(img_save_en) fout_visual_pos.open(runtime_log_dir_ + "image/image_poses.txt", std::ios::out);
  fout_pre.open(runtime_log_dir_ + "mat_pre.txt", std::ios::out);
  fout_out.open(runtime_log_dir_ + "mat_out.txt", std::ios::out);
  if (gnss_en) {
    fout_gnss_pos.open(runtime_log_dir_ + "gnss_poses.txt", std::ios::out);
    // R3 stage 1 (WP1): this file now carries two record types. The historical
    // one (a line starting with a number: t_rel E N U x y z) is written only for
    // ACCEPTED updates, as before. The new one (a line starting with "DT") is a
    // per-evaluated-fix timing diagnostic used to size the GNSS/EKF time-base
    // misalignment. Counting lines is therefore no longer the accepted count.
    if (fout_gnss_pos.is_open())
      fout_gnss_pos << "# gnss_poses.txt | DT record: DT <t_g_rel> <t_lio_rel> <dt_g=t_lio-t_g> <|v|_lio> <|v|*|dt_g|> <fwd_prop> <|dp_prop|> <|dv_prop|> | DV record (R3-L2, when gnss/use_velocity and a velocity epoch was used): DV <t_g_rel> <|v|_lio> <|v|_gnss> <|res_v|> <lever> | pose record (accepted updates only): <t_rel> <E> <N> <U> <x> <y> <z>" << std::endl;
  }
  // Improvement 1/3: latency (frontend + graph) and dynamic-statistics logs
  if (latency_en_)
  {
    fout_latency_.open(runtime_log_dir_ + "result/" + seq_name + "_latency.csv", std::ios::out);
    fout_latency_ << "stamp,frontend_latency_ms,graph_opt_ms,graph_queue_ms,graph_output_ms,graph_window,graph_iters" << std::endl;
  }
  // Geometric-conditioning log for adaptive RTK weighting (lambda_min / frame).
  fout_lambda_.open(runtime_log_dir_ + "result/" + seq_name + "_lambda.csv", std::ios::out);
  fout_lambda_ << "stamp,lambda_min" << std::endl;
  if (mem_log_every_n_ > 0)
  {
    fout_mem_.open(runtime_log_dir_ + "result/" + seq_name + "_mem.csv", std::ios::out);
    fout_mem_ << "stamp,frame,vm_rss_kb,vm_hwm_kb,img_buf,lid_buf,imu_buf,"
                 "gnss_buf,prop_imu_buf,feat_map,voxel_map" << std::endl;
  }
  if (voxelmap_manager->config_setting_.dynamic_en_)
  {
    fout_dyn_.open(runtime_log_dir_ + "result/" + seq_name + "_dyn.csv", std::ios::out);
    fout_dyn_ << "stamp,total_points,matched_points,dyn_points" << std::endl;
  }
}

void LIVMapper::initializeSubscribersAndPublishers(ros::NodeHandle &nh, image_transport::ImageTransport &it) 
{
  sub_pcl = p_pre->lidar_type == AVIA ? 
            nh.subscribe(lid_topic, 200000, &LIVMapper::livox_pcl_cbk, this): 
            nh.subscribe(lid_topic, 200000, &LIVMapper::standard_pcl_cbk, this);
  sub_imu = nh.subscribe(imu_topic, 200000, &LIVMapper::imu_cbk, this);
  sub_img = nh.subscribe(img_topic, 200000, &LIVMapper::img_cbk, this);
  if (gnss_en) {
    sub_gnss = nh.subscribe(gnss_topic, 100, &LIVMapper::gnss_cbk, this);
    // R3 stage 4 (L2): subscribed unconditionally (when a topic is configured) so
    // the velocity can be logged and compared even while gnss/use_velocity is
    // false - the A/B then differs only in whether the filter uses it.
    if (!gnss_vel_topic.empty())
      sub_gnss_vel = nh.subscribe(gnss_vel_topic, 100, &LIVMapper::gnss_vel_cbk, this);
    // A2.1: quality records are optional; without them the fix carries the
    // same unknown-quality defaults as before.
    if (!gnss_quality_topic.empty())
    {
      gnss_pairer_.reset(new GnssPairer(gnss_quality_wait_sec_,
                                        static_cast<size_t>(gnss_quality_capacity_)));
      sub_gnss_quality = nh.subscribe(gnss_quality_topic, 100,
                                      &LIVMapper::gnss_quality_cbk, this);
      gnss_quality_timer_ = nh.createWallTimer(ros::WallDuration(0.02),
                                              &LIVMapper::drainGnssPairs, this);
    }
  }
  if (rtk_tight_en)
    sub_rtk = nh.subscribe(rtk_topic, 200, &LIVMapper::rtk_cbk, this);
  
  pubLaserCloudFullRes = nh.advertise<sensor_msgs::PointCloud2>("/cloud_registered", 100);
  pubNormal = nh.advertise<visualization_msgs::MarkerArray>("visualization_marker", 100);
  pubSubVisualMap = nh.advertise<sensor_msgs::PointCloud2>("/cloud_visual_sub_map_before", 100);
  pubLaserCloudEffect = nh.advertise<sensor_msgs::PointCloud2>("/cloud_effected", 100);
  pubLaserCloudMap = nh.advertise<sensor_msgs::PointCloud2>("/Laser_map", 100);
  pubOdomAftMapped = nh.advertise<nav_msgs::Odometry>("/aft_mapped_to_init", 10);
  pubPath = nh.advertise<nav_msgs::Path>("/path", 10);
  plane_pub = nh.advertise<visualization_msgs::Marker>("/planner_normal", 1);
  voxel_pub = nh.advertise<visualization_msgs::MarkerArray>("/voxels", 1);
  pubLaserCloudDyn = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj", 100);
  pubLaserCloudDynRmed = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj_removed", 100);
  pubLaserCloudDynDbg = nh.advertise<sensor_msgs::PointCloud2>("/dyn_obj_dbg_hist", 100);
  pubSmoothedOdom = nh.advertise<nav_msgs::Odometry>("/LIVO2/smoothed_odom", 100);
  pubSmoothedPath = nh.advertise<nav_msgs::Path>("/LIVO2/smoothed_path", 100);
  if (online_graph_en_)
  {
    // P0: the graph needs lambda_min and the per-epoch quality record, not
    // just a pose/point. The old PoseStamped/PointStamped consumers are gone.
    pubOnlineGraphKeyframe =
        nh.advertise<fast_livo::OnlineGraphKeyframe>("/online_graph/keyframe", 100);
    pubOnlineGraphFix =
        nh.advertise<fast_livo::OnlineGraphFix>("/online_graph/gnss_enu", 100);
    pubOnlineGraphVel =
        nh.advertise<fast_livo::OnlineGraphVel>("/online_graph/vel", 100);
    if (graph_feedback_en_)
    {
      subOnlineGraphCorrection = nh.subscribe(
          "/online_graph/graph_correction", 10,
          &LIVMapper::onlineGraphCorrectionCallback, this);
      pubGraphOffset = nh.advertise<geometry_msgs::Vector3Stamped>(
          "/LIVO2/graph_offset", 100);
    }
    if (graph_fusion_en_)
    {
      subGlobalGraphOdom = nh.subscribe(
          "/online_graph/global_odom", 10,
          &LIVMapper::globalGraphOdomCallback, this);
      pubGlobalOdom = nh.advertise<nav_msgs::Odometry>(
          "/LIVO2/global_odom", 100);
      pubGlobalPath = nh.advertise<nav_msgs::Path>(
          "/LIVO2/global_path", 10);
      std::cout << CYAN << "[ GRAPH FUSION ] 1 Hz graph global pose + EKF "
                << "relative motion -> /LIVO2/global_odom" << RESET << std::endl;
    }
  }
  mavros_pose_publisher = nh.advertise<geometry_msgs::PoseStamped>("/mavros/vision_pose/pose", 10);
  pubImage = it.advertise("/rgb_img", 1);
  pubImuPropOdom = nh.advertise<nav_msgs::Odometry>("/LIVO2/imu_propagate", 10000);
  imu_prop_timer = nh.createTimer(ros::Duration(0.004), &LIVMapper::imu_prop_callback, this);
  voxelmap_manager->voxel_map_pub_= nh.advertise<visualization_msgs::MarkerArray>("/planes", 10000);
}

void LIVMapper::handleFirstFrame() 
{
  if (!is_first_frame)
  {
    _first_lidar_time = LidarMeasures.last_lio_update_time;
    p_imu->first_lidar_time = _first_lidar_time; // Only for IMU data log
    is_first_frame = true;
    cout << "FIRST LIDAR FRAME!" << endl;
  }
}

void LIVMapper::gravityAlignment() 
{
  if (!p_imu->imu_need_init && !gravity_align_finished) 
  {
    std::cout << "Gravity Alignment Starts" << std::endl;
    V3D ez(0, 0, -1), gz(_state.gravity);
    Quaterniond G_q_I0 = Quaterniond::FromTwoVectors(gz, ez);
    M3D G_R_I0 = G_q_I0.toRotationMatrix();

    _state.pos_end = G_R_I0 * _state.pos_end;
    _state.rot_end = G_R_I0 * _state.rot_end;
    _state.vel_end = G_R_I0 * _state.vel_end;
    _state.gravity = G_R_I0 * _state.gravity;
    gravity_align_finished = true;
    std::cout << "Gravity Alignment Finished" << std::endl;
  }
}

void LIVMapper::processImu() 
{
  // double t0 = omp_get_wtime();

  p_imu->Process2(LidarMeasures, _state, feats_undistort);

  if (gravity_align_en) gravityAlignment();

  state_propagat = _state;
  voxelmap_manager->state_ = _state;
  voxelmap_manager->feats_undistort_ = feats_undistort;

  // double t_prop = omp_get_wtime();

  // std::cout << "[ Mapping ] feats_undistort: " << feats_undistort->size() << std::endl;
  // std::cout << "[ Mapping ] predict cov: " << _state.cov.diagonal().transpose() << std::endl;
  // std::cout << "[ Mapping ] predict sta: " << state_propagat.pos_end.transpose() << state_propagat.vel_end.transpose() << std::endl;
}

void LIVMapper::stateEstimationAndMapping() 
{
  // P1: with lio_update_en=false the LiDAR/VIO measurement update is skipped;
  // the IMU propagation and the GNSS/RTK updates still run.
  if (!lio_update_en) return;
  if (lio_off_after_s >= 0.0 &&
      LidarMeasures.last_lio_update_time - _first_lidar_time > lio_off_after_s)
    return;
  switch (LidarMeasures.lio_vio_flg) 
  {
    case VIO:
      handleVIO();
      break;
    case LIO:
    case LO:
      handleLIO();
      break;
  }
}

// A3 report-level static hold.
//
// ZUPT already zeroes the velocity while stationary, but the position is driven
// by the scan-to-map EKF, and on a static platform that problem is unobservable
// along the planes: the pose slides at ~0.15-0.3 m/s with a healthy match
// (thousands of effective features, sub-cm residual). Measured displacement
// while the reference stands still: 30 m over 100 s (campus-02), 4-5 m over 25 s
// (campus-01). That arbitrary spur is carried by the whole trajectory and no
// global alignment can remove it, because the direction it walked is unrelated
// to the subsequent motion - it is the dominant error source on campus-02
// (7-13 m after alignment).
//
// Freezing `_state` directly was tried and REJECTED: the EKF then disagrees with
// the map it registers against (the map is updated from the same pose), and the
// estimate collapses afterwards (measured 4x under-motion, 145 m error).
//
// So the EKF and its map keep their own consistent pose, and only the reported
// pose is held. The offset is recomputed every static frame (the internal pose
// keeps walking) and simply stops changing at release, which makes it a rigid
// shift of everything reported afterwards.
//
// R4-1 (A3-1b): the IMU-only release cannot separate a genuinely slow start
// from the estimator's own drift (campus-02 releases within 0.5 s of the lock
// and the 0.3 m/s walk lands in the report). When the veto is enabled, the
// hold is EXTENDED past the IMU release for as long as the GNSS has not seen
// the antenna move (displacement from the reference fix below the calibrated
// threshold, fixes fresh). This touches only the report, never the EKF or the
// map, so it inherits the report-level hold's safety argument; with no fix
// ever seen it is exactly the historical IMU-only behaviour.
bool LIVMapper::gnssHoldVetoShouldHold()
{
  if (!zupt_hold_veto_gnss_en_ || gnss_hold_veto_done_ || !gnss_hold_veto_eligible_ ||
      !gnss_hold_ref_set_)
    return false;
  const double now = LidarMeasures.last_lio_update_time;
  if (now - gnss_hold_veto_last_fix_t_ > zupt_hold_veto_stale_s_) return false;
  if (now - gnss_hold_ref_t_ > zupt_hold_veto_max_s_) return false;
  return gnss_hold_disp_ < zupt_hold_veto_thresh_;
}

void LIVMapper::updateStaticReportOffset()
{
  const bool hold_imu = zupt_hold_pos_en_ && p_imu->zuptEnabled() && p_imu->zuptStatic();
  // R4-1: record the lock time, and at the IMU-release EDGE decide whether the
  // release is credible. A hold that lasted >= zupt_hold_veto_min_hold_s got a
  // real chance to observe the motion onset (campus-01: 25.7 s) and must stay
  // untouched; only an implausibly early release (campus-02: < 1 s, the known
  // 7.5 failure) hands the decision to the GNSS displacement check.
  if (hold_imu && !gnss_hold_prev_imu_ && gnss_hold_lock_t_ < 0.0)
    gnss_hold_lock_t_ = LidarMeasures.last_lio_update_time;
  if (gnss_hold_prev_imu_ && !hold_imu && !gnss_hold_veto_done_)
  {
    gnss_hold_veto_eligible_ =
        zupt_hold_veto_gnss_en_ && gnss_hold_lock_t_ >= 0.0 &&
        (LidarMeasures.last_lio_update_time - gnss_hold_lock_t_) < zupt_hold_veto_min_hold_s_;
    if (zupt_hold_veto_gnss_en_)
      printf("[ZUPT] hold veto %s: IMU hold lasted %.1f s\n",
             gnss_hold_veto_eligible_ ? "ENGAGED (release not credible)" : "bypassed (credible hold)",
             gnss_hold_lock_t_ >= 0.0 ? LidarMeasures.last_lio_update_time - gnss_hold_lock_t_ : 0.0);
  }
  gnss_hold_prev_imu_ = hold_imu;

  const bool hold_veto = zupt_hold_pos_en_ && gnssHoldVetoShouldHold();
  // T1-4: the LIVE hold condition, refreshed every LIO frame. zupt_rep_active_
  // above is only the once-ever latch (it never clears), so the alignment
  // state's freeze must read this instead - the smoke run caught exactly that
  // mistake (frozen=1 during motion) before it could do any harm.
  zupt_rep_holding_ = hold_imu || hold_veto;
  if (!(hold_imu || hold_veto)) return;
  if (!zupt_rep_active_)
  {
    zupt_rep_hold_ = _state.pos_end;
    zupt_rep_active_ = true;
  }
  report_offset_ = zupt_rep_hold_ - _state.pos_end;
}

void LIVMapper::handleVIO() 
{
  euler_cur = RotMtoEuler(_state.rot_end);
  fout_pre << std::setw(20) << LidarMeasures.last_lio_update_time - _first_lidar_time << " " << euler_cur.transpose() * 57.3 << " "
            << _state.pos_end.transpose() << " " << _state.vel_end.transpose() << " " << _state.bias_g.transpose() << " "
            << _state.bias_a.transpose() << " " << V3D(_state.inv_expo_time, 0, 0).transpose() << std::endl;
    
  if (pcl_w_wait_pub->empty() || (pcl_w_wait_pub == nullptr)) 
  {
    std::cout << "[ VIO ] No point!!!" << std::endl;
    return;
  }
    
  // Perf: per-frame VIO log removed (was printed every frame)

  if (fabs((LidarMeasures.last_lio_update_time - _first_lidar_time) - plot_time) < (frame_cnt / 2 * 0.1)) 
  {
    vio_manager->plot_flag = true;
  } 
  else 
  {
    vio_manager->plot_flag = false;
  }

  vio_manager->processFrame(LidarMeasures.measures.back().img, _pv_list, voxelmap_manager->voxel_map_, LidarMeasures.last_lio_update_time - _first_lidar_time);

  if (imu_prop_enable) 
  {
    ekf_finish_once = true;
    latest_ekf_state = _state;
    latest_ekf_time = LidarMeasures.last_lio_update_time;
    state_update_flg = true;
  }

  // int size_sub_map = vio_manager->visual_sub_map_cur.size();
  // visual_sub_map->reserve(size_sub_map);
  // for (int i = 0; i < size_sub_map; i++) 
  // {
  //   PointType temp_map;
  //   temp_map.x = vio_manager->visual_sub_map_cur[i]->pos_[0];
  //   temp_map.y = vio_manager->visual_sub_map_cur[i]->pos_[1];
  //   temp_map.z = vio_manager->visual_sub_map_cur[i]->pos_[2];
  //   temp_map.intensity = 0.;
  //   visual_sub_map->push_back(temp_map);
  // }

  publish_frame_world(pubLaserCloudFullRes, vio_manager);
  publish_img_rgb(pubImage, vio_manager);

  euler_cur = RotMtoEuler(_state.rot_end);
  fout_out << std::setw(20) << LidarMeasures.last_lio_update_time - _first_lidar_time << " " << euler_cur.transpose() * 57.3 << " "
            << _state.pos_end.transpose() << " " << _state.vel_end.transpose() << " " << _state.bias_g.transpose() << " "
            << _state.bias_a.transpose() << " " << V3D(_state.inv_expo_time, 0, 0).transpose() << " " << feats_undistort->points.size() << std::endl;
}

void LIVMapper::handleLIO() 
{    
  euler_cur = RotMtoEuler(_state.rot_end);
  fout_pre << setw(20) << LidarMeasures.last_lio_update_time - _first_lidar_time << " " << euler_cur.transpose() * 57.3 << " "
           << _state.pos_end.transpose() << " " << _state.vel_end.transpose() << " " << _state.bias_g.transpose() << " "
           << _state.bias_a.transpose() << " " << V3D(_state.inv_expo_time, 0, 0).transpose() << endl;
           
  if (feats_undistort->empty() || (feats_undistort == nullptr)) 
  {
    std::cout << "[ LIO ]: No point!!!" << std::endl;
    return;
  }

  double t0 = omp_get_wtime();

  downSizeFilterSurf.setInputCloud(feats_undistort);
  downSizeFilterSurf.filter(*feats_down_body);
  
  double t_down = omp_get_wtime();

  feats_down_size = feats_down_body->points.size();
  voxelmap_manager->feats_down_body_ = feats_down_body;
  transformLidar(_state.rot_end, _state.pos_end, feats_down_body, feats_down_world);
  voxelmap_manager->feats_down_world_ = feats_down_world;
  voxelmap_manager->feats_down_size_ = feats_down_size;
  
  if (!lidar_map_inited) 
  {
    lidar_map_inited = true;
    voxelmap_manager->BuildVoxelMap();
  }

  double t1 = omp_get_wtime();

  voxelmap_manager->StateEstimation(state_propagat);
  _state = voxelmap_manager->state_;
  if (fout_lambda_.is_open())
    fout_lambda_ << std::fixed << std::setprecision(6)
                 << LidarMeasures.last_lio_update_time << ","
                 << voxelmap_manager->lambda_min_ << std::endl;
  _pv_list = voxelmap_manager->pv_list_;

  // A3: refresh the report-level static-hold offset BEFORE anything is reported.
  // The EKF state itself is left untouched (see updateStaticReportOffset).
  updateStaticReportOffset();

  // ZUPT unlock: the IMU-layer static detection cannot tell a standstill from
  // a slow straight start (specific-force noise ~0.15-0.25 m/s^2 masks the
  // ~0.15 m/s^2 start acceleration on campus-02). The LiDAR stream can: when
  // the cumulative frame-to-frame displacement exceeds 0.5 m the platform is
  // really moving, so permanently release the velocity freeze. On a static
  // platform the (degenerate) registration leaves the pose at ~0.01 m
  // wander, so the threshold is safe.
  //
  // A3: this test is DISABLED while the static position hold is active. The
  // displacement it measures is dominated by the very static sliding the hold
  // exists to remove (measured walk 0.04-0.3 m/s), so it fires within ~12 s of
  // a genuine standstill and defeats the hold. The IMU-only release tests in
  // ImuProcess (gyro, specific-force deviation, and the detrended specific-force
  // integral, whose noise is ~0.01 m/s against a ~0.3 m/s real start) replace it.
  if (zupt_enable_ && p_imu->zuptEnabled() && !zupt_hold_pos_en_)
  {
    static bool zupt_disp_init = false;
    static V3D zupt_last_pos = V3D::Zero();
    static double zupt_disp_acc = 0.0;
    if (!zupt_disp_init)
    {
      zupt_last_pos = _state.pos_end;
      zupt_disp_init = true;
    }
    if (!p_imu->zuptLocked())
    {
      zupt_disp_acc += (_state.pos_end - zupt_last_pos).norm();
      if (zupt_disp_acc > 0.5)
      {
        ROS_INFO("[ZUPT] LiDAR displacement %.2f m -> unlock", zupt_disp_acc);
        p_imu->zuptUnlock();
      }
    }
    zupt_last_pos = _state.pos_end;
  }

  double t2 = omp_get_wtime();

  if (imu_prop_enable) 
  {
    ekf_finish_once = true;
    latest_ekf_state = _state;
    latest_ekf_time = LidarMeasures.last_lio_update_time;
    state_update_flg = true;
  }

  if (graph_feedback_en_)
  {
    const double t_graph = LidarMeasures.last_lio_update_time;
    updateGraphOffset(t_graph);
    // Publish the applied offset every frame (held between graph updates) so
    // an evaluator can reconstruct the uncorrected EKF pose by subtraction.
    if (pubGraphOffset)
    {
      geometry_msgs::Vector3Stamped m;
      m.header.stamp = ros::Time().fromSec(t_graph);
      m.header.frame_id = "camera_init";
      m.vector.x = graph_offset_.x();
      m.vector.y = graph_offset_.y();
      m.vector.z = graph_offset_.z();
      pubGraphOffset.publish(m);
    }
  }

  if (graph_fusion_en_)
    updateGraphFusion(LidarMeasures.last_lio_update_time);

  logStateDiagnostic();

  if (pose_output_en) 
  {
    // WP8d: hold the stream instead of reopening it every frame. As a local, the
    // stream was destroyed at the end of each frame, so this was an open/close
    // pair per frame at 10 Hz. The `std::endl` below still flushes every frame,
    // so the on-disk content and its write timing are unchanged.
    static bool pos_opend = false;
    static std::ofstream evoFile;
    if (!pos_opend) 
    {
      evoFile.open(runtime_log_dir_ + "result/" + seq_name + ".txt", std::ios::out);
      pos_opend = true;
      if (!evoFile.is_open()) ROS_ERROR("open fail\n");
    } 
    Eigen::Matrix4d outT;
    Eigen::Quaterniond q(_state.rot_end);
    // A3: report the held pose during a confirmed standstill (report_offset_ is
    // zero unless the static hold is/has been active).
    const V3D rp = _state.truePos() + report_offset_ + graph_offset_;
    evoFile << std::fixed;
    evoFile << LidarMeasures.last_lio_update_time << " " << rp[0] << " " << rp[1] << " " << rp[2] << " "
            << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << std::endl;
  }
  
  euler_cur = RotMtoEuler(_state.rot_end);
  geoQuat = tf::createQuaternionMsgFromRollPitchYaw(euler_cur(0), euler_cur(1), euler_cur(2));
  publish_odometry(pubOdomAftMapped);

  double t3 = omp_get_wtime();

  PointCloudXYZI::Ptr world_lidar(new PointCloudXYZI());
  transformLidar(_state.rot_end, _state.pos_end, feats_down_body, world_lidar);
  for (size_t i = 0; i < world_lidar->points.size(); i++) 
  {
    voxelmap_manager->pv_list_[i].point_w << world_lidar->points[i].x, world_lidar->points[i].y, world_lidar->points[i].z;
    M3D point_crossmat = voxelmap_manager->cross_mat_list_[i];
    M3D var = voxelmap_manager->body_cov_list_[i];
    var = (_state.rot_end * extR) * var * (_state.rot_end * extR).transpose() +
          (-point_crossmat) * _state.cov.block<3, 3>(0, 0) * (-point_crossmat).transpose() + _state.cov.block<3, 3>(3, 3);
    voxelmap_manager->pv_list_[i].var = var;
  }
  voxelmap_manager->UpdateVoxelMap(voxelmap_manager->pv_list_);
  // Perf: per-frame "Update Voxel Map" log removed
  _pv_list = voxelmap_manager->pv_list_;

  // Improvement 1/3: dynamic-object debug clouds + per-frame statistics
  if (voxelmap_manager->config_setting_.dynamic_pub_en_) publishDynClouds();
  if (voxelmap_manager->config_setting_.dynamic_en_) logDynamicStats();

  // Improvement 2: factor-graph backend - push keyframes, poll smoothed output
  if (graph_)
  {
    tryPushGraphKeyframe();
    pollGraphResult();
  }
  // P5b: online bounded-history graph uses the same keyframe snapshot point
  // (before handleGNSS), i.e. scheme B; the graph itself runs in a separate node.
  if (online_graph_en_) tryPushOnlineGraphKeyframe();

  // Improvement 1/3: end-to-end latency instrumentation (frontend vs backend)
  // R4-5 (P3-1): the frontend "latency" used to be ros::Time::now() (wall
  // clock, 2020 epoch here) minus the DATA timestamp - a constant ~1.86e11 ms
  // that carried no information. What is actually measurable in-process is the
  // frame's own processing duration (t0 is the frame's omp_get_wtime start).
  if (latency_en_ && fout_latency_.is_open())
  {
    double frontend_ms = (omp_get_wtime() - t0) * 1000.0;
    fast_livo::GraphStats gs = graph_ ? graph_->getStats() : fast_livo::GraphStats();
    fout_latency_ << std::fixed << std::setprecision(6) << LidarMeasures.last_lio_update_time << ","
                  << frontend_ms << "," << gs.last_opt_time * 1000.0 << "," << gs.last_queue_latency * 1000.0 << ","
                  << gs.last_output_latency * 1000.0 << "," << gs.window << "," << gs.iters << std::endl;
  }
  
  double t4 = omp_get_wtime();

  if(voxelmap_manager->config_setting_.map_sliding_en)
  {
    voxelmap_manager->mapSliding();
    // R6 T3-2: the visual sparse map has no spatial bound of its own; follow
    // the LIO sliding cube (plus a margin) to stop the measured c03 growth.
    if (vio_visual_prune_en_ &&
        vio_manager->feat_map.size() >= (size_t)vio_visual_prune_min_voxels_)
    {
      const double lio_voxel = voxelmap_manager->config_setting_.max_voxel_size_;
      const double half_m =
          voxelmap_manager->config_setting_.half_map_size * lio_voxel;
      const int half_visual_voxels =
          (int)std::ceil(half_m / 0.5) + vio_visual_prune_margin_;
      vio_manager->pruneVisualMap(voxelmap_manager->position_last_,
                                  half_visual_voxels);
    }
  }
  
  PointCloudXYZI::Ptr laserCloudFullRes(dense_map_en ? feats_undistort : feats_down_body);
  int size = laserCloudFullRes->points.size();
  PointCloudXYZI::Ptr laserCloudWorld(new PointCloudXYZI(size, 1));

  for (int i = 0; i < size; i++) 
  {
    RGBpointBodyToWorld(&laserCloudFullRes->points[i], &laserCloudWorld->points[i]);
  }
  *pcl_w_wait_pub = *laserCloudWorld;

  publish_frame_world(pubLaserCloudFullRes, vio_manager);
  if (pub_effect_point_en) publish_effect_world(pubLaserCloudEffect, voxelmap_manager->ptpl_list_);
  if (voxelmap_manager->config_setting_.is_pub_plane_map_) voxelmap_manager->pubVoxelMap();
  publish_path(pubPath);
  publish_mavros(mavros_pose_publisher);

  frame_num++;
  aver_time_consu = aver_time_consu * (frame_num - 1) / frame_num + (t4 - t0) / frame_num;

  // aver_time_icp = aver_time_icp * (frame_num - 1) / frame_num + (t2 - t1) / frame_num;
  // aver_time_map_inre = aver_time_map_inre * (frame_num - 1) / frame_num + (t4 - t3) / frame_num;
  // aver_time_solve = aver_time_solve * (frame_num - 1) / frame_num + (solve_time) / frame_num;
  // aver_time_const_H_time = aver_time_const_H_time * (frame_num - 1) / frame_num + solve_const_H_time / frame_num;
  // printf("[ mapping time ]: per scan: propagation %0.6f downsample: %0.6f match: %0.6f solve: %0.6f  ICP: %0.6f  map incre: %0.6f total: %0.6f \n"
  //         "[ mapping time ]: average: icp: %0.6f construct H: %0.6f, total: %0.6f \n",
  //         t_prop - t0, t1 - t_prop, match_time, solve_time, t3 - t1, t5 - t3, t5 - t0, aver_time_icp, aver_time_const_H_time, aver_time_consu);

  // printf("\033[1;36m[ LIO mapping time ]: current scan: icp: %0.6f secs, map incre: %0.6f secs, total: %0.6f secs.\033[0m\n"
  //         "\033[1;36m[ LIO mapping time ]: average: icp: %0.6f secs, map incre: %0.6f secs, total: %0.6f secs.\033[0m\n",
  //         t2 - t1, t4 - t3, t4 - t0, aver_time_icp, aver_time_map_inre, aver_time_consu);
  // Perf: per-frame LIO timing table removed (was printed every frame)
  if (false)
  {
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;34m|                         LIO Mapping Time                    |\033[0m\n");
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;34m| %-29s | %-27s |\033[0m\n", "Algorithm Stage", "Time (secs)");
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "DownSample", t_down - t0);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "ICP", t2 - t1);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "updateVoxelMap", t4 - t3);
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "Current Total Time", t4 - t0);
    printf("\033[1;36m| %-29s | %-27f |\033[0m\n", "Average Total Time", aver_time_consu);
    printf("\033[1;34m+-------------------------------------------------------------+\033[0m\n");
  }

  euler_cur = RotMtoEuler(_state.rot_end);
  fout_out << std::setw(20) << LidarMeasures.last_lio_update_time - _first_lidar_time << " " << euler_cur.transpose() * 57.3 << " "
            << _state.pos_end.transpose() << " " << _state.vel_end.transpose() << " " << _state.bias_g.transpose() << " "
            << _state.bias_a.transpose() << " " << V3D(_state.inv_expo_time, 0, 0).transpose() << " " << feats_undistort->points.size() << std::endl;
}

void LIVMapper::savePCD() 
{
  if (pcd_save_en && (pcl_wait_save->points.size() > 0 || pcl_wait_save_intensity->points.size() > 0) && pcd_save_interval < 0) 
  {
    std::string raw_points_dir = runtime_log_dir_ + "pcd/all_raw_points.pcd";
    std::string downsampled_points_dir = runtime_log_dir_ + "pcd/all_downsampled_points.pcd";
    pcl::PCDWriter pcd_writer;

    if (img_en)
    {
      pcl::PointCloud<pcl::PointXYZRGB>::Ptr downsampled_cloud(new pcl::PointCloud<pcl::PointXYZRGB>);
      pcl::VoxelGrid<pcl::PointXYZRGB> voxel_filter;
      voxel_filter.setInputCloud(pcl_wait_save);
      voxel_filter.setLeafSize(filter_size_pcd, filter_size_pcd, filter_size_pcd);
      voxel_filter.filter(*downsampled_cloud);
  
      pcd_writer.writeBinary(raw_points_dir, *pcl_wait_save); // Save the raw point cloud data
      std::cout << GREEN << "Raw point cloud data saved to: " << raw_points_dir 
                << " with point count: " << pcl_wait_save->points.size() << RESET << std::endl;
      
      pcd_writer.writeBinary(downsampled_points_dir, *downsampled_cloud); // Save the downsampled point cloud data
      std::cout << GREEN << "Downsampled point cloud data saved to: " << downsampled_points_dir 
                << " with point count after filtering: " << downsampled_cloud->points.size() << RESET << std::endl;

      if(colmap_output_en)
      {
        fout_points << "# 3D point list with one line of data per point\n";
        fout_points << "#  POINT_ID, X, Y, Z, R, G, B, ERROR\n";
        for (size_t i = 0; i < downsampled_cloud->size(); ++i) 
        {
            const auto& point = downsampled_cloud->points[i];
            fout_points << i << " "
                        << std::fixed << std::setprecision(6)
                        << point.x << " " << point.y << " " << point.z << " "
                        << static_cast<int>(point.r) << " "
                        << static_cast<int>(point.g) << " "
                        << static_cast<int>(point.b) << " "
                        << 0 << std::endl;
        }
      }
    }
    else
    {      
      pcd_writer.writeBinary(raw_points_dir, *pcl_wait_save_intensity);
      std::cout << GREEN << "Raw point cloud data saved to: " << raw_points_dir 
                << " with point count: " << pcl_wait_save_intensity->points.size() << RESET << std::endl;
    }
  }
}

void LIVMapper::run() 
{
  // Continue servicing wall-time quality deadlines when /clock is paused.
  ros::WallRate rate(5000);
  while (ros::ok()) 
  {
    ros::spinOnce();

    // A4: GNSS-driven baseline modes (no LiDAR, no camera). These never call
    // sync_packages/processImu: the filter is advanced by GNSS epochs instead of
    // LiDAR frames (see runGnssInertial).
    if (slam_mode_ == GNSS_ONLY || slam_mode_ == GNSS_IMU)
    {
      if (!runGnssInertial()) rate.sleep();
      continue;
    }

    if (!sync_packages(LidarMeasures)) 
    {
      rate.sleep();
      continue;
    }
    handleFirstFrame();

    processImu();

    // if (!p_imu->imu_time_init) continue;

    stateEstimationAndMapping();

    // P2: cache the LIVO health for the next GNSS/RTK supervisor epoch.
    if (fusion_sup_cfg_.en)
    {
      livo_health_.eff_features = voxelmap_manager ? voxelmap_manager->effct_feat_num_ : 0;
      livo_health_.matched_points = voxelmap_manager ? voxelmap_manager->matched_point_num_ : 0;
      livo_health_.vio_points = vio_manager ? vio_manager->total_points : 0;
      livo_health_.vio_enabled = (img_en != 0);
      livo_health_.zupt_static = p_imu ? p_imu->zuptStatic() : false;
      livo_health_.report_hold = zupt_rep_holding_;
      livo_health_.align_locked = gnss_yaw_aligned;
    }

    // R6 P0-C: periodic memory/buffer growth probe (off unless configured).
    if (mem_log_every_n_ > 0 &&
        (++mem_frame_count_ % mem_log_every_n_ == 0))
      logMemoryStats();

    // Process GNSS measurements
    // Process all GNSS data within the time window, in chronological order
    if (gnss_en) {
      mtx_buffer.lock();
      bool origin_ok = gnss_origin_set;   // 锁内读取,避免与回调线程数据竞争
      mtx_buffer.unlock();
      if (origin_ok) {
      while (true) {
        mtx_buffer.lock();
        bool has_data = !gnss_buffer.empty();
        double front_time = has_data ? gnss_buffer.front().timestamp : 0.0;
        mtx_buffer.unlock();

        if (!has_data) break;        // Only process GNSS data that is not too far in the future
        // (propagation time < 0.5s)
        if (front_time >= LidarMeasures.last_lio_update_time + 0.5)
        {
          break;
        }
        handleGNSS();
      }
      }
    }

    // Phase 2: RTK double-difference updates. The NavSatFix path above performs
    // the ENU<->world alignment; this path consumes /rtk/dd and is independent
    // of the position-domain GNSS updates.
    if (rtk_tight_en) handleRTK();
  }
  savePCD();
}

void LIVMapper::prop_imu_once(StatesGroup &imu_prop_state, const double dt, V3D acc_avr, V3D angvel_avr)
{
  double mean_acc_norm = p_imu->IMU_mean_acc_norm;
  acc_avr = acc_avr * G_m_s2 / mean_acc_norm - imu_prop_state.bias_a;
  angvel_avr -= imu_prop_state.bias_g;

  M3D Exp_f = Exp(angvel_avr, dt);
  /* propogation of IMU attitude */
  imu_prop_state.rot_end = imu_prop_state.rot_end * Exp_f;

  /* Specific acceleration (global frame) of IMU */
  V3D acc_imu = imu_prop_state.rot_end * acc_avr + V3D(imu_prop_state.gravity[0], imu_prop_state.gravity[1], imu_prop_state.gravity[2]);

  /* propogation of IMU */
  imu_prop_state.pos_end = imu_prop_state.pos_end + imu_prop_state.vel_end * dt + 0.5 * acc_imu * dt * dt;

  /* velocity of IMU */
  imu_prop_state.vel_end = imu_prop_state.vel_end + acc_imu * dt;
}

void LIVMapper::imu_prop_callback(const ros::TimerEvent &e)
{
  if (p_imu->imu_need_init || !new_imu || !ekf_finish_once) { return; }
  mtx_buffer_imu_prop.lock();
  new_imu = false; // 控制propagate频率和IMU频率一致
  if (imu_prop_enable && !prop_imu_buffer.empty())
  {
    static double last_t_from_lidar_end_time = 0;
    if (state_update_flg)
    {
      imu_propagate = latest_ekf_state;
      // drop all useless imu pkg
      while ((!prop_imu_buffer.empty() && prop_imu_buffer.front().header.stamp.toSec() < latest_ekf_time))
      {
        prop_imu_buffer.pop_front();
      }
      last_t_from_lidar_end_time = 0;
      for (int i = 0; i < prop_imu_buffer.size(); i++)
      {
        double t_from_lidar_end_time = prop_imu_buffer[i].header.stamp.toSec() - latest_ekf_time;
        double dt = t_from_lidar_end_time - last_t_from_lidar_end_time;
        // cout << "prop dt" << dt << ", " << t_from_lidar_end_time << ", " << last_t_from_lidar_end_time << endl;
        V3D acc_imu(prop_imu_buffer[i].linear_acceleration.x, prop_imu_buffer[i].linear_acceleration.y, prop_imu_buffer[i].linear_acceleration.z);
        V3D omg_imu(prop_imu_buffer[i].angular_velocity.x, prop_imu_buffer[i].angular_velocity.y, prop_imu_buffer[i].angular_velocity.z);
        prop_imu_once(imu_propagate, dt, acc_imu, omg_imu);
        last_t_from_lidar_end_time = t_from_lidar_end_time;
      }
      state_update_flg = false;
    }
    else
    {
      V3D acc_imu(newest_imu.linear_acceleration.x, newest_imu.linear_acceleration.y, newest_imu.linear_acceleration.z);
      V3D omg_imu(newest_imu.angular_velocity.x, newest_imu.angular_velocity.y, newest_imu.angular_velocity.z);
      double t_from_lidar_end_time = newest_imu.header.stamp.toSec() - latest_ekf_time;
      double dt = t_from_lidar_end_time - last_t_from_lidar_end_time;
      prop_imu_once(imu_propagate, dt, acc_imu, omg_imu);
      last_t_from_lidar_end_time = t_from_lidar_end_time;
    }

    V3D posi, vel_i;
    Eigen::Quaterniond q;
    posi = imu_propagate.pos_end;
    vel_i = imu_propagate.vel_end;
    q = Eigen::Quaterniond(imu_propagate.rot_end);
    imu_prop_odom.header.frame_id = "world";
    imu_prop_odom.header.stamp = newest_imu.header.stamp;
    imu_prop_odom.pose.pose.position.x = posi.x();
    imu_prop_odom.pose.pose.position.y = posi.y();
    imu_prop_odom.pose.pose.position.z = posi.z();
    imu_prop_odom.pose.pose.orientation.w = q.w();
    imu_prop_odom.pose.pose.orientation.x = q.x();
    imu_prop_odom.pose.pose.orientation.y = q.y();
    imu_prop_odom.pose.pose.orientation.z = q.z();
    imu_prop_odom.twist.twist.linear.x = vel_i.x();
    imu_prop_odom.twist.twist.linear.y = vel_i.y();
    imu_prop_odom.twist.twist.linear.z = vel_i.z();
    pubImuPropOdom.publish(imu_prop_odom);
  }
  mtx_buffer_imu_prop.unlock();
}

void LIVMapper::transformLidar(const Eigen::Matrix3d rot, const Eigen::Vector3d t, const PointCloudXYZI::Ptr &input_cloud, PointCloudXYZI::Ptr &trans_cloud)
{
  PointCloudXYZI().swap(*trans_cloud);
  trans_cloud->reserve(input_cloud->size());
  for (size_t i = 0; i < input_cloud->size(); i++)
  {
    pcl::PointXYZINormal p_c = input_cloud->points[i];
    Eigen::Vector3d p(p_c.x, p_c.y, p_c.z);
    p = (rot * (extR * p + extT) + t);
    PointType pi;
    pi.x = p(0);
    pi.y = p(1);
    pi.z = p(2);
    pi.intensity = p_c.intensity;
    trans_cloud->points.push_back(pi);
  }
}

void LIVMapper::pointBodyToWorld(const PointType &pi, PointType &po)
{
  V3D p_body(pi.x, pi.y, pi.z);
  V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end);
  po.x = p_global(0);
  po.y = p_global(1);
  po.z = p_global(2);
  po.intensity = pi.intensity;
}

template <typename T> void LIVMapper::pointBodyToWorld(const Matrix<T, 3, 1> &pi, Matrix<T, 3, 1> &po)
{
  V3D p_body(pi[0], pi[1], pi[2]);
  V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end);
  po[0] = p_global(0);
  po[1] = p_global(1);
  po[2] = p_global(2);
}

template <typename T> Matrix<T, 3, 1> LIVMapper::pointBodyToWorld(const Matrix<T, 3, 1> &pi)
{
  V3D p(pi[0], pi[1], pi[2]);
  p = (_state.rot_end * (extR * p + extT) + _state.pos_end);
  Matrix<T, 3, 1> po(p[0], p[1], p[2]);
  return po;
}

void LIVMapper::RGBpointBodyToWorld(PointType const *const pi, PointType *const po)
{
  V3D p_body(pi->x, pi->y, pi->z);
  // A3: shift the published cloud by the same report offset as the pose, so the
  // displayed map and the displayed pose stay consistent in RViz.
  V3D p_global(_state.rot_end * (extR * p_body + extT) + _state.pos_end + report_offset_);
  po->x = p_global(0);
  po->y = p_global(1);
  po->z = p_global(2);
  po->intensity = pi->intensity;
}

void LIVMapper::RGBpointBodyLidarToIMU(PointType const *const pi, PointType *const po)
{
  V3D p_body_lidar(pi->x, pi->y, pi->z);
  V3D p_body_imu(extR * p_body_lidar + extT);

  po->x = p_body_imu(0);
  po->y = p_body_imu(1);
  po->z = p_body_imu(2);
  po->intensity = pi->intensity;
}

void LIVMapper::standard_pcl_cbk(const sensor_msgs::PointCloud2::ConstPtr &msg)
{
  if (!lidar_en) return;
  mtx_buffer.lock();

  double cur_head_time = msg->header.stamp.toSec() + lidar_time_offset;
  // cout<<"got feature"<<endl;
  if (cur_head_time < last_timestamp_lidar)
  {
    ROS_ERROR("lidar loop back, clear buffer");
    lid_raw_data_buffer.clear();
  }
  // ROS_INFO("get point cloud at time: %.6f", msg->header.stamp.toSec());
  PointCloudXYZI::Ptr ptr(new PointCloudXYZI());
  p_pre->process(msg, ptr);
  lid_raw_data_buffer.push_back(ptr);
  lid_header_time_buffer.push_back(cur_head_time);
  last_timestamp_lidar = cur_head_time;

  mtx_buffer.unlock();
  sig_buffer.notify_all();
}

void LIVMapper::livox_pcl_cbk(const livox_ros_driver::CustomMsg::ConstPtr &msg_in)
{
  if (!lidar_en) return;
  mtx_buffer.lock();
  livox_ros_driver::CustomMsg::Ptr msg(new livox_ros_driver::CustomMsg(*msg_in));
  // if ((abs(msg->header.stamp.toSec() - last_timestamp_lidar) > 0.2 && last_timestamp_lidar > 0) || sync_jump_flag)
  // {
  //   ROS_WARN("lidar jumps %.3f\n", msg->header.stamp.toSec() - last_timestamp_lidar);
  //   sync_jump_flag = true;
  //   msg->header.stamp = ros::Time().fromSec(last_timestamp_lidar + 0.1);
  // }
  if (abs(last_timestamp_imu - msg->header.stamp.toSec()) > 1.0 && !imu_buffer.empty())
  {
    double timediff_imu_wrt_lidar = last_timestamp_imu - msg->header.stamp.toSec();
    printf("\033[95mSelf sync IMU and LiDAR, HARD time lag is %.10lf \n\033[0m", timediff_imu_wrt_lidar - 0.100);
    // imu_time_offset = timediff_imu_wrt_lidar;
  }

  double cur_head_time = msg->header.stamp.toSec();
  ROS_INFO("Get LiDAR, its header time: %.6f", cur_head_time);
  if (cur_head_time < last_timestamp_lidar)
  {
    ROS_ERROR("lidar loop back, clear buffer");
    lid_raw_data_buffer.clear();
  }
  // ROS_INFO("get point cloud at time: %.6f", msg->header.stamp.toSec());
  PointCloudXYZI::Ptr ptr(new PointCloudXYZI());
  p_pre->process(msg, ptr);

  if (!ptr || ptr->empty()) {
    ROS_ERROR("Received an empty point cloud");
    mtx_buffer.unlock();
    return;
  }

  lid_raw_data_buffer.push_back(ptr);
  lid_header_time_buffer.push_back(cur_head_time);
  last_timestamp_lidar = cur_head_time;

  mtx_buffer.unlock();
  sig_buffer.notify_all();
}

void LIVMapper::imu_cbk(const sensor_msgs::Imu::ConstPtr &msg_in)
{
  if (!imu_en) return;

  // This guard drops IMU arriving before the first LiDAR scan. In the
  // GNSS-driven modes (A4) there is no scan at all, so it would silently
  // discard every IMU sample and the filter would never propagate.
  const bool gnss_driven = (slam_mode_ == GNSS_ONLY || slam_mode_ == GNSS_IMU);
  if (last_timestamp_lidar < 0.0 && !gnss_driven) return;
  // ROS_INFO("get imu at time: %.6f", msg_in->header.stamp.toSec());
  sensor_msgs::Imu::Ptr msg(new sensor_msgs::Imu(*msg_in));
  msg->header.stamp = ros::Time().fromSec(msg->header.stamp.toSec() - imu_time_offset);
  double timestamp = msg->header.stamp.toSec();

  if (ros_driver_fix_en)
  {
    if (!gnss_driven && fabs(last_timestamp_lidar - timestamp) > 0.5)
      ROS_WARN("IMU and LiDAR not synced! delta time: %lf .\n", last_timestamp_lidar - timestamp);
    timestamp += std::round(last_timestamp_lidar - timestamp);
  }
  msg->header.stamp = ros::Time().fromSec(timestamp);

  mtx_buffer.lock();

  if (last_timestamp_imu > 0.0 && timestamp < last_timestamp_imu)
  {
    mtx_buffer.unlock();
    sig_buffer.notify_all();
    ROS_ERROR("imu loop back, offset: %lf \n", last_timestamp_imu - timestamp);
    return;
  }

  // if (last_timestamp_imu > 0.0 && timestamp > last_timestamp_imu + 0.2)
  // {

  //   ROS_WARN("imu time stamp Jumps %0.4lf seconds \n", timestamp - last_timestamp_imu);
  //   mtx_buffer.unlock();
  //   sig_buffer.notify_all();
  //   return;
  // }

  last_timestamp_imu = timestamp;

  imu_buffer.push_back(msg);

  // Also maintain IMU history buffer for GNSS propagation
  // (imu_buffer gets consumed by sync_packages, but we need history for GNSS)
  imu_history_buffer.push_back(*msg);
  // Keep last ~30 seconds of IMU data (assuming 200Hz = 6000 samples)
  while (imu_history_buffer.size() > 6000) {
    imu_history_buffer.pop_front();
  }

  // Improvement 2: feed the factor-graph backend with the raw IMU stream
  if (graph_)
  {
    fast_livo::ImuSample s;
    s.t = timestamp;
    s.acc << msg->linear_acceleration.x, msg->linear_acceleration.y, msg->linear_acceleration.z;
    s.gyr << msg->angular_velocity.x, msg->angular_velocity.y, msg->angular_velocity.z;
    graph_->pushImu(s);
  }

  // cout<<"got imu: "<<timestamp<<" imu size "<<imu_buffer.size()<<endl;
  mtx_buffer.unlock();
  if (imu_prop_enable)
  {
    mtx_buffer_imu_prop.lock();
    if (imu_prop_enable && !p_imu->imu_need_init) { prop_imu_buffer.push_back(*msg); }
    newest_imu = *msg;
    new_imu = true;
    mtx_buffer_imu_prop.unlock();
  }
  sig_buffer.notify_all();
}

cv::Mat LIVMapper::getImageFromMsg(const sensor_msgs::ImageConstPtr &img_msg)
{
  cv::Mat img;
  img = cv_bridge::toCvCopy(img_msg, "bgr8")->image;
  return img;
}

void LIVMapper::img_cbk(const sensor_msgs::ImageConstPtr &msg_in)
{
  if (!img_en) return;
  sensor_msgs::Image::Ptr msg(new sensor_msgs::Image(*msg_in));
  // if ((abs(msg->header.stamp.toSec() - last_timestamp_img) > 0.2 && last_timestamp_img > 0) || sync_jump_flag)
  // {
  //   ROS_WARN("img jumps %.3f\n", msg->header.stamp.toSec() - last_timestamp_img);
  //   sync_jump_flag = true;
  //   msg->header.stamp = ros::Time().fromSec(last_timestamp_img + 0.1);
  // }

  // Hiliti2022 40Hz
  if (hilti_en)
  {
    static int frame_counter = 0;
    if (++frame_counter % 4 != 0) return;
  }
  // double msg_header_time =  msg->header.stamp.toSec();
  double msg_header_time = msg->header.stamp.toSec() + img_time_offset;
  if (abs(msg_header_time - last_timestamp_img) < 0.001) return;
  ROS_INFO("Get image, its header time: %.6f", msg_header_time);
  if (last_timestamp_lidar < 0) return;

  if (msg_header_time < last_timestamp_img)
  {
    ROS_ERROR("image loop back. \n");
    return;
  }

  mtx_buffer.lock();

  double img_time_correct = msg_header_time; // last_timestamp_lidar + 0.105;

  if (img_time_correct - last_timestamp_img < 0.02)
  {
    ROS_WARN("Image need Jumps: %.6f", img_time_correct);
    mtx_buffer.unlock();
    sig_buffer.notify_all();
    return;
  }

  cv::Mat img_cur = getImageFromMsg(msg);
  img_buffer.push_back(img_cur);
  img_time_buffer.push_back(img_time_correct);

  // ROS_INFO("Correct Image time: %.6f", img_time_correct);

  last_timestamp_img = img_time_correct;
  // cv::imshow("img", img);
  // cv::waitKey(1);
  // cout<<"last_timestamp_img:::"<<last_timestamp_img<<endl;
  mtx_buffer.unlock();
  sig_buffer.notify_all();
}

bool LIVMapper::sync_packages(LidarMeasureGroup &meas)
{
  if (lid_raw_data_buffer.empty() && lidar_en) return false;
  if (img_buffer.empty() && img_en) return false;
  if (imu_buffer.empty() && imu_en) return false;

  switch (slam_mode_)
  {
  case ONLY_LIO:
  {
    if (meas.last_lio_update_time < 0.0) meas.last_lio_update_time = lid_header_time_buffer.front();
    if (!lidar_pushed)
    {
      // If not push the lidar into measurement data buffer
      meas.lidar = lid_raw_data_buffer.front(); // push the first lidar topic
      if (meas.lidar->points.size() <= 1) return false;

      meas.lidar_frame_beg_time = lid_header_time_buffer.front();                                                // generate lidar_frame_beg_time
      meas.lidar_frame_end_time = meas.lidar_frame_beg_time + meas.lidar->points.back().curvature / double(1000); // calc lidar scan end time
      meas.pcl_proc_cur = meas.lidar;
      lidar_pushed = true;                                                                                       // flag
    }

    if (imu_en && last_timestamp_imu < meas.lidar_frame_end_time)
    { // waiting imu message needs to be
      // larger than _lidar_frame_end_time,
      // make sure complete propagate.
      // ROS_ERROR("out sync");
      return false;
    }

    struct MeasureGroup m; // standard method to keep imu message.

    m.imu.clear();
    m.lio_time = meas.lidar_frame_end_time;
    mtx_buffer.lock();
    while (!imu_buffer.empty())
    {
      if (imu_buffer.front()->header.stamp.toSec() > meas.lidar_frame_end_time) break;
      m.imu.push_back(imu_buffer.front());
      imu_buffer.pop_front();
    }
    lid_raw_data_buffer.pop_front();
    lid_header_time_buffer.pop_front();
    mtx_buffer.unlock();
    sig_buffer.notify_all();

    meas.lio_vio_flg = LIO; // process lidar topic, so timestamp should be lidar scan end.
    meas.measures.push_back(m);
    // ROS_INFO("ONlY HAS LiDAR and IMU, NO IMAGE!");
    lidar_pushed = false; // sync one whole lidar scan.
    return true;

    break;
  }

  case LIVO_GNSS:
  case LIVO:
  {
    /*** For LIVO mode, the time of LIO update is set to be the same as VIO, LIO
     * first than VIO imediatly ***/
    EKF_STATE last_lio_vio_flg = meas.lio_vio_flg;
    // double t0 = omp_get_wtime();
    switch (last_lio_vio_flg)
    {
    // double img_capture_time = meas.lidar_frame_beg_time + exposure_time_init;
    case WAIT:
    case VIO:
    {
      // printf("!!! meas.lio_vio_flg: %d \n", meas.lio_vio_flg);
      double img_capture_time = img_time_buffer.front() + exposure_time_init;
      /*** has img topic, but img topic timestamp larger than lidar end time,
       * process lidar topic. After LIO update, the meas.lidar_frame_end_time
       * will be refresh. ***/
      if (meas.last_lio_update_time < 0.0) meas.last_lio_update_time = lid_header_time_buffer.front();
      // printf("[ Data Cut ] wait \n");
      // printf("[ Data Cut ] last_lio_update_time: %lf \n",
      // meas.last_lio_update_time);

      double lid_newest_time = lid_header_time_buffer.back() + lid_raw_data_buffer.back()->points.back().curvature / double(1000);
      double imu_newest_time = imu_buffer.back()->header.stamp.toSec();

      if (img_capture_time < meas.last_lio_update_time + 0.00001)
      {
        img_buffer.pop_front();
        img_time_buffer.pop_front();
        ROS_ERROR("[ Data Cut ] Throw one image frame! \n");
        return false;
      }

      if (img_capture_time > lid_newest_time || img_capture_time > imu_newest_time)
      {
        // ROS_ERROR("lost first camera frame");
        // printf("img_capture_time, lid_newest_time, imu_newest_time: %lf , %lf
        // , %lf \n", img_capture_time, lid_newest_time, imu_newest_time);
        return false;
      }

      struct MeasureGroup m;

      // printf("[ Data Cut ] LIO \n");
      // printf("[ Data Cut ] img_capture_time: %lf \n", img_capture_time);
      m.imu.clear();
      m.lio_time = img_capture_time;
      mtx_buffer.lock();
      while (!imu_buffer.empty())
      {
        if (imu_buffer.front()->header.stamp.toSec() > m.lio_time) break;

        if (imu_buffer.front()->header.stamp.toSec() > meas.last_lio_update_time) m.imu.push_back(imu_buffer.front());

        imu_buffer.pop_front();
        // printf("[ Data Cut ] imu time: %lf \n",
        // imu_buffer.front()->header.stamp.toSec());
      }
      mtx_buffer.unlock();
      sig_buffer.notify_all();

      *(meas.pcl_proc_cur) = *(meas.pcl_proc_next);
      PointCloudXYZI().swap(*meas.pcl_proc_next);

      int lid_frame_num = lid_raw_data_buffer.size();
      int max_size = meas.pcl_proc_cur->size() + 24000 * lid_frame_num;
      meas.pcl_proc_cur->reserve(max_size);
      meas.pcl_proc_next->reserve(max_size);
      // deque<PointCloudXYZI::Ptr> lidar_buffer_tmp;

      while (!lid_raw_data_buffer.empty())
      {
        if (lid_header_time_buffer.front() > img_capture_time) break;
        auto pcl(lid_raw_data_buffer.front()->points);
        double frame_header_time(lid_header_time_buffer.front());
        float max_offs_time_ms = (m.lio_time - frame_header_time) * 1000.0f;

        for (int i = 0; i < pcl.size(); i++)
        {
          auto pt = pcl[i];
          if (pcl[i].curvature < max_offs_time_ms)
          {
            pt.curvature += (frame_header_time - meas.last_lio_update_time) * 1000.0f;
            meas.pcl_proc_cur->points.push_back(pt);
          }
          else
          {
            pt.curvature += (frame_header_time - m.lio_time) * 1000.0f;
            meas.pcl_proc_next->points.push_back(pt);
          }
        }
        lid_raw_data_buffer.pop_front();
        lid_header_time_buffer.pop_front();
      }

      meas.measures.push_back(m);
      meas.lio_vio_flg = LIO;
      meas.last_lio_update_time = m.lio_time;
      // printf("!!! meas.lio_vio_flg: %d \n", meas.lio_vio_flg);
      // printf("[ Data Cut ] pcl_proc_cur number: %d \n", meas.pcl_proc_cur
      // ->points.size()); printf("[ Data Cut ] LIO process time: %lf \n",
      // omp_get_wtime() - t0);
      return true;
    }

    case LIO:
    {
      double img_capture_time = img_time_buffer.front() + exposure_time_init;
      meas.lio_vio_flg = VIO;
      // printf("[ Data Cut ] VIO \n");
      meas.measures.clear();
      double imu_time = imu_buffer.front()->header.stamp.toSec();

      struct MeasureGroup m;
      m.vio_time = img_capture_time;
      m.lio_time = meas.last_lio_update_time;
      m.img = img_buffer.front();
      mtx_buffer.lock();
      // NOTE: VIO frame intentionally has no IMU: it shares the same image
      // timestamp as the preceding LIO frame (img_time_buffer.front() is not
      // consumed by the LIO branch), so its propagation window is empty.
      // Consuming IMU here would steal the LIO frame's propagation window.
      img_buffer.pop_front();
      img_time_buffer.pop_front();
      mtx_buffer.unlock();
      sig_buffer.notify_all();
      meas.measures.push_back(m);
      lidar_pushed = false; // after VIO update, the _lidar_frame_end_time will be refresh.
      // printf("[ Data Cut ] VIO process time: %lf \n", omp_get_wtime() - t0);
      return true;
    }

    default:
    {
      // printf("!! WRONG EKF STATE !!");
      return false;
    }
      // return false;
    }
    break;
  }

  case ONLY_LO:
  {
    if (!lidar_pushed) 
    { 
      // If not in lidar scan, need to generate new meas
      if (lid_raw_data_buffer.empty())  return false;
      meas.lidar = lid_raw_data_buffer.front(); // push the first lidar topic
      meas.lidar_frame_beg_time = lid_header_time_buffer.front(); // generate lidar_beg_time
      meas.lidar_frame_end_time  = meas.lidar_frame_beg_time + meas.lidar->points.back().curvature / double(1000); // calc lidar scan end time
      lidar_pushed = true;             
    }
    struct MeasureGroup m; // standard method to keep imu message.
    m.lio_time = meas.lidar_frame_end_time;
    mtx_buffer.lock();
    // Collect IMU up to the lidar scan end time for propagation.
    // (Restored: this loop was missing, so LIO-only mode had NO IMU
    // propagation at all and the state froze at the origin.)
    while (!imu_buffer.empty())
    {
      if (imu_buffer.front()->header.stamp.toSec() > meas.lidar_frame_end_time) break;
      m.imu.push_back(imu_buffer.front());
      imu_buffer.pop_front();
    }
    lid_raw_data_buffer.pop_front();
    lid_header_time_buffer.pop_front();
    mtx_buffer.unlock();
    sig_buffer.notify_all();
    lidar_pushed = false; // sync one whole lidar scan.
    meas.lio_vio_flg = LO; // process lidar topic, so timestamp should be lidar scan end.
    meas.measures.push_back(m);
    return true;
    break;
  }

  default:
  {
    printf("!! WRONG SLAM TYPE !!");
    return false;
  }
  }
  ROS_ERROR("out sync");
}

void LIVMapper::publish_img_rgb(const image_transport::Publisher &pubImage, VIOManagerPtr vio_manager)
{
  cv::Mat img_rgb = vio_manager->img_cp;
  cv_bridge::CvImage out_msg;
  out_msg.header.stamp = ros::Time::now();
  // out_msg.header.frame_id = "camera_init";
  out_msg.encoding = sensor_msgs::image_encodings::BGR8;
  out_msg.image = img_rgb;
  pubImage.publish(out_msg.toImageMsg());
}

// Provide output format for LiDAR-visual BA
void LIVMapper::publish_frame_world(const ros::Publisher &pubLaserCloudFullRes, VIOManagerPtr vio_manager)
{
  if (pcl_w_wait_pub->empty()) return;
  PointCloudXYZRGB::Ptr laserCloudWorldRGB(new PointCloudXYZRGB());
  static int pub_num = 1;
  pub_num++;

  if (LidarMeasures.lio_vio_flg == VIO)
  {
    *pcl_wait_pub += *pcl_w_wait_pub;
    if(pub_num >= pub_scan_num)
    {
      pub_num = 1;
      size_t size = pcl_wait_pub->points.size();
      laserCloudWorldRGB->reserve(size);
      // double inv_expo = _state.inv_expo_time;
      cv::Mat img_rgb = vio_manager->img_rgb;
      for (size_t i = 0; i < size; i++)
      {
        PointTypeRGB pointRGB;
        pointRGB.x = pcl_wait_pub->points[i].x;
        pointRGB.y = pcl_wait_pub->points[i].y;
        pointRGB.z = pcl_wait_pub->points[i].z;

        V3D p_w(pcl_wait_pub->points[i].x, pcl_wait_pub->points[i].y, pcl_wait_pub->points[i].z);
        V3D pf(vio_manager->new_frame_->w2f(p_w)); if (pf[2] < 0) continue;
        V2D pc(vio_manager->new_frame_->w2c(p_w));

        if (vio_manager->new_frame_->cam_->isInFrame(pc.cast<int>(), 3)) // 100
        {
          V3F pixel = vio_manager->getInterpolatedPixel(img_rgb, pc);
          pointRGB.r = pixel[2];
          pointRGB.g = pixel[1];
          pointRGB.b = pixel[0];
          // pointRGB.r = pixel[2] * inv_expo; pointRGB.g = pixel[1] * inv_expo; pointRGB.b = pixel[0] * inv_expo;
          // if (pointRGB.r > 255) pointRGB.r = 255; else if (pointRGB.r < 0) pointRGB.r = 0;
          // if (pointRGB.g > 255) pointRGB.g = 255; else if (pointRGB.g < 0) pointRGB.g = 0;
          // if (pointRGB.b > 255) pointRGB.b = 255; else if (pointRGB.b < 0) pointRGB.b = 0;
          if (pf.norm() > blind_rgb_points) laserCloudWorldRGB->push_back(pointRGB);
        }
      }
    }
  }

  /*** Publish Frame ***/
  sensor_msgs::PointCloud2 laserCloudmsg;
  if (slam_mode_ == LIVO && LidarMeasures.lio_vio_flg == VIO)
  {
    pcl::toROSMsg(*laserCloudWorldRGB, laserCloudmsg);
  }
  if (slam_mode_ == ONLY_LIO || slam_mode_ == ONLY_LO)
  { 
    pcl::toROSMsg(*pcl_w_wait_pub, laserCloudmsg); 
  }
  laserCloudmsg.header.stamp = ros::Time::now(); //.fromSec(last_timestamp_lidar);
  laserCloudmsg.header.frame_id = "camera_init";
  pubLaserCloudFullRes.publish(laserCloudmsg);

  /**************** save map ****************/
  /* 1. make sure you have enough memories
  /* 2. noted that pcd save will influence the real-time performences **/
  double update_time = 0.0;
  if (LidarMeasures.lio_vio_flg == VIO) {
    update_time = LidarMeasures.measures.back().vio_time;
  } else { // LIO / LO
    update_time = LidarMeasures.measures.back().lio_time;
  }
  std::stringstream ss_time;
  ss_time << std::fixed << std::setprecision(6) << update_time;

  if (pcd_save_en)
  {
    static int scan_wait_num = 0;

    switch (pcd_save_type)
    {
      case 0: /** world frame **/
        if (slam_mode_ == LIVO)
        {
          *pcl_wait_save += *laserCloudWorldRGB;
        }
        else
        {
          *pcl_wait_save_intensity += *pcl_w_wait_pub;
        }
        if(LidarMeasures.lio_vio_flg == LIO || LidarMeasures.lio_vio_flg == LO) scan_wait_num++;
        break;

      case 1: /** body frame **/
        if (LidarMeasures.lio_vio_flg == LIO || LidarMeasures.lio_vio_flg == LO)
        {
          int size = feats_undistort->points.size();
          PointCloudXYZI::Ptr laserCloudBody(new PointCloudXYZI(size, 1));
          for (int i = 0; i < size; i++)
          {
            RGBpointBodyLidarToIMU(&feats_undistort->points[i], &laserCloudBody->points[i]);
          }
          *pcl_wait_save_intensity += *laserCloudBody;
          scan_wait_num++;
          cout << "save body frame points: " << pcl_wait_save_intensity->points.size() << endl;
        }
        pcd_save_interval = 1;
        
        break;

      default:
        pcd_save_interval = 1;
        scan_wait_num++;
        break;
    }
    if ((pcl_wait_save->size() > 0 || pcl_wait_save_intensity->size() > 0) && pcd_save_interval > 0 && scan_wait_num >= pcd_save_interval)
    {
      string all_points_dir(string(runtime_log_dir_ + "pcd/") + ss_time.str() + string(".pcd"));

      pcl::PCDWriter pcd_writer;

      cout << "current scan saved to " << all_points_dir << endl;
      if (pcl_wait_save->points.size() > 0)
      {
        pcd_writer.writeBinary(all_points_dir, *pcl_wait_save); // pcl::io::savePCDFileASCII(all_points_dir, *pcl_wait_save);
        PointCloudXYZRGB().swap(*pcl_wait_save);
      }
      if(pcl_wait_save_intensity->points.size() > 0)
      {
        pcd_writer.writeBinary(all_points_dir, *pcl_wait_save_intensity);
        PointCloudXYZI().swap(*pcl_wait_save_intensity);
      }
      scan_wait_num = 0;
    }
    
    if(LidarMeasures.lio_vio_flg == LIO || LidarMeasures.lio_vio_flg == LO)
    {
      Eigen::Quaterniond q(_state.rot_end);
      fout_lidar_pos << std::fixed << std::setprecision(6);
      fout_lidar_pos <<  LidarMeasures.measures.back().lio_time << " " << _state.pos_end[0] << " " << _state.pos_end[1] << " " << _state.pos_end[2] << " " << q.x() << " " << q.y() << " " << q.z()
          << " " << q.w() << " " << endl;
    }
  }
  if (img_save_en && LidarMeasures.lio_vio_flg == VIO)
  {
    static int img_wait_num = 0;
    img_wait_num++;

    if (img_save_interval > 0 && img_wait_num >= img_save_interval)
    {
      imwrite(string(runtime_log_dir_ + "image/") + ss_time.str() + string(".png"), vio_manager->img_rgb);
      
      Eigen::Quaterniond q(_state.rot_end);
      fout_visual_pos << std::fixed << std::setprecision(6);
      fout_visual_pos << LidarMeasures.measures.back().vio_time << " " << _state.pos_end[0] << " " << _state.pos_end[1] << " " << _state.pos_end[2] << " "
            << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << std::endl;
      img_wait_num = 0;
    }
  }

  if(laserCloudWorldRGB->size() > 0)  PointCloudXYZI().swap(*pcl_wait_pub); 
  if(LidarMeasures.lio_vio_flg == VIO)  PointCloudXYZI().swap(*pcl_w_wait_pub);
}

void LIVMapper::publish_visual_sub_map(const ros::Publisher &pubSubVisualMap)
{
  PointCloudXYZI::Ptr laserCloudFullRes(visual_sub_map);
  int size = laserCloudFullRes->points.size(); if (size == 0) return;
  PointCloudXYZI::Ptr sub_pcl_visual_map_pub(new PointCloudXYZI());
  *sub_pcl_visual_map_pub = *laserCloudFullRes;
  if (1)
  {
    sensor_msgs::PointCloud2 laserCloudmsg;
    pcl::toROSMsg(*sub_pcl_visual_map_pub, laserCloudmsg);
    laserCloudmsg.header.stamp = ros::Time::now();
    laserCloudmsg.header.frame_id = "camera_init";
    pubSubVisualMap.publish(laserCloudmsg);
  }
}

void LIVMapper::publish_effect_world(const ros::Publisher &pubLaserCloudEffect, const std::vector<PointToPlane> &ptpl_list)
{
  int effect_feat_num = ptpl_list.size();
  PointCloudXYZI::Ptr laserCloudWorld(new PointCloudXYZI(effect_feat_num, 1));
  for (int i = 0; i < effect_feat_num; i++)
  {
    laserCloudWorld->points[i].x = ptpl_list[i].point_w_[0];
    laserCloudWorld->points[i].y = ptpl_list[i].point_w_[1];
    laserCloudWorld->points[i].z = ptpl_list[i].point_w_[2];
  }
  sensor_msgs::PointCloud2 laserCloudFullRes3;
  pcl::toROSMsg(*laserCloudWorld, laserCloudFullRes3);
  laserCloudFullRes3.header.stamp = ros::Time::now();
  laserCloudFullRes3.header.frame_id = "camera_init";
  pubLaserCloudEffect.publish(laserCloudFullRes3);
}

template <typename T> void LIVMapper::set_posestamp(T &out)
{
  // A3: same report-level static hold as the trajectory output.
  const V3D rp = _state.truePos() + report_offset_ + graph_offset_;
  out.position.x = rp(0);
  out.position.y = rp(1);
  out.position.z = rp(2);
  out.orientation.x = geoQuat.x;
  out.orientation.y = geoQuat.y;
  out.orientation.z = geoQuat.z;
  out.orientation.w = geoQuat.w;
}

void LIVMapper::publish_odometry(const ros::Publisher &pubOdomAftMapped)
{
  odomAftMapped.header.frame_id = "camera_init";
  odomAftMapped.child_frame_id = "aft_mapped";
  odomAftMapped.header.stamp = ros::Time().fromSec(last_timestamp_lidar);
  set_posestamp(odomAftMapped.pose.pose);

  static tf::TransformBroadcaster br;
  tf::Transform transform;
  tf::Quaternion q;
  // WP8a: same report-level static hold as set_posestamp above, so the tf frame
  // agrees with odom/path. Broadcasting the raw _state.pos_end made tf (and every
  // downstream consumer of it) disagree with odometry while the hold was active.
  const V3D rp = _state.truePos() + report_offset_ + graph_offset_;
  transform.setOrigin(tf::Vector3(rp(0), rp(1), rp(2)));
  q.setW(geoQuat.w);
  q.setX(geoQuat.x);
  q.setY(geoQuat.y);
  q.setZ(geoQuat.z);
  transform.setRotation(q);
  br.sendTransform( tf::StampedTransform(transform, odomAftMapped.header.stamp, "camera_init", "aft_mapped") );
  pubOdomAftMapped.publish(odomAftMapped);
}

void LIVMapper::publish_mavros(const ros::Publisher &mavros_pose_publisher)
{
  msg_body_pose.header.stamp = ros::Time::now();
  msg_body_pose.header.frame_id = "camera_init";
  set_posestamp(msg_body_pose.pose);
  mavros_pose_publisher.publish(msg_body_pose);
}

void LIVMapper::publish_path(const ros::Publisher pubPath)
{
  set_posestamp(msg_body_pose.pose);
  msg_body_pose.header.stamp = ros::Time::now();
  msg_body_pose.header.frame_id = "camera_init";
  path.poses.push_back(msg_body_pose);
  pubPath.publish(path);
}

// ============================================================
// Improvement 1/3: dynamic-object output
// ============================================================

void LIVMapper::publishDynClouds()
{
  voxelmap_manager->collectDynamicClouds();
  sensor_msgs::PointCloud2 msg;
  msg.header.frame_id = "camera_init";
  msg.header.stamp = ros::Time().fromSec(LidarMeasures.last_lio_update_time);
  pcl::toROSMsg(*voxelmap_manager->dyn_points_, msg);
  pubLaserCloudDyn.publish(msg);
  pcl::toROSMsg(*voxelmap_manager->dyn_removed_, msg);
  pubLaserCloudDynRmed.publish(msg);
  pcl::toROSMsg(*voxelmap_manager->dyn_hist_, msg);
  pubLaserCloudDynDbg.publish(msg);
}

void LIVMapper::logDynamicStats()
{
  if (!fout_dyn_.is_open()) return;
  fout_dyn_ << std::fixed << std::setprecision(6) << LidarMeasures.last_lio_update_time << ","
            << feats_down_size << "," << voxelmap_manager->matched_point_num_ << "," << voxelmap_manager->dyn_point_num_
            << std::endl;
}

void LIVMapper::logMemoryStats()
{
  if (!fout_mem_.is_open()) return;
  long rss_kb = 0, hwm_kb = 0;
  std::ifstream status("/proc/self/status");
  std::string line;
  while (std::getline(status, line))
  {
    if (line.rfind("VmRSS:", 0) == 0)
      rss_kb = std::atol(line.c_str() + 6);
    else if (line.rfind("VmHWM:", 0) == 0)
      hwm_kb = std::atol(line.c_str() + 6);
  }
  const size_t feat_n = vio_manager ? vio_manager->feat_map.size() : 0;
  const size_t vox_n = voxelmap_manager ? voxelmap_manager->voxel_map_.size() : 0;
  fout_mem_ << std::fixed << std::setprecision(3) << LidarMeasures.last_lio_update_time << ","
            << mem_frame_count_ << "," << rss_kb << "," << hwm_kb << ","
            << img_buffer.size() << "," << lid_raw_data_buffer.size() << ","
            << imu_buffer.size() << "," << gnss_buffer.size() << ","
            << prop_imu_buffer.size() << "," << feat_n << "," << vox_n << std::endl;
}

void LIVMapper::logStateDiagnostic()
{
  if (!state_diagnostic_en_ || !fout_state_diagnostic_) return;
  const V3D metric = _state.truePos();
  const V3D reported = metric + report_offset_ + graph_offset_;
  const Eigen::Quaterniond q(_state.rot_end);
  fout_state_diagnostic_ << std::fixed << std::setprecision(9)
      << LidarMeasures.last_lio_update_time;
  for (const auto &v : {_state.pos_end, metric, reported, report_offset_, graph_offset_, _state.vel_end})
    fout_state_diagnostic_ << ',' << v.x() << ',' << v.y() << ',' << v.z();
  fout_state_diagnostic_ << ',' << q.x() << ',' << q.y() << ',' << q.z() << ',' << q.w()
      << ',' << _state.scale_h << ',' << zupt_rep_holding_ << ',' << p_imu->zuptStatic()
      << ',' << voxelmap_manager->lambda_min_ << ',' << _state.cov.block<3,3>(3,3).trace()
      << ',' << last_timestamp_imu << ',' << last_timestamp_lidar << '\n';
}

// ============================================================
// Improvement 2: factor-graph backend integration
// ============================================================

void LIVMapper::tryPushGraphKeyframe()
{
  if (!graph_) return;

  // keyframe selection: distance / rotation / frame-count thresholds
  bool is_kf = false;
  if (!graph_has_prev_kf_)
  {
    is_kf = true;
  }
  else
  {
    const double dist = (_state.pos_end - graph_prev_kf_pos_).norm();
    const M3D rot_rel = graph_prev_kf_R_.transpose() * _state.rot_end;
    const double rot_deg = Log(rot_rel).norm() * 57.3;
    is_kf = dist > graph_cfg_.kf_dist || rot_deg > graph_cfg_.kf_rot_deg || frames_since_kf_ >= graph_cfg_.kf_min_frames;
  }
  frames_since_kf_++;
  if (!is_kf) return;
  frames_since_kf_ = 0;

  fast_livo::GraphKeyframe kf;
  kf.stamp = LidarMeasures.last_lio_update_time;
  kf.R = _state.rot_end;
  kf.p = _state.pos_end;
  kf.v = _state.vel_end;
  kf.gravity = _state.gravity;

  // R3 P1-1 third layer: the filter's velocity transiently LEADS its own
  // position increments during acceleration (~0.3 m/s, EVAL_PROTOCOL 15.6),
  // and the pre-int's v_k*dt term turns that into phantom motion which the
  // window-slide then accumulates. When graph_v_ref_pos_frames_ > 0, anchor
  // the graph's velocity reference to the position-implied velocity over that
  // many keyframes instead - consistent with the odometry factors by
  // construction. 0 keeps the filter velocity (the historical behaviour).
  if (graph_v_ref_pos_frames_ > 0)
  {
    graph_pos_hist_.emplace_back(kf.stamp, kf.p);
    while ((int)graph_pos_hist_.size() > graph_v_ref_pos_frames_ + 1)
      graph_pos_hist_.pop_front();
    if ((int)graph_pos_hist_.size() > 1)
    {
      const auto &old = graph_pos_hist_.front();
      const double dts = kf.stamp - old.first;
      if (dts > 1e-3) kf.v = (kf.p - old.second) / dts;
    }
  }

  if (graph_has_prev_kf_)
  {
    kf.R_rel = graph_prev_kf_R_.transpose() * _state.rot_end;
    kf.p_rel = graph_prev_kf_R_.transpose() * (_state.pos_end - graph_prev_kf_pos_);
  }
  else
  {
    kf.R_rel = M3D::Identity();
    kf.p_rel = V3D::Zero();
  }

  // attach the most recent GNSS fix (only after the ENU-world yaw alignment)
  kf.have_gnss = false;
  if (graph_cfg_.gnss_en && gnss_en && gnss_yaw_aligned && last_valid_gnss_.valid)
  {
    // R3-WP8i: the tolerance needs an absolute value. Without fabs a fix whose
    // timestamp is in the FUTURE relative to the LIO state (a negative difference)
    // passed unconditionally, so a keyframe could be attached to a GNSS position
    // that is arbitrarily far ahead in time. The GNSS updates themselves do
    // encounter such fixes (the 0-0.5 s forward window), so this is not academic.
    if (fabs(LidarMeasures.last_lio_update_time - last_valid_gnss_.timestamp) < 0.5)
    {
      V3D p_enu(last_valid_gnss_.pos_e, last_valid_gnss_.pos_n, last_valid_gnss_.pos_u);
      kf.gnss_pos = enu_R_world * p_enu + enu_t_world;
      kf.gnss_sigma = graph_cfg_.gnss_pos_sigma;
      kf.have_gnss = true;
    }
  }

  graph_->pushKeyframe(kf);
  graph_prev_kf_R_ = kf.R;
  graph_prev_kf_pos_ = kf.p;
  graph_has_prev_kf_ = true;

  // non-threaded fallback: optimize synchronously in the main loop
  if (!graph_cfg_.thread_en)
  {
    graph_->optimizeOnce();
    pollGraphResult();
  }
}

void LIVMapper::tryPushOnlineGraphKeyframe()
{
  if (!online_graph_en_ || !pubOnlineGraphKeyframe) return;
  const double t = LidarMeasures.last_lio_update_time;
  if (t <= 0.0) return;
  if (online_graph_last_kf_t_ >= 0.0 && t - online_graph_last_kf_t_ < 1.0) return;

  fast_livo::OnlineGraphKeyframe msg;
  msg.header.stamp = ros::Time().fromSec(t);
  msg.header.frame_id = "camera_init";
  // Same metric pose as the logged trajectory: truePos() applies the GNSS
  // horizontal scale and report_offset_ the static hold.
  const V3D p_report = _state.truePos() + report_offset_;
  if (graph_fusion_en_)
  {
    GraphKeyframe hk;
    hk.t = t;
    hk.p = p_report;
    hk.R = _state.rot_end;
    std::lock_guard<std::mutex> lk(graph_fusion_mtx_);
    graph_kf_hist_.push_back(hk);
    while (graph_kf_hist_.size() > 20) graph_kf_hist_.pop_front();
  }
  msg.pose.position.x = p_report.x();
  msg.pose.position.y = p_report.y();
  msg.pose.position.z = p_report.z();
  Eigen::Quaterniond q(_state.rot_end);
  q.normalize();
  msg.pose.orientation.x = q.x();
  msg.pose.orientation.y = q.y();
  msg.pose.orientation.z = q.z();
  msg.pose.orientation.w = q.w();
  // P0: the LiDAR pose Hessian min eigenvalue drives the degeneracy-aware
  // RTK weight. 0 (not published) means "unknown" in the graph.
  msg.lambda_min = voxelmap_manager ? voxelmap_manager->lambda_min_ : 0.0;
  // R4.2c: publish the frontend's locked ENU<->world transform so the graph does
  // not re-fit yaw from a short window. world = enu_R_world * enu + enu_t_world.
  msg.frame_valid = gnss_yaw_aligned;
  if (gnss_yaw_aligned)
  {
    Eigen::Quaterniond qf(enu_R_world);
    qf.normalize();
    msg.world_from_enu.rotation.x = qf.x();
    msg.world_from_enu.rotation.y = qf.y();
    msg.world_from_enu.rotation.z = qf.z();
    msg.world_from_enu.rotation.w = qf.w();
    msg.world_from_enu.translation.x = enu_t_world.x();
    msg.world_from_enu.translation.y = enu_t_world.y();
    msg.world_from_enu.translation.z = enu_t_world.z();
  }
  msg.scale = _state.scale_h;
  pubOnlineGraphKeyframe.publish(msg);
  online_graph_last_kf_t_ = t;
}

void LIVMapper::onlineGraphCorrectionCallback(
    const geometry_msgs::Vector3Stamped::ConstPtr &msg)
{
  if (!graph_feedback_en_) return;
  std::lock_guard<std::mutex> lk(graph_corr_mtx_);
  graph_corr_target_ = V3D(msg->vector.x, msg->vector.y, msg->vector.z);
  graph_corr_stamp_ = msg->header.stamp.toSec();
  graph_corr_valid_ = true;
}

void LIVMapper::updateGraphOffset(double t)
{
  if (!graph_feedback_en_) return;
  V3D target;
  double stamp = 0.0;
  bool valid = false;
  {
    std::lock_guard<std::mutex> lk(graph_corr_mtx_);
    target = graph_corr_target_;
    stamp = graph_corr_stamp_;
    valid = graph_corr_valid_;
  }
  if (!valid) return;
  const double age = t - stamp;
  if (age > graph_feedback_max_age_ || age < -0.5) return;
  if (target.norm() > graph_feedback_max_offset_) return;

  const V3D delta = target - graph_offset_;
  const double n = delta.norm();
  if (n < 1e-9) return;
  const double step = std::min(
      n, std::max(0.0, graph_feedback_max_step_) *
             std::max(0.0, graph_feedback_gain_));
  graph_offset_ += delta * (step / n);
  const double on = graph_offset_.norm();
  if (on > graph_feedback_max_offset_)
    graph_offset_ *= graph_feedback_max_offset_ / on;
}

void LIVMapper::globalGraphOdomCallback(
    const nav_msgs::Odometry::ConstPtr &msg)
{
  if (!graph_fusion_en_) return;
  const double t = msg->header.stamp.toSec();
  GraphKeyframe kf;
  bool found = false;
  {
    std::lock_guard<std::mutex> lk(graph_fusion_mtx_);
    for (auto it = graph_kf_hist_.rbegin(); it != graph_kf_hist_.rend(); ++it)
    {
      if (std::fabs(it->t - t) < 0.1)
      {
        kf = *it;
        found = true;
        break;
      }
    }
    if (!found) return;

    GraphAnchor a;
    a.valid = true;
    a.t = t;
    a.p_G = V3D(msg->pose.pose.position.x, msg->pose.pose.position.y,
                msg->pose.pose.position.z);
    a.q_G = Eigen::Quaterniond(
        msg->pose.pose.orientation.w, msg->pose.pose.orientation.x,
        msg->pose.pose.orientation.y, msg->pose.pose.orientation.z);
    a.q_G.normalize();
    // The graph orientation is R_G * R_k; recover the ENU<-LIO yaw.
    a.R_G = a.q_G.toRotationMatrix() * kf.R.transpose();
    a.p_k = kf.p;
    a.R_k = kf.R;
    for (int i = 0; i < 36; ++i)
      a.cov[i] = msg->pose.covariance[i];
    a.seq = ++graph_anchor_seq_;
    graph_anchor_pending_ = a;
  }
}

void LIVMapper::updateGraphFusion(double t)
{
  if (!graph_fusion_en_ || !pubGlobalOdom) return;

  bool has_pending = false;
  GraphAnchor pending;
  {
    std::lock_guard<std::mutex> lk(graph_fusion_mtx_);
    if (graph_anchor_pending_.valid &&
        graph_anchor_pending_.seq != graph_anchor_seen_seq_)
    {
      pending = graph_anchor_pending_;
      graph_anchor_seen_seq_ = pending.seq;
      has_pending = true;
    }
  }
  if (has_pending)
  {
    if (graph_anchor_has_cur_)
    {
      const GraphAnchor old = graph_anchor_cur_;
      const double dt = pending.t - old.t;
      if (dt > 1e-3)
      {
        pending.v_G = (pending.p_G - old.p_G) / dt;
        if (graph_fusion_mode_ == "auto")
        {
          const V3D pred = old.p_G + old.R_G * (pending.p_k - old.p_k);
          const double err = (pending.p_G - pred).norm();
          pending.use_velocity =
              (err > graph_fusion_relative_max_error_ ||
               pending.v_G.norm() < graph_fusion_static_speed_);
        }
        graph_anchor_prev_ = old;
        graph_anchor_has_prev_ = true;
      }
      else
      {
        // Fix-only re-solve of the same keyframe: keep the last distinct-time
        // velocity; resetting it to zero made the velocity mode hold/jump.
        pending.v_G = old.v_G;
        pending.use_velocity = old.use_velocity;
      }
    }
    if (graph_fusion_mode_ == "graph_vel")
      pending.use_velocity = true;
    else if (graph_fusion_mode_ == "ekf_rel")
      pending.use_velocity = false;
    graph_anchor_cur_ = pending;
    graph_anchor_has_cur_ = true;
    graph_blend_start_t_ = t;
  }
  if (!graph_anchor_has_cur_) return;

  const GraphAnchor &cur = graph_anchor_cur_;
  const V3D p_report = _state.truePos() + report_offset_;
  const M3D R_ekf = _state.rot_end;

  const auto compose = [&](const GraphAnchor &a) {
    V3D p;
    Eigen::Quaterniond q;
    if (a.use_velocity)
    {
      // The EKF relative is not trustworthy (large anchor error or standstill):
      // interpolate the graph's global motion instead.
      p = a.p_G + a.v_G * (t - a.t);
      q = a.q_G;
    }
    else
    {
      p = a.p_G + a.R_G * (p_report - a.p_k);
      q = a.q_G * Eigen::Quaterniond(a.R_k.transpose() * R_ekf);
    }
    q.normalize();
    return std::make_pair(p, q);
  };

  auto cur_out = compose(cur);
  V3D p_out = cur_out.first;
  Eigen::Quaterniond q_out = cur_out.second;
  if (graph_anchor_has_prev_ && graph_fusion_blend_s_ > 0.0 &&
      t - graph_blend_start_t_ < graph_fusion_blend_s_)
  {
    const auto prev_out = compose(graph_anchor_prev_);
    const double alpha = std::min(
        1.0, std::max(0.0, (t - graph_blend_start_t_) /
                               graph_fusion_blend_s_));
    p_out = (1.0 - alpha) * prev_out.first + alpha * cur_out.first;
    q_out = prev_out.second.slerp(alpha, cur_out.second);
    q_out.normalize();
  }

  nav_msgs::Odometry odom;
  odom.header.stamp = ros::Time().fromSec(t);
  odom.header.frame_id = "enu";
  odom.child_frame_id = "base_link";
  odom.pose.pose.position.x = p_out(0);
  odom.pose.pose.position.y = p_out(1);
  odom.pose.pose.position.z = p_out(2);
  odom.pose.pose.orientation.x = q_out.x();
  odom.pose.pose.orientation.y = q_out.y();
  odom.pose.pose.orientation.z = q_out.z();
  odom.pose.pose.orientation.w = q_out.w();
  for (int i = 0; i < 36; ++i)
    odom.pose.covariance[i] = cur.cov[i];
  pubGlobalOdom.publish(odom);

  if (!pubGlobalPath) return;
  global_path_.header.frame_id = "enu";
  global_path_.header.stamp = ros::Time().fromSec(t);
  geometry_msgs::PoseStamped ps;
  ps.header = global_path_.header;
  ps.pose = odom.pose.pose;
  global_path_.poses.push_back(ps);
  const int max_len = std::max(1, graph_fusion_path_len_);
  if (static_cast<int>(global_path_.poses.size()) > max_len)
    global_path_.poses.erase(
        global_path_.poses.begin(),
        global_path_.poses.begin() +
            (static_cast<int>(global_path_.poses.size()) - max_len));
  if (++global_path_counter_ % 20 == 0)
    pubGlobalPath.publish(global_path_);
}

void LIVMapper::publishSmoothedOdom(const fast_livo::GraphResult &gr)
{
  smoothed_odom_.header.frame_id = "camera_init";
  smoothed_odom_.child_frame_id = "smoothed";
  smoothed_odom_.header.stamp = ros::Time().fromSec(gr.stamp);
  Eigen::Quaterniond q(gr.R);
  smoothed_odom_.pose.pose.position.x = gr.p(0);
  smoothed_odom_.pose.pose.position.y = gr.p(1);
  smoothed_odom_.pose.pose.position.z = gr.p(2);
  smoothed_odom_.pose.pose.orientation.x = q.x();
  smoothed_odom_.pose.pose.orientation.y = q.y();
  smoothed_odom_.pose.pose.orientation.z = q.z();
  smoothed_odom_.pose.pose.orientation.w = q.w();
  smoothed_odom_.twist.twist.linear.x = gr.v(0);
  smoothed_odom_.twist.twist.linear.y = gr.v(1);
  smoothed_odom_.twist.twist.linear.z = gr.v(2);
  pubSmoothedOdom.publish(smoothed_odom_);

  geometry_msgs::PoseStamped ps;
  ps.header = smoothed_odom_.header;
  ps.pose = smoothed_odom_.pose.pose;
  smoothed_path_.header.frame_id = "camera_init";
  smoothed_path_.header.stamp = smoothed_odom_.header.stamp;
  smoothed_path_.poses.push_back(ps);
  pubSmoothedPath.publish(smoothed_path_);

  // TUM trajectory of the smoothed backend
  if (pose_output_en)
  {
    static bool graph_pos_opend = false;
    static std::ofstream graphEvoFile;
    if (!graph_pos_opend)
    {
      graphEvoFile.open(runtime_log_dir_ + "result/" + seq_name + "_graph.txt", std::ios::out);
      graph_pos_opend = true;
    }
    if (graphEvoFile.is_open())
    {
      graphEvoFile << std::fixed;
      graphEvoFile << gr.stamp << " " << gr.p(0) << " " << gr.p(1) << " " << gr.p(2) << " "
                   << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << std::endl;
    }
  }
}

void LIVMapper::pollGraphResult()
{
  if (!graph_) return;
  fast_livo::GraphResult gr;
  if (graph_->getLatest(gr) && gr.updated && gr.stamp > graph_last_written_stamp_ + 1e-9)
  {
    graph_last_written_stamp_ = gr.stamp;
    publishSmoothedOdom(gr);
  }
}

// ============================================================
// GNSS/RTK Tight Coupling Functions
// ============================================================

// Exact-stamp bidirectional pairing. ROS callbacks run on the same spinOnce
// queue. Waiting is nonblocking and happens before taking mtx_buffer.
void LIVMapper::gnss_quality_cbk(const fast_livo::GnssQuality::ConstPtr &msg)
{
  fast_livo::GnssQualityRecord r;
  r.valid = msg->valid;
  r.num_sv = msg->num_sv;
  r.p_dop = msg->p_dop;
  r.h_acc_mm = msg->h_acc_mm;
  r.v_acc_mm = msg->v_acc_mm;
  r.carr_soln = msg->carr_soln;
  r.fix_type = msg->fix_type;
  r.has_p_dop = msg->has_p_dop;
  r.has_h_acc = msg->has_h_acc;
  r.has_v_acc = msg->has_v_acc;
  r.source = gnss_quality_source_;
  const uint64_t stamp = msg->header.stamp.toNSec();
  if (gnss_pairer_) {
    flushGnssPairs();
    gnss_pairer_->addQuality(stamp, r, gnssReceiveTime());
    flushGnssPairs();
  }
}

void LIVMapper::gnss_cbk(const sensor_msgs::NavSatFix::ConstPtr &msg)
{
  if (!gnss_pairer_) { processGnssFix(msg, nullptr); return; }
  flushGnssPairs();
  gnss_pairer_->addFix(msg->header.stamp.toNSec(), msg, gnssReceiveTime());
  flushGnssPairs();
}

void LIVMapper::drainGnssPairs(const ros::WallTimerEvent &)
{
  flushGnssPairs();
}

void LIVMapper::flushGnssPairs()
{
  if (!gnss_pairer_) return;
  const ros::Time clock = ros::Time::now();
  if (!gnss_pair_clock_.isZero() && clock < gnss_pair_clock_) {
    gnss_pairer_->reset();
    ROS_WARN("GNSS pairing reset after ROS clock rollback");
  }
  gnss_pair_clock_ = clock;
  for (const auto &ready : gnss_pairer_->drain(gnssReceiveTime())) {
    const double process_start = gnss_pair_diagnostic_en_ ? gnssReceiveTime() : 0.;
    processGnssFix(ready.fix, ready.matched ? &ready.quality : nullptr);
    if (gnss_pair_diagnostic_en_ && fout_gnss_pair_diagnostic_) {
      const double process_end = gnssReceiveTime();
      fout_gnss_pair_diagnostic_ << std::fixed << std::setprecision(9)
          << ready.stamp << ',' << (ready.matched ? "matched" : "timeout")
          << ',' << ready.fix_arrival << ',' << ready.quality_arrival << ',' << ready.drain_time
          << ',' << process_start << ',' << process_end
          << ',' << ready.pending_fixes << ',' << ready.pending_quality << '\n' << std::flush;
    }
  }
  const auto &c = gnss_pairer_->counters();
  ROS_INFO_THROTTLE(5.0, "GNSS pairing matched=%lu timeout=%lu late_quality=%lu "
      "duplicate=%lu overflow=%lu out_of_order=%lu expired_quality=%lu pending=%zu resets=%lu",
      c.matched,c.timeout,c.late_quality,c.duplicate,c.overflow,c.out_of_order,
      c.expired_quality,gnss_pairer_->pending(),c.resets);
}

void LIVMapper::processGnssFix(const sensor_msgs::NavSatFix::ConstPtr &msg,
                              const fast_livo::GnssQualityRecord *quality)
{
  mtx_buffer.lock();

  GnssMeasureGroup gnss_meas;
  // R3-WP10a: GNSS time offset, same convention as the IMU offset (the stamp is
  // reduced by it). Default 0.0, so this is a no-op unless a config sets it.
  gnss_meas.timestamp = msg->header.stamp.toSec() - gnss_time_offset;
  gnss_meas.lat = msg->latitude;
  gnss_meas.lon = msg->longitude;
  gnss_meas.alt = msg->altitude;
  gnss_meas.fix_status = msg->status.status;

  // Pairing uses the raw stamp before applying gnss_time_offset above.
  if (quality)
  {
      const auto &q = *quality;
      gnss_meas.quality.valid = q.valid;
      gnss_meas.quality.nsat = static_cast<int>(q.num_sv);
      gnss_meas.quality.pdop = q.p_dop;
      gnss_meas.quality.h_acc_mm = q.h_acc_mm;
      gnss_meas.quality.v_acc_mm = q.v_acc_mm;
      gnss_meas.quality.carr_soln = static_cast<int>(q.carr_soln);
      gnss_meas.quality.fix_type = static_cast<int>(q.fix_type);
      gnss_meas.quality.has_p_dop = q.has_p_dop;
      gnss_meas.quality.has_h_acc = q.has_h_acc;
      gnss_meas.quality.has_v_acc = q.has_v_acc;
      gnss_meas.quality.source = q.source;
  }

  // Check if fix is valid
  if (!p_gnss->isFixValid(gnss_meas.fix_status))
  {
    sig_buffer.notify_all();
    mtx_buffer.unlock();
    return;
  }

  // Set origin on first good fix
  if (!gnss_origin_set && p_gnss->isFixGoodEnoughForInit(gnss_meas.fix_status))
  {
    p_gnss->setOrigin(gnss_meas.lat, gnss_meas.lon, gnss_meas.alt);
    gnss_origin_set = true;
    gnss_origin_lat_ = gnss_meas.lat;
    gnss_origin_lon_ = gnss_meas.lon;
    gnss_origin_alt_ = gnss_meas.alt;
    if (rtk_tight_en)
      rtk_tight_.setOrigin(gnss_meas.lat, gnss_meas.lon, gnss_meas.alt);
    std::cout << "[GNSS] Origin set: lat=" << gnss_meas.lat
              << ", lon=" << gnss_meas.lon
              << ", alt=" << gnss_meas.alt << std::endl;
  }

  // Convert to ENU if origin is set
  if (gnss_origin_set)
  {
    p_gnss->wgs84ToEnu(gnss_meas.lat, gnss_meas.lon, gnss_meas.alt,
                       gnss_meas.pos_e, gnss_meas.pos_n, gnss_meas.pos_u);

    // Prefer the covariance reported by the RTK engine when it is meaningful
    // (campus-01 bag carries real per-epoch covariance, 0.02 .. 380 m; the
    // campus-02 bag only has defaults). Fall back to the fix-type table.
    const double cxx = msg->position_covariance[0];
    const double cyy = msg->position_covariance[4];
    const double czz = msg->position_covariance[8];
    // Trust the reported covariance only when its std is meaningful (>= 30 cm).
    // The campus-02 bag carries cm-level values (std ~2-5 cm) that contradict
    // the measured ~1.5 m horizontal error vs the reference; trusting them
    // makes the chi-square gate reject every update (fusion silently degrades
    // to pure LIVO). Below the floor we fall back to the calibrated table.
    const double cmin = 0.3 * 0.3, cmax = 1e4;   // std in [0.3 m, 100 m]
    // WP8b: decide the two channels independently. Requiring all three entries
    // to be meaningful meant a single bad vertical value also discarded a good
    // horizontal covariance (and vice versa), pushing the other channel onto the
    // fix-type table for no reason. Checked against the bags actually used by the
    // A/B (campus01_rtk1hz: 910/910 epochs all-three-valid; gnss_c02_trim and
    // campus02_rtk1hz: 0/927 valid) - no epoch has a mixed verdict, so this is
    // numerically identical to the previous all-three test on those streams.
    const bool ovr = p_gnss->hasSigmaOverride();
    bool cov_h_ok = !ovr && (cxx > cmin && cxx < cmax) && (cyy > cmin && cyy < cmax);
    bool cov_v_ok = !ovr && (czz > cmin && czz < cmax);

    // R3-WP10a: sanity check between the reported covariance and the fix status.
    // Off by default. It only fires when the existing cov_ok logic has ALREADY
    // decided the reported covariance is untrustworthy and fallen back to the table
    // - i.e. it makes an existing silent fallback visible instead of adding a second,
    // independent judgement. Acting on it (warn_only = false) means trusting a
    // covariance that cov_ok just rejected; on campus-02 that is every Float epoch
    // (the bag writes cm-level covariance for all epochs), and trusting it is exactly
    // what makes the gate reject everything (EVAL_PROTOCOL 6.3b). Hence warn-only.
    if (gnss_status_sanity_check && !ovr && !(cov_h_ok && cov_v_ok) &&
        gnss_meas.fix_status >= GNSS_PHASE_FLOAT)
    {
      if (!gnss_status_sanity_warn_only)
      {
        ROS_WARN("[GNSS] status sanity: fix_status=%d but the reported covariance "
                 "(%.4g %.4g %.4g) was judged unusable; TRUSTING it anyway because "
                 "gnss/status_sanity_warn_only is false. This is the campus-02 "
                 "failure mode (see EVAL_PROTOCOL 6.3b).",
                 gnss_meas.fix_status, cxx, cyy, czz);
        cov_h_ok = true;
        cov_v_ok = true;
      }
      else if (!gnss_status_sanity_warned_)
      {
        gnss_status_sanity_warned_ = true;
        ROS_WARN("[GNSS] status sanity: fix_status=%d but the reported covariance "
                 "(%.4g %.4g %.4g) is outside the trusted range - falling back to the "
                 "fix-type table (this warning is printed once; "
                 "gnss/status_sanity_warn_only is true so behaviour is unchanged).",
                 gnss_meas.fix_status, cxx, cyy, czz);
      }
    }

    // A yaml-calibrated override wins over both the reported covariance and
    // the fix-type table: campus-01 reports cm-level covariances that
    // contradict the ~7 m error measured against the reference.
    gnss_meas.pos_cov_h = cov_h_ok ? sqrt(0.5 * (cxx + cyy))   // mean horizontal std
                                   : p_gnss->getHorizontalCov(gnss_meas.fix_status);
    gnss_meas.pos_cov_v = cov_v_ok ? sqrt(czz)
                                   : p_gnss->getVerticalCov(gnss_meas.fix_status);
    gnss_meas.valid = true;

    // P5b: raw ENU fix for the separate online_graph_node.
    // P0: carry the per-epoch quality record and the ENU origin. The graph
    // uses sigma_h/v directly, gates Fixed/Float/NSat/PDOP, and needs the
    // origin to evaluate the TDDD geometry in its own ENU frame.
    if (online_graph_en_ && pubOnlineGraphFix)
    {
      fast_livo::OnlineGraphFix msg;
      msg.header.stamp = ros::Time().fromSec(gnss_meas.timestamp);
      msg.header.frame_id = "enu";
      msg.point.x = gnss_meas.pos_e;
      msg.point.y = gnss_meas.pos_n;
      msg.point.z = gnss_meas.pos_u;
      std::fill(msg.position_covariance.begin(), msg.position_covariance.end(), 0.0);
      const double sig_h = gnss_meas.pos_cov_h > 0.0 ? gnss_meas.pos_cov_h : 0.0;
      const double sig_v = gnss_meas.pos_cov_v > 0.0 ? gnss_meas.pos_cov_v : 0.0;
      msg.position_covariance[0] = sig_h * sig_h;
      msg.position_covariance[4] = sig_h * sig_h;
      msg.position_covariance[8] = sig_v * sig_v;
      msg.status = static_cast<uint8_t>(gnss_meas.fix_status < 0 ? 0
                                                                 : gnss_meas.fix_status);
      // A2.1: real quality from the PVT relay, when present. Without it the
      // fields stay at their unknown defaults (0 / has_* false), exactly as
      // before; nothing here feeds the filter or changes a weight yet.
      const auto &q = gnss_meas.quality;
      msg.nsat = static_cast<uint8_t>(std::min(255, std::max(0, q.nsat)));
      msg.pdop = q.has_p_dop ? static_cast<float>(q.pdop) : 0.0f;
      msg.sigma0 = 0.0f;
      msg.rms_xyz = 0.0f;
      msg.h_acc_mm = q.h_acc_mm;
      msg.v_acc_mm = q.v_acc_mm;
      msg.carr_soln = static_cast<uint8_t>(q.carr_soln);
      msg.fix_type = static_cast<uint8_t>(q.fix_type);
      msg.quality_valid = q.valid;
      msg.has_h_acc = q.has_h_acc;
      msg.has_v_acc = q.has_v_acc;
      msg.has_p_dop = q.has_p_dop;
      msg.quality_source = q.source;
      msg.lat0 = gnss_origin_lat_;
      msg.lon0 = gnss_origin_lon_;
      msg.alt0 = gnss_origin_alt_;
      pubOnlineGraphFix.publish(msg);
    }

    // R4-1 (A3-1b): track the GNSS displacement that decides the static-hold
    // veto. Runs on every accepted fix, needs no yaw and no alignment, so it
    // works while the fusion itself is withheld (campus-02). See LIVMapper.h.
    if (zupt_hold_veto_gnss_en_ && !gnss_hold_veto_done_)
    {
      const V3D enu_now(gnss_meas.pos_e, gnss_meas.pos_n, gnss_meas.pos_u);
      gnss_hold_veto_last_fix_t_ = gnss_meas.timestamp;
      if (!gnss_hold_ref_set_)
      {
        gnss_hold_ref_enu_ = enu_now;
        gnss_hold_ref_t_ = gnss_meas.timestamp;
        gnss_hold_ref_set_ = true;
        gnss_hold_disp_ = 0.0;
        printf("[ZUPT] hold veto armed: GNSS reference fix at t=%.2f s\n",
               gnss_meas.timestamp);
      }
      else
      {
        gnss_hold_disp_ = (enu_now - gnss_hold_ref_enu_).head<2>().norm();
        if (gnss_hold_disp_ >= zupt_hold_veto_thresh_)
        {
          gnss_hold_veto_done_ = true; // latched: real motion seen, never hold again
          printf("[ZUPT] hold veto RELEASED by GNSS motion: disp=%.2f m >= %.2f m "
                 "at t=%.2f s (fix dt from ref %.1f s)\n",
                 gnss_hold_disp_, zupt_hold_veto_thresh_, gnss_meas.timestamp,
                 gnss_meas.timestamp - gnss_hold_ref_t_);
        }
      }
    }

    gnss_buffer.push_back(gnss_meas);

    // Limit buffer size
    while (gnss_buffer.size() > 100) {
      gnss_buffer.pop_front();
    }
  }

  sig_buffer.notify_all();
  mtx_buffer.unlock();
}

// R3 stage 4 (L2): doppler velocity epoch. Kept in ECEF exactly as received; the
// rotation into this node's local ENU frame happens when the epoch is matched to
// a fix (handleGNSS), using the same origin convention as the positions.
void LIVMapper::gnss_vel_cbk(const geometry_msgs::TwistWithCovarianceStamped::ConstPtr &msg)
{
  GnssVelGroup vg;
  vg.timestamp = msg->header.stamp.toSec() - gnss_vel_time_offset;
  vg.vel_ecef = V3D(msg->twist.twist.linear.x, msg->twist.twist.linear.y,
                    msg->twist.twist.linear.z);
  // the receiver's formal V-RMS, kept for the record only (see the header note)
  vg.cov_h = sqrt(0.5 * (msg->twist.covariance[0] + msg->twist.covariance[7]));
  vg.cov_v = sqrt(std::max(0.0, msg->twist.covariance[14]));

  // R4.3: A-main consumes the Doppler epoch in the global graph. Publish it at
  // its own timestamp, not attached to a fix, so the graph can interpolate the
  // two surrounding velocity nodes.
  {
    static int vel_print = 0;
    if (vel_print < 3)
    {
      printf("[GNSS] vel rx t=%.2f online=%d pub=%d subs=%d origin=%d\n",
             vg.timestamp, (int)online_graph_en_, (int)(bool)pubOnlineGraphVel,
             pubOnlineGraphVel.getNumSubscribers(), (int)gnss_origin_set);
      fflush(stdout);
      vel_print++;
    }
  }
  if (online_graph_en_ && pubOnlineGraphVel && gnss_origin_set)
  {
    double ve = 0.0, vn = 0.0, vu = 0.0;
    p_gnss->ecefToEnuVector(vg.vel_ecef(0), vg.vel_ecef(1), vg.vel_ecef(2),
                            ve, vn, vu);
    // The GREAT .flt velocity is the INS/IMU velocity (body origin), not the
    // antenna velocity; do not subtract R*(omega x lever). The earlier lever
    // subtraction raised the Doppler residual from 0.018 to 0.074 m/s.
    const fast_livo::OnlineGraphVel out =
        fast_livo::makeOnlineGraphVelMsg(
            msg->header.stamp.toSec(), gnss_vel_time_offset,
            Eigen::Vector3d(ve, vn, vu), vg.cov_h, vg.cov_v, "ins");
    pubOnlineGraphVel.publish(out);
  }

  mtx_buffer.lock();
  gnss_vel_buffer.push_back(vg);
  while (gnss_vel_buffer.size() > 200) gnss_vel_buffer.pop_front();
  mtx_buffer.unlock();

  sig_buffer.notify_all();
}

void LIVMapper::rtk_cbk(const fast_livo::RtkDD::ConstPtr &msg)
{
  static int rtk_rx_print = 0;
  if (rtk_rx_print < 3)
  {
    printf("[RTK] rx t=%.2f n=%u\n", msg->header.stamp.toSec(), (unsigned)msg->n);
    fflush(stdout);
    rtk_rx_print++;
  }
  mtx_buffer.lock();
  fast_livo::RtkDD adjusted = *msg;
  if (rtk_time_offset != 0.0)
    adjusted.header.stamp =
        ros::Time().fromSec(msg->header.stamp.toSec() - rtk_time_offset);
  rtk_buffer_.push_back(adjusted);
  while (rtk_buffer_.size() > 400) rtk_buffer_.pop_front();
  mtx_buffer.unlock();
  sig_buffer.notify_all();
}

void LIVMapper::clampAuxState()
{
  if (!gnss_state_scale_en)
  {
    _state.scale_h = 1.0;
    return;
  }
  const double lo = 0.85, hi = 1.15;
  if (_state.scale_h > hi) _state.scale_h = hi;
  if (_state.scale_h < lo) _state.scale_h = lo;
}

void LIVMapper::handleRTK()
{
  {
    static double last_print = -1.0;
    const double now = ros::Time::now().toSec();
    if (now - last_print > 5.0)
    {
      printf("[RTK] handle lio=%.2f aligned=%d ekf=%d buf=%zu time_rej=%d\n",
             LidarMeasures.last_lio_update_time, (int)gnss_yaw_aligned,
             (int)ekf_finish_once, rtk_buffer_.size(), rtk_time_reject_count);
      fflush(stdout);
      last_print = now;
    }
  }
  if (!rtk_tight_en || !gnss_yaw_aligned) return;
  // ekf_finish_once is only set when uav/imu_rate_odom is true, which is not
  // the case in the GREAT configs. The GNSS path uses the same guard below.
  if (LidarMeasures.last_lio_update_time < 0) return;

  // P3: if the DD stream stops, tell the supervisor to drop to LIVO-only.
  // Rate-limited to 1 Hz so the 5 kHz main loop does not spam the EMA/log.
  if (fusion_sup_cfg_.en)
  {
    const RtkTight::Health &h = rtk_tight_.health();
    const double now = LidarMeasures.last_lio_update_time;
    if (h.t > 0.0 && now - h.t > fusion_sup_cfg_.rtk_timeout_s &&
        (last_rtk_timeout_t_ < 0.0 || now - last_rtk_timeout_t_ >= 1.0))
    {
      FusionSupervisorInput in;
      in.rtk_available = true;
      in.gnss_valid = gnss_origin_set;
      in.n_pairs = 0;
      in.n_fixed = 0;
      in.fixed_streak_s = 0.0;
      in.t = now;
      in.livo = livo_health_;
      fusion_sup_.update(in);
      last_rtk_timeout_t_ = now;
    }
  }

  while (true)
  {
    fast_livo::RtkDD msg;
    bool has = false;
    {
      mtx_buffer.lock();
      if (!rtk_buffer_.empty())
      {
        const double t = rtk_buffer_.front().header.stamp.toSec();
        // The alignment lock can happen tens of seconds after the first RTK
        // epoch (it needs a real 50 m span). Drop messages that are older than
        // the current LIO state instead of updating with a stale position.
        if (t < LidarMeasures.last_lio_update_time - 1.0)
        {
          rtk_buffer_.pop_front();
          mtx_buffer.unlock();
          continue;
        }
        if (t <= LidarMeasures.last_lio_update_time + 0.5)
        {
          msg = rtk_buffer_.front();
          rtk_buffer_.pop_front();
          has = true;
        }
      }
      mtx_buffer.unlock();
    }
    if (!has)
    {
      static int rtk_wait_print = 0;
      if (rtk_wait_print < 10 && !rtk_buffer_.empty())
      {
        printf("[RTK] wait front=%.2f lio=%.2f buf=%zu aligned=%d ekf=%d\n",
               rtk_buffer_.front().header.stamp.toSec(),
               LidarMeasures.last_lio_update_time, rtk_buffer_.size(),
               (int)gnss_yaw_aligned, (int)ekf_finish_once);
        fflush(stdout);
        rtk_wait_print++;
      }
      break;
    }
    static int rtk_proc_print = 0;
    if (rtk_proc_print < 3)
    {
      printf("[RTK] proc t=%.2f lio=%.2f\n", msg.header.stamp.toSec(),
             LidarMeasures.last_lio_update_time);
      fflush(stdout);
      rtk_proc_print++;
    }
    updateStateWithRTK(msg);
    if (fusion_sup_cfg_.en)
    {
      FusionSupervisorInput in;
      in.rtk_available = true;
      in.gnss_valid = gnss_origin_set;
      in.fix_status = 5;
      const RtkTight::Health &h = rtk_tight_.health();
      in.n_pairs = h.n_pairs;
      in.n_fixed = h.n_fixed;
      in.fixed_streak_s = h.fixed_streak_s;
      in.ratio = h.ratio;
      in.gamma = h.gamma;
      in.gate = h.gate;
      in.rtk_accepted = h.accepted;
      in.t = h.t;
      in.livo = livo_health_;
      fusion_sup_.update(in);
    }
  }
}

bool LIVMapper::updateStateWithRTK(const fast_livo::RtkDD &msg)
{
  {
    static int u = 0;
    if (u < 5)
    {
      printf("[RTK] updateState origin=%d t=%.2f\n",
             (int)rtk_tight_.originSet(), msg.header.stamp.toSec());
      fflush(stdout);
      u++;
    }
  }
  if (!rtk_tight_.originSet()) return false;

  // P2 supervisor: the previous epoch decides the mode/weight. REJECT means
  // LIVO-only; FLOAT disables the externally fixed phase but keeps float DD.
  if (fusion_sup_cfg_.en && fusion_sup_.updates() > 0)
  {
    const FusionSupervisorOutput &o = fusion_sup_.output();
    // Keep a tiny non-zero weight in REJECT mode so RtkTight still refreshes
    // its health/streak and the supervisor can recover. w=1e-3 doubles R by
    // 1000, making the correction negligible.
    rtk_tight_.setExternalWeight(std::max(o.w_rtk, 1e-3));
    rtk_tight_.setUseFixedPhase(o.mode == FusionMode::FIXED && o.w_rtk > 1e-3);
  }

  const double t = msg.header.stamp.toSec();
  // R1 (P0-1): the correction below is applied to _state, whose reference time
  // is LidarMeasures.last_lio_update_time. Without history/replay an observation
  // outside this window would be compared against (and applied to) the wrong
  // state, so reject it and count it. R2b replaces this with a proper delayed-
  // observation path.
  if (rtk_time_sync_tol > 0.0)
  {
    const double t_lio = LidarMeasures.last_lio_update_time;
    const double dt_sync = t - t_lio;
    if (std::fabs(dt_sync) > rtk_time_sync_tol)
    {
      ++rtk_time_reject_count;
      if (rtk_time_reject_count <= 5 || rtk_time_reject_count % 100 == 0)
      {
        printf("[RTK] time reject t=%.3f lio=%.3f dt=%+.3f tol=%.3f count=%d\n",
               t, t_lio, dt_sync, rtk_time_sync_tol, rtk_time_reject_count);
        fflush(stdout);
      }
      return false;
    }
  }
  StatesGroup state_prop = _state;
  propagateStateToTime(t, state_prop);

  Eigen::Matrix<double, DIM_STATE, 1> dx;
  Eigen::Matrix<double, DIM_STATE, DIM_STATE> P_new;
  const bool ok = rtk_tight_.update(msg, state_prop, enu_R_world, enu_t_world,
                                    gnss_extT, dx, P_new);

  // The one-time fixed-phase frame translation is applied to the ENU->world
  // mapping, not to the ESKF state. Skip this epoch's state update; the next
  // DD epoch sees the corrected frame.
  V3D frame_offset_enu;
  if (rtk_tight_.consumeFrameOffset(frame_offset_enu))
  {
    const V3D frame_offset_world = enu_R_world * frame_offset_enu;
    enu_t_world -= frame_offset_world;
    printf("[RTK] frame translation applied: dENU=(%.2f %.2f %.2f) |d|=%.2f m\n",
           frame_offset_enu(0), frame_offset_enu(1), frame_offset_enu(2),
           frame_offset_enu.norm());
    fflush(stdout);
    return false;
  }
  if (!ok) return false;

  // Same invariant as updateStateWithGNSS: apply the correction to the CURRENT
  // state, not to state_prop (state_prop has already been propagated to the RTK
  // epoch; assigning it back would integrate that interval twice).
  _state += dx;
  _state.cov = P_new;
  _state.cov = 0.5 * (_state.cov + _state.cov.transpose());
  clampAuxState();
  if (gnss_state_scale_en)
  {
    static int scale_log_count = 0;
    if (++scale_log_count % 10 == 0)
    {
      printf("[SCALE] t=%.2f s=%.4f\n", t, _state.scale_h);
      fflush(stdout);
    }
  }
  // Mirror the position-domain path: the IMU propagation thread must see the
  // RTK correction as the new base state.
  if (imu_prop_enable)
  {
    latest_ekf_state = _state;
    // _state is the LIO-epoch state (the correction was applied to it, not to
    // state_prop). Stamping it with the RTK time made the IMU output thread
    // discard [t_lio, t_rtk] as if it had already been integrated.
    latest_ekf_time = LidarMeasures.last_lio_update_time;
    state_update_flg = true;
  }
  return true;
}

void LIVMapper::handleGNSS()
{
  if (!gnss_origin_set || gnss_buffer.empty()) {
    return;
  }

  mtx_buffer.lock();
  if (gnss_buffer.empty()) {
    mtx_buffer.unlock();
    return;
  }

  GnssMeasureGroup gnss_meas = gnss_buffer.front();
  gnss_buffer.pop_front();

  // R3 stage 4 (L2): attach the doppler velocity epoch belonging to this fix.
  // The two arrive as different messages on different topics, so they are matched
  // by timestamp; the tolerance is small because rtk_flt_to_bag.py stamps both
  // from the SAME .flt epoch. Note the fix is consumed here, at the next LIO
  // frame, which is later than its arrival in gnss_cbk - so the velocity does not
  // have to precede the fix in the bag, it only has to arrive before this point.
  if (gnss_use_velocity && !gnss_vel_buffer.empty())
  {
    int best = -1;
    double best_dt = gnss_vel_max_dt;
    for (size_t k = 0; k < gnss_vel_buffer.size(); k++)
    {
      const double d = fabs(gnss_vel_buffer[k].timestamp - gnss_meas.timestamp);
      if (d <= best_dt) { best_dt = d; best = (int)k; }
    }
    if (best >= 0)
    {
      const GnssVelGroup vg = gnss_vel_buffer[best];
      gnss_meas.vel_ecef = vg.vel_ecef;
      gnss_meas.vel_cov_h = vg.cov_h;
      gnss_meas.vel_cov_v = vg.cov_v;
      // The receiver's velocity is the ANTENNA's; the model in
      // updateStateWithGNSS accounts for the lever arm. Only epochs at or above
      // gnss/vel_min_status are used: measured on campus-01, Float epochs are
      // ~10x worse than Fixed while reporting a small formal sigma.
      gnss_meas.has_vel = (gnss_meas.fix_status >= gnss_vel_min_status);
      double ve = 0.0, vn = 0.0, vu = 0.0;
      p_gnss->ecefToEnuVector(vg.vel_ecef(0), vg.vel_ecef(1), vg.vel_ecef(2), ve, vn, vu);
      gnss_meas.vel_enu = V3D(ve, vn, vu);
      gnss_vel_matched_count++;
    }
    // drop epochs that can no longer match anything
    while (!gnss_vel_buffer.empty() &&
           gnss_vel_buffer.front().timestamp < gnss_meas.timestamp - 1.0)
      gnss_vel_buffer.pop_front();
  }
  mtx_buffer.unlock();

  if (!gnss_meas.valid) {
    return;
  }

  // Skip if system not initialized yet
  if (!ekf_finish_once && LidarMeasures.last_lio_update_time < 0) {
    return;
  }

  // Try yaw alignment if not yet aligned
  if (!gnss_yaw_aligned)
  {
    if (tryAlignGnssYaw(gnss_meas))
    {
      gnss_yaw_aligned = true;
    }
    // Don't do EKF update until yaw is aligned
    return;
  }

  // E4: periodic refit of the locked ENU<->world transform. The one-shot lock
  // fits the frame from the startup window only; on long sequences LIVO drift
  // makes that mapping progressively stale and absolute updates start
  // dragging the state. With gnss/refit_interval_dist > 0 the pair buffer
  // keeps collecting after the lock and the 2D Procrustes fit is re-run every
  // refit_interval_dist metres of GNSS travel, replacing enu_R_world /
  // enu_t_world in place when the same residual gate and a yaw-continuity
  // bound pass. 0 (default) preserves the one-shot lock.
  if (gnss_refit_interval_dist > 0.0)
  {
    const V3D p_enu(gnss_meas.pos_e, gnss_meas.pos_n, gnss_meas.pos_u);
    if (refit_has_last_)
      refit_travel_ += (p_enu - refit_last_enu_).head<2>().norm();
    refit_last_enu_ = p_enu;
    refit_has_last_ = true;
    align_enu_hist_.push_back(p_enu);
    align_world_hist_.push_back(_state.pos_end);
    while (align_enu_hist_.size() > 1000)
    {
      align_enu_hist_.pop_front();
      align_world_hist_.pop_front();
    }
    if (refit_travel_ >= gnss_refit_interval_dist)
    {
      refit_travel_ = 0.0;
      refitEnuWorld();
    }
  }

  // Phase 2: the NavSatFix stream is used for ENU<->world alignment only when
  // position updates are disabled; the RTK DD path does the actual update.
  if (!gnss_position_update_en)
    return;

  // Perform EKF update
  bool success = updateStateWithGNSS(gnss_meas);

  // P2: position-domain mode (no RTK DD stream). The RTK path updates the
  // supervisor itself when rtk_tight_en is on.
  if (fusion_sup_cfg_.en && !rtk_tight_en)
  {
    FusionSupervisorInput in;
    in.rtk_available = false;
    in.gnss_valid = gnss_meas.valid;
    in.fix_status = gnss_meas.fix_status;
    in.t = gnss_meas.timestamp;
    in.livo = livo_health_;
    fusion_sup_.update(in);
  }

  if (success)
  {
    gnss_update_count++;
    last_valid_gnss_ = gnss_meas; // Improvement 2: latest fix for the factor-graph backend

    // Note: do NOT overwrite LidarMeasures.last_lio_update_time here.
    // It is the LIO data-cut / deskew time base, updated per LIO frame in
    // sync_packages. Overwriting it with the GNSS epoch would corrupt the
    // evo output timestamps and the Data Cut window. GNSS propagation
    // (propagateStateToTime) uses it as the propagation start, which is
    // correct as long as it reflects the latest LIO update.

    // Update imu propagate state
    if (imu_prop_enable)
    {
      latest_ekf_state = _state;
      // _state is the LIO-epoch state; the update was applied there, not at the
      // (possibly earlier) GNSS epoch. Using the GNSS stamp here made the IMU
      // thread skip the interval that _state had already integrated.
      latest_ekf_time = LidarMeasures.last_lio_update_time;
      state_update_flg = true;
    }

    // Log GNSS position
    if (pose_output_en && fout_gnss_pos.is_open())
    {
      fout_gnss_pos << std::setw(20) << gnss_meas.timestamp - _first_lidar_time
                    << " " << gnss_meas.pos_e
                    << " " << gnss_meas.pos_n
                    << " " << gnss_meas.pos_u
                    << " " << _state.pos_end.transpose()
                    << std::endl;
    }
  }
}

bool LIVMapper::tryAlignGnssYaw(const GnssMeasureGroup &gnss_meas)
{
  // GNSS position in ENU (U up). The LIO world is also z-up: the IMU
  // initialisation solves gravity as (0,0,-g), so the previous "-U to match a
  // z-down world" comment was wrong and flipped the vertical observation sign.
  const V3D p_enu(gnss_meas.pos_e, gnss_meas.pos_n, gnss_meas.pos_u);

  // Accumulate paired (GNSS ENU, LIO world) samples and FIT the map between the
  // two frames instead of assuming it.
  //
  // The old code took the yaw from the displacement between two single epochs
  // (alignment start and the epoch where |d| >= yaw_align_min_dist). That is
  // unreliable when the LIO displacement over that short baseline is itself
  // degraded (campus-02: the LIO loses ~21 m in the first seconds of motion),
  // and it silently assumed the two frame ORIGINS coincide - they do not in
  // general (the GNSS ENU origin is the first fix, the LIO world origin is the
  // first LiDAR frame). A least-squares fit over all accumulated pairs is
  // insensitive to any single bad epoch and yields rotation AND translation.
  //
  // R4-2b (EVAL_PROTOCOL 17.2): the internal pose carries the ~0.3 m/s static
  // walk that the report-level hold exists to hide - a 50 s window of it
  // stretches ~15 m and is exactly the 5-8 m "fit residual" that withheld the
  // alignment forever on c02/c03. Sampling the REPORTED pose (internal plus
  // the current hold offset) removes the walk from the fit; offline replay on
  // the archived reported trajectories puts the residual median at 0.22-0.27 m
  // on both datasets. Default off = the historical internal-pose sampling.
  align_enu_hist_.push_back(p_enu);
  align_world_hist_.push_back(align_use_report_pos_ ? (_state.pos_end + report_offset_)
                                                    : _state.pos_end);
  // E4: with the refit enabled the buffer doubles as the refit sample
  // window; a longer window keeps the span check satisfiable at ground-robot
  // speeds (500 epochs = 50 s ≈ 35 m at 0.7 m/s).
  const size_t align_hist_cap = (gnss_refit_interval_dist > 0.0) ? 1000 : 500;
  while (align_enu_hist_.size() > align_hist_cap)
  {
    align_enu_hist_.pop_front();
    align_world_hist_.pop_front();
  }

  const int n = (int)align_enu_hist_.size();
  if (n < gnss_align_min_samples) return false;

  // Frame means (3D; the U component is negated above so this is consistent)
  V3D mean_enu = V3D::Zero(), mean_world = V3D::Zero();
  for (int i = 0; i < n; i++)
  {
    mean_enu += align_enu_hist_[i];
    mean_world += align_world_hist_[i];
  }
  mean_enu /= (double)n;
  mean_world /= (double)n;

  // Need a real baseline before a fitted yaw means anything. Span is measured
  // on the GNSS stream (independent of any LIO problem).
  double span_gnss = 0.0, span_lio = 0.0;
  for (int i = 0; i < n; i++)
  {
    const double dg = (align_enu_hist_[i] - mean_enu).head<2>().norm();
    const double dl = (align_world_hist_[i] - mean_world).head<2>().norm();
    if (dg > span_gnss) span_gnss = dg;
    if (dl > span_lio) span_lio = dl;
  }
  if (span_gnss < gnss_yaw_align_min_dist || span_lio < 2.0) return false;

  // Procrustes fit with one robust refit pass. The first fit uses every pair;
  // pairs whose horizontal residual exceeds align_drop_scale * median are then
  // dropped and the fit repeated, so one degraded epoch (a fix jump, an LIO
  // loss) cannot drag the yaw.
  std::vector<char> keep(n, 1);
  std::vector<double> resid_all;
  double yaw_offset = 0.0, fit_resid = 0.0;
  V3D fit_t = V3D::Zero();
  if (!fitEnuWorld2D(align_enu_hist_, align_world_hist_, keep, yaw_offset, fit_t,
                     fit_resid, resid_all))
    return false;

  int dropped = 0;
  {
    std::vector<double> kept(resid_all.begin(), resid_all.end());
    std::nth_element(kept.begin(), kept.begin() + kept.size() / 2, kept.end());
    const double med = kept[kept.size() / 2];
    const double thr = std::max(gnss_align_drop_scale * med, 1.0);
    for (int i = 0; i < n; i++)
      if (keep[i] && resid_all[i] > thr) { keep[i] = 0; dropped++; }
  }
  if (dropped > 0 &&
      !fitEnuWorld2D(align_enu_hist_, align_world_hist_, keep, yaw_offset, fit_t,
                     fit_resid, resid_all))
    return false;
  align_dropped_last_ = dropped;

  // ---- P1-4: relative-displacement alignment -----------------------------
  // The absolute fit above minimizes position residuals, so slow LIO drift is
  // folded into the translation. A relative fit on consecutive GNSS/LIO
  // displacement vectors is translation-free: it estimates yaw (and scale)
  // from short baselines, then the translation is recovered as the median of
  // the absolute pairs. `gnss/align_relative_en` forces it; otherwise it is
  // selected automatically when the absolute fit residual exceeds the gate
  // while the relative fit is inside it. That is the c02 case: the LIO scale
  // error biases the absolute yaw, but short-baseline displacements still fit
  // at ~1.5 m. No per-sequence threshold is involved.
  bool used_relative = false;
  bool have_relative = false;
  // rel_resid_saved starts at +inf so that an unset relative solution can
  // never pass a gate by comparing as 0.0 (rerun5 finding: the unset zero made
  // auto_relative fire and lock the identity transform, yaw=0, t=0).
  double rel_yaw = 0.0, rel_resid_saved = INFINITY;
  V3D rel_t = V3D::Zero();
  {
    std::vector<Eigen::Vector2d> dl, dg;
    dl.reserve(n);
    dg.reserve(n);
    for (int i = 1; i < n; i++)
    {
      const Eigen::Vector2d dgv(align_enu_hist_[i](0) - align_enu_hist_[i - 1](0),
                                align_enu_hist_[i](1) - align_enu_hist_[i - 1](1));
      const Eigen::Vector2d dlv(align_world_hist_[i](0) - align_world_hist_[i - 1](0),
                                align_world_hist_[i](1) - align_world_hist_[i - 1](1));
      if (dgv.norm() >= gnss_align_rel_min_disp)
      {
        dg.push_back(dgv);
        dl.push_back(dlv);
      }
    }
    if ((int)dl.size() >= 3)
    {
      Eigen::Matrix2d H = Eigen::Matrix2d::Zero();
      double var = 0.0;
      for (size_t i = 0; i < dl.size(); i++)
      {
        H += dl[i] * dg[i].transpose();
        var += dl[i].squaredNorm();
      }
      Eigen::JacobiSVD<Eigen::Matrix2d> svd(H, Eigen::ComputeFullU | Eigen::ComputeFullV);
      const Eigen::Matrix2d U = svd.matrixU(), V = svd.matrixV();
      const Eigen::Vector2d S = svd.singularValues();
      const double d = (V.determinant() * U.determinant() < 0.0) ? -1.0 : 1.0;
      const Eigen::Matrix2d R2 = V * Eigen::Vector2d(1.0, d).asDiagonal() * U.transpose();
      const double s = (var > 1e-9) ? (S(0) + S(1) * d) / var : 1.0;
      double rel_sq = 0.0;
      for (size_t i = 0; i < dl.size(); i++)
      {
        const Eigen::Vector2d e = s * R2 * dl[i] - dg[i];
        rel_sq += e.squaredNorm();
      }
      const double rel_resid = std::sqrt(rel_sq / dl.size());

      // R2 maps world displacements -> ENU displacements. The code's stored
      // transform maps ENU -> world, so use its transpose and recompute the
      // translation in that direction. (A direct copy of the world->ENU yaw
      // produced a sign-flipped transform and 230 m innovations in testing.)
      const Eigen::Matrix2d R_code = R2.transpose();
      const double yaw_code = std::atan2(R_code(1, 0), R_code(0, 0));
      std::vector<double> tx(n), ty(n);
      for (int i = 0; i < n; i++)
      {
        const Eigen::Vector2d w(align_world_hist_[i](0), align_world_hist_[i](1));
        const Eigen::Vector2d e(align_enu_hist_[i](0), align_enu_hist_[i](1));
        const Eigen::Vector2d t = w - R_code * e;
        tx[i] = t(0);
        ty[i] = t(1);
      }
      std::nth_element(tx.begin(), tx.begin() + n / 2, tx.end());
      std::nth_element(ty.begin(), ty.begin() + n / 2, ty.end());
      const Eigen::Vector2d t_med(tx[n / 2], ty[n / 2]);
      double abs_sq = 0.0;
      for (int i = 0; i < n; i++)
      {
        const Eigen::Vector2d w(align_world_hist_[i](0), align_world_hist_[i](1));
        const Eigen::Vector2d e(align_enu_hist_[i](0), align_enu_hist_[i](1));
        const Eigen::Vector2d d = R_code * e + t_med - w;
        abs_sq += d.squaredNorm();
      }
      const double abs_resid = std::sqrt(abs_sq / n);
      if (gnss_align_relative_en || (align_badfit_count_ % 5 == 0))
        printf("[GNSS] align-rel: pairs=%d yaw(ENU->world)=%.3f deg scale=%.5f "
               "rel_resid=%.3f m abs_resid(median t)=%.3f m\n",
               (int)dl.size(), yaw_code * 57.2957795, s, rel_resid, abs_resid);
      have_relative = true;
      rel_yaw = yaw_code;
      rel_t = V3D(t_med(0), t_med(1), 0.0);
      rel_resid_saved = rel_resid;
    }
  }

  // Score absolute and relative candidates against the buffered DD code before
  // locking. This is the direct fix for c02: the Procrustes yaw can be -16 deg
  // while the relative candidate is +5 deg, and only the DD code knows which
  // one puts the antenna in the right place. If neither candidate is inside the
  // gate, withhold the lock and wait for a better fit.
  bool dd_scored = false;
  if (have_relative && gnss_align_dd_score_en && rtk_tight_en &&
      !rtk_buffer_.empty())
  {
    const fast_livo::RtkDD &dd = rtk_buffer_.back();
    auto yawToR = [](double yaw) {
      M3D R;
      const double c = std::cos(yaw), s = std::sin(yaw);
      R << c, -s, 0, s, c, 0, 0, 0, 1;
      return R;
    };
    double score_abs = -1.0, score_rel = -1.0;
    const M3D R_abs = yawToR(yaw_offset);
    const M3D R_rel = yawToR(rel_yaw);
    const bool ok_abs = rtk_tight_.scoreAlignment(
        dd, _state, R_abs, fit_t, gnss_extT, score_abs);
    const bool ok_rel = rtk_tight_.scoreAlignment(
        dd, _state, R_rel, rel_t, gnss_extT, score_rel);
    if (ok_abs || ok_rel)
    {
      dd_scored = true;
      const bool choose_rel = ok_rel && (!ok_abs || score_rel < score_abs);
      const double chosen = choose_rel ? score_rel : score_abs;
      printf("[GNSS] align-dd: abs=%.2f m rel=%.2f m chosen=%s max=%.1f m\n",
             score_abs, score_rel, choose_rel ? "relative" : "absolute",
             gnss_align_dd_max_rms);
      if (chosen > gnss_align_dd_max_rms)
      {
        if (align_badfit_count_++ % 5 == 0)
          printf("[GNSS] alignment WITHHELD: DD code score %.2f m > %.1f m\n",
                 chosen, gnss_align_dd_max_rms);
        return false;
      }
      if (choose_rel)
      {
        yaw_offset = rel_yaw;
        fit_t = rel_t;
        fit_resid = rel_resid_saved;
        used_relative = true;
      }
      else
      {
        used_relative = false;
      }
    }
  }

  // Fallback when no DD message is buffered (position-domain modes or the very
  // first epochs): keep the old auto-relative rule.
  if (!dd_scored)
  {
    // The relative fallback must require a real relative solution: rel_yaw /
    // rel_t stay at identity when fewer than 3 displacement pairs were found,
    // and gnss_align_relative_en must not lock that identity either (rerun5
    // c02: "LOCKED FORCED, relative; yaw=0; translation=0; fit_resid=0").
    const bool auto_relative =
        (fit_resid > gnss_align_max_resid && rel_resid_saved <= gnss_align_max_resid);
    if (have_relative && (gnss_align_relative_en || auto_relative))
    {
      yaw_offset = rel_yaw;
      fit_t = rel_t;
      fit_resid = rel_resid_saved;
      used_relative = true;
    }
  }

  // Fit-quality gate: a large residual means LIO and GNSS disagree by metres
  // over the alignment window, so the fitted yaw is not trustworthy and must
  // not be used to gate/weight real updates. campus-02 hits this (8 m residual
  // over a 167 m span, i.e. the LIO's motion-onset degradation). Report it and
  // keep the fusion OFF rather than locking a bogus yaw.
  if (gnss_align_resid_gate && fit_resid > gnss_align_max_resid)
  {
    if (align_badfit_count_++ % 5 == 0)
      printf("[GNSS] alignment WITHHELD: fit residual %.2f m > %.2f m gate "
             "(samples=%d, GNSS span=%.1f m, LIO span=%.1f m) -> fusion OFF\n",
             fit_resid, gnss_align_max_resid, n, span_gnss, span_lio);
    return false;
  }

  // Freeze only once the fitted yaw stops moving. Locking on the first fit
  // whose span crosses a threshold made the result depend on which epochs
  // happened to lie in the degraded startup window (measured run-to-run spread
  // 3.1-8.7 deg on identical data). `align_force_dist` bounds the wait in case
  // the estimate never quite settles on a hard sequence.
  double dyaw = yaw_offset - align_yaw_prev_;
  dyaw = std::atan2(std::sin(dyaw), std::cos(dyaw));
  align_yaw_prev_ = yaw_offset;
  if (std::fabs(dyaw) * 57.2957795 < gnss_align_yaw_tol_deg) align_stable_count_++;
  else align_stable_count_ = 0;
  // T1-4: with the slow alignment state there is no need to force an early
  // lock - a wrong-but-early prior (c02 FORCED locks measured >20 deg apart
  // across runs, EVAL_PROTOCOL 23) is worse than a late lock the filter can
  // still converge from. The forced path stays for the disabled default.
  // P2-01 (EXP-P2-001): the forced path now requires its own stability floor
  // (gnss_align_forced_min_stable, include/yaw_accept_policy.h). campus-02
  // locked FORCED at stable_count == 1 with a 1.416 m local residual, 43.8
  // deg off the GNSS-implied heading (five-round audit) - a span crossing
  // alone is not trust. 0 keeps the historical predicate.
  const bool forced = yaw_accept::forcedLockAllowed(
      align_stable_count_, span_gnss, gnss_align_force_dist,
      gnss_align_state_en, gnss_align_forced_min_stable);
  if (align_stable_count_ < gnss_align_settle && !forced)
  {
    // P2-01 diagnostic: a span-crossed lock deferred by the stability floor.
    static unsigned forced_deferred_count = 0;
    if (!gnss_align_state_en && span_gnss >= gnss_align_force_dist &&
        gnss_align_forced_min_stable > 0 && forced_deferred_count++ % 10 == 0)
      printf("[GNSS] FORCED lock deferred: span %.1f m >= %.1f m but stable "
             "%d < %d (P2-01 floor)\n",
             span_gnss, gnss_align_force_dist, align_stable_count_,
             gnss_align_forced_min_stable);
    return false;
  }

  const double cos_yaw = cos(yaw_offset), sin_yaw = sin(yaw_offset);
  enu_R_world << cos_yaw, -sin_yaw, 0,
                 sin_yaw,  cos_yaw, 0,
                 0,        0,       1;
  // Least-squares translation for that rotation. The vertical component is
  // forced to zero: both frames start gravity-aligned at their own origin, so
  // the mean vertical difference is LIO vertical DRIFT, and folding it into a
  // constant measurement offset would bias every vertical update (measured:
  // -6.7 m on campus-01).
  enu_t_world = fit_t;
  // R4-2b frame consistency: the fit above was computed against the REPORTED
  // pose (internal + hold offset), but the updates correct the INTERNAL state
  // (`_state += dx`) and the innovations are formed against it - so the stored
  // translation must be mapped back to the internal frame, otherwise every
  // update carries a constant bias equal to the hold offset (measured on c03
  // 0-400 s: the on-arm degraded +1.1/+2.5 m before this line). Horizontal
  // only: the fit forces its vertical to zero and the vertical channel is
  // adaptively down-weighted anyway. Correct when the hold has already
  // released at lock time (the offset is then frozen); a lock DURING an active
  // hold leaves a small residual bias until release (documented corner).
  if (align_use_report_pos_)
    enu_t_world.head<2>() -= report_offset_.head<2>();
  align_resid_last = fit_resid;
  // Coarse DD acquisition is only enabled when the frame fit is sub-metre.
  // c02's 1.4 m fit is rejected by this guard; c01's 0.49 m is allowed.
  rtk_tight_.setAlignResidual(align_resid_last);

  // T1-4: the lock becomes the INITIALIZATION of the slow alignment state.
  // sigma_yaw0 is DATA-INDEPENDENT: the lock only happens after `settle`
  // consecutive fits within gnss_align_yaw_tol_deg (FORCED is disabled while
  // the state is on), so that tolerance is the bound on the locked yaw
  // uncertainty - no per-sequence constant. The translation prior is the fit
  // residual, the direct scale of the translation uncertainty.
  align_psi_ = yaw_offset;
  align_span_lock_ = std::max(span_gnss, 1.0); // yaw-lever scale for the auto rate
  if (gnss_align_state_en)
  {
    const double sigma_yaw0_deg = (gnss_align_sigma_yaw0_deg > 0.0)
                                      ? gnss_align_sigma_yaw0_deg
                                      : gnss_align_yaw_tol_deg;
    align_state_.initAtLock(sigma_yaw0_deg * M_PI / 180.0,
                            align_resid_last, gnss_meas.timestamp);
  }

  std::cout << "[GNSS] Frame alignment LOCKED (2D Procrustes, robust refit"
            << (forced && align_stable_count_ < gnss_align_settle ? ", FORCED" : "")
            << (used_relative ? ", relative" : "")
            << ")" << std::endl;
  std::cout << "[GNSS]   samples = " << n << " (dropped " << align_dropped_last_
            << "), GNSS span = " << span_gnss << " m, LIO span = " << span_lio
            << " m, settled = " << align_stable_count_ << std::endl;
  std::cout << "[GNSS]   yaw_offset = " << yaw_offset * 57.3 << " deg" << std::endl;
  std::cout << "[GNSS]   translation = " << enu_t_world.transpose()
            << " m (ENU, U up)" << std::endl;
  std::cout << "[GNSS]   horizontal fit residual RMS = " << align_resid_last
            << " m (LIO-vs-GNSS drift indicator)" << std::endl;

  // Force a fresh anchor: the first update after alignment establishes it.
  gnss_anchor_set_ = false;
  return true;
}

// E4: re-run the 2D Procrustes fit on the sliding pair buffer and replace the
// locked enu_R_world / enu_t_world in place. Guarded by the same residual
// gate as the initial lock plus a yaw-continuity bound so one bad window can
// never swing the frame; a rejected refit simply keeps the previous
// transform (behaviour degrades to the one-shot lock).
bool LIVMapper::refitEnuWorld()
{
  const int n = (int)align_enu_hist_.size();
  if (n < gnss_align_min_samples) return false;

  V3D mean_enu = V3D::Zero(), mean_world = V3D::Zero();
  for (int i = 0; i < n; i++)
  {
    mean_enu += align_enu_hist_[i];
    mean_world += align_world_hist_[i];
  }
  mean_enu /= (double)n;
  mean_world /= (double)n;
  double span_gnss = 0.0, span_lio = 0.0;
  for (int i = 0; i < n; i++)
  {
    const double dg = (align_enu_hist_[i] - mean_enu).head<2>().norm();
    const double dl = (align_world_hist_[i] - mean_world).head<2>().norm();
    if (dg > span_gnss) span_gnss = dg;
    if (dl > span_lio) span_lio = dl;
  }
  if (span_gnss < gnss_yaw_align_min_dist || span_lio < 2.0) return false;

  std::vector<char> keep(n, 1);
  std::vector<double> resid_all;
  double yaw_new = 0.0, fit_resid = 0.0;
  V3D fit_t = V3D::Zero();
  if (!fitEnuWorld2D(align_enu_hist_, align_world_hist_, keep, yaw_new, fit_t,
                     fit_resid, resid_all))
    return false;

  int dropped = 0;
  {
    std::vector<double> kept(resid_all.begin(), resid_all.end());
    std::nth_element(kept.begin(), kept.begin() + kept.size() / 2, kept.end());
    const double med = kept[kept.size() / 2];
    const double thr = std::max(gnss_align_drop_scale * med, 1.0);
    for (int i = 0; i < n; i++)
      if (keep[i] && resid_all[i] > thr) { keep[i] = 0; dropped++; }
  }
  if (dropped > 0 &&
      !fitEnuWorld2D(align_enu_hist_, align_world_hist_, keep, yaw_new, fit_t,
                     fit_resid, resid_all))
    return false;

  // Same residual gate as the initial lock.
  if (gnss_align_resid_gate && fit_resid > gnss_align_max_resid)
    return false;

  // Yaw-continuity guard: the locked frame is the filter's working reference;
  // a refit may correct its slow drift but must not flip it in one step.
  const double yaw_cur = std::atan2(enu_R_world(1, 0), enu_R_world(0, 0));
  double dyaw = yaw_new - yaw_cur;
  dyaw = std::atan2(std::sin(dyaw), std::cos(dyaw));
  if (std::fabs(dyaw) * 57.2957795 > gnss_align_yaw_tol_deg * 20.0)
  {
    if (align_badfit_count_++ % 5 == 0)
      printf("[GNSS] E4 refit REJECTED: dyaw %.2f deg exceeds %.2f deg bound "
             "(resid=%.3f m)\n", dyaw * 57.2957795,
             gnss_align_yaw_tol_deg * 20.0, fit_resid);
    return false;
  }

  const double cos_yaw = cos(yaw_new), sin_yaw = sin(yaw_new);
  enu_R_world << cos_yaw, -sin_yaw, 0,
                 sin_yaw,  cos_yaw, 0,
                 0,        0,       1;
  enu_t_world = fit_t;   // vertical forced zero by fitEnuWorld2D
  if (align_badfit_count_++ % 5 == 0)
    printf("[GNSS] E4 refit applied: n=%d dyaw=%.3f deg t=(%.2f,%.2f) "
           "resid=%.3f m span=%.1f m\n",
           n, dyaw * 57.2957795, fit_t(0), fit_t(1), fit_resid, span_gnss);
  return true;
}

void LIVMapper::propagateStateToTime(double target_time, StatesGroup &state_inout)
{
  if (imu_history_buffer.empty() || target_time <= LidarMeasures.last_lio_update_time) {
    return;
  }

  double current_time = LidarMeasures.last_lio_update_time;
  StatesGroup state = state_inout;

  // Find IMU measurements in the time range from history buffer
  // (lock buffer while copying data, unlock during integration)
  vector<sensor_msgs::Imu> imu_in_range;
  mtx_buffer.lock();
  for (const auto &imu_msg : imu_history_buffer)
  {
    double t = imu_msg.header.stamp.toSec();
    if (t > current_time && t <= target_time) {
      imu_in_range.push_back(imu_msg);
    }
  }
  mtx_buffer.unlock();

  if (imu_in_range.empty()) {
    // No IMU data, do simple linear propagation
    double dt = target_time - current_time;
    V3D acc = state.rot_end * (-state.bias_a) + state.gravity;
    state.pos_end += state.vel_end * dt + 0.5 * acc * dt * dt;
    state.vel_end += acc * dt;
    state_inout = state;
    return;
  }

  // Integrate IMU measurements
  double last_t = current_time;
  for (const auto &imu_msg : imu_in_range)
  {
    double t = imu_msg.header.stamp.toSec();
    double dt = t - last_t;

    if (dt <= 0) continue;

    V3D acc_imu(imu_msg.linear_acceleration.x,
                imu_msg.linear_acceleration.y,
                imu_msg.linear_acceleration.z);
    V3D gyr_imu(imu_msg.angular_velocity.x,
                imu_msg.angular_velocity.y,
                imu_msg.angular_velocity.z);

    prop_imu_once(state, dt, acc_imu, gyr_imu);
    last_t = t;
  }

  // Propagate remaining time to target
  if (last_t < target_time)
  {
    double dt = target_time - last_t;
    const auto &last_imu = imu_in_range.back();
    V3D acc_imu(last_imu.linear_acceleration.x,
                last_imu.linear_acceleration.y,
                last_imu.linear_acceleration.z);
    V3D gyr_imu(last_imu.angular_velocity.x,
                last_imu.angular_velocity.y,
                last_imu.angular_velocity.z);
    prop_imu_once(state, dt, acc_imu, gyr_imu);
  }

  state_inout = state;

  // ============================================================
  // Simplified covariance propagation
  // ============================================================
  // Note: Full EKF covariance propagation requires the state transition
  // matrix F (19x19) and process noise Q. For GNSS updates which typically
  // have short propagation times (<0.1s), we use a simplified random walk
  // model to increase position and velocity covariance.
  // This is an approximation; full F matrix propagation should be implemented
  // for high-accuracy applications.
  double dt = target_time - current_time;
  if (dt > 0)
  {
    // Use IMU acceleration noise as process noise (approximate)
    double acc_noise_std = acc_cov;  // m/s^2 (from config, approximate)
    double acc_var = acc_noise_std * acc_noise_std;

    // Position variance increase: σ^2 * dt^4 / 4
    double pos_var = acc_var * dt * dt * dt * dt / 4.0;
    // Velocity variance increase: σ^2 * dt^2
    double vel_var = acc_var * dt * dt;

    // Add to diagonal elements (simplified, ignoring cross terms)
    state_inout.cov(3, 3) += pos_var;
    state_inout.cov(4, 4) += pos_var;
    state_inout.cov(5, 5) += pos_var;
    state_inout.cov(7, 7) += vel_var;
    state_inout.cov(8, 8) += vel_var;
    state_inout.cov(9, 9) += vel_var;

    // Ensure symmetry
    state_inout.cov = 0.5 * (state_inout.cov + state_inout.cov.transpose());
  }
}

// ── A4: GNSS-only (single-RTK) and GNSS+IMU (RTK/IMU) modes ────────────────
//
// These run with lidar_en = 0 and img_en = 0, so the LiDAR-frame pipeline never
// executes; the filter is driven by GNSS epochs instead. The point is to obtain
// the two baselines from THIS estimator, so they are directly comparable with
// the LIVO / LIVO+RTK results (same frames, same update, same evaluation).
//
// GNSS_ONLY reports the GNSS position itself: that is what single-RTK
// positioning is, there is nothing to estimate.
//
// GNSS_IMU propagates the state between epochs with the ordinary IMU
// propagation and then applies the GNSS position update. Rather than
// re-implementing IMU initialisation and covariance propagation, it reuses
// ImuProcess::Process2 by synthesising a frame whose "capture time" is the GNSS
// epoch and whose IMU batch is that interval - Process2 only needs a lidar scan
// for deskewing, and that step is skipped in VIO mode. So the mean and the
// covariance are propagated by exactly the same tested code path as the normal
// pipeline (including the process noise).
bool LIVMapper::runGnssInertial()
{
  GnssMeasureGroup fix;
  {
    mtx_buffer.lock();
    if (!gnss_origin_set || gnss_buffer.empty())
    {
      mtx_buffer.unlock();
      return false;
    }
    fix = gnss_buffer.front();
    gnss_buffer.pop_front();
    mtx_buffer.unlock();
  }
  if (!fix.valid) return true;

  if (slam_mode_ == GNSS_ONLY)
  {
    // The ENU frame of the fix is the same convention as the reference
    // trajectory, so no frame fitting is involved.
    writeGnssModeRow(fix.timestamp, V3D(fix.pos_e, fix.pos_n, fix.pos_u));
    return true;
  }

  // ---- GNSS + IMU ----
  if (LidarMeasures.last_lio_update_time < 0.0)
  {
    // First fix only defines the time base and the world-frame origin.
    LidarMeasures.last_lio_update_time = fix.timestamp;
    _state.pos_end.setZero();
    writeGnssModeRow(fix.timestamp, _state.pos_end);
    return true;
  }

  // IMU batch of (last_lio_update_time, fix.timestamp]
  MeasureGroup m;
  m.lio_time = fix.timestamp;
  m.vio_time = fix.timestamp;
  {
    mtx_buffer.lock();
    while (!imu_buffer.empty() &&
           imu_buffer.front()->header.stamp.toSec() <= fix.timestamp)
    {
      m.imu.push_back(imu_buffer.front());
      imu_buffer.pop_front();
    }
    mtx_buffer.unlock();
  }

  if (!m.imu.empty())
  {
    if (!gnss_mode_dummy_cloud_)
      gnss_mode_dummy_cloud_.reset(new PointCloudXYZI());
    PointCloudXYZI::Ptr dummy_out(new PointCloudXYZI());
    LidarMeasureGroup g;
    g.lidar = gnss_mode_dummy_cloud_;
    g.pcl_proc_cur = gnss_mode_dummy_cloud_;
    g.lio_vio_flg = VIO;
    g.measures.push_back(m);
    g.last_lio_update_time = LidarMeasures.last_lio_update_time;
    p_imu->Process2(g, _state, dummy_out);   // IMU init first, then propagation
  }

  // The propagation above already advanced the state to the fix time. The GNSS
  // update propagates internally as well (propagateStateToTime), so the time
  // base must be moved forward first or that interval would be integrated twice
  // (the defect fixed in A2).
  LidarMeasures.last_lio_update_time = fix.timestamp;

  // The ENU -> world frame fit must be done here as well: handleGNSS() normally
  // performs it, but this path bypasses handleGNSS. Without it enu_R_world stays
  // the identity and the updates would pull the state toward an unaligned target
  // (measured: the resulting trajectory was worse than the raw GNSS).
  if (!gnss_yaw_aligned)
  {
    if (tryAlignGnssYaw(fix)) gnss_yaw_aligned = true;
    writeGnssModeRow(fix.timestamp, _state.pos_end);
    return true;
  }

  if (!p_imu->imu_need_init)
  {
    // P1 acceptance: allow the GNSS/IMU-only mode to run the same DD
    // fixed-phase update as the full pipeline. Position-domain updates are
    // optional so the test can isolate the fixed-phase observation.
    if (gnss_position_update_en) updateStateWithGNSS(fix);
    if (rtk_tight_en) handleRTK();
    updateStaticReportOffset();
  }
  writeGnssModeRow(fix.timestamp, _state.pos_end);
  return true;
}

void LIVMapper::writeGnssModeRow(double stamp, const V3D &pos)
{
  if (!gnss_mode_file_open_)
  {
    fout_gnss_mode_.open(runtime_log_dir_ + "result/" + seq_name + ".txt", std::ios::app);
    gnss_mode_file_open_ = true;
  }
  if (!fout_gnss_mode_.is_open()) return;
  fout_gnss_mode_ << std::fixed << std::setprecision(6) << stamp
                  << " " << pos(0) << " " << pos(1) << " " << pos(2)
                  << " 0.0 0.0 0.0 1.0" << std::endl;
}

bool LIVMapper::updateStateWithGNSS(const GnssMeasureGroup &gnss_meas)
{
  // R3 stage 1 (WP1) - measure, do not fix.
  //
  // The P0-2 question is whether the fix is compared against a state from a
  // different time. Three quantities answer it, all captured below:
  //   dt_g      = t_lio - t_g, the fix's age relative to the LIO state;
  //   |v|*|dt_g| the distance the state moves over that age (the "0.5 m" figure
  //              the review quotes) - but this is only an innovation error if no
  //              propagation happens, so the residual is also recorded;
  //   |dp_prop| = how far Step 1 actually moved the state. If it matches
  //              |v|*|dt_g| the state was carried to t_g and the residual IS
  //              time-consistent; if it is 0 the fix is truly misaligned.
  const double t_g = gnss_meas.timestamp;
  const double t_lio = LidarMeasures.last_lio_update_time;
  const double dt_g = t_lio - t_g;
  // |v| of the LIO state the innovation is formed against (the estimator's own
  // velocity at t_lio). The bias this term causes is b ~= |v| * dt_g.
  const double v_lio = _state.vel_end.norm();
  // propagateStateToTime() returns early when target_time <= t_lio, so a fix at
  // or before t_lio is never propagated; only a fix ahead of it is carried
  // forward (the 0-0.5 s "future" window).
  const bool fwd_prop = (t_g > t_lio);

  // Step 1: Propagate state to GNSS measurement time
  StatesGroup state_prop = _state;
  propagateStateToTime(gnss_meas.timestamp, state_prop);

  // WP1 diagnostic (see the note at the top of this function). Written after the
  // propagation so the measured travel is included. Diagnostic only.
  if (pose_output_en && fout_gnss_pos.is_open())
  {
    const double dp_prop = (state_prop.pos_end - _state.pos_end).norm();
    const double dv_prop = (state_prop.vel_end - _state.vel_end).norm();
    fout_gnss_pos << "DT"
                  << " " << t_g - _first_lidar_time
                  << " " << t_lio - _first_lidar_time
                  << " " << dt_g
                  << " " << v_lio
                  << " " << v_lio * fabs(dt_g)
                  << " " << (fwd_prop ? 1 : 0)
                  << " " << dp_prop
                  << " " << dv_prop
                  << std::endl;
  }

  // R1 (P0-1): the update is applied to _state at t_lio, not to state_prop.
  // Reject an observation that is not contemporaneous with that state; R2b
  // replaces this with a history/replay path. Keep the DT diagnostic above so
  // the rejection rate can be measured from the same log.
  if (gnss_time_sync_tol > 0.0 && std::fabs(dt_g) > gnss_time_sync_tol)
  {
    ++gnss_time_reject_count;
    if (gnss_time_reject_count <= 5 || gnss_time_reject_count % 100 == 0)
    {
      printf("[GNSS] time reject t_g=%.3f t_lio=%.3f dt=%+.3f tol=%.3f count=%d\n",
             t_g, t_lio, dt_g, gnss_time_sync_tol, gnss_time_reject_count);
      fflush(stdout);
    }
    return false;
  }

  // Step 2: Compute predicted measurement
  // h(x) = p_I + R_I * p_GI  (IMU position + rotated lever arm)
  V3D lever_arm_world = state_prop.rot_end * gnss_extT;
  V3D z_pred = state_prop.pos_end + lever_arm_world;
  if (gnss_state_scale_en)
  {
    z_pred(0) = state_prop.scale_h * state_prop.pos_end(0) + lever_arm_world(0);
    z_pred(1) = state_prop.scale_h * state_prop.pos_end(1) + lever_arm_world(1);
  }

  // Step 3: Measurement residual.
  // Both the GNSS ENU frame and the LIO world frame are z-up (the IMU
  // initialisation gives gravity (0,0,-g)), so U is used with its own sign.
  // The former "-U to match a z-down world" negated every vertical change and
  // was masked only by the adaptive vertical sigma absorbing a constant offset.
  //
  // Two models are available (A/B in docs/EVAL_PROTOCOL.md section 6.3):
  //  * relative_update = false (default): absolute position against the fitted
  //    ENU->world transform. Best absolute accuracy, but the transform's
  //    translation absorbs the LIO drift present during the fit window.
  //  * relative_update = true: displacement from a sliding anchor, which
  //    cancels the translation identically and so cannot absorb drift; the
  //    innovation stays bounded (drift over the anchor window). Smaller gain,
  //    better local smoothness; must be used with inflate_prior = false.
  V3D z_meas_enu(gnss_meas.pos_e, gnss_meas.pos_n, gnss_meas.pos_u);
  double anchor_dt = 0.0, anchor_dist = 0.0;
  bool reanchor_due = false;
  V3D residual;

  if (gnss_relative_update)
  {
    if (!gnss_anchor_set_)
    {
      gnss_anchor_enu_ = z_meas_enu;
      gnss_anchor_world_ = z_pred;
      gnss_anchor_time_ = gnss_meas.timestamp;
      gnss_anchor_set_ = true;
      printf("[GNSS] anchor set at t=%.3f\n", gnss_meas.timestamp);
      return false;   // reference epoch: nothing to correct yet
    }
    anchor_dt = gnss_meas.timestamp - gnss_anchor_time_;
    anchor_dist = (z_pred - gnss_anchor_world_).head<2>().norm();
    reanchor_due = (anchor_dt > gnss_rel_max_dt) || (anchor_dist > gnss_rel_max_dist);
    residual = enu_R_world * (z_meas_enu - gnss_anchor_enu_) + gnss_anchor_world_ - z_pred;
  }
  else
  {
    // Absolute model (pre-A2 behaviour), kept for A/B comparison.
    V3D z_meas_world = enu_R_world * z_meas_enu + enu_t_world;
    residual = z_meas_world - z_pred;
  }

  // ---- P0-2: adaptive per-channel measurement noise ----------------------
  // The assumed GNSS sigma must match the actual LIO-vs-GNSS disagreement, and
  // that disagreement is dataset dependent (campus-01 ~0.7 m, campus-02 ~9 m
  // rising to 20 m with drift). A hand-calibrated table therefore cannot
  // transfer to a new dataset: too small -> every fix is gated out and the
  // fusion silently does nothing; too large -> the GNSS is ignored.
  // Estimate the scale online instead, robustly (median/MAD), per channel.
  // Because enu_R_world is a yaw rotation, |(rx,ry)| is the horizontal
  // magnitude and |rz| the vertical one regardless of the yaw.
  {
    const double r_h = sqrt(residual(0) * residual(0) + residual(1) * residual(1));
    const double r_u = fabs(residual(2));
    gnss_res_h_hist_.push_back(r_h);
    gnss_res_u_hist_.push_back(r_u);
    while ((int)gnss_res_h_hist_.size() > gnss_sigma_window) gnss_res_h_hist_.pop_front();
    while ((int)gnss_res_u_hist_.size() > gnss_sigma_window) gnss_res_u_hist_.pop_front();
    const double sh = robustSigma(gnss_res_h_hist_);
    const double su = robustSigma(gnss_res_u_hist_);
    if (sh > 0.0)
    {
      gnss_sigma_h = std::min(std::max(sh, gnss_sigma_floor), gnss_sigma_ceil);
      gnss_sigma_u = std::min(std::max(su, gnss_sigma_floor), gnss_sigma_ceil);
    }
  }
  const double sig_h = (gnss_sigma_h > 0.0) ? gnss_sigma_h : gnss_meas.pos_cov_h;
  const double sig_u = (gnss_sigma_u > 0.0) ? gnss_sigma_u : gnss_meas.pos_cov_v;

  // ---- optional GNSS quality factor -------------------------------------
  // The residual-derived sig_h/sig_u answer "how large is the current
  // disagreement", not "how trustworthy is this fix".  Combine it with the
  // quality information actually present in the data:
  //   * receiver covariance (NavSatFix) -> an independent scale;
  //   * fix status -> the calibrated fix-type table ratio, taken relative to
  //     a configurable reference (default Float), so Fixed gets q<1 (raise
  //     the weight) and Single gets q>1 (lower it);
  //   * DOP -> only when hdop/vdop are populated (the NavSatFix path leaves
  //     the 99 sentinel, so this term is skipped there);
  //   * C/N0 is not carried by the current GNSS messages, so it is not used.
  // The chi-square gate below keeps the absolute fix-type table, so this
  // factor changes the gain only, not the accept/reject decision.
  double q_fix_h = 1.0, q_fix_u = 1.0, q_dop_h = 1.0, q_dop_u = 1.0;
  double sig_cov_h = 0.0, sig_cov_u = 0.0;
  double sig_h_quality = sig_h, sig_u_quality = sig_u;
  if (gnss_quality_en)
  {
    // q_fix is 1 at the configured reference status (default Float), <1 for
    // Fixed (better -> raise the GNSS weight) and >1 for Single (worse ->
    // lower it).  Set quality_fix_ref_status=5 to make Fixed the baseline.
    const double sr_h = p_gnss->getHorizontalCov(gnss_quality_fix_ref_status);
    const double sr_u = p_gnss->getVerticalCov(gnss_quality_fix_ref_status);
    const double st_h = p_gnss->getHorizontalCov(gnss_meas.fix_status);
    const double st_u = p_gnss->getVerticalCov(gnss_meas.fix_status);
    q_fix_h = 1.0 + gnss_quality_fix_weight *
        (st_h / std::max(1e-6, sr_h) - 1.0);
    q_fix_u = 1.0 + gnss_quality_fix_weight *
        (st_u / std::max(1e-6, sr_u) - 1.0);
    q_fix_h = std::min(std::max(q_fix_h, gnss_quality_factor_min),
                       gnss_quality_factor_max);
    q_fix_u = std::min(std::max(q_fix_u, gnss_quality_factor_min),
                       gnss_quality_factor_max);

    if (gnss_meas.hdop > 0.0 && gnss_meas.hdop < 90.0 &&
        gnss_quality_dop_ref > 0.0)
      q_dop_h = 1.0 + gnss_quality_dop_weight *
          (gnss_meas.hdop / gnss_quality_dop_ref - 1.0);
    if (gnss_meas.vdop > 0.0 && gnss_meas.vdop < 90.0 &&
        gnss_quality_dop_ref > 0.0)
      q_dop_u = 1.0 + gnss_quality_dop_weight *
          (gnss_meas.vdop / gnss_quality_dop_ref - 1.0);
    q_dop_h = std::min(std::max(q_dop_h, gnss_quality_factor_min),
                       gnss_quality_factor_max);
    q_dop_u = std::min(std::max(q_dop_u, gnss_quality_factor_min),
                       gnss_quality_factor_max);

    sig_cov_h = gnss_quality_cov_weight * std::max(0.0, gnss_meas.pos_cov_h);
    sig_cov_u = gnss_quality_cov_weight * std::max(0.0, gnss_meas.pos_cov_v);
    sig_h_quality = std::sqrt(sig_h * sig_h + sig_cov_h * sig_cov_h) *
                    q_fix_h * q_dop_h;
    sig_u_quality = std::sqrt(sig_u * sig_u + sig_cov_u * sig_cov_u) *
                    q_fix_u * q_dop_u;
    sig_h_quality = std::min(std::max(sig_h_quality, gnss_sigma_floor),
                             gnss_sigma_ceil);
    sig_u_quality = std::min(std::max(sig_u_quality, gnss_sigma_floor),
                             gnss_sigma_ceil);
  }

  // ---- P0-A: systematic-bias detector -----------------------------------
  // The adaptive sigma is a magnitude scale; it cannot distinguish a stable
  // 3 m misalignment from 3 m of zero-mean noise. Keep the horizontal residual
  // VECTOR, take its component-wise median, and require both a large median and
  // directional consistency before declaring a bias. This is diagnostic by
  // default; gnss/bias_guard turns it into a hold (never an update).
  {
    gnss_res_xy_hist_.push_back(Eigen::Vector2d(residual(0), residual(1)));
    while ((int)gnss_res_xy_hist_.size() > gnss_bias_window)
      gnss_res_xy_hist_.pop_front();
    const int nb = (int)gnss_res_xy_hist_.size();
    if (nb >= std::max(10, gnss_bias_window / 3))
    {
      std::vector<double> xs(nb), ys(nb);
      int k = 0;
      for (const auto &r : gnss_res_xy_hist_) { xs[k] = r(0); ys[k] = r(1); k++; }
      std::nth_element(xs.begin(), xs.begin() + nb / 2, xs.end());
      std::nth_element(ys.begin(), ys.begin() + nb / 2, ys.end());
      const Eigen::Vector2d bias(xs[nb / 2], ys[nb / 2]);
      const double bmag = bias.norm();
      int same = 0;
      for (const auto &r : gnss_res_xy_hist_)
        if (r.dot(bias) > 0.0) same++;
      const double sign = double(std::max(same, nb - same)) / double(nb);
      gnss_bias_mag_last_ = bmag;
      gnss_bias_sign_last_ = sign;
      gnss_bias_n_last_ = nb;
      const bool candidate = (bmag > gnss_bias_thresh) && (sign >= gnss_bias_sign_min);
      if (candidate) gnss_bias_count_++;
      else gnss_bias_count_ = 0;
      if (gnss_bias_count_ >= gnss_bias_persist) gnss_bias_active_ = true;
      // Hysteresis: only clear on a substantially smaller bias or weak direction.
      if ((bmag < 0.5 * gnss_bias_thresh) || (sign < 0.8 * gnss_bias_sign_min))
      {
        gnss_bias_active_ = false;
        gnss_bias_count_ = 0;
      }
    }
  }

  // Health line: an inert fusion (everything rejected) must be visible in the
  // log instead of being discovered later from the numbers. gnss/health_every_n
  // controls the rate (1 = every fix); the default 10 is the historical rate.
  // R3-WP7 adds the pieces that make a DEGRADED gate visible: median(|r|) is what
  // the adaptive sigma is built from (a centred residual would give ~0.6745*sigma,
  // i.e. a median of ~1.0*sigma after the 1.4826 MAD factor, so a median that
  // tracks sigma means the estimate is following a systematic bias rather than
  // noise), and sigma_gate is the scale the chi-square test actually uses.
  gnss_eval_count++;
  double med_h = 0.0;
  if (!gnss_res_h_hist_.empty())
  {
    std::vector<double> tmp(gnss_res_h_hist_.begin(), gnss_res_h_hist_.end());
    std::nth_element(tmp.begin(), tmp.begin() + tmp.size() / 2, tmp.end());
    med_h = tmp[tmp.size() / 2];
  }
  const double sig_gate_h_hl = (gnss_gate_sigma_mode == "adaptive")
      ? sig_h_quality : p_gnss->getHorizontalCov(gnss_meas.fix_status);
  if (gnss_health_every_n > 0 && gnss_eval_count % gnss_health_every_n == 0)
  {
    printf("[GNSS] health: evaluated=%d accepted=%d rejected=%d time_rej=%d | sigma_h=%.2f sigma_u=%.2f m "
           "| med|r_h|=%.2f (ratio %.2f) | gate_sigma=%s/%.2f m | anchor dt=%.1fs dist=%.1fm\n",
           gnss_eval_count, gnss_ok_count, gnss_rej_count, gnss_time_reject_count,
           sig_h, sig_u,
           med_h, (sig_gate_h_hl > 0.0) ? med_h / sig_gate_h_hl : 0.0,
           gnss_gate_sigma_mode.c_str(), sig_gate_h_hl, anchor_dt, anchor_dist);
    if (gnss_quality_en)
      printf("[GNSS] quality: fix=%d q_fix=(%.2f,%.2f) q_dop=(%.2f,%.2f) "
             "sig_cov=(%.2f,%.2f) -> sigma=(%.2f,%.2f)\n",
             gnss_meas.fix_status, q_fix_h, q_fix_u, q_dop_h, q_dop_u,
             sig_cov_h, sig_cov_u, sig_h_quality, sig_u_quality);
  }
  if (gnss_bias_active_)
    printf("[GNSS] bias: |b|=%.2f m sign=%.2f n=%d holds=%d\n",
           gnss_bias_mag_last_, gnss_bias_sign_last_, gnss_bias_n_last_,
           gnss_bias_hold_count_);

  // P0-A guard: a persistent directional innovation is an alignment/scale
  // problem, not noise. Holding updates is the safe fallback: it cannot drag
  // the trajectory toward a stale frame. The detector keeps running, so the
  // guard clears itself once the bias disappears.
  if (gnss_bias_guard && gnss_bias_active_)
  {
    gnss_rej_count++;
    gnss_bias_hold_count_++;
    if (gnss_health_every_n > 0 && gnss_eval_count % gnss_health_every_n == 0)
      printf("[GNSS] bias guard HOLD: |b|=%.2f m sign=%.2f\n",
             gnss_bias_mag_last_, gnss_bias_sign_last_);
    return false;
  }

  // P2 supervisor: soft-weight the position-domain update. The chi-square gate
  // below still uses the raw table covariance; only the gain covariance is
  // scaled, so the gate cannot be disabled by the weight.
  double sig_h_use = sig_h_quality, sig_u_use = sig_u_quality;
  if (fusion_sup_cfg_.en && fusion_sup_.updates() > 0)
  {
    const double w = fusion_sup_.output().w_gnss;
    if (w <= 1e-3)
    {
      gnss_rej_count++;
      return false;
    }
    const double scale = 1.0 / std::sqrt(std::max(w, 1e-3));
    sig_h_use *= scale;
    sig_u_use *= scale;
  }

  // Step 4: Measurement Jacobian H (3 x DIM_STATE)
  // h = p + R * p_lever
  // Right perturbation (StatesGroup::operator+ does R*Exp(dtheta)):
  //   dh/d(theta) = -R * [p_lever]_x = -[R*p_lever]_x * R
  // The previous code kept only -[R*p_lever]_x, i.e. the left-perturbation
  // derivative, which mismatches the state update for any non-identity R.
  // dh/dp = I; all other states: 0.
  Matrix<double, 3, DIM_STATE> H = Matrix<double, 3, DIM_STATE>::Zero();

  // Attitude Jacobian (indices 0-2)
  M3D lever_arm_crossmat;
  lever_arm_crossmat << SKEW_SYM_MATRX(lever_arm_world);
  H.block<3, 3>(0, 0) = -lever_arm_crossmat * state_prop.rot_end;

  // Position Jacobian (indices 3-5): p_true = [s*px, s*py, pz].
  H.block<3, 3>(0, 3) = M3D::Identity();
  if (gnss_state_scale_en)
  {
    H(0, 3) = state_prop.scale_h;
    H(1, 4) = state_prop.scale_h;
    // Scale column: d p_true / d s = [px, py, 0].
    H(0, 19) = state_prop.pos_end(0);
    H(1, 19) = state_prop.pos_end(1);
  }

  // Step 5: Measurement noise covariance R
  // R is defined in the ENU frame (U up) and rotated to the world frame.
  // sig_h / sig_u are the ADAPTIVE per-channel sigmas estimated above.
  M3D R_enu = M3D::Zero();
  R_enu(0, 0) = sig_h_use * sig_h_use;  // East
  R_enu(1, 1) = sig_h_use * sig_h_use;  // North
  R_enu(2, 2) = sig_u_use * sig_u_use;  // Up (negated)
  M3D R = enu_R_world * R_enu * enu_R_world.transpose();

  // Fuse all three channels and let the per-channel adaptive sigma decide how
  // much each one is trusted. A degraded vertical channel (campus-02: ~8 m)
  // simply gets a large sigma and is down-weighted automatically, so the
  // per-dataset `use_vertical` switch is no longer needed.
  //
  // ---- R3 stage 4 (L2): optional GNSS velocity (doppler) rows ----------------
  // The quantity a receiver reports is the ANTENNA's velocity, not the body's:
  //     v_ant = v + R*(omega x p_lever)
  // The lever term is ~0.18 m/s at 0.5 rad/s with this antenna's 0.37 m lever -
  // the same order as the velocity sigma - and it appears precisely while
  // turning, i.e. exactly when yaw is observable, so leaving it out would bias
  // the turns this observation is meant to help. omega is taken from the newest
  // IMU gyro as a KNOWN input, so no Jacobian w.r.t. bias_g is needed
  // (|p_lever|*|bg| ~ 0.004 m/s is second order). A velocity carries no
  // translation term, so the absolute and anchored position models do not differ
  // here: both compare the measured antenna velocity with the predicted one.
  const bool use_vel = gnss_use_velocity && gnss_meas.has_vel;
  int n_obs = use_vel ? 6 : 3;  // D1: reduced below when gnss/use_vertical=false

  // NOTE: dynamic-size Eigen matrices are NOT zero-initialised, and the velocity
  // rows only fill some of the 19 columns (the position block of a velocity row is
  // genuinely zero, as is the gravity / exposure-time block). Constructing these
  // with ::Zero is therefore required, not cosmetic: leaving the remaining columns
  // as garbage makes H*P*H^T indefinite and the innovation covariance
  // undecomposable, which shows up as a NaN chi-square statistic.
  Eigen::Matrix<double, Eigen::Dynamic, DIM_STATE> H_full =
      Eigen::Matrix<double, Eigen::Dynamic, DIM_STATE>::Zero(n_obs, DIM_STATE);
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> R_full =
      Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic>::Zero(n_obs, n_obs);
  Eigen::Matrix<double, Eigen::Dynamic, 1> res_full =
      Eigen::Matrix<double, Eigen::Dynamic, 1>::Zero(n_obs);
  H_full.topRows(3) = H;
  R_full.topLeftCorner(3, 3) = R;
  res_full.head(3) = residual;

  if (use_vel)
  {
    // Angular velocity for the lever-arm term. Taken from the IMU history buffer
    // rather than newest_imu: newest_imu is only written when imu_prop_enable is
    // set, so in configurations that disable it the gyro there stays zero and the
    // lever term would be silently absent - which is exactly the systematic turn
    // error this term exists to remove. imu_history_buffer is the same stream
    // propagateStateToTime() already uses, so it is populated whenever IMU data
    // flows. The lock is taken here for the same reason and in the same way.
    V3D omega_body = V3D::Zero();
    mtx_buffer.lock();
    if (!imu_history_buffer.empty())
    {
      const sensor_msgs::Imu &imu_last = imu_history_buffer.back();
      omega_body = V3D(imu_last.angular_velocity.x, imu_last.angular_velocity.y,
                       imu_last.angular_velocity.z);
    }
    mtx_buffer.unlock();
    const V3D lever_vel_world = state_prop.rot_end * omega_body.cross(gnss_extT);
    const V3D z_pred_vel = state_prop.vel_end + lever_vel_world;
    // ENU and world are both z-up: no sign flip on the velocity channel.
    const V3D vel_meas_enu(gnss_meas.vel_enu(0), gnss_meas.vel_enu(1),
                           gnss_meas.vel_enu(2));
    const V3D residual_v = enu_R_world * vel_meas_enu - z_pred_vel;

    // Attitude block: d(R*a)/d(theta) = -R*[a]_x with a = omega x p_lever,
    // under the right perturbation R*Exp(dtheta) used by StatesGroup.
    M3D lever_vel_crossmat;
    lever_vel_crossmat << SKEW_SYM_MATRX(lever_vel_world);
    H_full.block<3, 3>(3, 0) = -lever_vel_crossmat * state_prop.rot_end;
    // Velocity block. R4-4: the state layout is rot 0-2, pos 3-5, INV_EXPO 6,
    // vel 7-9 (StatesGroup::operator+ is the authority). This block used to be
    // written at columns 6-8, which put the velocity Jacobian on the exposure
    // time and shifted every velocity correction into it - dormant while
    // gnss/use_velocity is off (the default everywhere), but wrong.
    H_full.block<3, 3>(3, 7) = M3D::Identity();
    H_full.block<3, 9>(3, 10).setZero();

    M3D Rv_enu = M3D::Zero();
    const double sv2 = gnss_vel_sigma * gnss_vel_sigma;
    Rv_enu(0, 0) = sv2;   // East
    Rv_enu(1, 1) = sv2;   // North
    // The vertical velocity is much worse than the horizontal one, and the
    // receiver's formal sigma does not say so. Rather than dropping the row (which
    // would make the observation count, and therefore the chi-square DOF, depend
    // on configuration), give it a large sigma: it is then down-weighted to
    // nothing, exactly the trick the position path uses for a bad channel.
    Rv_enu(2, 2) = gnss_vel_use_vertical ? sv2 : 1e6;
    R_full.block<3, 3>(3, 3) = enu_R_world * Rv_enu * enu_R_world.transpose();
    res_full.segment<3>(3) = residual_v;

    gnss_vel_used_count++;
    gnss_vel_res_last = residual_v.norm();
    // Levers term magnitude, kept for the diagnostics line below: it is the term
    // the plan flags as most easily omitted, so it should be observable. It is
    // ~0 at standstill and ~0.1-0.2 m/s in a turn with this 0.37 m antenna.
    gnss_vel_lever_last = lever_vel_world.norm();
  }

  // D1: revive gnss/use_vertical — when false, drop the vertical position row
  // entirely (2-row update, velocity rows keep their own gnss/vel_use_vertical
  // switch). The switch was dead since the "adaptive sigma replaces the switch"
  // refactor: declared and read but never consulted, so the vertical row always
  // entered both the gain and the gate.
  if (!gnss_use_vertical)
  {
    const int keep_n = use_vel ? 5 : 2;
    // source rows: 0,1 = horizontal; 3,4,5 = velocity (present only when use_vel)
    const int src[5] = {0, 1, 3, 4, 5};
    Eigen::Matrix<double, Eigen::Dynamic, DIM_STATE> H_k(keep_n, DIM_STATE);
    Eigen::MatrixXd R_k(keep_n, keep_n);
    Eigen::VectorXd res_k(keep_n);
    for (int a = 0; a < keep_n; ++a)
    {
      H_k.row(a) = H_full.row(src[a]);
      res_k(a) = res_full(src[a]);
      for (int b = 0; b < keep_n; ++b)
        R_k(a, b) = R_full(src[a], src[b]);
    }
    H_full.swap(H_k);
    R_full.swap(R_k);
    res_full.swap(res_k);
    n_obs = keep_n;
  }

  Eigen::Matrix<double, Eigen::Dynamic, DIM_STATE> H_use = H_full;
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> R_use = R_full;
  Eigen::Matrix<double, Eigen::Dynamic, 1> res_use = res_full;

  // ---- R3-WP7: the gate must not share the gain's sigma ----------------------
  // Until now gamma and K both came from one S built with the ADAPTIVE sigma.
  // robustSigma() takes the median of |residual| WITHOUT centring it, so it measures
  // the disagreement scale rather than the noise. gamma then reduces to roughly
  // (|r|/median)^2 - a RELATIVE test that only rejects what is ~4x the current median
  // - and the absolute error constraint disappears, which is what lets a chronically
  // biased stream pass unnoticed (campus-02: 20 m of disagreement, sigma_h -> 20 m,
  // gamma ~ 0.5 for ANY innovation). The adaptive sigma is still the right WEIGHT on
  // campus-01, so this needs two S matrices and two LLTs: the gate uses the fix-type
  // table (absolute, physical scale) and the gain keeps the adaptive sigma.
  // gnss/gate_sigma_mode = adaptive restores the old single-S behaviour for the A/B.
  const bool gate_adaptive = (gnss_gate_sigma_mode == "adaptive");
  Eigen::Matrix<double, Eigen::Dynamic, Eigen::Dynamic> R_gate = R_full;
  if (!gate_adaptive)
  {
    M3D Rg_enu = M3D::Zero();
    const double sg_h = p_gnss->getHorizontalCov(gnss_meas.fix_status);
    double sg_u = p_gnss->getVerticalCov(gnss_meas.fix_status);
    // D1: split mode floors the vertical gate sigma — the table value (1.2/2.5 m)
    // is far below the measured vertical disagreement (adaptive sigma_u 11-27 m
    // on campus-01), which is what let the vertical row decide the joint test.
    if (gnss_vertical_gate == "split")
      sg_u = std::max(sg_u, gnss_vertical_gate_floor);
    Rg_enu(0, 0) = sg_h * sg_h;
    Rg_enu(1, 1) = sg_h * sg_h;
    Rg_enu(2, 2) = sg_u * sg_u;
    const M3D Rg_world = enu_R_world * Rg_enu * enu_R_world.transpose();
    // D1: the position block is 2x2 when gnss/use_vertical=false (row dropped
    // above); velocity rows, if present, keep their assembled constants.
    const int pos_rows = gnss_use_vertical ? 3 : 2;
    R_gate.topLeftCorner(pos_rows, pos_rows) = Rg_world.topLeftCorner(pos_rows, pos_rows);
    // the velocity rows are a configured constant, not an adaptive estimate, so the
    // gate and the gain share them unchanged
  }

  // Step 6: Innovation covariance S = H * P * H^T + R (LLT for stable solves)
  //
  // A2: use an honest position prior. The LIO reports a position sigma of a few
  // centimetres (measured P_pos_prior ~0.03 m) while its real drift is metres,
  // so the raw gain P/(P+R) collapses to ~1% and the fusion is inert. Setting
  // the horizontal position prior sigma to the observed innovation scale sig_h
  // - the filter's own online estimate of the LIO-vs-GNSS disagreement - makes
  // the gain sig_h^2/(sig_h^2+R) ~ 0.5, i.e. each accepted fix removes about
  // half of the measured drift. There is no per-dataset constant here: sig_h is
  // estimated from the data. The inflation is bounded (it is a max, and sig_h
  // is clamped to sigma_ceil), so it cannot compound.
  Matrix<double, DIM_STATE, DIM_STATE> P_use = state_prop.cov;
  if (gnss_inflate_prior)
  {
    const double p_h = std::max(sig_h_quality, gnss_sigma_floor);
    for (int k = 0; k < 2; k++)   // world x/y are the horizontal axes (yaw-only rotation)
      if (P_use(3 + k, 3 + k) < p_h * p_h) P_use(3 + k, 3 + k) = p_h * p_h;
  }

  // R3 P1-3 (A3-2): bounded physical drift prior. P1-2 (EVAL_PROTOCOL 14) showed
  // the per-epoch gain (~5e-4, from the ~0.03 m prior vs the ~4 m adaptive
  // sigma) caps the total correction at ~0.1-0.2 m over 200 s while the LIO
  // drifts metres; the gate's absolute scale is NOT the limiter. So grow the
  // position prior with the drift a pure LIO accumulates between absolute
  // corrections, as an exact ACCOUNT: accrue b*dt per fix interval (b = 0.004
  // m/s measured on c01 pure-LIVO vs reference, 3.5-5.3 mm/s over 70-200 s),
  // pay the account down by the correction an accepted epoch actually applies,
  // use sigma = max(a, acc), cap the account so a long uncorrected stretch
  // cannot blow the gain up.
  //
  // THREE separations make this safe where inflate_prior was not:
  //  1. no innovation feedback: the account grows with TIME at the LIO's own
  //     drift rate and is paid by the APPLIED correction, never by the residual,
  //     so a large LIO-GNSS disagreement (campus-02: ~20 m) cannot inflate the
  //     prior and deaden the gate (the 6.3c circularity);
  //  2. the chi-square gate below keeps the RAW P_use - only the update's S/K
  //     and the Joseph covariance use P_upd - so the accepted/rejected epoch set
  //     is unchanged (14.4: widening the gate's acceptance measurably hurts);
  //  3. self-balancing: the gain rises only until gain*res pays the b*dt
  //     accrual, so a well-corrected steady state keeps a small sigma while a
  //     long-uncorrected state gets a real correction budget.
  double drift_sigma = 0.0;
  Matrix<double, DIM_STATE, DIM_STATE> P_upd = P_use;
  if (gnss_prior_drift_en)
  {
    if (gnss_drift_last_t_ < 0.0)
      gnss_drift_last_t_ = gnss_meas.timestamp; // first fix: nothing accrued yet
    gnss_drift_acc_ = gnssDriftGrow(gnss_drift_acc_, gnss_prior_drift_b,
                                    gnss_meas.timestamp - gnss_drift_last_t_,
                                    gnss_prior_drift_max);
    gnss_drift_last_t_ = gnss_meas.timestamp;
    drift_sigma = gnssDriftSigmaOf(gnss_drift_acc_, gnss_prior_drift_a);
    if (drift_sigma > 0.0)
      for (int k = 3; k < 6; k++)   // position block only (rot 0-2, pos 3-5, vel 6-8)
        P_upd(k, k) += drift_sigma * drift_sigma;
  }

  // R3-WP7: two decompositions - the gate's (fix-type table sigma, absolute scale)
  // and the update's (adaptive sigma, kept as the weight). They are identical when
  // gnss/gate_sigma_mode is "adaptive".
  // R3 P1-3: the gate's S uses the RAW prior P_use, never the drift-inflated
  // P_upd - inflating the gate's S would loosen exactly the test that 14.4
  // measured as better left strict. The two are identical when the drift prior
  // is off (the default), so the gate's behaviour is history-preserving.
  //
  // T1-4: the joint S gains an additive H_a P_a H_a^T block - the alignment
  // prior is the same honest uncertainty for the gate and the gain (no
  // inflation, no P_use/P_upd separation on the alignment side). With P_xa = 0
  // this is the exact joint filter under the parallel-prior approximation.
  // When the state is disabled S_a is exactly zero, so both computes are
  // bit-identical to the historical expressions.
  const bool align_frozen = zupt_rep_holding_; // LIVE hold condition: no Q AND no update
  Eigen::Matrix<double, Eigen::Dynamic, 3> H_a;
  bool align_active = gnss_align_state_en && align_state_.initialised;
  if (align_active && !gnss_use_vertical)
  {
    // D1: H_a is laid out for the 3-row (or 6-row) residual; the 5-row layout
    // (use_vertical=false + velocity) is not mapped, so disable the alignment
    // state rather than adding a mismatched block to S.
    static bool warn_align_drop = false;
    if (!warn_align_drop)
    {
      ROS_WARN("[GNSS] align_state disabled: incompatible with gnss/use_vertical=false");
      warn_align_drop = true;
    }
    align_active = false;
  }
  double align_dt_g = 0.0; // fix interval, captured BEFORE propagate advances last_t
  if (align_active)
  {
    // AUTO rates (documented in LIVMapper.h): tau = sig_h*sqrt(dt)/q is held at
    // gnss_align_tau_s, but the rate is CAPPED at the physical drift scale
    // (redesign (a), EVAL_PROTOCOL 26.3): q_eff = min(sig_h*sqrt(dt)/tau,
    // drift_rate*sqrt(tau)). With the cap the steady-state authority
    // K ~ q/σ falls as 1/σ - worse data, LESS authority (the monotonicity
    // invariant). Explicit >0 values reproduce historical arms.
    //
    // dt_g MUST be captured here: propagate() below advances align_state_.last_t
    // to this epoch, so a later "timestamp - last_t" reads 0 and would silently
    // disable the fold-rate cap (the re-validation batch's log-level criterion
    // (2) caught exactly that: c02 fold_t 10.4 m > resid0 + 2bT = 7.4 m).
    align_dt_g = std::max(gnss_meas.timestamp - align_state_.last_t, 1e-3);
    const double q_cap = gnss_align_drift_rate * std::sqrt(std::max(gnss_align_tau_s, 1.0));
    const double q_pos = (gnss_align_q_pos > 0.0)
                             ? gnss_align_q_pos
                             : std::min(sig_h * std::sqrt(align_dt_g) / std::max(gnss_align_tau_s, 1.0),
                                        q_cap);
    const double q_yaw_rad = (gnss_align_q_yaw_deg > 0.0)
                                 ? gnss_align_q_yaw_deg * M_PI / 180.0
                                 : q_pos / align_span_lock_;
    align_q_pos_last_ = q_pos;
    align_q_yaw_last_ = q_yaw_rad;
    // (b') authority ceiling, relative to the CURRENT adaptive noise scale:
    // R_eff = sig_h^2 (the same sigma the update R uses), so K_a <= kmax
    // holds for every epoch (c03's 8 m^2 prior against 0.09 m^2 of R is
    // structurally impossible now).
    align_state_.capAuthority(gnss_align_kmax / (1.0 - gnss_align_kmax),
                              sig_h * sig_h);
    align_state_.propagate(gnss_meas.timestamp, q_yaw_rad * q_yaw_rad,
                           q_pos * q_pos, align_frozen);
    // v for the yaw lever: the ENU vector the transform acts on in THIS mode
    // (anchored mode cancels the translation identically -> no dt columns).
    const Eigen::Vector3d v_pos = gnss_relative_update
        ? Eigen::Vector3d(enu_R_world * (z_meas_enu - gnss_anchor_enu_))
        : Eigen::Vector3d(enu_R_world * z_meas_enu);
    const Eigen::Vector3d v_vel = enu_R_world *
        V3D(gnss_meas.vel_enu(0), gnss_meas.vel_enu(1), gnss_meas.vel_enu(2));
    H_a = GnssAlignState::haMatrix(v_pos, use_vel, v_vel, !gnss_relative_update);
  }
  Eigen::MatrixXd S_a = Eigen::MatrixXd::Zero(n_obs, n_obs);
  if (align_active)
    S_a = (H_a * align_state_.P) * H_a.transpose();
  Eigen::MatrixXd S_dense = H_use * P_upd * H_use.transpose() + R_use + S_a;
  // D3 (gnss/prior_drift_gate): optionally give the gate the same drift-inflated
  // prior as the gain (consistent S). P1-3 kept the gate on the raw prior
  // because inflating it loosened the test (EVAL_PROTOCOL 14.4) — that was
  // measured with the joint 3-DOF gate whose vertical row dominated; this
  // switch re-tests the question with the channel-split gate. Default off is
  // bit-identical to the historical expression.
  const auto &P_gate = (gnss_prior_drift_gate && gnss_prior_drift_en) ? P_upd : P_use;
  Eigen::MatrixXd S_gate = H_use * P_gate * H_use.transpose() + R_gate + S_a;
  Eigen::LLT<Matrix<double, Eigen::Dynamic, Eigen::Dynamic>> llt_S;      // updates
  Eigen::LLT<Matrix<double, Eigen::Dynamic, Eigen::Dynamic>> llt_gate;   // chi-square
  llt_S.compute(S_dense);
  llt_gate.compute(S_gate);

  // Step 7: Outlier rejection (chi-square test).
  //
  // gnss/vertical_gate:
  //   "joint" (default, historical): one n_obs-DOF test, 7.815 (12.592 with
  //     velocity rows). Kept for the A/B: with the fix-status table sigma the
  //     vertical row alone decides the test (e1e2_n3 REPORT.md A2: 293/349
  //     rejects were RTK-fixed epochs; vertical disagreement 7-18 m against a
  //     1.2/2.5 m table).
  //   "split": horizontal 2-DOF test on the marginalized {x,y} sub-block
  //     (chi2(2,0.95)=5.991) plus a separate 1-DOF vertical test
  //     (chi2(1,0.95)=3.841) whose gate sigma is floored at
  //     gnss/vertical_gate_floor, so the known-unreliable vertical channel
  //     cannot veto horizontally good fixes. Velocity rows fall back to the
  //     joint test (velocity gating is D4, not part of D1).
  //   gnss/use_vertical=false drops the vertical row before this point, so the
  //     joint test there is already horizontal-only.
  // The threshold follows the observation count so that enabling the velocity
  // rows does not silently tighten it. gnss/outlier_threshold still overrides
  // the horizontal (or joint) threshold when a config sets it > 0 (0 = auto).
  double gate_used = 0.0, gamma_last = 0.0;
  if (gnss_outlier_rejection)
  {
    const bool split_gate =
        (gnss_vertical_gate == "split") && !use_vel && gnss_use_vertical;
    double gate_auto;
    if (use_vel)
      gate_auto = gnss_use_vertical ? 12.592 : 11.070;  // chi2(6/5, 0.95)
    else
      gate_auto = gnss_use_vertical ? 7.815 : 5.991;    // chi2(3/2, 0.95)
    const double gate = (gnss_outlier_thresh > 0) ? gnss_outlier_thresh : gate_auto;
    const double gamma = res_use.transpose() * llt_gate.solve(res_use);
    double gamma_h = gamma, gamma_v = 0.0, gate_v = 0.0;
    if (split_gate)
    {
      // Marginalize the vertical row: p(r_h) ~ N(0, S_h) with S_h the {x,y}
      // sub-block of S_gate; the 1-DOF vertical test uses the S_zz diagonal
      // entry (marginal variance of the vertical component).
      Eigen::Matrix2d S_h;
      S_h << S_gate(0, 0), S_gate(0, 1), S_gate(1, 0), S_gate(1, 1);
      Eigen::Vector2d r_h(res_use(0), res_use(1));
      Eigen::LLT<Eigen::Matrix2d> llt_h(S_h);
      gamma_h = r_h.dot(llt_h.solve(r_h));
      gamma_v = res_use(2) * res_use(2) / S_gate(2, 2);
      gate_v = 3.841;  // chi2(1, 0.95); deliberately not user-overridable
      // the user override applies to the horizontal test only
      gate_used = (gnss_outlier_thresh > 0) ? gnss_outlier_thresh : 5.991;
      gamma_last = gamma_h;
    }
    else
    {
      gate_used = gate;
      gamma_last = gamma;
    }
    // NaN must reject. A non-finite gamma means the innovation covariance was not
    // decomposable (S not positive definite), and `NaN > gate` is FALSE, so a
    // plain comparison would ACCEPT the epoch and then apply a NaN correction to
    // the state, which poisons it permanently. Written as !(gamma <= gate) so
    // that non-finite values take the rejection branch; the split test also
    // rejects a failed 2x2 decomposition and a non-positive S_zz (which would
    // make gamma_v negative and slip through a plain comparison).
    const bool h_bad = (llt_gate.info() != Eigen::Success) || !std::isfinite(gamma);
    const bool rej_h = h_bad || !(gamma_h <= gate_used);
    const bool rej_v = split_gate &&
                       !(gamma_v >= 0.0 && gamma_v <= gate_v);
    if (rej_h || rej_v)
    {
      gnss_rej_count++;
      // R3-WP7: print the epoch's own time so a rejection can be attributed to a
      // specific fix - that is what makes the outlier-injection test checkable
      // ("the injected epoch at t=X must be rejected") rather than inferred from a
      // count the estimator's own random walk can mask.
      std::cout << "[GNSS] Outlier rejected, t="
                << (gnss_meas.timestamp - _first_lidar_time);
      if (split_gate)
        std::cout << " gamma_h=" << gamma_h << "/" << gate_used
                  << (rej_h ? " FAIL" : " pass")
                  << " gamma_v=" << gamma_v << "/" << gate_v
                  << (rej_v ? " FAIL" : " pass");
      else
        std::cout << " gamma=" << gamma << " > " << gate_used;
      std::cout << " (gate_sigma_mode=" << gnss_gate_sigma_mode
                << ", fix_status=" << gnss_meas.fix_status << ")"
                << std::endl;
      // Never let a rejecting window grow without bound: if the anchor window
      // is already over its limit, restart it from here so the following epochs
      // are judged on a fresh short baseline instead of a stale large residual.
      if (reanchor_due)
      {
        gnss_anchor_enu_ = z_meas_enu;
        gnss_anchor_world_ = z_pred;
        gnss_anchor_time_ = gnss_meas.timestamp;
      }
      return false;
    }
  }

  // Step 8: Kalman gain K = P * H^T * S^{-1}
  Matrix<double, DIM_STATE, Eigen::Dynamic> K;
  K = llt_S.solve(H_use * P_upd).transpose();

  // Step 9: State update
  // NOTE: everything below must use the *reduced* measurement set (res_use /
  // H_use / R_use). With use_vertical: false these are the 2 horizontal rows;
  // using the full 3-row residual/H/R against a 2-column K is a dimension
  // mismatch that silently reads out of bounds in Release builds (Eigen
  // asserts compiled out) and made the state explode (observed: position
  // -5e5 m at t=166 s on campus-01).
  Matrix<double, DIM_STATE, 1> dx = K * res_use;

  // A2 safety clamp: never let one epoch move the position by more than
  // gnss_max_corr metres. R1: reject the epoch instead of scaling dx, because
  // the Joseph update below uses the full gain K; a scaled dx with an unscaled
  // covariance would make the filter claim a correction it never applied.
  if (gnss_max_corr > 0.0)
  {
    const double dpos = dx.segment<3>(3).norm();
    if (dpos > gnss_max_corr)
    {
      ++gnss_rej_count;
      if (gnss_health_every_n > 0 && gnss_eval_count % gnss_health_every_n == 0)
        printf("[GNSS] reject: |dx_pos|=%.2f > max_corr=%.2f (not applied)\n",
               dpos, gnss_max_corr);
      return false;
    }
  }

  // Apply the correction to the CURRENT state, not to the state propagated to
  // the GNSS epoch. `state_prop` exists only to evaluate the innovation and the
  // Jacobian at the measurement time. Assigning it back would advance `_state`
  // past `last_prop_end_time`, while ImuProcess::UndistortPcl resumes
  // integration from `last_prop_end_time` - so the interval between the last
  // LiDAR frame and the GNSS fix would be integrated TWICE (position and
  // velocity overshoot, trajectory stretched ~2%). That went unnoticed while
  // almost every fix was chi-square rejected; once the anchored update made the
  // fusion active it showed up as a several-metre, sometimes divergent, drift.
  _state += dx;
  clampAuxState();

  // T1-4: alignment-state update - accepted epochs only (rejections returned
  // above). The fold applies the clamped correction to the transform itself so
  // the next epoch's innovation uses it; the filter keeps the posterior
  // covariance. A frozen epoch (report hold active) skips the update entirely
  // per the review-fixed semantics (T1_4_DESIGN 2.4/10.1): the translation is
  // perfectly observable from a static fix and would chase the internal walk
  // plus GNSS scatter - harmful, not uninformative.
  if (align_active)
  {
    const Eigen::Matrix3d P_prev = align_state_.P;
    // Redesign (c): the translation fold is capped at drift_rate*dt_g - the
    // transform can never be dragged faster than the LIO physically drifts
    // (yaw rate cap DISABLED: 0.0 - the c01 evidence, EVAL_PROTOCOL 26.5,
    // shows the yaw channel's useful action includes initial corrections a
    // b/span rate cap would suffocate; the yaw stays governed by (a)+(b')).
    const Eigen::Vector3d da = align_state_.update(
        H_a, S_dense, res_use,
        gnss_align_max_dyaw_deg * M_PI / 180.0, gnss_align_max_dt_m,
        0.0, gnss_align_drift_rate,
        align_dt_g, align_frozen);
    // The posterior cross term the parallel-prior approximation discards:
    // P_xa' = -K_x H_a P_a. Logged as the v2 true-augmentation trigger.
    align_cross_last_ = (K * (H_a * P_prev)).norm();
    if (!align_frozen && da.squaredNorm() > 0.0)
    {
      align_fold_t_total_ += da.tail<2>().norm();
      align_psi_ += da(0);
      const double cy = cos(align_psi_), sy = sin(align_psi_);
      enu_R_world << cy, -sy, 0,
                     sy,  cy, 0,
                     0,   0,  1;
      enu_t_world.head<2>() += da.tail<2>();
    }
  }

  // Gain regime diagnostics: the position prior sigma decides whether a fix can
  // move anything at all. Without this a silently inert (or over-aggressive)
  // fusion is invisible in the log. Same configurable rate as the health line.
  if (gnss_health_every_n > 0 && gnss_eval_count % gnss_health_every_n == 0)
  {
    // P1-3: the EFFECTIVE update prior (P_upd) is what decides whether a fix can
    // move anything, so that is what this line reports; with the drift prior off
    // P_upd is P_use and the output is unchanged. The drift sigma itself is
    // printed only while active, so disabled runs keep the historical format.
    const double p_pos = sqrt(P_upd.block<3, 3>(3, 3).diagonal().maxCoeff());
    if (drift_sigma > 0.0)
      printf("[GNSS] update: |res|=%.3f |dx_pos|=%.3f P_pos_eff=%.4f m (drift_sigma=%.3f)\n",
             res_use.norm(), dx.segment<3>(3).norm(), p_pos, drift_sigma);
    else
      printf("[GNSS] update: |res|=%.3f |dx_pos|=%.3f P_pos_eff=%.4f m\n",
             res_use.norm(), dx.segment<3>(3).norm(), p_pos);
    // R3-WP7: the chi-square quantities, so that "the gate rejects nothing because
    // it has no absolute scale" is visible rather than deduced. gamma_sigma is the
    // residual multiple the gate currently corresponds to (sqrt(gate)); with an
    // absolute sigma table it is ~2.8, whereas an adaptive sigma makes gamma ~1 for
    // any innovation, i.e. an effective multiple of ~1.
    if (gate_used > 0.0)
      printf("[GNSS] update: gate t=%.1f gamma=%.3f gate=%.3f (equiv %.2f sigma, mode=%s)\n",
             gnss_meas.timestamp - _first_lidar_time, gamma_last, gate_used,
             sqrt(gate_used), gnss_gate_sigma_mode.c_str());
    // R3-L2: make visible whether the velocity observation can move anything at
    // all. The velocity prior of a tightly integrated LIO can be far more
    // confident than the receiver's velocity is accurate, in which case
    // gain = P/(P+R) ~ 0 and the observation is inert - the same failure mode A2
    // hit with the position prior, and the reason this line exists.
    if (use_vel)
    {
      // R4-4: the velocity block lives at 7-9 (see the H comment above); this
      // diagnostic used to read block (6,6) - the exposure-time variance.
      const double p_vel = sqrt(P_use.block<3, 3>(7, 7).diagonal().maxCoeff());
      const double g_v = p_vel * p_vel / (p_vel * p_vel + gnss_vel_sigma * gnss_vel_sigma);
      printf("[GNSS] update: vel |res_v|=%.3f m/s |dx_vel|=%.3f P_vel_eff=%.4f "
             "sigma_v=%.2f gain_v=%.3f lever=%.3f\n",
             gnss_vel_res_last, dx.segment<3>(7).norm(), p_vel, gnss_vel_sigma, g_v,
             gnss_vel_lever_last);
    }
    // T1-4: alignment-state convergence trace (the review's observability
    // deliverable), the auto/redesign rates in use, the discarded posterior
    // cross term, and the cumulative translation fold (pre-registered
    // criterion (2): total <= resid0 + k*b*T, EVAL_PROTOCOL 26.3).
    if (align_active)
      printf("[GNSS] align: psi=%.3f deg t=(%.2f, %.2f) Pa_diag=(%.2e, %.2e, %.2e) "
             "cross=%.2e q=(%.4f m/sqrt(s), %.4f deg/sqrt(s)) fold_t=%.3f m frozen=%d\n",
             align_psi_ * 57.295779513082323, enu_t_world(0), enu_t_world(1),
             align_state_.P(0, 0), align_state_.P(1, 1), align_state_.P(2, 2),
             align_cross_last_, align_q_pos_last_,
             align_q_yaw_last_ * 57.295779513082323, align_fold_t_total_,
             (int)align_frozen);
  }

  // Step 10: Covariance update (Joseph form for numerical stability)
  // P1-3: uses P_upd, so once an update lands the filter's own covariance
  // reflects the (now reduced) honest uncertainty instead of snapping back to
  // the over-confident LIO value.
  Matrix<double, DIM_STATE, DIM_STATE> I_KH =
      Matrix<double, DIM_STATE, DIM_STATE>::Identity() - K * H_use;
  _state.cov = I_KH * P_upd * I_KH.transpose() + K * R_use * K.transpose();
  clampAuxState();

  // Ensure covariance symmetry
  _state.cov = 0.5 * (_state.cov + _state.cov.transpose());

  // Successful update: if the window is over its limit, slide the anchor to the
  // corrected state so the next window measures drift from here.
  if (reanchor_due)
  {
    gnss_anchor_enu_ = z_meas_enu;
    gnss_anchor_world_ = _state.pos_end + _state.rot_end * gnss_extT;
    gnss_anchor_time_ = gnss_meas.timestamp;
  }

  // P1-3: an accepted epoch pays the drift account by what it actually applied
  // (|dx_pos|), not by the residual it saw - a millimetre correction must not
  // pretend the state was re-anchored. Rejected epochs leave the account
  // growing, which is the "uncorrected for tens of seconds" situation the
  // prior exists for. In steady state this self-balances: the gain rises just
  // enough that gain*res pays the b*dt accrual.
  if (gnss_prior_drift_en)
    gnss_drift_acc_ = gnssDriftPay(gnss_drift_acc_, dx.segment<3>(3).norm());
  gnss_ok_count++;
  // R3-L2 diagnostics (item 6.5/6.6): one record per epoch that USED the velocity
  // observation, so the residual can be related to the speed (it must go to ~0 at
  // standstill) and to the turn rate (the lever term is largest there).
  if (use_vel && pose_output_en && fout_gnss_pos.is_open())
    fout_gnss_pos << "DV " << (gnss_meas.timestamp - _first_lidar_time)
                  << " " << state_prop.vel_end.norm()
                  << " " << V3D(gnss_meas.vel_enu(0), gnss_meas.vel_enu(1), gnss_meas.vel_enu(2)).norm()
                  << " " << gnss_vel_res_last
                  << " " << gnss_vel_lever_last
                  << std::endl;
  return true;
}
