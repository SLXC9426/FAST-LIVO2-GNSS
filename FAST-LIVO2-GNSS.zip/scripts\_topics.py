#!/usr/bin/env python3
import rosbag

b = rosbag.Bag("/home/slxc9426/campus-01.bag")
info = b.get_type_and_topic_info()
for t, v in sorted(info.topics.items()):
    print(t, v.msg_type, v.message_count)
b.close()
