#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""GREAT-PVT .flt solution -> NavSatFix rosbag (generalised from the campus-02
converter that produced the original 30 s /gnss bag).

The .flt epochs are labelled in GPS seconds-of-week and carry ECEF positions:
    col0 = GPS TOW, col1..3 = X Y Z (m), col16 = ambiguity status
The mapper's timeline is UNIX, so each epoch is written at
    bag_time = GPS_TOW + OFFSET,  OFFSET = 604800*2129 + 315964800 - 18
i.e. the start of GPS week 2129 in UNIX time minus the 18 leap seconds. Using
the same constant as the existing converters keeps the new 1 Hz stream on exactly
the same timeline as the 30 s one, so the two can be compared and mixed.

Conventions copied from the original converter so the receiver treats the two
streams identically: status 5 for Fixed (else 2) and a cm-level reported
covariance, which gnss_processing deliberately distrusts (it falls back to the
fix-type table).

R3 stage 4 / item 6.2 adds an OPTIONAL velocity output. Pass --vel-topic to also
write the doppler velocity of the same epoch as a
geometry_msgs/TwistWithCovarianceStamped on its own topic (NavSatFix has no
velocity field). The velocity is written in ECEF: a velocity is a free vector, so
keeping it in ECEF lets the receiver rotate it into its own local ENU frame with
the same origin convention it already uses for positions, rather than this
converter guessing that convention. The formal V-RMS is carried in the
covariance for the record only - it is 10-80x below the measured disagreement on
Float epochs (docs/EVAL_PROTOCOL.md 11.1) - so the mapper must use a configured
sigma rather than this field. Default: no velocity topic, i.e. the behaviour
without --vel-topic is unchanged.

Usage: rtk_flt_to_bag.py <in.flt> <out.bag> [topic] [--shift SECONDS]
                         [--vel-topic TOPIC] [--tow-min TOW] [--tow-max TOW]
                         [--quality-csv PATH] [--position-cov synthetic|rms]

Quality export:
  --quality-csv writes a sidecar CSV with TOW, ECEF XYZ, velocity, XYZ-RMS,
  V-RMS, NSat, PDOP, sigma0, ambiguity status, ratio and BL. This is the
  per-epoch quality that the NavSatFix message cannot carry.
  --position-cov rms writes the ENU rotation of the ECEF diagonal XYZ-RMS as a
  full 3x3 covariance (type 3) instead of the synthetic cm-level diagonal.
  The default remains "synthetic" so existing bags keep their behaviour.

--tow-min/--tow-max clamp the GPS seconds-of-week range. A GREAT-PVT .flt covers
a whole observing session, but the sensor recording is only a window inside it;
playing the unfiltered bag would spend the whole play window (rosbag play -s/-u)
on epochs for which no LiDAR data exists. campus-01's window starts at TOW
180589, which is what the original 1 Hz bag used.
"""
import math
import csv
import sys

import rosbag
import genpy
from sensor_msgs.msg import NavSatFix
from geometry_msgs.msg import TwistWithCovarianceStamped

OFFSET = 604800 * 2129 + 315964800 - 18
A = 6378137.0
F = 1.0 / 298.257223563
E2 = F * (2.0 - F)


def ecef2lla(x, y, z):
    lon = math.atan2(y, x)
    p = math.sqrt(x * x + y * y)
    lat = math.atan2(z, p * (1 - E2))
    for _ in range(8):
        N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
        h = p / math.cos(lat) - N
        lat = math.atan2(z, p * (1 - E2 * N / (N + h)))
    N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
    return math.degrees(lat), math.degrees(lon), p / math.cos(lat) - N


def ecef_to_enu_rotation(lat_deg, lon_deg):
    """3x3 rotation mapping an ECEF vector to local ENU (E,N,U)."""
    lat, lon = math.radians(lat_deg), math.radians(lon_deg)
    sl, cl = math.sin(lat), math.cos(lat)
    so, co = math.sin(lon), math.cos(lon)
    return [[-so, co, 0.0],
            [-sl * co, -sl * so, cl],
            [cl * co, cl * so, sl]]


def rms_to_enu_covariance(lat_deg, lon_deg, x_rms, y_rms, z_rms):
    """Rotate an ECEF diagonal covariance (formal XYZ-RMS) into ENU.

    The .flt only carries per-axis ECEF RMS, not the cross terms; assuming a
    diagonal ECEF covariance is an approximation, but it is still far closer
    to the receiver's formal quality than the constant cm-level covariance.
    """
    R = ecef_to_enu_rotation(lat_deg, lon_deg)
    C = [[x_rms * x_rms, 0.0, 0.0],
         [0.0, y_rms * y_rms, 0.0],
         [0.0, 0.0, z_rms * z_rms]]
    RC = [[sum(R[i][k] * C[k][j] for k in range(3)) for j in range(3)] for i in range(3)]
    ENU = [[sum(RC[i][k] * R[j][k] for k in range(3)) for j in range(3)] for i in range(3)]
    return [ENU[i][j] for i in range(3) for j in range(3)]


def hms(s):
    s = s % 86400.0
    return "%02d:%02d:%06.3f" % (int(s // 3600), int(s % 3600 // 60), s % 60)


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        return 1
    src, dst = sys.argv[1], sys.argv[2]
    topic = sys.argv[3] if len(sys.argv) > 3 else "/gnss_rtk"
    shift = 0.0
    if "--shift" in sys.argv:
        shift = float(sys.argv[sys.argv.index("--shift") + 1])
    vel_topic = None
    if "--vel-topic" in sys.argv:
        vel_topic = sys.argv[sys.argv.index("--vel-topic") + 1]
    tow_min = float(sys.argv[sys.argv.index("--tow-min") + 1]) if "--tow-min" in sys.argv else None
    tow_max = float(sys.argv[sys.argv.index("--tow-max") + 1]) if "--tow-max" in sys.argv else None
    quality_csv = sys.argv[sys.argv.index("--quality-csv") + 1] if "--quality-csv" in sys.argv else None
    position_cov = "synthetic"
    if "--position-cov" in sys.argv:
        position_cov = sys.argv[sys.argv.index("--position-cov") + 1]
        if position_cov not in ("synthetic", "rms"):
            print("!! --position-cov must be synthetic or rms")
            return 1

    rows = []
    dropped = 0
    with open(src, errors="ignore") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            v = line.split()
            if len(v) < 17:
                continue
            tow = float(v[0])
            if (tow_min is not None and tow < tow_min) or (tow_max is not None and tow > tow_max):
                dropped += 1
                continue
            # cols: 0 TOW | 1-3 XYZ | 4-6 VxVyVz (ECEF m/s) | 7-9 XYZ-RMS |
            #       10-12 V-RMS | 13 NSat | 14 PDOP | 15 sigma0 | 16 AmbStatus
            #       17 Ratio | 18 BL | 19 Quality (optional)
            rows.append({
                "tow": tow,
                "x": float(v[1]), "y": float(v[2]), "z": float(v[3]),
                "vx": float(v[4]), "vy": float(v[5]), "vz": float(v[6]),
                "x_rms": float(v[7]), "y_rms": float(v[8]), "z_rms": float(v[9]),
                "vx_rms": float(v[10]), "vy_rms": float(v[11]), "vz_rms": float(v[12]),
                "nsat": int(float(v[13])), "pdop": float(v[14]),
                "sigma0": float(v[15]), "status": v[16],
                "ratio": float(v[17]) if len(v) > 17 else 0.0,
                "bl": float(v[18]) if len(v) > 18 else 0.0,
                "quality": int(float(v[19])) if len(v) > 19 else 0,
            })
    if not rows:
        print("!! no epochs parsed from", src)
        return 1
    fixed = sum(1 for r in rows if r["status"].lower().startswith("fix"))
    dt = (rows[-1]["tow"] - rows[0]["tow"]) / max(len(rows) - 1, 1)
    nz_vel = sum(1 for r in rows
                 if abs(r["vx"]) > 1e-9 or abs(r["vy"]) > 1e-9 or abs(r["vz"]) > 1e-9)
    print("epochs: %d  TOW %.1f..%.1f = %s..%s GPST  (%.2f Hz)  Fixed %d (%.0f%%)  nonzero_vel %d"
          % (len(rows), rows[0]["tow"], rows[-1]["tow"],
             hms(rows[0]["tow"]), hms(rows[-1]["tow"]),
             1.0 / dt, fixed, 100.0 * fixed / len(rows), nz_vel))
    print("bag time: %.3f..%.3f (UNIX, OFFSET %d)"
          % (rows[0]["tow"] + OFFSET, rows[-1]["tow"] + OFFSET, OFFSET))
    for key in ("nsat", "pdop", "sigma0", "x_rms", "y_rms", "z_rms"):
        vals = [r[key] for r in rows]
        print("  %s: min=%.4g median=%.4g max=%.4g"
              % (key, min(vals), sorted(vals)[len(vals) // 2], max(vals)))
    print("position covariance: %s"
          % ("ENU rotation of ECEF XYZ-RMS (type 3)" if position_cov == "rms"
             else "synthetic 0.02/0.02/0.05 m (type 2)"))

    if quality_csv:
        fields = ["tow", "t_unix", "x", "y", "z", "vx", "vy", "vz",
                  "x_rms", "y_rms", "z_rms", "vx_rms", "vy_rms", "vz_rms",
                  "nsat", "pdop", "sigma0", "status", "ratio", "bl", "quality"]
        with open(quality_csv, "w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            for r in rows:
                r["t_unix"] = r["tow"] + OFFSET
                w.writerow(r)
        print("quality CSV: %s" % quality_csv)
    if vel_topic:
        if nz_vel == 0:
            print("!! %s has no non-zero velocity columns: was it solved with "
                  "<doppler>true</doppler>? Writing a velocity topic anyway."
                  % src)
        print("velocity topic: %s (ECEF m/s, %d of %d epochs non-zero)"
              % (vel_topic, nz_vel, len(rows)))

    n, nv = 0, 0
    rms_fallback = 0
    with rosbag.Bag(dst, "w") as bag:
        for i, r in enumerate(rows):
            t, x, y, z = r["tow"], r["x"], r["y"], r["z"]
            lat, lon, h = ecef2lla(x, y, z)
            msg = NavSatFix()
            msg.header.seq = i + 1
            msg.header.frame_id = "gnss"
            msg.header.stamp = genpy.Time.from_sec(t + OFFSET + shift)
            msg.latitude, msg.longitude, msg.altitude = lat, lon, h
            msg.status.status = 5 if r["status"].lower().startswith("fix") else 2
            msg.status.service = 1
            if position_cov == "rms" and max(r["x_rms"], r["y_rms"], r["z_rms"]) > 0.0:
                msg.position_covariance = rms_to_enu_covariance(
                    lat, lon, r["x_rms"], r["y_rms"], r["z_rms"])
                msg.position_covariance_type = 3
            else:
                if position_cov == "rms":
                    rms_fallback += 1
                msg.position_covariance[0] = 0.02 * 0.02
                msg.position_covariance[4] = 0.02 * 0.02
                msg.position_covariance[8] = 0.05 * 0.05
                msg.position_covariance_type = 2
            bag.write(topic, msg, t=msg.header.stamp)
            n += 1
            if vel_topic:
                vm = TwistWithCovarianceStamped()
                vm.header = msg.header
                vm.twist.twist.linear.x = r["vx"]
                vm.twist.twist.linear.y = r["vy"]
                vm.twist.twist.linear.z = r["vz"]
                # formal variances of the ECEF velocity (record only)
                vm.twist.covariance[0] = r["vx_rms"] * r["vx_rms"]
                vm.twist.covariance[7] = r["vy_rms"] * r["vy_rms"]
                vm.twist.covariance[14] = r["vz_rms"] * r["vz_rms"]
                bag.write(vel_topic, vm, t=vm.header.stamp)
                nv += 1
    if rms_fallback:
        print("!! %d epochs had no XYZ-RMS; fell back to synthetic covariance"
              % rms_fallback)
    print("wrote %s: %d messages on %s%s"
          % (dst, n, topic, (", %d on %s" % (nv, vel_topic)) if vel_topic else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
