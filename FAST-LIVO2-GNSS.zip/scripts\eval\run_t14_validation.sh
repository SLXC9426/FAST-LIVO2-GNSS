#!/bin/bash
# T1-4 method-default validation batch: ONE method default (align state, auto
# sigma_yaw0, auto tau=150 s), THREE datasets - the answer to "must generalise
# beyond the dataset it was developed on".
#
# Arms (all with the state ON, no explicit Q overrides - pure auto):
#   c01 full    : great_campus01_alignstate                      x3 (re-confirm
#                 under the unified auto default; the 18-run batch used the
#                 explicit q3/1.0deg overrides)
#   c03 0-400 s : great_campus03 (base) x3  vs  great_campus03_alignstate x3
#                 (held-out dataset; c03-on locks per R4-2b, residual gate has
#                 margin 2.83 m < 5 m)
#   c02 full + 1 Hz stream: great_campus02_gate_adaptive (base, r1 exists as
#                 t12x_c02_rtk1hz_adapt_r1) x2 more, vs
#                 great_campus02_gate_adaptive_alignstate x3
#                 (the §23 prediction: the alignment state is c02's only
#                 channel with gain once sigma is honest)
#
# Usage: run_t14_validation.sh [summary]
# BATCH prefixes every tag. The default is a NEW batch, so a rerun cannot pool
# its rows into the historical t14v_* groups (the val1/val2 tag collision that
# contaminated §27.1).
export LANG=C.UTF-8
set -o pipefail
SUM=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/t1_4_val4/val_summary.txt}
BATCH=${BATCH:-t14x}
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
SEG=$REPO/scripts/eval/segment_run.sh
EVALDIR=$REPO/scripts/eval
REG=$HOME/catkin_ws/src/fast_livo/Log/result/registry.csv
RTK01=$HOME/datasets/GREAT/campus01_rtk1hz.bag
RTK03=$HOME/datasets/GREAT/gnss_c03.bag
RTK02=$HOME/datasets/GREAT/campus02_rtk1hz.bag
mkdir -p "$(dirname "$SUM")"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

: > "$SUM"
echo "=== T1-4 method-default validation (auto tau/sigma0, state on) | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum $HOME/catkin_ws/devel/lib/liblaser_mapping.so | cut -c1-8)" | tee -a "$SUM"

echo "--- c01 full x3: same-binary base (state absent) ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus01 gnss 0 607 "${BATCH}_c01_base_r$k" "$RTK01" "" great_campus01 2>&1 | tee -a "$SUM"
done
echo "--- c01 full x3: auto alignstate ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus01 gnss 0 607 "${BATCH}_c01_auto_r$k" "$RTK01" "" great_campus01_alignstate 2>&1 | tee -a "$SUM"
done

echo "--- c03 0-400 s: base x3 ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus03 gnss 0 400 "${BATCH}_c03_base_r$k" "$RTK03" "" great_campus03 2>&1 | tee -a "$SUM"
done
echo "--- c03 0-400 s: alignstate x3 ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus03 gnss 0 400 "${BATCH}_c03_auto_r$k" "$RTK03" "" great_campus03_alignstate 2>&1 | tee -a "$SUM"
done

echo "--- c02 full + 1Hz: adaptive gate base x3 ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus02 gnss 0 806 "${BATCH}_c02_base_r$k" "$RTK02" "/gnss_rtk" great_campus02_gate_adaptive 2>&1 | tee -a "$SUM"
done
echo "--- c02 full + 1Hz: adaptive gate + alignstate x3 ---" | tee -a "$SUM"
for k in 1 2 3; do
  bash "$SEG" campus02 gnss 0 806 "${BATCH}_c02_auto_r$k" "$RTK02" "/gnss_rtk" great_campus02_gate_adaptive_alignstate 2>&1 | tee -a "$SUM"
done

VRC=0
(
  echo ""
  echo "=== verdicts ==="
  echo "-- c03 base vs auto (held-out dataset) --"
  python3 "$EVALDIR/verdict.py" --registry "$REG" "${BATCH}_c03_base" "${BATCH}_c03_auto" --field r2_full --field r2_mov --field r2_stat_gf 2>&1 || VRC=1
  echo "-- c02 base vs auto (1 Hz stream) --"
  python3 "$EVALDIR/verdict.py" --registry "$REG" "${BATCH}_c02_base" "${BATCH}_c02_auto" --field r2_full --field r2_mov --field r2_stat_gf 2>&1 || VRC=1
  echo "-- c01 base vs auto (same binary) --"
  python3 "$EVALDIR/verdict.py" --registry "$REG" "${BATCH}_c01_base" "${BATCH}_c01_auto" --field r2_steady --field r2_stat_gf --field r2_full 2>&1 || VRC=1
  echo ""
  echo "=== pre-registered mechanism criteria (EVAL_PROTOCOL 26.3) ==="
  echo "criterion 1: K_a0 <= kmax (P_a0 vs R at lock; q and fold below)"
  echo "criterion 2: fold_t_total <= resid0 + 2*b*T"
  for tag in "${BATCH}_c01_auto" "${BATCH}_c03_auto" "${BATCH}_c02_auto"; do
    for f in "$HOME"/seg_${tag}_r*.log; do
      [ -f "$f" ] || continue
      echo "-- $(basename "$f")"
      grep -m1 "alignment: LOCKED" "$f" | sed 's/^/   /'
      grep "GNSS. align:" "$f" | tail -1 | sed 's/^/   /'
    done
  done
  exit $VRC
) | tee -a "$SUM"
VERDICT_RC=${PIPESTATUS[0]}
echo "T14_VAL_DONE $(date +%T)" | tee -a "$SUM"
exit $VERDICT_RC
