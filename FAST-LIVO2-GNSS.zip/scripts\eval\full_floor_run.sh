#!/bin/bash
# A3-5 / EVAL_PROTOCOL §5: measure the FULL-LENGTH metric noise floor.
#
# Why: two runs of one arm on ONE binary differ only by the estimator's internal
# chaotic amplification (protocol §2(b): same input, same binary, the two
# trajectories part after ~3.4 s at 1e-6 m and end ~2.5 m apart over 607 s).
# The metric difference between such a pair IS the noise floor for that segment
# length, and it replaces the cross-build estimate (~0.4 m) that had never been
# measured (protocol §5, R3_NEXT_STEPS P0-1).
#
# The repeats run back-to-back in one invocation and the library hashes are
# recorded before and after, because a floor is only a floor if the binary did
# not change between the runs.
#
# Usage:
#   full_floor_run.sh <campus01|campus02|campus03> "<arms>" <repeats> [summary]
#     arms: space-separated list, e.g. "livo gnss"
#   full_floor_run.sh campus01 "livo gnss" 2 /mnt/c/.../p0_1_floor/c01_floor.txt
#
# Each run writes Log/result/<seq>_floor_<arm>_r<k>.txt and appends its metrics
# to Log/result/registry.csv (via segment_run.sh). Afterwards summarise with
# scripts/eval/floor_stats.py.
export LANG=C.UTF-8
SEQ=${1:?usage: full_floor_run.sh <seq> \"<arms>\" <repeats> [summary]}
ARMS=${2:?usage: full_floor_run.sh <seq> \"<arms>\" <repeats> [summary]}
REPEATS=${3:-2}
SUM=${4:-$HOME/floor_${SEQ}.txt}
HERE="$(cd "$(dirname "$0")" && pwd)"
SEG="$HERE/segment_run.sh"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

# Segment length and the GNSS bag each sequence needs when a fix stream is
# played alongside the main bag (see EVAL_PROTOCOL §6.1 / §9.4).
case "$SEQ" in
  campus01) DUR=607;  RTKBAG=$HOME/datasets/GREAT/campus01_rtk1hz.bag ;;
  campus02) DUR=806;  RTKBAG=$HOME/datasets/GREAT/gnss_c02_trim.bag ;;
  campus03) DUR=1255; RTKBAG=$HOME/datasets/GREAT/gnss_c03.bag ;;
  *) echo "unknown sequence $SEQ"; exit 1 ;;
esac

libhash () { md5sum "$HOME"/catkin_ws/devel/lib/lib*.so | awk '{printf "%s:%s ", substr($1,1,8), $2}'; }

mkdir -p "$(dirname "$SUM")"
: > "$SUM"
{
  echo "=== full-length noise floor | seq=$SEQ arms=[$ARMS] repeats=$REPEATS ==="
  echo "start       $(date +%F' '%T)  (local)"
  echo "libs before $(libhash)"
} | tee -a "$SUM"

for arm in $ARMS; do
  for k in $(seq 1 "$REPEATS"); do
    TAG=${SEQ}_floor_${arm}_r${k}
    echo "--- $TAG start $(date +%T)" | tee -a "$SUM"
    bash "$SEG" "$SEQ" "$arm" 0 "$DUR" "$TAG" "$RTKBAG" "" "great_$SEQ" 2>&1 | tee -a "$SUM"
    echo "--- $TAG end   $(date +%T)" | tee -a "$SUM"
  done
done

{
  echo "libs after  $(libhash)"
  echo "end         $(date +%F' '%T)  (local)"
} | tee -a "$SUM"

# T0-2: automatic verdict line for the arms that were repeated (n<3 => INVALID;
# the floor itself is the threshold, so anything else is NOT RESOLVABLE here by
# construction -- this line documents that the batch cannot decide arm order).
if [ "$REPEATS" -ge 1 ]; then
  for arm in $ARMS; do
    python3 "$HERE/verdict.py" --registry "$HOME/catkin_ws/src/fast_livo/Log/result/registry.csv" \
        "${SEQ}_floor_${arm}" 2>&1 | tee -a "$SUM"
  done
fi
echo "FLOOR_RUN_DONE  (summary: $SUM)"
