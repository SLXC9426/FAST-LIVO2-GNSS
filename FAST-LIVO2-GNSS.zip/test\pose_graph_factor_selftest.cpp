/*
R5 audit: finite-difference check of every Pose3 factor's analytic Jacobian.

GTSAM Pose3 retract uses [rotation, translation] with the translation
perturbation in the body frame: retract([0,v]) changes t by R*v. Therefore
d(translation)/d(tangent) = [0, R]. The pre-R5 factors used [0, I], which this
test must catch.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/pose_graph_factor_selftest

Exit code 0 = all Jacobians match, 1 = failure.
*/

#include "pose_graph_factors.h"

#include <gtsam/geometry/Pose3.h>
#include <gtsam/linear/NoiseModel.h>

#include <cmath>
#include <cstdio>
#include <random>
#include <string>

namespace
{

int g_failures = 0;

void check(const std::string &name, double err, double tol)
{
  const bool ok = err <= tol;
  std::printf("%s  %-46s err=%.3e tol=%.1e\n", ok ? "ok  " : "FAIL",
              name.c_str(), err, tol);
  if (!ok) ++g_failures;
}

gtsam::Pose3 randomPose(std::mt19937 &rng)
{
  std::uniform_real_distribution<double> a(-0.8, 0.8);
  std::normal_distribution<double> p(0.0, 2.0);
  return gtsam::Pose3(
      gtsam::Rot3::RzRyRx(a(rng), a(rng), a(rng)),
      gtsam::Point3(p(rng), p(rng), p(rng)));
}

gtsam::Vector3 randomVec(std::mt19937 &rng)
{
  std::normal_distribution<double> n(0.0, 1.0);
  return gtsam::Vector3(n(rng), n(rng), n(rng));
}

const double kEps = 1e-6;
const double kTol = 1e-4;

void checkPoseColumns(const std::string &name, const gtsam::Matrix &H,
                      const std::vector<gtsam::Vector> &fd)
{
  double worst = 0.0;
  for (int c = 0; c < 6; ++c)
    worst = std::max(worst, (H.col(c) - fd[c]).norm());
  check(name + " pose H", worst, kTol);
}

}  // namespace

int main()
{
  std::mt19937 rng(20261104u);

  // ---- AbsPosFactor --------------------------------------------------------
  {
    const gtsam::Pose3 T = randomPose(rng);
    const gtsam::Point3 z(3.0, -1.0, 2.0);
    fast_livo::AbsPosFactor f(0, z,
                              gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    gtsam::Vector e0 = f.evaluateError(T, boost::none);
    gtsam::Matrix H;
    f.evaluateError(T, boost::optional<gtsam::Matrix &>(H));
    std::vector<gtsam::Vector> fd(6);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      const gtsam::Vector e = f.evaluateError(T.retract(d), boost::none);
      fd[k] = (e - e0) / kEps;
    }
    checkPoseColumns("AbsPos", H, fd);
  }

  // ---- AbsPosXY / AbsPosZ --------------------------------------------------
  {
    const gtsam::Pose3 T = randomPose(rng);
    fast_livo::AbsPosXYFactor fxy(
        0, Eigen::Vector2d(2.0, -3.0),
        gtsam::noiseModel::Isotropic::Sigma(2, 1.0));
    fast_livo::AbsPosZFactor fz(0, 1.5,
                                gtsam::noiseModel::Isotropic::Sigma(1, 1.0));
    const gtsam::Vector e0x = fxy.evaluateError(T, boost::none);
    const gtsam::Vector e0z = fz.evaluateError(T, boost::none);
    gtsam::Matrix Hx, Hz;
    fxy.evaluateError(T, boost::optional<gtsam::Matrix &>(Hx));
    fz.evaluateError(T, boost::optional<gtsam::Matrix &>(Hz));
    double wx = 0.0, wz = 0.0;
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      const gtsam::Pose3 Tp = T.retract(d);
      wx = std::max(wx, (Hx.col(k) -
                         (fxy.evaluateError(Tp, boost::none) - e0x) / kEps).norm());
      wz = std::max(wz, (Hz.col(k) -
                         (fz.evaluateError(Tp, boost::none) - e0z) / kEps).norm());
    }
    check("AbsPosXY pose H", wx, kTol);
    check("AbsPosZ pose H", wz, kTol);
  }

  // ---- InterpolatedAbsPosFactor (A1) --------------------------------------
  {
    // Endpoint reduction: at alpha = 0 the prediction must be Ti's antenna,
    // at alpha = 1 Tj's. This catches a wrong Exp/Log composition even before
    // the Jacobian check.
    const gtsam::Pose3 Ti = randomPose(rng);
    const gtsam::Pose3 Tj = randomPose(rng);
    const Eigen::Vector3d lever(0.2, -0.4, 0.1);
    const gtsam::Point3 z(0.0, 0.0, 0.0);
    auto antenna = [&](const gtsam::Pose3 &T) {
      return T.translation() + T.rotation().matrix() * lever;
    };
    fast_livo::InterpolatedAbsPosFactor f0(
        0, 1, 0.0, z, gtsam::Point3(lever.x(), lever.y(), lever.z()),
        gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    fast_livo::InterpolatedAbsPosFactor f1(
        0, 1, 1.0, z, gtsam::Point3(lever.x(), lever.y(), lever.z()),
        gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    const gtsam::Vector e0 = f0.evaluateError(Ti, Tj, boost::none, boost::none);
    const gtsam::Vector e1 = f1.evaluateError(Ti, Tj, boost::none, boost::none);
    check("InterpolatedAbsPos alpha=0 endpoint",
          (e0 - gtsam::Vector3(antenna(Ti))).norm(), 1e-12);
    check("InterpolatedAbsPos alpha=1 endpoint",
          (e1 - gtsam::Vector3(antenna(Tj))).norm(), 1e-12);

    // 20 random pose pairs / alphas, central-difference Jacobian check.
    std::uniform_real_distribution<double> alpha_dist(0.0, 1.0);
    std::normal_distribution<double> z_dist(0.0, 2.0);
    double worst1 = 0.0, worst2 = 0.0;
    for (int trial = 0; trial < 20; ++trial)
    {
      const gtsam::Pose3 A = randomPose(rng);
      const gtsam::Pose3 B = randomPose(rng);
      const double alpha = alpha_dist(rng);
      const gtsam::Point3 meas(z_dist(rng), z_dist(rng), z_dist(rng));
      const Eigen::Vector3d lv(z_dist(rng) * 0.1, z_dist(rng) * 0.1,
                               z_dist(rng) * 0.1);
      fast_livo::InterpolatedAbsPosFactor f(
          0, 1, alpha, meas, gtsam::Point3(lv.x(), lv.y(), lv.z()),
          gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
      const gtsam::Vector ref = f.evaluateError(A, B, boost::none, boost::none);
      gtsam::Matrix H1, H2;
      f.evaluateError(A, B, boost::optional<gtsam::Matrix &>(H1),
                      boost::optional<gtsam::Matrix &>(H2));
      for (int k = 0; k < 6; ++k)
      {
        gtsam::Vector6 d = gtsam::Vector6::Zero();
        d(k) = kEps;
        const gtsam::Vector ep =
            f.evaluateError(A.retract(d), B, boost::none, boost::none);
        const gtsam::Vector em =
            f.evaluateError(A.retract(-d), B, boost::none, boost::none);
        worst1 = std::max(worst1, (H1.col(k) - (ep - em) / (2.0 * kEps)).norm());
        const gtsam::Vector fp =
            f.evaluateError(A, B.retract(d), boost::none, boost::none);
        const gtsam::Vector fm =
            f.evaluateError(A, B.retract(-d), boost::none, boost::none);
        worst2 = std::max(worst2, (H2.col(k) - (fp - fm) / (2.0 * kEps)).norm());
      }
    }
    std::printf("      worst |H_i - FD| = %.3e, |H_j - FD| = %.3e (20 poses)\n",
                worst1, worst2);
    check("InterpolatedAbsPos H_i (20 poses)", worst1, kTol);
    check("InterpolatedAbsPos H_j (20 poses)", worst2, kTol);
  }

  // ---- AbsRotFactor --------------------------------------------------------
  {
    const gtsam::Pose3 T = randomPose(rng);
    fast_livo::AbsRotFactor f(
        0, T.rotation() * gtsam::Rot3::RzRyRx(0.1, -0.1, 0.05),
        gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    const gtsam::Vector e0 = f.evaluateError(T, boost::none);
    gtsam::Matrix H;
    f.evaluateError(T, boost::optional<gtsam::Matrix &>(H));
    std::vector<gtsam::Vector> fd(6);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd[k] = (f.evaluateError(T.retract(d), boost::none) - e0) / kEps;
    }
    checkPoseColumns("AbsRot", H, fd);
  }

  // ---- RelPosFactor --------------------------------------------------------
  {
    const gtsam::Pose3 Ti = randomPose(rng), Tj = randomPose(rng);
    fast_livo::RelPosFactor f(
        0, 1, gtsam::Point3(1.0, 2.0, 3.0),
        gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    const gtsam::Vector e0 = f.evaluateError(Ti, Tj, boost::none, boost::none);
    gtsam::Matrix H1, H2;
    f.evaluateError(Ti, Tj, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2));
    std::vector<gtsam::Vector> fd1(6), fd2(6);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(Ti.retract(d), Tj, boost::none, boost::none) - e0) / kEps;
      fd2[k] = (f.evaluateError(Ti, Tj.retract(d), boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("RelPos i", H1, fd1);
    checkPoseColumns("RelPos j", H2, fd2);
  }

  // ---- TdddFactor (legacy scalar, currently unused by the graph) ------------
  {
    const gtsam::Pose3 Ti = randomPose(rng), Tj = randomPose(rng);
    const Eigen::Vector3d g(0.3, -0.2, 0.9);
    const double y = 1.7;
    fast_livo::TdddFactor f(0, 1, g, y,
                            gtsam::noiseModel::Isotropic::Sigma(1, 1.0));
    const gtsam::Vector e0 = f.evaluateError(Ti, Tj, boost::none, boost::none);
    gtsam::Matrix H1, H2;
    f.evaluateError(Ti, Tj, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2));
    std::vector<gtsam::Vector> fd1(6), fd2(6);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(Ti.retract(d), Tj, boost::none, boost::none) - e0) / kEps;
      fd2[k] = (f.evaluateError(Ti, Tj.retract(d), boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("TdddFactor i", H1, fd1);
    checkPoseColumns("TdddFactor j", H2, fd2);
  }

  // ---- TdddBlockFactor -----------------------------------------------------
  {
    const gtsam::Pose3 Ti = randomPose(rng), Tj = randomPose(rng);
    std::vector<Eigen::Vector3d> g = {Eigen::Vector3d(0.3, 0.4, 0.5),
                                      Eigen::Vector3d(-0.2, 0.1, 0.9)};
    std::vector<double> y = {1.0, -2.0};
    fast_livo::TdddBlockFactor f(
        0, 1, g, y, gtsam::noiseModel::Isotropic::Sigma(2, 1.0));
    const gtsam::Vector e0 = f.evaluateError(Ti, Tj, boost::none, boost::none);
    gtsam::Matrix H1, H2;
    f.evaluateError(Ti, Tj, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2));
    std::vector<gtsam::Vector> fd1(6), fd2(6);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(Ti.retract(d), Tj, boost::none, boost::none) - e0) / kEps;
      fd2[k] = (f.evaluateError(Ti, Tj.retract(d), boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("TdddBlock i", H1, fd1);
    checkPoseColumns("TdddBlock j", H2, fd2);
  }

  // ---- PoseVelFactor -------------------------------------------------------
  {
    const gtsam::Pose3 Ti = randomPose(rng), Tj = randomPose(rng);
    const gtsam::Vector3 vi = randomVec(rng), vj = randomVec(rng);
    const double dt = 1.0;
    fast_livo::PoseVelFactor f(
        0, 1, 2, 3, dt, gtsam::noiseModel::Isotropic::Sigma(3, 1.0));
    const gtsam::Vector e0 =
        f.evaluateError(Ti, Tj, vi, vj, boost::none, boost::none, boost::none,
                        boost::none);
    gtsam::Matrix H1, H2, H3, H4;
    f.evaluateError(Ti, Tj, vi, vj, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2),
                    boost::optional<gtsam::Matrix &>(H3),
                    boost::optional<gtsam::Matrix &>(H4));
    std::vector<gtsam::Vector> fd1(6), fd2(6), fd3(3), fd4(3);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(Ti.retract(d), Tj, vi, vj, boost::none,
                                boost::none, boost::none, boost::none) - e0) / kEps;
      fd2[k] = (f.evaluateError(Ti, Tj.retract(d), vi, vj, boost::none,
                                boost::none, boost::none, boost::none) - e0) / kEps;
    }
    for (int k = 0; k < 3; ++k)
    {
      gtsam::Vector3 d = gtsam::Vector3::Zero();
      d(k) = kEps;
      fd3[k] = (f.evaluateError(Ti, Tj, vi + d, vj, boost::none, boost::none,
                                boost::none, boost::none) - e0) / kEps;
      fd4[k] = (f.evaluateError(Ti, Tj, vi, vj + d, boost::none, boost::none,
                                boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("PoseVel i", H1, fd1);
    checkPoseColumns("PoseVel j", H2, fd2);
    double w3 = 0.0, w4 = 0.0;
    for (int k = 0; k < 3; ++k)
    {
      w3 = std::max(w3, (H3.col(k) - fd3[k]).norm());
      w4 = std::max(w4, (H4.col(k) - fd4[k]).norm());
    }
    check("PoseVel vi", w3, kTol);
    check("PoseVel vj", w4, kTol);
  }

  // ---- BoundaryJointFactor -------------------------------------------------
  {
    const gtsam::Pose3 T = randomPose(rng);
    const gtsam::Pose3 T0 = T * gtsam::Pose3(
                                    gtsam::Rot3::RzRyRx(0.02, -0.01, 0.03),
                                    gtsam::Point3(0.1, -0.2, 0.3));
    const gtsam::Vector3 v = randomVec(rng);
    const gtsam::Vector3 v0 = v + gtsam::Vector3(0.1, -0.1, 0.05);
    fast_livo::BoundaryJointFactor f(
        0, 1, T0, v0, gtsam::noiseModel::Isotropic::Sigma(9, 1.0));
    const gtsam::Vector e0 =
        f.evaluateError(T, v, boost::none, boost::none);
    gtsam::Matrix H1, H2;
    f.evaluateError(T, v, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2));
    std::vector<gtsam::Vector> fd1(6), fd2(3);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(T.retract(d), v, boost::none, boost::none) -
                e0) / kEps;
    }
    for (int k = 0; k < 3; ++k)
    {
      gtsam::Vector3 d = gtsam::Vector3::Zero();
      d(k) = kEps;
      fd2[k] = (f.evaluateError(T, v + d, boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("BoundaryJoint pose", H1, fd1);
    double w2 = 0.0;
    for (int k = 0; k < 3; ++k)
      w2 = std::max(w2, (H2.col(k) - fd2[k]).norm());
    check("BoundaryJoint vel", w2, kTol);
  }

  // ---- TdddBlockVelFactor --------------------------------------------------
  {
    const gtsam::Pose3 Ti = randomPose(rng), Tj = randomPose(rng);
    const gtsam::Vector3 vi = randomVec(rng), vj = randomVec(rng);
    std::vector<Eigen::Vector3d> g = {Eigen::Vector3d(0.2, -0.3, 0.8),
                                      Eigen::Vector3d(0.5, 0.1, -0.4)};
    std::vector<double> y = {0.5, -1.5};
    fast_livo::TdddBlockVelFactor f(
        0, 1, 2, 3, 0.1, -0.05, Eigen::Vector3d(0.1, -0.2, 0.3), g, y,
        gtsam::noiseModel::Isotropic::Sigma(2, 1.0));
    const gtsam::Vector e0 =
        f.evaluateError(Ti, Tj, vi, vj, boost::none, boost::none, boost::none,
                        boost::none);
    gtsam::Matrix H1, H2, H3, H4;
    f.evaluateError(Ti, Tj, vi, vj, boost::optional<gtsam::Matrix &>(H1),
                    boost::optional<gtsam::Matrix &>(H2),
                    boost::optional<gtsam::Matrix &>(H3),
                    boost::optional<gtsam::Matrix &>(H4));
    std::vector<gtsam::Vector> fd1(6), fd2(6), fd3(3), fd4(3);
    for (int k = 0; k < 6; ++k)
    {
      gtsam::Vector6 d = gtsam::Vector6::Zero();
      d(k) = kEps;
      fd1[k] = (f.evaluateError(Ti.retract(d), Tj, vi, vj, boost::none,
                                boost::none, boost::none, boost::none) - e0) / kEps;
      fd2[k] = (f.evaluateError(Ti, Tj.retract(d), vi, vj, boost::none,
                                boost::none, boost::none, boost::none) - e0) / kEps;
    }
    for (int k = 0; k < 3; ++k)
    {
      gtsam::Vector3 d = gtsam::Vector3::Zero();
      d(k) = kEps;
      fd3[k] = (f.evaluateError(Ti, Tj, vi + d, vj, boost::none, boost::none,
                                boost::none, boost::none) - e0) / kEps;
      fd4[k] = (f.evaluateError(Ti, Tj, vi, vj + d, boost::none, boost::none,
                                boost::none, boost::none) - e0) / kEps;
    }
    checkPoseColumns("TdddBlockVel i", H1, fd1);
    checkPoseColumns("TdddBlockVel j", H2, fd2);
    double w3 = 0.0, w4 = 0.0;
    for (int k = 0; k < 3; ++k)
    {
      w3 = std::max(w3, (H3.col(k) - fd3[k]).norm());
      w4 = std::max(w4, (H4.col(k) - fd4[k]).norm());
    }
    check("TdddBlockVel vi", w3, kTol);
    check("TdddBlockVel vj", w4, kTol);
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: all Pose3 factor Jacobians\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
