import io
import os

CFG = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config")


def load(name):
    return io.open(os.path.join(CFG, name), encoding="utf-8").read()


def save(name, txt):
    io.open(os.path.join(CFG, name), "w", encoding="utf-8").write(txt)
    print("wrote", name)


# occ_only: occlusion.en + LIO occlusion, NO robust kernel, NO vio occlusion
txt = load("great_campus01_occlusion.yaml")
txt = txt.replace("robust_kernel_type: 1", "robust_kernel_type: 0")
txt = txt.replace("vio_en: true", "vio_en: false")
save("great_campus01_occ_only.yaml", txt)

# robust_only: robust kernel only, NO occlusion
txt = load("great_campus01_baseline.yaml")
txt = txt.replace("robust_kernel_type: 0", "robust_kernel_type: 1")
txt = txt.replace("occlusion:\n  en: false", "occlusion:\n  en: false")
save("great_campus01_robust_only.yaml", txt)

# occ_lio_only: occlusion.en true, vio false, robust kernel ON (original P1 intent)
txt = load("great_campus01_occlusion.yaml")
txt = txt.replace("vio_en: true", "vio_en: false")
save("great_campus01_occ_lio_only.yaml", txt)
