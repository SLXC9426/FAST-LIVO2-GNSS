#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 4 GNSS-quality series: per-30 s DD code/phase residual vs FIXBASE-RTK.

The 1 Hz CSV supplies the DD observations; the 30 s FIXBASE-RTK .flt supplies a
high-quality rover position at the common epochs. Code residual = dd_code -
dd_geom; phase residual = dd_phase - dd_geom minus a per-pair constant.
"""
import csv
import math
import os
import statistics
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rtk_preprocess import gps_sow, load_flt_epochs

CSV = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
FLT = "/home/slxc9426/great_pvt/result/FIXBASE-RTK.flt"
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/metrics/phase4_gnss_quality.csv"
BASE = np.array([-2267749.9279, 5009154.2407, 3221290.6333])


def main():
    groups = {}
    with open(CSV, newline="") as f:
        for r in csv.DictReader(f):
            groups.setdefault(round(float(r["t_gps"]), 3), []).append(r)
    flt = load_flt_epochs(FLT)
    rows = []
    for t, rr in sorted(groups.items()):
        sow = gps_sow(t)
        fs, pos, status = min(flt, key=lambda x: abs(x[0] - sow))
        if abs(fs - sow) > 0.05:
            continue
        code = []
        for r in rr:
            sat = np.array([float(r["sat_x"]), float(r["sat_y"]), float(r["sat_z"])])
            ref = np.array([float(r["ref_x"]), float(r["ref_y"]), float(r["ref_z"])])
            rr_s = np.linalg.norm(sat - pos)
            rr_r = np.linalg.norm(ref - pos)
            rb_s = np.linalg.norm(sat - BASE)
            rb_r = np.linalg.norm(ref - BASE)
            g = (rr_s - rb_s) - (rr_r - rb_r)
            code.append(float(r["dd_code"]) - g)
        code = np.array(code)
        rows.append(dict(t_unix=float(rr[0]["t_unix"]), sow=sow, status=status,
                         n_pairs=len(rr), slips=sum(int(r["slip"]) for r in rr),
                         code_rms=float(np.sqrt(np.mean(code ** 2)))))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    with open(OUT, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"wrote {OUT} ({len(rows)} epochs)")
    for r in rows:
        print(f"  t={r['t_unix']:.0f} {r['status']:5s} n={r['n_pairs']:2d} "
              f"slips={r['slips']:2d} code={r['code_rms']:.2f}")


if __name__ == "__main__":
    main()
