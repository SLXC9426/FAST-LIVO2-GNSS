# 位姿图 + 回环检测（iSAM2/GTSAM）可行性与执行方案

> 日期：2026-10-17
> 依据：`docs/R6_STATE.md`、`docs/GV1_METHOD.md`、`docs/ONBOARD_EXECUTION_PLAN.md`
> 结论：**技术上可行，环境已验证；oracle 收益门已于 2026-10-17 执行，未通过，回环线关闭。**
>
> **执行结果（2026-10-17）**：c01 full −26.9% 但 steady +15.4%；c02 full/steady
> −17.0%/−14.9%（c02 两项均低于 20%）；无数据集满足 full/steady 同时 >20%，
> `GATE_PASS=0`。不实现 ScanContext，不做 iSAM2 全历史+回环；资源转 P2
> 固定滞后图与 c02 局部 RTK 离群模型。完整数据见 `docs/LOOP_ORACLE_REPORT.md`。

## 1. 环境验证（已实测）

- GTSAM **4.2.2** 已源码安装在 WSL `/usr/local`：
  - `/usr/local/include/gtsam/nonlinear/ISAM2.h`
  - `/usr/local/include/gtsam/slam/BetweenFactor.h`
  - `/usr/local/lib/libgtsam.so.4.2.2`、`/usr/local/lib/cmake/GTSAM/`
- 最小 C++ 程序（`PriorFactor<Pose3>` + 10 个 `BetweenFactor<Pose3>` +
  `ISAM2` + 回环 `BetweenFactor(x10,x0,identity)`）已编译运行：
  - 回环前 x10 漂移 (8.64, 4.17)；
  - 回环 + 5 次 iSAM2 更新后 x10 = (−1.31, 1.29)，回环因子确实参与优化。
- 依赖：系统 Boost 1.71、METIS；编译需 `-I/usr/include/eigen3 -I/usr/local/include
  -L/usr/local/lib -lgtsam -Wl,-rpath,/usr/local/lib`。
- **没有 GTSAM Python 绑定**（`import gtsam` 失败）：只能 C++，或另建 Python 绑定；
  机载建议 C++。
- ARM 目标板：GTSAM 需源码交叉构建；若构建困难，Ceres 1.14 可做批量位姿图，
  但 iSAM2 增量只有 GTSAM 提供。

## 2. 数据上的回环潜力

用参考轨迹、剔除静止段、仅运动段、>60 s 时间差、水平 <5 m：

| 序列 | 原始（含静止自配对） | **仅运动段** |
|---|---:|---:|
| c01 | 55.9% | **33.6%** |
| c02 | 61.2% | **41.7%** |
| c03 | 23.9% | **0.7%** |

- c01/c02 值得做；**c03 不是回环候选**（23.9% 主要是静止自配对）。
- 回环检测的验收只能用 c01/c02；c03 作为“无回环负对照”，不能因为没加回环
  而判失败。

## 3. 架构：Pose3 + iSAM2

### 3.1 图模型

变量：每个关键帧 `Pose3 T_w_b`（6-DoF）。

因子：

1. **LIO 相对因子**：`BetweenFactor<Pose3>(x_i, x_{i+1}, T_i^{-1}T_{i+1})`，
   来自纯 LIO 相对位姿（避免 RTK 重复计数；在线用方案 A/B，见
   `ONLINE_GRAPH_DESIGN.md`）。
2. **RTK 绝对位置因子**：自定义 `GPSFactor`，残差 `p_i + R_i*lever - rtk_i`，
   水平/垂直分开；自动 σ_rtk/σ_odom、Huber δ=3（沿用 v1）。
3. **回环因子**：`BetweenFactor<Pose3>(x_i, x_j, T_loop)`，协方差来自 ICP/GICP
   拟合质量；鲁棒核（Huber/Geman-McClure）或 switchable constraint。
4. **首帧先验**：固定规范自由度。

求解：`ISAM2` 增量更新；回环因子在检测到后追加，触发局部重线性化。
离线全历史批量可用 `LevenbergMarquardtOptimizer` 做对照。

### 3.2 回环检测管线

```text
关键帧 LiDAR → 描述子（ScanContext/Scan Context++ 或 LiDAR Iris）
  → KD-tree 候选（时间差 >60 s、水平距离 <5 m、非静止）
  → RTK 先验消歧（候选相对位移与 RTK 粗对齐一致）
  → 几何验证（GICP/ICP；fitness、inlier、重叠率）
  → 回环因子 + 协方差（fitness 映射）
  → iSAM2 增量更新 + 误回环护栏
```

- 描述子：优先 ScanContext（旋转不变、VLP-16 可用）；仓库无现成实现，
  需移植/自写。
- 误回环护栏：
  1. RTK 先验不一致直接拒绝；
  2. ICP fitness/重叠率不达标拒绝；
  3. 加入后回环残差过大回滚；
  4. 注入假回环测试（必须能拒绝）；
  5. 同一关键帧最多一个回环，避免因子爆炸。
- 不考虑视觉回环（光照/动态）；LiDAR 描述子为主。

## 4. 先做 oracle 回环收益门（P0，3–5 天）

在写检测器之前，先用**参考轨迹挑选真回环**，给图加“oracle 回环因子”，测
APE 还能降多少。oracle 只用于评估，不是生产测量。

- 数据：c01/c02 各 N=3（已有 `gv1_*` LIVO 轨迹 + 当前二进制）。
- 对照组：
  - v1（无回环）；
  - v1 + oracle 回环（2D 位置差；c01/c02 参考无姿态，实际执行见
    `docs/LOOP_ORACLE_REPORT.md`）。
- 指标：full/steady/movfit/static-loc；同批地板；c01/c02 两个数据集。
- **收益门**：oracle 回环使 c01 或 c02 的 full/steady 改善 **>20%**，且不伤
  static-loc；否则**不实现回环检测**，把预算留给机上固定滞后图/前端优化。
- 产物：`docs/LOOP_ORACLE_REPORT.md` + 图；结论决定 Phase B 是否立项。

> 预期管理：v1 已把 c02 full 从 7.75 压到 0.97、c01 到 0.97；剩余误差主要是
> 局部形状/RTK 离群，回环主要修“长程闭合”，收益不一定大。oracle 门就是
> 防止为了“架构完整”投入 3–4 周却换不到精度。

## 5. 实现阶段（oracle 通过后）

### Phase B：检测器 v1（2–3 周）

- 关键帧描述子（ScanContext 类），每关键帧提取一次；
- KD-tree 候选 + 时间/距离/静止排除；
- RTK 先验消歧 + GICP 几何验证；
- 回环因子协方差与鲁棒核；
- 离线批处理在 c01/c02 上 A/B；c03 负对照（应 0 回环）。

**验收**：
- c01/c02 N≥3 full/steady 改善 >10%（相对 v1），static-loc 不退化；
- 假回环注入测试 0 误接受；
- c03 不产生回环；
- 单关键帧检测耗时 <30 ms（桌面），机上 <50 ms。

### Phase C：iSAM2 在线集成（1–2 周）

- 关键帧历史 + iSAM2；回环因子增量加入；
- 独立线程，1 Hz 检测/更新；前端不等待；
- 输出 `publishSmoothedOdom` / `_graph.txt`；
- 默认 `loop_closure/en=false`。

**验收**：
- 1 Hz 更新 <100 ms（目标 <50 ms）；回环检测 <50 ms/关键帧；
- c01/c02 10 min 连续回放无丢帧、内存 <4 GB；
- 关闭时与 v1 逐位一致；开启时精度不劣于 oracle 上限的合理比例。

## 6. 与现有 v1/机载计划的关系

- v1（离线位置图 + 自动 σ/odom + 静止混合）是**精度参考**，不因回环而废弃。
- 机载 P2 原计划是 C++ 固定滞后图；若 oracle 回环收益大，可**直接升级为
  iSAM2 全历史位姿图 + 回环**，避免两套图并存：
  - 固定滞后图更适合“无回环、低延迟”的保守方案；
  - iSAM2 更适合“有回环、长程闭合”的最终方案；
  - **先 oracle 门，再二选一**，不要同时实现两套。
- 回环只做 c01/c02；c03 不做（0.7%）。

## 7. 风险与对策

| 风险 | 对策 |
|---|---|
| 回环收益不足 | oracle 门；不通过就不立项 |
| 误回环导致轨迹崩 | RTK 先验 + GICP + 残差回滚 + 假回环注入测试 |
| VLP-16 稀疏、描述子退化 | ScanContext 参数按点云密度调；备选 LiDAR Iris |
| 动态/植被误匹配 | 几何验证 + 时间/距离约束 + 鲁棒核 |
| c02 RTK 局部离群 | 不把 RTK 先验当唯一判据；保留 v1 的鲁棒项 |
| iSAM2 更新变慢 | 限制回环数/关键帧数；增量重线性化；benchmark |
| ARM GTSAM 构建 | 源码交叉构建；失败则 Ceres 批量 + 低频回环 |
| 内存 | 描述子/关键帧 LRU、prune、回环候选上限 |

## 8. 明确不做

- 不在 oracle 门通过前写 ScanContext 检测器；
- 不用参考轨迹的相对位姿作为生产回环测量；
- 不对 c03 做回环；
- 不在每个 LiDAR 帧做回环检测（关键帧/1 Hz 级）；
- 不把“架构完整”当作立项理由。

## 9. 建议的第一周

1. 用现有 `gv1_*` 轨迹 + 参考轨迹跑 oracle 回环（C++/GTSAM 或 Python 调
   C++ 小工具），输出 c01/c02 的 APE 改善表。
2. 同时测 iSAM2 在 600/1200 节点、加 10/50/100 个回环因子时的单次更新耗时。
3. 若 oracle 改善 >20%：立项 Phase B，先做 ScanContext 描述子 + 候选搜索，
   暂不做在线线程。
4. 若 oracle 改善 ≤20%：关闭回环线，把资源投入机上固定滞后图/前端优化；
   c01/c02 的回环能力留作未来数据集的储备。

> **实际执行（2026-10-17）**：第 1 步完成，`GATE_PASS=0`；第 2 步 iSAM2 基准
> 按预注册停止条件取消；进入第 4 步止损分支。oracle 工具保留为未来数据集的
> 评估脚手架，默认关。
