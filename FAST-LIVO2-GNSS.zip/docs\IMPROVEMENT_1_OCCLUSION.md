# 改进 1：复杂遮挡场景的鲁棒处理（LIO + VIO）

## 问题

复杂遮挡场景（建筑群、树冠、走廊转角）下，原系统存在三类退化：

1. **幽灵点污染匹配**：多路径反射/动态目标产生的点在已有平面"后方"，
   会被邻域回退（`BuildResidualListOMP` 的 neighbor fallback）错误地匹配到
   更远的平面，拉偏位姿；
2. **平面拟合被单帧异常点破坏**：`init_plane` 使用普通 PCA，一帧遮挡点/动态点
   即可污染平面法向与截距；
3. **VIO 特征被遮挡物误导**：检索地图点时未考虑当前 LiDAR 深度，
   被近处物体（行人、树枝）遮挡的静态特征仍参与光度跟踪；
4. **硬门控 + 无鲁棒核**：残差超过 3σ 直接丢弃（`voxel_map.cpp:737`），
   门控边缘的合法点在遮挡/噪声下被误杀或误留，无软权重。

## 方案（全部 config 门控，默认关）

### LIO 侧（`voxel_map.cpp` / `include/raycast.h`）

**a) 光线遮挡判定（`occlusion.en`）**

新增 `raycast::isPointOccluded`（`include/raycast.h`）：对当前扫描点 `p` 与
传感器原点 `o`（每轮迭代由 `state_.rot_end * extT_ + state_.pos_end` 更新），
若地图中某高置信平面（`confidence_ ≥ min_confidence`、`points_size_ ≥ 5`）
满足：

- 有效法向朝向射线：`n·d < -0.05`（PCA 法向符号任意，按朝向传感器翻转）；
- 射线与平面的交点 `t` 满足 `min_block_dist < t < |p-o| - margin`；
- 交点落在平面片内（`range_dis ≤ 3·radius`）；
- 且 `p` 位于平面**后方**（`n·(p-c) < -behind_eps`），

则 `p` 判定为被遮挡（幽灵点），从匹配中剔除、不进入地图更新。
该检查在八叉树下潜时逐平面进行（O(访问节点数)，无额外遍历）。

**b) IRLS 鲁棒核（`lio/robust_kernel_type`，1=Huber 2=Cauchy）**

`StateEstimation` 中测量噪声按残差重加权：

```
sigma_i = sqrt(0.001 + sigma_l + nᵀ var n)
w_i     = rho'(|r_i|/sigma_i) / (|r_i|/sigma_i)
R_inv(i) *= w_i
```

门控放宽到 `reject_gate_scale_ * sigma_num_ * sigma`（默认 2×3σ），
门控内残差由鲁棒核软衰减——遮挡/动态残差不再硬性二值化。

**c) 平面置信度先验**

`init_plane` 计算 `confidence_ = min(1, n/10) * (1 - min_eigen/planer_threshold)`
（点数 + 平面性），在 `build_single_residual` 的候选概率中相乘——
低置信平面（薄片/欠观测）不再吸引错误对应。

**d) 鲁棒 PCA（IRLS 重加权）**

`init_plane` 先普通 PCA，再做 2 轮 Cauchy 重加权（尺度 = 2.5·MAD 距离，
下限 2cm），仅用内点（权重 ≥ 0.5）计算平面参数不确定性 `plane_var_`。
单帧遮挡/动态点不再污染平面。

### VIO 侧（`vio.cpp`）

**e) 深度一致性遮挡检查（`occlusion.vio_en`）**

`retrieveFromVisualSparseMap` 已构建当前帧 LiDAR 深度图 `depth_img`（像素级）。
检索候选地图点时，若该像素有 LiDAR 深度且
`map_point_depth - lidar_depth > occlusion_depth_thresh`（默认 0.5m），
说明地图点被更近的表面遮挡 → 跳过该候选（主检索 + raycast 补点两处）。

**f) 光度残差鲁棒核（`vio.robust_kernel_type`）**

`updateState` / `updateStateInverse` 对逐像素残差按
`w = robust(|res|/sqrt(img_point_cov), delta)` 缩放 `z` 与 `H_sub` 行——
补丁部分遮挡（行人/树枝掠过）时大残差像素不再主导更新。

## 对比方法

同一二进制，`occlusion.en/vio_en` 开关跑两遍（基线 vs 改进），
`scripts/eval/run_eval.sh` + `eval_occlusion.py` 输出 APE/RPE 对比表与图。
推荐数据集：NTU-VIRAL（校园建筑/树木遮挡丰富，9 序列有 GT）、GREAT campus-01。

## 参数

```yaml
occlusion:
  en: true              # LIO 光线遮挡判定
  margin: 0.3           # 遮挡判定余量（m）
  behind_eps: 0.05      # 点在平面后方的最小距离（m）
  vio_en: true          # VIO 深度一致性遮挡检查
  vio_depth_ratio: 0.5  # 地图点深度超前量（m）
lio:
  robust_kernel_type: 1 # 0 无, 1 Huber, 2 Cauchy
  robust_delta: 1.5     # 核尺度（σ 单位）
  reject_gate_scale: 2.0# 门控 = 2×3σ
vio:
  robust_kernel_type: 1
  robust_delta: 2.0     # 光度量 σ 单位
```
