#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inject a controlled DD fault into a /rtk/dd bag for P3 validation.

Modes
-----
fixed_bias : in [t0,t1], add `bias` metres to dd_phase_fixed for every pair and
             force fix_valid=1.  The float dd_phase and dd_code stay clean, so
             this isolates the "wrong integer fix" path.  A 1.0 m bias is ~5 L1
             cycles; RtkTight's fixed gate / IGG3 must reject or downweight it.
drop       : remove every /rtk/dd message in [t0,t1], simulating a GNSS outage.

Usage (inside the ROS/catkin environment):
  python3 scripts/rtk/inject_dd_fault.py --in c01_dd_greatmsf.bag \
      --out /tmp/c01_dd_bad1m.bag --mode fixed_bias --bias 1.0 \
      --t0 1603764772 --t1 1603764802
  python3 scripts/rtk/inject_dd_fault.py --in c01_dd_greatmsf.bag \
      --out /tmp/c01_dd_drop30.bag --mode drop \
      --t0 1603764772 --t1 1603764802
"""
import argparse
import sys

import rosbag
from fast_livo.msg import RtkDD


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--in', dest='inp', required=True)
    ap.add_argument('--out', dest='out', required=True)
    ap.add_argument('--mode', choices=['fixed_bias', 'drop'], required=True)
    ap.add_argument('--bias', type=float, default=1.0)
    ap.add_argument('--t0', type=float, required=True)
    ap.add_argument('--t1', type=float, required=True)
    args = ap.parse_args()

    n_in = n_out = n_hit = 0
    with rosbag.Bag(args.inp) as src, rosbag.Bag(args.out, 'w') as dst:
        for topic, msg, t in src.read_messages(topics=['/rtk/dd']):
            n_in += 1
            ts = t.to_sec()
            hit = args.t0 <= ts <= args.t1
            if hit:
                n_hit += 1
                if args.mode == 'drop':
                    continue
                # Wrong integer: make every pair look fixed and shift its
                # resolved phase by a constant.  dd_phase/dd_code stay clean.
                n = min(len(msg.dd_phase_fixed), len(msg.fix_valid), int(msg.n))
                fv = list(msg.fix_valid)
                pf = list(msg.dd_phase_fixed)
                for i in range(n):
                    fv[i] = 1
                    pf[i] += args.bias
                msg.fix_valid = bytes(fv)
                msg.dd_phase_fixed = pf
            dst.write('/rtk/dd', msg, t)
            n_out += 1
    print('mode=%s t=[%.1f, %.1f] bias=%.2f m' % (args.mode, args.t0, args.t1, args.bias))
    print('messages in=%d out=%d affected=%d' % (n_in, n_out, n_hit))
    print('wrote', args.out)
    return 0


if __name__ == '__main__':
    sys.exit(main())
