#!/bin/bash
# Phase 4: three-arm N=3 batch (LIVO, RTK tight, RTK robust).
# Robust r1 is phase3_c01_rtk_robust_full1 (same Phase-3 binary); r2/r3 are new.
BASE=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main
RUN=$BASE/00_源代码/FAST-LIVO2-main/scripts/eval
NAVSAT=/home/slxc9426/datasets/GREAT/campus01_rtk1hz.bag
DD=$BASE/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.bag
OUT=$BASE/02_评估结果/rtk_tight_eval/logs
mkdir -p "$OUT"

for r in 1 2 3; do
  tag=phase4_c01_livo_r$r
  echo "=== $tag ==="
  bash "$RUN/segment_run.sh" campus01 livo 0 607 "$tag" "" "" great_campus01 \
    > "$OUT/${tag}.out" 2>&1 || echo "FAILED $tag"
done

for r in 1 2 3; do
  tag=phase4_c01_tight_r$r
  echo "=== $tag ==="
  bash "$RUN/segment_run_rtk.sh" campus01 rtk 0 607 "$tag" "$NAVSAT" "$DD" "" \
    great_campus01_rtk_tight > "$OUT/${tag}.out" 2>&1 || echo "FAILED $tag"
done

for r in 2 3; do
  tag=phase4_c01_robust_r$r
  echo "=== $tag ==="
  bash "$RUN/segment_run_rtk.sh" campus01 rtk 0 607 "$tag" "$NAVSAT" "$DD" "" \
    great_campus01_rtk_robust > "$OUT/${tag}.out" 2>&1 || echo "FAILED $tag"
done

echo "PHASE4_RUNS_DONE"
