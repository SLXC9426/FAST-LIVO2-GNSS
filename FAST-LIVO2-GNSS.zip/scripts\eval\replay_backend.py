#!/usr/bin/env python3
"""Portable same-input backend replay. Run in a sourced ROS Noetic shell.

Use --dry-run to validate paths and record metadata without starting ROS.
All paths are explicit; a new output directory is required for every arm.
"""
import argparse
import csv
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from quality_provenance import verify_quality_positions


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def tum_times(path):
    times=[]
    for line in path.read_text(encoding='utf-8-sig').splitlines():
        fields=line.split()
        if not fields or fields[0].startswith('#'): continue
        if len(fields)<8: raise ValueError(f'invalid TUM row in {path}')
        if not all(math.isfinite(float(x)) for x in fields[:8]):
            raise ValueError(f'non-finite TUM row in {path}')
        times.append(float(fields[0]))
    if not times or any(not times[i]>times[i-1] for i in range(1,len(times))):
        raise ValueError(f'empty/non-monotonic TUM: {path}')
    return times


def main():
    p=argparse.ArgumentParser(description=__doc__)
    for key in ['node','livo','rtk','reference','quality-csv','out']:
        p.add_argument('--'+key,required=True,type=Path)
    p.add_argument('--status-csv',type=Path)
    p.add_argument('--params-json',type=Path)
    p.add_argument('--port',type=int,default=11461)
    p.add_argument('--speed',type=float,default=1.)
    p.add_argument('--duration',type=float)
    p.add_argument('--drain-timeout',type=float,default=180.)
    p.add_argument('--dry-run',action='store_true')
    args=p.parse_args()
    if not 1024<=args.port<=65535 or args.speed<=0 or (args.duration is not None and args.duration<=0):
        p.error('invalid port, speed or duration')
    source=Path(__file__).resolve().parents[2]
    # The normal feeder is versioned here; frozen evidence stays untouched.
    feeder=source/'scripts/eval/feed_online_graph.py'
    inputs={k:getattr(args,k).resolve() for k in ['node','livo','rtk','reference','quality_csv']}
    inputs['feeder']=feeder
    inputs['libonline_graph']=args.node.resolve().parents[1]/'libonline_graph.so'
    if args.status_csv: inputs['status_csv']=args.status_csv.resolve()
    if args.params_json: inputs['params_json']=args.params_json.resolve()
    for key,path in inputs.items():
        if not path.is_file(): p.error(f'missing {key}: {path}')
    times=tum_times(inputs['livo']); tum_times(inputs['rtk']); tum_times(inputs['reference'])
    with inputs['quality_csv'].open(encoding='utf-8-sig') as stream:
        quality=csv.DictReader(stream)
        if not {'t_unix','status'}.issubset(quality.fieldnames or []) or next(quality,None) is None:
            p.error('empty quality CSV or missing t_unix/status columns')
    provenance=verify_quality_positions(inputs['rtk'],inputs['quality_csv'])
    end=times[0]+args.duration if args.duration is not None else times[-1]
    expected=[t for t in times if t<=end]
    if len(expected)<20: p.error('backend requires at least 20 keyframes')
    params=dict(window=max(1500,len(expected)),tddd_en=False,quality_gate_en=True,
        quality_min_status=2,cauchy_xy_en=True,lambda_weight_en=True,scale_fit_en=True,
        sig_rigid=.01,sig_anchor=.3,rtk_interp_en=True,rtk_static_rule_bracket=True,
        rtk_interp_max_bracket_dt=1.5,rtk_interp_model_sigma=.10,
        rtk_class_gate_en=False,rtk_innovation_gate_en=False,fit_two_pass_en=False,
        fit_robust_en=False,static_anchor_validity_en=False,cov_en=False,
        fixed_lag_en=False,vel_en=False)
    if args.params_json:
        extra=json.loads(args.params_json.read_text(encoding='utf-8-sig'))
        if not isinstance(extra,dict): p.error('params JSON must be an object')
        if any(not k.replace('_','').isalnum() or k in ['output','assoc_trace'] for k in extra):
            p.error('invalid or reserved parameter key')
        params.update(extra)
    out=args.out.resolve()
    if out.exists(): p.error('output already exists; use a new arm directory')
    out.mkdir(parents=True)
    metadata=dict(inputs={k:dict(path=str(v),sha256=digest(v)) for k,v in inputs.items()},
        source_hashes={str(v.relative_to(source)):digest(v) for folder in ['src','include','msg'] for v in sorted((source/folder).rglob('*')) if v.is_file()},
        params=params,speed=args.speed,expected_keyframes=len(expected),quality_provenance=provenance,
        start=expected[0],end=expected[-1],dry_run=args.dry_run,status='VALIDATED')
    (out/'manifest.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    if args.dry_run:
        print('Validated inputs:',len(expected),'keyframes;',out); return 0
    if not os.environ.get('ROS_DISTRO'):
        metadata['status']='FAILED'; metadata['error']='ROS environment not sourced'
        (out/'manifest.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
        raise RuntimeError('source ROS and this build devel/setup.bash first')
    env=dict(os.environ,ROS_MASTER_URI=f'http://127.0.0.1:{args.port}',ROS_HOSTNAME='127.0.0.1',ROS_IP='127.0.0.1',ROS_HOME=str(out/'ros'),
             LD_LIBRARY_PATH=str(inputs['libonline_graph'].parent)+os.pathsep+os.environ.get('LD_LIBRARY_PATH',''))
    logs=[]; children=[]
    def launch(command,name):
        log=(out/name).open('w',encoding='utf-8'); logs.append(log)
        process=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT)
        children.append(process); return process
    try:
        # Abort if an existing master owns the port. Never terminate others.
        try:
            check=subprocess.run(['rosnode','list'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=2)
            if check.returncode==0: raise RuntimeError('ROS master already active at selected port')
        except subprocess.TimeoutExpired: pass
        core=launch(['roscore','-p',str(args.port)],'roscore.log')
        for _ in range(40):
            if core.poll() is not None: raise RuntimeError('roscore failed')
            try:
                if subprocess.run(['rosnode','list'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,timeout=1).returncode==0: break
            except subprocess.TimeoutExpired: pass
            time.sleep(.25)
        else: raise RuntimeError('ROS master startup timed out')
        def ros_value(v):
            return json.dumps(v,separators=(',',':')) if isinstance(v,(bool,list,dict)) else str(v)
        command=[str(inputs['node']),f'_output:={out / "trajectory.tum"}',f'_assoc_trace:={out / "assoc.csv"}']
        command += [f'_{k}:={ros_value(v)}' for k,v in params.items()]
        node=launch(command,'node.log'); time.sleep(1.)
        feed=[sys.executable,str(feeder),'--livo',str(inputs['livo']),'--rtk',str(inputs['rtk']),
              '--quality-csv',str(inputs['quality_csv']),'--speed',str(args.speed),
              '--duration',str(end-times[0])]
        if args.status_csv: feed+=['--status-csv',str(inputs['status_csv'])]
        feeder_process=launch(feed,'feed.log')
        while feeder_process.poll() is None:
            if node.poll() is not None: raise RuntimeError('backend exited during feed')
            time.sleep(.25)
        if feeder_process.returncode: raise RuntimeError('feeder failed; inspect feed.log')
        deadline=time.monotonic()+args.drain_timeout
        previous=None; stable_since=time.monotonic()
        while time.monotonic()<deadline:
            if node.poll() is not None: raise RuntimeError('backend exited while draining')
            path=out/'trajectory.tum'
            try:
                data=path.read_bytes(); rows=data.splitlines()
                last=float(rows[-1].split()[0]) if rows else -1
                signature=hashlib.sha256(data).hexdigest()
            except (OSError,ValueError,IndexError): signature=None; last=-1; rows=[]
            if signature!=previous: previous=signature; stable_since=time.monotonic()
            if last>=expected[-1]-1e-6 and len(rows)==len(expected) and time.monotonic()-stable_since>=3: break
            time.sleep(.5)
        else: raise RuntimeError('incomplete output coverage or drain timeout')
        metadata['status']='COMPLETED'; metadata['trajectory_sha256']=digest(out/'trajectory.tum')
        print('Completed:',out)
    except Exception as exc:
        metadata['status']='FAILED'; metadata['error']=str(exc)
        raise
    finally:
        for child in reversed(children):
            if child.poll() is None: child.terminate()
        for child in reversed(children):
            try: child.wait(timeout=5)
            except subprocess.TimeoutExpired: child.kill(); child.wait()
        for log in logs: log.close()
        (out/'manifest.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    return 0

if __name__=='__main__': raise SystemExit(main())
