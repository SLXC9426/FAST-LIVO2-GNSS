#!/usr/bin/env python3
"""
eval_graph.py - Improvement 2 comparison (frontend ESKF vs sliding-window
factor-graph backend): trajectory accuracy (APE/RPE vs GT) and latency
statistics from the <seq>_latency.csv produced by the C++ instrumentation.

Usage:
  python3 scripts/eval/eval_graph.py --gt gt.tum --front front.txt \
      --graph graph.txt --latency latency.csv --out Log/eval/<seq>
"""

import argparse
import os
import sys

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MPL = True
except Exception:
    HAS_MPL = False


def load_tum(path):
    data = np.loadtxt(path)
    return data[:, 0], data[:, 1:4]


def interpolate(ref_t, ref_pos, q_t):
    out = np.zeros((len(q_t), 3))
    for k in range(3):
        out[:, k] = np.interp(q_t, ref_t, ref_pos[:, k])
    return out


def umeyama(est, gt):
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gt", required=True)
    ap.add_argument("--front", required=True)
    ap.add_argument("--graph", required=True)
    ap.add_argument("--latency", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    t_gt, p_gt = load_tum(args.gt)
    t_f, p_f = load_tum(args.front)
    t_g, p_g = load_tum(args.graph)

    t0 = max(t_f[0], t_g[0], t_gt[0])
    t1 = min(t_f[-1], t_g[-1], t_gt[-1])
    mask = (t_gt >= t0) & (t_gt <= t1)
    t_c, p_gt_c = t_gt[mask], p_gt[mask]
    p_f_c = interpolate(t_f, p_f, t_c)
    p_g_c = interpolate(t_g, p_g, t_c)

    print("=== accuracy: frontend ESKF vs factor-graph backend ===")
    print(f"{'metric':<14}{'ESKF':>14}{'factor-graph':>14}{'delta':>12}")
    res = {}
    for name, p in (("ESKF", p_f_c), ("factor-graph", p_g_c)):
        e = np.linalg.norm(umeyama(p, p_gt_c) - p_gt_c, axis=1)
        res[name] = e
    for label, key in (("APE RMSE", "rmse"), ("APE mean", "mean"), ("APE max", "max")):
        eb = {"rmse": np.sqrt(np.mean(res["ESKF"] ** 2)), "mean": np.mean(res["ESKF"]),
              "max": np.max(res["ESKF"])}[key]
        ei = {"rmse": np.sqrt(np.mean(res["factor-graph"] ** 2)), "mean": np.mean(res["factor-graph"]),
              "max": np.max(res["factor-graph"])}[key]
        d = (ei - eb) / eb * 100
        print(f"{label:<14}{eb * 100:>12.2f}cm{ei * 100:>12.2f}cm{d:>+11.1f}%")

    # ---- latency analysis ----
    print("\n=== latency: frontend vs backend (from *_latency.csv) ===")
    print("csv columns: stamp, frontend_latency_ms, graph_opt_ms, graph_queue_ms, graph_output_ms, window, iters")
    lat = np.loadtxt(args.latency, delimiter=",", skiprows=1)
    if lat.ndim == 1:
        lat = lat.reshape(1, -1)
    front_ms = lat[:, 1]
    opt_ms = lat[:, 2]
    out_ms = lat[:, 4]
    print(f"{'quantity':<28}{'mean':>10}{'p50':>10}{'p95':>10}{'max':>10}")
    for name, v in (
        ("frontend end-to-end (ms)", front_ms),
        ("graph optimize (ms)", opt_ms),
        ("graph output lag (ms)", out_ms),
    ):
        print(f"{name:<28}{np.mean(v):>10.2f}{np.percentile(v, 50):>10.2f}{np.percentile(v, 95):>10.2f}{np.max(v):>10.2f}")

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "graph_compare.csv"), "w") as f:
        f.write("metric,eskf_cm,graph_cm,delta_pct\n")
        for label, key in (("APE RMSE", "rmse"), ("APE mean", "mean"), ("APE max", "max")):
            eb = {"rmse": np.sqrt(np.mean(res["ESKF"] ** 2)), "mean": np.mean(res["ESKF"]),
                  "max": np.max(res["ESKF"])}[key]
            ei = {"rmse": np.sqrt(np.mean(res["factor-graph"] ** 2)), "mean": np.mean(res["factor-graph"]),
                  "max": np.max(res["factor-graph"])}[key]
            f.write(f"{label},{eb * 100:.4f},{ei * 100:.4f},{(ei - eb) / eb * 100:.2f}\n")
    with open(os.path.join(args.out, "graph_latency.csv"), "w") as f:
        f.write("quantity,mean,p50,p95,max\n")
        for name, v in (("frontend", front_ms), ("graph_opt", opt_ms), ("graph_output", out_ms)):
            f.write(f"{name},{np.mean(v):.3f},{np.percentile(v, 50):.3f},{np.percentile(v, 95):.3f},{np.max(v):.3f}\n")

    if HAS_MPL:
        fig, ax = plt.subplots(1, 3, figsize=(15, 4.5))
        ax[0].plot(p_gt_c[:, 0], p_gt_c[:, 1], "k-", lw=2, label="GT")
        ax[0].plot(p_f_c[:, 0], p_f_c[:, 1], "b--", lw=1, label="ESKF frontend")
        ax[0].plot(p_g_c[:, 0], p_g_c[:, 1], "r-", lw=1, label="factor-graph")
        ax[0].set_title("trajectory XY")
        ax[0].legend(fontsize=8)
        ax[1].plot(t_c, res["ESKF"] * 100, "b--", lw=1, label="ESKF")
        ax[1].plot(t_c, res["factor-graph"] * 100, "r-", lw=1, label="factor-graph")
        ax[1].set_title("APE vs time (cm)")
        ax[1].legend(fontsize=8)
        ax[2].hist(front_ms, bins=40, alpha=0.5, label="frontend latency")
        ax[2].hist(out_ms, bins=40, alpha=0.5, label="graph output lag")
        ax[2].set_title("latency histogram (ms)")
        ax[2].legend(fontsize=8)
        fig.tight_layout()
        fig.savefig(os.path.join(args.out, "graph_compare.png"), dpi=150)
        print("\nplot ->", os.path.join(args.out, "graph_compare.png"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
