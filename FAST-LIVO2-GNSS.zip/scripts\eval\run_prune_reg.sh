#!/bin/bash
# R6 T3-2: c01/c02 prune on/off regression before changing the default.
# Prune stays default-off; this batch checks the code path and memory on the
# two short campus datasets (c03 already passed 600 s + 1255 s).
#
#   bash run_prune_reg.sh [outdir]
export LANG=C.UTF-8
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
SEG=$REPO/scripts/eval/segment_run.sh
OUT=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/prune_reg}
mkdir -p "$OUT"
LOG=$OUT/prune_reg.log
: > "$LOG"
echo "=== PRUNE REG c01/c02 | $(date +%F' '%T) ===" | tee -a "$LOG"
echo "libs $(md5sum "$HOME/catkin_ws/devel/lib/liblaser_mapping.so" | cut -c1-8)" | tee -a "$LOG"

run_one () {
  local SEQ=$1 DUR=$2 ARM=$3 CFG=$4
  local TAG="prune_${SEQ}_${ARM}"
  echo "--- $TAG start $(date +%T) ---" | tee -a "$LOG"
  DRAIN_ITERS=80 bash "$SEG" "$SEQ" livo 0 "$DUR" "$TAG" "" "" "$CFG" >> "$LOG" 2>&1
  echo "--- $TAG done $(date +%T) ---" | tee -a "$LOG"
}

run_one campus01 607 on  great_campus01_mem
run_one campus01 607 off great_campus01_mem_noprune
run_one campus02 806 on  great_campus02_mem
run_one campus02 806 off great_campus02_mem_noprune
echo "PRUNE_REG_DONE $(date +%T)" | tee -a "$LOG"
