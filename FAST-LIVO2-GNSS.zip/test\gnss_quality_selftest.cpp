/*
A2.1 self-test: exact-timestamp GNSS quality matching.

The relay publishes GnssQuality and NavSatFix from the same PVT callback, so
their stamps are identical. This test pins the cache contract:
  - exact stamp match, one record consumed by one fix;
  - an adjacent epoch is never substituted;
  - duplicate publications are counted, not merged;
  - missing/late records do not resurrect an older quality record;
  - out-of-order arrival still matches by stamp;
  - expiry drops stale records;
  - absent fields keep their has_* flag instead of becoming a valid zero.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/gnss_quality_selftest
*/
#include "gnss_quality_cache.h"

#include <cstdio>
#include <string>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok)
{
  std::printf("%s  %-58s\n", ok ? "ok  " : "FAIL", name.c_str());
  if (!ok) ++g_failures;
}

fast_livo::GnssQualityRecord make(uint8_t sv, double dop, uint32_t h,
                                  uint32_t v)
{
  fast_livo::GnssQualityRecord r;
  r.valid = true;
  r.num_sv = sv;
  r.p_dop = dop;
  r.h_acc_mm = h;
  r.v_acc_mm = v;
  r.has_p_dop = true;
  r.has_h_acc = true;
  r.has_v_acc = true;
  r.carr_soln = 2;
  r.fix_type = 3;
  r.source = "ublox";
  return r;
}

}  // namespace

int main()
{
  using fast_livo::GnssQualityCache;
  using fast_livo::GnssQualityRecord;

  // ---- exact match, one record per fix ------------------------------------
  {
    GnssQualityCache c;
    check("insert accepted", c.insert(1000000000ull, make(19, 1.53, 40, 70)));
    GnssQualityRecord out;
    check("exact stamp matches", c.take(1000000000ull, &out));
    check("fields survive", out.num_sv == 19 && out.p_dop == 1.53 &&
                                out.h_acc_mm == 40 && out.v_acc_mm == 70);
    check("record is consumed", !c.take(1000000000ull, &out));
  }

  // ---- adjacent epoch is not substituted ----------------------------------
  {
    GnssQualityCache c;
    c.insert(1000000000ull, make(19, 1.53, 40, 70));
    GnssQualityRecord out;
    check("1 ms away does not match", !c.take(1001000000ull, &out));
    check("1 s away does not match", !c.take(2000000000ull, &out));
    check("original still matches its own stamp", c.take(1000000000ull, &out));
  }

  // ---- duplicate publication ----------------------------------------------
  {
    GnssQualityCache c;
    check("first insert ok", c.insert(7ull, make(10, 2.0, 100, 200)));
    check("duplicate rejected", !c.insert(7ull, make(11, 3.0, 300, 400)));
    check("duplicate counted", c.duplicates() == 1);
    GnssQualityRecord out;
    c.take(7ull, &out);
    check("first record kept", out.num_sv == 10);
  }

  // ---- out-of-order arrival -----------------------------------------------
  {
    GnssQualityCache c;
    c.insert(300ull, make(30, 1.0, 10, 20));
    c.insert(100ull, make(10, 3.0, 30, 40));
    GnssQualityRecord out;
    check("later stamp matches independently", c.take(300ull, &out) &&
                                                  out.num_sv == 30);
    check("earlier stamp matches independently", c.take(100ull, &out) &&
                                                    out.num_sv == 10);
  }

  // ---- expiry -------------------------------------------------------------
  {
    GnssQualityCache c(5.0);
    c.insert(1000000000ull, make(19, 1.53, 40, 70));
    c.prune(4000000000ull);  // 3 s later
    check("record inside expiry kept", c.size() == 1);
    c.prune(7000000000ull);  // 6 s later
    check("stale record dropped", c.size() == 0 && c.expired() == 1);
    GnssQualityRecord out;
    check("stale record cannot match", !c.take(1000000000ull, &out));
  }

  // ---- missing fields stay explicitly unknown -----------------------------
  {
    GnssQualityCache c;
    GnssQualityRecord r;
    r.valid = true;
    r.num_sv = 8;
    r.has_p_dop = false;
    r.has_h_acc = false;
    r.has_v_acc = false;
    c.insert(42ull, r);
    GnssQualityRecord out;
    c.take(42ull, &out);
    check("unknown fields keep has_* false",
          !out.has_p_dop && !out.has_h_acc && !out.has_v_acc);
    check("zero is not promoted to a valid value",
          out.p_dop == 0.0 && out.h_acc_mm == 0 && out.v_acc_mm == 0);
  }

  // ---- counters do not double count ---------------------------------------
  {
    GnssQualityCache c;
    c.insert(1ull, make(1, 1.0, 1, 1));
    GnssQualityRecord out;
    c.take(1ull, &out);
    c.take(1ull, &out);
    check("one matched and one unmatched", c.matched() == 1 &&
                                               c.unmatched() == 1);
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: GNSS quality exact-stamp matching\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
