#!/usr/bin/env python3
import numpy as np

for fn in ["1603774014641040128.bin", "1603774014741900032.bin"]:
    p = "/mnt/d/BaiduNetdiskDownload/Urban-01/Lidar/data/" + fn
    raw = np.fromfile(p, dtype=np.uint8)
    n = len(raw) // 22
    pts = raw[: n * 22].reshape(n, 22)
    x = pts[:, 0:4].copy().view(np.float32).ravel()
    t = pts[:, 18:22].copy().view(np.float32).ravel()
    ring = pts[:, 16].astype(np.uint32) | (pts[:, 17].astype(np.uint32) << 8)
    print(fn, "n=", n, "x0=", x[0])
    print("  time min %.6f max %.6f first3 %s" % (t.min(), t.max(), t[:3].round(6)))
    print("  rings:", np.unique(ring).tolist()[:20], "nrings:", len(np.unique(ring)))
