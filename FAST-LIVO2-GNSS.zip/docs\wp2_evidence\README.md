# WP2 同输入对照证据包

日期：2026-11-04
分支：`fix/r4-backend`
运行使用提交：`06f3fc8`（R5.0 Pose3 Jacobian 修正）+ `f8b41cc`（R5.1–R5.3）
证据包提交：`ae808fd`（R5.6 复核修复）

后续 R5.4–R5.6 不改变本次 arm 的行为：TDDD 关闭、未喂速度、`fixed_lag=false`。

## 1. 对照契约

四臂使用完全相同的输入时间范围、参考真值和评估脚本：

| 项 | 值 |
|---|---|
| 序列 | campus-02 |
| 时长 | 805 s |
| LIO 输入 | `inputs/gv1_campus02_livo_r1_base.tum` |
| RTK 输入 | `inputs/campus02_rtk1hz.tum` |
| 状态 CSV | `inputs/v2_epoch_errors.csv` |
| 参考真值 | `inputs/campus02_reference.tum` |
| 节点 | `online_graph_node` |
| 窗口 | 1500 |
| TDDD | 关闭 |
| 速度 | 未喂入（`_vel_en:=false`） |
| 边界先验 | 关闭（`_fixed_lag_en:=false`） |
| Marginals | 关闭（`_cov_en:=false`） |
| 质量门 | `quality_min_status=2` |
| 静态/鲁棒 | `sig_rigid=0.01`、`sig_anchor=0.3`、Cauchy XY |
| scale | `scale_fit_en=false` |

在线节点参数见 `scripts/run_wp2_pose3.sh`；该脚本是本次运行的记录，路径为
WSL 绝对路径，复跑时按本机路径替换 `ROOT` 与 catkin 工作区即可。

## 2. 结果

| arm | 文件 | n | matched | ATE median | ATE p95 | ATE RMSE |
|---|---|---|---:|---:|---:|---:|
| online_pose3（新） | `results/online_pose3_scaleoff.tum` | 805 | 805 | **1.063** | **2.855** | **1.515** |
| online_point3（旧） | `results/online_full_scaleoff.tum` | 805 | 805 | 1.271 | 3.491 | 1.806 |
| offline_static_cauchy | `results/offline_static_cauchy.tum` | 805 | 805 | 1.307 | 3.736 | 1.903 |

同输入差异：

- Pose3 vs Point3：位置差 0.312 / 1.549 / 2.311 m（median/p95/max）；
  姿态差 0.776 / 1.914 / 3.107°。
- Pose3 vs 离线图：位置差 0.497 / 1.991 / 2.618 m。

评估方法：

- 轨迹与参考按最近时间戳匹配，容差 0.25 s；
- ATE 使用 3D 刚体 Umeyama 对齐后的逐点位置误差；
- Pose3 vs Point3/offline 使用最近时间戳匹配，容差 0.1 s；
- 姿态差为 `acos((trace(R_a^T R_b)-1)/2)`。

## 3. 目录

| 路径 | 内容 |
|---|---|
| `inputs/` | LIO TUM、RTK TUM、参考 TUM、状态 CSV |
| `results/` | 三臂 TUM、节点日志、比较结果 `wp2_pose3_compare.md` |
| `scripts/` | 运行脚本 `run_wp2_pose3.sh`、比较脚本 `compare_wp2.py`、Pose3 冒烟比较 `compare_pose3.py` |
| `SHA256SUMS` | 本目录所有文件的 SHA256 |

## 4. 限制

- 单次 805 s 运行，尚无 N=3；不能作为最终论文数字。
- 该 arm 不含 TDDD、速度因子和边界先验，只验证 Pose3 + PVT + LIVO 相对位姿。
- 参考文件不含姿态，姿态差只在 Pose3 与旧 Point3 之间比较。
- 比较脚本使用刚体 Umeyama；与项目原有 `stage1_eval` 的 full 3D 口径一致的部分
  需要以 `scripts/compare_wp2.py` 为准。
