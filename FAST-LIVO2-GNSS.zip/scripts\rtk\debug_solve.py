import numpy as np
import pandas as pd
from rtk_preprocess import _dd_geom, _dd_jac, load_flt_pos, gps_sow

p = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
d = pd.read_csv(p)
base = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
t = d.t_gps.min()
rows = d[d.t_gps == t].to_dict("records")
print("epoch", t, "rows", len(rows))

def cost(x):
    return sum(((r["dd_code"] - _dd_geom(r, x, base)) / r["sigma_code"]) ** 2 for r in rows)

x = base.copy()
for it in range(5):
    H = np.array([_dd_jac(r, x) for r in rows])
    b = np.array([r["dd_code"] - _dd_geom(r, x, base) for r in rows])
    w = np.array([1.0 / r["sigma_code"] ** 2 for r in rows])
    A = (H * w[:, None]).T @ H
    rhs = (H * w[:, None]).T @ b
    dx = np.linalg.solve(A + np.eye(3) * 1e-6, rhs)
    print(f"iter {it}: cost={cost(x):.3g} |dx|={np.linalg.norm(dx):.2f}")
    for step in [1.0, 0.5, 0.25, 0.1]:
        print(f"  step {step}: cost={cost(x + step * dx):.3g}")
    x = x + dx
    print("  x", x)
    if np.linalg.norm(dx) < 1e-4:
        break

sow = gps_sow(t)
ts, flt = load_flt_pos("/home/slxc9426/great_pvt/result/SEPT-RTK.flt", sow)
print("flt", ts, flt, "error", np.linalg.norm(x - flt))
