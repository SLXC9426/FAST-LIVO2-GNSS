/*
R1 self-test: a max_corr rejection must be atomic.

Pre-P0 the update scaled dx/da but still ran the full-gain Joseph update, and
the per-pair loop had already created ambiguity states. A rejected epoch could
therefore leave new ambiguities (and a covariance) behind.

This test builds a minimal 3-pair epoch whose position correction is far above
max_corr and checks that update() returns false while nAmb(), accepted() and
rejected() are consistent, and that a malformed message cannot mutate the
ambiguity block either.

    catkin_make --pkg fast_livo
    ./devel/lib/fast_livo/rtk_maxcorr_selftest

Exit code 0 = pass, 1 = failure.
*/

#include "rtk_tight.h"

#include <cmath>
#include <cstdio>

namespace
{

int g_failures = 0;

void check(bool ok, const char *name, double value, double expected)
{
  if (!ok)
  {
    ++g_failures;
    std::printf("FAIL  %-42s value=%.9g expected=%.9g\n", name, value, expected);
  }
  else
  {
    std::printf("ok    %-42s value=%.9g expected=%.9g\n", name, value, expected);
  }
}

fast_livo::RtkDD makeMessage()
{
  const Eigen::Vector3d base(-2267749.9279, 5009154.2407, 3221290.6333);
  const Eigen::Vector3d sat = base + Eigen::Vector3d(2.0e7, 0.0, 0.0);
  const Eigen::Vector3d ref = base + Eigen::Vector3d(0.0, 2.0e7, 0.0);

  fast_livo::RtkDD msg;
  msg.header.stamp = ros::Time().fromSec(100.0);
  msg.n = 3;
  for (int i = 0; i < 3; ++i)
  {
    msg.sys.push_back("G");
    msg.freq.push_back("L1");
    msg.sat.push_back("G0" + std::to_string(i + 1));
    msg.ref_sat.push_back("G13");
    msg.dd_code.push_back(0.0);   // ~100 m away from the geometry below
    msg.dd_phase.push_back(0.0);
    msg.sat_x.push_back(sat.x());
    msg.sat_y.push_back(sat.y());
    msg.sat_z.push_back(sat.z());
    msg.ref_x.push_back(ref.x());
    msg.ref_y.push_back(ref.y());
    msg.ref_z.push_back(ref.z());
    msg.sigma_code.push_back(0.5);
    msg.sigma_phase.push_back(0.01);
    msg.slip.push_back(0);
    msg.ref_change.push_back(0);
  }
  return msg;
}

}  // namespace

int main()
{
  RtkTight::Config cfg;
  cfg.max_corr = 0.01;        // any sane correction is "too large"
  cfg.gate_chi2 = 1.0e30;     // do not let the chi-square gate decide first
  cfg.prior_sigma_pos = 1000.0;
  cfg.prior_sigma_pos_tight = 1000.0;
  cfg.sigma_code_min = 0.01;
  cfg.sigma_code_scale = 1.0;
  cfg.init_amb_var = 4.0;
  cfg.fixed_phase_en = false;
  cfg.tdcp_en = false;
  cfg.coarse_acq_en = false;
  cfg.verbose = false;

  RtkTight rtk;
  rtk.setConfig(cfg);
  rtk.setUseScale(false);
  // Origin at the default base station (computed from base_ecef), so the base
  // sits at the ENU origin and a 100 m state offset is a real 100 m baseline.
  rtk.setOrigin(30.531651482004428, 114.35726709590782, 25.966409120708704);

  StatesGroup state;
  state.pos_end = V3D(100.0, 0.0, 0.0);
  state.rot_end = M3D::Identity();
  state.vel_end = V3D::Zero();
  state.cov = Eigen::Matrix<double, DIM_STATE, DIM_STATE>::Identity() * 1.0e4;

  const M3D enu_R_world = M3D::Identity();
  const V3D enu_t_world = V3D::Zero();
  const V3D lever_body = V3D::Zero();

  Eigen::Matrix<double, DIM_STATE, 1> dx;
  Eigen::Matrix<double, DIM_STATE, DIM_STATE> P_new;

  fast_livo::RtkDD msg = makeMessage();
  const bool ok = rtk.update(msg, state, enu_R_world, enu_t_world, lever_body,
                             dx, P_new);
  check(!ok, "max_corr epoch rejected", ok ? 1.0 : 0.0, 0.0);
  check(rtk.nAmb() == 0, "ambiguity block rolled back", (double)rtk.nAmb(), 0.0);
  check(rtk.accepted() == 0, "accepted count", (double)rtk.accepted(), 0.0);
  check(rtk.rejected() == 1, "rejected count", (double)rtk.rejected(), 1.0);

  // A malformed epoch must not touch the ambiguity block either.
  fast_livo::RtkDD bad = makeMessage();
  bad.sat_y.resize(2);
  const bool bad_ok = rtk.update(bad, state, enu_R_world, enu_t_world,
                                 lever_body, dx, P_new);
  check(!bad_ok, "malformed epoch rejected", bad_ok ? 1.0 : 0.0, 0.0);
  check(rtk.nAmb() == 0, "malformed epoch leaves nAmb", (double)rtk.nAmb(), 0.0);

  if (g_failures == 0)
  {
    std::printf("\nPASS: max_corr rejection is atomic\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
