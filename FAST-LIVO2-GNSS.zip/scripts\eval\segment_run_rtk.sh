#!/bin/bash
# Phase 2 RTK tight-coupling run.
#
# Usage:
#   segment_run_rtk.sh <campus01> <rtk> <start_s> <dur_s> <tag> \
#       [navsat_bag] [dd_bag] [topic_override] [cfg_name]
#
# It plays three bags together: the main LiDAR/IMU bag, the 1 Hz NavSatFix bag
# (used ONLY for the ENU<->world alignment; position updates are disabled by the
# config), and the /rtk/dd bag produced in Phase 1.
export LANG=C.UTF-8
set -o pipefail
SEQ=$1; MODE=$2; START=$3; DUR=$4; TAG=$5
RTKBAG=${6:-}; DDBAG=${7:-}; TOPICOV=${8:-}; CFGOV=${9:-}
DRAIN_ITERS=${DRAIN_ITERS:-40}
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo

CFGNAME=${CFGOV:-great_${SEQ}}
CFG=config/${CFGNAME}.yaml
REF=~/eval_great/${SEQ}_reference.tum
if [ ! -f "$CFG" ]; then
  echo "[segment_run_rtk] config not found: $CFG"; exit 1
fi

CFG_BAK=$(mktemp)
cp "$CFG" "$CFG_BAK"
trap 'cp "$CFG_BAK" "$CFG" 2>/dev/null; rm -f "$CFG_BAK"' EXIT

case "$SEQ" in
  campus01) BAG=~/datasets/GREAT/campus-01-full.bag ;;
  campus02) BAG=~/datasets/GREAT/campus-02.bag ;;
  campus03) BAG=~/datasets/GREAT/campus-03.bag ;;
  *) echo "unknown sequence $SEQ"; exit 1 ;;
esac

# RTK mode always keeps gnss_en true: the NavSatFix stream is needed for the
# alignment, even though the position update itself is disabled in the config.
sed -i 's/^  gnss_en: .*/  gnss_en: true/' $CFG
case "$SEQ" in
  campus01) sed -i 's|^  gnss_topic: .*|  gnss_topic: "/gnss_rtk"|' $CFG ;;
  *)        sed -i 's|^  gnss_topic: .*|  gnss_topic: "/gnss"|' $CFG ;;
esac
if [ -n "$TOPICOV" ]; then
  sed -i "s|^  gnss_topic: .*|  gnss_topic: \"$TOPICOV\"|" $CFG
fi
sed -i "s/^  seq_name: .*/  seq_name: \"$TAG\"/" $CFG
RES=Log/result/${TAG}.txt
LOG=$HOME/seg_${TAG}.log
if { [ -e "$RES" ] || [ -e "$LOG" ]; } && [ "${FORCE:-0}" != "1" ]; then
  echo "[segment_run_rtk] refusing to overwrite TAG=$TAG ($RES / $LOG exists)."
  echo "[segment_run_rtk]   use a unique tag, or set FORCE=1 to overwrite deliberately."
  exit 2
fi
: > "$RES"

bash "$(dirname "$0")/kill_ros.sh"
# roslaunch does not always start a master after kill_ros.sh; make sure one
# exists before launching the node (otherwise every publisher fails to register).
if ! pgrep -f '[r]osmaster' >/dev/null 2>&1; then
  roscore > "$HOME/roscore_${TAG}.log" 2>&1 &
  sleep 5
fi
rm -f "$RES"; : > "$RES"

# Extra roslaunch args, e.g. a campus-specific base ECEF for the TDDD graph:
#   LAUNCH_ARGS='online_graph_base_ecef:=[-2267750.14853585,5009154.50747098,3221294.38263863]'
roslaunch fast_livo mapping_great.launch rviz:=false seq_name:=$TAG cfg:=$CFGNAME ${LAUNCH_ARGS:-} > "$LOG" 2>&1 &
MP=$!
sleep 8

if [ -n "$RTKBAG" ] && [ -n "$DDBAG" ]; then
  rosbag play -q --queue 5000 -s $START -u $DUR "$BAG" "$RTKBAG" "$DDBAG" > "$HOME/play_${TAG}.log" 2>&1 &
elif [ -n "$RTKBAG" ]; then
  rosbag play -q --queue 5000 -s $START -u $DUR "$BAG" "$RTKBAG" > "$HOME/play_${TAG}.log" 2>&1 &
else
  rosbag play -q --queue 5000 -s $START -u $DUR "$BAG" > "$HOME/play_${TAG}.log" 2>&1 &
fi
PP=$!
wait $PP 2>/dev/null || true

last=-1; stable=0
for i in $(seq 1 "$DRAIN_ITERS"); do
  sleep 4
  n=$(wc -l < "$RES" 2>/dev/null || echo 0)
  if [ "$n" = "$last" ]; then stable=$((stable+1)); else stable=0; fi
  last=$n
  [ "$stable" -ge 3 ] && break
done
kill -9 $MP 2>/dev/null || true
bash "$(dirname "$0")/kill_ros.sh"
echo "[segment_run_rtk] $TAG: $(wc -l < "$RES") lines"

python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main/scripts/eval/eval_unified.py \
    "$RES" "$REF" "$TAG" --config "$CFG"
EVAL_RC=$?
python3 /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/00_源代码/FAST-LIVO2-main/scripts/eval/fusion_health.py \
    "$LOG"
exit $EVAL_RC
