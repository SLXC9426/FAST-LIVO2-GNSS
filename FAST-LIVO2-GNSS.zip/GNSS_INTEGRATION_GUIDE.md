# FAST-LIVO2 + RTK 紧组合集成指南

## 已修改/新增的文件清单

### 已修改文件
1. `include/common_lib.h` - 新增 GNSS 数据结构、SLAM 模式枚举
2. `include/LIVMapper.h` - 新增 GNSS 成员变量与函数声明
3. `CMakeLists.txt` - 新增 gnss_proc 库链接

### 新增文件
1. `include/gnss_processing.h` - GNSS 坐标转换与质量评估类
2. `src/gnss_processing.cpp` - GNSS 处理类实现
3. `attic/gnss_integration.cpp` - LIVMapper GNSS 函数实现（**已归档**：文中函数早已集成进 `src/LIVMapper.cpp`，本文件仅作历史参考，不参与编译，见 `attic/README.md`）
4. `config/avia_gnss.yaml` - GNSS 配置示例

---

## 集成步骤

### 第一步：将 gnss_integration.cpp 中的函数合并到 LIVMapper.cpp

> 注：这些函数**已经集成**到 `src/LIVMapper.cpp`。本步骤仅对"从零重建"的场景有效；参考副本已归档至 `attic/gnss_integration.cpp`。

#### 1.1 构造函数中添加初始化
在 `LIVMapper::LIVMapper()` 构造函数末尾添加：
```cpp
p_gnss.reset(new GnssProcess());
```

#### 1.2 readParameters() 中添加参数读取
在 `readParameters()` 函数内添加：
```cpp
nh.param<bool>("common/gnss_en", gnss_en, false);
nh.param<string>("common/gnss_topic", gnss_topic, "/gnss/fix");
nh.param<vector<double>>("extrin_calib/gnss_T", gnssextrinT, vector<double>());
nh.param<double>("gnss/outlier_threshold", gnss_outlier_thresh, 3.0);
nh.param<bool>("gnss/outlier_rejection", gnss_outlier_rejection, true);
```

#### 1.3 initializeComponents() 中添加初始化
在 `initializeComponents()` 函数内添加：
```cpp
if (gnss_en && !gnssextrinT.empty())
{
  gnss_extT << VEC_FROM_ARRAY(gnssextrinT);
  p_gnss->setGnssExtrinsic(gnss_extT);
}

if (gnss_en && img_en && lidar_en) {
  slam_mode_ = LIVO_GNSS;
}
```

#### 1.4 initializeSubscribersAndPublishers() 中添加订阅
在订阅者初始化部分添加：
```cpp
if (gnss_en) {
  sub_gnss = nh.subscribe(gnss_topic, 100, &LIVMapper::gnss_cbk, this);
}
```

#### 1.5 initializeFiles() 中添加日志文件
```cpp
if (gnss_en) {
  fout_gnss_pos.open(DEBUG_FILE_DIR("gnss_poses.txt"), ios::out);
}
```

#### 1.6 run() 主循环中添加 GNSS 处理
在 `run()` 函数的 while 循环中，LIDAR 同步处理之后添加：
```cpp
// Process GNSS measurements
if (gnss_en && gnss_origin_set && !gnss_buffer.empty()) {
  mtx_buffer.lock();
  if (!gnss_buffer.empty() && gnss_buffer.front().timestamp < LidarMeasures.last_lio_update_time + 0.5) {
    mtx_buffer.unlock();
    handleGNSS();
  } else {
    mtx_buffer.unlock();
  }
}
```

#### 1.7 将 gnss_integration.cpp 中的 4 个核心函数添加到 LIVMapper.cpp 末尾
（参考副本现位于 `attic/gnss_integration.cpp`；下列函数当前均已在 `src/LIVMapper.cpp` 中实现）
- `gnss_cbk()` - GNSS 数据回调
- `handleGNSS()` - GNSS 处理入口
- `propagateStateToTime()` - 状态时间传播
- `updateStateWithGNSS()` - EKF 更新核心

---

## 核心融合原理

### 观测模型
RTK 提供 ENU 局部坐标系下的绝对位置观测：
```
z_gnss = p_IMU + R_IMU * p_lever_arm + noise
```

### 雅可比矩阵
对 19 维状态向量的观测雅可比：
- 姿态 (0-2): -[R * p_lever]_×  (反对称矩阵)
- 位置 (3-5): 单位矩阵 I
- 其余状态: 0

### 噪声自适应
| 解状态 | 水平噪声 | 垂直噪声 |
|--------|---------|---------|
| RTK 固定解 | 2 cm | 3.6 cm |
| RTK 浮点解 | 30 cm | 54 cm |
| 单点定位 | 3 m | 5.4 m |

### 野值剔除
卡方检验 (3 自由度): γ = rᵀ S⁻¹ r < χ²₃,₀.₉₅ = 7.815

---

## 使用方法

### 1. 配置外参
在 yaml 配置文件中设置 GNSS 天线相对 IMU 的杆臂：
```yaml
extrin_calib:
  gnss_T: [0.0, 0.0, 0.5]   # x, y, z 单位: 米
```

### 2. 启用 GNSS
```yaml
common:
  gnss_en: true
  gnss_topic: "/gnss/fix"
```

### 3. 编译运行
```bash
cd ~/catkin_ws
catkin_make
roslaunch fast_livo mapping_avia.launch config:=avia_gnss.yaml
```

---

## 坐标系说明

- **世界坐标系**: ENU 局部切平面 (East-North-Up)
- **原点**: 第一帧有效 RTK 浮点解的位置
- **IMU 系**: 前-左-上 (FLU) 约定
- **GNSS 观测**: 转换到 ENU 后与状态位置对齐

---

## 调参建议

### 观测噪声
- 开阔环境 RTK 固定解稳定：可适当减小噪声 (0.01~0.02m)
- 城市峡谷多路径严重：增大噪声或提高野值阈值

### 野值阈值
- 默认 3.0 倍标准差，对应置信度 ~99.7%
- 出现频繁失锁可适当放宽到 4.0~5.0

### 初始化
- 确保起步时有 RTK 浮点以上的定位质量
- 静止初始化 3~5 秒后再开始运动

---

## 已知限制与扩展方向

### 当前实现
- [x] 位置观测紧组合融合
- [x] 杆臂补偿 (lever arm)
- [x] 噪声自适应
- [x] 卡方野值剔除

### 可扩展
- [ ] GNSS 速度观测 (多普勒)
- [ ] 双天线航向观测
- [ ] 伪距/载波相位深耦合
- [ ] 坐标系对齐优化 (Yaw 初始化)
- [ ] RTK 失锁检测与状态降级
