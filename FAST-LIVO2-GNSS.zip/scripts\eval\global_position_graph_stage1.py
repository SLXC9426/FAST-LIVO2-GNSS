#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Offline global position graph v1 (no loop closure).

Purpose
-------
Combine a pure-LIVO relative-motion chain with 1 Hz RTK absolute positions and
solve for a globally consistent trajectory. This is the first milestone of the
R6 plan: it is deliberately POSITION-ONLY (orientations are taken from LIVO) so
that the value of the global absolute factors can be measured without touching
the front-end or the dense 25-frame FactorGraph.

Why position-only?
  * The prototype (`.tmp_check/pg/position_graph_proto.py`) showed the big win
    is translational: c01 full 2D 1.47 -> 0.77 m, c02 8.23 -> 2.61 m.
  * A full SE(3) graph is the next step; this tool is the cheap, auditable
    lower bound and the control for that step.

Key design choices (R6_STATE §4.2)
  * LIVO relative factors are frame-invariant; RTK factors are absolute ENU.
  * RTK is split into horizontal (strong) and vertical (weak) factors. A single
    3D Huber norm lets vertical spikes suppress valid horizontal corrections.
  * Each keyframe uses at most one nearest fix; no fix is reused.
  * Static handling is optional and OFF by default. The prototype showed a
    rigid zero-displacement prior can *hurt* (c02 2.61 -> 4.91 m); use
    --static-prior-sigma only for experiments.
  * No per-dataset constants: all weights are CLI arguments with global
    defaults; sweep on c01, validate on c02.

Usage
-----
  global_position_graph.py --livo <livo.tum> --rtk <rtk.tum|bag> \
      [--ref <reference.tum>] [--out <graph.tum>] [--tag TAG] \
      [--rtk-topic /gnss_rtk] [--keyframe-dt 1.0] \
      [--sig-odom 0.05] [--sig-rtk-xy 1.0] [--sig-rtk-z 10.0] \
      [--huber-xy 0.0] [--static-prior-sigma 0.0] \
      [--lever -0.05 -0.325 0.165] [--yaw-deg NAN]

Outputs the same scopes as eval_unified.py (full / steady / movfit /
stat@movfit / static-loc) for the input LIVO, RTK-only, and graph arms.
"""
import argparse
import csv
import math
import os
import subprocess
import sys
import tempfile
import time

import numpy as np

try:
    from scipy.sparse import coo_matrix
    from scipy.sparse.linalg import lsqr
    HAVE_SCIPY = True
except ImportError:
    HAVE_SCIPY = False

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import eval_unified as eu  # noqa: E402  (load_tum, score, static_segments, fit_eval)


# --------------------------------------------------------------------------- io


def load_tum_q(path):
    t, p, q = [], [], []
    for line in open(path, encoding="utf-8", errors="ignore"):
        s = line.split()
        if len(s) < 8:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
            q.append([float(s[4]), float(s[5]), float(s[6]), float(s[7])])
        except ValueError:
            pass
    return np.array(t), np.array(p), np.array(q)


def quat_to_R(q):
    x, y, z, w = q
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def interp_xyz(t_src, p_src, t_dst):
    out = np.empty((len(t_dst), 3))
    for k in range(3):
        out[:, k] = np.interp(t_dst, t_src, p_src[:, k])
    return out


# ------------------------------------------------------------------ TDDD / DD


def ecef_to_geodetic(ecef):
    a = 6378137.0
    e2 = 6.6943799901413165e-3
    x, y, z = ecef
    lon = math.atan2(y, x)
    p = math.hypot(x, y)
    lat = math.atan2(z, p * (1.0 - e2))
    for _ in range(8):
        s = math.sin(lat)
        n = a / math.sqrt(1.0 - e2 * s * s)
        h = p / math.cos(lat) - n
        lat = math.atan2(z, p * (1.0 - e2 * n / (n + h)))
    s = math.sin(lat)
    n = a / math.sqrt(1.0 - e2 * s * s)
    h = p / math.cos(lat) - n
    return lat, lon, h


def enu_matrix(lat, lon):
    sl, cl = np.sin(lat), np.cos(lat)
    so, co = np.sin(lon), np.cos(lon)
    return np.array([
        [-so, co, 0.0],
        [-sl * co, -sl * so, cl],
        [cl * co, cl * so, sl],
    ])


def ecef_to_enu(xyz, base, R):
    return R @ (np.asarray(xyz) - base)


def unit(v):
    n = np.linalg.norm(v)
    return v / n if n > 1e-9 else v


def load_dd_epochs(path):
    """{t_unix: {(sys,freq,ref,sat): row}} from the GREAT-MSF DD CSV."""
    epochs = {}
    with open(path, newline="", encoding="utf-8", errors="ignore") as f:
        for r in csv.DictReader(f):
            try:
                t = float(r["t_unix"])
                key = (r["sys"], r["freq"], r["ref_sat"], r["sat"])
                row = dict(
                    key=key,
                    t=t, t_gps=float(r["t_gps"]),
                    sat=np.array([float(r["sat_x"]), float(r["sat_y"]),
                                  float(r["sat_z"])]),
                    ref=np.array([float(r["ref_x"]), float(r["ref_y"]),
                                  float(r["ref_z"])]),
                    dd_phase=float(r["dd_phase"]),
                    sigma_phase=float(r["sigma_phase"]),
                    elev_sat=float(r["elev_sat"]),
                    elev_ref=float(r["elev_ref"]),
                    slip=int(float(r["slip"])),
                    ref_change=int(float(r["ref_change"])),
                )
            except (ValueError, KeyError, TypeError):
                continue
            epochs.setdefault(t, {})[key] = row
    return epochs


def build_tddd_pairs(tk, dd, tol=0.25, min_pairs=6):
    """Consecutive keyframe pairs with a clean TDDD interval."""
    ts = np.array(sorted(dd))
    out = []
    for i in range(len(tk) - 1):
        if not (0.8 <= tk[i + 1] - tk[i] <= 1.2):
            continue
        j1 = int(np.argmin(np.abs(ts - tk[i])))
        j2 = int(np.argmin(np.abs(ts - tk[i + 1])))
        if abs(ts[j1] - tk[i]) > tol or abs(ts[j2] - tk[i + 1]) > tol:
            continue
        if j1 == j2 or not (0.8 <= ts[j2] - ts[j1] <= 1.2):
            continue
        common = set(dd[ts[j1]]) & set(dd[ts[j2]])
        rows = []
        for k in common:
            r1, r2 = dd[ts[j1]][k], dd[ts[j2]][k]
            if r2["slip"] or r2["ref_change"]:
                continue
            rows.append((r1, r2))
        if len(rows) >= min_pairs:
            out.append((i, float(ts[j1]), float(ts[j2]), rows))
    return out


def dd_geom_enu(row, p_enu, base, R):
    sat = ecef_to_enu(row["sat"], base, R)
    ref = ecef_to_enu(row["ref"], base, R)
    return ((np.linalg.norm(sat - p_enu) - np.linalg.norm(sat))
            - (np.linalg.norm(ref - p_enu) - np.linalg.norm(ref)))


FREQ_SIGMA = {"L1": 0.008, "L2": 0.008, "B2I": 0.025, "B3I": 0.015}


def tddd_pair_rows(rows, p_enu, base, R, sigma_scale=1.0, opts=None):
    """One scalar TDDD row per DD pair: y - g.(p_j - p_i) = 0."""
    out = []
    for r1, r2 in rows:
        sat1 = ecef_to_enu(r1["sat"], base, R)
        ref1 = ecef_to_enu(r1["ref"], base, R)
        sat2 = ecef_to_enu(r2["sat"], base, R)
        ref2 = ecef_to_enu(r2["ref"], base, R)
        # d(dd_geom)/dp = -(u_sat - u_ref)
        g = 0.5 * (unit(ref1 - p_enu) + unit(ref2 - p_enu)) \
            - 0.5 * (unit(sat1 - p_enu) + unit(sat2 - p_enu))
        sat_term = dd_geom_enu(r2, p_enu, base, R) - dd_geom_enu(r1, p_enu, base, R)
        y = (r2["dd_phase"] - r1["dd_phase"]) - sat_term
        sig0 = r2["sigma_phase"]
        if opts is not None:
            if opts.get("freq_sigma_en"):
                sig0 = FREQ_SIGMA.get(r1["key"][1], sig0)
            elev = min(r1["elev_sat"], r1["elev_ref"],
                       r2["elev_sat"], r2["elev_ref"])
            if elev < opts.get("raim_elev_min", 0.0):
                continue
            if sig0 > opts.get("raim_sigma_max", 1e9):
                continue
            if opts.get("elev_weight_en"):
                e = max(elev, 1.0)
                fac = math.sqrt(max(1.0, 1.0 / (2.0 * math.sin(math.radians(e)))))
                sig0 *= fac
        sig = sigma_scale * math.sqrt(2.0) * max(sig0, 1e-3)
        out.append((g, y, 1.0 / sig))
    return out


GPS_EPOCH_UNIX = 315964800.0


def dcm_body_to_enu(pitch_deg, roll_deg, yaw_deg):
    p, r, y = map(math.radians, (pitch_deg, roll_deg, yaw_deg))
    sp, cp = math.sin(p), math.cos(p)
    sr, cr = math.sin(r), math.cos(r)
    sy, cy = math.sin(y), math.cos(y)
    return np.array([
        [cy * cr - sy * sp * sr, -sy * cp, cy * sr + sy * sp * cr],
        [sy * cr + cy * sp * sr, cy * cp, sy * sr - cy * sp * cr],
        [-cp * sr, sp, cp * cr],
    ])


def dcm_ecef_to_enu(lat, lon):
    sl, cl = math.sin(lat), math.cos(lat)
    so, co = math.sin(lon), math.cos(lon)
    return np.array([
        [-so, co, 0.0],
        [-sl * co, -sl * so, cl],
        [cl * co, cl * so, sl],
    ])


def load_ins(path):
    out = {}
    with open(path, "r", errors="replace") as f:
        for line in f:
            if not line.strip() or line.lstrip().startswith("#"):
                continue
            v = line.split()
            if len(v) < 21:
                continue
            try:
                t = float(v[0])
                ecef = np.array([float(v[1]), float(v[2]), float(v[3])])
                pitch, roll, yaw = float(v[7]), float(v[8]), float(v[9])
                status = v[19]
            except (ValueError, IndexError):
                continue
            key = int(round(t))
            if key not in out:
                out[key] = dict(ecef=ecef, att=(pitch, roll, yaw), status=status)
    return out


def ins_antenna(ins, t_gps, lever):
    sow = int(round((t_gps - GPS_EPOCH_UNIX) % 604800.0))
    r = ins.get(sow)
    if r is None:
        return None
    lat, lon, _ = ecef_to_geodetic(r["ecef"])
    return r["ecef"] + dcm_ecef_to_enu(lat, lon).T @ dcm_body_to_enu(*r["att"]) @ lever


def estimate_ref_to_base(rt, rp, ins, base, lever, iters=3):
    """Rigid 2D transform reference-ENU -> base-ENU from RTK TUM vs .ins."""
    R_base = enu_matrix(*ecef_to_geodetic(base)[:2])
    src, dst, dz = [], [], []
    for i, t in enumerate(rt):
        p = ins_antenna(ins, t + 18.0, lever)  # t is UTC; .ins is GPS time
        if p is None:
            continue
        q = R_base @ (p - base)
        src.append(rp[i, :2])
        dst.append(q[:2])
        dz.append(q[2] - rp[i, 2])
    if len(src) < 20:
        return np.eye(2), np.zeros(2), 0.0, 1e9, 0.0, len(src)
    yaw, tr, rms, n = yaw_fit_robust(np.array(src), np.array(dst), iters=iters)
    R2 = np.array([[math.cos(yaw), -math.sin(yaw)],
                   [math.sin(yaw), math.cos(yaw)]])
    tz = float(np.median(dz)) if dz else 0.0
    return R2, tr, tz, rms, yaw, n


def load_lambda_csv(path):
    """Read the per-frame LiDAR Hessian lambda_min log (stamp,lambda_min)."""
    t, v = [], []
    for line in open(path, encoding="utf-8", errors="ignore"):
        s = line.strip().split(",")
        if len(s) < 2:
            continue
        try:
            t.append(float(s[0]))
            v.append(float(s[1]))
        except ValueError:
            pass
    return np.array(t), np.array(v)


def ensure_rtk_tum(path, topic, start, dur):
    """Accept a TUM or a rosbag and return a TUM path."""
    if not path.endswith(".bag"):
        return path
    out = os.path.join(tempfile.gettempdir(),
                       "rtk_%d_%s.tum" % (os.getpid(), os.path.basename(path)))
    conv = os.path.join(HERE, "gnss_bag_to_tum.py")
    cmd = [sys.executable, conv, path, topic, out]
    if start:
        cmd += ["--start", str(start)]
    if dur:
        cmd += ["--dur", str(dur)]
    subprocess.run(cmd, check=True)
    return out


# ------------------------------------------------------------------- alignment


def yaw_fit_robust(p_livo, p_rtk, iters=3):
    """2D rigid yaw+translation, with MAD-based outlier rejection."""
    a = p_livo[:, :2].copy()
    b = p_rtk[:, :2].copy()
    keep = np.ones(len(a), bool)
    yaw, t = 0.0, np.zeros(2)
    for _ in range(iters):
        ac = a[keep] - a[keep].mean(0)
        bc = b[keep] - b[keep].mean(0)
        dot = (ac * bc).sum()
        cross = (ac[:, 0] * bc[:, 1] - ac[:, 1] * bc[:, 0]).sum()
        yaw = math.atan2(cross, dot)
        R = np.array([[math.cos(yaw), -math.sin(yaw)],
                      [math.sin(yaw), math.cos(yaw)]])
        t = b[keep].mean(0) - R @ a[keep].mean(0)
        pred = (R @ a.T).T + t
        r = np.linalg.norm(pred - b, axis=1)
        med = np.median(r[keep])
        mad = np.median(np.abs(r[keep] - med)) + 1e-6
        new_keep = r < med + 3.0 * 1.4826 * mad
        if new_keep.sum() < max(20, 0.5 * keep.sum()):
            break
        if np.array_equal(new_keep, keep):
            break
        keep = new_keep
    pred = (np.array([[math.cos(yaw), -math.sin(yaw)],
                      [math.sin(yaw), math.cos(yaw)]]) @ a.T).T + t
    rms = float(np.sqrt(((pred - b) ** 2).sum(1).mean()))
    return yaw, t, rms, int(keep.sum())


# ------------------------------------------------------------------- graph core


def select_keyframes(t, dt):
    if dt <= 0:
        return np.arange(len(t))
    idx = [0]
    last = t[0]
    for i in range(1, len(t)):
        if t[i] - last >= dt:
            idx.append(i)
            last = t[i]
    return np.array(idx)


def static_mask_keyframes(t, p, thresh=0.10, win=2):
    dt = np.diff(t)
    dt[dt <= 0] = np.inf
    v = np.concatenate([[0.0], np.linalg.norm(np.diff(p, axis=0), axis=1) / dt])
    vm = np.array([np.median(v[max(0, i - win):min(len(v), i + win + 1)])
                   for i in range(len(v))])
    return vm < thresh


def select_oracle_loops(t, ref_t, ref_p, yaw_ref, args):
    """Select oracle loop pairs from a reference trajectory.

    Evaluation only: the loop measurement is the reference displacement between
    two keyframes. It estimates the upper bound of loop-closure benefit and is
    never a production measurement. Only x/y are constrained because the c01/c02
    reference files carry position but no orientation.
    """
    pref = interp_xyz(ref_t, ref_p, t)
    inside = (t >= ref_t[0]) & (t <= ref_t[-1])
    smask = static_mask_keyframes(t, pref, thresh=args.loop_static_v, win=3)
    moving = (~smask) & inside
    R = np.array([[math.cos(yaw_ref), -math.sin(yaw_ref)],
                  [math.sin(yaw_ref), math.cos(yaw_ref)]])
    loops = []
    seen = set()
    n_with_prev = 0
    n_near = 0
    for i in range(len(t)):
        if not moving[i]:
            continue
        # Last keyframe strictly older than loop_min_gap.
        jmax = int(np.searchsorted(t, t[i] - args.loop_min_gap,
                                   side="left")) - 1
        if jmax < 0:
            continue
        js = np.where(moving[:jmax + 1])[0]
        if js.size == 0:
            continue
        n_with_prev += 1
        d = np.linalg.norm(pref[js, :2] - pref[i, :2], axis=1)
        k = int(np.argmin(d))
        if d[k] > args.loop_max_dist:
            continue
        n_near += 1
        j = int(js[k])
        pair = (min(i, j), max(i, j))
        if pair in seen:
            continue
        seen.add(pair)
        dd = R @ (pref[i, :2] - pref[j, :2])
        loops.append((i, j, float(dd[0]), float(dd[1]), float(d[k])))
    diag = {
        "n": len(loops),
        "n_with_prev": n_with_prev,
        "n_near": n_near,
        "moving_frac": float(moving.mean()),
        "static_frac": float(smask.mean()),
        "inside_frac": float(inside.mean()),
    }
    return loops, diag


def loop_residual_rms(p, loops):
    if not loops:
        return 0.0
    e = np.array([p[i, :2] - p[j, :2] - np.array([dx, dy])
                  for i, j, dx, dy, _ in loops])
    return float(np.sqrt((e ** 2).sum(1).mean()))


def write_loop_report(path, t, loops, residual_rms=None, extra=""):
    parent = os.path.dirname(os.path.abspath(path))
    if parent:
        os.makedirs(parent, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write("# oracle loops %s\n" % extra)
        f.write("i\tj\tt_i\tt_j\tgap_s\tdist_ref_m\tdx_m\tdy_m\n")
        for i, j, dx, dy, dist in loops:
            f.write("%d\t%d\t%.6f\t%.6f\t%.3f\t%.4f\t%.4f\t%.4f\n" %
                    (i, j, t[i], t[j], t[i] - t[j], dist, dx, dy))
        if residual_rms is not None:
            f.write("# loop residual RMS = %.4f m, n=%d\n" %
                    (residual_rms, len(loops)))


def consistency_sigma(t, p, rtk_t, rtk_p_at_kf, yaw, args):
    """Per-keyframe RTK sigma from the LIO-vs-RTK relative-motion agreement.

    c01: LIO is locally accurate, the 60 s relative motion agrees with RTK ->
         weak absolute RTK (do not let a slow RTK bias distort the LIO shape).
    c02: LIO drifts, the relative motion disagrees -> strong absolute RTK.
    This is a global rule (same window/thresholds for every dataset).
    """
    n = len(t)
    Rz = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                   [math.sin(yaw), math.cos(yaw), 0],
                   [0, 0, 1.0]])
    p_enu = (Rz @ p.T).T
    W = max(args.consistency_window, 1.0)
    # Static keyframes must not enter the consistency statistics: their RTK
    # scatter is small but meaningless for the "is LIO drifting?" question.
    dtk = np.diff(t)
    dtk[dtk <= 0] = np.inf
    v = np.concatenate([[0.0], np.linalg.norm(np.diff(p_enu, axis=0), axis=1) / dtk])
    vm = np.array([np.median(v[max(0, i - 2):min(n, i + 3)]) for i in range(n)])
    moving = vm > 0.15
    e = np.zeros(n)
    for i in range(n):
        if not moving[i]:
            e[i] = args.e_low
            continue
        j = int(np.searchsorted(t, t[i] - W))
        j = max(0, min(j, i - 1))
        dt = t[i] - t[j]
        if dt < 0.5 * W:
            e[i] = args.e_low
            continue
        d_lio = p_enu[i] - p_enu[j]
        d_rtk = rtk_p_at_kf[i] - rtk_p_at_kf[j]
        e[i] = np.linalg.norm((d_lio - d_rtk)[:2]) / dt
    # median filter over moving neighbours only (+/-3 keyframes)
    em = np.empty(n)
    for i in range(n):
        sl = slice(max(0, i - 3), min(n, i + 4))
        vals = e[sl][moving[sl]]
        em[i] = np.median(vals) if vals.size else args.e_low
    sig = np.empty(n)
    for i, v in enumerate(em):
        if v <= args.e_low:
            sig[i] = args.sigma_rtk_weak
        elif v >= args.e_high:
            sig[i] = args.sigma_rtk_strong
        else:
            f = (v - args.e_low) / max(args.e_high - args.e_low, 1e-9)
            sig[i] = args.sigma_rtk_weak + f * (args.sigma_rtk_strong -
                                                args.sigma_rtk_weak)
    n_weak = int(np.sum(sig >= 0.5 * (args.sigma_rtk_weak +
                                      args.sigma_rtk_strong)))
    mv = em[moving] if np.any(moving) else em
    print("  adaptive rtk: moving e p10/p50/p90 = %.4f/%.4f/%.4f m/s; "
          "weak-side keyframes %.1f%%; sigma range %.2f..%.2f m" %
          (np.percentile(mv, 10), np.percentile(mv, 50), np.percentile(mv, 90),
           100.0 * n_weak / n, sig.min(), sig.max()))
    return sig


def load_rel_weight(path, t_kf):
    """WP3: read a per-keyframe reliability weight CSV.

    Accepts either `t,w` (one row per keyframe/window centre) or
    `w0,w1,w` (window start/end/weight).  Weights are interpolated to the
    keyframe times and clipped to [0.02, 1.0].
    """
    ts, ws = [], []
    with open(path, "r", newline="", encoding="utf-8-sig", errors="ignore") as f:
        rd = csv.DictReader(f)
        fields = rd.fieldnames or []
        for r in rd:
            try:
                if "t" in fields and "w" in fields:
                    ts.append(float(r["t"]))
                    ws.append(float(r["w"]))
                elif "w0" in fields and "w1" in fields and "w" in fields:
                    ts.append(0.5 * (float(r["w0"]) + float(r["w1"])))
                    ws.append(float(r["w"]))
            except (ValueError, KeyError, TypeError):
                continue
    if not ts:
        raise ValueError("empty reliability weight CSV: %s" % path)
    order = np.argsort(ts)
    ts = np.asarray(ts, dtype=float)[order]
    ws = np.asarray(ws, dtype=float)[order]
    out = np.interp(t_kf, ts, ws)
    return np.clip(out, 0.02, 1.0)


def load_rtk_status(path):
    """Read per-epoch RTK status from bag_quality CSV (`t,status`)."""
    ts, st = [], []
    with open(path, "r", newline="", encoding="utf-8-sig", errors="ignore") as f:
        rd = csv.DictReader(f)
        for r in rd:
            try:
                ts.append(float(r["t"]))
                st.append(int(float(r["status"])))
            except (ValueError, KeyError, TypeError):
                continue
    if not ts:
        raise ValueError("empty RTK status CSV: %s" % path)
    order = np.argsort(ts)
    return np.asarray(ts, dtype=float)[order], np.asarray(st, dtype=int)[order]


def load_imu_csv(path):
    """Read IMU CSV (t, ax, ay, az, gx, gy, gz, ...)."""
    a = np.loadtxt(path, delimiter=",", skiprows=1)
    return a[:, 0], a[:, 1:4], a[:, 4:7]


def rot_vec(w):
    """SO(3) exponential map for a rotation vector."""
    th = float(np.linalg.norm(w))
    if th < 1e-9:
        return np.eye(3)
    k = w / th
    K = np.array([[0.0, -k[2], k[1]],
                  [k[2], 0.0, -k[0]],
                  [-k[1], k[0], 0.0]])
    return np.eye(3) + math.sin(th) * K + (1.0 - math.cos(th)) * (K @ K)


def fix_jump_mask(rtk_t, rtk_p, max_jump):
    """P1: horizontal jump of each fix from the local (+/-2 s) RTK median."""
    ok = np.ones(len(rtk_t), dtype=bool)
    if max_jump <= 0.0 or len(rtk_t) < 3:
        return ok
    for j in range(len(rtk_t)):
        m = np.abs(rtk_t - rtk_t[j]) <= 2.0
        if m.sum() >= 3:
            med = np.median(rtk_p[m, :2], axis=0)
            ok[j] = np.linalg.norm(rtk_p[j, :2] - med) <= max_jump
    return ok


def solve_graph(t, p, q, rtk_t, rtk_p, yaw, tr_xy, args, sig_rtk_vec=None,
                loops=None, tddd=None, lambda_kf=None, rel_w=None,
                rtk_status=None, rtk_kf=None, imu=None):
    n = len(t)
    Rz = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                   [math.sin(yaw), math.cos(yaw), 0],
                   [0, 0, 1.0]])
    p0 = (Rz @ p.T).T + np.array([tr_xy[0], tr_xy[1], 0.0])

    # unique nearest fix per keyframe
    ir = np.array([int(np.argmin(np.abs(rtk_t - x))) for x in t])
    ok_raw = np.abs(rtk_t[ir] - t) < args.fix_max_dt
    ok = ok_raw.copy()
    def rtk_p_at(i):
        """Absolute RTK position at keyframe i (interpolated if requested)."""
        return rtk_kf[i] if rtk_kf is not None else rtk_p[ir[i]]

    fix_jump_ok = fix_jump_mask(rtk_t, rtk_p, args.fixed_max_jump)

    fixed_innov_ok = np.ones(len(t), dtype=bool)

    def fixed_ok(i):
        """P1: Fixed status is not enough; reject a local RTK jump or a
        motion-compensated innovation outlier."""
        if not (args.status_sigma_en and rtk_status is not None
                and rtk_status[ir[i]] == 5):
            return True
        return bool(fix_jump_ok[ir[i]]) and bool(fixed_innov_ok[i])

    if args.fixed_max_jump > 0 and rtk_status is not None:
        n_veto = sum(1 for i in range(len(t)) if ok[i]
                     and rtk_status[ir[i]] == 5 and not fix_jump_ok[ir[i]])
        if n_veto:
            print("  fixed consistency veto: %d Fixed keyframes rejected "
                  "(local jump > %.2f m)" % (n_veto, args.fixed_max_jump))
    if args.rtk_subsample > 1:
        # Decimate the absolute factors: correlated RTK bias should not be
        # counted as N independent observations. This is a global rate, not a
        # per-dataset constant.
        ok &= (ir % args.rtk_subsample == 0)
    used = {}
    for i in np.where(ok)[0]:
        j = int(ir[i])
        if j not in used:
            used[j] = i
        else:
            ok[i] = False
    n_fix = int(ok.sum())

    Rbody = [quat_to_R(qq) for qq in q]
    if args.fixed_max_innov_sigma > 0 and rtk_status is not None:
        last_t = None
        last_ant = None
        last_lio = None
        prev_t = None
        prev_ant = None
        n_veto_innov = 0
        scale_win = []
        offset_win = []
        offset = None
        imu_offset_win = []
        imu_offset = None
        prop_p = None
        prop_v = None
        prop_R = None
        prop_t = None
        hist = []
        anchor_t = None
        anchor_ant = None
        last_body = None
        last_R = None
        last_v = None
        g_world = np.array([0.0, 0.0, -9.81])
        if (args.fixed_innov_mode in ("imu", "imu_rtk", "imu_rtk_med")
                and imu is not None):
            t_imu, acc_imu, gyr_imu = imu
            m0 = (t_imu >= t[0]) & (t_imu <= t[0] + 10.0)
            if m0.sum() > 10:
                R0 = Rz @ Rbody[0]
                g_world = -np.mean((R0 @ acc_imu[m0].T).T, axis=0)
            print("  imu gravity: [%.3f %.3f %.3f]" % tuple(g_world))

            def imu_propagate(p_b, v_b, R_b, t0, t1):
                t_prev = t0
                a = int(np.searchsorted(t_imu, t0, side="right"))
                b = int(np.searchsorted(t_imu, t1, side="right"))
                for k in range(a, b):
                    dtk = t_imu[k] - t_prev
                    if dtk <= 0:
                        continue
                    R_b = R_b @ rot_vec(gyr_imu[k] * dtk)
                    a_w = R_b @ acc_imu[k] + g_world
                    p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                    v_b = v_b + a_w * dtk
                    t_prev = t_imu[k]
                dtk = t1 - t_prev
                if dtk > 0 and b > a:
                    kk = b - 1
                    R_b = R_b @ rot_vec(gyr_imu[kk] * dtk)
                    a_w = R_b @ acc_imu[kk] + g_world
                    p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                    v_b = v_b + a_w * dtk
                return p_b, v_b, R_b
        init_scale = 1.0
        if args.fixed_innov_local_scale_en:
            idx0 = [i for i in range(n) if ok[i] and rtk_status[ir[i]] == 5]
            if len(idx0) >= 5:
                i0 = idx0[0]
                lio0 = p0[i0] + Rz @ Rbody[i0] @ np.asarray(args.lever)
                rtk0 = rtk_p_at(i0)
                ratios = []
                for i in idx0[1:]:
                    lio_i = p0[i] + Rz @ Rbody[i] @ np.asarray(args.lever)
                    dl = float(np.linalg.norm((lio_i - lio0)[:2]))
                    dr = float(np.linalg.norm((rtk_p_at(i) - rtk0)[:2]))
                    if dl > 5.0 and dr > 5.0:
                        ratios.append(dr / dl)
                if len(ratios) >= 3:
                    init_scale = float(np.median(ratios))
                    init_scale = min(args.fixed_innov_scale_max,
                                     max(args.fixed_innov_scale_min, init_scale))
                    print("  fixed innovation init scale: %.4f (n=%d)" % (
                        init_scale, len(ratios)))
        debug_rows = []
        for i in range(n):
            if not ok[i] or rtk_status[ir[i]] != 5:
                continue
            lio_ant = p0[i] + Rz @ Rbody[i] @ np.asarray(args.lever)
            rtk_ant = rtk_p_at(i)
            if args.fixed_innov_mode == "imu_rtk_med":
                # Drop stale anchors even when no fix has been accepted for a
                # while; otherwise a Float gap makes every later Fixed frame
                # re-integrate from a minutes-old anchor (O(n^2)).
                hist = [h for h in hist if 0.0 <= t[i] - h["t"] <= 5.0]
            accepted = 1
            r_val = -1.0
            pred = rtk_ant.copy()
            s_val = 1.0
            sig_val = float(args.fixed_innov_sigma_rtk)
            if last_t is not None:
                dt = max(t[i] - last_t, 0.0)
                d_lio = lio_ant - last_lio
                d_rtk = rtk_ant - last_ant
                if (args.fixed_innov_mode == "imu_rtk"
                        and imu is not None and prop_t is not None):
                    p_b = prop_p.copy()
                    v_b = prop_v.copy()
                    R_b = prop_R.copy()
                    t_prev = prop_t
                    a = int(np.searchsorted(t_imu, prop_t, side="right"))
                    b = int(np.searchsorted(t_imu, t[i], side="right"))
                    for k in range(a, b):
                        dtk = t_imu[k] - t_prev
                        if dtk <= 0:
                            continue
                        R_b = R_b @ rot_vec(gyr_imu[k] * dtk)
                        a_w = R_b @ acc_imu[k] + g_world
                        p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                        v_b = v_b + a_w * dtk
                        t_prev = t_imu[k]
                    dtk = t[i] - t_prev
                    if dtk > 0 and b > a:
                        kk = b - 1
                        R_b = R_b @ rot_vec(gyr_imu[kk] * dtk)
                        a_w = R_b @ acc_imu[kk] + g_world
                        p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                        v_b = v_b + a_w * dtk
                    prop_p, prop_v, prop_R, prop_t = p_b, v_b, R_b, t[i]
                    pred = p_b + R_b @ np.asarray(args.lever)
                    dt_since = ((t[i] - anchor_t) if anchor_t is not None
                                else (t[i] - prop_t))
                    s_val = 1.0
                    sig_pred = min(0.2 + 0.2 * dt_since,
                                   args.fixed_innov_sigma_max)
                elif (args.fixed_innov_mode == "imu_rtk_med"
                        and imu is not None and hist):
                    # Closure test: robust multi-frame anchor.  Each accepted
                    # fix is propagated to the current keyframe with IMU and
                    # the median antenna position is the predictor.  One bad
                    # Fixed fix can no longer poison the anchor.
                    ants = []
                    for h in hist:
                        p_h, _v_h, R_h = imu_propagate(
                            h["p"], h["v"], h["R"], h["t"], t[i])
                        ants.append(p_h + R_h @ np.asarray(args.lever))
                    pred = np.median(np.array(ants), axis=0)
                    s_val = 1.0
                    sig_pred = min(0.2 + 0.2 * (t[i] - hist[-1]["t"]),
                                   args.fixed_innov_sigma_max)
                elif (args.fixed_innov_mode == "imu"
                        and imu is not None and i > 0):
                    j = i - 1
                    p_b = p0[j].copy()
                    R_b = Rz @ Rbody[j]
                    if j > 0 and t[j] > t[j - 1]:
                        v_b = (p0[j] - p0[j - 1]) / (t[j] - t[j - 1])
                    else:
                        v_b = np.zeros(3)
                    t_prev = t[j]
                    a = int(np.searchsorted(t_imu, t[j], side="right"))
                    b = int(np.searchsorted(t_imu, t[i], side="right"))
                    for k in range(a, b):
                        dtk = t_imu[k] - t_prev
                        if dtk <= 0:
                            continue
                        R_b = R_b @ rot_vec(gyr_imu[k] * dtk)
                        a_w = R_b @ acc_imu[k] + g_world
                        p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                        v_b = v_b + a_w * dtk
                        t_prev = t_imu[k]
                    dtk = t[i] - t_prev
                    if dtk > 0 and b > a:
                        kk = b - 1
                        R_b = R_b @ rot_vec(gyr_imu[kk] * dtk)
                        a_w = R_b @ acc_imu[kk] + g_world
                        p_b = p_b + v_b * dtk + 0.5 * a_w * dtk * dtk
                        v_b = v_b + a_w * dtk
                    pred = p_b + R_b @ np.asarray(args.lever)
                    if imu_offset is not None:
                        pred = pred + imu_offset
                    s_val = 1.0
                    sig_pred = min(args.imu_pred_sigma_base
                                   + args.imu_pred_sigma_rate * dt,
                                   args.fixed_innov_sigma_max)
                elif args.fixed_innov_mode == "imu_rtk_med":
                    # No recent accepted anchor: do not veto (accept raw RTK).
                    pred = rtk_ant.copy()
                    s_val = 1.0
                    sig_pred = args.fixed_innov_sigma_rtk
                elif args.fixed_innov_mode == "lio_abs":
                    pred = (rtk_ant.copy() if offset is None
                            else lio_ant + offset)
                    s_val = 1.0
                    sig_pred = min(0.5 + 0.2 * dt,
                                   args.fixed_innov_sigma_max)
                elif args.fixed_innov_mode == "rtk":
                    v = np.zeros(3)
                    if prev_t is not None and last_t - prev_t > 1e-6:
                        v = (last_ant - prev_ant) / (last_t - prev_t)
                    pred = last_ant + v * dt
                    s_val = 1.0
                    sig_pred = min(1.0 + 0.5 * dt,
                                   args.fixed_innov_sigma_max)
                else:
                    s = (init_scale if args.fixed_innov_local_scale_en else 1.0)
                    if args.fixed_innov_local_scale_en and len(scale_win) >= 3:
                        s = float(np.median(scale_win))
                        s = min(args.fixed_innov_scale_max,
                                max(args.fixed_innov_scale_min, s))
                    pred = last_ant + s * d_lio
                    sig_pred = min(args.fixed_innov_sigma_pred
                                   + args.fixed_innov_sigma_rate * dt
                                   + args.fixed_innov_sigma_rel
                                   * float(np.linalg.norm(d_lio[:2])),
                                   args.fixed_innov_sigma_max)
                    s_val = float(s)
                sig = math.sqrt(args.fixed_innov_sigma_rtk ** 2
                                + sig_pred ** 2)
                r_val = float(np.linalg.norm((rtk_ant - pred)[:2])
                              / max(sig, 1e-6))
                sig_val = float(sig)
                if r_val > args.fixed_max_innov_sigma:
                    accepted = 0
                    fixed_innov_ok[i] = False
                    n_veto_innov += 1
            debug_rows.append(dict(
                t=float(t[i]), accepted=accepted, r=r_val,
                rtk_x=float(rtk_ant[0]), rtk_y=float(rtk_ant[1]),
                pred_x=float(pred[0]), pred_y=float(pred[1]),
                lio_x=float(lio_ant[0]), lio_y=float(lio_ant[1]),
                s=s_val, sig=sig_val))
            if not accepted:
                continue
            if args.fixed_innov_mode == "imu_rtk":
                if (anchor_t is not None and 0.0 < t[i] - anchor_t <= 3.0):
                    v_new = (rtk_ant - anchor_ant) / (t[i] - anchor_t)
                elif prop_v is not None:
                    v_new = prop_v
                else:
                    v_new = np.zeros(3)
                R_new = Rz @ Rbody[i]
                prop_p = rtk_ant - R_new @ np.asarray(args.lever)
                prop_v = v_new
                prop_R = R_new
                prop_t = t[i]
                anchor_t = t[i]
                anchor_ant = rtk_ant.copy()
            if args.fixed_innov_mode == "imu_rtk_med":
                # Velocity from a robust median of recent accepted RTK fixes.
                # The rerun5 LIO can be metres/s wrong in yaw at a manoeuvre;
                # using its velocity here injects that error into the anchor.
                vs = []
                if args.med_vel_source == "rtk":
                    for k in range(max(1, len(hist) - 4), len(hist)):
                        dtk = hist[k]["t"] - hist[k - 1]["t"]
                        if 0.0 < dtk <= 3.0:
                            vs.append((hist[k]["ant"] - hist[k - 1]["ant"]) / dtk)
                if vs:
                    v_new = np.median(np.array(vs), axis=0)
                elif i > 0 and i + 1 < n and t[i + 1] > t[i - 1]:
                    v_new = (p0[i + 1] - p0[i - 1]) / (t[i + 1] - t[i - 1])
                elif i > 0 and t[i] > t[i - 1]:
                    v_new = (p0[i] - p0[i - 1]) / (t[i] - t[i - 1])
                else:
                    v_new = np.zeros(3)
                R_new = Rz @ Rbody[i]
                p_new = rtk_ant - R_new @ np.asarray(args.lever)
                hist.append(dict(t=float(t[i]), p=p_new, v=v_new,
                                 R=R_new, ant=rtk_ant.copy()))
                if len(hist) > 5:
                    hist.pop(0)
                hist = [h for h in hist if t[i] - h["t"] <= 5.0]
            if args.fixed_innov_mode == "imu":
                last_body = p0[i].copy()
                last_R = Rz @ Rbody[i]
                last_v = ((p0[i] - p0[i - 1]) / (t[i] - t[i - 1])
                          if i > 0 and t[i] > t[i - 1] else np.zeros(3))
                lio_ant_i = p0[i] + Rz @ Rbody[i] @ np.asarray(args.lever)
                imu_offset_win.append(rtk_ant - lio_ant_i)
                if len(imu_offset_win) > 10:
                    imu_offset_win.pop(0)
                imu_offset = np.median(np.array(imu_offset_win), axis=0)
            if args.fixed_innov_mode == "lio_abs":
                offset_win.append(rtk_ant - lio_ant)
                if len(offset_win) > 10:
                    offset_win.pop(0)
                offset = np.median(np.array(offset_win), axis=0)
            if (last_t is not None and args.fixed_innov_local_scale_en
                    and np.linalg.norm(d_lio[:2]) > 0.5
                    and np.linalg.norm(d_rtk[:2]) > 0.5):
                scale_win.append(float(np.linalg.norm(d_rtk[:2])
                                       / np.linalg.norm(d_lio[:2])))
                if len(scale_win) > args.fixed_innov_scale_window:
                    scale_win.pop(0)
            if last_t is not None:
                prev_t = last_t
                prev_ant = last_ant.copy()
            last_t = t[i]
            last_ant = rtk_ant.copy()
            last_lio = lio_ant.copy()
        if args.fixed_innov_debug_csv and debug_rows:
            d = os.path.dirname(args.fixed_innov_debug_csv)
            if d:
                os.makedirs(d, exist_ok=True)
            with open(args.fixed_innov_debug_csv, "w", newline="",
                      encoding="utf-8-sig") as f:
                w = csv.DictWriter(f, fieldnames=list(debug_rows[0].keys()))
                w.writeheader()
                w.writerows(debug_rows)
            print("  fixed innovation debug: %s" % args.fixed_innov_debug_csv)
        if n_veto_innov:
            print("  fixed innovation veto: %d Fixed keyframes rejected "
                  "(r > %.1f sigma)" % (n_veto_innov, args.fixed_max_innov_sigma))
    lever = np.array(args.lever)
    tddd_opts = dict(
        freq_sigma_en=bool(args.tddd_freq_sigma_en),
        elev_weight_en=bool(args.elev_weight_en),
        raim_elev_min=args.raim_elev_min,
        raim_sigma_max=args.raim_sigma_max,
    )

    # Continuous geometric-conditioning weight.  FAST-LIVOG's Mode A/B logic:
    # a well-conditioned LIO (high lambda_min) gets a low RTK weight; a degraded
    # LIO (low lambda_min) trusts the RAIM-passed RTK.  This uses the LiDAR
    # Hessian, not the LIO-GNSS innovation, so it does not close the circularity
    # loop documented in gnss_processing.h / EVAL_PROTOCOL 6.3c.
    w_lambda = np.ones(n)
    if args.lambda_weight_en and lambda_kf is not None:
        lam = np.asarray(lambda_kf, dtype=float)
        ok = np.isfinite(lam)
        if ok.any():
            th = args.lambda_th if args.lambda_th >= 0 else float(np.median(lam[ok]))
            sc = args.lambda_scale if args.lambda_scale > 0 else max(
                float(np.percentile(lam[ok], 75) - np.percentile(lam[ok], 25)), 1e-6)
            z = np.clip((lam - th) / sc, -50.0, 50.0)
            w_raw = 1.0 / (1.0 + np.exp(z))  # high lambda -> 0, low -> 1
            if args.lambda_mode == "one_sided":
                # Only a degraded (low-lambda) LIO gets more RTK authority;
                # a well-conditioned but biased LIO is not further trusted.
                w_lambda = 1.0 + args.lambda_gain * w_raw
            else:
                w_lambda = args.lambda_w_min + (1.0 - args.lambda_w_min) * w_raw
            w_lambda[~ok] = 1.0
            print("  lambda weight: th=%.3f scale=%.3f w(min/med/max)=%.2f/%.2f/%.2f" %
                  (th, sc, w_lambda.min(), np.median(w_lambda), w_lambda.max()))

    # ------------------------------------------------------------------
    # General adaptive rule (no dataset-specific thresholds):
    #   z_lio  = normalized TDDD-vs-LIO relative-displacement residual
    #   s_lam  = standardized log(lambda_min) within the run
    #   TDDD factor weight : high only when the LIO is TDDD-inconsistent
    #   RTK weight         : low only when LIO is both well-conditioned and
    #                        TDDD-consistent (i.e. it is safe to trust LIO)
    # ------------------------------------------------------------------
    z_int = {}
    tf_int = {}
    w_gen = np.ones(n)
    if args.general_adapt and tddd is not None:
        R2g = tddd.get("R2", np.eye(2))
        t2g = tddd.get("t2", np.zeros(2))
        tzg = tddd.get("tz", 0.0)
        for (i, _t1, _t2, dd_rows) in tddd["pairs"]:
            if i + 1 >= n:
                continue
            p_base = np.empty(3)
            p_base[:2] = R2g @ p0[i, :2] + t2g
            p_base[2] = p0[i, 2] + tzg
            dp_lio = p0[i + 1] - p0[i]
            zz = []
            for g_b, y, w in tddd_pair_rows(dd_rows, p_base, tddd["base"],
                                            tddd["R"], args.tddd_sigma_scale,
                                            opts=tddd_opts):
                g = np.empty(3)
                g[:2] = R2g.T @ g_b[:2]
                g[2] = g_b[2]
                zz.append(abs(y - float(g @ dp_lio)) * w)
            if zz:
                z_int[i] = float(np.median(zz))
        win = max(1, int(round(args.general_window)))
        z_sm = np.full(n, np.nan)
        for i in range(n):
            vals = [z_int[j] for j in range(max(0, i - win), min(n - 1, i + win + 1))
                    if j in z_int]
            if vals:
                z_sm[i] = float(np.median(vals))

        # Long-baseline z: compare the W-second TDDD displacement with the LIO
        # window displacement.  The 1 s residual cannot see a slow scale/velocity
        # bias; the 10 s baseline can.
        Wg = max(2, int(round(args.general_z_window)))
        by_w = {p[0]: p for p in tddd["pairs"]}
        z_win = np.full(n, np.nan)
        for i0 in range(0, n - Wg, Wg):
            if any(i not in by_w for i in range(i0, i0 + Wg)):
                continue
            keys = None
            for i in range(i0, i0 + Wg):
                kk = set(r[0]["key"] for r in by_w[i][3])
                keys = kk if keys is None else (keys & kk)
            if not keys or len(keys) < 2:
                continue
            start_rows = {r[0]["key"]: r[0] for r in by_w[i0][3]}
            end_rows = {r[1]["key"]: r[1] for r in by_w[i0 + Wg - 1][3]}
            p_base = np.empty(3)
            p_base[:2] = R2g @ p0[i0, :2] + t2g
            p_base[2] = p0[i0, 2] + tzg
            H = np.zeros((3, 3))
            b = np.zeros(3)
            for k in keys:
                rs = start_rows.get(k)
                re = end_rows.get(k)
                if rs is None or re is None:
                    continue
                sat_s = ecef_to_enu(rs["sat"], tddd["base"], tddd["R"])
                ref_s = ecef_to_enu(rs["ref"], tddd["base"], tddd["R"])
                sat_e = ecef_to_enu(re["sat"], tddd["base"], tddd["R"])
                ref_e = ecef_to_enu(re["ref"], tddd["base"], tddd["R"])
                g_b = 0.5 * (unit(ref_s - p_base) + unit(ref_e - p_base)) \
                    - 0.5 * (unit(sat_s - p_base) + unit(sat_e - p_base))
                g = np.empty(3)
                g[:2] = R2g.T @ g_b[:2]
                g[2] = g_b[2]
                sat_term = (dd_geom_enu(re, p_base, tddd["base"], tddd["R"])
                            - dd_geom_enu(rs, p_base, tddd["base"], tddd["R"]))
                yy = (re["dd_phase"] - rs["dd_phase"]) - sat_term
                sig = args.tddd_sigma_scale * math.sqrt(2.0) * max(re["sigma_phase"], 1e-3)
                ww = 1.0 / sig
                H += (ww * ww) * np.outer(g, g)
                b += (ww * ww) * g * yy
            ev, V = np.linalg.eigh(H)
            floor = max(float(ev.max()) * 1e-8, 1e-12)
            ev = np.maximum(ev, floor)
            Sigma = V @ np.diag(1.0 / ev) @ V.T
            drop = Sigma @ b
            L = np.linalg.cholesky(Sigma + 1e-12 * np.eye(3))
            A = np.linalg.inv(L)
            r_win = A @ (p0[i0 + Wg] - p0[i0] - drop)
            z_win[i0:i0 + Wg + 1] = float(np.linalg.norm(r_win) / math.sqrt(3.0))
        z_use = np.where(np.isfinite(z_win), z_win, z_sm)

        sig_lam = np.ones(n)
        if lambda_kf is not None:
            lnl = np.log(np.maximum(np.asarray(lambda_kf, dtype=float), 1e-9))
            ok_l = np.isfinite(lnl)
            if ok_l.any():
                med_l = float(np.median(lnl[ok_l]))
                mad_l = 1.4826 * float(np.median(np.abs(lnl[ok_l] - med_l)))
                sig_lam = 1.0 / (1.0 + np.exp(-(lnl - med_l) / max(mad_l, 0.1)))
                sig_lam[~ok_l] = 0.5
        fit_rms = float(getattr(args, "fit_rms", 1e9))
        s_fit = fit_rms / max(args.general_sigma_expected, 1e-6)
        zf = np.clip((s_fit - args.general_fit_sigma) /
                     max(args.general_fit_scale, 1e-6), -50.0, 50.0)
        tf_fit = 1.0 / (1.0 + np.exp(-zf))
        trust_fit = 1.0 / (1.0 + np.exp(zf))  # high fit -> 0
        for i in range(n):
            tf_int[i] = tf_fit
            w_gen[i] = 1.0 - args.general_gain * trust_fit * sig_lam[i]
        w_gen = np.clip(w_gen, args.general_w_min, 1.0)
        print("  general adapt: fit_rms=%.2f (%.2f sigma) tf=%.2f trust=%.2f "
              "w_gen(min/med/max)=%.2f/%.2f/%.2f" %
              (fit_rms, s_fit, tf_fit, trust_fit,
               w_gen.min(), np.median(w_gen), w_gen.max()))

    # TDDD relative-consistency gate: independent of the LIO prior.  If the RTK
    # displacement between two fixes disagrees with the carrier-phase TDDD, the
    # absolute fix is soft-downweighted.  This is what catches c02 600-620 s.
    w_cons = np.ones(n)
    if args.tddd_consistency_gate and tddd is not None:
        n_gate = 0
        for (i, _t1, _t2, dd_rows) in tddd["pairs"]:
            if i + 1 >= n or not (ok[i] and ok[i + 1]):
                continue
            lw0 = Rz @ Rbody[i] @ lever
            lw1 = Rz @ Rbody[i + 1] @ lever
            dp_rtk = (rtk_p[ir[i + 1]] - lw1) - (rtk_p[ir[i]] - lw0)
            R2 = tddd.get("R2", np.eye(2))
            t2 = tddd.get("t2", np.zeros(2))
            tz = tddd.get("tz", 0.0)
            p_base = np.empty(3)
            p_base[:2] = R2 @ p0[i, :2] + t2
            p_base[2] = p0[i, 2] + tz
            rr = []
            for g, y, _w in tddd_pair_rows(
                    dd_rows, p_base, tddd["base"], tddd["R"],
                    args.tddd_sigma_scale, opts=tddd_opts):
                g_ref = np.empty(3)
                g_ref[:2] = R2.T @ g[:2]
                g_ref[2] = g[2]
                rr.append(y - float(g_ref @ dp_rtk))
            rr = np.array(rr)
            if rr.size == 0:
                continue
            r_cons = float(np.median(np.abs(rr)))
            wc = math.exp(-0.5 * (r_cons / max(args.tddd_consistency_sigma, 1e-6)) ** 2)
            w_cons[i + 1] = min(w_cons[i + 1], wc)
            if wc < 0.5:
                n_gate += 1
        print("  TDDD consistency gate: %d fix(es) with weight < 0.5" % n_gate)

    # Long-baseline TDDD window factors: aggregate the per-second scalar rows
    # over W keyframes, solve the 3D displacement, and add one whitened
    # relative factor.  This observes the along-track direction over a longer
    # baseline, where the single-epoch DD geometry is weak.
    tddd_windows = []
    if tddd is not None and not args.tddd_gate_only and args.tddd_window >= 2:
        by_i = {p[0]: p for p in tddd["pairs"]}
        R2w = tddd.get("R2", np.eye(2))
        t2w = tddd.get("t2", np.zeros(2))
        tzw = tddd.get("tz", 0.0)
        W = int(args.tddd_window)
        for i0 in range(0, n - W, W):
            if any(i not in by_i for i in range(i0, i0 + W)):
                continue
            # Common DD keys across the whole window.  The per-interval builder
            # already dropped any interval with slip/ref_change, so a common key
            # has a continuous ambiguity over the window.
            keys = None
            for i in range(i0, i0 + W):
                kk = set(r[0]["key"] for r in by_i[i][3])
                keys = kk if keys is None else (keys & kk)
            if not keys or len(keys) < 2:
                continue
            start_rows = {r[0]["key"]: r[0] for r in by_i[i0][3]}
            end_rows = {r[1]["key"]: r[1] for r in by_i[i0 + W - 1][3]}
            p_base = np.empty(3)
            p_base[:2] = R2w @ p0[i0, :2] + t2w
            p_base[2] = p0[i0, 2] + tzw
            H = np.zeros((3, 3))
            b = np.zeros(3)
            for k in keys:
                rs = start_rows.get(k)
                re = end_rows.get(k)
                if rs is None or re is None:
                    continue
                sat_s = ecef_to_enu(rs["sat"], tddd["base"], tddd["R"])
                ref_s = ecef_to_enu(rs["ref"], tddd["base"], tddd["R"])
                sat_e = ecef_to_enu(re["sat"], tddd["base"], tddd["R"])
                ref_e = ecef_to_enu(re["ref"], tddd["base"], tddd["R"])
                g_b = 0.5 * (unit(ref_s - p_base) + unit(ref_e - p_base)) \
                    - 0.5 * (unit(sat_s - p_base) + unit(sat_e - p_base))
                g = np.empty(3)
                g[:2] = R2w.T @ g_b[:2]
                g[2] = g_b[2]
                sat_term = (dd_geom_enu(re, p_base, tddd["base"], tddd["R"])
                            - dd_geom_enu(rs, p_base, tddd["base"], tddd["R"]))
                y = (re["dd_phase"] - rs["dd_phase"]) - sat_term
                sig = args.tddd_sigma_scale * math.sqrt(2.0) * max(re["sigma_phase"], 1e-3)
                w = 1.0 / sig
                H += (w * w) * np.outer(g, g)
                b += (w * w) * g * y
            ev, V = np.linalg.eigh(H)
            floor = max(float(ev.max()) * 1e-8, 1e-12)
            ev = np.maximum(ev, floor)
            Sigma = V @ np.diag(1.0 / ev) @ V.T
            drop = Sigma @ b
            L = np.linalg.cholesky(Sigma + 1e-12 * np.eye(3))
            A = np.linalg.inv(L) / max(args.tddd_window_sigma_scale, 1e-6)
            tddd_windows.append((i0, i0 + W, drop, A))
        print("  TDDD windows: %d x %d kf (sigma_scale=%.1f)" %
              (len(tddd_windows), W, args.tddd_window_sigma_scale))

    rigid = bool(args.static_rigid_sigma > 0)
    if rigid:
        smask = static_mask_keyframes(t, p, thresh=args.static_detect_thresh,
                                      win=args.static_detect_win)
    elif args.static_prior_sigma > 0:
        smask = static_mask_keyframes(t, p, thresh=args.static_detect_thresh,
                                      win=args.static_detect_win)
    else:
        smask = None
    # Static-run RTK downweighting (independent of the zero-displacement prior):
    # let the LIO odom chain define the static shape, so RTK jitter/bias cannot
    # drag the adjacent moving segment through the odometry coupling.
    dw_mask = (static_mask_keyframes(t, p, thresh=0.20, win=3)
               if args.static_downweight else None)
    dw_w = max(args.static_rtk_weight, 1e-6) if dw_mask is not None else 1.0
    # P1a: one robust median RTK anchor per static run. The factor added to the
    # graph constrains the MEAN of the run's positions to this anchor, while the
    # zero-displacement rows keep the run rigid. This is the graph equivalent of
    # apply_static_hold(), but it moves the static segment inside the solve and
    # lets the odometry factors carry the boundary continuously.
    rigid_runs = []
    anchor_of = np.full((n, 3), np.nan)
    rigid_member = np.zeros(n, bool)
    if rigid and smask is not None:
        # merge 1-2 frame gaps so a single noisy frame cannot split a stop
        runs = []
        i = 0
        while i < n:
            if not smask[i]:
                i += 1
                continue
            j = i
            while j + 1 < n and smask[j + 1]:
                j += 1
            if runs and i - runs[-1][1] <= 2:
                runs[-1] = (runs[-1][0], j)
            else:
                runs.append((i, j))
            i = j + 1
        for a0, b0 in runs:
            run = np.arange(a0, b0 + 1)
            rigid_member[run] = True
            valid = np.array([i for i in run if ok[i] and fixed_ok(i)], dtype=int)
            if valid.size > 0:
                z = np.median(np.array([rtk_p_at(i) - Rz @ Rbody[i] @ lever
                                        for i in valid]), axis=0)
                if args.static_no_anchor:
                    z = None
            else:
                z = None
            rigid_runs.append((run, z))
            if z is not None:
                anchor_of[run] = z
        n_anchor = sum(1 for _r, z in rigid_runs if z is not None)
        print("  static rigid: %d run(s), %d anchored, sigma_stat=%.3f m, "
              "sigma_anchor=%.3f m, detect=%.2f m/s win=%d, keep_rtk=%s" %
              (len(rigid_runs), n_anchor, args.static_rigid_sigma,
               args.static_anchor_sigma, args.static_detect_thresh,
               args.static_detect_win, "on" if args.static_keep_rtk else "off"))
        for run, z in rigid_runs:
            tt = t[run]
            print("    static run %.1f-%.1f s (%d kf)%s" %
                  (tt[0] - t[0], tt[-1] - t[0], len(run),
                   "" if z is None else " anchor=(%.2f,%.2f,%.2f)" %
                   (z[0], z[1], z[2])))
    n_fix_eff = n_fix
    if rigid and not args.static_keep_rtk:
        n_fix_eff = int((ok & ~rigid_member).sum()) + sum(
            1 for _r, z in rigid_runs if z is not None)
    # P1b: local RTK-relative transition factors over the first N keyframes
    # after each static->moving boundary. They anchor the early motion scale
    # without trusting an absolute RTK bias; the lever-arm difference is kept.
    trans_factors = []
    if rigid and args.static_transition_sigma > 0:
        for run, _z in rigid_runs:
            b = int(run[-1])
            for j in range(1, args.static_transition_kf + 1):
                i0, i1 = b + j - 1, b + j
                if i1 >= n or rigid_member[i1]:
                    break
                if not (ok[i0] and ok[i1]) or ir[i0] == ir[i1]:
                    continue
                lw0 = Rz @ Rbody[i0] @ lever
                lw1 = Rz @ Rbody[i1] @ lever
                d = (rtk_p[ir[i1]] - lw1) - (rtk_p[ir[i0]] - lw0)
                trans_factors.append((i0, i1, d))
        print("  static transition: %d local RTK-relative factor(s), kf=%d, "
              "sigma_xy=%.3f m, sigma_z=%.3f m" %
              (len(trans_factors), args.static_transition_kf,
               args.static_transition_sigma, args.static_transition_z_sigma))
    static_anchor = None
    if smask is not None and not rigid:        # Keep one absolute anchor per static run; per-epoch RTK factors inside
        # a static run fight the zero-displacement prior and inject jitter.
        static_anchor = np.zeros(n, bool)
        for i in range(n):
            if smask[i] and (i == 0 or not smask[i - 1]):
                static_anchor[i] = True
    # Static override: low lambda_min in a stationary run means "no LiDAR
    # geometry", not "moving geometry degraded".  With a static prior active,
    # that segment is handled by the zero-displacement factor, so do not let the
    # lambda rule upweight a possibly biased static RTK fix.
    if args.lambda_weight_en and smask is not None and (rigid or args.static_prior_sigma > 0):
        w_lambda[smask] = 1.0
    if args.general_adapt and smask is not None and (rigid or args.static_prior_sigma > 0):
        w_gen[smask] = 1.0

    w_odom = 1.0 / max(args.sig_odom, 1e-9)
    w_odom_z = 1.0 / max(
        args.sig_odom_z if args.sig_odom_z > 0 else args.sig_odom, 1e-9)
    w_odom_a = (1.0 / max(args.sig_odom_along, 1e-9)
                if args.aniso_odom else w_odom)
    w_odom_c = (1.0 / max(args.sig_odom_cross, 1e-9)
                if args.aniso_odom else w_odom)
    wp = 1.0 / 0.01
    if rigid:
        w_st = 1.0 / max(args.static_rigid_sigma, 1e-9)
    elif smask is not None:
        w_st = 1.0 / max(args.static_prior_sigma, 1e-9)
    else:
        w_st = 0.0

    # Local RTK gate: a short-window LIO-vs-RTK relative-motion disagreement
    # flags a transient RTK outlier (e.g. c02 600-620 s). Expand the flag by
    # one window so the interior of the outlier also loses authority.
    gate_mask = None
    if args.rtk_consistency_gate:
        W = max(args.rtk_gate_window, 1.0)
        raw = np.zeros(n, bool)
        Rz_g = np.array([[math.cos(yaw), -math.sin(yaw), 0],
                         [math.sin(yaw), math.cos(yaw), 0],
                         [0, 0, 1.0]])
        p_enu_g = (Rz_g @ p.T).T
        rtk_kf = np.array([rtk_p[int(np.argmin(np.abs(rtk_t - x)))]
                           for x in t])
        for i in range(n):
            j = int(np.searchsorted(t, t[i] - W))
            j = max(0, min(j, i - 1))
            if t[i] - t[j] < 0.5 * W:
                continue
            d = np.linalg.norm(((p_enu_g[i] - p_enu_g[j]) -
                                (rtk_kf[i] - rtk_kf[j]))[:2])
            if d > args.rtk_gate_thresh:
                raw[i] = True
        gate_mask = np.zeros(n, bool)
        for i in np.where(raw)[0]:
            a = int(np.searchsorted(t, t[i] - W))
            b = int(np.searchsorted(t, t[i] + W, side="right"))
            gate_mask[max(0, a):min(n, b)] = True
        if np.any(gate_mask):
            tt = t[gate_mask] - t[0]
            print("  rtk consistency gate: %d/%d keyframes (%.1f-%.1f s)" %
                  (int(gate_mask.sum()), n, tt.min(), tt.max()))
        else:
            print("  rtk consistency gate: no keyframes flagged")

    # P3: per-block LIO odometry scale with a random-walk prior. The scale is a
    # free variable in the same linear system (column 3*n+kb); block 0 is tied
    # to 1 with a weak prior so the scale/position gauge is fixed.
    scale_on = bool(args.odom_scale_walk_sigma > 0)
    block_kf = max(1, int(args.odom_scale_block_kf))
    nb = int(np.ceil(n / float(block_kf))) if scale_on else 0
    w_scale_walk = 1.0 / max(args.odom_scale_walk_sigma, 1e-9) if scale_on else 0.0
    w_scale_prior = 1.0 / max(args.odom_scale_prior_sigma, 1e-9) if scale_on else 0.0
    ncol = 3 * n + (nb if scale_on else 0)
    if scale_on:
        print("  odom scale: %d block(s), block_kf=%d, walk_sigma=%.4f, "
              "prior_sigma=%.3f" % (nb, block_kf, args.odom_scale_walk_sigma,
                                    args.odom_scale_prior_sigma))

    def build(weights_xy, weights_z):
        rows, cols, vals, rhs = [], [], [], []

        def add_row(terms, b):
            for c, v in terms:
                rows.append(len(rhs))
                cols.append(c)
                vals.append(v)
            rhs.append(b)

        r = 0
        for i in range(n - 1):
            d = Rz @ (p[i + 1] - p[i])
            if scale_on:
                kb = i // block_kf
                col_s = 3 * n + kb
                for k in range(3):
                    wa = w_odom_z if k == 2 else w_odom
                    add_row([(3 * i + k, -wa),
                             (3 * (i + 1) + k, wa),
                             (col_s, -wa * d[k])], 0.0)
            else:
                if args.aniso_odom and np.linalg.norm(d[:2]) > 0.05:
                    f = d[:2] / np.linalg.norm(d[:2])
                    r = np.array([f[1], -f[0]])
                    for coef, wk in ((f, w_odom_a), (r, w_odom_c)):
                        add_row([(3 * i + 0, -wk * coef[0]),
                                 (3 * i + 1, -wk * coef[1]),
                                 (3 * (i + 1) + 0, wk * coef[0]),
                                 (3 * (i + 1) + 1, wk * coef[1])],
                                wk * float(coef @ d[:2]))
                    add_row([(3 * i + 2, -w_odom_z),
                             (3 * (i + 1) + 2, w_odom_z)], w_odom_z * d[2])
                else:
                    for k in range(3):
                        wa = w_odom_z if k == 2 else w_odom
                        add_row([(3 * i + k, -wa), (3 * (i + 1) + k, wa)],
                                wa * d[k])
            in_static = ((rigid and rigid_member[i] and rigid_member[i + 1])
                         or (not rigid and smask is not None
                             and smask[i] and smask[i + 1]))
            if in_static:
                for k in range(3):
                    add_row([(3 * i + k, -w_st), (3 * (i + 1) + k, w_st)], 0.0)
        if tddd is not None and not args.tddd_gate_only:
            # One scalar carrier-phase TDDD row per DD pair:
            #   w * (y - g . (p_{i+1} - p_i)) = 0
            # The per-pair rows naturally form the full G^T W G normal matrix,
            # so weak directions stay weak instead of being forced isotropic.
            R2 = tddd.get("R2", np.eye(2))
            t2 = tddd.get("t2", np.zeros(2))
            tz = tddd.get("tz", 0.0)
            for (i, _t1, _t2, dd_rows) in tddd["pairs"]:
                p_base = np.empty(3)
                p_base[:2] = R2 @ p0[i, :2] + t2
                p_base[2] = p0[i, 2] + tz
                tf = tf_int.get(i, 1.0) if args.general_adapt else 1.0
                for g_b, y, w in tddd_pair_rows(dd_rows, p_base, tddd["base"],
                                                tddd["R"], args.tddd_sigma_scale,
                                                opts=tddd_opts):
                    g = np.empty(3)  # base ENU -> ref ENU
                    g[:2] = R2.T @ g_b[:2]
                    g[2] = g_b[2]
                    we = w * tf
                    terms = []
                    for k in range(3):
                        terms.append((3 * i + k, -we * g[k]))
                        terms.append((3 * (i + 1) + k, we * g[k]))
                    add_row(terms, we * y)
        for (i0, j, drop, A) in tddd_windows:
            for k in range(3):
                terms = [(3 * i0 + c, -A[k, c]) for c in range(3)]
                terms += [(3 * j + c, A[k, c]) for c in range(3)]
                add_row(terms, float(A[k] @ drop))
        if scale_on:
            add_row([(3 * n, w_scale_prior)], w_scale_prior)
            for kb in range(nb - 1):
                add_row([(3 * n + kb, -w_scale_walk),
                         (3 * n + kb + 1, w_scale_walk)], 0.0)
        if args.rtk_mode != "relative":
            for i in range(n):
                if not ok[i] or not fixed_ok(i):
                    continue
                w_scale = dw_w if (dw_mask is not None and dw_mask[i]) else 1.0
                if gate_mask is not None and gate_mask[i]:
                    w_scale *= max(args.rtk_gate_weight, 1e-6)
                if (static_anchor is not None and smask[i]
                        and not static_anchor[i]):
                    w_scale *= max(args.static_rtk_weight, 1e-6)
                if rigid and rigid_member[i]:
                    if not args.static_keep_rtk:
                        continue
                    w_scale *= max(args.static_rtk_weight, 1e-6)
                lever_w = Rz @ Rbody[i] @ lever
                base = rtk_p_at(i) - lever_w
                wx = weights_xy[i] * w_scale
                wz = weights_z[i] * w_scale
                wg = w_gen[i] if args.general_adapt else 1.0
                if args.rtk_aniso_en:
                    if i > 0 and i + 1 < len(p):
                        vv = p[i + 1, :2] - p[i - 1, :2]
                    elif i + 1 < len(p):
                        vv = p[i + 1, :2] - p[i, :2]
                    elif i > 0:
                        vv = p[i, :2] - p[i - 1, :2]
                    else:
                        vv = np.zeros(2)
                    nv = np.linalg.norm(vv)
                    if nv > 1e-3:
                        f = vv / nv
                        rr = np.array([f[1], -f[0]])
                        wa = wx * wg
                        wc = wx
                        add_row([(3 * i + 0, wa * f[0]),
                                 (3 * i + 1, wa * f[1])],
                                wa * float(f @ base[:2]))
                        add_row([(3 * i + 0, wc * rr[0]),
                                 (3 * i + 1, wc * rr[1])],
                                wc * float(rr @ base[:2]))
                        add_row([(3 * i + 2, wz)], wz * base[2])
                    else:
                        wxg = wx * wg
                        add_row([(3 * i + 0, wxg)], wxg * base[0])
                        add_row([(3 * i + 1, wxg)], wxg * base[1])
                        add_row([(3 * i + 2, wz)], wz * base[2])
                else:
                    wxg = wx * wg
                    add_row([(3 * i + 0, wxg)], wxg * base[0])
                    add_row([(3 * i + 1, wxg)], wxg * base[1])
                    add_row([(3 * i + 2, wz)], wz * base[2])
        if rigid:
            # One robust anchor per static run, applied to the run MEAN. Together
            # with the zero-displacement rows above this is the eliminated form
            # of  x_i = q_k (sigma_stat)  +  q_k = median(RTK) (sigma_anchor).
            w_a = 1.0 / max(args.static_anchor_sigma, 1e-9)
            for run, z in rigid_runs:
                if z is None:
                    continue
                nr = float(len(run))
                for k in range(3):
                    add_row([(3 * ii + k, w_a / nr) for ii in run],
                            w_a * z[k])
        if trans_factors:
            wx = 1.0 / max(args.static_transition_sigma, 1e-9)
            wz = 1.0 / max(args.static_transition_z_sigma, 1e-9)
            for i0, i1, d in trans_factors:
                for k in range(2):
                    add_row([(3 * i0 + k, -wx), (3 * i1 + k, wx)], wx * d[k])
                add_row([(3 * i0 + 2, -wz), (3 * i1 + 2, wz)], wz * d[2])
        if args.rtk_mode != "absolute":
            # Relative RTK factors: immune to a slow absolute bias, which is
            # exactly what makes c01 prefer a weak absolute weight while c02
            # needs a strong one. The lever-arm difference is kept.
            wx = 1.0 / max(args.sig_rtk_rel_xy, 1e-9)
            wz = 1.0 / max(args.sig_rtk_rel_z, 1e-9)
            for i in range(n - 1):
                if not (ok_raw[i] and ok_raw[i + 1]):
                    continue
                if ir[i] == ir[i + 1]:
                    continue
                if abs(rtk_t[ir[i + 1]] - rtk_t[ir[i]]) > 2.0 * args.fix_max_dt:
                    continue
                lw_i = Rz @ Rbody[i] @ lever
                lw_j = Rz @ Rbody[i + 1] @ lever
                d = (rtk_p[ir[i + 1]] - lw_j) - (rtk_p[ir[i]] - lw_i)
                add_row([(3 * i + 0, -wx), (3 * (i + 1) + 0, wx)], wx * d[0])
                add_row([(3 * i + 1, -wx), (3 * (i + 1) + 1, wx)], wx * d[1])
                add_row([(3 * i + 2, -wz), (3 * (i + 1) + 2, wz)], wz * d[2])
        if loops:
            # Oracle loop factors: p_i - p_j = reference displacement (x/y only).
            # These are evaluation-only; production loops must come from a
            # verified detector and use GICP covariance.
            wl = 1.0 / max(args.loop_sigma_xy, 1e-9)
            for (i, j, dx, dy, _dist) in loops:
                add_row([(3 * i + 0, wl), (3 * j + 0, -wl)], wl * dx)
                add_row([(3 * i + 1, wl), (3 * j + 1, -wl)], wl * dy)
        # Gauge: when the first keyframe is inside an anchored static run, the
        # segment anchor already fixes the absolute frame. A strong x[0]=p0[0]
        # prior would pin the whole stop to the LIO start and defeat the anchor.
        keep_gauge = not (rigid and rigid_member[0]
                          and np.isfinite(anchor_of[0, 0]))
        if keep_gauge:
            for k in range(3):
                add_row([(3 * 0 + k, wp)], wp * p0[0, k])
        A = coo_matrix((vals, (rows, cols)), shape=(len(rhs), ncol)).tocsr()
        return A, np.array(rhs)

    if sig_rtk_vec is None:
        base_w = np.full(n, 1.0 / max(args.sig_rtk_xy, 1e-9))
    else:
        base_w = 1.0 / np.maximum(sig_rtk_vec, 1e-9)
    base_w_z = 1.0 / max(args.sig_rtk_z, 1e-9)
    base_w = base_w * w_cons * w_lambda
    base_w_z = base_w_z * w_cons * w_lambda * w_gen
    if not args.rtk_aniso_en:
        base_w = base_w * w_gen
    if rel_w is not None:
        base_w = base_w * rel_w
        base_w_z = base_w_z * rel_w
    if args.status_sigma_en and rtk_status is not None:
        n_fixed = 0
        for i in range(n):
            if ok[i] and rtk_status[ir[i]] == 5:
                # E-A: Fixed epoch uses the RTK's own sigma, bypassing
                # fit_rms / lambda / consistency multipliers.
                base_w[i] = 1.0 / max(args.fixed_sigma, 1e-6)
                sig_z = (args.fixed_sigma_z if args.fixed_sigma_z > 0
                         else args.sig_rtk_z)
                base_w_z[i] = 1.0 / max(sig_z, 1e-6)
                n_fixed += 1
        if n_fixed:
            print("  status-aware sigma: fixed=%d, sigma=%.3f m (bypass fit/lambda/consistency)"
                  % (n_fixed, args.fixed_sigma))
    weights = base_w.copy()
    weights_z = np.full(n, base_w_z)
    robust_on = (args.huber_xy > 0 or args.cauchy_xy > 0 or args.cauchy_z > 0)
    x = p0.reshape(-1).copy()
    if scale_on:
        x = np.concatenate([x, np.ones(nb)])

    def finalize(x):
        if scale_on:
            sc = x[3 * n:]
            print("  odom scale: " + " ".join("%.5f" % v for v in sc))
        return x[:3 * n].reshape(n, 3), n_fix_eff, ok

    def robust_weights(res):
        """Per-axis IRLS weights (Huber/Cauchy) for one Gauss-Newton step."""
        wx = base_w.copy()
        wz = np.full(n, base_w_z)
        for i in range(n):
            if not ok[i] or not fixed_ok(i):
                continue
            if (args.status_sigma_en and rtk_status is not None
                    and rtk_status[ir[i]] == 5):
                # E-A: Fixed epochs keep the status-aware base weight;
                # do not let Cauchy/Huber downweight them.
                continue
            if (static_anchor is not None and smask[i]
                    and not static_anchor[i]):
                continue
            if rigid and rigid_member[i]:
                continue
            lever_w = Rz @ Rbody[i] @ lever
            base = rtk_p[ir[i]] - lever_w
            rn = math.hypot(res[i, 0] - base[0], res[i, 1] - base[1])
            rz = abs(res[i, 2] - base[2])
            if args.cauchy_xy > 0:
                wx[i] = base_w[i] / (1.0 + (rn / args.cauchy_xy) ** 2)
            elif args.huber_xy > 0 and rn > args.huber_xy:
                wx[i] = base_w[i] * args.huber_xy / rn
            if args.cauchy_z > 0:
                wz[i] = base_w_z / (1.0 + (rz / args.cauchy_z) ** 2)
        return wx, wz

    for it in range(args.iters if robust_on else 1):
        A, b = build(weights, weights_z)
        if HAVE_SCIPY:
            x = lsqr(A, b, atol=1e-10, btol=1e-10, iter_lim=4000)[0]
        else:
            x = np.linalg.lstsq(A.toarray(), b, rcond=None)[0]
        if (not robust_on or args.rtk_mode == "relative"
                or it == args.iters - 1):
            break
        res = x[:3 * n].reshape(n, 3)
        weights, weights_z = robust_weights(res)
    return finalize(x)


# --------------------------------------------------------------------- metrics


def eval_arms(tag, t, p, rt, rp, ref_t, ref_p, wins=()):
    """Print full/steady/movfit/stat@movfit/static-loc for one arm."""
    m_full, _ = eu.score(t, p, rt, rp, 0.0)
    m_steady, _ = eu.score(t, p, rt, rp, 150.0)
    irall = np.array([int(np.argmin(np.abs(rt - x))) for x in t])
    okall = np.abs(rt[irall] - t) < 0.25
    rpm = rp[irall]
    segs = eu.static_segments(rt, rp, 0.10, 2, 5.0, 2.0)
    stat_ref = np.zeros(len(rt), bool)
    for a0, b0 in segs:
        stat_ref |= (rt >= a0) & (rt <= b0)
    statm = stat_ref[irall] & okall
    movm = ~stat_ref[irall] & okall
    line = ["== %s ==" % tag]
    if m_full:
        line.append("  full   : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f 3D_mean=%.4f 3D_max=%.4f"
                    % (m_full["n"], m_full["r3"], m_full["r2"],
                       m_full["mean3"], m_full["mx"]))
    if m_steady:
        line.append("  steady : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                    % (m_steady["n"], m_steady["r3"], m_steady["r2"]))
    if movm.sum() >= 20:
        m, _, _ = eu.fit_eval(p, rpm, movm, movm)
        if m:
            line.append("  movfit : n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (m["n"], m["r3"], m["r2"]))
        m, _, _ = eu.fit_eval(p, rpm, movm, statm)
        if m:
            line.append("  stat@movfit: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (m["n"], m["r3"], m["r2"]))
    pool = []
    for a0, b0 in segs:
        mseg = okall & (rt[irall] >= a0) & (rt[irall] <= b0)
        m, _, e2 = eu.fit_eval(p, rpm, mseg, mseg)
        if m:
            pool.append(e2)
    if pool:
        e2 = np.concatenate(pool)
        line.append("  static-loc pooled: n=%d 2D_RMSE=%.4f"
                    % (e2.size, float(np.sqrt((e2 ** 2).mean()))))
    for a, b in wins:
        mwin = okall & ((t - t[0]) >= a) & ((t - t[0]) <= b)
        m, _, _ = eu.fit_eval(p, rpm, mwin, mwin)
        if m:
            line.append("  win %.0f:%.0f: n=%-6d 3D_RMSE=%.4f 2D_RMSE=%.4f"
                        % (a, b, m["n"], m["r3"], m["r2"]))
    print("\n".join(line))
    return {
        "full2": m_full["r2"] if m_full else None,
        "steady2": m_steady["r2"] if m_steady else None,
    }


def apply_static_hold(pg, pk, smask, t, blend_s, rtk_kf=None,
                      expand_s=5.0, anchor="rtk"):
    """Keep the graph's moving solution, but replace detected static runs with
    the LIVO static segment rigidly placed by the RTK mean of that run.

    Shape comes from LIO (cm-level static self-motion); absolute placement comes
    from the robust RTK mean (not from one noisy fix and not from the graph's
    distorted static segment). A short blend removes the boundary jump.
    """
    out = pg.copy()
    n = len(pg)
    if n < 3:
        return out
    dt = np.diff(t)
    dt = dt[dt > 0]
    step = float(np.median(dt)) if dt.size else 1.0
    blend_n = max(1, int(round(blend_s / max(step, 1e-6))))
    expand_n = max(0, int(round(expand_s / max(step, 1e-6))))
    i = 0
    runs = 0
    while i < n:
        if not smask[i]:
            i += 1
            continue
        j = i
        while j + 1 < n and smask[j + 1]:
            j += 1
        # Expand the held run so the full reference stop (whose edges move
        # slowly) is covered; the offset still comes from the detected core.
        a = max(0, i - expand_n)
        b = min(n - 1, j + expand_n)
        print("  static hold run: core %.1f-%.1f s, applied %.1f-%.1f s" %
              (t[i] - t[0], t[j] - t[0], t[a] - t[0], t[b] - t[0]))
        if anchor == "boundary":
            # Keep the held segment continuous with the adjacent moving part.
            # A trajectory-start stop anchors on its end boundary; a final stop
            # anchors on its start boundary; a middle stop averages both.
            has_prev = a > 0
            has_next = b < n - 1
            if has_prev and has_next:
                off = 0.5 * ((pg[a] - pk[a]) + (pg[b] - pk[b]))
            elif has_next:
                off = pg[b] - pk[b]
            elif has_prev:
                off = pg[a] - pk[a]
            else:
                off = pg[i] - pk[i]
        elif rtk_kf is not None:
            # robust absolute placement of this static run
            off = np.median(rtk_kf[i:j + 1] - pk[i:j + 1], axis=0)
        else:
            off = pg[i] - pk[i]
        for k in range(a, b + 1):
            seg_k = pk[k] + off
            if a > 0 and k - a < blend_n:
                w = (k - a + 1.0) / (blend_n + 1.0)
            elif b < n - 1 and b - k < blend_n:
                w = (b - k + 1.0) / (blend_n + 1.0)
            else:
                w = 1.0
            out[k] = (1.0 - w) * pg[k] + w * seg_k
        runs += 1
        i = j + 1
    print("  static hold: %d run(s), no factor changes" % runs)
    return out


def write_tum(path, t, p, q):
    with open(path, "w") as f:
        for i in range(len(t)):
            f.write("%.6f %.6f %.6f %.6f %.9f %.9f %.9f %.9f\n" %
                    (t[i], p[i, 0], p[i, 1], p[i, 2],
                     q[i, 0], q[i, 1], q[i, 2], q[i, 3]))


# ------------------------------------------------------------------------ main


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--livo", required=True)
    ap.add_argument("--rtk", required=True)
    ap.add_argument("--ref", default=None)
    ap.add_argument("--out", default=None)
    ap.add_argument("--tag", default="global_position_graph")
    ap.add_argument("--rtk-topic", default="/gnss_rtk")
    ap.add_argument("--rtk-start", type=float, default=0.0)
    ap.add_argument("--rtk-dur", type=float, default=None)
    ap.add_argument("--keyframe-dt", type=float, default=1.0)
    ap.add_argument("--sig-odom", type=float, default=0.05)
    ap.add_argument("--sig-odom-z", type=float, default=0.0,
                    help="P4: vertical LIO odometry sigma (0 = use --sig-odom)")
    ap.add_argument("--sig-rtk-xy", type=float, default=1.0)
    ap.add_argument("--sig-rtk-z", type=float, default=10.0)
    ap.add_argument("--rtk-mode", choices=["absolute", "relative", "both"],
                    default="absolute",
                    help="absolute factors are sensitive to slow RTK bias; "
                         "relative factors cancel it but need an absolute gauge")
    ap.add_argument("--sig-rtk-rel-xy", type=float, default=0.2)
    ap.add_argument("--sig-rtk-rel-z", type=float, default=1.0)
    ap.add_argument("--rtk-subsample", type=int, default=1,
                    help="keep every Nth absolute fix (1 = all); correlated "
                         "RTK bias should not count as independent observations")
    ap.add_argument("--adaptive-rtk", action="store_true",
                    help="per-keyframe RTK weight from LIO-vs-RTK relative "
                         "consistency (one global rule for all datasets)")
    ap.add_argument("--consistency-window", type=float, default=60.0)
    ap.add_argument("--e-low", type=float, default=0.045,
                    help="m/s; below this LIO is locally consistent -> weak RTK")
    ap.add_argument("--e-high", type=float, default=0.10,
                    help="m/s; above this LIO is drifting -> strong RTK")
    ap.add_argument("--sigma-rtk-weak", type=float, default=5.0)
    ap.add_argument("--sigma-rtk-strong", type=float, default=1.0)
    ap.add_argument("--auto-odom", action="store_true",
                    help="set the odom sigma from the same initial fit residual: "
                         "larger LIO drift -> looser odom (one global formula)")
    ap.add_argument("--odom-a", type=float, default=0.05)
    ap.add_argument("--odom-b", type=float, default=0.06)
    ap.add_argument("--odom-fit-ref", type=float, default=2.0)
    ap.add_argument("--odom-max", type=float, default=0.5)
    ap.add_argument("--auto-sigma-rtk", action="store_true",
                    help="set one global RTK sigma from the initial LIO-RTK fit "
                         "residual: larger residual -> trust RTK more. This is "
                         "a single global formula, not a per-dataset constant.")
    ap.add_argument("--fit-a", type=float, default=6.0)
    ap.add_argument("--fit-b", type=float, default=0.6)
    ap.add_argument("--huber-xy", type=float, default=0.0,
                    help="Huber delta on HORIZONTAL RTK residual (0 = off)")
    ap.add_argument("--cauchy-xy", type=float, default=0.0,
                    help="P2: Cauchy delta (m) on HORIZONTAL RTK residual (0 = off)")
    ap.add_argument("--cauchy-z", type=float, default=0.0,
                    help="P2: Cauchy delta (m) on VERTICAL RTK residual (0 = off)")
    ap.add_argument("--rel-weight-csv", default=None,
                    help="WP3: per-keyframe reliability weight CSV (t,w or w0,w1,w); "
                         "multiplies the RTK xy/z information weights (0 = off)")
    ap.add_argument("--rtk-status-csv", default=None,
                    help="WP3 E-A: per-epoch RTK status CSV (t,status; 5=Fixed, 2=Float)")
    ap.add_argument("--status-sigma-en", action="store_true",
                    help="WP3 E-A: for Fixed epochs, use fixed-sigma and bypass "
                         "fit_rms/lambda/consistency multipliers")
    ap.add_argument("--fixed-sigma", type=float, default=0.2,
                    help="WP3 E-A: horizontal sigma for Fixed epochs (m)")
    ap.add_argument("--rtk-interp-en", action="store_true",
                    help="WP3 E-A: interpolate the RTK position at each keyframe "
                         "time instead of using the nearest 1 Hz fix")
    ap.add_argument("--rtk-interp-status-aware", action="store_true",
                    help="WP3 P0: interpolate only between fixes of the same "
                         "status (Fixed-Fixed / Float-Float); avoids spreading "
                         "a Float outlier into a neighbouring Fixed keyframe")
    ap.add_argument("--rtk-interp-max-gap", type=float, default=2.5,
                    help="WP3 P0: max gap (s) between same-status fixes to interpolate")
    ap.add_argument("--fixed-max-jump", type=float, default=0.0,
                    help="WP3 P1: reject a Fixed fix whose horizontal jump from the "
                         "local (+/-2 s) RTK median exceeds this (0 = off)")
    ap.add_argument("--fixed-sigma-z", type=float, default=0.0,
                    help="WP3 P2: vertical sigma for Fixed epochs (0 = use sig_rtk_z)")
    ap.add_argument("--fixed-max-innov-sigma", type=float, default=0.0,
                    help="WP3 P1: reject a Fixed fix whose motion-compensated "
                         "innovation exceeds this normalized threshold (0 = off)")
    ap.add_argument("--fixed-innov-sigma-rtk", type=float, default=0.3,
                    help="WP3 P1: RTK sigma used in the innovation denominator (m)")
    ap.add_argument("--fixed-innov-sigma-pred", type=float, default=0.2,
                    help="WP3 P1: base LIO prediction sigma (m)")
    ap.add_argument("--fixed-innov-sigma-rate", type=float, default=0.2,
                    help="WP3 P1: prediction sigma growth per second")
    ap.add_argument("--fixed-innov-sigma-max", type=float, default=2.0,
                    help="WP3 P1: cap of the prediction sigma (m)")
    ap.add_argument("--fixed-innov-local-scale-en", action="store_true",
                    help="WP3 P1: estimate a local LIO->RTK relative scale from "
                         "recent accepted Fixed pairs")
    ap.add_argument("--fixed-innov-scale-window", type=int, default=10,
                    help="WP3 P1: number of accepted pairs for the local scale")
    ap.add_argument("--fixed-innov-scale-min", type=float, default=0.8)
    ap.add_argument("--fixed-innov-scale-max", type=float, default=1.2)
    ap.add_argument("--fixed-innov-sigma-rel", type=float, default=0.05,
                    help="WP3 P1: prediction sigma per metre of LIO motion")
    ap.add_argument("--fixed-innov-debug-csv", default=None,
                    help="WP3 P0: write per-Fixed innovation diagnostics")
    ap.add_argument("--fixed-innov-mode",
                    choices=["lio", "rtk", "lio_abs", "imu", "imu_rtk",
                             "imu_rtk_med"],
                    default="lio",
                    help="WP3 P1: predictor for the consistency veto; 'imu_rtk_med' "
                         "uses a multi-frame robust anchor + IMU propagation")
    ap.add_argument("--med-vel-source", choices=["lio", "rtk"], default="lio",
                    help="velocity source for the imu_rtk_med anchor; 'lio' is the "
                         "best rerun5 variant (106 rejects), 'rtk' the noisier one")
    ap.add_argument("--imu-csv", default=None,
                    help="IMU CSV (t,ax,ay,az,gx,gy,gz) for --fixed-innov-mode imu")
    ap.add_argument("--imu-pred-sigma-base", type=float, default=0.3,
                    help="IMU preintegration prediction sigma base (m)")
    ap.add_argument("--imu-pred-sigma-rate", type=float, default=0.1,
                    help="IMU preintegration prediction sigma growth per second")
    ap.add_argument("--static-prior-sigma", type=float, default=0.0,
                    help="m, zero-displacement prior in detected static segments (0 = off)")
    ap.add_argument("--static-rigid-sigma", type=float, default=0.0,
                    help="m, P1a: rigid zero-displacement factor inside detected "
                         "static runs plus one robust segment-mean anchor "
                         "(0 = off). Replaces the post-hoc --static-hold.")
    ap.add_argument("--static-anchor-sigma", type=float, default=0.3,
                    help="m, P1a: sigma of the per-run robust median RTK anchor")
    ap.add_argument("--static-detect-thresh", type=float, default=0.20,
                    help="m/s, P1a: LIO speed below which a keyframe is static")
    ap.add_argument("--static-detect-win", type=int, default=3,
                    help="frames, P1a: median window for static detection")
    ap.add_argument("--static-keep-rtk", action="store_true",
                    help="P1a: keep per-epoch RTK factors inside static runs "
                         "(default: skip them, the segment anchor replaces them)")
    ap.add_argument("--static-transition-sigma", type=float, default=0.0,
                    help="m, P1b: local RTK-relative factor over the first "
                         "N keyframes after a static->moving boundary (0 = off)")
    ap.add_argument("--static-transition-z-sigma", type=float, default=1.0,
                    help="m, P1b: vertical sigma of the local transition factor")
    ap.add_argument("--static-transition-kf", type=int, default=3,
                    help="keyframes after the boundary covered by the P1b factor")
    ap.add_argument("--odom-scale-walk-sigma", type=float, default=0.0,
                    help="P3: per-block LIO odometry scale random-walk sigma "
                         "(0 = off; try 0.001-0.003)")
    ap.add_argument("--odom-scale-block-kf", type=int, default=60,
                    help="P3: keyframes per scale block")
    ap.add_argument("--odom-scale-prior-sigma", type=float, default=0.01,
                    help="P3: prior sigma of the first scale block around 1")
    ap.add_argument("--static-rtk-weight", type=float, default=0.1,
                    help="scale of non-anchor RTK factors inside a static run "
                         "when the static prior is on; keeps the segment rigid "
                         "while averaging (instead of trusting one fix)")
    ap.add_argument("--rtk-consistency-gate", action="store_true",
                    help="downweight RTK factors in short windows where the "
                         "LIO-vs-RTK relative motion disagrees strongly "
                         "(transient RTK outliers, e.g. c02 600-620 s)")
    ap.add_argument("--rtk-gate-window", type=float, default=10.0)
    ap.add_argument("--rtk-gate-thresh", type=float, default=2.0)
    ap.add_argument("--rtk-gate-weight", type=float, default=0.05)
    ap.add_argument("--static-downweight", action="store_true",
                    help="downweight absolute RTK factors inside static runs "
                         "(no zero-displacement prior); the LIO odom chain then "
                         "defines the static shape and the adjacent moving segment "
                         "is not dragged by RTK static jitter")
    ap.add_argument("--static-hold", action="store_true",
                    help="post-process: keep the graph for moving parts, use "
                         "the LIVO static segment (rigidly shifted) for static "
                         "runs, with a short boundary blend")
    ap.add_argument("--static-hold-blend", type=float, default=3.0)
    ap.add_argument("--static-hold-expand", type=float, default=5.0,
                    help="s; extend each detected static run to cover slow edges")
    ap.add_argument("--static-hold-anchor", choices=["rtk", "boundary"],
                    default="rtk",
                    help="constant offset for a static run: its RTK median, or "
                         "the graph offset at the adjacent moving boundary")
    ap.add_argument("--oracle-loops", default=None,
                    help="reference TUM used to build oracle loop factors "
                         "(evaluation only; never a production measurement)")
    ap.add_argument("--loop-sigma-xy", type=float, default=0.1,
                    help="m, horizontal sigma of oracle loop factors")
    ap.add_argument("--loop-min-gap", type=float, default=60.0,
                    help="s, minimum time separation for a loop pair")
    ap.add_argument("--loop-max-dist", type=float, default=5.0,
                    help="m, maximum horizontal reference distance for a loop pair")
    ap.add_argument("--loop-static-v", type=float, default=0.10,
                    help="m/s, reference speed below which a keyframe is static")
    ap.add_argument("--loop-report", default=None,
                    help="TSV path for the selected oracle loops")
    ap.add_argument("--shuffle-loops", action="store_true",
                    help="permute loop measurements across the same pairs "
                         "(mechanism control)")
    ap.add_argument("--loop-shuffle-seed", type=int, default=0)
    ap.add_argument("--lever", nargs=3, type=float,
                    default=[-0.05, -0.325, 0.165])
    ap.add_argument("--yaw-deg", type=float, default=None)
    ap.add_argument("--yaw-robust", action="store_true",
                    help="MAD-refit the 2D yaw; default uses all 2D samples "
                         "(excluding moving samples biases yaw on c01)")
    ap.add_argument("--fix-max-dt", type=float, default=0.6)
    ap.add_argument("--tddd-csv", default=None,
                    help="DD CSV (c01/c02_dd_greatmsf.csv); enables TDDD factors")
    ap.add_argument("--tddd-base", nargs=3, type=float,
                    default=[-2267749.9279, 5009154.2407, 3221290.6333],
                    help="base ECEF of the DD generator")
    ap.add_argument("--tddd-ins", default=None,
                    help="GREAT-MSF .ins used to estimate the reference-ENU "
                         "to base-ENU rigid transform")
    ap.add_argument("--tddd-ins-lever", nargs=3, type=float,
                    default=[-0.05, -0.41, 0.15],
                    help="antenna lever used when reading the .ins")
    ap.add_argument("--tddd-sigma-scale", type=float, default=1.0,
                    help="scale on sqrt(2)*sigma_phase for the TDDD rows")
    ap.add_argument("--tddd-window", type=int, default=0,
                    help="keyframes, long-baseline TDDD window factor (0=off)")
    ap.add_argument("--tddd-window-sigma-scale", type=float, default=3.0,
                    help="weaken the window factor by this factor")
    ap.add_argument("--elev-weight-en", action="store_true",
                    help="GVIL elevation weighting on TDDD rows (e<30 deg downweight)")
    ap.add_argument("--elev-weight-ref-deg", type=float, default=30.0,
                    help="reference elevation for the weighting model")
    ap.add_argument("--tddd-freq-sigma-en", action="store_true",
                    help="frequency-specific TDDD sigma: L1/L2 8 mm, B3I 15 mm, B2I 25 mm")
    ap.add_argument("--raim-elev-min", type=float, default=15.0,
                    help="deg, RAIM-lite: drop DD pairs below this elevation")
    ap.add_argument("--raim-sigma-max", type=float, default=0.05,
                    help="m, RAIM-lite: drop DD pairs above this sigma")
    ap.add_argument("--lambda-csv", default=None,
                    help="per-frame lambda_min CSV from LIVMapper (<seq>_lambda.csv)")
    ap.add_argument("--lambda-weight-en", action="store_true",
                    help="continuous RTK weight from lambda_min (low lambda -> trust RTK)")
    ap.add_argument("--lambda-th", type=float, default=-1.0,
                    help="lambda_min threshold (negative = median of the run)")
    ap.add_argument("--lambda-scale", type=float, default=0.0,
                    help="lambda_min soft scale (0 = IQR of the run)")
    ap.add_argument("--lambda-w-min", type=float, default=0.1,
                    help="minimum RTK weight multiplier at high lambda_min")
    ap.add_argument("--lambda-mode", choices=["both", "one_sided"], default="both",
                    help="both: high lambda -> trust LIO; one_sided: only "
                         "upweight RTK at low lambda, leave high lambda at 1")
    ap.add_argument("--lambda-gain", type=float, default=0.5,
                    help="one_sided: RTK weight gain at low lambda_min")
    ap.add_argument("--general-adapt", action="store_true",
                    help="general rule: z_lio (TDDD-vs-LIO) + relative lambda_min; "
                         "no dataset-specific fit_rms/lambda thresholds")
    ap.add_argument("--general-z-th", type=float, default=3.0,
                    help="normalized TDDD-vs-LIO residual threshold (sigma units)")
    ap.add_argument("--general-z-scale", type=float, default=1.0,
                    help="soft scale of the z_lio transition")
    ap.add_argument("--general-window", type=float, default=30.0,
                    help="s, rolling median window for z_lio")
    ap.add_argument("--general-z-window", type=float, default=10.0,
                    help="s, long-baseline TDDD-vs-LIO window for z_lio")
    ap.add_argument("--static-no-anchor", action="store_true",
                    help="static rigid runs use zero-displacement only; no "
                         "single-frame RTK anchor (avoid biased static RTK)")
    ap.add_argument("--general-gain", type=float, default=0.8,
                    help="max RTK downweight when LIO is trustworthy")
    ap.add_argument("--general-w-min", type=float, default=0.2,
                    help="minimum RTK weight multiplier")
    ap.add_argument("--general-sigma-expected", type=float, default=0.4,
                    help="m, expected RTK+LIO local noise; fit_rms is normalized by it")
    ap.add_argument("--general-fit-sigma", type=float, default=4.5,
                    help="normalized fit_rms threshold (sigma units)")
    ap.add_argument("--general-fit-scale", type=float, default=0.25,
                    help="soft scale of the normalized fit transition")
    ap.add_argument("--rtk-aniso-en", action="store_true",
                    help="apply the adaptive RTK weight along the motion "
                         "direction only; keep cross-track/vertical RTK at 1")
    ap.add_argument("--tddd-min-pairs", type=int, default=6,
                    help="minimum DD pairs per keyframe interval")
    ap.add_argument("--tddd-consistency-gate", action="store_true",
                    help="downweight an absolute fix when its displacement is "
                         "inconsistent with the TDDD relative displacement")
    ap.add_argument("--tddd-consistency-sigma", type=float, default=0.5,
                    help="m, soft threshold for the TDDD consistency gate")
    ap.add_argument("--tddd-gate-only", action="store_true",
                    help="use TDDD only for the consistency gate; do not add "
                         "TDDD relative factors")
    ap.add_argument("--tddd-auto-fit", action="store_true",
                    help="enable TDDD factors only when the initial LIO-RTK "
                         "fit_rms is above --tddd-fit-thresh; otherwise gate-only")
    ap.add_argument("--tddd-fit-thresh", type=float, default=1.7,
                    help="m, initial LIO-RTK fit_rms threshold for --tddd-auto-fit")
    ap.add_argument("--stage2-auto", action="store_true",
                    help="fit_rms < thresh: TDDD gate-only, no static/Cauchy; "
                         ">= thresh: TDDD + static0.01@0.20 + Cauchy1.0")
    ap.add_argument("--aniso-odom", action="store_true",
                    help="use along/cross anisotropic LIO odometry covariance")
    ap.add_argument("--sig-odom-along", type=float, default=0.20,
                    help="m, along-track odom sigma when --aniso-odom")
    ap.add_argument("--sig-odom-cross", type=float, default=0.05,
                    help="m, cross-track odom sigma when --aniso-odom")
    ap.add_argument("--iters", type=int, default=5)
    ap.add_argument("--win", action="append", default=[],
                    help="A:B local-fit window (repeatable), e.g. 150:300")
    args = ap.parse_args()
    wins = []
    for w in args.win:
        a, b = w.split(":")
        wins.append((float(a or 0.0), float(b or 1e9)))

    rtk_path = ensure_rtk_tum(args.rtk, args.rtk_topic,
                              args.rtk_start, args.rtk_dur)
    t, p, q = load_tum_q(args.livo)
    rt, rp, _ = load_tum_q(rtk_path)
    if len(t) < 20 or len(rt) < 2:
        print("!! not enough poses (livo=%d rtk=%d)" % (len(t), len(rt)))
        return 1

    kf = select_keyframes(t, args.keyframe_dt)
    tk, pk, qk = t[kf], p[kf], q[kf]
    tddd = None
    if args.tddd_csv:
        if not args.tddd_ins:
            print("!! --tddd-csv requires --tddd-ins for the ref-ENU -> base-ENU transform")
            return 1
        dd = load_dd_epochs(args.tddd_csv)
        pairs = build_tddd_pairs(tk, dd, args.fix_max_dt, args.tddd_min_pairs)
        base = np.array(args.tddd_base, dtype=float)
        lat, lon, _ = ecef_to_geodetic(base)
        ins = load_ins(args.tddd_ins)
        R2, t2, tz, rms, yaw, n_ins = estimate_ref_to_base(
            rt, rp, ins, base, np.array(args.tddd_ins_lever), iters=3)
        print("  TDDD ref->base: yaw=%.3f deg, rms=%.2f m, tz=%.2f m, n=%d" %
              (math.degrees(yaw), rms, tz, n_ins))
        tddd = dict(pairs=pairs, base=base, R=enu_matrix(lat, lon),
                    R2=R2, t2=t2, tz=tz)
        n_tddd_rows = sum(len(p[3]) for p in pairs)
        print("  TDDD: %d interval(s), %d scalar row(s), csv=%s" %
              (len(pairs), n_tddd_rows, os.path.basename(args.tddd_csv)))

    lambda_kf = None
    if args.lambda_csv:
        lam_t, lam_v = load_lambda_csv(args.lambda_csv)
        if len(lam_t) > 0:
            lambda_kf = np.interp(tk, lam_t, lam_v)
            print("  lambda csv: %d samples, kf min/med/max=%.3f/%.3f/%.3f" %
                  (len(lam_t), float(np.min(lam_v)), float(np.median(lam_v)),
                   float(np.max(lam_v))))
        else:
            print("  !! empty lambda csv: %s" % args.lambda_csv)

    rt_interp = interp_xyz(rt, rp, tk)
    inb = (tk >= rt[0]) & (tk <= rt[-1])
    if inb.sum() < 20:
        print("!! too little time overlap between LIVO and RTK")
        return 1

    if args.yaw_deg is None:
        yaw, tr, fit_rms, nfit = yaw_fit_robust(
            pk[inb], rt_interp[inb], iters=3 if args.yaw_robust else 1)
    else:
        yaw = math.radians(args.yaw_deg)
        # fit only the translation with the given yaw
        R2 = np.array([[math.cos(yaw), -math.sin(yaw)],
                       [math.sin(yaw), math.cos(yaw)]])
        tr = rt_interp[inb].mean(0) - R2 @ pk[inb].mean(0)
        pred = (R2 @ pk[inb, :2].T).T + tr
        fit_rms = float(np.sqrt(((pred - rt_interp[inb, :2]) ** 2).sum(1).mean()))
        nfit = int(inb.sum())

    args.fit_rms = fit_rms

    if args.tddd_csv and args.tddd_auto_fit:
        if fit_rms < args.tddd_fit_thresh:
            args.tddd_gate_only = True
            args.tddd_consistency_gate = True
            print("  TDDD auto: fit_rms=%.2f < %.2f -> gate-only (no factors)" %
                  (fit_rms, args.tddd_fit_thresh))
        else:
            print("  TDDD auto: fit_rms=%.2f >= %.2f -> TDDD factors" %
                  (fit_rms, args.tddd_fit_thresh))

    if args.stage2_auto:
        if fit_rms < args.tddd_fit_thresh:
            args.tddd_gate_only = True
            args.tddd_consistency_gate = True
            args.static_prior_sigma = 0.0
            args.cauchy_xy = 0.0
            print("  Stage2 auto: fit_rms=%.2f < %.2f -> gate-only, no static/Cauchy" %
                  (fit_rms, args.tddd_fit_thresh))
        else:
            args.tddd_gate_only = False
            args.static_prior_sigma = 0.01
            args.static_detect_thresh = 0.20
            args.cauchy_xy = 1.0
            print("  Stage2 auto: fit_rms=%.2f >= %.2f -> TDDD + static0.01@0.20 + Cauchy1.0" %
                  (fit_rms, args.tddd_fit_thresh))

    if args.auto_sigma_rtk:
        auto = args.fit_a - args.fit_b * fit_rms
        auto = min(args.sigma_rtk_weak, max(args.sigma_rtk_strong, auto))
        print("  auto sigma_rtk_xy=%.3f m from fit_rms=%.2f m "
              "(a=%.2f b=%.2f, clip %.2f..%.2f)" %
              (auto, fit_rms, args.fit_a, args.fit_b,
               args.sigma_rtk_strong, args.sigma_rtk_weak))
        args.sig_rtk_xy = auto

    if args.auto_odom:
        odom = args.odom_a + args.odom_b * (fit_rms - args.odom_fit_ref)
        odom = min(args.odom_max, max(args.odom_a, odom))
        print("  auto sigma_odom=%.3f m from fit_rms=%.2f m "
              "(a=%.2f b=%.2f ref=%.2f, clip %.2f..%.2f)" %
              (odom, fit_rms, args.odom_a, args.odom_b,
               args.odom_fit_ref, args.odom_a, args.odom_max))
        args.sig_odom = odom

    print("== %s ==" % args.tag)
    loops = []
    if args.oracle_loops:
        reft, refp, _ = load_tum_q(args.oracle_loops)
        inb_ref = (rt >= reft[0]) & (rt <= reft[-1])
        if inb_ref.sum() < 20:
            print("!! not enough reference/RTK overlap for oracle loops")
            return 1
        ref_at_rt = interp_xyz(reft, refp, rt[inb_ref])
        yaw_ref, _, rms_ref, n_ref = yaw_fit_robust(
            ref_at_rt[:, :2], rp[inb_ref, :2], iters=3)
        print("  oracle reference: %s, ref->rtk yaw=%.2f deg, "
              "fit_rms=%.2f m (n=%d)" %
              (os.path.basename(args.oracle_loops), math.degrees(yaw_ref),
               rms_ref, n_ref))
        loops, loop_diag = select_oracle_loops(tk, reft, refp, yaw_ref, args)
        if args.shuffle_loops and loops:
            rng = np.random.default_rng(args.loop_shuffle_seed)
            orig = list(loops)
            perm = rng.permutation(len(orig))
            loops = [(i, j, orig[p][2], orig[p][3], dist)
                     for (i, j, _, _, dist), p in zip(orig, perm)]
            print("  oracle loops: SHUFFLED measurements (seed=%d)" %
                  args.loop_shuffle_seed)
        dvals = np.array([x[4] for x in loops])
        print("  oracle loops: n=%d (%.1f%% of keyframes), near=%d/%d, "
              "moving=%.1f%%, static=%.1f%%, ref dist p50/p90=%.2f/%.2f m, "
              "sigma=%.2f m" %
              (loop_diag["n"], 100.0 * loop_diag["n"] / max(len(tk), 1),
               loop_diag["n_near"], loop_diag["n_with_prev"],
               100.0 * loop_diag["moving_frac"],
               100.0 * loop_diag["static_frac"],
               np.percentile(dvals, 50) if dvals.size else float("nan"),
               np.percentile(dvals, 90) if dvals.size else float("nan"),
               args.loop_sigma_xy))
        if not loops:
            print("  !! oracle loops requested but none selected")
    print("  livo=%s (%d poses) rtk=%s (%d fixes)" %
          (os.path.basename(args.livo), len(t), os.path.basename(rtk_path), len(rt)))
    print("  keyframes=%d (dt>=%.2fs) yaw=%.2f deg fit_rms=%.2f m (n=%d)" %
          (len(tk), args.keyframe_dt, math.degrees(yaw), fit_rms, nfit))
    print("  weights: odom=%.3f m, rtk_mode=%s, rtk_xy=%.3f m, rtk_z=%.3f m, "
          "rtk_rel_xy=%.3f m, rtk_subsample=%d, adaptive_rtk=%s, huber_xy=%s, "
          "static=%s, static_dw=%s, static_rtk_w=%.2f" %
          (args.sig_odom, args.rtk_mode, args.sig_rtk_xy, args.sig_rtk_z,
           args.sig_rtk_rel_xy, args.rtk_subsample,
           "on" if args.adaptive_rtk else "off",
           "off" if args.huber_xy <= 0 else "%.2f m" % args.huber_xy,
           "off" if args.static_prior_sigma <= 0 else "%.2f m" % args.static_prior_sigma,
           "on" if args.static_downweight else "off",
           args.static_rtk_weight))
    if args.tddd_csv:
        print("  TDDD: sigma_scale=%.2f, consistency_gate=%s, aniso_odom=%s "
              "(along=%.3f cross=%.3f m)" %
              (args.tddd_sigma_scale,
               "on" if args.tddd_consistency_gate else "off",
               "on" if args.aniso_odom else "off",
               args.sig_odom_along, args.sig_odom_cross))
    if args.static_rigid_sigma > 0:
        print("  static rigid: sigma=%.3f m, anchor=%.3f m, detect=%.2f m/s "
              "win=%d, keep_rtk=%s (post-hoc static-hold should be OFF)" %
              (args.static_rigid_sigma, args.static_anchor_sigma,
               args.static_detect_thresh, args.static_detect_win,
               "on" if args.static_keep_rtk else "off"))
    if args.static_transition_sigma > 0:
        print("  static transition: sigma_xy=%.3f m, sigma_z=%.3f m, kf=%d" %
              (args.static_transition_sigma, args.static_transition_z_sigma,
               args.static_transition_kf))
    if args.odom_scale_walk_sigma > 0:
        print("  odom scale: walk_sigma=%.4f, block_kf=%d, prior_sigma=%.3f" %
              (args.odom_scale_walk_sigma, args.odom_scale_block_kf,
               args.odom_scale_prior_sigma))
    if args.cauchy_xy > 0 or args.cauchy_z > 0:
        print("  robust RTK: cauchy_xy=%.2f m, cauchy_z=%.2f m" %
              (args.cauchy_xy, args.cauchy_z))
    if args.sig_odom_z > 0:
        print("  odom z sigma: %.3f m (xy %.3f m)" %
              (args.sig_odom_z, args.sig_odom))

    sig_vec = None
    if args.adaptive_rtk:
        sig_vec = consistency_sigma(tk, pk, rt, rt_interp, yaw, args)
    rel_w = None
    if args.rel_weight_csv:
        rel_w = load_rel_weight(args.rel_weight_csv, tk)
        print("  reliability weight: %s (min/med/max=%.3f/%.3f/%.3f)" %
              (os.path.basename(args.rel_weight_csv), rel_w.min(),
               float(np.median(rel_w)), rel_w.max()))
    rtk_status = None
    if args.rtk_status_csv:
        st_t, st_v = load_rtk_status(args.rtk_status_csv)
        rtk_status = np.full(len(rt), -1, dtype=int)
        for j, tt in enumerate(rt):
            k = int(np.argmin(np.abs(st_t - tt)))
            if abs(st_t[k] - tt) < 0.55:
                rtk_status[j] = st_v[k]
        print("  rtk status: fixed=%d float=%d unknown=%d" % (
            int(np.sum(rtk_status == 5)), int(np.sum(rtk_status == 2)),
            int(np.sum(rtk_status < 0))))
    rtk_kf = None
    if args.rtk_interp_en:
        rtk_kf = np.empty((len(tk), 3))
        if args.rtk_interp_status_aware and rtk_status is not None:
            ir_kf = np.array([int(np.argmin(np.abs(rt - x))) for x in tk])
            jump_ok = (fix_jump_mask(rt, rp, args.fixed_max_jump)
                       if args.fixed_max_jump > 0 else np.ones(len(rt), bool))
            for i, tt in enumerate(tk):
                st = int(rtk_status[ir_kf[i]])
                if st in (2, 5):
                    idx = np.where((rtk_status == st) & jump_ok)[0]
                    if len(idx) == 0:
                        idx = np.where(rtk_status == st)[0]
                    pos = int(np.searchsorted(rt[idx], tt))
                    if 0 < pos < len(idx):
                        j0, j1 = int(idx[pos - 1]), int(idx[pos])
                        if rt[j1] - rt[j0] <= max(args.rtk_interp_max_gap, 1e-6):
                            f = (tt - rt[j0]) / max(rt[j1] - rt[j0], 1e-9)
                            rtk_kf[i] = (1.0 - f) * rp[j0] + f * rp[j1]
                            continue
                    j = int(idx[np.argmin(np.abs(rt[idx] - tt))])
                    rtk_kf[i] = rp[j]
                else:
                    for k in range(3):
                        rtk_kf[i, k] = np.interp(tt, rt, rp[:, k])
            print("  rtk interpolation: %d keyframes, status-aware (same-status only)" % len(tk))
        else:
            for k in range(3):
                rtk_kf[:, k] = np.interp(tk, rt, rp[:, k])
            print("  rtk interpolation: %d keyframes (c02 phase .5 s fixed)" % len(tk))
    imu = None
    if args.imu_csv:
        imu = load_imu_csv(args.imu_csv)
        print("  imu: %d samples, t=[%.3f, %.3f]" % (
            len(imu[0]), imu[0][0], imu[0][-1]))
    if loops:
        print("  loop factors: %d x 2D, sigma=%.3f m, source=%s" %
              (len(loops), args.loop_sigma_xy,
               os.path.basename(args.oracle_loops or "")))
    t_solve = time.perf_counter()
    pg, n_fix, used = solve_graph(tk, pk, qk, rt, rp, yaw, tr, args,
                                  sig_rtk_vec=sig_vec, loops=loops, tddd=tddd,
                                  lambda_kf=lambda_kf, rel_w=rel_w,
                                  rtk_status=rtk_status, rtk_kf=rtk_kf,
                                  imu=imu)
    print("  graph solve: %.1f ms" % ((time.perf_counter() - t_solve) * 1000.0))
    print("  rtk factors used: %d/%d (unique)" % (n_fix, len(tk)))
    if loops:
        loop_rms = loop_residual_rms(pg, loops)
        print("  loop residual RMS: %.4f m (n=%d)" % (loop_rms, len(loops)))
        if args.loop_report:
            write_loop_report(args.loop_report, tk, loops, loop_rms,
                              extra="tag=%s sigma=%.3f" %
                                    (args.tag, args.loop_sigma_xy))
    elif args.loop_report:
        print("  !! --loop-report given but no loops")
    if args.static_hold:
        # Wider than the graph's static-prior mask: the hold must cover the
        # full reference stop, including the slow edges.
        smask = static_mask_keyframes(tk, pk, thresh=0.20, win=3)
        pg = apply_static_hold(pg, pk, smask, tk, args.static_hold_blend,
                               rtk_kf=rt_interp,
                               expand_s=args.static_hold_expand,
                               anchor=args.static_hold_anchor)
    out = args.out or ("%s_graph.tum" % args.tag)
    write_tum(out, tk, pg, qk)
    print("  wrote %s" % out)

    if args.ref:
        reft, refp = eu.load_tum(args.ref)
        print("")
        eval_arms("LIVO (keyframes)", tk, pk, reft, refp, reft, refp, wins)
        eval_arms("RTK-only (interp)", tk, rt_interp, reft, refp, reft, refp, wins)
        eval_arms("GRAPH", tk, pg, reft, refp, reft, refp, wins)
    return 0


if __name__ == "__main__":
    sys.exit(main())
