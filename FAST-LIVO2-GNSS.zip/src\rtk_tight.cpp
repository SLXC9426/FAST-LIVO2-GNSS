#include "rtk_tight.h"

#include "rtk_geometry.h"
#include "rtk_validation.h"

#include <algorithm>
#include <cmath>
#include <cstdio>

// Frame note (R4.2a): RtkTight evaluates its DD geometry in a base-centred ENU
// with U NEGATED (z-down), the convention the frontend used before R4.2a. The
// main GNSS/ENU path is now z-up, and the A-main configuration disables frontend
// RTK injection. Re-audit base_enu_neg_, sat_enu and p_ant_enu together before
// re-enabling this branch in the main chain; the vertical lever/offset is small
// enough that the R1 float-DD smoke still converged.

namespace
{
constexpr double kPi = 3.14159265358979323846;
constexpr double kWgs84A = 6378137.0;
constexpr double kWgs84F = 1.0 / 298.257223563;
constexpr double kWgs84E2 = kWgs84F * (2.0 - kWgs84F);
}  // namespace

RtkTight::RtkTight() : amb_(0), P_amb_(0, 0) {}

void RtkTight::setConfig(const Config &cfg)
{
  cfg_ = cfg;
  origin_set_ = false;
  base_enu_neg_.setZero();
  reset();
}

void RtkTight::setExternalWeight(double w)
{
  external_weight_ = std::max(0.0, std::min(1.0, w));
}

bool RtkTight::scoreAlignment(const fast_livo::RtkDD &msg,
                              const StatesGroup &state,
                              const M3D &enu_R_world,
                              const V3D &enu_t_world,
                              const V3D &lever_body,
                              double &rms) const
{
  if (!origin_set_) return false;
  const int n = (int)std::min({msg.dd_code.size(), msg.sat_x.size(),
                               msg.sat_y.size(), msg.sat_z.size(),
                               msg.ref_x.size(), msg.ref_y.size(),
                               msg.ref_z.size()});
  if (n <= 0) return false;

  double base_lat = 0.0, base_lon = 0.0, base_alt = 0.0;
  ecefToGeodetic(cfg_.base_ecef, base_lat, base_lon, base_alt);
  const M3D R_enu_base = enuRotation(base_lat, base_lon);

  const V3D lever_world = state.rot_end * lever_body;
  const V3D p_ant_world = state.pos_end + lever_world;
  const V3D p_ant_enu =
      enu_R_world.transpose() * (p_ant_world - enu_t_world) - base_enu_neg_;

  std::vector<double> abs_res;
  abs_res.reserve(n);
  for (int i = 0; i < n; ++i)
  {
    const Eigen::Vector3d sat_ecef(msg.sat_x[i], msg.sat_y[i], msg.sat_z[i]);
    const Eigen::Vector3d ref_ecef(msg.ref_x[i], msg.ref_y[i], msg.ref_z[i]);
    const Eigen::Vector3d sat_enu_u = R_enu_base * (sat_ecef - cfg_.base_ecef);
    const Eigen::Vector3d ref_enu_u = R_enu_base * (ref_ecef - cfg_.base_ecef);
    const V3D sat_enu(sat_enu_u(0), sat_enu_u(1), -sat_enu_u(2));
    const V3D ref_enu(ref_enu_u(0), ref_enu_u(1), -ref_enu_u(2));
    const double rho_r_sat = (sat_enu - p_ant_enu).norm();
    const double rho_r_ref = (ref_enu - p_ant_enu).norm();
    const double rho_b_sat = sat_enu.norm();
    const double rho_b_ref = ref_enu.norm();
    const double dd_geom = (rho_r_sat - rho_b_sat) - (rho_r_ref - rho_b_ref);
    abs_res.push_back(std::fabs(msg.dd_code[i] - dd_geom));
  }
  std::sort(abs_res.begin(), abs_res.end());
  const int keep = std::max(1, (int)(0.8 * n));
  double sq = 0.0;
  for (int i = 0; i < keep; ++i) sq += abs_res[i] * abs_res[i];
  rms = std::sqrt(sq / keep);
  return true;
}

void RtkTight::setAlignResidual(double r)
{
  align_resid_ = r;
  if (!cfg_.coarse_acq_en || r < 0.0 || r > cfg_.coarse_acq_max_align_resid)
    coarse_acq_ = false;
  else if (!coarse_done_)
    coarse_acq_ = true;
}

void RtkTight::reset()
{
  index_.clear();
  amb_.resize(0);
  P_amb_.resize(0, 0);
  accepted_ = 0;
  rejected_ = 0;
  evaluated_ = 0;
  fixed_streak_ = 0;
  fixed_streak_s_ = 0.0;
  first_t_ = -1.0;
  last_health_t_ = -1.0;
  last_t_ = -1.0;
  coarse_acq_ = false;
  coarse_done_ = false;
  fixed_settled_ = false;
  fixed_settle_good_s_ = 0.0;
  align_resid_ = -1.0;
  frame_offset_done_ = false;
  frame_offset_pending_ = false;
  frame_offset_first_t_ = -1.0;
  frame_offset_enu_.setZero();
  coarse_good_s_ = 0.0;
  coarse_last_t_ = -1.0;
  health_ = Health();
  external_weight_ = 1.0;
  use_fixed_phase_ext_ = true;
}

void RtkTight::ecefToGeodetic(const Eigen::Vector3d &ecef, double &lat,
                              double &lon, double &alt)
{
  const double x = ecef(0), y = ecef(1), z = ecef(2);
  lon = std::atan2(y, x);
  const double p = std::hypot(x, y);
  lat = std::atan2(z, p * (1.0 - kWgs84E2));
  for (int i = 0; i < 8; ++i)
  {
    const double N = kWgs84A / std::sqrt(1.0 - kWgs84E2 * std::sin(lat) * std::sin(lat));
    alt = p / std::cos(lat) - N;
    lat = std::atan2(z, p * (1.0 - kWgs84E2 * N / (N + alt)));
  }
  const double N = kWgs84A / std::sqrt(1.0 - kWgs84E2 * std::sin(lat) * std::sin(lat));
  alt = p / std::cos(lat) - N;
}

Eigen::Vector3d RtkTight::geodeticToEcef(double lat, double lon, double alt)
{
  const double N = kWgs84A / std::sqrt(1.0 - kWgs84E2 * std::sin(lat) * std::sin(lat));
  return Eigen::Vector3d((N + alt) * std::cos(lat) * std::cos(lon),
                         (N + alt) * std::cos(lat) * std::sin(lon),
                         (N * (1.0 - kWgs84E2) + alt) * std::sin(lat));
}

Eigen::Matrix3d RtkTight::enuRotation(double lat, double lon)
{
  const double sl = std::sin(lat), cl = std::cos(lat);
  const double so = std::sin(lon), co = std::cos(lon);
  Eigen::Matrix3d R;
  R << -so, co, 0.0,
       -sl * co, -sl * so, cl,
        cl * co, cl * so, sl;
  return R;
}

double RtkTight::chi2Threshold95(int dof)
{
  if (dof <= 0) return 0.0;
  const double z = 1.6448536269514722;  // 95% normal quantile
  const double a = 2.0 / (9.0 * dof);
  const double t = 1.0 - a + z * std::sqrt(a);
  return dof * t * t * t;
}

double RtkTight::igg3Weight(double u, double k0, double k1)
{
  if (u <= k0) return 1.0;
  if (u <= k1) return k0 / u;
  return 0.0;
}

void RtkTight::setOrigin(double lat, double lon, double alt)
{
  origin_lat_ = lat * kPi / 180.0;
  origin_lon_ = lon * kPi / 180.0;
  origin_alt_ = alt;

  double base_lat = 0.0, base_lon = 0.0, base_alt = 0.0;
  ecefToGeodetic(cfg_.base_ecef, base_lat, base_lon, base_alt);
  const Eigen::Vector3d d = cfg_.base_ecef - geodeticToEcef(origin_lat_, origin_lon_, origin_alt_);
  const Eigen::Vector3d enu = enuRotation(origin_lat_, origin_lon_) * d;
  base_enu_neg_ = Eigen::Vector3d(enu(0), enu(1), -enu(2));
  origin_set_ = true;

  if (cfg_.verbose)
  {
    printf("[RTK] origin set: base in GNSS ENU (U negated) = %.3f %.3f %.3f m\n",
           base_enu_neg_(0), base_enu_neg_(1), base_enu_neg_(2));
    fflush(stdout);
  }
}

int RtkTight::addAmbiguity(const AmbKey &key, double value)
{
  const int idx = (int)amb_.size();
  amb_.conservativeResize(idx + 1);
  amb_(idx) = value;
  P_amb_.conservativeResize(idx + 1, idx + 1);
  P_amb_.row(idx).setZero();
  P_amb_.col(idx).setZero();
  P_amb_(idx, idx) = cfg_.init_amb_var;
  index_[key] = idx;
  return idx;
}

void RtkTight::resetAmbiguity(int idx, double value)
{
  amb_(idx) = value;
  P_amb_.row(idx).setZero();
  P_amb_.col(idx).setZero();
  P_amb_(idx, idx) = cfg_.init_amb_var;
}

// Store the anchor for the next TDCP interval: the DD phase and satellite
// geometry of this epoch, plus the posterior antenna position in the
// base-centred, U-negated ENU frame used by the DD geometry.
void RtkTight::storeTdcpPrev(const StatesGroup &post,
                             const fast_livo::RtkDD &msg,
                             const M3D &enu_R_world,
                             const V3D &enu_t_world,
                             const V3D &lever_body)
{
  double base_lat = 0.0, base_lon = 0.0, base_alt = 0.0;
  ecefToGeodetic(cfg_.base_ecef, base_lat, base_lon, base_alt);
  const Eigen::Matrix3d R_enu_base = enuRotation(base_lat, base_lon);

  const V3D lever_world = post.rot_end * lever_body;
  V3D p_ant_world = post.pos_end + lever_world;
  if (use_scale_)
  {
    p_ant_world(0) = post.scale_h * post.pos_end(0) + lever_world(0);
    p_ant_world(1) = post.scale_h * post.pos_end(1) + lever_world(1);
  }
  const V3D p_ant_enu_first = enu_R_world.transpose() * (p_ant_world - enu_t_world);
  const V3D p_ant_enu = p_ant_enu_first - base_enu_neg_;

  tdcp_prev_.clear();
  const int n = (int)msg.n;
  for (int i = 0; i < n; ++i)
  {
    if (msg.slip[i] || msg.ref_change[i]) continue;
    const Eigen::Vector3d sat_ecef(msg.sat_x[i], msg.sat_y[i], msg.sat_z[i]);
    const Eigen::Vector3d ref_ecef(msg.ref_x[i], msg.ref_y[i], msg.ref_z[i]);
    const Eigen::Vector3d sat_enu_u = R_enu_base * (sat_ecef - cfg_.base_ecef);
    const Eigen::Vector3d ref_enu_u = R_enu_base * (ref_ecef - cfg_.base_ecef);
    const V3D sat_enu(sat_enu_u(0), sat_enu_u(1), -sat_enu_u(2));
    const V3D ref_enu(ref_enu_u(0), ref_enu_u(1), -ref_enu_u(2));
    const double rho_r_sat = (sat_enu - p_ant_enu).norm();
    const double rho_r_ref = (ref_enu - p_ant_enu).norm();
    const double dd_geom =
        (rho_r_sat - sat_enu.norm()) - (rho_r_ref - ref_enu.norm());

    AmbKey key;
    key.sys = msg.sys[i];
    key.freq = msg.freq[i];
    key.sat = msg.sat[i];
    key.ref = msg.ref_sat[i];

    TdcpPrev p;
    p.phase = msg.dd_phase[i];
    p.sat_ecef = sat_ecef;
    p.ref_ecef = ref_ecef;
    p.sigma_phase = (i < (int)msg.sigma_phase.size()) ? msg.sigma_phase[i] : 0.015;
    p.elev_min = 90.0;
    if (i < (int)msg.elev_sat.size() && i < (int)msg.elev_ref.size())
      p.elev_min = std::min(msg.elev_sat[i], msg.elev_ref[i]);
    p.dd_geom = dd_geom;
    tdcp_prev_[key] = p;
  }
  last_p_ant_enu_ = p_ant_enu;
  last_tdcp_t_ = msg.header.stamp.toSec();
  have_tdcp_prev_ = !tdcp_prev_.empty();
}

bool RtkTight::update(const fast_livo::RtkDD &msg,
                      const StatesGroup &state_prop,
                      const M3D &enu_R_world,
                      const V3D &enu_t_world,
                      const V3D &lever_body,
                      Eigen::Matrix<double, DIM_STATE, 1> &dx,
                      Eigen::Matrix<double, DIM_STATE, DIM_STATE> &P_new)
{
  if (!origin_set_) return false;
  const fast_livo::RtkDDValidation valid = fast_livo::validateRtkDD(msg);
  if (!valid.ok)
  {
    printf("[RTK] malformed message: %s (n=%u)\n", valid.reason.c_str(),
           static_cast<unsigned>(msg.n));
    fflush(stdout);
    return false;
  }
  const int n = (int)msg.n;
  {
    static int e = 0;
    if (e < 5)
    {
      printf("[RTK] update enter n=%d origin=%d\n", n, (int)origin_set_);
      fflush(stdout);
      e++;
    }
  }

  // Fixed-pair supervisor: time-based so 1 Hz and 10 Hz streams behave the
  // same. The physical minimum pair count is dataset-independent.
  const double t_now = msg.header.stamp.toSec();
  double dt = 1.0;
  if (last_health_t_ > 0.0 && t_now > last_health_t_)
    dt = std::max(0.01, std::min(2.0, t_now - last_health_t_));
  last_health_t_ = t_now;
  if (first_t_ < 0.0) first_t_ = t_now;

  int n_fixed_valid = 0;
  if (cfg_.fixed_phase_en && (int)msg.fix_valid.size() >= n)
  {
    for (int i = 0; i < n; ++i)
      if (msg.fix_valid[i] && !msg.slip[i] && !msg.ref_change[i]) ++n_fixed_valid;
  }
  if (n_fixed_valid >= cfg_.min_fixed_pairs) fixed_streak_s_ += dt;
  else fixed_streak_s_ = 0.0;
  fixed_streak_ = (int)(fixed_streak_s_ + 0.5);
  const bool fixed_streak_ok = fixed_streak_s_ >= cfg_.fixed_min_streak_s;
  // Admission gate uses the previous epoch's code RMS (health_ is overwritten
  // later in this call). A large common code residual means the frame/state is
  // not close enough for a cm-level fixed phase.
  const bool fixed_code_ok =
      !cfg_.fixed_phase_code_gate_en ||
      health_.code_rms <= cfg_.fixed_phase_max_code_rms;

  health_.n_pairs = n;
  health_.n_fixed = n_fixed_valid;
  health_.fixed_streak = fixed_streak_;
  health_.fixed_streak_s = fixed_streak_s_;
  health_.ratio = msg.ratio;
  health_.t = t_now;
  health_.accepted = false;
  health_.gamma = 0.0;
  health_.gate = 0.0;

  double base_lat = 0.0, base_lon = 0.0, base_alt = 0.0;
  ecefToGeodetic(cfg_.base_ecef, base_lat, base_lon, base_alt);
  const Eigen::Matrix3d R_enu_base = enuRotation(base_lat, base_lon);

  // Antenna position in the existing U-negated ENU frame, then shifted to the
  // base-centred ENU origin.
  const V3D lever_world = state_prop.rot_end * lever_body;
  V3D p_ant_world = state_prop.pos_end + lever_world;
  if (use_scale_)
  {
    p_ant_world(0) = state_prop.scale_h * state_prop.pos_end(0) + lever_world(0);
    p_ant_world(1) = state_prop.scale_h * state_prop.pos_end(1) + lever_world(1);
  }
  const V3D p_ant_enu_first = enu_R_world.transpose() * (p_ant_world - enu_t_world);
  const V3D p_ant_enu = p_ant_enu_first - base_enu_neg_;

  const int m_obs = 2 * n;
  Eigen::MatrixXd H_meas = Eigen::MatrixXd::Zero(m_obs, DIM_STATE);
  Eigen::MatrixXd H_a = Eigen::MatrixXd::Zero(m_obs, (int)amb_.size() + n);
  Eigen::VectorXd r = Eigen::VectorXd::Zero(m_obs);
  Eigen::MatrixXd R_eff = Eigen::MatrixXd::Zero(m_obs, m_obs);
  std::vector<int> amb_idx(n, -1);
  std::vector<uint8_t> row_fixed(m_obs, 0);
  std::vector<double> row_base_var(m_obs, 0.0);
  std::vector<V3D> d_dd_rows(m_obs, V3D::Zero());

  // R1: the max_corr gate rejects after the pair loop, but that loop has
  // already created/reset ambiguity states. Keep a snapshot so a rejected epoch
  // leaves amb_, P_amb_ and index_ exactly as they were. Only taken when the
  // gate can actually fire; the dense copy is O(n_amb^2), acceptable while the
  // ambiguity lifecycle (R3) is still unbounded.
  const bool can_reject_by_corr = cfg_.max_corr > 0.0 && !coarse_acq_;
  Eigen::VectorXd amb_before;
  Eigen::MatrixXd P_amb_before;
  std::map<AmbKey, int> index_before;
  if (can_reject_by_corr)
  {
    amb_before = amb_;
    P_amb_before = P_amb_;
    index_before = index_;
  }

  double code_sq = 0.0, phase_sq = 0.0, fixed_phase_sq = 0.0;
  int fixed_phase_n = 0;
  int phase_slips = 0;
  int rej_code = 0, rej_phase = 0;
  int n_fixed = 0;
  const bool fixed_tight =
      cfg_.fixed_settle_en
          ? fixed_settled_
          : (first_t_ >= 0.0 && t_now - first_t_ >= cfg_.fixed_warmup_s);
  const double sigma_fixed_use =
      fixed_tight ? cfg_.sigma_fixed_phase_tight : cfg_.sigma_fixed_phase;
  const double gate_fixed_use =
      fixed_tight ? cfg_.fixed_phase_gate_tight : cfg_.fixed_phase_gate;
  // Coarse acquisition overrides the normal tight schedule until the DD code
  // residual has been small for a few accepted epochs. This is what lets a
  // metre-level LIO/GNSS offset be removed in one update instead of being
  // clamped to 1 m/epoch while the LIO drift keeps re-adding it.
  const double prior_pos_use = coarse_acq_
                                   ? cfg_.coarse_acq_prior_sigma
                                   : (fixed_tight ? cfg_.prior_sigma_pos_tight
                                                  : cfg_.prior_sigma_pos);

  for (int i = 0; i < n; ++i)
  {
    const Eigen::Vector3d sat_ecef(msg.sat_x[i], msg.sat_y[i], msg.sat_z[i]);
    const Eigen::Vector3d ref_ecef(msg.ref_x[i], msg.ref_y[i], msg.ref_z[i]);
    const Eigen::Vector3d sat_enu_u = R_enu_base * (sat_ecef - cfg_.base_ecef);
    const Eigen::Vector3d ref_enu_u = R_enu_base * (ref_ecef - cfg_.base_ecef);
    const V3D sat_enu(sat_enu_u(0), sat_enu_u(1), -sat_enu_u(2));
    const V3D ref_enu(ref_enu_u(0), ref_enu_u(1), -ref_enu_u(2));

    const double rho_r_sat = (sat_enu - p_ant_enu).norm();
    const double rho_r_ref = (ref_enu - p_ant_enu).norm();
    const double rho_b_sat = sat_enu.norm();
    const double rho_b_ref = ref_enu.norm();
    if (rho_r_sat < 1.0 || rho_r_ref < 1.0)
    {
      printf("[RTK] degenerate range at pair %d (%s/%s)\n", i,
             msg.sat[i].c_str(), msg.ref_sat[i].c_str());
      return false;
    }
    // Residual is r = z - h(p) and h is the DD geometry.  The base-station
    // terms are constant, so dh/dp = u_sat - u_ref with u_x = (p - x)/|p - x|.
    // The sign must match the TDCP branch and the z-h convention; reversing it
    // makes every update move away from the measurement.
    const double dd_geom = fast_livo::ddGeometry(p_ant_enu, sat_enu, ref_enu) -
                           (rho_b_sat - rho_b_ref);
    const V3D u_sat = (p_ant_enu - sat_enu) / rho_r_sat;
    const V3D u_ref = (p_ant_enu - ref_enu) / rho_r_ref;
    const V3D d_dd_dp_enu = u_sat - u_ref;
    const Eigen::Matrix<double, 1, 3> H_pos =
        d_dd_dp_enu.transpose() * enu_R_world.transpose();
    // Right perturbation R_new = R * Exp(dtheta): d(R l)/dtheta = -R [l]_x.
    const Eigen::Matrix<double, 1, 3> H_att =
        fast_livo::leverArmAttitudeJacobian(H_pos, state_prop.rot_end,
                                            lever_body);

    Eigen::Matrix<double, 1, DIM_STATE> H_row =
        Eigen::Matrix<double, 1, DIM_STATE>::Zero();
    H_row.block<1, 3>(0, 0) = H_att;
    Eigen::Matrix<double, 1, 3> H_pos_lio = H_pos;
    if (use_scale_)
    {
      H_pos_lio(0, 0) *= state_prop.scale_h;
      H_pos_lio(0, 1) *= state_prop.scale_h;
      // d(dd_geom)/ds = H_pos_true * [px, py, 0].
      H_row(0, 19) = H_pos(0, 0) * state_prop.pos_end(0) +
                     H_pos(0, 1) * state_prop.pos_end(1);
    }
    H_row.block<1, 3>(0, 3) = H_pos_lio;

    AmbKey key;
    key.sys = msg.sys[i];
    key.freq = msg.freq[i];
    key.sat = msg.sat[i];
    key.ref = msg.ref_sat[i];

    // GREAT-MSF-aided fixed phase: use the externally integer-fixed phase as a
    // precise range measurement and do not create an ambiguity state for it.
    // A slip or reference change invalidates the external integer.
    const bool use_fixed =
        cfg_.fixed_phase_en && fixed_streak_ok && fixed_code_ok &&
        use_fixed_phase_ext_ &&
        i < (int)msg.fix_valid.size() &&
        i < (int)msg.dd_phase_fixed.size() && msg.fix_valid[i] != 0 &&
        !msg.slip[i] && !msg.ref_change[i];
    if (use_fixed) ++n_fixed;

    int idx = -1;
    double r_phase = 0.0;
    if (!use_fixed)
    {
      auto it = index_.find(key);
      idx = -1;
      const bool is_new = (it == index_.end());
      bool just_reset = is_new;
      if (is_new)
      {
        idx = addAmbiguity(key, msg.dd_phase[i] - dd_geom);
      }
      else
      {
        idx = it->second;
        if (msg.slip[i] || msg.ref_change[i])
        {
          resetAmbiguity(idx, msg.dd_phase[i] - dd_geom);
          just_reset = true;
        }
      }
      amb_idx[i] = idx;

      r_phase = msg.dd_phase[i] - dd_geom - amb_(idx);
      // Residual-based slip catch: the Phase-1 flags use the rover only, so a
      // base-station cycle slip can survive them. A metre-level phase jump is a
      // new ambiguity, not an outlier to reject the whole epoch for.
      if (!just_reset && std::fabs(r_phase) > cfg_.phase_slip_thresh)
      {
        resetAmbiguity(idx, msg.dd_phase[i] - dd_geom);
        r_phase = 0.0;
        ++phase_slips;
      }
    }
    else
    {
      r_phase = msg.dd_phase_fixed[i] - dd_geom;
    }

    const double sigma_code_floor =
        coarse_acq_ ? cfg_.coarse_acq_code_sigma : cfg_.sigma_code_min;
    // Optional elevation-dependent quality factor.  A DD pair is limited by
    // its lower satellite; the reference is 30 deg, so a 10-deg pair gets
    // q = sqrt(sin30/sin10) ~= 1.7 at the default exponent 0.5.  The factor
    // is applied after the configured sigma floors, so it can either
    // down-weight a low pair or strengthen a high pair.
    double q_elev = 1.0;
    if (cfg_.quality_elev_en)
    {
      const double e_sat = (i < (int)msg.elev_sat.size()) ? msg.elev_sat[i] : 90.0;
      const double e_ref = (i < (int)msg.elev_ref.size()) ? msg.elev_ref[i] : 90.0;
      const double e = std::max(5.0, std::min(e_sat, e_ref));
      const double e0 = std::max(5.0, cfg_.quality_elev_ref_deg);
      const double ratio = std::sin(e0 * kPi / 180.0) /
                           std::max(0.05, std::sin(e * kPi / 180.0));
      q_elev = std::pow(ratio, std::max(0.0, cfg_.quality_elev_weight));
      q_elev = std::min(std::max(q_elev, cfg_.quality_elev_min),
                        cfg_.quality_elev_max);
    }
    const double sigma_code =
        std::max(msg.sigma_code[i] * cfg_.sigma_code_scale, sigma_code_floor) * q_elev;
    const double sigma_phase =
        std::max(msg.sigma_phase[i], cfg_.sigma_phase_min) * q_elev;

    const int rc = 2 * i;
    const int rp = 2 * i + 1;
    d_dd_rows[rp] = d_dd_dp_enu;
    H_meas.row(rc) = H_row;
    H_meas.row(rp) = H_row;
    r(rc) = msg.dd_code[i] - dd_geom;
    r(rp) = r_phase;

    // Phase 3: IGG3 relative weights + IMU/LiDAR-prior absolute code gate.
    // The innovation r_code is formed at the IMU/LiDAR-propagated state, so
    // |r_code| is exactly the absolute observation error relative to an
    // independent geometric prior.  robust_en=false is the Phase-2 path.
    double w_code = 1.0, w_phase = 1.0;
    // During coarse acquisition the code sigma is small enough to pull a metre-
    // level offset, so per-pair code outliers must be gated robustly. The
    // normal Phase-2 path keeps robust_en as configured.
    if (cfg_.robust_en || coarse_acq_)
    {
      const double sc = std::max(cfg_.robust_sigma_code_abs, 1e-3);
      const double uc = std::fabs(r(rc)) / sc;
      w_code = igg3Weight(uc, cfg_.robust_k0_code, cfg_.robust_k1_code);
      if (std::fabs(r(rc)) > cfg_.robust_kappa_code * sc) w_code = 0.0;
      if (w_code <= 0.0) ++rej_code;
    }

    R_eff(rc, rc) = (w_code > 0.0) ? (sigma_code * sigma_code / w_code) : 1e12;
    if (use_fixed)
    {
      // Fixed phase is already an integer-resolved range: use a small sigma
      // and an absolute gate. A large residual means the external integer is
      // stale/wrong for this pair, so drop the pair instead of biasing the state.
      double sigma = sigma_fixed_use * q_elev;
      if (fixed_tight && cfg_.per_pair_sigma &&
          i < (int)msg.sigma_phase_fixed.size())
      {
        sigma = msg.sigma_phase_fixed[i] * q_elev;
        sigma = std::max(cfg_.sigma_fixed_floor,
                         std::min(cfg_.sigma_fixed_ceiling, sigma));
      }
      sigma = std::max(sigma, 1e-4);
      const double gross_gate = std::max(gate_fixed_use, 50.0);
      if (std::fabs(r_phase) > gross_gate)
      {
        R_eff(rp, rp) = 1e12;
        ++rej_phase;
      }
      else
      {
        row_fixed[rp] = 1;
        row_base_var[rp] = sigma * sigma;
        R_eff(rp, rp) = sigma * sigma;
        fixed_phase_sq += r_phase * r_phase;
        ++fixed_phase_n;
      }
    }
    else
    {
      if (cfg_.robust_en)
      {
        const double sp = std::max(cfg_.robust_sigma_phase_abs, 1e-3);
        const double up = std::fabs(r_phase) / sp;
        w_phase = igg3Weight(up, cfg_.robust_k0_phase, cfg_.robust_k1_phase);
        if (w_phase <= 0.0) ++rej_phase;
      }
      // Marginalise the float ambiguity: its prior variance is added to the
      // phase measurement variance (block-diagonal P_xa = 0 approximation).
      const double phase_var = sigma_phase * sigma_phase + P_amb_(idx, idx);
      R_eff(rp, rp) = (w_phase > 0.0) ? (phase_var / w_phase) : 1e12;
    }
    code_sq += r(rc) * r(rc);
    phase_sq += r_phase * r_phase;
  }

  const double code_rms = std::sqrt(code_sq / std::max(1, n));
  const double fixed_phase_rms =
      fixed_phase_n > 0 ? std::sqrt(fixed_phase_sq / fixed_phase_n) : 0.0;
  health_.code_rms = code_rms;
  health_.phase_rms = fixed_phase_rms;
  health_.coarse_acq = coarse_acq_;

  // Grow H_a only after all new ambiguities exist.
  const int n_amb = (int)amb_.size();
  H_a.setZero(m_obs, n_amb);
  for (int i = 0; i < n; ++i)
    if (amb_idx[i] >= 0) H_a(2 * i + 1, amb_idx[i]) = 1.0;

  Eigen::Matrix<double, DIM_STATE, DIM_STATE> P_use = state_prop.cov;
  if (prior_pos_use > 0.0)
  {
    const double p2 = prior_pos_use * prior_pos_use;
    P_use(3, 3) = std::max(P_use(3, 3), p2);
    P_use(4, 4) = std::max(P_use(4, 4), p2);
  }
  Eigen::MatrixXd S = H_meas * P_use * H_meas.transpose() + R_eff;
  S = 0.5 * (S + S.transpose());

  // State-covariance-aware IGG3 weighting for the fixed phase. S_ii already
  // contains the LIO position covariance and the measurement variance, so a
  // metre-level frame offset is ~2-3 sigma while the prior is loose and is
  // downweighted/rejected once the state is tight. This replaces the hard
  // 0.5 m gate that rejected every fixed pair during convergence.
  if (cfg_.fixed_robust_en)
  {
    int robust_zero = 0;
    for (int k = 0; k < m_obs; ++k)
    {
      if (!row_fixed[k]) continue;
      const double s_ii = std::max(S(k, k), 1e-12);
      const double u = std::fabs(r(k)) / std::sqrt(s_ii);
      const double w = igg3Weight(u, cfg_.fixed_robust_k0, cfg_.fixed_robust_k1);
      if (w <= 0.0)
      {
        R_eff(k, k) = 1e12;
        ++robust_zero;
      }
      else
      {
        R_eff(k, k) = row_base_var[k] / w;
      }
    }
    rej_phase += robust_zero;
    S = H_meas * P_use * H_meas.transpose() + R_eff;
    S = 0.5 * (S + S.transpose());
  }

  // One-time common frame translation from the fixed-phase residuals. The
  // fixed integer is correct but the LIO/GNSS frame can be offset by metres.
  // Estimate that offset from the accepted fixed rows and apply it to
  // enu_t_world instead of pulling the state 1 m/epoch. The window and the
  // translation-fit residual guard keep a later wrong integer (P3) out.
  if (cfg_.frame_offset_en && !frame_offset_done_ && n_fixed > 0)
  {
    if (frame_offset_first_t_ < 0.0) frame_offset_first_t_ = t_now;
    if (t_now - frame_offset_first_t_ <= cfg_.frame_offset_window_s)
    {
      Eigen::Matrix3d A = Eigen::Matrix3d::Zero();
      Eigen::Vector3d b = Eigen::Vector3d::Zero();
      int m = 0;
      for (int k = 0; k < m_obs; ++k)
      {
        if (!row_fixed[k] || R_eff(k, k) >= 1e11) continue;
        if (d_dd_rows[k].squaredNorm() < 1e-12) continue;
        A += d_dd_rows[k] * d_dd_rows[k].transpose();
        b += d_dd_rows[k] * r(k);
        ++m;
      }
      if (m >= cfg_.frame_offset_min_pairs &&
          std::fabs(A.determinant()) > 1e-9)
      {
        Eigen::LDLT<Eigen::Matrix3d> aldlt(A);
        if (aldlt.info() == Eigen::Success)
        {
          const Eigen::Vector3d delta = aldlt.solve(b);
          double fit_sq = 0.0;
          for (int k = 0; k < m_obs; ++k)
          {
            if (!row_fixed[k] || R_eff(k, k) >= 1e11) continue;
            if (d_dd_rows[k].squaredNorm() < 1e-12) continue;
            const double e = d_dd_rows[k].dot(delta) - r(k);
            fit_sq += e * e;
          }
          const double fit = std::sqrt(fit_sq / m);
          if (fit <= cfg_.frame_offset_max_resid &&
              delta.norm() >= cfg_.frame_offset_min &&
              delta.norm() <= cfg_.frame_offset_max &&
              std::fabs(delta(2)) <= cfg_.frame_offset_max_vertical)
          {
            frame_offset_enu_ = delta;
            frame_offset_pending_ = true;
            frame_offset_done_ = true;
            if (cfg_.verbose)
              printf("[RTK] frame offset estimate t=%.2f dENU=(%.2f %.2f %.2f) "
                     "|d|=%.2f fit=%.2f m=%d\n",
                     t_now, delta(0), delta(1), delta(2), delta.norm(), fit, m);
            fflush(stdout);
            if (cfg_.tdcp_en)
              storeTdcpPrev(state_prop, msg, enu_R_world, enu_t_world, lever_body);
            return false;
          }
          if (fit <= cfg_.frame_offset_max_resid &&
              delta.norm() < cfg_.frame_offset_min)
          {
            frame_offset_done_ = true;
            if (cfg_.verbose)
              printf("[RTK] frame already aligned t=%.2f |d|=%.2f fit=%.2f\n",
                     t_now, delta.norm(), fit);
          }
        }
      }
    }
    else
    {
      frame_offset_done_ = true;
      if (cfg_.verbose)
        printf("[RTK] frame offset window expired t=%.2f (no translation fit)\n",
               t_now);
    }
  }

  // Common-mode wrong-integer guard: a biased external integer is consistent
  // across satellites, so per-pair IGG3 can reject a minority and still let the
  // surviving common offset move the state. Demand that most fixed pairs pass
  // their own gates; otherwise discard this epoch's fixed solution entirely.
  if (cfg_.fixed_consensus_en && n_fixed > 0)
  {
    const int n_fixed_used = std::max(0, n_fixed - rej_phase);
    const int n_fixed_need =
        std::max(cfg_.fixed_consensus_min_pairs,
                 (int)std::ceil(cfg_.fixed_consensus_min_frac * n_fixed));
    if (n_fixed_used < n_fixed_need)
    {
      ++rejected_;
      coarse_good_s_ = 0.0;
      fixed_settle_good_s_ = 0.0;
      health_.accepted = false;
      health_.coarse_acq = coarse_acq_;
      if (cfg_.verbose)
        printf("[RTK] reject t=%.2f fixed_consensus used=%d/%d need=%d "
               "rej_phase=%d |r_phase|=%.2f\n",
               msg.header.stamp.toSec(), n_fixed_used, n_fixed, n_fixed_need,
               rej_phase, std::sqrt(phase_sq / std::max(1, n)));
      fflush(stdout);
      if (cfg_.tdcp_en)
        storeTdcpPrev(state_prop, msg, enu_R_world, enu_t_world, lever_body);
      return false;
    }
  }

  // P2 supervisor: soft-weight the whole DD block. w=0.5 doubles R.
  if (external_weight_ < 1.0)
  {
    const double inv = 1.0 / std::max(external_weight_, 1e-3);
    R_eff *= inv;
    S = H_meas * P_use * H_meas.transpose() + R_eff;
    S = 0.5 * (S + S.transpose());
  }

  Eigen::LDLT<Eigen::MatrixXd> ldlt(S);
  if (ldlt.info() != Eigen::Success)
  {
    ++rejected_;
    coarse_good_s_ = 0.0;
    fixed_settle_good_s_ = 0.0;
    health_.coarse_acq = coarse_acq_;
    printf("[RTK] S not decomposable (n=%d)\n", n);
    if (cfg_.tdcp_en)
      storeTdcpPrev(state_prop, msg, enu_R_world, enu_t_world, lever_body);
    return false;
  }
  const Eigen::VectorXd S_inv_r = ldlt.solve(r);
  const double gamma = r.dot(S_inv_r);
  const double gate = (cfg_.gate_chi2 > 0.0) ? cfg_.gate_chi2
                                             : chi2Threshold95(m_obs);
  health_.gamma = gamma;
  health_.gate = gate;
  ++evaluated_;
  if (!(gamma <= gate))
  {
    ++rejected_;
    coarse_good_s_ = 0.0;
    fixed_settle_good_s_ = 0.0;
    health_.coarse_acq = coarse_acq_;
    if (cfg_.verbose && (cfg_.health_every_n <= 0 || evaluated_ % cfg_.health_every_n == 0))
      printf("[RTK] reject t=%.2f pairs=%d fixed=%d amb=%d slips=%d gamma=%.1f gate=%.1f "
             "|r_code|=%.2f |r_phase|=%.2f rej_code=%d rej_phase=%d "
             "tdcp=%d tdcp_rms=%.2f\n",
             msg.header.stamp.toSec(), n, n_fixed, n_amb, phase_slips, gamma, gate,
             std::sqrt(code_sq / n), std::sqrt(phase_sq / n), rej_code, rej_phase,
             health_.n_tdcp, health_.tdcp_rms);
    fflush(stdout);
    if (cfg_.tdcp_en)
      storeTdcpPrev(state_prop, msg, enu_R_world, enu_t_world, lever_body);
    return false;
  }

  const Eigen::MatrixXd S_inv =
      ldlt.solve(Eigen::MatrixXd::Identity(m_obs, m_obs));
  const Eigen::Matrix<double, DIM_STATE, Eigen::Dynamic> K_x =
      P_use * H_meas.transpose() * S_inv;
  const Eigen::MatrixXd K_a = P_amb_ * H_a.transpose() * S_inv;

  dx = K_x * r;
  Eigen::VectorXd da = K_a * r;

  if (cfg_.max_corr > 0.0 && !coarse_acq_)
  {
    const double dpos = dx.segment<3>(3).norm();
    if (dpos > cfg_.max_corr)
    {
      // R1: a clamped correction and a full-gain Joseph update are mutually
      // inconsistent (the covariance would claim a correction the state never
      // received).  Reject the epoch instead and roll the ambiguity states back
      // to their pre-epoch values; coarse acquisition keeps its explicit bypass
      // above so the initial metre-level offset can still be removed.
      amb_ = amb_before;
      P_amb_ = P_amb_before;
      index_ = index_before;
      ++rejected_;
      coarse_good_s_ = 0.0;
      fixed_settle_good_s_ = 0.0;
      health_.accepted = false;
      health_.coarse_acq = coarse_acq_;
      if (cfg_.verbose)
        printf("[RTK] reject t=%.2f |dx_pos|=%.2f > max_corr=%.2f (not applied)\n",
               msg.header.stamp.toSec(), dpos, cfg_.max_corr);
      fflush(stdout);
      return false;
    }
  }

  amb_ += da;

  const Eigen::Matrix<double, DIM_STATE, DIM_STATE> I_KH =
      Eigen::Matrix<double, DIM_STATE, DIM_STATE>::Identity() - K_x * H_meas;
  P_new = I_KH * P_use * I_KH.transpose() + K_x * R_eff * K_x.transpose();
  P_new = 0.5 * (P_new + P_new.transpose());

  P_amb_ = P_amb_ - K_a * S * K_a.transpose();
  P_amb_ = 0.5 * (P_amb_ + P_amb_.transpose());
  // Keep the ambiguity block positive definite: the block-diagonal
  // approximation can leave tiny negative eigenvalues after many updates.
  Eigen::SelfAdjointEigenSolver<Eigen::MatrixXd> es(P_amb_);
  if (es.info() == Eigen::Success)
  {
    Eigen::VectorXd ev = es.eigenvalues().cwiseMax(1e-9);
    P_amb_ = es.eigenvectors() * ev.asDiagonal() * es.eigenvectors().transpose();
    P_amb_ = 0.5 * (P_amb_ + P_amb_.transpose());
  }

  // ---- TDCP: time-differenced DD phase relative update -------------------
  // Sequential second update after the code/phase posterior. The previous
  // posterior is the fixed anchor; r = y - g . (p_cur - p_prev), with
  // y = dPhi_dd - d(rho_dd). The ambiguity cancels over a clean interval.
  int n_tdcp_used = 0;
  double tdcp_sq = 0.0;
  if (cfg_.tdcp_en && have_tdcp_prev_)
  {
    const double tdcp_dt = t_now - last_tdcp_t_;
    if (tdcp_dt > 0.2 && tdcp_dt <= cfg_.tdcp_max_dt)
    {
      StatesGroup post = state_prop;
      post += dx;
      const V3D lever_world_post = post.rot_end * lever_body;
      V3D p_ant_world_post = post.pos_end + lever_world_post;
      if (use_scale_)
      {
        p_ant_world_post(0) = post.scale_h * post.pos_end(0) + lever_world_post(0);
        p_ant_world_post(1) = post.scale_h * post.pos_end(1) + lever_world_post(1);
      }
      const V3D p_post_enu =
          enu_R_world.transpose() * (p_ant_world_post - enu_t_world) - base_enu_neg_;

      std::vector<Eigen::Matrix<double, 1, DIM_STATE>,
                  Eigen::aligned_allocator<Eigen::Matrix<double, 1, DIM_STATE>>>
          H_rows;
      std::vector<double> res, sig;
      for (int i = 0; i < n; ++i)
      {
        AmbKey key;
        key.sys = msg.sys[i];
        key.freq = msg.freq[i];
        key.sat = msg.sat[i];
        key.ref = msg.ref_sat[i];
        auto it = tdcp_prev_.find(key);
        if (it == tdcp_prev_.end()) continue;
        if (msg.slip[i] || msg.ref_change[i]) continue;
        const TdcpPrev &pr = it->second;
        if (pr.elev_min > 0.0 && pr.elev_min < 5.0) continue;

        const Eigen::Vector3d sat_ecef(msg.sat_x[i], msg.sat_y[i], msg.sat_z[i]);
        const Eigen::Vector3d ref_ecef(msg.ref_x[i], msg.ref_y[i], msg.ref_z[i]);
        const Eigen::Vector3d sat_enu_u = R_enu_base * (sat_ecef - cfg_.base_ecef);
        const Eigen::Vector3d ref_enu_u = R_enu_base * (ref_ecef - cfg_.base_ecef);
        const V3D sat_enu(sat_enu_u(0), sat_enu_u(1), -sat_enu_u(2));
        const V3D ref_enu(ref_enu_u(0), ref_enu_u(1), -ref_enu_u(2));
        // y already subtracts the ACTUAL DD geometry change between the two
        // posteriors. The residual is y itself; the Jacobian is the
        // current-epoch DD geometry derivative. Subtracting g.dp again would
        // double-count the geometry change (this was the tdcp_rms 3-4 m bug).
        const Eigen::Matrix<double, 1, 3> H_dd =
            fast_livo::ddGeometryJacobian(p_post_enu, sat_enu, ref_enu);
        const V3D g = H_dd.transpose();
        const double dd_geom_cur =
            fast_livo::ddGeometry(p_post_enu, sat_enu, ref_enu) -
            (sat_enu.norm() - ref_enu.norm());
        const double y =
            msg.dd_phase[i] - pr.phase - (dd_geom_cur - pr.dd_geom);
        const double r_t = y;

        const Eigen::Matrix<double, 1, 3> H_pos =
            g.transpose() * enu_R_world.transpose();
        const Eigen::Matrix<double, 1, 3> H_att =
            fast_livo::leverArmAttitudeJacobian(H_pos, post.rot_end, lever_body);
        Eigen::Matrix<double, 1, DIM_STATE> H_row =
            Eigen::Matrix<double, 1, DIM_STATE>::Zero();
        H_row.block<1, 3>(0, 0) = H_att;
        Eigen::Matrix<double, 1, 3> H_pos_lio = H_pos;
        if (use_scale_)
        {
          H_pos_lio(0, 0) *= post.scale_h;
          H_pos_lio(0, 1) *= post.scale_h;
          H_row(0, 19) = H_pos(0, 0) * post.pos_end(0) +
                         H_pos(0, 1) * post.pos_end(1);
        }
        H_row.block<1, 3>(0, 3) = H_pos_lio;

        const double sp = std::max(msg.sigma_phase[i], 1e-3);
        const double sigma = cfg_.tdcp_sigma_scale *
                             std::sqrt(2.0 * sp * sp +
                                       cfg_.tdcp_prev_sigma * cfg_.tdcp_prev_sigma);
        H_rows.push_back(H_row);
        res.push_back(r_t);
        sig.push_back(sigma);
      }

      if (static_cast<int>(H_rows.size()) >= cfg_.tdcp_min_pairs)
      {
        const int k = static_cast<int>(H_rows.size());
        Eigen::MatrixXd H_t(k, DIM_STATE);
        Eigen::VectorXd r_t(k);
        Eigen::MatrixXd R_t = Eigen::MatrixXd::Zero(k, k);
        for (int j = 0; j < k; ++j)
        {
          H_t.row(j) = H_rows[j];
          r_t(j) = res[j];
          R_t(j, j) = sig[j] * sig[j];
        }
        Eigen::MatrixXd S_t = H_t * P_new * H_t.transpose() + R_t;
        S_t = 0.5 * (S_t + S_t.transpose());
        if (cfg_.tdcp_robust_en)
        {
          for (int j = 0; j < k; ++j)
          {
            const double s_ii = std::max(S_t(j, j), 1e-12);
            const double u = std::fabs(r_t(j)) / std::sqrt(s_ii);
            const double w =
                igg3Weight(u, cfg_.tdcp_robust_k0, cfg_.tdcp_robust_k1);
            if (w <= 0.0) R_t(j, j) = 1e12;
            else R_t(j, j) = sig[j] * sig[j] / w;
          }
          S_t = H_t * P_new * H_t.transpose() + R_t;
          S_t = 0.5 * (S_t + S_t.transpose());
        }
        Eigen::LDLT<Eigen::MatrixXd> ldlt_t(S_t);
        if (ldlt_t.info() == Eigen::Success)
        {
          const double gamma_t = r_t.dot(ldlt_t.solve(r_t));
          const double gate_t = chi2Threshold95(k);
          if (gamma_t <= gate_t)
          {
            const Eigen::MatrixXd S_inv_t =
                ldlt_t.solve(Eigen::MatrixXd::Identity(k, k));
            const Eigen::Matrix<double, DIM_STATE, Eigen::Dynamic> K_t =
                P_new * H_t.transpose() * S_inv_t;
            const Eigen::Matrix<double, DIM_STATE, 1> dx_t = K_t * r_t;
            const Eigen::Matrix<double, DIM_STATE, DIM_STATE> I_KH_t =
                Eigen::Matrix<double, DIM_STATE, DIM_STATE>::Identity() -
                K_t * H_t;
            P_new = I_KH_t * P_new * I_KH_t.transpose() +
                    K_t * R_t * K_t.transpose();
            P_new = 0.5 * (P_new + P_new.transpose());
            dx += dx_t;
            n_tdcp_used = k;
            tdcp_sq = r_t.squaredNorm();
          }
        }
      }
    }
  }
  health_.n_tdcp = n_tdcp_used;
  health_.tdcp_rms =
      n_tdcp_used > 0 ? std::sqrt(tdcp_sq / std::max(1, n_tdcp_used)) : 0.0;

  // Anchor the next TDCP interval at the final posterior (DD + TDCP).
  if (cfg_.tdcp_en)
  {
    StatesGroup post = state_prop;
    post += dx;
    storeTdcpPrev(post, msg, enu_R_world, enu_t_world, lever_body);
  }

  ++accepted_;
  health_.accepted = true;
  last_t_ = msg.header.stamp.toSec();

  if (cfg_.fixed_settle_en && !fixed_settled_ && fixed_phase_n > 0)
  {
    if (fixed_phase_rms <= cfg_.fixed_settle_rms)
      fixed_settle_good_s_ += dt;
    else
      fixed_settle_good_s_ = 0.0;
    if (fixed_settle_good_s_ >= cfg_.fixed_settle_s)
    {
      fixed_settled_ = true;
      printf("[RTK] fixed phase settled t=%.2f phase_rms=%.2f "
             "(loose gate kept %.1f s)\n", last_t_, fixed_phase_rms,
             fixed_settle_good_s_);
      fflush(stdout);
    }
  }

  if (coarse_acq_)
  {
    if (code_rms <= cfg_.coarse_acq_exit_code_rms)
      coarse_good_s_ += dt;
    else
      coarse_good_s_ = 0.0;
    if (coarse_good_s_ >= cfg_.coarse_acq_exit_s)
    {
      coarse_acq_ = false;
      coarse_done_ = true;
      printf("[RTK] coarse acquisition done t=%.2f code_rms=%.2f "
             "(kept %.1f s)\n", last_t_, code_rms, coarse_good_s_);
      fflush(stdout);
    }
  }
  health_.coarse_acq = coarse_acq_;
  if (cfg_.verbose && (cfg_.health_every_n <= 0 || evaluated_ % cfg_.health_every_n == 0))
  {
    printf("[RTK] accept t=%.2f pairs=%d fixed=%d amb=%d slips=%d gamma=%.1f/%.1f "
           "|r_code|=%.2f |r_phase|=%.2f |dx_pos|=%.3f P_pos=%.3f rej_code=%d rej_phase=%d "
           "tdcp=%d tdcp_rms=%.2f\n",
           last_t_, n, n_fixed, n_amb, phase_slips, gamma, gate, std::sqrt(code_sq / n),
           std::sqrt(phase_sq / n), dx.segment<3>(3).norm(),
           std::sqrt(P_new.block<3, 3>(3, 3).diagonal().maxCoeff()), rej_code, rej_phase,
           health_.n_tdcp, health_.tdcp_rms);
    fflush(stdout);
  }
  return true;
}
