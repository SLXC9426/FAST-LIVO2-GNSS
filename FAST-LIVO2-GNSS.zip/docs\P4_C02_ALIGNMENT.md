# P4: campus-02 对齐诊断

## 结论

campus-02 的 DD 数据本身是正确的，问题不在基站、时间戳或 DD 生成链，而在
**LIO 轨迹的尺度/漂移**：

- 用 GREAT-MSF `.ins` 的位置反算 DD 几何，`dd_code - geom` 在抽查的 10 个
  历元上只有 0.11–0.75 m，说明 DD CSV、基站 ECEF、卫星坐标都一致；
- 同一时段 LIO 与 GNSS 的位移尺度差约 8.6%（GNSS span 151.5 m，
  LIO span 138.4 m），绝对 yaw 拟合在多次运行间从 -14.7° 变到 +3.2°；
- 相对位移拟合（translation-free）给出的 yaw 稳定在 2–5°，scale 约
  1.01–1.09，说明 LIO 短基线形状可用，但绝对尺度/长时漂移不可用；
- 当前 RTK 紧组合在 c02 上只能“追”漂移：固定相位每个历元拉 1 m，
  LIO 下一秒又漂回 1–2 m，`|r_code|` 长期停在 7–12 m，无法收敛。

因此，c02 的 DD 紧组合不是监督器阈值问题，也不应继续靠调
`max_corr`/`sigma_code_min` 解决；需要 LIO 尺度校正，或在滤波器中增加
尺度/速度误差状态。

## 验证过程

### 1. DD 数据与 `.ins` 的一致性

对 `c02_dd_greatmsf.csv` 的前 10 个有 `.ins` 覆盖的历元，用 `.ins` 的 ECEF
位置按 `dd_geom = (|sat-r|-|sat-b|) - (|ref-r|-|ref-b|)` 重算：

| t_unix | 卫星/参考 | dd_code | dd_geom | 残差 |
|---|---|---|---|---|
| 1603765473 | G02/G13 | 164.736 | 164.622 | +0.114 |
| 1603765500 | G02/G13 | 190.820 | 190.698 | +0.122 |
| 1603765520 | G02/G13 | 238.136 | 237.389 | +0.747 |
| 1603765580 | G05/G02 | -1006.017 | -1006.392 | +0.375 |
| 1603765640 | G02/G13 | 159.918 | 159.496 | +0.422 |

结论：DD 数据链无误，LIO/RTK 的残差来自状态位置本身。

### 2. 绝对对齐 vs 相对对齐

c02 第一次 DD 尝试（`p2_c02_300`）：

```
[GNSS] Frame alignment LOCKED (FORCED)
  samples = 146, GNSS span = 151.508 m, LIO span = 138.405 m
  yaw_offset = -14.6719 deg
  horizontal fit residual RMS = 1.038 m
[RTK] accept t=1603765473.00 ... |r_code|=25.81 |dx_pos|=0.405
```

之后 `|r_code|` 从 25.8 m 增长到 43 m，固定相位 `|r_phase|` 同步增大，
大量历元被卡方门拒绝。

同一份数据改为自动/强制相对对齐后（`align_relative_en`）：

```
[GNSS] align-rel: yaw=4.565 deg scale=1.013 rel_resid=1.354 m abs_resid=7.530 m
[GNSS] Frame alignment LOCKED (2D Procrustes, robust refit, relative)
  yaw_offset = 4.56546 deg
[RTK] accept t=1603765472.00 ... |r_code|=6.47 |dx_pos|=0.123
```

首个 DD 残差从 25.8 m 降到 6.5 m，说明相对 yaw 明显更接近真实值；但随后
残差仍以约 1–2 m/s 的速度增长，固定相位残差很快到 10–18 m，滤波器只能
持续拉 1 m/历元，无法把 offset 消掉。

### 3. 强代码锚测试

把 `sigma_code_min` 从 20 m 降到 1 m，让 DD code 有足够增益：

```
[RTK] accept ... |r_code|=9.85 |dx_pos|=2.167  (每历元拉 2 m)
[RTK] reject ... gamma=421.2 gate=43.8 |r_code|=12.11
```

前几秒确实拉动了 2 m/历元，但 LIO 漂移同量级，残差保持在 10–12 m；随后
卡方门因 code sigma 变小而拒绝几乎所有历元（接受率 10.9%）。这说明只改
code 权重不能解决尺度漂移。

## 结果对比

| 运行 | full 3D | steady 3D | static-loc 2D | accept | 说明 |
|---|---|---|---|---|---|
| LIO（`rerun4_c02_livo`） | 7.6049 | 2.7003 | 0.0114 | - | 无融合 |
| 位置域（`p2_c02_pos_300`） | 9.3645 | 0.9013 | 0.0084 | - | 当前最佳 full/static |
| 位置域自适应（`p2_adapt2_c02_pos_300`） | 9.6414 | 0.9821 | 0.0092 | - | P2 记录 |
| DD + 绝对对齐（`p4_c02_dd_rel`） | 10.0770 | 0.9355 | 0.0101 | 93.3% | 首个 r_code 7.6 m，仍漂移 |
| DD + 相对对齐 + 强 code（`p4_c02_dd_code`） | 9.8490 | 0.9711 | 0.0086 | 10.9% | 前几秒拉动 2 m，后拒绝 |

DD 运行的 steady 与位置域同水平（0.94–0.97 vs 0.90），full 反而更差
（10.0–10.1 vs 9.36），没有形成稳定增益。

## 代码改动

- `tryAlignGnssYaw` 增加自动相对对齐：绝对拟合残差超过门限、而相对拟合
  残差在门限内时，使用相对 yaw/translation，并用 `rel_resid` 过 gate。
  这样不需要为 c02 单独设置阈值；c02 的绝对残差 1.4 m 未触发该分支，
  需要显式 `gnss/align_relative_en: true` 才会走相对对齐。
- 实验配置（非正式配置）：
  `config/experiments/great_campus02_p2_rel.yaml`（相对对齐 + `max_corr=0`）、
  `great_campus02_p2_code.yaml`（相对对齐 + `sigma_code_min=1`）、
  `great_campus02_p2_nocorr.yaml`（绝对对齐 + `max_corr=0`）。

## 后续选项

1. **LIO 尺度校正**：在 LiDAR 前端或 ESKF 中估计尺度因子（例如把
   `align-rel` 的 scale 作为状态/常量补偿），这是让 c02 DD 收敛的根本办法。
2. **速度/尺度状态**：在 19 维 ESKF 中增加尺度或速度偏置状态，使位置更新
   能修正 LIO 的 1–2 m/s 漂移。
3. **接受 c02 位置域回退**：当前 `p2_c02_pos_300` 的 full 9.36、steady 0.90、
   static 0.0084 是可用的基线；c02 DD 暂不纳入验收。
4. 在解决 LIO 尺度前，不建议继续调整 `max_corr`/`sigma_code_min`，那只会
   在“拉得动”和“被卡方拒绝”之间摆动。
