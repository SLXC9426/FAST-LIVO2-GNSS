/*
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with a sliding-window factor-graph backend (Improvement 2).

The frontend iEKF (fast, low latency) stays unchanged as the real-time
estimator. This module runs a separate optimizer thread that maintains a
sliding window of the last `window_size` keyframe poses + velocities and
optimizes them over:

  - IMU pre-integration factors (Forster/VINS-style, with bias Jacobians and
    first-order bias correction), using the raw IMU stream;
  - LiDAR odometry relative-pose factors between consecutive keyframes
    (from the frontend output);
  - GNSS position factors (optional, LIVO_GNSS mode), antenna lever arm
    included.

The oldest keyframe is marginalized by a Schur-complement prior (or simply
dropped when `marginalize=false`). The module is self-contained (Eigen only,
no ROS types) so the math can be validated numerically by the companion
script scripts/sim/sim_filter_compare.py.
*/

#ifndef FACTOR_GRAPH_H_
#define FACTOR_GRAPH_H_

#include <Eigen/Dense>
#include <atomic>
#include <condition_variable>
#include <deque>
#include <mutex>
#include <thread>
#include <tuple>
#include <vector>

namespace fast_livo
{

struct ImuSample
{
  double t;
  Eigen::Vector3d acc;
  Eigen::Vector3d gyr;
};

struct GraphKeyframe
{
  double stamp;
  double push_wt = 0.0;  // R4-5: wallTime() at enqueue (latency reference clock)
  Eigen::Matrix3d R;     // frontend rotation at the keyframe (world)
  Eigen::Vector3d p;     // frontend position (world)
  Eigen::Vector3d v;     // frontend velocity (world)
  Eigen::Vector3d gravity = Eigen::Vector3d(0, 0, 9.81); // world-frame gravity at the keyframe
  Eigen::Matrix3d R_rel; // relative rotation to the previous keyframe (frontend)
  Eigen::Vector3d p_rel; // relative translation to the previous keyframe
  bool have_gnss;
  Eigen::Vector3d gnss_pos; // antenna position in ENU (U negated to match world Z-down)
  double gnss_sigma;
};

struct GraphConfig
{
  bool en = false;
  int window_size = 25;         // number of poses in the sliding window
  double kf_dist = 1.0;         // keyframe distance threshold (m)
  double kf_rot_deg = 10.0;     // keyframe rotation threshold (deg)
  int kf_min_frames = 10;       // force a keyframe every N frames
  double odom_rot_sigma = 0.01; // rad
  double odom_pos_sigma = 0.05; // m
  double imu_gyr_sigma = 0.02;  // rad/s / sqrt(Hz)
  double imu_acc_sigma = 0.5;   // m/s^2 / sqrt(Hz)
  double imu_bg_sigma = 0.0001; // rad/s^2 / sqrt(Hz)
  double imu_ba_sigma = 0.0005; // m/s^3 / sqrt(Hz)
  bool marginalize = true;      // Schur-complement marginalization of the oldest keyframe
  bool gnss_en = true;          // attach GNSS position factors
  double gnss_pos_sigma = 0.5;  // m
  bool robust_en = true;        // Huber re-weighting of factor residuals
  double robust_delta = 1.5;    // Huber scale (Mahalanobis units)
  bool thread_en = true;        // run the optimizer on a separate thread
  int max_gn_iter = 8;          // Gauss-Newton iterations per optimization
  int diag_link_every_n = 0;    // P1-1: print the raw per-link factor diagnostics
                                // every N links (0 = off). The drift diagnosis in
                                // EVAL_PROTOCOL 15 was read from these lines.
  double v_prior_weight = 100.0; // P1-1: the per-node velocity anchor (sigma
                                // ~ 0.1 m/s at 100). Configurable because the
                                // third-layer probe hinges on it.
  Eigen::Vector3d lever = Eigen::Vector3d::Zero(); // GNSS antenna lever arm w.r.t. IMU
};

struct GraphStats
{
  double last_opt_time = 0;       // last optimization duration (s)
  double last_queue_latency = 0;  // keyframe wait time in the queue (s)
  double last_output_latency = 0; // data-time to publish-time of the last result (s)
  int window = 0;
  int iters = 0;
  int keyframes_total = 0;
};

struct GraphResult
{
  bool updated = false;
  double stamp = 0;
  Eigen::Matrix3d R;
  Eigen::Vector3d p;
  Eigen::Vector3d v;
};

class FactorGraph
{
public:
  explicit FactorGraph(const GraphConfig &cfg);
  ~FactorGraph();

  void setGravity(const Eigen::Vector3d &g) { gravity_ = g; }
  void pushImu(const ImuSample &imu);
  void pushKeyframe(const GraphKeyframe &kf);
  bool getLatest(GraphResult &out);
  GraphStats getStats();
  void stop();

  // expose the optimization for synchronous use (no thread)
  int optimizeOnce();

  // ---- R3-WP4: the line-search objective -----------------------------------
  // Cost of the current window at the given biases. It must contain EVERY term
  // the A/b system contains; a term present in one and missing from the other
  // makes the Gauss-Newton direction non-descent for the evaluated cost, and the
  // line search then rejects (or wrongly accepts) steps. The three terms that
  // used to be missing were the GNSS position factors, the Schur marginalized
  // prior and the node0 gauge.
  //
  // The node0 gauge is penalised against the linearization point of the CURRENT
  // Gauss-Newton iteration: the A/b assembly adds 1e4*I on node 0 with no b
  // contribution, which penalises only the increment. The caller therefore passes
  // that point explicitly instead of relying on hidden state.
  double stateCost(const Eigen::Vector3d &bg_t, const Eigen::Vector3d &ba_t,
                   const Eigen::Matrix3d &R0_lin, const Eigen::Vector3d &p0_lin,
                   const Eigen::Vector3d &v0_lin) const;

  // ---- R3-WP5: the parallel-array invariant --------------------------------
  // window_, preints_, kf_rel_R_, kf_rel_p_ and node_gnss_ are indexed by the
  // same node index and must always have the same length. The marginalize=false
  // path used to slide only window_, which silently re-attached every factor to
  // the wrong node. Exposed so the self-test can assert it after the window slid.
  bool sideArraysConsistent() const;
  int windowSize() const { return (int)window_.size(); }

private:
  struct Preint
  {
    double dt = 0;
    Eigen::Vector3d bg0 = Eigen::Vector3d::Zero(); // bias used for the integration
    Eigen::Vector3d ba0 = Eigen::Vector3d::Zero();
    Eigen::Matrix3d dR = Eigen::Matrix3d::Identity();
    Eigen::Vector3d dv = Eigen::Vector3d::Zero();
    Eigen::Vector3d dp = Eigen::Vector3d::Zero();
    Eigen::Matrix3d J_R_bg = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d J_v_bg = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d J_v_ba = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d J_p_bg = Eigen::Matrix3d::Zero();
    Eigen::Matrix3d J_p_ba = Eigen::Matrix3d::Zero();
    Eigen::Matrix<double, 9, 9> cov = Eigen::Matrix<double, 9, 9>::Zero();     // [theta, v, p] block
    Eigen::Matrix<double, 15, 15> cov15 = Eigen::Matrix<double, 15, 15>::Zero(); // [theta, v, p, bg, ba]
  };
  struct Node
  {
    double stamp;
    double push_wt = 0.0; // R4-5: wall clock at enqueue, the latency reference
    Eigen::Matrix3d R;
    Eigen::Vector3d p, v;
    Eigen::Vector3d gravity = Eigen::Vector3d(0, 0, 9.81);
    Eigen::Vector3d v_ref = Eigen::Vector3d::Zero(); // frontend velocity (v-prior anchor)
  };
  struct GnssFix
  {
    bool have = false;
    double t = 0;
    Eigen::Vector3d pos = Eigen::Vector3d::Zero();
    double sigma = 1.0;
  };

  Preint preintegrate(double t0, double t1, const Eigen::Vector3d &bg, const Eigen::Vector3d &ba);
  int optimizeWindow();
  void marginalizeOldest(const Eigen::MatrixXd &A, const Eigen::VectorXd &b);
  void threadLoop();
  // Publish the newest optimized pose. Shared by threadLoop() and optimizeOnce()
  // so the two paths cannot drift: optimizeOnce() used to omit it entirely, which
  // left the non-threaded fallback in LIVMapper (optimizeOnce + pollGraphResult)
  // with nothing to publish, i.e. the backend produced no output at all.
  void publishResult(double opt_time, double queue_latency, int used_iters);

  GraphConfig cfg_;
  Eigen::Vector3d gravity_ = Eigen::Vector3d(0, 0, 9.81); // world frame (Z-down)

  std::thread thread_;
  std::mutex mtx_, imu_mtx_, res_mtx_;
  std::condition_variable cv_;
  bool stop_ = false;

  std::deque<GraphKeyframe> kf_queue_;
  // raw IMU ring (~60 s). Guarded by imu_mtx_ - NOT mtx_: pre-integration in
  // the optimize thread used to run while holding mtx_, which blocked the
  // main thread's 200 Hz imu_cbk (pushImu) for the whole pre-integration
  // (~1-100 ms) and corrupted the front-end IMU stream (state divergence
  // observed on GREAT urban-01: position exploded to 1e4-1e5 m in the
  // standstill segment). Sampling under imu_mtx_ and computing unlocked
  // keeps the two threads independent.
  std::deque<ImuSample> imu_ring_;
  std::vector<Node> window_;                                    // optimized keyframes
  std::vector<Preint> preints_;                                 // preint between window_[i-1] and window_[i]
  std::vector<Eigen::Matrix3d> kf_rel_R_;                       // odometry factors: rel rotation window_[i-1]->window_[i]
  std::vector<Eigen::Vector3d> kf_rel_p_;                       // odometry factors: rel translation
  std::vector<GnssFix> node_gnss_;                              // per-node GNSS fix
  Eigen::Vector3d bias_g_ = Eigen::Vector3d::Zero();
  Eigen::Vector3d bias_a_ = Eigen::Vector3d::Zero();
  Eigen::MatrixXd last_A_, last_b_;                             // last normal equations (for marginalization)

  // marginalized prior (Improvement 2): fixed-linearization-point factor on the
  // oldest remaining keyframe pose + biases
  bool have_prior_ = false;
  Eigen::Matrix<double, 15, 15> prior_A_ = Eigen::Matrix<double, 15, 15>::Zero();
  Eigen::Matrix<double, 15, 1> prior_b_ = Eigen::Matrix<double, 15, 1>::Zero();
  Eigen::Matrix3d prior_R0_ = Eigen::Matrix3d::Identity();
  Eigen::Vector3d prior_p0_ = Eigen::Vector3d::Zero();
  Eigen::Vector3d prior_v0_ = Eigen::Vector3d::Zero();
  Eigen::Vector3d prior_bg_ = Eigen::Vector3d::Zero();
  Eigen::Vector3d prior_ba_ = Eigen::Vector3d::Zero();

  bool have_result_ = false;
  GraphResult result_;
  GraphStats stats_;
  long diag_count_ = 0; // P1-1: link counter for the per-link diagnostics
  // P1-1 third layer: the PUSHED pose/velocity/rotation of the previous keyframe.
  // The node copies of these get optimized, so the fresh-link decomposition
  // (dp_front vs dp_imu vs v_k*dt) needs the pre-optimization values.
  Eigen::Vector3d prev_pushed_p_ = Eigen::Vector3d::Zero();
  Eigen::Vector3d prev_pushed_v_ = Eigen::Vector3d::Zero();
  Eigen::Matrix3d prev_pushed_R_ = Eigen::Matrix3d::Identity();
  bool prev_pushed_valid_ = false;
};

// ---------- small SO(3) helpers (Rodrigues), Eigen-only ----------
namespace fg_so3
{
inline Eigen::Matrix3d hat(const Eigen::Vector3d &v)
{
  Eigen::Matrix3d m;
  m << 0, -v(2), v(1), v(2), 0, -v(0), -v(1), v(0), 0;
  return m;
}
inline Eigen::Matrix3d Exp(const Eigen::Vector3d &phi)
{
  const double theta = phi.norm();
  if (theta < 1e-12) { return Eigen::Matrix3d::Identity(); }
  const Eigen::Vector3d u = phi / theta;
  const double ct = std::cos(theta), st = std::sin(theta);
  return ct * Eigen::Matrix3d::Identity() + (1.0 - ct) * u * u.transpose() + st * hat(u);
}
inline Eigen::Vector3d Log(const Eigen::Matrix3d &R)
{
  // w = (R21-R12, R02-R20, R10-R01) = 2*sin(theta)*axis.
  // Robust form: theta from the clamped trace, direction from w. The old
  // "small angle" test used |w|/2 ~ sin(theta) which also fired near pi
  // (sin(pi-eps) ~ eps), returning ~0 for 180 deg rotations.
  const Eigen::Vector3d w(R(2, 1) - R(1, 2), R(0, 2) - R(2, 0), R(1, 0) - R(0, 1));
  const double wn = w.norm();
  const double cos_theta = std::min(1.0, std::max(-1.0, 0.5 * (R.trace() - 1.0)));
  const double theta = std::acos(cos_theta);
  if (theta < 1e-9) { return Eigen::Vector3d::Zero(); }
  if (wn < 1e-12) { return M_PI * Eigen::Vector3d::UnitX() * (theta > M_PI_2 ? 1.0 : 0.0); }  // near-pi fallback
  if (theta > M_PI - 1e-6) { return theta * w / wn; }   // near-pi: direction from w
  if (theta < 1e-4) { return 0.5 * w; }                 // small angle
  return theta / (2.0 * std::sin(theta)) * w;
}
// right Jacobian J_r(phi) and its inverse
inline Eigen::Matrix3d rightJacobian(const Eigen::Vector3d &phi)
{
  const double theta = phi.norm();
  if (theta < 1e-12) { return Eigen::Matrix3d::Identity(); }
  const Eigen::Matrix3d w = hat(phi);
  const double ct = std::cos(theta), st = std::sin(theta);
  return Eigen::Matrix3d::Identity() - (1.0 - ct) / (theta * theta) * w + (theta - st) / (theta * theta * theta) * w * w;
}
inline Eigen::Matrix3d inverseRightJacobian(const Eigen::Vector3d &phi)
{
  const double theta = phi.norm();
  if (theta < 1e-12) { return Eigen::Matrix3d::Identity(); }
  const Eigen::Matrix3d w = hat(phi);
  const double ct = std::cos(theta);
  return Eigen::Matrix3d::Identity() + 0.5 * w +
         (1.0 / (theta * theta) - (1.0 + ct) / (2.0 * theta * std::sin(theta))) * w * w;
}
} // namespace fg_so3

} // namespace fast_livo

#endif // FACTOR_GRAPH_H_
