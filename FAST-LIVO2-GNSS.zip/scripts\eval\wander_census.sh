#!/bin/bash
# T2-0: static wander census on c02 pure LIVO (改进方案 Tier-2 前置).
#
# Question the census answers: what FRACTION of runs exhibits the static-plane
# walk? The walk is bimodal across runs (measured: clean runs 0.007-0.013 m,
# walked runs 30 m/100 s), so any freeze/soft-constraint design (T2-1 ZUPT
# re-arm, T2-2 soft zero-displacement) buys accuracy proportional to that
# fraction. Decision rule from the plan: low fraction -> do NOT build T2-1/T2-2
# (benefit would be diluted by the appearance rate); high fraction -> pick
# T2-2 (EKF soft constraint) over T2-1.
#
# Pipeline: full_floor_run.sh (N full-length pure-LIVO runs, binary hash
# recorded) -> static_displacement.py --batch (self-displacement per run in
# reference-static segments) -> verdict.py single-group distribution.
#
# Usage: wander_census.sh [repeats=5] [summary]
export LANG=C.UTF-8
N=${1:-5}
SUM=${2:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/t2_0_census/census_summary.txt}
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$(dirname "$SUM")"

bash "$HERE/full_floor_run.sh" campus02 "livo" "$N" "$SUM"

# Census on the runs just produced (they accumulate in Log/result under the
# <seq>_floor_livo_r<k> tags; each was also appended to registry.csv).
RES=$HOME/catkin_ws/src/fast_livo/Log/result
REF=$HOME/eval_great/campus02_reference.tum
{
  echo ""
  echo "=== T2-0 wander census (wander = net/max-excursion > 0.5 m in any ref-static seg) ==="
  python3 "$HERE/static_displacement.py" --ref "$REF" "$RES"/campus02_floor_livo_r*.txt 2>&1
  echo ""
  echo "decision rule (改进方案 T2-0): appeared-fraction decides whether T2-1/T2-2 are built;"
  echo "a fraction near 0 => do NOT build (diluted benefit), a high fraction => prefer T2-2 over T2-1."
} | tee -a "$SUM"

echo "T2_0_CENSUS_DONE" | tee -a "$SUM"
