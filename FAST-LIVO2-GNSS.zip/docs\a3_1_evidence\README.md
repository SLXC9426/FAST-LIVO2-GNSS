# A3.1 静态锚有效性门（设计）

> 分支：`feat/a3.1-static-anchor-validity`（从 `a3-baseline` / `eb64f4f` 创建）
> 默认关闭；关闭时图输出必须与 A2 冻结版本逐字节一致。
> 本阶段只决定“是否允许插入既有静态锚因子”，不估计新锚、不改锚噪声、不改 A2 门控。

## 1. 职责边界

A3.1 在“静态段识别 + 候选 RTK 样本收集”之后、`add_abs()` 之前执行：

1. 用现有静态检测得到候选 run（阈值、中心窗口、run 合并均不变）；
2. 用现有唯一最近邻关联与 `fix_quality_ok()` 得到候选样本；
3. 对候选样本做**基于 fix 时间戳**的两端裁剪；
4. 统计 Fixed 比例、RTK 净位移、P95、最大偏离、稳健 σ、慢漂移；
5. 输出 `VALID` / `WEAK` / `UNAVAILABLE` 和逐段诊断；
6. 只有 `VALID` 才保留原来的 `has_anchor`，即仍用原 `medianVec()` 锚和原 `sig_anchor` 插入；
7. `WEAK` / `UNAVAILABLE` 将 `has_anchor=false`，不插入该静态锚因子。

`gap`（锚与 LIO 中值距离）不参与 A3.1 判定。

若首个 run 被拒绝，`has_anchor=false` 会触发原有 keyframe 0 的 `p0` 边界先验
（无锚时的既有回退），它不是静态锚因子；其余 run 的拒绝只删除该 run 的锚，
不改 transition 因子或 A1 静态跳过规则。

## 2. 三态语义

| 状态 | 条件 | 行为 |
|---|---|---|
| `STATIC_ANCHOR_VALID` | 有参考运动起点；六个阈值全部配置且全部通过 | 允许插入既有锚 |
| `STATIC_ANCHOR_WEAK` | 无硬失败，但无参考起点，或任一阈值未配置（0） | 不插入锚，保留诊断 |
| `STATIC_ANCHOR_UNAVAILABLE` | 样本不足、Fixed 比例不足、RTK 净位移/P95/最大偏离/慢漂移超限、裁剪窗无效 | 不插入锚，保留 LIO 相对轨迹 |

阈值 0 表示未配置，**不能**被解释为通过；因此 `VALID` 要求六个阈值全部为正。默认配置全部为 0，即使误开开关也不会产生 `VALID` 锚。

## 3. 裁剪

- 起点：`run_start + static_anchor_trim_start_sec`；
- 终点（有参考）：`min(run_end, run_start + reference_onset_sec - trim_end_sec)`；
- 终点（无参考）：`run_end - fallback_end_trim_sec`，状态最高只能是 `WEAK`；
- 选择样本：`fix_time ∈ [start, end]`，不是关键帧时间；
- 诊断同时记录关键帧范围与 fix 范围；
- 裁剪后重新统计，不沿用裁剪前数字。

campus-02 观测：启动 U 向瞬态到 12.0 s 仍为 −1.02 m，13.0 s 回到 −0.09 m；末端最近邻约晚 0.4 s。实验配置先用 `trim_start=13 s`、`trim_end=2 s`、`reference_onset=116.9 s`；这些是数据集参数，不是全局常数。

## 4. 统计口径

- 候选样本：现有 `quality_ok()` 通过的样本（与原锚输入一致）；
- Fixed：分类器的 `FIXED` + `GOOD`（载波固定族）；`FLOAT` 单独计数；`UNKNOWN/INVALID/DEGRADED` 计入 other；
  - 语义依据：`gnss_quality.h::classifyGnssQuality()` 只在 `carr_soln >= 2` 且 nsat/PDOP 满足 good 门限时返回 `GOOD`；`carr_soln >= 2` 但几何不满足 good 时返回 `FIXED`。`GnssQuality.msg` 明确 `carr_soln=2` 为 fixed，`gnss_quality_classifier_selftest` 有 "fixed + good geometry -> GOOD" 用例。`GOOD` 不是独立的非固定类别，`FIXED ∪ GOOD` = 载波固定族。
- 统计只在裁剪后的 Fixed 样本上计算：
  - 中心：逐轴中值；
  - 净位移：按 fix 时间排序后首末样本的 `q` 距离；
  - P95/最大偏离：各样本 `q` 到中心的欧氏距离；
  - 稳健 σ：`1.4826 * median(|d − median(d)|)`；
  - 慢漂移：对 `q(t)` 做最小二乘直线拟合，`||slope|| * (t_max − t_min)`；
  - LIO 净位移：裁剪后样本按关键帧时间排序的首末 LIO 位置距离（诊断用）；
- `q = p_fix − Rz·R_lio·lever`，与现有锚输入一致。
- 结果字段/CSV 仍用历史名 `rtk_*`；语义是 **candidate q**（关联、杆臂补偿后的候选锚观测），不是原始 RTK 位置漂移。报告统一称 `candidate_q_*`。

注意：A3 基线报告的 0.878 m 是**全部原始 fix** 的端点净位移；本模块的
`rtk_net_displacement` / `rtk_slow_drift` 使用**关联到关键帧、通过 quality_ok、
且裁剪后的候选 q**。两者口径不同，不能把 0.878 m 直接当作候选锚样本的漂移，
也不能用它直接设 `max_slow_drift`。c02 实测候选 q 的 net 为 0.0977 m、
slow 为 0.1457 m，而基线稳定核 P95（0.114 m）与门的 P95（0.1136 m）一致。

## 5. 配置

| 参数 | 默认 | 含义 |
|---|---:|---|
| `static_anchor_validity_en` | false | 总开关 |
| `static_anchor_trim_start_sec` | 0.0 | 起点裁剪（s） |
| `static_anchor_trim_end_sec` | 0.0 | 有参考起点时的终点余量（s） |
| `static_anchor_reference_onset_sec` | -1.0 | 参考运动起点，相对候选 run 起点；<0 表示无 |
| `static_anchor_fallback_end_trim_sec` | 2.0 | 无参考时的末端保守裁剪（s） |
| `static_anchor_min_samples` | 0 | 裁剪后样本数下限，0=未配置 |
| `static_anchor_min_fixed_ratio` | 0.0 | Fixed 比例下限，0=未配置 |
| `static_anchor_max_rtk_net_displacement` | 0.0 | 净位移上限，0=未配置 |
| `static_anchor_max_rtk_p95` | 0.0 | P95 上限，0=未配置 |
| `static_anchor_max_rtk_deviation` | 0.0 | 最大偏离上限，0=未配置 |
| `static_anchor_max_slow_drift` | 0.0 | 慢漂移上限，0=未配置 |
| `static_anchor_diagnostics_path` | "" | 逐段 CSV；空=不写 |

## 6. 诊断 CSV

字段：

```
segment_id,raw_start,raw_end,trimmed_start,trimmed_end,trim_basis,
trimmed_kf_start,trimmed_kf_end,trimmed_fix_start,trimmed_fix_end,
raw_sample_count,trimmed_sample_count,fixed_count,good_count,float_count,
other_count,fixed_ratio,rtk_net_displacement,rtk_robust_p95,
rtk_max_deviation,rtk_robust_sigma,rtk_slow_drift,lio_net_displacement,
anchor_validity,reject_reason,reason
```

`raw_*` / `trimmed_*` 时间相对当前解窗首关键帧。每次求解重写该文件（保留最近一次求解的候选段）。

拒绝原因：`INSUFFICIENT_SAMPLES`、`LOW_FIXED_RATIO`、`RTK_DISPLACEMENT_TOO_LARGE`、`RTK_DISPERSION_TOO_LARGE`、`RTK_SLOW_DRIFT`、`TRIMMED_WINDOW_TOO_SHORT`。

## 7. 代码落点

| 文件 | 作用 |
|---|---|
| `include/static_anchor_validity.h` | 参数、样本、结果、三态/原因枚举、纯计算接口 |
| `src/static_anchor_validity.cpp` | 裁剪、分类计数、统计、慢漂移、判定 |
| `include/global_pose_graph.h` | A3.1 开关、参数、诊断路径 |
| `src/global_pose_graph.cpp` | 候选样本收集；门控；`has_anchor` 置否；诊断写出 |
| `src/online_graph_node.cpp` | ROS 参数读取与启动日志 |
| `launch/mapping_great.launch` | 参数入口，默认关闭 |
| `CMakeLists.txt` | 新源文件与自测目标 |
| `test/static_anchor_validity_selftest.cpp` | 合成样本自测 |

## 8. 验收与未做

- 14 个自测全部 PASS（含新增 37 项检查）；
- A3.1 关闭时 c02/c01 全段 TUM 均与 A2.5 同源 A1R **逐字节一致**；
  与旧 c02 A1 的最大位置差 1e-11 m 是 A2.5 重建已知的浮点重排；
- c02 启动段：`STATIC_ANCHOR_VALID`（101 样本，net 0.0977、P95 0.1136、
  max 0.1157、slow 0.1457 m），VALID 的 TUM 与关闭状态逐字节一致；
  强制 `max_slow_drift=0.05` 时 `UNAVAILABLE / RTK_SLOW_DRIFT`，锚被移除；
- c01 启动段：`STATIC_ANCHOR_VALID`（26 样本，net 0.0733、P95 0.0097、
  max 0.0723、slow 0.0161 m），VALID 与关闭状态 TUM 逐字节一致；
- c01 长段（429.5–605.7 s）：Fixed 比例 0.682 < 0.9 → `LOW_FIXED_RATIO`；
  放宽比例到 0.6、`max_slow_drift=0.2` 时 slow 0.380 → `RTK_SLOW_DRIFT`；
  同一 0.2 门限下 26 样本启动段仍 VALID（0.016）；
- c02 启动瞬态反例（0–117.1 s）：max 0.865 > 0.5 → `RTK_DISPERSION_TOO_LARGE`；
- GOOD 语义审计：`GOOD` 是 `carr_soln>=2` 且几何 good 的子类，
  `FIXED` 是 `carr_soln>=2` 但几何不满足 good；`FIXED∪GOOD` 才是载波固定族；
- 未改静态检测、关联、`fix_quality_ok`、A2 门控、锚估计、锚噪声、transition 因子；
- **代码验收通过；阈值跨数据集验收未完成**：c02 用 13 s/80，c01 用 0 s/20，
  统一 trim/最小样本规则尚未建立；A3.1 暂不冻结，A3.2 不开始。
