#ifndef STATIC_ANCHOR_VALIDITY_H_
#define STATIC_ANCHOR_VALIDITY_H_

// A3.1: static-anchor validity gate.
//
// This module is a pure decision function. It answers one question only:
// "does this candidate static run have enough independent RTK evidence to keep
// its existing anchor factor?" It does not estimate an anchor, choose a noise
// model, or create a factor. The caller keeps the legacy anchor estimator and
// simply skips add_abs() when the state is not VALID.
//
// The gate is deliberately independent of the LIO anchor gap: a run can look
// perfectly consistent with LIO and still have a 0.87 m RTK P95 (campus-02),
// so the gap is not evidence of RTK validity.
//
// Trimming is applied to the associated fix timestamps, not to the keyframe
// timestamps. The nearest-fix association can be ~0.4 s late at the end of a
// run; trimming by keyframe time would leave a motion fix inside the window.
// Both the keyframe span and the actual fix span are reported.
//
// Threshold semantics: 0 means "not configured". A run cannot become VALID
// while any of the six thresholds is 0, because an unset threshold is not
// evidence of passing. Such a run is WEAK (no anchor inserted) and the reason
// records which thresholds are missing.

#include <Eigen/Core>
#include <string>
#include <vector>

#include "gnss_quality.h"

namespace fast_livo
{

enum class StaticAnchorValidityState
{
  VALID = 0,      // all configured checks pass; caller may insert the anchor
  WEAK,           // data usable, but certification is incomplete; no anchor
  UNAVAILABLE     // hard check failed or trimmed window has no usable sample
};

enum class StaticAnchorRejectReason
{
  NONE = 0,
  INSUFFICIENT_SAMPLES,
  LOW_FIXED_RATIO,
  RTK_DISPLACEMENT_TOO_LARGE,
  RTK_DISPERSION_TOO_LARGE,
  RTK_SLOW_DRIFT,
  TRIMMED_WINDOW_TOO_SHORT,
  INVALID_CONFIGURATION,
  INVALID_SAMPLE,
  INVALID_STATISTICS
};

const char *staticAnchorValidityStateName(StaticAnchorValidityState s);
const char *staticAnchorRejectReasonName(StaticAnchorRejectReason r);

struct StaticAnchorValidityParams
{
  // Candidate-run trim. The start/end bounds are derived from the run's
  // keyframe times, but they are applied to the associated fix timestamps.
  double trim_start_sec = 0.0;
  double trim_end_sec = 0.0;
  // Reference motion onset, seconds relative to the candidate run's start.
  // < 0 means "no reference onset": fallback_end_trim_sec is used and the run
  // can at best be WEAK, never VALID.
  double reference_onset_sec = -1.0;
  double fallback_end_trim_sec = 2.0;

  // Hard checks. 0 disables the individual check, but a disabled check also
  // makes the run ineligible for VALID (see the header comment).
  int min_samples = 0;
  double min_fixed_ratio = 0.0;
  double max_rtk_net_displacement = 0.0;
  double max_rtk_p95 = 0.0;
  double max_rtk_deviation = 0.0;
  double max_slow_drift = 0.0;
};

struct StaticAnchorSample
{
  double kf_time = 0.0;   // keyframe time (s)
  double fix_time = 0.0;  // associated RTK fix time (s)
  Eigen::Vector3d q = Eigen::Vector3d::Zero();  // p_fix - Rz*R_lio*lever
  Eigen::Vector3d lio_position = Eigen::Vector3d::Zero();  // raw LIO position
  GnssQualityClass quality_class = GnssQualityClass::UNKNOWN;
};

struct StaticAnchorValidityResult
{
  int segment_id = -1;
  // All times below are seconds relative to window_t0, except the actual
  // trimmed keyframe/fix spans which are the selected samples' min/max.
  double raw_start = 0.0;
  double raw_end = 0.0;
  double trimmed_start = 0.0;
  double trimmed_end = 0.0;
  double trimmed_kf_start = 0.0;
  double trimmed_kf_end = 0.0;
  double trimmed_fix_start = 0.0;
  double trimmed_fix_end = 0.0;
  std::string trim_basis;  // reference_onset / fallback_end_trim / invalid_window

  int raw_sample_count = 0;
  int trimmed_sample_count = 0;
  // Carrier-fixed family. GnssQualityClass::GOOD is carr_soln>=2 with good
  // geometry; FIXED is carr_soln>=2 otherwise. GOOD is not an independent
  // non-fixed quality class (see classifyGnssQuality in gnss_quality.h).
  int fixed_count = 0;
  int good_count = 0;
  int float_count = 0;
  int other_count = 0;  // UNKNOWN + INVALID + DEGRADED
  double fixed_ratio = 0.0;

  // Statistics are computed on the carrier-fixed samples inside the trimmed
  // fix-time window. The anchor estimate itself is untouched.
  double rtk_net_displacement = 0.0;
  double rtk_robust_p95 = 0.0;
  double rtk_max_deviation = 0.0;
  double rtk_robust_sigma = 0.0;
  double rtk_slow_drift = 0.0;  // ||linear-fit velocity|| * fix-time span
  double lio_net_displacement = 0.0;

  StaticAnchorValidityState state = StaticAnchorValidityState::UNAVAILABLE;
  StaticAnchorRejectReason reject_reason = StaticAnchorRejectReason::NONE;
  std::string reason;  // weak reason or failing value; never contains commas
  bool reference_onset_available = false;
  bool thresholds_complete = false;
  // A3.2: indices into the caller's `samples` vector for the carrier-fixed
  // selected subset -- the judgment/estimation set. The unified estimator
  // (static_anchor_unified_en) takes its median from exactly these samples;
  // rejected samples must not re-enter the anchor estimate.
  std::vector<int> estimation_indices;
};

// Evaluate one candidate static run.
//
// window_t0: first keyframe time of the current solve window (reporting only)
// run_start/run_end: keyframe times of the candidate run
// samples: the epochs the existing quality gate accepted for this run, in
//          keyframe order. The caller must not include rejected epochs.
StaticAnchorValidityResult evaluateStaticAnchorValidity(
    const StaticAnchorValidityParams &params,
    int segment_id,
    double window_t0,
    double run_start,
    double run_end,
    const std::vector<StaticAnchorSample> &samples);

}  // namespace fast_livo

#endif  // STATIC_ANCHOR_VALIDITY_H_
