#!/usr/bin/env python3
"""Probe official Urban-01.bag: pointcloud fields/ranges, IMU rate & range,
image rate. Run inside WSL where rosbag is available."""
import rosbag
import sensor_msgs.point_cloud2 as pc2
import numpy as np

BAG = "/mnt/d/BaiduNetdiskDownload/Urban-01/Urban-01.bag"
T0 = 1603774014.0

b = rosbag.Bag(BAG)

# ---- pointcloud ----
print("== /points_raw ==")
n = 0
for topic, msg, t in b.read_messages(topics=["/points_raw"], start_time=rosbag.rostime.Time(T0), end_time=rosbag.rostime.Time(T0 + 6)):
    n += 1
    if n > 3:
        break
    print("t:", msg.header.stamp.to_sec(), "frame:", msg.header.frame_id,
          "H:", msg.height, "W:", msg.width, "dense:", msg.is_dense)
    print("  fields:", [(f.name, f.datatype, f.count) for f in msg.fields])
    pts = list(pc2.read_points(msg, field_names=("x", "y", "z", "ring", "time"), skip_nans=True))
    a = np.array(pts[:3000], dtype=float)
    print("  npts:", len(pts), " x:", a[:, 0].min(), a[:, 0].max(),
          " y:", a[:, 1].min(), a[:, 1].max(), " z:", a[:, 2].min(), a[:, 2].max())
    print("  rings:", np.unique(a[:, 3]).tolist()[:24])
    print("  time-field:", a[:, 4].min(), a[:, 4].max())

# ---- IMU ----
print("\n== /imu_raw ==")
tprev = None
dts = []
accs = []
gyrs = []
cnt = 0
for topic, msg, t in b.read_messages(topics=["/imu_raw"], start_time=rosbag.rostime.Time(T0), end_time=rosbag.rostime.Time(T0 + 2)):
    ts = msg.header.stamp.to_sec() if msg.header.stamp.to_sec() != 0 else t.to_sec()
    if tprev is not None:
        dts.append(ts - tprev)
    tprev = ts
    accs.append([msg.linear_acceleration.x, msg.linear_acceleration.y, msg.linear_acceleration.z])
    gyrs.append([msg.angular_velocity.x, msg.angular_velocity.y, msg.angular_velocity.z])
    cnt += 1
a = np.array(accs)
g = np.array(gyrs)
print("count/2s:", cnt, " dt median:", np.median(dts), " dt min:", np.min(dts), " dt max:", np.max(dts))
print("acc mean:", a.mean(0), " acc std:", a.std(0))
print("acc abs max:", np.abs(a).max(), " gyr abs max:", np.abs(g).max())

# ---- image ----
print("\n== /img0_raw ==")
n = 0
tprev = None
dts = []
for topic, msg, t in b.read_messages(topics=["/img0_raw"], start_time=rosbag.rostime.Time(T0), end_time=rosbag.rostime.Time(T0 + 3)):
    ts = t.to_sec()
    if tprev is not None:
        dts.append(ts - tprev)
    tprev = ts
    n += 1
    if n == 1:
        print("encoding:", msg.encoding, " HxW:", msg.height, msg.width, "step:", msg.step)
print("count/3s:", n, " dt median:", np.median(dts) if dts else None)

b.close()
