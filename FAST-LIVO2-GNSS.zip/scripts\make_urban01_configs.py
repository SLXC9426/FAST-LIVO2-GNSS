#!/usr/bin/env python3
"""
make_urban01_configs.py - generate the FAST-LIVO2 mode matrix for
GREAT-Dataset urban-01 (and, with --seq campus-01, for campus-01).

urban-01 was acquired on 2020/10/27, the same day as campus-01, on the same
platform, so the extrinsics/IMU intrinsics from config/great_campus01.yaml
(derived from Sensor_Parameters/2020-10-27) apply directly. Only the sequence
name and the improvement-mode switches differ.

Modes (Log/result/<seq>_<mode>.txt + _graph/_latency/_dyn files):
  baseline      - all improvements OFF (original behaviour)
  occlusion     - P1 only
  dynamic       - P3 only
  graph         - P2 only
  improved      - P1+P2+P3
  improved_gnss - P1+P2+P3 + GNSS (needs GNSS/gnss.pos)
"""

import argparse
import io
import os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")

NEW_SECTIONS = """
# ============================================================
# Improvement 1: occlusion-aware matching & robust kernels (P1)
# ============================================================
occlusion:
  en: {occ}
  margin: 0.5
  behind_eps: 0.3
  vio_en: {vio}
  vio_depth_ratio: 0.5
lio:
  robust_kernel_type: {rk}
  robust_delta: 1.5
  # keep the ORIGINAL gate (1.0 * sigma_num * sigma): a larger gate lets far
  # residuals in on datasets with inflated sigma (e.g. GREAT VLP-16, where
  # dept_err/beam_err are amplified), which degrades the already weak LiDAR
  # matching and drove the occlusion/robust ablation runs to diverge
  reject_gate_scale: 1.0
  # covariance floor: without it, a long standstill (first 150 s of
  # urban-01) collapses the IEKF covariance -> the matching gate shrinks
  # below the motion residual -> ~96% of correspondences rejected when the
  # vehicle starts -> the estimator freezes at the origin (frozen pose)
  min_cov_rot: 1e-6
  min_cov_pos: 1e-3
  min_cov_vel: 1e-3
  min_cov_expo: 1e-4
  min_cov_bias: 1e-8
  min_cov_grav: 1e-6
vio:
  robust_kernel_type: {rk}
  robust_delta: 2.0

# ============================================================
# Improvement 3: dynamic object removal (P3)
# ============================================================
dynamic_remove:
  en: {dyn}
  conflict_thresh: 0.5
  dynamic_ratio: 0.6
  obs_min: 20
  max_idle_frames: 100
  check_interval: 50
  # pub_dyn_en stays false for evaluation runs: the per-frame full-map scan in
  # collectDynamicClouds slows the pipeline below real-time and drops frames;
  # the _dyn.csv statistics are written regardless of publishing
  pub_dyn_en: false

# ============================================================
# Improvement 2: sliding-window factor-graph backend (P2)
# ============================================================
factor_graph:
  en: {fg}
  window_size: 25
  kf_dist: 1.0
  kf_rot_deg: 10.0
  kf_min_frames: 10
  odom_rot_sigma: 0.01
  odom_pos_sigma: 0.05
  imu_gyr_sigma: 0.02
  imu_acc_sigma: 0.5
  imu_bg_sigma: 0.0001
  imu_ba_sigma: 0.0005
  marginalize: true
  gnss_en: {fggnss}
  gnss_pos_sigma: 0.5
  robust_en: true
  robust_delta: 1.5
  thread_en: true
  max_gn_iter: 8
"""


def mode_params(mode):
    """(occ, vio, rk, dyn, fg, fggnss) per mode."""
    base = {"occ": "false", "vio": "false", "rk": 0, "dyn": "false", "fg": "false", "fggnss": "true"}
    if mode == "occlusion":
        return dict(base, occ="true", vio="true", rk=1)
    if mode == "dynamic":
        return dict(base, dyn="true")
    if mode == "graph":
        return dict(base, fg="true")
    if mode == "improved":
        return dict(base, occ="true", vio="true", rk=1, dyn="true", fg="true")
    if mode == "improved_noP1":
        # P2+P3 only: on degraded VLP-16 matching (GREAT), the occlusion ray
        # test and the Huber kernel reject too many of the already-poor
        # correspondences and the estimate degenerates to pure IMU integration
        return dict(base, dyn="true", fg="true")
    if mode == "improved_gnss":
        return dict(base, occ="true", vio="true", rk=1, dyn="true", fg="true", fggnss="true")
    return base  # baseline


def build(seq, mode, base_yaml, camera_yaml, out_cfg, out_launch, toff=0.0):
    with io.open(base_yaml, encoding="utf-8") as f:
        txt = f.read()
    p = mode_params(mode)
    # sequence name and GNSS switch
    txt = txt.replace('seq_name: "great_campus01_gnss"', f'seq_name: "{seq}_{mode}"')
    txt = txt.replace('seq_name: "great_urban01_', f'seq_name: "{seq}_')
    txt = txt.replace("gnss_en: true", f"gnss_en: {('true' if mode == 'improved_gnss' else 'false')}")
    # GREAT rawdata2bag converts the VLP-16 time field to microseconds with the
    # frame stamp at scan start, which matches FAST-LIVO2's assumption
    # (curvature = time/1000 ms). Earlier bag versions recorded scan-END
    # stamps; a -0.1 s lidar_time_offset was once thought necessary, but the
    # ablation on urban-01 showed offsets in [-0.1, +0.05] s change nothing
    # (61.0-61.7 m vs 61.7 m at 0 offset), so no shift is applied.
    txt = txt.replace("\n  lidar_time_offset: ", "\n  lidar_time_offset_old: ")  # idempotent
    txt = txt.replace("img_time_offset: 0.0", f"img_time_offset: 0.0\n  lidar_time_offset: {toff}")
    # latency logging on for every mode
    if "latency_en:" not in txt:
        txt = txt.replace("  pose_output_en: true", "  pose_output_en: true\n  latency_en: true")
    # strip any previously appended improvement sections (idempotent)
    idx = txt.find("# ============================================================\n# Improvement 1:")
    if idx > 0:
        txt = txt[:idx]
    txt += NEW_SECTIONS.format(**p)
    out = os.path.join(ROOT, "config", f"{seq}_{mode}.yaml")
    with io.open(out, "w", encoding="utf-8") as f:
        f.write(txt)
    print("wrote", out)

    # camera params: copy from the source camera yaml (rename comment only)
    with io.open(camera_yaml, encoding="utf-8") as f:
        cam = f.read()
    cam_out = os.path.join(ROOT, "config", f"camera_{seq}.yaml")
    with io.open(cam_out, "w", encoding="utf-8") as f:
        f.write(cam)
    print("wrote", cam_out)

    # launch file
    launch = f"""<launch>
<!-- Launch FAST-LIVO2 on GREAT-Dataset {seq} (mode matrix)
     Usage: roslaunch fast_livo mapping_great_{seq}.launch mode:=improved rviz:=false
     mode in: baseline occlusion dynamic graph improved improved_gnss -->
\t<arg name="rviz" default="false" />
\t<arg name="mode" default="improved" />
\t<arg name="seq_name" default="{seq}_$(arg mode)" />

\t<rosparam command="load" file="$(find fast_livo)/config/{seq}_$(arg mode).yaml" />
\t<param name="evo/seq_name" value="$(arg seq_name)" />

\t<node pkg="fast_livo" type="fastlivo_mapping" name="laserMapping" output="screen">
\t\t<rosparam file="$(find fast_livo)/config/camera_{seq}.yaml" />
\t</node>

\t<group if="$(arg rviz)">
\t\t<node launch-prefix="nice" pkg="rviz" type="rviz" name="rviz" args="-d $(find fast_livo)/rviz_cfg/fast_livo2.rviz" />
\t</group>
</launch>
"""
    out_l = os.path.join(ROOT, "launch", f"mapping_{seq}.launch")
    with io.open(out_l, "w", encoding="utf-8") as f:
        f.write(launch)
    print("wrote", out_l)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--seq", default="urban-01", help="great_urban01 or great_campus01 (default urban-01)")
    args = ap.parse_args()
    seq = args.seq
    # urban01 was acquired on the same day as campus01 with the same platform,
    # so it reuses the campus01 extrinsics as its base config
    base = os.path.join(ROOT, "config", f"great_{seq}.yaml")
    if seq == "urban01" or not os.path.exists(base):
        base = os.path.join(ROOT, "config", "great_campus01.yaml")
    cam = os.path.join(ROOT, "config", "camera_great.yaml")
    if not os.path.exists(base):
        print("base config not found:", base)
        raise SystemExit(1)
    for m in ("baseline", "occlusion", "dynamic", "graph", "improved", "improved_noP1", "improved_gnss"):
        build(f"great_{seq}", m, base, cam, ROOT, ROOT)
    print("done.")

