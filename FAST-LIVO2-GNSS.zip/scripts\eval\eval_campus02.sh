#!/usr/bin/env bash
# campus-02 evaluation: LIVO (LIO+VIO) and tight GNSS coupling.
# usage: bash eval_campus02.sh <mode> [start] [dur]
#   mode: baseline(no GNSS) | gnssfix(LIVO+GNSS tight) | improved_noP1 | ...
#   start/dur are relative to the LiDAR start (bag origin + 146 s GNSS lead).
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
MODE=$1
START=${2:-146}
DUR=${3:-700}
BAG='/mnt/e/GREAT数据集/campus-02/campus-02.bag'
GNSS='/mnt/e/GREAT数据集/campus-02/gnss_c02.bag'
REF=Log/GREAT/campus02_reference.tum
mkdir -p ~/logs
SEQ=great_campus02_$MODE
rm -f Log/result/$SEQ.txt Log/result/${SEQ}_graph.txt Log/result/${SEQ}_latency.csv

if ! pgrep -f 'bin/roscore' > /dev/null; then
  roscore > ~/logs/roscore.log 2>&1 &
  sleep 5
fi

roslaunch fast_livo mapping_great_campus02.launch mode:=$MODE rviz:=false > ~/logs/c2_$MODE.log 2>&1 &
LPID=$!
sleep 70
# play sensor bag + GNSS bag together; -s 146 aligns both to the LiDAR start
# (the GNSS bag starts 146 s earlier because the RTK solution covers a wider window)
/opt/ros/noetic/bin/rosbag play -s $START -u $DUR --clock $BAG $GNSS > ~/logs/c2_play_$MODE.log 2>&1
sleep 5
kill $LPID 2>/dev/null
sleep 3

echo "==== $MODE (t=$START..$((START+DUR))s) ===="
grep -o 'effective feature num: [0-9]*' ~/logs/c2_$MODE.log | awk '{s+=$4; n++} END {if (n>0) printf "mean eff feat: %.1f (n=%d)\n", s/n, n}'
grep -m2 'GNSS' ~/logs/c2_$MODE.log | head -2
N=$(wc -l < Log/result/$SEQ.txt 2>/dev/null || echo 0)
echo "traj lines: $N"
if [ "$N" -gt 1 ]; then
  head -1 Log/result/$SEQ.txt
  tail -1 Log/result/$SEQ.txt
  awk 'NR>1 {dx=$2-px; dy=$3-py; dz=$4-pz; s+=sqrt(dx*dx+dy*dy+dz*dz)} {px=$2; py=$3; pz=$4} END {printf "traj total length: %.2f m over %d lines\n", s, NR}' Log/result/$SEQ.txt
  if command -v evo_ape >/dev/null 2>&1; then
    evo_ape tum $REF Log/result/$SEQ.txt -a --no_warnings 2>/dev/null | grep -E 'rmse|mean|max' | head -4
  fi
fi
