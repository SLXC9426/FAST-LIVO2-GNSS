/*
A3.1 self-test: static-anchor validity gate.

Pins the gate contract reviewed before implementation:
  - trimming is applied to the associated fix timestamps, not keyframe times;
  - Fixed means the carrier-fixed family (FIXED + GOOD); Float is not Fixed;
  - P95 and max deviation are separate checks (an isolated outlier must fail
    the max check even when the median is stable);
  - slow drift is a trend measure, independent of the endpoint difference;
  - no reference onset can only be WEAK, never VALID;
  - unset (0) thresholds can only be WEAK, never VALID;
  - insufficient samples / low Fixed ratio / short trimmed window are
    UNAVAILABLE with distinct reasons.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/static_anchor_validity_selftest
*/
#include "static_anchor_validity.h"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>
#include <limits>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok, const std::string &detail = "")
{
  std::printf("%s  %-58s %s\n", ok ? "ok  " : "FAIL", name.c_str(),
              detail.c_str());
  if (!ok) ++g_failures;
}

using fast_livo::GnssQualityClass;
using fast_livo::StaticAnchorSample;
using fast_livo::StaticAnchorValidityParams;
using fast_livo::StaticAnchorValidityResult;
using fast_livo::StaticAnchorValidityState;
using fast_livo::StaticAnchorRejectReason;

StaticAnchorSample mk(double kf, double fix, double x, double y, double z,
                      GnssQualityClass c)
{
  StaticAnchorSample s;
  s.kf_time = kf;
  s.fix_time = fix;
  s.q = Eigen::Vector3d(x, y, z);
  s.lio_position = Eigen::Vector3d(0.01 * kf, 0.0, 0.0);
  s.quality_class = c;
  return s;
}

StaticAnchorValidityParams validParams()
{
  StaticAnchorValidityParams p;
  p.trim_start_sec = 13.0;
  p.trim_end_sec = 2.0;
  p.reference_onset_sec = 116.9;
  p.fallback_end_trim_sec = 2.0;
  p.min_samples = 50;
  p.min_fixed_ratio = 0.9;
  p.max_rtk_net_displacement = 1.0;
  p.max_rtk_p95 = 0.2;
  p.max_rtk_deviation = 0.5;
  p.max_slow_drift = 0.5;
  return p;
}

// 120 one-hertz samples; fix is 0.4 s after the keyframe. The reference onset
// trim selects fix times [13.0, 114.9], i.e. keyframes 13..114.
std::vector<StaticAnchorSample> gridSamples()
{
  std::vector<StaticAnchorSample> v;
  for (int i = 0; i < 120; ++i)
  {
    const double t = static_cast<double>(i);
    v.push_back(mk(t, t + 0.4, 0.01 * std::sin(0.3 * t),
                   0.01 * std::cos(0.3 * t), 0.0,
                   GnssQualityClass::GOOD));
  }
  return v;
}

bool near(double a, double b, double tol = 1e-9)
{
  return std::fabs(a - b) <= tol;
}

}  // namespace

int main()
{
  const double t0 = 0.0;
  const double run_start = 0.0;
  const double run_end = 119.0;

  // ---- 1. fully configured, clean run: VALID ------------------------------
  {
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        validParams(), 0, t0, run_start, run_end, gridSamples());
    check("clean run is VALID", r.state == StaticAnchorValidityState::VALID);
    check("trim basis is reference_onset", r.trim_basis == "reference_onset");
    check("raw sample count 120", r.raw_sample_count == 120);
    check("trimmed sample count 102", r.trimmed_sample_count == 102);
    check("all samples are Fixed", r.fixed_count == 102 && r.good_count == 102);
    check("fixed ratio is 1", near(r.fixed_ratio, 1.0));
    check("trimmed fix start is 13.4", near(r.trimmed_fix_start, 13.4, 1e-9));
    check("trimmed fix end is 114.4", near(r.trimmed_fix_end, 114.4, 1e-9));
    check("thresholds complete", r.thresholds_complete);
  }

  // ---- 2. trim uses fix time, not keyframe time ---------------------------
  {
    std::vector<StaticAnchorSample> v;
    v.push_back(mk(12.0, 12.5, 0, 0, 0, GnssQualityClass::GOOD));
    v.push_back(mk(13.0, 13.5, 0, 0, 0, GnssQualityClass::GOOD));
    v.push_back(mk(114.0, 114.5, 0, 0, 0, GnssQualityClass::GOOD));
    v.push_back(mk(115.0, 115.5, 0, 0, 0, GnssQualityClass::GOOD));
    v.push_back(mk(116.0, 116.5, 0, 0, 0, GnssQualityClass::GOOD));
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 2;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 1, t0, run_start, run_end, v);
    check("fix-time trim keeps only 2 samples", r.trimmed_sample_count == 2);
    check("fix-time trim ends at 114.5", near(r.trimmed_fix_end, 114.5, 1e-9));
    check("fix-time trim excludes 115/116 kf",
          r.trimmed_kf_end < 114.9);
  }

  // ---- 3. Fixed ratio uses the classifier, not quality_ok ----------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 20; ++i)
    {
      const double t = 20.0 + i;
      v.push_back(mk(t, t + 0.4, 0, 0, 0,
                     i < 10 ? GnssQualityClass::FIXED
                            : GnssQualityClass::FLOAT));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 10;
    p.min_fixed_ratio = 0.8;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 2, t0, run_start, run_end, v);
    check("Float is not counted as Fixed",
          r.fixed_count == 10 && r.float_count == 10);
    check("Fixed ratio is 0.5", near(r.fixed_ratio, 0.5));
    check("low Fixed ratio is UNAVAILABLE",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::LOW_FIXED_RATIO);
  }

  // ---- 4. GOOD belongs to the carrier-fixed family ------------------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 5; ++i)
    {
      const double t = 20.0 + i;
      v.push_back(mk(t, t + 0.4, 0, 0, 0,
                     i < 3 ? GnssQualityClass::GOOD
                           : GnssQualityClass::FIXED));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 5;
    p.min_fixed_ratio = 1.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 3, t0, run_start, run_end, v);
    check("FIXED and GOOD both count as Fixed",
          r.fixed_count == 5 && r.good_count == 3);
    check("FIXED+GOOD ratio is 1", near(r.fixed_ratio, 1.0));
  }

  // ---- 5. isolated outlier: max deviation fails, P95 stays small ---------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 20; ++i)
    {
      const double t = 20.0 + i;
      const double x = (i == 10) ? 5.0 : 0.0;
      v.push_back(mk(t, t + 0.4, x, 0, 0, GnssQualityClass::GOOD));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 20;
    p.min_fixed_ratio = 1.0;
    p.max_rtk_net_displacement = 10.0;
    p.max_rtk_p95 = 0.5;
    p.max_rtk_deviation = 1.0;
    p.max_slow_drift = 10.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 4, t0, run_start, run_end, v);
    check("isolated outlier keeps P95 small", r.rtk_robust_p95 < 0.5);
    check("isolated outlier fails max deviation",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::RTK_DISPERSION_TOO_LARGE);
    check("max-deviation reason names the check",
          r.reason.find("rtk_max_deviation") != std::string::npos);
  }

  // ---- 6. P95 check is separate from max deviation -----------------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 20; ++i)
    {
      const double t = 20.0 + i;
      const double x = (i >= 17) ? 2.0 : 0.0;  // three of twenty
      v.push_back(mk(t, t + 0.4, x, 0, 0, GnssQualityClass::GOOD));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 20;
    p.min_fixed_ratio = 1.0;
    p.max_rtk_net_displacement = 10.0;
    p.max_rtk_p95 = 0.5;
    p.max_rtk_deviation = 3.0;
    p.max_slow_drift = 10.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 5, t0, run_start, run_end, v);
    check("P95 check fires before max-deviation check",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reason.find("rtk_p95") != std::string::npos);
  }

  // ---- 7. slow monotone drift with small residuals -----------------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 102; ++i)
    {
      const double t = 13.0 + i;
      const double x = 0.01 * (t - 13.0);
      v.push_back(mk(t, t + 0.4, x, 0, 0, GnssQualityClass::GOOD));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 50;
    p.min_fixed_ratio = 1.0;
    p.max_rtk_net_displacement = 2.0;
    p.max_rtk_p95 = 0.5;
    p.max_rtk_deviation = 2.0;
    p.max_slow_drift = 0.5;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 6, t0, run_start, run_end, v);
    check("slow drift is detected", r.rtk_slow_drift > 0.5);
    check("slow drift fails with RTK_SLOW_DRIFT",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason == StaticAnchorRejectReason::RTK_SLOW_DRIFT);
    check("slow-drift reason names the check",
          r.reason.find("rtk_slow_drift") != std::string::npos);
  }

  // ---- 8. net displacement check -----------------------------------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 20; ++i)
    {
      const double t = 20.0 + i;
      const double x = (i == 19) ? 1.5 : 0.0;
      v.push_back(mk(t, t + 0.4, x, 0, 0, GnssQualityClass::GOOD));
    }
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 20;
    p.min_fixed_ratio = 1.0;
    p.max_rtk_net_displacement = 1.0;
    p.max_rtk_p95 = 0.5;
    p.max_rtk_deviation = 2.0;
    p.max_slow_drift = 5.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 7, t0, run_start, run_end, v);
    check("net displacement fails with RTK_DISPLACEMENT_TOO_LARGE",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::RTK_DISPLACEMENT_TOO_LARGE);
  }

  // ---- 9. no reference onset: fallback trim, WEAK only -------------------
  {
    StaticAnchorValidityParams p = validParams();
    p.reference_onset_sec = -1.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 8, t0, run_start, run_end, gridSamples());
    check("no reference onset is WEAK",
          r.state == StaticAnchorValidityState::WEAK);
    check("no reference onset uses fallback trim",
          r.trim_basis == "fallback_end_trim" &&
              !r.reference_onset_available);
    check("fallback trim ends at run_end - 2",
          near(r.trimmed_fix_end, 116.4, 1e-9));
  }

  // ---- 10. unset threshold: WEAK, not VALID ------------------------------
  {
    StaticAnchorValidityParams p = validParams();
    p.max_slow_drift = 0.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 9, t0, run_start, run_end, gridSamples());
    check("unset threshold is WEAK",
          r.state == StaticAnchorValidityState::WEAK);
    check("unset threshold is not complete", !r.thresholds_complete);
    check("unset threshold is named",
          r.reason.find("max_slow_drift") != std::string::npos);
  }

  // ---- 11. min sample count ----------------------------------------------
  {
    StaticAnchorValidityParams p = validParams();
    p.min_samples = 200;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 10, t0, run_start, run_end, gridSamples());
    check("insufficient samples is UNAVAILABLE",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::INSUFFICIENT_SAMPLES);
  }

  // ---- 12. trimmed window too short --------------------------------------
  {
    StaticAnchorValidityParams p = validParams();
    p.trim_start_sec = 120.0;
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        p, 11, t0, run_start, run_end, gridSamples());
    check("start after end is TRIMMED_WINDOW_TOO_SHORT",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::TRIMMED_WINDOW_TOO_SHORT);
    check("invalid window basis is recorded", r.trim_basis == "invalid_window");
  }

  // ---- 13. empty candidate set -------------------------------------------
  {
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        validParams(), 12, t0, run_start, run_end,
        std::vector<StaticAnchorSample>());
    check("empty set is UNAVAILABLE",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::INSUFFICIENT_SAMPLES);
  }

  // ---- 14. Float-only set cannot pass ------------------------------------
  {
    std::vector<StaticAnchorSample> v;
    for (int i = 0; i < 20; ++i)
    {
      const double t = 20.0 + i;
      v.push_back(mk(t, t + 0.4, 0, 0, 0, GnssQualityClass::FLOAT));
    }
    const auto r = fast_livo::evaluateStaticAnchorValidity(
        validParams(), 13, t0, run_start, run_end, v);
    check("Float-only set is LOW_FIXED_RATIO",
          r.state == StaticAnchorValidityState::UNAVAILABLE &&
              r.reject_reason ==
                  StaticAnchorRejectReason::LOW_FIXED_RATIO);
  }

  // ---- 15. deterministic ------------------------------------------------
  {
    const auto a = fast_livo::evaluateStaticAnchorValidity(
        validParams(), 14, t0, run_start, run_end, gridSamples());
    const auto b = fast_livo::evaluateStaticAnchorValidity(
        validParams(), 14, t0, run_start, run_end, gridSamples());
    check("same input gives identical state and counts",
          a.state == b.state && a.trimmed_sample_count == b.trimmed_sample_count &&
              a.fixed_count == b.fixed_count &&
              near(a.rtk_robust_p95, b.rtk_robust_p95) &&
              near(a.rtk_slow_drift, b.rtk_slow_drift));
  }

  // Malformed numerical input must never certify an anchor.
  for (double bad : {std::numeric_limits<double>::quiet_NaN(),
                     std::numeric_limits<double>::infinity()}) {
    auto p = validParams(); auto samples = gridSamples();
    samples[20].q.x() = bad;
    auto r = fast_livo::evaluateStaticAnchorValidity(p,15,t0,run_start,run_end,samples);
    check("non-finite candidate rejected",r.state==StaticAnchorValidityState::UNAVAILABLE &&
          r.reject_reason==StaticAnchorRejectReason::INVALID_SAMPLE);
    samples=gridSamples(); samples[20].fix_time=bad;
    r=fast_livo::evaluateStaticAnchorValidity(p,15,t0,run_start,run_end,samples);
    check("non-finite timestamp rejected",r.reject_reason==StaticAnchorRejectReason::INVALID_SAMPLE);
    p.max_slow_drift=bad;
    r=fast_livo::evaluateStaticAnchorValidity(p,15,t0,run_start,run_end,gridSamples());
    check("non-finite threshold rejected",r.reject_reason==StaticAnchorRejectReason::INVALID_CONFIGURATION);
  }
  {
    auto samples=gridSamples(); samples[21].fix_time=samples[20].fix_time;
    const auto r=fast_livo::evaluateStaticAnchorValidity(validParams(),16,t0,run_start,run_end,samples);
    check("duplicate fix cannot count twice",r.reject_reason==StaticAnchorRejectReason::INVALID_SAMPLE);
    auto p=validParams(); p.min_fixed_ratio=1.1;
    const auto invalid=fast_livo::evaluateStaticAnchorValidity(p,16,t0,run_start,run_end,gridSamples());
    check("impossible fixed ratio rejected",invalid.reject_reason==StaticAnchorRejectReason::INVALID_CONFIGURATION);
  }
  if (g_failures == 0)
  {
    std::printf("\nPASS: static-anchor validity gate\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
