#!/usr/bin/env python3
"""Re-integrate campus IMU with CORRECT units (gyr deg/s -> rad/s)."""
import numpy as np

rows = []
with open("/home/slxc9426/datasets/GREAT/IMU/Tactical_imu_data.txt") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "ime" in line:
            continue
        rows.append([float(x) for x in line.split()])
a = np.array(rows)
OFFSET = 604800 * 2129 + 315964800 - 18
t = a[:, 0] + OFFSET
gyr = a[:, 1:4] * np.pi / 180.0  # deg/s -> rad/s
acc = a[:, 4:7]

# window 0-400s
t0, t1 = 1603764571.0, 1603764971.0
m = (t >= t0) & (t <= t1)
ts, gs, as_ = t[m], gyr[m], acc[m]

# gravity from first 200 samples
g0 = as_[:200].mean(0)
print("gravity:", g0.round(4), "|g|:", np.linalg.norm(g0))

# integrate with full 3D rotation (body -> world via R)
R = np.eye(3)
p = np.zeros(3)
v = np.zeros(3)
dist = 0.0
prev = None
for i in range(len(ts) - 1):
    dt = ts[i + 1] - ts[i]
    if dt <= 0 or dt > 0.1:
        continue
    w = (gs[i] + gs[i + 1]) / 2.0
    wn = np.linalg.norm(w)
    if wn > 1e-12:
        K = w / wn * np.sin(wn * dt / 2)
        q = np.array([np.cos(wn * dt / 2), K[0], K[1], K[2]])
        # quaternion rotate
        def qv(q, vv):
            t_ = 2 * np.cross(q[1:], vv)
            return vv + q[0] * t_ + np.cross(q[1:], t_)
        # R = R @ Exp(w dt) via quaternion: q_world = q_world * q
        # body frame update: v_world = R @ v_body
        R = qv(np.array([q[0], -q[1], -q[2], -q[3]]), R.T).T  # rotate R rows
        # simpler: R = R @ Exp(w*dt)
        # use rotation matrix: R_new = R @ Exp(w dt)
        # Exp(w dt):
        wx, wy, wz = w * dt
        ang = np.linalg.norm(w * dt)
        if ang < 1e-12:
            Exp = np.eye(3)
        else:
            kx, ky, kz = w * dt / ang
            K = np.array([[0, -kz, ky], [kz, 0, -kx], [-ky, kx, 0]])
            Exp = np.eye(3) + np.sin(ang) * K + (1 - np.cos(ang)) * (K @ K)
        R = R @ Exp
    a_body = (as_[i] + as_[i + 1]) / 2.0
    aw = R @ a_body + np.array([0, 0, -9.81])  # gravity in world (z down)
    # align world: gravity estimate says world z is along -g0 direction; use g0
    aw = R @ a_body - g0  # subtract measured gravity vector (body frame)
    v = v + aw * dt
    p = p + v * dt
    dist += np.linalg.norm(v) * dt
print("correct-unit integration: final p=(%.1f, %.1f, %.1f) path %.0f m, final v %.2f m/s" %
      (p[0], p[1], p[2], dist, np.linalg.norm(v)))
