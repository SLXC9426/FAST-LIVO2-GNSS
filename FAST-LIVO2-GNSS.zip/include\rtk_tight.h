#ifndef RTK_TIGHT_H
#define RTK_TIGHT_H

#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <map>
#include <string>
#include <vector>

#include <fast_livo/RtkDD.h>
#include "common_lib.h"

// Front-end RTK double-difference tight coupling.
//
// The 19-dim ESIKF state (StatesGroup) is kept unchanged.  A separate block of
// float DD ambiguities (one per sys/freq/sat/ref pair, in metres) is maintained
// with its own covariance.  The update uses the block-diagonal approximation
// P_xa = 0:
//
//   S      = H_x P_xx H_x^T + R + H_a P_aa H_a^T
//   K_x    = P_xx H_x^T S^-1
//   K_a    = P_aa H_a^T S^-1
//   dx     = K_x r,  da = K_a r
//
// The base position is the GREAT fixed-base coordinate.  Double differences are
// evaluated in the base-centred ENU frame; the rover ENU position comes from
// the existing ENU->world alignment (tryAlignGnssYaw), so this class never
// touches the world frame convention.
class RtkTight
{
public:
  struct Config
  {
    Eigen::Vector3d base_ecef = Eigen::Vector3d(-2267749.9279, 5009154.2407,
                                                3221290.6333);
    double sigma_code_min = 1.0;     // m, floor on the per-pair code sigma
    double sigma_code_scale = 2.0;   // measured DD code residual is ~2-3 m
    double sigma_phase_min = 0.03;   // m, floor on the per-pair phase sigma
    // Optional elevation-dependent quality weighting for the per-pair code/
    // phase sigmas.  The RtkDD message carries elevation at the base; a pair
    // is limited by its lower satellite, so q = (sin(e_ref)/sin(e_min))^w.
    // Disabled by default; the baseline float/robust results are unchanged.
    bool quality_elev_en = false;
    double quality_elev_weight = 0.5;   // exponent on the elevation ratio
    double quality_elev_ref_deg = 30.0;
    double quality_elev_min = 0.7;
    double quality_elev_max = 3.0;
    double init_amb_var = 4.0;      // m^2 (2 m sigma) for a new ambiguity
    double phase_slip_thresh = 0.5; // m, residual-based cycle-slip reset
    // Fixed-phase (GREAT-MSF-aided) path. When fix_valid[i] is set, the DD
    // phase is already integer-fixed externally and is used as a precise range
    // measurement without adding an ambiguity state. Pairs with fix_valid=0
    // keep the float-ambiguity path above.
    bool fixed_phase_en = false;
    double sigma_fixed_phase = 0.02;   // m, fixed-phase measurement sigma
    double fixed_phase_gate = 0.10;    // m, reject a fixed pair above this residual

    // TDCP (time-differenced DD phase). One scalar relative-displacement
    // update per common pair between consecutive DD epochs, applied after the
    // ordinary code/phase update. The previous posterior is the fixed anchor;
    // its uncertainty is added to the measurement variance.
    bool tdcp_en = false;
    double tdcp_sigma_scale = 1.0;
    double tdcp_prev_sigma = 0.05;   // m, previous-anchor uncertainty floor
    int tdcp_min_pairs = 4;
    double tdcp_max_dt = 2.0;        // s
    bool tdcp_robust_en = true;
    double tdcp_robust_k0 = 3.0;
    double tdcp_robust_k1 = 6.0;
    // Admission gate: do not use the fixed phase while the float/code solution
    // is still metres away (c02: 8 m common residual). One bad fixed epoch
    // pulls the state by metres and corrupts the frame; use float DD until the
    // code RMS is back inside this gate.
    bool fixed_phase_code_gate_en = true;
    double fixed_phase_max_code_rms = 3.0; // m, previous-epoch code RMS
    // Two-stage schedule: during the first accepted epochs the LIO/GNSS frame
    // offset can be metres, so the fixed phase starts loose; after warm-up it is
    // tightened to the cm-level values below.
    int fixed_warmup_epochs = 30;
    double sigma_fixed_phase_tight = 0.05;
    double fixed_phase_gate_tight = 0.5;
    double prior_sigma_pos_tight = 0.5;
    // Per-pair sigma from the GREAT-MSF bias MAD, plus a fixed-pair
    // count/streak supervisor. Pairs with an unstable bias are not used.
    bool per_pair_sigma = true;
    double sigma_fixed_floor = 0.03;
    double sigma_fixed_ceiling = 1.0;
    int min_fixed_pairs = 5;
    int fixed_min_streak = 2;
    // Time-based variants (dataset/rate independent). The epoch-based fields
    // above are kept for backward-compatible YAML but are no longer used.
    double fixed_warmup_s = 30.0;
    double fixed_min_streak_s = 2.0;
    // Data-driven warm-up: stay on the loose fixed-phase gate until the fixed
    // residual has been below settle_rms for settle_s seconds. The old fixed
    // 30 s timer could switch to the 0.5 m gate while the state was still 1-2 m
    // off, after which every fixed epoch was rejected and never converged.
    bool fixed_settle_en = false;
    double fixed_settle_rms = 0.5; // m
    double fixed_settle_s = 5.0;   // s
    // One-time common frame translation from the fixed-phase residuals. A
    // wrong integer is also a common offset, so this is only allowed inside a
    // short window after the first fixed-phase epoch and requires the residual
    // pattern to fit a pure translation; P3's later 1 m injection therefore
    // cannot be absorbed as a frame shift.
    // Off by default: the c01/c02 trials showed the fixed-phase residual is not
    // a stable constant translation (c01 produced a perfect 9.5 m vertical fit
    // at one epoch, followed by 2-4 m residuals again). A state-level vertical/
    // scale term is needed; keep this estimator for experiments only.
    bool frame_offset_en = false;
    int frame_offset_min_pairs = 8;
    double frame_offset_min = 0.25;      // m, below this the frame is aligned
    double frame_offset_max = 10.0;      // m, reject implausible estimates
    double frame_offset_max_vertical = 1.0; // m, frames are gravity-aligned
    double frame_offset_max_resid = 0.5; // m, residual after the translation
    double frame_offset_window_s = 60.0; // s after the first fixed-phase epoch
    // State-covariance-aware robust weighting for the fixed phase. The
    // normalized innovation uses S_ii (state + measurement), not the raw
    // residual, so a metre-level frame offset can be pulled while the LIO
    // covariance is still large, and is rejected once the state is tight.
    bool fixed_robust_en = true;
    double fixed_robust_k0 = 3.0;
    double fixed_robust_k1 = 6.0;
    // A wrong external integer moves every fixed pair in the same direction
    // (common-mode). Per-pair robust tests can discard the minority and leave
    // enough "inliers" to shift the state by a metre. Require a majority of the
    // fixed set to survive its own gates before accepting the fixed solution.
    bool fixed_consensus_en = true;
    double fixed_consensus_min_frac = 0.5;
    int fixed_consensus_min_pairs = 4;
    // Phase 3: IMU/LiDAR-prior robust weights.  robust_en=false reproduces the
    // Phase-2 measurement update exactly.
    bool robust_en = false;
    double robust_kappa_code = 3.0;        // absolute code gate: kappa*sigma_abs
    double robust_sigma_code_abs = 2.5;    // m, DD code noise for the gate/IGG3
    double robust_k0_code = 1.5;           // IGG3 no-downweight below k0
    double robust_k1_code = 3.0;           // IGG3 zero above k1
    double robust_sigma_phase_abs = 0.05;  // m, DD phase noise for IGG3
    double robust_k0_phase = 3.0;
    double robust_k1_phase = 6.0;
    // The LIO covariance is over-confident (cm-level) while its drift is metres.
    // Inflate the horizontal position prior for the RTK update only; vertical is
    // left to the LIO (the RTK vertical channel is the known weak one).
    double prior_sigma_pos = 1.0;    // m, horizontal prior floor
    // Coarse acquisition: before the first DD update the LIO/GNSS offset can be
    // metres. A 20 m code floor makes the code innovation weak; a 20 m prior
    // with a 1 m code sigma lets the first accepted epoch remove the offset,
    // then the filter returns to the normal (tight) schedule once the code RMS
    // has stayed small for a few seconds. Dataset-independent: the exit is
    // driven by the measured residual, not a sequence name or tuning.
    // Off by default: the c02/c01 experiments showed that pulling several
    // metres along DD code before the frame/scale are trustworthy is unstable
    // (code multipath and yaw errors dominate). Kept for a future scale-aware
    // acquisition path.
    bool coarse_acq_en = false;
    double coarse_acq_max_align_resid = 1.0; // m, only start if the frame fit is tight
    double coarse_acq_code_sigma = 3.0;   // m, code sigma during acquisition
    double coarse_acq_prior_sigma = 20.0; // m, position prior during acquisition
    double coarse_acq_exit_code_rms = 2.0; // m, exit when the code RMS is below
    double coarse_acq_exit_s = 5.0;       // s, and has stayed below this long
    double gate_chi2 = 0.0;          // 0 = 95% chi-square by DOF
    double max_corr = 5.0;           // m, per-epoch position correction clamp
    int health_every_n = 10;
    bool verbose = true;
  };

  RtkTight();
  void setConfig(const Config &cfg);
  const Config &config() const { return cfg_; }

  // Per-epoch quality snapshot for the P2 fusion supervisor.
  struct Health
  {
    int n_pairs = 0;
    int n_fixed = 0;
    int fixed_streak = 0;
    double fixed_streak_s = 0.0;
    double gamma = 0.0;
    double gate = 0.0;
    double ratio = 0.0;
    double code_rms = 0.0;   // m, RMS DD code residual this epoch
    double phase_rms = 0.0;  // m, RMS fixed-phase residual (0 if no fixed pairs)
    int n_tdcp = 0;          // TDCP rows used this epoch
    double tdcp_rms = 0.0;   // m, RMS TDCP residual
    bool coarse_acq = false; // true while the coarse acquisition schedule is on
    bool accepted = false;
    double t = -1.0;
  };
  const Health &health() const { return health_; }

  // Soft weight applied to the whole DD measurement block (1 = nominal,
  // 0.5 = covariance doubled).  Set per epoch by the fusion supervisor.
  void setExternalWeight(double w);
  // FLOAT/REJECT modes disable the externally fixed phase but keep the
  // ordinary float DD path; REJECT should skip update() entirely.
  void setUseFixedPhase(bool en) { use_fixed_phase_ext_ = en; }

  // Tell RtkTight how well the ENU<->world frame fit is. Coarse acquisition is
  // only safe when the frame itself is sub-metre; otherwise a large pull along
  // a wrong yaw makes the DD residual grow. c02 (1.4 m fit) is excluded by this
  // guard, c01 (0.49 m) is allowed.
  void setAlignResidual(double r);
  void setUseScale(bool en) { use_scale_ = en; }

  // One-time frame translation (base ENU) estimated from the fixed-phase
  // residual pattern. Returns true once and clears the pending value.
  bool consumeFrameOffset(V3D &offset_enu)
  {
    if (!frame_offset_pending_) return false;
    offset_enu = frame_offset_enu_;
    frame_offset_pending_ = false;
    return true;
  }

  // GNSS origin used by the existing ENU alignment (first valid NavSatFix).
  void setOrigin(double lat, double lon, double alt);
  bool originSet() const { return origin_set_; }

  // Score a candidate ENU<->world alignment against the DD code measurements.
  // Used before locking: absolute and relative yaw/translation candidates are
  // compared by their robust DD code RMS, so a bad Procrustes yaw cannot lock.
  bool scoreAlignment(const fast_livo::RtkDD &msg,
                      const StatesGroup &state,
                      const M3D &enu_R_world,
                      const V3D &enu_t_world,
                      const V3D &lever_body,
                      double &rms) const;

  // Process one /rtk/dd epoch.  state_prop is the ESIKF state propagated to the
  // message timestamp; enu_R_world / enu_t_world are the existing ENU->world
  // alignment; lever_body is the antenna lever arm in the IMU body frame.
  // On success returns true and fills dx (20) and P_new (20x20).
  bool update(const fast_livo::RtkDD &msg,
              const StatesGroup &state_prop,
              const M3D &enu_R_world,
              const V3D &enu_t_world,
              const V3D &lever_body,
              Eigen::Matrix<double, DIM_STATE, 1> &dx,
              Eigen::Matrix<double, DIM_STATE, DIM_STATE> &P_new);

  void reset();
  size_t nAmb() const { return (size_t)amb_.size(); }
  int accepted() const { return accepted_; }
  int rejected() const { return rejected_; }

private:
  struct AmbKey
  {
    std::string sys, freq, sat, ref;
    bool operator<(const AmbKey &o) const
    {
      if (sys != o.sys) return sys < o.sys;
      if (freq != o.freq) return freq < o.freq;
      if (sat != o.sat) return sat < o.sat;
      return ref < o.ref;
    }
  };

  int addAmbiguity(const AmbKey &key, double value);
  void resetAmbiguity(int idx, double value);

  // TDCP anchor: the previous epoch's DD phase/satellite geometry and the
  // posterior antenna position in the base ENU frame.
  struct TdcpPrev
  {
    double phase = 0.0;
    Eigen::Vector3d sat_ecef = Eigen::Vector3d::Zero();
    Eigen::Vector3d ref_ecef = Eigen::Vector3d::Zero();
    double sigma_phase = 0.015;
    double elev_min = 90.0;
    double dd_geom = 0.0;
  };
  void storeTdcpPrev(const StatesGroup &post, const fast_livo::RtkDD &msg,
                     const M3D &enu_R_world, const V3D &enu_t_world,
                     const V3D &lever_body);

  static void ecefToGeodetic(const Eigen::Vector3d &ecef, double &lat,
                             double &lon, double &alt);
  static Eigen::Vector3d geodeticToEcef(double lat, double lon, double alt);
  static Eigen::Matrix3d enuRotation(double lat, double lon);
  static double chi2Threshold95(int dof);
  static double igg3Weight(double u, double k0, double k1);

  Config cfg_;
  bool origin_set_ = false;
  double origin_lat_ = 0.0, origin_lon_ = 0.0, origin_alt_ = 0.0;
  Eigen::Vector3d base_enu_neg_ = Eigen::Vector3d::Zero();  // base in origin ENU, U negated

  std::map<AmbKey, int> index_;
  Eigen::VectorXd amb_;
  Eigen::MatrixXd P_amb_;

  int accepted_ = 0;
  int rejected_ = 0;
  int evaluated_ = 0;
  int fixed_streak_ = 0;
  double fixed_streak_s_ = 0.0;
  double first_t_ = -1.0;
  double last_health_t_ = -1.0;
  double last_t_ = -1.0;
  // TDCP anchor: previous epoch's DD pairs + posterior antenna position.
  bool have_tdcp_prev_ = false;
  double last_tdcp_t_ = -1.0;
  V3D last_p_ant_enu_ = V3D::Zero();
  std::map<AmbKey, TdcpPrev> tdcp_prev_;
  // Coarse-acquisition schedule (see Config::coarse_acq_*).
  bool coarse_acq_ = false;
  bool coarse_done_ = false;
  bool fixed_settled_ = false;
  double fixed_settle_good_s_ = 0.0;
  double align_resid_ = -1.0;
  bool frame_offset_done_ = false;
  bool frame_offset_pending_ = false;
  double frame_offset_first_t_ = -1.0;
  V3D frame_offset_enu_ = V3D::Zero();
  double coarse_good_s_ = 0.0;
  double coarse_last_t_ = -1.0;
  Health health_;
  double external_weight_ = 1.0;
  bool use_fixed_phase_ext_ = true;
  bool use_scale_ = true;
};

#endif  // RTK_TIGHT_H
