#!/usr/bin/env python3
"""Generate urban-01 baseline variants with different lidar_time_offset for a
quick freeze diagnosis (effective feature count probe)."""
import io, os

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "config")
SRC = os.path.join(ROOT, "great_urban01_baseline.yaml")
txt = io.open(SRC, encoding="utf-8", errors="replace").read()

for off in (-0.1, -0.05, 0.05, 0.1):
    name = f"great_urban01_toff{int(off * 1000):+d}"
    out = txt.replace("seq_name: \"great_urban01_baseline\"", f"seq_name: \"{name}\"")
    # insert offset into time_offset section
    out = out.replace("img_time_offset: 0.0", f"img_time_offset: 0.0\n  lidar_time_offset: {off}")
    p = os.path.join(ROOT, name + ".yaml")
    io.open(p, "w", encoding="utf-8").write(out)
    print("wrote", name, "offset", off)
