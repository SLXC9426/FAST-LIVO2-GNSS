# A0/A1 evaluation

reference: `/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data/campus01_reference.tum`

| arm | rows | matched | ATE med/p95/RMSE (m) | abs 2D RMSE | abs 3D RMSE | abs p95 | 2D RMSE after constant-bias removal | RPE1 RMSE | RPE10 RMSE |
|---|---:|---:|---|---:|---:|---:|---:|---:|---:|
| A0 | 606 | 606 | 0.996 / 2.588 / 1.553 | 1.115 | 1.222 | 2.162 | 1.164 | 0.107 | 0.616 |
| A1 | 606 | 606 | 0.388 / 1.282 / 0.706 | 0.509 | 0.804 | 1.575 | 0.442 | 0.101 | 0.516 |

## Segment absolute 2D / 3D / bias-removed 2D RMSE (m)

| arm | 0-120s | 240-360s |
|---|---|---|
| A0 | 0.557 / 0.767 / 0.795 | 1.680 / 1.698 / 2.003 |
| A1 | 0.546 / 0.716 / 0.722 | 0.419 / 0.681 / 0.395 |

- A0 median ENU bias: E -0.313, N -0.326, U 0.192 m

- A1 median ENU bias: E -0.015, N 0.386, U 0.181 m
