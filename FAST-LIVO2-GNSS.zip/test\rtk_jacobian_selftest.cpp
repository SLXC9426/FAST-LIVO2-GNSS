/*
R1 self-test: RTK geometry/Jacobian signs and RtkDD validation.

This is intentionally a standalone executable (no gtest), matching the other
*_selftest.cpp targets:

    catkin_make --pkg fast_livo
    ./devel/lib/fast_livo/rtk_jacobian_selftest

Checks
  (1) dh/dp of the DD geometry equals u_sat - u_ref, by central finite
      differences.  This is the sign that the pre-P0 code had reversed.
  (2) d(H_pos * R * l)/dtheta equals -H_pos * R * [l]_x under the right
      perturbation R_new = R * Exp(dtheta), for random non-identity rotations.
  (3) The cached form -H_pos * [R l]_x * R agrees with (2).
  (4) validateRtkDD rejects truncated arrays, NaN/Inf, zero sigmas, short n,
      partially populated optional arrays and sat == ref.

Exit code 0 = all checks pass, 1 = at least one failure.
*/

#include "rtk_geometry.h"
#include "rtk_validation.h"

#include <Eigen/Dense>
#include <Eigen/Geometry>

#include <cmath>
#include <cstdio>
#include <random>
#include <string>

namespace
{

int g_failures = 0;

void check(bool ok, const std::string &name, double value, double expected,
           double tol)
{
  if (!ok)
  {
    ++g_failures;
    std::printf("FAIL  %-46s value=%.9g expected=%.9g tol=%.3g\n",
                name.c_str(), value, expected, tol);
  }
  else
  {
    std::printf("ok    %-46s value=%.9g expected=%.9g\n", name.c_str(), value,
                expected);
  }
}

Eigen::Matrix3d randomRotation(std::mt19937 &rng)
{
  std::uniform_real_distribution<double> angle(-M_PI, M_PI);
  std::normal_distribution<double> axis(0.0, 1.0);
  Eigen::Vector3d a(axis(rng), axis(rng), axis(rng));
  if (a.norm() < 1e-9) a = Eigen::Vector3d::UnitZ();
  a.normalize();
  return Eigen::AngleAxisd(angle(rng), a).toRotationMatrix();
}

void testGeometryJacobian(std::mt19937 &rng)
{
  std::uniform_real_distribution<double> pdist(-500.0, 500.0);
  std::uniform_real_distribution<double> sdist(-2.0e7, 2.0e7);

  for (int trial = 0; trial < 20; ++trial)
  {
    const Eigen::Vector3d p(pdist(rng), pdist(rng), pdist(rng));
    const Eigen::Vector3d sat(sdist(rng), sdist(rng), sdist(rng));
    const Eigen::Vector3d ref(sdist(rng), sdist(rng), sdist(rng));

    const Eigen::Matrix<double, 1, 3> H =
        fast_livo::ddGeometryJacobian(p, sat, ref);
    // 1 m step: with ECEF ranges of ~2e7 m a smaller step loses the difference
    // to double-precision cancellation, while the truncation error is O(eps^2/R)
    // and therefore negligible.
    const double eps = 1.0;

    for (int axis = 0; axis < 3; ++axis)
    {
      Eigen::Vector3d e = Eigen::Vector3d::Zero();
      e(axis) = 1.0;
      const double hp = fast_livo::ddGeometry(p + eps * e, sat, ref);
      const double hm = fast_livo::ddGeometry(p - eps * e, sat, ref);
      const double fd = (hp - hm) / (2.0 * eps);
      check(std::fabs(fd - H(0, axis)) < 1e-6,
            "dd geometry d/dp axis " + std::to_string(axis), H(0, axis), fd,
            1e-6);
    }

    // The residual is z - h; moving p toward the satellite decreases the range
    // to that satellite, so h decreases.
    const Eigen::Vector3d toward_sat = (sat - p).normalized();
    const double h0 = fast_livo::ddGeometry(p, sat, ref);
    const double h1 = fast_livo::ddGeometry(p + 0.01 * toward_sat, sat, ref);
    check(h1 < h0 - 1e-6, "dd geometry decreases toward satellite", h1, h0,
          1e-6);
  }

  // Negative control: the pre-P0 expression (u_ref - u_sat) must be far from
  // the finite-difference derivative. If a future edit reintroduces it, the
  // finite-difference checks above fail; this line documents the magnitude.
  {
    const Eigen::Vector3d p0(0.0, 0.0, 0.0);
    const Eigen::Vector3d s0(1.0, 0.0, 0.0);
    const Eigen::Vector3d r0(0.0, 1.0, 0.0);
    const Eigen::Matrix<double, 1, 3> correct =
        fast_livo::ddGeometryJacobian(p0, s0, r0);
    const Eigen::Matrix<double, 1, 3> old_sign =
        (fast_livo::ddUnit(p0, r0) - fast_livo::ddUnit(p0, s0)).transpose();
    check((old_sign - correct).norm() > 1.0, "old DD sign is rejected",
          (old_sign - correct).norm(), 0.0, 1.0);
  }
}

void testLeverArmJacobian(std::mt19937 &rng)
{
  std::normal_distribution<double> nd(0.0, 0.4);
  for (int trial = 0; trial < 20; ++trial)
  {
    const Eigen::Matrix3d R = randomRotation(rng);
    const Eigen::Vector3d lever(nd(rng), nd(rng), nd(rng));
    Eigen::Matrix<double, 1, 3> H_pos;
    H_pos << nd(rng), nd(rng), nd(rng);

    const Eigen::Matrix<double, 1, 3> H =
        fast_livo::leverArmAttitudeJacobian(H_pos, R, lever);
    const double eps = 1e-6;

    for (int axis = 0; axis < 3; ++axis)
    {
      Eigen::Vector3d e = Eigen::Vector3d::Zero();
      e(axis) = 1.0;
      const Eigen::Matrix3d Rp = R * Eigen::AngleAxisd(eps, e).toRotationMatrix();
      const Eigen::Matrix3d Rm = R * Eigen::AngleAxisd(-eps, e).toRotationMatrix();
      const double fp = (H_pos * (Rp * lever))(0, 0);
      const double fm = (H_pos * (Rm * lever))(0, 0);
      const double fd = (fp - fm) / (2.0 * eps);
      check(std::fabs(fd - H(0, axis)) < 1e-6,
            "lever attitude d/dtheta axis " + std::to_string(axis), H(0, axis),
            fd, 1e-6);
    }

    // Cached equivalent: [R l]_x = R [l]_x R^T, so -[R l]_x R = -R [l]_x.
    const Eigen::Matrix<double, 1, 3> cached =
        -H_pos * fast_livo::skewSymmetric(R * lever) * R;
    check((cached - H).norm() < 1e-9, "cached lever Jacobian", cached.norm(),
          H.norm(), 1e-9);
  }
}

fast_livo::RtkDD makeValidMessage(int n)
{
  fast_livo::RtkDD msg;
  msg.n = static_cast<uint8_t>(n);
  msg.sys.assign(n, "G");
  msg.freq.assign(n, "L1");
  msg.sat.assign(n, "G01");
  msg.ref_sat.assign(n, "G13");
  msg.dd_code.assign(n, 1.0);
  msg.dd_phase.assign(n, 0.5);
  msg.sat_x.assign(n, 2.0e7);
  msg.sat_y.assign(n, 1.0e7);
  msg.sat_z.assign(n, 1.5e7);
  msg.ref_x.assign(n, 2.1e7);
  msg.ref_y.assign(n, 1.1e7);
  msg.ref_z.assign(n, 1.6e7);
  msg.sigma_code.assign(n, 0.5);
  msg.sigma_phase.assign(n, 0.01);
  msg.slip.assign(n, 0);
  msg.ref_change.assign(n, 0);
  for (int i = 0; i < n; ++i) msg.sat[i] = "G0" + std::to_string(i + 1);
  return msg;
}

void testValidation()
{
  check(fast_livo::validateRtkDD(makeValidMessage(4)).ok, "valid message", 1.0,
        1.0, 0.0);

  {
    auto m = makeValidMessage(4);
    m.sat_y.resize(3);
    check(!fast_livo::validateRtkDD(m).ok, "missing sat_y", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.dd_phase[0] = std::nan("");
    check(!fast_livo::validateRtkDD(m).ok, "NaN dd_phase", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.sigma_code[1] = 0.0;
    check(!fast_livo::validateRtkDD(m).ok, "zero sigma_code", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.sigma_phase[2] = -1.0;
    check(!fast_livo::validateRtkDD(m).ok, "negative sigma_phase", 0.0, 1.0,
          0.0);
  }
  {
    auto m = makeValidMessage(2);
    check(!fast_livo::validateRtkDD(m).ok, "n < 3", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.fix_valid.assign(3, 1);
    check(!fast_livo::validateRtkDD(m).ok, "partial fix_valid", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.sat[0] = m.ref_sat[0];
    check(!fast_livo::validateRtkDD(m).ok, "sat equals ref", 0.0, 1.0, 0.0);
  }
  {
    auto m = makeValidMessage(4);
    m.fix_valid.assign(4, 1);
    m.dd_phase_fixed.assign(4, 0.5);
    m.sigma_phase_fixed.assign(4, 0.02);
    check(fast_livo::validateRtkDD(m).ok, "complete fixed arrays", 1.0, 1.0,
          0.0);
  }
}

}  // namespace

int main()
{
  std::mt19937 rng(20261104u);
  testGeometryJacobian(rng);
  testLeverArmJacobian(rng);
  testValidation();

  if (g_failures == 0)
  {
    std::printf("\nPASS: all RTK geometry/validation checks\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
