#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert the Phase-1 DD CSV into a ROS bag on /rtk/dd.

Usage (inside the ROS/catkin environment):
  source /opt/ros/noetic/setup.bash
  source ~/catkin_ws/devel/setup.bash
  python3 dd_csv_to_bag.py --csv .../c01_dd_gps_bds.csv --bag .../c01_dd_gps_bds.bag
"""
import argparse
import csv
import os

import rospy
import rosbag
from fast_livo.msg import RtkDD


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--bag", required=True)
    ap.add_argument("--topic", default="/rtk/dd")
    args = ap.parse_args()

    rows = []
    with open(args.csv, newline="") as f:
        for r in csv.DictReader(f):
            rows.append(r)
    if not rows:
        raise SystemExit("empty CSV")

    # group by GPS epoch (1 Hz, all bands/pairs in one message)
    groups = {}
    for r in rows:
        key = float(r["t_gps"])
        groups.setdefault(key, []).append(r)

    os.makedirs(os.path.dirname(os.path.abspath(args.bag)), exist_ok=True)
    bag = rosbag.Bag(args.bag, "w")
    nmsg = 0
    for t_gps in sorted(groups):
        rr = groups[t_gps]
        m = RtkDD()
        m.header.stamp = rospy.Time.from_sec(float(rr[0]["t_unix"]))
        m.header.frame_id = "rtk_dd"
        m.t_gps = t_gps
        m.ratio = float(rr[0].get("ratio", 0.0))
        m.n = len(rr)
        slips = []
        ref_changes = []
        fix_valid = []
        phase_fixed = []
        sigma_fixed = []
        has_fix = "fix_valid" in rr[0]
        has_sigma = "sigma_phase_fixed" in rr[0]
        for r in rr:
            m.sys.append(r["sys"])
            m.freq.append(r["freq"])
            m.ref_sat.append(r["ref_sat"])
            m.sat.append(r["sat"])
            m.dd_code.append(float(r["dd_code"]))
            m.dd_phase.append(float(r["dd_phase"]))
            if has_fix:
                fix_valid.append(int(r["fix_valid"]))
                phase_fixed.append(float(r.get("dd_phase_fixed", r["dd_phase"])))
            if has_sigma:
                sigma_fixed.append(float(r.get("sigma_phase_fixed", 0.0)))
            m.sat_x.append(float(r["sat_x"]))
            m.sat_y.append(float(r["sat_y"]))
            m.sat_z.append(float(r["sat_z"]))
            m.ref_x.append(float(r["ref_x"]))
            m.ref_y.append(float(r["ref_y"]))
            m.ref_z.append(float(r["ref_z"]))
            m.elev_sat.append(float(r["elev_sat"]))
            m.elev_ref.append(float(r["elev_ref"]))
            m.sigma_code.append(float(r["sigma_code"]))
            m.sigma_phase.append(float(r["sigma_phase"]))
            slips.append(int(r["slip"]))
            ref_changes.append(int(r["ref_change"]))
        m.slip = bytes(slips)
        m.ref_change = bytes(ref_changes)
        if has_fix:
            m.fix_valid = bytes(fix_valid)
            m.dd_phase_fixed = phase_fixed
        if has_sigma:
            m.sigma_phase_fixed = sigma_fixed
        bag.write(args.topic, m, t=m.header.stamp)
        nmsg += 1
    bag.close()
    print(f"wrote {args.bag}: {nmsg} messages, {len(rows)} DD rows, topic {args.topic}")


if __name__ == "__main__":
    main()
