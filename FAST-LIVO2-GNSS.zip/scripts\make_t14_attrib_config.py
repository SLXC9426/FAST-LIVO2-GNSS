#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""T1-4 c01-regression attribution arm: auto q + explicit sigma_yaw0 = 1.0 deg.

The held-out batch (EVAL_PROTOCOL 26) left the c01 regression (auto 1.0855 /
stat_gf 1.99 vs explicit-q3 0.924 / 1.70) unattributed. The consistency account
says auto q on c01 IS 0.03 = q3, so the suspects are sigma_yaw0 (1.0 -> 0.35,
8x variance), FORCED-disabled lock timing, the binary change, or sampling.
This arm changes ONLY sigma_yaw0 back to 1.0 (all else auto): if it reproduces
the q3 batch numbers, sigma_yaw0 is the main cause; if not, the remaining
suspects move to the front. Review 12.4 ordering.

Usage: make_t14_attrib_config.py -> config/great_campus01_alignstate_yaw0fix.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

BLOCK = """\
{i}# T1-4 attribution arm (review 12.4): auto q, explicit sigma_yaw0=1.0 deg.
{i}align_state_en: true
{i}align_sigma_yaw0_deg: 1.0
"""


def main():
    base = os.path.join(HERE, os.pardir, "config", "great_campus01.yaml")
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()
    out, inserted = [], False
    for ln in lines:
        m = re.match(r"^(\s*)outlier_rejection:", ln)
        if m and not inserted:
            out.append(BLOCK.format(i=m.group(1)))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor not found")
    dst = os.path.join(HERE, os.pardir, "config",
                       "great_campus01_alignstate_yaw0fix.yaml")
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote", os.path.normpath(dst))


if __name__ == "__main__":
    main()
