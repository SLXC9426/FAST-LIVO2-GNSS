# 审查后运行入口（2026-11-06）

当前工作目录是提取快照，无 Git 历史。项目根目录 `执行记录/2026-11-06_修复/` 保存修复前归档、输入/源码哈希、评估更正表及验收日志；`docs/*_evidence` 为历史证据，不作为当前运行脚本入口。

后续核查发现原 `campus0X_rtk1hz.tum` 与 FIXBASE 质量 CSV 的位置不一致。当前 `replay_backend.py` / `feed_online_graph.py` 在绑定质量前检查公共精确历元的位置能否通过一个刚体变换一致到 1 mm，发现差异就拒绝。该必要检查不能替代完整来源清单。历史同输入质量归因须重做，不能沿用“时间戳相同即同源”的假设。

从同一解算行生成新观察臂可使用 `scripts/dev/quality_csv_to_bag.py`，显式传入 CSV、时间范围及全新输出路径。生成位置＋质量 bag、ENU TUM 和原点/哈希清单；它是新输入版本，不是冻结基线的替换文件。

全链路入口 `scripts/eval/replay_sensor_bags.py` 要求显式指定前端/图节点、传感器包、同源观察包、配置、相机配置、全新结果目录。支持 matched/absent/bypass 三种质量通道模式，按实际传感器话题的索引确定时间范围，并核对包含结束端点的实收消息数。`debug/runtime_log_dir` 将本次全部运行日志隔离到结果目录；默认仍为原 Log 路径。`gnss/quality_source` 默认 ublox，离线 CSV 实验显式设为 rtklib_csv。

## 构建与回归

在已加载 ROS Noetic、vikit 等依赖的 shell 中，从源码目录配置新的构建目录；消息生成是消费目标的正式依赖，不需要预生成头文件。`BUILD_ONLINE_GRAPH=OFF` 用于只构建前端。

新增回归：`gnss_epoch_pairer_selftest`、`graph_fit_mask_selftest`；既有 `static_anchor_validity_selftest` 增加非有限输入与重复历元检查。评估回归使用 `python3 -B test/eval_ate_selftest.py`，需 numpy。

## 同输入后端回放

入口 `scripts/eval/replay_backend.py` 要求显式指定：

```
python3 -B scripts/eval/replay_backend.py \
  --node <本次构建/devel/lib/fast_livo/online_graph_node> \
  --livo <LIO.tum> --rtk <RTK.tum> --reference <参考.tum> \
  --quality-csv <质量.csv> --out <全新实验目录> \
  --speed 1 --port 11461
```

先加 `--dry-run` 检查输入并生成清单。实际回放前加载 ROS 和本次构建的 `devel/setup.bash`。输出目录必须不存在；脚本启动独立 master，只清理自己启动的进程，并将节点目录的 lib 放在动态库搜索首位。该入口默认关闭分类/创新/两遍/Huber/静态锚有效性门，开启 A1；更改参数通过 `--params-json`，最终参数完整写入 manifest。

正常脚本 `feed_online_graph.py` 来源于冻结 A2.2 feeder，保留质量字段适配；显式质量/状态路径缺失会报错。未传状态表时，由质量 CSV 的 Fixed/Float/DGPS/Single 映射状态，缺失历元为 unknown，不虚构 Fixed。因而与旧 harness 对比时必须两臂使用相同 feeder 与参数，不能默认其状态标签完全相同。

`--reference` 只登记评价输入，不向图优化器发布参考位置。后续评价使用项目 `04_执行记录/03_A0-A4优化/eval_ate.py` 修正版；历史版本的 ATE 表格需查阅更正表。

## 在线质量配对

- `common/gnss_quality_topic` 非空时，精确配对位置与质量，先后顺序不影响关联。保持原有默认话题 `/gnss/quality`。
- `gnss/quality_wait_sec` 默认 0.2 秒；`gnss/quality_capacity` 默认 1000，必须为正。墙钟定时器每 20 ms 尝试释放，实际等待以单调接收时钟衡量，不依赖 /clock 推进。
- 到期仍缺质量则以 unknown 处理位置一次；晚到质量不追补，重复/落后于已处理水位的历元不再更新。较晚完成的配对不会越过较早待处理的位置。
- 缓存满时明确拒绝新入队并计 overflow；收到 ROS 时钟回拨时清空配对缓存并记录 reset。日志包含匹配、超时、晚到、重复/乱序、溢出、过期与待处理数。
- 将质量话题设为空字符串可禁用等待并立即处理位置。原有默认质量话题非空，在没有质量发布者时会等待到期；这会改变位置进入估计器的时刻，真实 bag 的延迟与同步容差仍需验收，不能用后端 TUM 重放替代。

转发脚本正常入口 `scripts/gnss_pvt_relay.py` 由冻结证据复制；不依靠它先发布哪个话题保证正确性。必须使用当前构建生成的消息包。

## 未完成

A3.1 统一在线规则、A3.2 锚输入、A4 权重解耦与原始 bag 的完整精度验收继续按执行方案推进。修复异常值放行，不等于已证明静态锚绝对准确；修复两遍筛选，也不等于已取得精度收益。实验门控/拟合功能默认开关保持原状态。
