#!/usr/bin/env python3
import numpy as np

rows = []
with open("/home/slxc9426/datasets/GREAT/IMU/Tactical_imu_data.txt") as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#") or "ime" in line:
            continue
        rows.append([float(x) for x in line.split()])
a = np.array(rows)
print("gyr abs max whole:", np.abs(a[:, 1:4]).max(0))
print("gyr std whole:", a[:, 1:4].std(0))
for tag, t0 in [("t=100", 180689.0), ("t=300", 180889.0)]:
    i = np.argmin(np.abs(a[:, 0] - t0))
    w = a[i : i + 2000, 1:4]
    print("%s: gyr std %s absmax %s" % (tag, w.std(0).round(4), np.abs(w).max(0).round(4)))
