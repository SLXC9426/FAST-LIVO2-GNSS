#!/usr/bin/env bash
# run all 6 modes on campus-01 inside WSL, then evaluate
# (no set -u: the ROS setup scripts reference unset variables)
source /opt/ros/noetic/setup.bash
source ~/catkin_ws/devel/setup.bash
cd ~/catkin_ws/src/fast_livo
mkdir -p Log/eval

MODES="${MODES:-baseline occlusion dynamic graph improved improved_gnss}"
BAG=~/campus-01.bag
START="${START:--s 285}"
DUR="${DUR:--u 610}"

for mode in $MODES; do
  echo "########## $mode ##########" | tee -a /tmp/campus_modes.log
  roslaunch fast_livo mapping_great_campus01.launch mode:=$mode rviz:=false > /tmp/livo_$mode.log 2>&1 &
  LPID=$!
  sleep 15
  /opt/ros/noetic/bin/rosbag play $START $DUR $BAG --clock > /tmp/play_$mode.log 2>&1
  sleep 8
  kill $LPID 2>/dev/null
  sleep 4
  pkill -f fastlivo_mapping 2>/dev/null
  sleep 2
  N=$(wc -l < Log/result/great_campus01_$mode.txt 2>/dev/null || echo 0)
  echo "$mode: trajectory lines = $N" | tee -a /tmp/campus_modes.log
done
echo "ALL MODES DONE" | tee -a /tmp/campus_modes.log
