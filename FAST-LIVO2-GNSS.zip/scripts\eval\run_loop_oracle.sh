#!/bin/bash
# LOOP-ORACLE-1: c01/c02 N=3, base / oracle / shuffled arms.
# Pre-registration: gv1/oracle/PRE_REG.md. Oracle loops are evaluation-only.
export LANG=C.UTF-8
# gnss_bag_to_tum.py imports rosbag; source ROS before invoking the tools.
source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
ROOT=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/gv1
OUT=$ROOT/oracle
RES=$HOME/catkin_ws/src/fast_livo/Log/result
G=$HOME/datasets/GREAT
REF=$HOME/eval_great
TOOL=$REPO/scripts/eval/global_position_graph.py
CONV=$REPO/scripts/eval/gnss_bag_to_tum.py

mkdir -p "$OUT"
SUM=$OUT/loop_oracle_summary.txt
: > "$SUM"
echo "=== LOOP-ORACLE-1 | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum "$HOME/catkin_ws/devel/lib/liblaser_mapping.so" | cut -c1-8)" | tee -a "$SUM"
echo "pre-reg: $OUT/PRE_REG.md" | tee -a "$SUM"
echo "tool: $(md5sum "$TOOL" | cut -c1-8)" | tee -a "$SUM"

# Convert the 1 Hz RTK bags once; the graph tool accepts TUM directly.
for seq in campus01 campus02; do
  RTK_TUM=$OUT/${seq}_rtk1hz.tum
  if [ ! -s "$RTK_TUM" ]; then
    python3 "$CONV" "$G/${seq}_rtk1hz.bag" /gnss_rtk "$RTK_TUM" 2>&1 | tee -a "$SUM"
  fi
done

WINS_C01="--win 0:150 --win 150:300 --win 300:450 --win 450:607"
WINS_C02="--win 0:150 --win 150:300 --win 300:450 --win 450:600 --win 600:806"
COMMON="--auto-sigma-rtk --auto-odom --huber-xy 3.0 --static-hold --static-hold-expand 5"

run_arm () {
  local SEQ=$1 K=$2 ARM=$3
  local TAG="gv1_${SEQ}_livo_r${K}"
  local LIVO=$RES/${TAG}.txt
  local RTK=$OUT/${SEQ}_rtk1hz.tum
  local REFT=$REF/${SEQ}_reference.tum
  local ARM_TAG="${TAG}_${ARM}"
  local OUT_TUM=$OUT/${ARM_TAG}.tum
  local WINS=$WINS_C01
  [ "$SEQ" = "campus02" ] && WINS=$WINS_C02
  if [ ! -f "$LIVO" ]; then
    echo "!! missing $LIVO" | tee -a "$SUM"
    return 1
  fi
  echo "" | tee -a "$SUM"
  echo "######## $ARM_TAG ########" | tee -a "$SUM"
  local EXTRA=""
  case "$ARM" in
    base)
      ;;
    oracle)
      EXTRA="--oracle-loops $REFT --loop-sigma-xy 0.1 --loop-report $OUT/${ARM_TAG}_loops.tsv"
      ;;
    shuffled)
      EXTRA="--oracle-loops $REFT --loop-sigma-xy 0.1 --shuffle-loops --loop-shuffle-seed 0 --loop-report $OUT/${ARM_TAG}_loops.tsv"
      ;;
    *)
      echo "!! unknown arm $ARM" | tee -a "$SUM"
      return 1
      ;;
  esac
  python3 "$TOOL" --livo "$LIVO" --rtk "$RTK" --ref "$REFT" \
    --out "$OUT_TUM" --tag "$ARM_TAG" $COMMON $WINS $EXTRA 2>&1 | tee -a "$SUM"
  local rc=${PIPESTATUS[0]}
  echo "EXIT_${ARM_TAG}=$rc" | tee -a "$SUM"
  return $rc
}

FAIL=0
for seq in campus01 campus02; do
  for k in 1 2 3; do
    for arm in base oracle shuffled; do
      run_arm "$seq" "$k" "$arm" || FAIL=$((FAIL + 1))
    done
  done
done

echo "" | tee -a "$SUM"
echo "LOOP_ORACLE_FAIL=$FAIL" | tee -a "$SUM"
echo "LOOP_ORACLE_DONE $(date +%T)" | tee -a "$SUM"
exit $([ "$FAIL" -eq 0 ] && echo 0 || echo 1)
