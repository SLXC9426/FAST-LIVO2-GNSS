#!/usr/bin/env python3
"""Patch save_gps_fix_data: drop GNSS fixes outside the LiDAR time range.

The E-drive gnss.pos (64 rows, 30 s spacing) starts ~289 s BEFORE the LiDAR
data (180300 vs 180589 GPS s). When such fixes are written first, the bag time
origin is pulled back 289 s: rosbag play -s 0 then plays 289 s of GNSS-only
data before any LiDAR/IMU arrives, the estimator's time base is corrupted and
the run diverges (120 km trajectories observed). Keeping only fixes >= the
first LiDAR frame keeps the bag origin on the LiDAR start.
"""
import io

p = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/rawdata2bag_great.py"
txt = io.open(p, encoding="utf-8").read()

old = """    i_count = 0
    for data_line in zip(gnss_data):
        data = data_line[0].split()
        navsatfix_msg = NavSatFix()
        i_count = i_count + 1
        timestamp = float(data[0]) + 604800*2129 + UNIX_GPS_DIF - LEAPSEC
        navsatfix_msg.header.seq = i_count"""
new = """    # first LiDAR frame time: GNSS fixes before it would pull the bag time
    # origin away from the LiDAR stream (see module docstring)
    lidar_t0 = None
    lidar_ts_path = os.path.join(whu.data_path, 'Lidar', 'timestamps.txt')
    if os.path.exists(lidar_ts_path):
        with open(lidar_ts_path, 'r') as f:
            for line in f:
                line = line.strip()
                if not line or line[0] == '#' or 'ime' in line:
                    continue
                lidar_t0 = float(line.split(',')[0]) + 604800*2129 + UNIX_GPS_DIF - LEAPSEC
                break

    i_count = 0
    for data_line in zip(gnss_data):
        data = data_line[0].split()
        navsatfix_msg = NavSatFix()
        i_count = i_count + 1
        timestamp = float(data[0]) + 604800*2129 + UNIX_GPS_DIF - LEAPSEC
        if lidar_t0 is not None and timestamp < lidar_t0 - 0.01:
            i_count = i_count - 1
            continue
        navsatfix_msg.header.seq = i_count"""
assert old in txt, "gnss block not found"
txt = txt.replace(old, new)
io.open(p, "w", encoding="utf-8").write(txt)
print("gnss time-range filter patched")
