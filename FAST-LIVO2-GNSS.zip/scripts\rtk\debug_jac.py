import numpy as np
import pandas as pd
from rtk_preprocess import _dd_geom, _dd_jac

p = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval/raw/c01_dd_gps_bds.csv"
d = pd.read_csv(p)
base = np.array([-2267749.9279, 5009154.2407, 3221290.6333])
for i in [0, 5, 10]:
    row = d.iloc[i].to_dict()
    x = base
    H = _dd_jac(row, x)
    print("row", i, row["sys"], row["freq"], row["sat"])
    for k in range(3):
        eps = np.zeros(3); eps[k] = 1.0
        num = _dd_geom(row, x + eps, base) - _dd_geom(row, x, base)
        print(f"  axis {k}: numeric={num:+.6f} analytic={H[k]:+.6f}")
