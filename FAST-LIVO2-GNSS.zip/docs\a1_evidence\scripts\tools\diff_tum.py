#!/usr/bin/env python3
"""Compare two TUM files: row count, timestamp alignment, position/orientation."""
import argparse

import numpy as np


def load(path):
    d = np.loadtxt(path)
    return d


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("a")
    ap.add_argument("b")
    ap.add_argument("--tol", type=float, default=0.01)
    args = ap.parse_args()

    a, b = load(args.a), load(args.b)
    print(f"rows: {a.shape[0]} vs {b.shape[0]}")
    n = min(a.shape[0], b.shape[0])
    dt = np.abs(a[:n, 0] - b[:n, 0])
    dp = np.linalg.norm(a[:n, 1:4] - b[:n, 1:4], axis=1)
    print(f"max |dt| = {dt.max():.6f} s   max |dp| = {dp.max():.6g} m")
    print(f"median |dp| = {np.median(dp):.6g} m   identical = "
          f"{np.array_equal(a, b)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
