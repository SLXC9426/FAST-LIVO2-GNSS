#!/usr/bin/env python3
"""A2.2: distribution of the unified quality classification in a trace."""
import argparse
import csv
from collections import Counter, defaultdict

import numpy as np


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("traces", nargs="+")
    ap.add_argument("--segments", default="")
    args = ap.parse_args()

    for path in args.traces:
        with open(path, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        if not rows:
            print(f"{path}: empty")
            continue
        classes = Counter(r["q_class"] for r in rows)
        reasons = Counter(r["q_reason"] for r in rows if r["q_reason"])
        sources = Counter(r["q_source"] or "none" for r in rows)
        print(f"\n## {path}")
        print(f"rows={len(rows)} classes={dict(classes)}")
        print(f"sources={dict(sources)}")
        if reasons:
            print(f"reasons={dict(reasons)}")

        # factor rate per class (for B2 planning; gating is not applied here)
        by_class = defaultdict(lambda: [0, 0])
        for r in rows:
            c = r["q_class"]
            by_class[c][0] += 1
            by_class[c][1] += int(r["factor"])
        print("class -> rows / factors / rate:")
        for c in sorted(by_class):
            n, k = by_class[c]
            print(f"  {c:<9} {n:5d} {k:5d} {k / n:.3f}")

        if args.segments:
            t = np.array([float(r["t_fix"]) for r in rows])
            t0 = t.min()
            for chunk in args.segments.split(","):
                a, b = (float(x) for x in chunk.split("-"))
                sel = (t - t0 >= a) & (t - t0 <= b)
                c = Counter(rows[i]["q_class"] for i in np.where(sel)[0])
                print(f"  {a:g}-{b:g}s: {dict(c)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
