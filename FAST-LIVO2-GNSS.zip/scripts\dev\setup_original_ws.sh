#!/bin/bash
# Set up a SEPARATE catkin workspace holding the ORIGINAL (vanilla) FAST-LIVO2,
# for the LIVO / LIO / VIO ablation on the GREAT campus data.
#
# Why a separate workspace: the original package is also called fast_livo and
# defines the same CMake targets (vio, lio, laser_mapping, fastlivo_mapping) as
# our modified package. Two packages cannot define the same target inside one
# CMake project, so it cannot simply be dropped into ~/catkin_ws/src next to
# ours. A second workspace also keeps our own build untouched.
set -e
WIN="/mnt/c/Users/张浩/Desktop/FAST-LIVO2原版/FAST-LIVO2-main/FAST-LIVO2-main"
OURS="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main"
WS=$HOME/catkin_ws_orig
DST=$WS/src/fast_livo

echo "=== workspace ==="
rm -rf "$WS"
mkdir -p "$WS/src"
cd "$WS/src"
source /opt/ros/noetic/setup.bash
catkin_init_workspace

# dependency packages built in our main workspace: reuse the sources via symlink
for p in Sophus rpg_vikit; do
  if [ -d "$HOME/catkin_ws/src/$p" ]; then
    ln -s "$HOME/catkin_ws/src/$p" "$WS/src/$p"
    echo "  linked $p"
  else
    echo "  !! missing dependency source: $p"
  fi
done

echo "=== original source ==="
mkdir -p "$DST"
cp -r "$WIN/src" "$WIN/include" "$WIN/config" "$WIN/launch" "$WIN/rviz_cfg" "$DST/"
cp "$WIN/CMakeLists.txt" "$WIN/package.xml" "$DST/"
cp "$OURS/scripts/dev/mapping_great_orig.launch" "$DST/launch/"
cp "$OURS/config/great_campus01.yaml" "$OURS/config/great_campus02.yaml" \
   "$OURS/config/camera_great.yaml" "$DST/config/"
mkdir -p "$DST/Log/result"
echo "  copied $(ls "$DST/src" | wc -l) sources"

echo "=== build (own workspace) ==="
cd "$WS"
catkin_make -j8 > /tmp/orig_build.log 2>&1 || {
  grep -E "error|Error" /tmp/orig_build.log | head -20
  echo "ORIG_BUILD_FAILED"; exit 1
}
ls -la --time-style=long-iso "$WS/devel/lib/fast_livo/fastlivo_mapping"
echo ORIG_SETUP_DONE
