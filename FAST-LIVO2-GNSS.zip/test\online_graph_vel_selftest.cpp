/*
R5.5 regression: the OnlineGraphVel header must carry the time-offset-adjusted
epoch, not the raw receiver stamp. The online graph interpolates velocity nodes
by this stamp; using the raw stamp silently ignores time_offset/gnss_vel_time_offset.

Exit code 0 = pass, 1 = failure.
*/

#include "online_graph_vel_utils.h"

#include <cmath>
#include <cstdio>

int main()
{
  int failures = 0;
  auto check = [&](bool ok, const char *name, double value, double expected) {
    std::printf("%s  %-38s value=%.9f expected=%.9f\n", ok ? "ok  " : "FAIL",
                name, value, expected);
    if (!ok) ++failures;
  };

  const Eigen::Vector3d v(1.5, -2.0, 0.25);
  const fast_livo::OnlineGraphVel a =
      fast_livo::makeOnlineGraphVelMsg(1000.25, 0.25, v, 0.2, 0.3, "ins");
  check(std::fabs(a.header.stamp.toSec() - 1000.0) < 1e-9,
        "non-zero offset stamp", a.header.stamp.toSec(), 1000.0);
  check(std::fabs(a.vel_enu.x - 1.5) < 1e-12, "vel x", a.vel_enu.x, 1.5);
  check(std::fabs(a.vel_enu.y + 2.0) < 1e-12, "vel y", a.vel_enu.y, -2.0);
  check(std::fabs(a.vel_enu.z - 0.25) < 1e-12, "vel z", a.vel_enu.z, 0.25);
  check(std::fabs(a.sigma_h - 0.2) < 1e-12, "sigma_h", a.sigma_h, 0.2);
  check(std::fabs(a.sigma_v - 0.3) < 1e-12, "sigma_v", a.sigma_v, 0.3);
  check(a.source == "ins", "source", a.source == "ins" ? 1.0 : 0.0, 1.0);

  const fast_livo::OnlineGraphVel b =
      fast_livo::makeOnlineGraphVelMsg(2000.5, 0.0, v, 0.1, 0.2, "doppler");
  check(std::fabs(b.header.stamp.toSec() - 2000.5) < 1e-9, "zero offset stamp",
        b.header.stamp.toSec(), 2000.5);
  check(b.source == "doppler", "source doppler",
        b.source == "doppler" ? 1.0 : 0.0, 1.0);

  if (failures == 0)
  {
    std::printf("\nPASS: OnlineGraphVel time offset\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", failures);
  return 1;
}
