#ifndef GNSS_QUALITY_CACHE_H_
#define GNSS_QUALITY_CACHE_H_

// A2.1: exact-timestamp cache between the GNSS quality message and the
// NavSatFix of the SAME solution. The relay publishes both from one PVT
// callback, so the stamps are identical; a nearest-neighbour match would risk
// attaching the previous epoch's satellite count/DOP to the current fix, which
// is worse than having no quality at all. Header-only so the matching contract
// is unit-tested without ROS.

#include <cstdint>
#include <map>
#include <string>

namespace fast_livo
{

struct GnssQualityRecord
{
  bool valid = false;
  uint8_t num_sv = 0;
  double p_dop = 0.0;
  uint32_t h_acc_mm = 0;
  uint32_t v_acc_mm = 0;
  uint8_t carr_soln = 0;
  uint8_t fix_type = 0;
  bool has_p_dop = false;
  bool has_h_acc = false;
  bool has_v_acc = false;
  std::string source;  // "ublox" or "rtklib", trace only
};

class GnssQualityCache
{
public:
  explicit GnssQualityCache(double expiry_s = 5.0) : expiry_s_(expiry_s) {}

  // Inserts under the raw ROS stamp in nanoseconds. A duplicate stamp is
  // rejected (and counted): the same epoch must not overwrite or multiply.
  bool insert(uint64_t stamp_ns, const GnssQualityRecord &r)
  {
    if (records_.find(stamp_ns) != records_.end())
    {
      ++duplicates_;
      return false;
    }
    records_.emplace(stamp_ns, r);
    return true;
  }

  // Exact match only; removes the record on success so one quality message can
  // never serve two fixes.
  bool take(uint64_t stamp_ns, GnssQualityRecord *out)
  {
    const auto it = records_.find(stamp_ns);
    if (it == records_.end())
    {
      ++unmatched_;
      return false;
    }
    if (out) *out = it->second;
    records_.erase(it);
    ++matched_;
    return true;
  }

  // Drops records older than expiry_s_ relative to now_ns.
  void prune(uint64_t now_ns)
  {
    const uint64_t expiry_ns =
        static_cast<uint64_t>(expiry_s_ * 1e9 > 0.0 ? expiry_s_ * 1e9 : 0.0);
    const uint64_t cut = now_ns > expiry_ns ? now_ns - expiry_ns : 0;
    while (!records_.empty() && records_.begin()->first < cut)
    {
      records_.erase(records_.begin());
      ++expired_;
    }
  }

  std::size_t size() const { return records_.size(); }
  uint64_t matched() const { return matched_; }
  uint64_t unmatched() const { return unmatched_; }
  uint64_t duplicates() const { return duplicates_; }
  uint64_t expired() const { return expired_; }

private:
  std::map<uint64_t, GnssQualityRecord> records_;
  double expiry_s_;
  uint64_t matched_ = 0;
  uint64_t unmatched_ = 0;
  uint64_t duplicates_ = 0;
  uint64_t expired_ = 0;
};

}  // namespace fast_livo

#endif  // GNSS_QUALITY_CACHE_H_
