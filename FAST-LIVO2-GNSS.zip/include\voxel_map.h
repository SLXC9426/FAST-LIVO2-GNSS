/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.

Developer: Chunran Zheng <zhengcr@connect.hku.hk>

For commercial use, please contact me at <zhengcr@connect.hku.hk> or
Prof. Fu Zhang at <fuzhang@hku.hk>.

This file is subject to the terms and conditions outlined in the 'LICENSE' file,
which is included as part of this source code package.
*/

#ifndef VOXEL_MAP_H_
#define VOXEL_MAP_H_

#include "common_lib.h"
#include "raycast.h"
#include <Eigen/Dense>
#include <fstream>
#include <math.h>
#include <mutex>
#include <omp.h>
#include <pcl/common/io.h>
#include <ros/ros.h>
#include <thread>
#include <unistd.h>
#include <unordered_map>
#include <visualization_msgs/Marker.h>
#include <visualization_msgs/MarkerArray.h>

#define VOXELMAP_HASH_P 116101
#define VOXELMAP_MAX_N 10000000000

static int voxel_plane_id = 0;

typedef struct VoxelMapConfig
{
  double max_voxel_size_;
  int max_layer_;
  int max_iterations_;
  std::vector<int> layer_init_num_;
  int max_points_num_;
  double planner_threshold_;
  double beam_err_;
  double dept_err_;
  double sigma_num_;
  bool is_pub_plane_map_;

  // config of local map sliding
  double sliding_thresh;
  bool map_sliding_en;
  int half_map_size;

  // occlusion-aware matching (Improvement 1, LIO side)
  bool occlusion_en_;          // enable ray-blocked point rejection
  double occlusion_margin_;    // block must be at least this far before the point (m)
  double occlusion_behind_eps_;// point must be at least this far behind the plane (m)
  int robust_kernel_type_;     // 0 none, 1 huber, 2 cauchy (IRLS on point-to-plane residuals)
  double robust_delta_;        // kernel scale in units of residual sigma
  double reject_gate_scale_;   // gate = reject_gate_scale_ * sigma_num_ * sigma

  // covariance floor (standstill robustness): a long static stretch (e.g. the
  // first 150 s of GREAT urban-01, vehicle idling) collapses the IEKF
  // covariance - and with it the matching gate (sigma_l contains the rot/pos
  // covariance projected through the point geometry). When motion resumes the
  // residuals (0.5~1 m) exceed the tiny gate, ~96% of correspondences are
  // rejected, the weak zero-displacement observation pins the velocity to
  // zero and the estimator freezes at the origin. Clamping the diagonal keeps
  // the gate wide enough to re-lock the motion.
  double min_cov_rot_;   // rotation (rad^2)
  double min_cov_pos_;   // position (m^2)
  double min_cov_vel_;   // velocity (m^2/s^2)
  double min_cov_expo_;  // inverse exposure time
  double min_cov_bias_;  // IMU biases
  double min_cov_grav_;  // gravity estimate

  // dynamic object removal (Improvement 3)
  bool dynamic_en_;            // master switch: temporal stats, forgetting, dynamic-plane exclusion
  double dynamic_conflict_thresh_; // |dist to plane| above this counts as a conflict (m)
  double dynamic_ratio_thresh_;    // dynamic_hit_/obs_count_ above this flags the plane dynamic
  int dynamic_obs_min_;            // min observations before the ratio is trusted
  int dynamic_max_idle_frames_;    // voxel idle for N frames -> forgotten (ghost removal)
  int dynamic_check_interval_;     // forgetting sweep every N frames
  bool dynamic_pub_en_;            // publish /dyn_obj, /dyn_obj_removed, /dyn_obj_dbg_hist
} VoxelMapConfig;

typedef struct PointToPlane
{
  Eigen::Vector3d point_b_;
  Eigen::Vector3d point_w_;
  Eigen::Vector3d normal_;
  Eigen::Vector3d center_;
  Eigen::Matrix<double, 6, 6> plane_var_;
  M3D body_cov_;
  int layer_;
  double d_;
  double eigen_value_;
  bool is_valid_;
  float dis_to_plane_;
} PointToPlane;

typedef struct VoxelPlane
{
  Eigen::Vector3d center_;
  Eigen::Vector3d normal_;
  Eigen::Vector3d y_normal_;
  Eigen::Vector3d x_normal_;
  Eigen::Matrix3d covariance_;
  Eigen::Matrix<double, 6, 6> plane_var_;
  float radius_ = 0;
  float min_eigen_value_ = 1;
  float mid_eigen_value_ = 1;
  float max_eigen_value_ = 1;
  float d_ = 0;
  int points_size_ = 0;
  bool is_plane_ = false;
  bool is_init_ = false;
  int id_ = 0;
  bool is_update_ = false;
  // dynamic object removal (Improvement 3) bookkeeping
  int obs_count_ = 0;       // points observed within the plane patch
  int dynamic_hit_ = 0;     // points conflicting with the plane (ray-blocked or far from it)
  float dynamic_score_ = 0; // dynamic_hit_ / max(obs_count_,1)
  bool is_dynamic_ = false; // flagged dynamic -> excluded from matching and removed at sweep
  double confidence_ = 1.0; // plane confidence in [0,1] (points count + planarity)
  VoxelPlane()
  {
    plane_var_ = Eigen::Matrix<double, 6, 6>::Zero();
    covariance_ = Eigen::Matrix3d::Zero();
    center_ = Eigen::Vector3d::Zero();
    normal_ = Eigen::Vector3d::Zero();
  }
} VoxelPlane;

class VOXEL_LOCATION
{
public:
  int64_t x, y, z;

  VOXEL_LOCATION(int64_t vx = 0, int64_t vy = 0, int64_t vz = 0) : x(vx), y(vy), z(vz) {}

  bool operator==(const VOXEL_LOCATION &other) const { return (x == other.x && y == other.y && z == other.z); }
};

// Hash value
namespace std
{
template <> struct hash<VOXEL_LOCATION>
{
  int64_t operator()(const VOXEL_LOCATION &s) const
  {
    using std::hash;
    using std::size_t;
    return ((((s.z) * VOXELMAP_HASH_P) % VOXELMAP_MAX_N + (s.y)) * VOXELMAP_HASH_P) % VOXELMAP_MAX_N + (s.x);
  }
};
} // namespace std

struct DS_POINT
{
  float xyz[3];
  float intensity;
  int count = 0;
};

void calcBodyCov(Eigen::Vector3d &pb, const float range_inc, const float degree_inc, Eigen::Matrix3d &cov);

class VoxelOctoTree
{

public:
  VoxelOctoTree() = default;
  std::vector<pointWithVar> temp_points_;
  VoxelPlane *plane_ptr_;
  int layer_;
  int octo_state_; // 0 is end of tree, 1 is not
  VoxelOctoTree *leaves_[8];
  double voxel_center_[3]; // x, y, z
  std::vector<int> layer_init_num_;
  float quater_length_;
  float planer_threshold_;
  int points_size_threshold_;
  int update_size_threshold_;
  int max_points_num_;
  int max_layer_;
  int new_points_;
  bool init_octo_;
  bool update_enable_;
  int last_obs_frame_; // last frame id that inserted a point here (idle forgetting, Improvement 3)

  VoxelOctoTree(int max_layer, int layer, int points_size_threshold, int max_points_num, float planer_threshold)
      : max_layer_(max_layer), layer_(layer), points_size_threshold_(points_size_threshold), max_points_num_(max_points_num),
        planer_threshold_(planer_threshold)
  {
    temp_points_.clear();
    octo_state_ = 0;
    new_points_ = 0;
    update_size_threshold_ = 5;
    init_octo_ = false;
    update_enable_ = true;
    last_obs_frame_ = 0;
    for (int i = 0; i < 8; i++)
    {
      leaves_[i] = nullptr;
    }
    plane_ptr_ = new VoxelPlane;
  }

  ~VoxelOctoTree()
  {
    for (int i = 0; i < 8; i++)
    {
      delete leaves_[i];
    }
    delete plane_ptr_;
  }
  void init_plane(const std::vector<pointWithVar> &points, VoxelPlane *plane);
  void init_octo_tree();
  void cut_octo_tree();
  void UpdateOctoTree(const pointWithVar &pv);

  VoxelOctoTree *find_correspond(Eigen::Vector3d pw);
  VoxelOctoTree *Insert(const pointWithVar &pv);
};

void loadVoxelConfig(ros::NodeHandle &nh, VoxelMapConfig &voxel_config);

class VoxelMapManager
{
public:
  VoxelMapManager() = default;
  VoxelMapConfig config_setting_;
  int current_frame_id_ = 0;
  ros::Publisher voxel_map_pub_;
  std::unordered_map<VOXEL_LOCATION, VoxelOctoTree *> voxel_map_;

  PointCloudXYZI::Ptr feats_undistort_;
  PointCloudXYZI::Ptr feats_down_body_;
  PointCloudXYZI::Ptr feats_down_world_;

  M3D extR_;
  V3D extT_;
  float build_residual_time, ekf_time;
  float ave_build_residual_time = 0.0;
  float ave_ekf_time = 0.0;
  int scan_count = 0;
  StatesGroup state_;
  // Min eigenvalue of the 6-DoF LiDAR pose Hessian (last GN iteration).
  // Independent geometric-conditioning signal for adaptive RTK weighting.
  double lambda_min_ = 0.0;
  V3D position_last_;

  V3D last_slide_position = {0,0,0};

  geometry_msgs::Quaternion geoQuat_;

  int feats_down_size_ = 0;
  int effct_feat_num_ = 0;
  std::vector<M3D> cross_mat_list_;
  std::vector<M3D> body_cov_list_;
  std::vector<pointWithVar> pv_list_;
  std::vector<PointToPlane> ptpl_list_;

  VoxelMapManager(VoxelMapConfig &config_setting, std::unordered_map<VOXEL_LOCATION, VoxelOctoTree *> &voxel_map)
      : config_setting_(config_setting), voxel_map_(voxel_map)
  {
    current_frame_id_ = 0;
    feats_undistort_.reset(new PointCloudXYZI());
    feats_down_body_.reset(new PointCloudXYZI());
    feats_down_world_.reset(new PointCloudXYZI());
  };

  void StateEstimation(StatesGroup &state_propagat);
  void TransformLidar(const Eigen::Matrix3d rot, const Eigen::Vector3d t, const PointCloudXYZI::Ptr &input_cloud,
                      pcl::PointCloud<pcl::PointXYZI>::Ptr &trans_cloud);

  void BuildVoxelMap();
  V3F RGBFromVoxel(const V3D &input_point);

  void UpdateVoxelMap(const std::vector<pointWithVar> &input_points);

  void BuildResidualListOMP(std::vector<pointWithVar> &pv_list, std::vector<PointToPlane> &ptpl_list);

  void build_single_residual(pointWithVar &pv, const VoxelOctoTree *current_octo, const int current_layer, bool &is_sucess, double &prob,
                             PointToPlane &single_ptpl, const int pv_idx);

  void pubVoxelMap();

  void mapSliding();
  void clearMemOutOfMap(const int& x_max,const int& x_min,const int& y_max,const int& y_min,const int& z_max,const int& z_min );

  // Improvement 1/3 helpers
  void collectDynamicClouds();                 // fill dyn_points_/dyn_removed_/dyn_hist_ from pv_list_
  void checkPlaneDynamics(VoxelPlane *pl);     // update dynamic_score_/is_dynamic_ of one plane from its stats
  void forgetStaleVoxels();                    // idle / dynamic-plane removal sweep
  raycast::OcclusionParams occlusion_params_;  // pre-built from config

  // occlusion / dynamic outputs (world frame)
  PointCloudXYZI::Ptr dyn_points_;   // points flagged dynamic/occluded in the current scan
  PointCloudXYZI::Ptr dyn_removed_;  // current scan with dynamic points removed
  PointCloudXYZI::Ptr dyn_hist_;     // plane centers, intensity = dynamic_score_
  int dyn_point_num_ = 0;            // number of dynamic points in the current scan
  int matched_point_num_ = 0;        // number of matched inlier points in the current scan

private:
  void GetUpdatePlane(const VoxelOctoTree *current_octo, const int pub_max_voxel_layer, std::vector<VoxelPlane> &plane_list);

  void pubSinglePlane(visualization_msgs::MarkerArray &plane_pub, const std::string plane_ns, const VoxelPlane &single_plane, const float alpha,
                      const Eigen::Vector3d rgb);
  void CalcVectQuation(const Eigen::Vector3d &x_vec, const Eigen::Vector3d &y_vec, const Eigen::Vector3d &z_vec, geometry_msgs::Quaternion &q);

  void mapJet(double v, double vmin, double vmax, uint8_t &r, uint8_t &g, uint8_t &b);

  V3D ray_origin_;                       // sensor (lidar) origin in world frame, per iEKF iteration
  std::vector<VoxelPlane *> block_planes_; // per-point blocking plane found by the occlusion test
  int forget_check_count_ = 0;           // frame counter for the periodic forgetting sweep
};
typedef std::shared_ptr<VoxelMapManager> VoxelMapManagerPtr;

#endif // VOXEL_MAP_H_