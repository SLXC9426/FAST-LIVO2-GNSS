#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Feed a LIO TUM + RTK TUM into fast_livo/online_graph_node.

Publishes:
  /online_graph/keyframe   fast_livo/OnlineGraphKeyframe
  /online_graph/gnss_enu   fast_livo/OnlineGraphFix

This is a file-replay harness for the WP2 same-input comparison.  It does not
modify the graph; it only replaces the live mapping node as the message source.
"""
import argparse
import csv
import os
import sys
import time

import numpy as np
import rospy
from fast_livo.msg import OnlineGraphKeyframe, OnlineGraphFix


def load_tum(path):
    rows = []
    with open(path, "r", encoding="utf-8", errors="ignore") as f:
        for line in f:
            s = line.split()
            if len(s) < 4:
                continue
            try:
                t = float(s[0])
                xyz = [float(s[1]), float(s[2]), float(s[3])]
                if len(s) >= 8:
                    q = [float(s[4]), float(s[5]), float(s[6]), float(s[7])]
                else:
                    q = [0.0, 0.0, 0.0, 1.0]
            except ValueError:
                continue
            rows.append((t, xyz, q))
    rows.sort(key=lambda x: x[0])
    return rows


def load_status(path):
    """Optional v2 epoch labels: timestamp -> status."""
    out = {}
    if not path or not os.path.exists(path):
        return out
    with open(path, "r", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            try:
                out[float(r["tau"])] = int(float(r["status"]))
            except (ValueError, KeyError):
                continue
    return out


def load_quality(path):
    """RTKLIB per-epoch quality table, keyed by integer Unix second.

    Supplies nsat/pdop/sigma0/status. It does not carry the receiver's hAcc/vAcc,
    so those stay explicitly unknown (has_h_acc/has_v_acc false) instead of
    being derived from x_rms/y_rms.
    """
    out = {}
    if not path or not os.path.exists(path):
        return out

    def fnum(v, d=0.0):
        try:
            return float(v)
        except (TypeError, ValueError):
            return d

    with open(path, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            try:
                t = int(round(fnum(r.get("t_unix"), -1.0)))
            except ValueError:
                continue
            if t < 0:
                continue
            st = (r.get("status") or "").strip()
            pdop = fnum(r.get("pdop"))
            out[t] = {
                "nsat": int(fnum(r.get("nsat"))),
                "pdop": pdop,
                "sigma0": fnum(r.get("sigma0")),
                "carr_soln": 2 if st == "Fixed" else (1 if st == "Float" else 0),
                "fix_type": 3 if st else 0,
                "valid": st in ("Fixed", "Float", "DGPS", "Single"),
                "has_p_dop": pdop > 0.0,
                "status": st,
            }
    return out


def nearest_status(status_map, t):
    if not status_map:
        return 5
    keys = np.fromiter(status_map.keys(), dtype=float, count=len(status_map))
    j = int(np.argmin(np.abs(keys - t)))
    if abs(keys[j] - t) > 0.55:
        return 5
    return status_map[keys[j]]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--livo", required=True)
    ap.add_argument("--rtk", required=True)
    ap.add_argument("--status-csv", default="")
    ap.add_argument("--quality-csv", default="",
                    help="RTKLIB per-epoch quality table (A2 offline channel)")
    ap.add_argument("--start", type=float, default=None, help="absolute unix start")
    ap.add_argument("--end", type=float, default=None, help="absolute unix end")
    ap.add_argument("--duration", type=float, default=None, help="seconds from start")
    ap.add_argument("--speed", type=float, default=1.0)
    ap.add_argument("--sigma-h", type=float, default=1.0)
    ap.add_argument("--sigma-v", type=float, default=10.0)
    args = ap.parse_args()

    livo = load_tum(args.livo)
    rtk = load_tum(args.rtk)
    if not livo:
        raise SystemExit("empty livo")
    if not rtk:
        raise SystemExit("empty rtk")

    t0 = args.start if args.start is not None else livo[0][0]
    if args.duration is not None:
        t1 = t0 + args.duration
    elif args.end is not None:
        t1 = args.end
    else:
        t1 = max(livo[-1][0], rtk[-1][0])
    livo = [r for r in livo if t0 <= r[0] <= t1]
    rtk = [r for r in rtk if t0 <= r[0] <= t1]
    status_map = load_status(args.status_csv)
    quality = load_quality(args.quality_csv)
    if quality:
        print("quality rows: %d" % len(quality))

    rospy.init_node("feed_online_graph", anonymous=True)
    pub_kf = rospy.Publisher("/online_graph/keyframe", OnlineGraphKeyframe,
                             queue_size=500)
    pub_fix = rospy.Publisher("/online_graph/gnss_enu", OnlineGraphFix,
                              queue_size=500)
    time.sleep(1.0)

    events = [("kf", r) for r in livo] + [("fix", r) for r in rtk]
    events.sort(key=lambda e: e[1][0])
    print("events: kf=%d fix=%d t=[%.3f, %.3f] speed=%.2fx" % (
        len(livo), len(rtk), events[0][1][0], events[-1][1][0], args.speed))

    wall0 = time.time()
    n_kf = 0
    n_fix = 0
    for kind, (t, xyz, q) in events:
        target = wall0 + (t - t0) / max(args.speed, 1e-6)
        dt = target - time.time()
        if dt > 0:
            time.sleep(dt)
        stamp = rospy.Time.from_sec(t)
        if kind == "kf":
            m = OnlineGraphKeyframe()
            m.header.stamp = stamp
            m.header.frame_id = "camera_init"
            m.pose.position.x = xyz[0]
            m.pose.position.y = xyz[1]
            m.pose.position.z = xyz[2]
            m.pose.orientation.x = q[0]
            m.pose.orientation.y = q[1]
            m.pose.orientation.z = q[2]
            m.pose.orientation.w = q[3]
            m.lambda_min = 0.0
            pub_kf.publish(m)
            n_kf += 1
            if n_kf <= 2:
                print("kf  t=%.3f p=(%.3f,%.3f,%.3f)" % (t, xyz[0], xyz[1], xyz[2]))
        else:
            m = OnlineGraphFix()
            m.header.stamp = stamp
            m.header.frame_id = "enu"
            m.point.x = xyz[0]
            m.point.y = xyz[1]
            m.point.z = xyz[2]
            m.status = nearest_status(status_map, t)
            m.nsat = 0
            m.pdop = 0.0
            m.sigma0 = 0.0
            m.rms_xyz = 0.0
            m.h_acc_mm = 0
            m.v_acc_mm = 0
            m.carr_soln = 0
            m.fix_type = 0
            m.quality_valid = False
            m.has_h_acc = False
            m.has_v_acc = False
            m.has_p_dop = False
            m.quality_source = ""
            qd = quality.get(int(round(t)))
            if qd is not None:
                m.nsat = qd["nsat"]
                m.pdop = qd["pdop"]
                m.sigma0 = qd["sigma0"]
                m.carr_soln = qd["carr_soln"]
                m.fix_type = qd["fix_type"]
                m.quality_valid = qd["valid"]
                m.has_p_dop = qd["has_p_dop"]
                m.quality_source = "rtklib"
            m.lat0 = 0.0
            m.lon0 = 0.0
            m.alt0 = 0.0
            cov = [0.0] * 9
            cov[0] = args.sigma_h * args.sigma_h
            cov[4] = args.sigma_h * args.sigma_h
            cov[8] = args.sigma_v * args.sigma_v
            m.position_covariance = cov
            pub_fix.publish(m)
            n_fix += 1
            if n_fix <= 2:
                print("fix t=%.3f p=(%.3f,%.3f,%.3f) status=%d" % (
                    t, xyz[0], xyz[1], xyz[2], m.status))

    print("replay done; waiting 6 s for final solves")
    time.sleep(6.0)
    print("publisher exit")


if __name__ == "__main__":
    main()
