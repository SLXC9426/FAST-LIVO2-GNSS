#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Print the RINEX observation types per constellation for the rover/base pair.

Phase 0 signal-compatibility check: a double difference needs the SAME signal
code on both receivers (e.g. GPS L1C/L2W).  This script makes the overlap
explicit before any DD preprocessing is written.
"""
import os
import re
from collections import OrderedDict

FILES = OrderedDict([
    ("rover", "/home/slxc9426/great_pvt/obs/campus-day.20O"),
    ("base_0200", "/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02/base_0200.rnx"),
])


def parse_obs_types(path):
    types = {}
    cur = None
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "END OF HEADER" in line:
                break
            if "SYS / # / OBS TYPES" not in line:
                continue
            # First line: "G   20 C1C ..." ; continuation: "       L2X ..."
            if line[0] != " ":
                sysname = line[0]
                try:
                    n = int(line[3:6])
                except ValueError:
                    continue
                cur = sysname
                types.setdefault(cur, [])
                parts = line[7:60].split()
            else:
                if cur is None:
                    continue
                parts = line[7:60].split()
            types[cur].extend(parts)
            # Trim trailing blanks / count padding
            if len(types[cur]) >= n:
                types[cur] = types[cur][:n]
                cur = None
    return types


def main():
    parsed = {name: parse_obs_types(p) for name, p in FILES.items()}
    for name, types in parsed.items():
        print(f"=== {name} ===")
        for sysname in "GRECJS":
            if sysname in types:
                print(f"  {sysname}: {types[sysname]}")

    print("\n=== common signals (same code on rover and base) ===")
    rv = parsed["rover"]
    bb = parsed["base_0200"]
    for sysname in "GRECJS":
        if sysname not in rv or sysname not in bb:
            continue
        common = [s for s in rv[sysname] if s in set(bb[sysname])]
        if common:
            print(f"  {sysname}: {common}")


if __name__ == "__main__":
    main()
