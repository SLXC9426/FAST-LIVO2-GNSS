/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.

Developer: Chunran Zheng <zhengcr@connect.hku.hk>

For commercial use, please contact me at <zhengcr@connect.hku.hk> or
Prof. Fu Zhang at <fuzhang@hku.hk>.

This file is subject to the terms and conditions outlined in the 'LICENSE' file,
which is included as part of this source code package.
*/

#ifndef IMU_PROCESSING_H
#define IMU_PROCESSING_H

#include <Eigen/Eigen>
#include "common_lib.h"
#include <condition_variable>
#include <nav_msgs/Odometry.h>
#include <utils/so3_math.h>
#include <fstream>
const bool time_list(PointType &x, PointType &y) { return (x.curvature < y.curvature); }

/// *************IMU Process and undistortion
class ImuProcess
{
public:
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  ImuProcess();
  ~ImuProcess();

  void Reset();
  void Reset(double start_timestamp, const sensor_msgs::ImuConstPtr &lastimu);
  void set_extrinsic(const V3D &transl, const M3D &rot);
  void set_extrinsic(const V3D &transl);
  void set_extrinsic(const MD(4, 4) & T);
  void set_gyr_cov_scale(const V3D &scaler);
  void set_acc_cov_scale(const V3D &scaler);
  void set_gyr_bias_cov(const V3D &b_g);
  void set_acc_bias_cov(const V3D &b_a);
  void set_inv_expo_cov(const double &inv_expo);
  // Random-walk covariance rate of the horizontal LIO scale state (1/s).
  void set_scale_cov(const double &cov);
  void set_imu_init_frame_num(const int &num);
  // ZUPT (zero-velocity update): detect stationary periods from raw gyro norm
  // and freeze position/velocity during them (LiDAR matching degenerates on a
  // static platform: frame-to-frame ICP has no information and pure IMU
  // integration drifts ~18 m over 60 s of standstill on GREAT campus-02).
  // Params: enable, static-threshold [deg/s] (enter), move-threshold [deg/s]
  // (exit, hysteresis), settle time [s] that gyro must stay below the static
  // threshold before the platform is declared static.
  void set_zupt_params(const bool &enable, const double &static_deg,
                       const double &move_deg, const double &acc_move,
                       const double &settle_s);
  // Called by the front-end when LiDAR/VIO observes real motion (cumulative
  // frame displacement): gyro/accel alone cannot tell standstill from a slow
  // straight start (specific force noise ~0.15-0.25 m/s^2 masks the start
  // acceleration), so the unlock decision must come from the LiDAR stream.
  void zuptUnlock();
  // A3: parameters of the static-hold release (see the members below).
  void set_zupt_hold_params(const bool &hold_mode, const double &release_vel,
                            const double &hold_max_s);
  double zuptShadowVel() const { return zupt_v_shadow_.norm(); }
  double zuptStaticDuration() const { return zupt_static_dur_; }
  bool zuptLocked() const { return zupt_locked_out_; }
  bool zuptStatic() const { return zupt_is_static_; }
  bool zuptEnabled() const { return zupt_enable_; }
  void disable_imu();
  void disable_gravity_est();
  void disable_bias_est();
  void disable_exposure_est();
  void Process2(LidarMeasureGroup &lidar_meas, StatesGroup &stat, PointCloudXYZI::Ptr cur_pcl_un_);
  void UndistortPcl(LidarMeasureGroup &lidar_meas, StatesGroup &state_inout, PointCloudXYZI &pcl_out);

  ofstream fout_imu;
  double IMU_mean_acc_norm;
  V3D unbiased_gyr;

  V3D cov_acc;
  V3D cov_gyr;
  V3D cov_bias_gyr;
  V3D cov_bias_acc;
  double cov_inv_expo;
  double cov_scale = 1e-6;
  double first_lidar_time;
  bool imu_time_init = false;
  bool imu_need_init = true;
  M3D Eye3d;
  V3D Zero3d;
  int lidar_type;

private:
  void IMU_init(const MeasureGroup &meas, StatesGroup &state, int &N);
  void Forward_without_imu(LidarMeasureGroup &meas, StatesGroup &state_inout, PointCloudXYZI &pcl_out);
  PointCloudXYZI pcl_wait_proc;
  sensor_msgs::ImuConstPtr last_imu;
  PointCloudXYZI::Ptr cur_pcl_un_;
  vector<Pose6D> IMUpose;
  M3D Lid_rot_to_IMU;
  V3D Lid_offset_to_IMU;
  V3D mean_acc;
  V3D mean_gyr;
  // most-stationary batch during IMU init (smallest gyro norm): gravity must
  // be estimated from a motion-free window. If the vehicle starts moving
  // before init finishes (e.g. GREAT campus-01, moving at t=0), the plain
  // mean_acc absorbs horizontal motion acceleration into the gravity vector;
  // propagation then cancels the real horizontal acceleration and the
  // trajectory comes out ~5x too short.
  double best_gyr_norm_ = 1e9;
  V3D best_acc_mean_ = V3D::Zero();
  V3D angvel_last;
  V3D acc_s_last;
  // R3-WP11: the IMU-pair guard (dt outside (0, 0.5]) now warns once instead of
  // skipping silently, so a data gap leaves a trace in the log.
  bool imu_dt_gap_warned_ = false;
  double last_prop_end_time = 0.0;   // must be initialized: first UndistortPcl
                                     // call reads it as prop_beg_time
  double time_last_scan = 0.0;
  int init_iter_num = 1, MAX_INI_COUNT = 20;
  bool b_first_frame = true;
  bool imu_en = true;
  bool gravity_est_en = true;
  bool ba_bg_est_en = true;
  // ---- ZUPT state ----
  bool zupt_enable_ = false;
  double zupt_static_thresh_deg_ = 0.6;  // enter static below this [deg/s]
  double zupt_move_thresh_deg_ = 1.2;    // exit static above this [deg/s]
  double zupt_acc_move_ = 0.3;           // exit static when |specific force|
                                         // exceeds this [m/s^2] (slow starts
                                         // have small gyro but real accel)
  double zupt_settle_s_ = 0.3;           // must stay static for this long
  double zupt_static_time_ = 0.0;
  bool zupt_is_static_ = false;
  bool zupt_ever_moved_ = false;         // never freeze before first motion
                                         // (protects the IMU-init / start)
  bool zupt_locked_out_ = false;         // permanently disabled after the
                                         // first real motion: gyro-norm based
                                         // detection cannot tell standstill
                                         // from constant straight-line motion
                                         // (both ~0 deg/s); freezing there
                                         // destroys the trajectory (observed
                                         // on campus-01: 95 km divergence).
                                         // ZUPT is a startup-static guard.
  V3D zupt_pos_frozen_ = V3D::Zero();    // frozen position while static

  // ---- A3: static-hold release -------------------------------------------
  // While the platform is confidently stationary the position is held (see
  // LIVMapper::stateEstimationAndMapping). That hold must not be able to
  // deadlock its own release, so every release test here uses IMU signals only.
  // The instantaneous tests above cannot see a slow start whose acceleration
  // stays under the specific-force noise floor (campus-02: ~0.15 m/s^2 against
  // 0.15-0.25 m/s^2), so the world-frame specific force is additionally
  // integrated after removing its running mean: a sustained real start
  // integrates into a detectable velocity, while a residual accelerometer bias
  // (removed by the mean) cannot.
  double zupt_release_vel_ = 0.12;       // m/s, |shadow velocity| that releases
  double zupt_hold_max_s_ = 300.0;       // s, backstop release
  // Release detector: compare the world-frame specific force averaged over ~3 s
  // against the ~30 s average. A real sustained start moves only the short mean;
  // a slowly drifting accelerometer bias / attitude estimate moves BOTH, so it
  // cannot false-release.
  //
  // LIMIT (measured): on campus-02 the estimator's own attitude/bias drift while
  // static already produces >=0.04 m/s^2 of short-vs-long difference within
  // 0.5 s, so no threshold separates its very gentle start from that drift. The
  // failure mode is deliberately the SOFT one - an early release only lets the
  // static walk return (the pre-A3 behaviour), whereas a late release silently
  // drops real motion. A GNSS-assisted release (a fix that has clearly moved) is
  // the identified fix for that case and is left as the next step.
  double zupt_acc_change_ = 0.06;        // m/s^2, |short-long| that releases
  // In hold mode the instantaneous specific-force test is only a fast path for
  // hard accelerations (gate below): with its normal 0.3 m/s^2 threshold it
  // false-fired during a genuine standstill (campus-01: acc_dev 0.35 m/s^2 from
  // a wandering online acc-bias estimate, 13.8 s in), releasing the hold and
  // letting the pose walk again. Sensitive slow-start detection is left to the
  // detrended integral, whose noise is ~0.01 m/s against a ~0.3 m/s real start.
  bool zupt_hold_mode_ = false;
  double zupt_acc_gate_hold_ = 1.0;      // m/s^2, fast-path gate in hold mode
  // A single gyro sample above the move threshold must NOT release a confirmed
  // standstill: the bias estimate is weakly observable while stationary and a
  // spike false-fired at 44 s into a genuine 100 s standstill (campus-02,
  // gyro 1.22 deg/s vs 1.20 threshold). A real start keeps the gyro up for
  // much longer than this dwell time.
  double zupt_move_confirm_s_ = 1.0;     // s above the move threshold to release
  double zupt_move_time_ = 0.0;
  V3D zupt_a_mean_ = V3D::Zero();        // ~30 s mean of the specific force
  V3D zupt_a_short_ = V3D::Zero();       // ~3 s mean of the specific force
  V3D zupt_v_shadow_ = V3D::Zero();      // detrended integral (diagnostics)
  bool zupt_a_mean_init_ = false;
  double zupt_static_dur_ = 0.0;         // seconds held static
  bool exposure_estimate_en = true;
};
typedef std::shared_ptr<ImuProcess> ImuProcessPtr;
#endif