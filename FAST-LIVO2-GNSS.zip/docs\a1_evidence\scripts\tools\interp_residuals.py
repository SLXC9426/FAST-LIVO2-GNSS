#!/usr/bin/env python3
"""A1 model-noise check: RTK interpolation residuals by motion regime.

For every RTK epoch that produced an InterpolatedAbsPosFactor, rebuild

    T(a) = Ti * Exp(a * Log(Ti^-1 * Tj))
    p_hat = T(a) * lever
    r = p_hat - z_rtk

from the optimized TUM (pose i/j by index) and the association trace, then bin
|r| by speed, yaw rate and longitudinal acceleration. This does not separate
model error from RTK measurement error; it shows whether the residual grows in
the high-yaw-rate / high-acceleration regimes, which is exactly where a
constant-twist interpolation is weakest. The normalized chi-square fraction is
also reported with the sigma actually used by the factor.
"""
import argparse
import csv
import math
from pathlib import Path

import numpy as np

LEVER = np.array([-0.05, -0.325, 0.165])


def skew(w):
    return np.array([[0.0, -w[2], w[1]], [w[2], 0.0, -w[0]], [-w[1], w[0], 0.0]])


def so3_exp(w):
    th = np.linalg.norm(w)
    W = skew(w)
    if th < 1e-8:
        return np.eye(3) + W + 0.5 * W @ W
    return (np.eye(3) + math.sin(th) / th * W +
            (1.0 - math.cos(th)) / (th * th) * W @ W)


def so3_log(R):
    c = np.clip((np.trace(R) - 1.0) / 2.0, -1.0, 1.0)
    th = math.acos(c)
    if th < 1e-8:
        return 0.5 * np.array([R[2, 1] - R[1, 2], R[0, 2] - R[2, 0],
                               R[1, 0] - R[0, 1]])
    return th / (2.0 * math.sin(th)) * np.array(
        [R[2, 1] - R[1, 2], R[0, 2] - R[2, 0], R[1, 0] - R[0, 1]])


def left_jacobian(w):
    th = np.linalg.norm(w)
    W = skew(w)
    if th < 1e-6:
        return np.eye(3) + 0.5 * W + (1.0 / 6.0) * W @ W
    return (np.eye(3) + (1.0 - math.cos(th)) / (th * th) * W +
            (th - math.sin(th)) / (th ** 3) * W @ W)


def left_jacobian_inv(w):
    th = np.linalg.norm(w)
    W = skew(w)
    if th < 1e-6:
        return np.eye(3) - 0.5 * W + (1.0 / 12.0) * W @ W
    c = (1.0 - math.cos(th)) / (th * th)
    return (np.eye(3) - 0.5 * W +
            (1.0 / (th * th) - (1.0 + math.cos(th)) / (2.0 * th * math.sin(th)))
            * W @ W)


def se3_exp(xi):
    w, v = xi[:3], xi[3:]
    R = so3_exp(w)
    return R, left_jacobian(w) @ v


def se3_log(R, t):
    w = so3_log(R)
    return np.concatenate([w, left_jacobian_inv(w) @ t])


def load_tum(path):
    t, p, q = [], [], []
    for line in Path(path).open(errors="ignore"):
        s = line.split()
        if len(s) < 8:
            continue
        try:
            t.append(float(s[0]))
            p.append([float(s[1]), float(s[2]), float(s[3])])
            q.append([float(s[4]), float(s[5]), float(s[6]), float(s[7])])
        except ValueError:
            continue
    return np.asarray(t), np.asarray(p), np.asarray(q)


def quat_to_R(q):
    x, y, z, w = q / np.linalg.norm(q)
    return np.array([
        [1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)],
        [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)],
        [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)],
    ])


def motion(t, p, q):
    """Per-bracket speed, yaw rate (deg/s) and |accel| (m/s^2)."""
    n = len(t)
    R = [quat_to_R(q[i]) for i in range(n)]
    v = np.zeros((n, 3))
    dt = np.diff(t)
    v[:-1] = np.diff(p, axis=0) / np.maximum(dt, 1e-9)[:, None]
    v[-1] = v[-2] if n > 1 else 0.0
    speed = np.linalg.norm(v, axis=1)
    yaw = np.zeros(n)
    for i in range(n - 1):
        yaw[i] = math.degrees(np.linalg.norm(so3_log(R[i].T @ R[i + 1]))) / max(dt[i], 1e-9)
    acc = np.zeros(n)
    for i in range(n - 1):
        a = np.linalg.norm(v[i + 1] - v[i]) / max(0.5 * (dt[max(i - 1, 0)] + dt[i]), 1e-9)
        acc[i] = a
    return speed, yaw, acc


def evaluate(tum, trace, rtk_path, lever):
    t, p, q = load_tum(tum)
    rt, rp = [], []
    for line in Path(rtk_path).open(errors="ignore"):
        s = line.split()
        if len(s) < 4:
            continue
        try:
            rt.append(float(s[0]))
            rp.append([float(s[1]), float(s[2]), float(s[3])])
        except ValueError:
            continue
    rt = np.asarray(rt)
    rp = np.asarray(rp)
    speed, yaw, acc = motion(t, p, q)

    rows = []
    with open(trace, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if int(r["factor"]) != 1:
                continue
            i, j = int(r["key_i"]), int(r["key_j"])
            a = float(r["alpha"])
            tf = float(r["t_fix"])
            k = int(np.argmin(np.abs(rt - tf)))
            if abs(rt[k] - tf) > 0.01:
                continue
            Ri, Rj = quat_to_R(q[i]), quat_to_R(q[j])
            ti, tj = p[i], p[j]
            dR, dtv = Ri.T @ Rj, Ri.T @ (tj - ti)
            xi = se3_log(dR, dtv)
            Rd, td = se3_exp(a * xi)
            Ra, ta = Ri @ Rd, ti + Ri @ td
            p_hat = ta + Ra @ lever
            res = p_hat - rp[k]
            rows.append((tf, res, speed[i], yaw[i], acc[i]))
    return rows


def stats(v):
    v = np.asarray(v)
    if v.size == 0:
        return "n=0"
    return (f"n={v.size:4d} med={np.median(v):.3f} "
            f"p95={np.percentile(v, 95):.3f} rms={np.sqrt(np.mean(v ** 2)):.3f}")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--tum", required=True)
    ap.add_argument("--trace", required=True)
    ap.add_argument("--rtk", required=True)
    ap.add_argument("--lever", default="-0.05,-0.325,0.165")
    ap.add_argument("--sigma-h", type=float, default=1.0)
    ap.add_argument("--sigma-v", type=float, default=10.0)
    ap.add_argument("--model-sigma", type=float, default=0.10)
    ap.add_argument("--debias", action="store_true",
                    help="subtract the median residual vector first; needed on "
                         "campus-02 where the static-anchor bias dominates")
    args = ap.parse_args()
    lever = np.array([float(x) for x in args.lever.split(",")])

    rows = evaluate(args.tum, args.trace, args.rtk, lever)
    if args.debias and rows:
        b = np.median(np.array([r[1] for r in rows]), axis=0)
        print(f"removed median residual: {b[0]:.3f} {b[1]:.3f} {b[2]:.3f} m")
        rows = [(r[0], r[1] - b, r[2], r[3], r[4]) for r in rows]
    norm = np.array([np.linalg.norm(r[1]) for r in rows])
    print(f"factors={len(rows)}  |r|: {stats(norm)}")

    # chi-square with the sigma the factor actually used
    sh = math.sqrt(args.sigma_h ** 2 + args.model_sigma ** 2)
    sv = math.sqrt(args.sigma_v ** 2 + args.model_sigma ** 2)
    gam = np.array([(r[1][0] / sh) ** 2 + (r[1][1] / sh) ** 2 +
                    (r[1][2] / sv) ** 2 for r in rows])
    if gam.size:
        print(f"chi2: med={np.median(gam):.3f} p99={np.percentile(gam, 99):.3f} "
              f"frac>11.345={np.mean(gam > 11.345):.4f}")

    for name, idx, cuts in (
            ("speed m/s", 2, [0.3, 1.5]),
            ("yaw deg/s", 3, [5.0, 20.0]),
            ("accel m/s2", 4, [0.3, 1.0])):
        print(f"\n-- by {name} --")
        vals = np.array([r[idx] for r in rows])
        edges = [-1e9] + cuts + [1e9]
        for lo, hi in zip(edges[:-1], edges[1:]):
            sel = (vals > lo) & (vals <= hi)
            print(f"  ({lo:g},{hi:g}]: " + stats(norm[sel]))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
