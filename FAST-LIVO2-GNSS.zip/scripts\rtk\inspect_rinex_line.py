#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Inspect the exact RINEX 3 observation line layout for the GREAT files."""
import os

ROVER = "/home/slxc9426/great_pvt/obs/campus-day.20O"
BASE = "/home/slxc9426/datasets/GREAT/rtk_base_1hz/2020_301/02/base_0200.rnx"


def header_types(path):
    out = {}
    cur = None
    n = 0
    with open(path, "r", errors="replace") as f:
        for line in f:
            if "END OF HEADER" in line:
                break
            if "SYS / # / OBS TYPES" not in line:
                continue
            if line[0] != " ":
                sysname = line[0]
                try:
                    n = int(line[3:6])
                except ValueError:
                    continue
                cur = sysname
                out.setdefault(cur, [])
                parts = line[7:60].split()
            else:
                if cur is None:
                    continue
                parts = line[7:60].split()
            out[cur].extend(parts)
            if len(out[cur]) >= n:
                out[cur] = out[cur][:n]
                cur = None
    return out


def show(path, target_prefix, max_lines=4):
    types = header_types(path)
    print(f"=== {path} ===")
    for s in "GC":
        print(f"  {s}: n={len(types.get(s, []))} {types.get(s, [])}")
    with open(path, "r", errors="replace") as f:
        lines = f.readlines()
    for i, line in enumerate(lines):
        if line.startswith(">") and "2020 10 27 02 09 32" in line:
            print(f"epoch line {i+1}: len={len(line.rstrip())} {line.rstrip()!r}")
            for j in range(i + 1, min(i + 1 + max_lines, len(lines))):
                s = lines[j].rstrip("\n")
                sysname = s[0] if s else "?"
                print(f"  line {j+1}: len={len(s)} first={s[:3]!r}")
                if sysname in types:
                    nt = len(types[sysname])
                    print(f"    ntypes={nt}, expected_len={3+16*nt}")
                    for k in range(min(nt, 8)):
                        field = s[3 + 16 * k: 3 + 16 * (k + 1)]
                        print(f"    {types[sysname][k]:4s} [{k:2d}] {field!r}")
            break


if __name__ == "__main__":
    show(ROVER, "G")
    print()
    show(BASE, "C")
