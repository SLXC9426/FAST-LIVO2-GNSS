/* 
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with RTK/GNSS tight-coupling support.

GNSS Processing Module - WGS84 to ENU conversion, quality assessment,
and extrinsic calibration handling for RTK integration.
*/

#ifndef GNSS_PROCESSING_H
#define GNSS_PROCESSING_H

#include <Eigen/Eigen>
#include "common_lib.h"
#include <sensor_msgs/NavSatFix.h>

using namespace Eigen;

// RTK fix status codes as used throughout this project.
//
// WARNING (R3-WP10a): these are NOT the ROS sensor_msgs/NavSatFix status values.
// ROS defines 0=FIX, 1=SBAS, 2=GBAS, while this enum follows the project's own bag
// converters (scripts/_campus02_gnss.py, scripts/eval/gnss_bag_to_tum.py), which
// write 5 for a Q-flag "Fixed" solution and 2 for everything else; 4 is kept as an
// extra "phase fixed" code. A NavSatFix produced by, say, the ublox driver would
// report 2 for a GBAS solution and this table reads that as PHASE_FLOAT. The
// mapping therefore has to be checked AND documented for every new data source -
// the comment here used to claim "matches NavSatFix status", which was simply wrong.
enum GNSS_FIX_STATUS
{
  GNSS_NO_FIX = -1,
  GNSS_SINGLE = 0,
  GNSS_DGPS = 1,
  GNSS_PHASE_FLOAT = 2,
  GNSS_PHASE_FIX = 4,
  GNSS_RTK_FIXED = 5
};

// R3 P1-3 (A3-2): bounded physical drift prior, bookkeeping model.
//
// The filter's position prior must reflect the drift a pure LIO accumulates
// while no absolute correction lands, but an accepted fix at a ~5e-4 gain
// removes only millimetres of error, so "reset the drift clock on every
// accept" (first instantiation, vA) neuters the model exactly where it should
// engage: sporadic transient accepts kept the accumulated sigma at ~b*13 s.
// The model is therefore an exact drift ACCOUNT instead:
//   acc grows by b*dt over every inter-fix interval, capped at sigma_max
//     (b = the LIO's OWN drift rate, never a function of the GNSS innovation -
//     feeding the innovation back is the inflate_prior circularity that
//     disabled the chi-square gate on campus-02, EVAL_PROTOCOL 6.3c / 14.4);
//   an accepted epoch PAYS the account down by the correction it actually
//     applied (|dx_pos|), not by the residual it saw - full credit for a
//     millimetre correction would pretend the state was re-anchored;
//   the sigma used is max(a, acc) - the floor says a freshly corrected state
//     still carries at least a metres of absolute uncertainty.
// In steady state this self-balances (gain rises until gain*res pays the
// b*dt accrual), and a long uncorrected stretch is bounded by sigma_max.
// Kept as free functions so the selftest can pin them without instantiating
// LIVMapper (which needs a ROS parameter server).
inline double gnssDriftGrow(double acc_m, double b_m_per_s, double dt_s, double sigma_max_m)
{
  if (dt_s < 0.0) dt_s = 0.0; // an out-of-order fix must not shrink the account
  acc_m += b_m_per_s * dt_s;
  if (sigma_max_m > 0.0 && acc_m > sigma_max_m) acc_m = sigma_max_m;
  return acc_m;
}

inline double gnssDriftPay(double acc_m, double applied_m)
{
  acc_m -= applied_m;
  return acc_m > 0.0 ? acc_m : 0.0;
}

inline double gnssDriftSigmaOf(double acc_m, double a_m)
{
  return acc_m > a_m ? acc_m : a_m;
}

class GnssProcess
{
public:
  EIGEN_MAKE_ALIGNED_OPERATOR_NEW

  GnssProcess();
  ~GnssProcess();

  // Set ENU origin from WGS84 coordinates
  void setOrigin(double lat0, double lon0, double alt0);
  
  // Convert WGS84 (lat/lon/alt in degrees/meters) to ENU local frame
  void wgs84ToEnu(double lat, double lon, double alt,
                  double &e, double &n, double &u);
  
  // Convert ENU to WGS84 (inverse)
  void enuToWgs84(double e, double n, double u,
                  double &lat, double &lon, double &alt);

  // R3 stage 4 (L2): rotate an ECEF VECTOR into the local ENU frame of the origin
  // set by setOrigin(). Unlike wgs84ToEnu there is no origin subtraction - a
  // velocity is a free vector, so only the rotation applies - and it uses the same
  // rotation as the position path, so a velocity and a position from the same
  // receiver stream land in the same ENU frame.
  void ecefToEnuVector(double x, double y, double z,
                       double &e, double &n, double &u);

  // Get position noise standard deviation based on fix type
  double getHorizontalCov(int fix_type);
  double getVerticalCov(int fix_type);

  // R3-WP10a: the fix-type noise table is settable from yaml (gnss/sigma_fixed,
  // sigma_float, sigma_dgps, sigma_single) so that recalibrating for a new dataset
  // does not need a rebuild. The defaults are the values that were hard-coded and
  // calibrated against GREAT campus-02, so leaving the yaml unset reproduces the
  // previous behaviour exactly.
  void setSigmaTable(double fixed_m, double float_m, double dgps_m, double single_m)
  {
    sig_fixed_ = fixed_m;
    sig_float_ = float_m;
    sig_dgps_ = dgps_m;
    sig_single_ = single_m;
  }
  
  // Check if fix quality is sufficient for update
  bool isFixValid(int fix_type);
  bool isFixGoodEnoughForInit(int fix_type);

  // Set GNSS antenna extrinsic w.r.t. IMU body frame
  void setGnssExtrinsic(const V3D &transl);
  V3D getGnssExtrinsic() const { return gnss_offset_; }

  // Override the fix-type noise table with measured sigmas (metres). A value
  // <= 0 keeps the built-in table. Used when the dataset's per-epoch
  // covariance is missing or contradicts the measured error.
  void setSigmaOverride(double horiz_m, double vert_m)
  {
    horiz_sigma_override_ = horiz_m;
    vert_sigma_override_ = vert_m;
  }
  bool hasSigmaOverride() const { return horiz_sigma_override_ > 0.0; }

  bool isOriginSet() const { return origin_set_; }

  // WGS84 constants
  static constexpr double WGS84_A = 6378137.0;           // semi-major axis
  static constexpr double WGS84_F = 1.0 / 298.257223563; // flattening
  static constexpr double WGS84_E2 = WGS84_F * (2.0 - WGS84_F); // first eccentricity squared
  // WP6: needed by the ECEF -> geodetic inverse and absent before, which is why
  // the expression there used (1 - e2*a) in a denominator instead of b.
  static constexpr double WGS84_B = WGS84_A * (1.0 - WGS84_F);  // semi-minor axis (~6356752.314)
  static constexpr double WGS84_EP2 =
      (WGS84_A * WGS84_A - WGS84_B * WGS84_B) / (WGS84_B * WGS84_B); // second eccentricity squared

private:
  // ENU origin in WGS84
  double lat0_rad_, lon0_rad_, alt0_;
  double sin_lat0_, cos_lat0_, sin_lon0_, cos_lon0_;
  V3D ecef_origin_;
  
  bool origin_set_ = false;
  
  // GNSS antenna position in IMU body frame (lever arm)
  V3D gnss_offset_;

  // yaml-calibrated sigma override (<= 0 -> use the fix-type table)
  double horiz_sigma_override_ = -1.0;
  double vert_sigma_override_ = -1.0;

  // fix-type noise table (m), settable via setSigmaTable(); defaults are the
  // calibrated values documented in getHorizontalCov()
  double sig_fixed_ = 1.2;
  double sig_float_ = 2.5;
  double sig_dgps_ = 3.0;
  double sig_single_ = 5.0;

  // Convert WGS84 to ECEF
  void wgs84ToEcef(double lat, double lon, double alt, V3D &ecef);
};

typedef std::shared_ptr<GnssProcess> GnssProcessPtr;

#endif // GNSS_PROCESSING_H
