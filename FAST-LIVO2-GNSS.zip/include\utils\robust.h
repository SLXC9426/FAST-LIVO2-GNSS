/*
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with occlusion-aware robust kernels for LIO/VIO residual weighting.

Robust kernel weight functions (IRLS form w = rho'(r)/r):
  - Huber:   w = 1            if |r| <= delta;  w = delta/|r| otherwise
  - Cauchy:  w = 1/(1+(r/delta)^2)
Both redescend to 0 (Huber) or small values (Cauchy) for large residuals,
which suppresses the influence of occluded / dynamic / outlier points in the
iEKF update without changing the measurement model.
*/

#ifndef ROBUST_H_
#define ROBUST_H_

#include <cmath>

namespace robust
{
enum RobustKernelType
{
  NONE = 0,
  HUBER = 1,
  CAUCHY = 2
};

inline double huberWeight(const double r, const double delta)
{
  const double abs_r = std::fabs(r);
  if (abs_r <= delta) { return 1.0; }
  return delta / abs_r;
}

inline double cauchyWeight(const double r, const double delta)
{
  const double t = r / delta;
  return 1.0 / (1.0 + t * t);
}

// IRLS weight of residual r under kernel `type` with scale `delta`.
// delta must be > 0 for a valid kernel; returns 1.0 (no reweighting) otherwise.
inline double weight(const int type, const double r, const double delta)
{
  if (delta <= 0.0) { return 1.0; }
  switch (type)
  {
    case HUBER:  return huberWeight(r, delta);
    case CAUCHY: return cauchyWeight(r, delta);
    default:     return 1.0;
  }
}

} // namespace robust

#endif // ROBUST_H_
