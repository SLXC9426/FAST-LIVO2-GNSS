#!/usr/bin/env python3
"""Inspect raw campus LiDAR bin layout."""
import numpy as np

p = "/home/slxc9426/datasets/GREAT/Lidar/data/1603764571917030144.bin"
raw = np.fromfile(p, dtype=np.float32)
print("total floats:", len(raw), "-> points if 6 fields:", len(raw) // 6, " rem:", len(raw) % 6)
# candidate layout 1: x,y,z,intensity,ring(f32),time(f32)
a = raw[: len(raw) // 6 * 6].reshape(-1, 6)
print("as f32 x,y,z,int,ring,time, first 5 points:")
print(a[:5])
b = np.fromfile(p, dtype=np.uint8)
print("point0 raw bytes:", b[0:24].tolist())
print("point1 raw bytes:", b[24:48].tolist())
# point size = 24 bytes? ring at 16 (uint16), time at 18 (f32)
ring0 = b[16] | (b[17] << 8)
time0 = np.frombuffer(b[18:22], dtype=np.float32)[0]
print("p0 uint16@16:", ring0, "f32@18:", time0)
ring1 = b[40] | (b[41] << 8)
time1 = np.frombuffer(b[42:46], dtype=np.float32)[0]
print("p1 uint16@16:", ring1, "f32@18:", time1)
