/*
A2.5 self-test: weighted / robust 2D similarity fit.

Pins the pass-1 formulas (so A2.5 does not silently change the baseline) and
the two properties the two-pass experiment relies on:
  - a single 25 m outlier biases the plain fit and is suppressed by Huber;
  - zero-weight samples do not enter the fit at all.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/graph_fit_selftest
*/
#include "graph_fit.h"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok, const std::string &detail = "")
{
  std::printf("%s  %-54s %s\n", ok ? "ok  " : "FAIL", name.c_str(),
              detail.c_str());
  if (!ok) ++g_failures;
}

struct Sample
{
  std::vector<Eigen::Vector3d> lio, enu;
};

Sample makeSample(double yaw, double scale, const Eigen::Vector3d &tr,
                  int n = 60)
{
  Sample s;
  const double cy = std::cos(yaw), sy = std::sin(yaw);
  for (int i = 0; i < n; ++i)
  {
    const double a = 2.0 * M_PI * i / n;
    Eigen::Vector3d l(20.0 * std::cos(a), 30.0 * std::sin(a), 0.05 * i);
    Eigen::Vector3d e(scale * (cy * l.x() - sy * l.y()) + tr.x(),
                      scale * (sy * l.x() + cy * l.y()) + tr.y(),
                      l.z() + tr.z());
    s.lio.push_back(l);
    s.enu.push_back(e);
  }
  return s;
}

}  // namespace

int main()
{
  using fast_livo::SimilarityFitOptions;
  using fast_livo::fitSimilarity2D;
  using fast_livo::fitSimilarity2DRobust;

  const double yaw = 0.30, scale = 1.07;
  const Eigen::Vector3d tr(2.0, -3.0, 0.5);
  const Sample clean = makeSample(yaw, scale, tr);
  SimilarityFitOptions opt;

  // ---- exact recovery ------------------------------------------------------
  {
    const auto r = fitSimilarity2D(clean.lio, clean.enu, {}, opt);
    check("clean data recovers yaw", r.valid && std::fabs(r.yaw - yaw) < 1e-9,
          "err=" + std::to_string(r.yaw - yaw));
    check("clean data recovers scale",
          std::fabs(r.scale - scale) < 1e-9,
          "err=" + std::to_string(r.scale - scale));
    check("clean data recovers translation",
          (r.tr - tr).norm() < 1e-9);
    check("clean data has ~zero RMS", r.rms < 1e-9);
  }

  // ---- yaw override --------------------------------------------------------
  {
    SimilarityFitOptions o;
    o.have_yaw_override = true;
    o.yaw_override = 0.5;
    const auto r = fitSimilarity2D(clean.lio, clean.enu, {}, o);
    check("frontend yaw override wins", r.valid && std::fabs(r.yaw - 0.5) < 1e-12);
  }

  // ---- scale disabled ------------------------------------------------------
  {
    SimilarityFitOptions o;
    o.scale_fit = false;
    const auto r = fitSimilarity2D(clean.lio, clean.enu, {}, o);
    check("scale fit off pins scale to 1", r.valid && r.scale == 1.0);
  }

  // ---- single gross outlier ------------------------------------------------
  {
    Sample dirty = clean;
    dirty.enu[25] += Eigen::Vector3d(25.0, 0.0, 0.0);
    const auto plain = fitSimilarity2D(dirty.lio, dirty.enu, {}, opt);
    const auto robust = fitSimilarity2DRobust(dirty.lio, dirty.enu, opt);
    const double plain_err = std::fabs(plain.scale - scale) +
                             std::fabs(plain.yaw - yaw);
    const double robust_err = std::fabs(robust.scale - scale) +
                              std::fabs(robust.yaw - yaw);
    check("plain fit is biased by a 25 m outlier",
          std::fabs(plain.scale - scale) > 1e-3, "dscale=" +
              std::to_string(plain.scale - scale));
    check("Huber fit suppresses the outlier", robust_err < 0.2 * plain_err,
          "plain=" + std::to_string(plain_err) + " robust=" +
              std::to_string(robust_err));
  }

  // ---- zero weight drops the outlier --------------------------------------
  {
    Sample dirty = clean;
    dirty.enu[25] += Eigen::Vector3d(25.0, 0.0, 0.0);
    std::vector<double> w(dirty.lio.size(), 1.0);
    w[25] = 0.0;
    const auto r = fitSimilarity2D(dirty.lio, dirty.enu, w, opt);
    check("zero-weight outlier is ignored",
          r.valid && std::fabs(r.scale - scale) < 1e-9 &&
              std::fabs(r.yaw - yaw) < 1e-9);
  }

  // ---- degenerate track ----------------------------------------------------
  {
    std::vector<Eigen::Vector3d> lio(10, Eigen::Vector3d(1.0, 2.0, 3.0));
    std::vector<Eigen::Vector3d> enu(10, Eigen::Vector3d(4.0, 5.0, 6.0));
    const auto r = fitSimilarity2D(lio, enu, {}, opt);
    check("degenerate LIO track is invalid", !r.valid);
  }

  // ---- empty input ---------------------------------------------------------
  {
    const auto r = fitSimilarity2D({}, {}, {}, opt);
    check("empty input is invalid", !r.valid);
  }

  // ---- robust fit on clean data stays put ---------------------------------
  {
    const auto r = fitSimilarity2DRobust(clean.lio, clean.enu, opt);
    check("Huber fit on clean data recovers the same model",
          r.valid && std::fabs(r.scale - scale) < 1e-9 &&
              std::fabs(r.yaw - yaw) < 1e-9);
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: weighted / robust similarity fit\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
