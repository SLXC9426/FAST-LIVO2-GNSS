# 开发 / 回退工作流

## 目录与角色

| 位置 | 角色 |
|---|---|
| `C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\` | **主副本 + Git 仓库**（唯一事实来源，所有改动先落这里） |
| `~/catkin_ws/src/fast_livo/`（WSL Ubuntu-20.04） | **运行副本**（编译与跑数据以此为准，由同步脚本覆盖） |

## Git 基线

- `baseline-2026-09-13`：本次优化开始前的完整快照（含 sigma override、`use_vertical` 维度修复、campus-01/02 配置）。
- `Log/`、`build/`、`devel/`、`__pycache__/`、`*.bag`、`*.pcd` 已在 `.gitignore` 中排除（结果与日志不入库，源码/配置/launch/docs 入库）。

## 日常流程

```bat
:: 1. 改主副本（Windows）
:: 2. 同步到 WSL 并编译
wsl -d Ubuntu-20.04 -e bash "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/dev/sync_to_wsl.sh"
:: 3. 跑数据 / 评估
:: 4. 达标则提交
cd /d "C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main"
git add -A && git commit -m "..."
```

每次有实质改动的实验，提交一次并打标签（例如 `p0-1-translation-align`），便于逐项回退。

## 出重大故障时回退

```bat
cd /d "C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main"

:: A. 回到某个已知良好的提交（源码+配置一起回退）
git checkout baseline-2026-09-13 -- .

:: B. 或整体回到某个提交（含分支指针）
git reset --hard baseline-2026-09-13

:: C. 只想看某个文件改了什么
git diff baseline-2026-09-13 -- src/LIVMapper.cpp

:: D. 回退后务必同步到 WSL 并重编译
wsl -d Ubuntu-20.04 -e bash "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/dev/sync_to_wsl.sh"
```

## 注意

- `git checkout <tag> -- .` 只覆盖**已入库**的文件；不含 `Log/` 下的结果与 `~/datasets/` 里的 bag。
- 数据（bag、GREAT-PVT 工程、参考解）不在本仓库内，回退源码不会影响它们。
- WSL 运行副本不进 Git，始终由同步脚本从主副本覆盖，因此不存在"两个仓库不一致"的问题。
