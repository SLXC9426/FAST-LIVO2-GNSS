# A1 验收证据包：RTK 历元与关键帧时间关联

基线 `16cda87`（`fix/r4-backend`）。本包只放验收材料，原始 TUM/日志/逐历元
trace 保留在 `06_exec/optimization/runs/`，其哈希见 `hashes.txt`。

## 1. 改动

| 文件 | 内容 |
|---|---|
| `include/rtk_time_association.h` | 新增：历元-关键帧夹取、外推/跨度/重复规则、bracket 查找 |
| `include/pose_graph_factors.h` | 新增 `InterpolatedAbsPosFactor`（Pose3 大地线 + 杆臂 + 解析 Jacobian） |
| `include/global_pose_graph.h` | A1 参数、2×2 开关、跳过计数、trace 结构 |
| `src/global_pose_graph.cpp` | 按历元构造因子；`static_skip_of` 统一静态判定；A0 路径保留 |
| `src/online_graph_node.cpp` | 读取 A1 参数 |
| `launch/mapping_great.launch` | A1 参数（默认开启） |
| `test/rtk_time_association_selftest.cpp` | 24 项关联规则测试 |
| `test/pose_graph_factor_selftest.cpp` | 插值因子端点 + 20 组随机位姿 Jacobian 测试 |
| `CMakeLists.txt` | 注册 `rtk_time_association_selftest` |

算法二进制：`libonline_graph.so`
`f66db1495fd255ef4542c07040b60997c51bcb1108d954538f6dd687afa6c804`。
`online_graph_node` 只是 ROS 薄壳；其哈希不随图代码变化。

## 2. 2×2 归因

| 臂 | `rtk_interp_en` | `rtk_static_rule_bracket` |
|---|---:|---:|
| A0 | 0 | 0 |
| A1-T | 1 | 0 |
| A1-S | 0 | 1 |
| A1 | 1 | 1 |

```bash
bash run_arm.sh c01 A0  0 1 1.0 11481 606 '' 0
bash run_arm.sh c01 A1T 1 1 1.0 11482 606 '' 0
bash run_arm.sh c01 A1S 0 1 1.0 11483 606 '' 1
bash run_arm.sh c01 A1  1 1 1.0 11484 606 '' 1
# c02: 805 s, 端口 11491-11494
```

关键读数（ATE RMSE / 绝对 2D / 去常值 bias 2D，m）：

| 数据 | A0 | A1-T | A1-S | A1 |
|---|---|---|---|---|
| c01 | 1.553 / 1.115 / 1.164 | **0.701 / 0.501 / 0.432** | 1.554 / 1.116 / 1.164 | 0.706 / 0.509 / 0.442 |
| c02 | 1.508 / 4.210 / 0.997 | **1.010 / 4.049 / 0.690** | 1.508 / 4.210 / 0.997 | 1.010 / 4.049 / 0.690 |

结论：

- A1-S 与 A0 基本一致（c01 表中值 +0.001 m；c02 原始 TUM 哈希相同）
  → 静态规则粒度不足以解释主要收益；
- A1-T 解释主要收益（c01 −54.9%，c02 −33.0% ATE）；
- A1 与 A1-T 差 ≤0.01 m → 静态规则不是主要来源。

归档核验（`verify_trace.py`，8 臂全部 PASS）：

- 启动行记录了实际生效的 `rtk_interp` / `static_rule_bracket`，四臂为
  00/10/01/11；
- 关键帧区间内每个输入 RTK 历元恰好一个决策，`t_fix` 唯一，决策计数=行数；
- 核验时发现并修复了 `addFix` 跳变门限丢弃历元没有 trace 行的问题
  （c01 1 个、c02 4 个），现记为 `pre_rejected / jump_rejected`；
  该改动只增加 trace 行，8 臂 TUM 与改动前逐文件相同；
- c02 `A0.tum` 与 `A1S.tum` 哈希相同；`A1T.tum` 与 `A1.tum` 哈希相同；
  c01 四臂哈希不同，因此只声明“表中值相差 0.001 m”。

## 3. 测试

`rtk_time_association_selftest` 24 项；`pose_graph_factor_selftest` 含插值因子
20 组随机位姿中心差分（`|H_i-FD|=1.5e-9`，`|H_j-FD|=1.4e-9`）；其余 7 个既有
自测全部通过。

## 4. 文件

| 文件 | 内容 |
|---|---|
| `report.md` | 完整验收报告（关联统计、残差分析、限制、更正记录） |
| `ablation_c01.md` / `ablation_c02.md` | 2×2 表（含因子数/跳过原因） |
| `eval_c01.md` / `eval_c02.md` | A0 vs A1 指标（ATE/绝对 ENU/RPE/分段） |
| `assoc_c01.txt` / `assoc_c02.txt` | 逐历元关联统计 |
| `residuals_c01.txt` / `residuals_c02.txt` | 插值残差按速度/角速度/加速度分档 |
| `hashes.txt` | 冻结源码、输入、二进制、运行产物哈希 |
| `scripts/` | 构建、回放、评估、诊断脚本 |

## 5. 复现

```bash
# 1) 构建（Windows git 树 -> WSL catkin 工作区）
wsl -d Ubuntu-20.04 -- bash .../sync_and_build.sh
# 2) 四臂回放
bash run_arm.sh c01 A1 1 1 1.0 11484 606 '' 1
# 3) 评估
python3 eval_ate.py --ref .../campus01_reference.tum \
  --arm A0=.../runs/c01_A0.tum --arm A1=.../runs/c01_A1.tum
```

## 6. 已知限制

- 同输入 harness 是后端层重放，不含 FAST-LIVO 前端；真实 bag 全链路仍需复跑；
- 同一输入的重放是确定性的，N=3 只对真实 bag 运行有意义；
- `rtk_interp_model_sigma=0.10 m` 仍为未标定值（见 `report.md` §2.1）；
- c02 的绝对摆放仍被约 4 m 静态 RTK 偏置主导，属于 A3 范围。
