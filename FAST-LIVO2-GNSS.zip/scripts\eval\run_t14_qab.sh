#!/bin/bash
# T1-4 Q calibration A/B (docs/T1_4_DESIGN.md 4, review 10.2-revised sweep).
#
# Arms, c01 gnss full length, N=3 each:
#   t14_base : great_campus01            (state absent -> the SAME binary floor
#              baseline for r2_steady / r2_stat_gf, review 10.3-2)
#   t14_q1   : great_campus01_alignstate (q_pos 0.01 m/s, q_yaw 0.05 deg/s)
#   t14_q3   : + q x3   (align_q_pos 0.03, align_q_yaw_deg 0.15)
#   t14_q10  : + q x10  (align_q_pos 0.1,  align_q_yaw_deg 0.5)
# Sweep is {x1, x3, x10} per the corrected steady-state math (tau ~ 1/q; the
# information is in the upper arm), NOT {0.3, 1, 3}.
#
# Acceptance inputs afterwards (verdict.py):
#   * floors from the t14_base group (r2_steady, r2_stat_gf) -> EVAL_PROTOCOL 19.3
#   * r2_stat_gf: q arms vs base - the direct evidence the alignment state
#     absorbs the frame-scatter bill; r2_steady: the 0.2-claim of the plan.
#
# Usage: run_t14_qab.sh [repeats=3] [summary]
export LANG=C.UTF-8
N=${1:-3}
SUM=${2:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/t1_4_qab/ab_summary.txt}
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
SEG=$REPO/scripts/eval/segment_run.sh
EVALDIR=$REPO/scripts/eval
REG=$HOME/catkin_ws/src/fast_livo/Log/result/registry.csv
RTK=$HOME/datasets/GREAT/campus01_rtk1hz.bag
mkdir -p "$(dirname "$SUM")"

source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"

run_arm () {  # tag_prefix cfg
  local PFX=$1 CFG=$2 k
  for k in $(seq 1 "$N"); do
    echo "--- $PFX r$k start $(date +%T)" | tee -a "$SUM"
    bash "$SEG" campus01 gnss 0 607 "${PFX}_r$k" "$RTK" "" "$CFG" 2>&1 | tee -a "$SUM"
  done
}

: > "$SUM"
echo "=== T1-4 alignment-state Q calibration | c01 gnss full x$N | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum $HOME/catkin_ws/devel/lib/liblaser_mapping.so | cut -c1-8)" | tee -a "$SUM"

run_arm t14_base great_campus01
run_arm t14_q1   great_campus01_alignstate
run_arm t14_q3   great_campus01_alignstate_q3
run_arm t14_q10  great_campus01_alignstate_q10

{
  echo ""
  echo "=== floors (base group, same binary, state absent) ==="
  python3 "$EVALDIR/verdict.py" --registry "$REG" t14_base --field r2_full --field r2_steady --field r2_stat_gf --field r2_statloc 2>&1
  echo ""
  echo "=== q arms vs base ==="
  python3 "$EVALDIR/verdict.py" --registry "$REG" t14_base t14_q1_ --field r2_stat_gf --field r2_steady --field r2_full 2>&1
  python3 "$EVALDIR/verdict.py" --registry "$REG" t14_base t14_q3_ --field r2_stat_gf --field r2_steady --field r2_full 2>&1
  python3 "$EVALDIR/verdict.py" --registry "$REG" t14_base t14_q10_ --field r2_stat_gf --field r2_steady --field r2_full 2>&1
  echo ""
  echo "read-out: r2_stat_gf REAL(down) = the alignment state absorbs the frame"
  echo "scatter (primary c01 evidence); r2_steady REAL(down) = the plan's 0.2 claim."
} | tee -a "$SUM"

echo "T14_QAB_DONE $(date +%T)" | tee -a "$SUM"
