#!/usr/bin/env python3
"""Compare raw bin time/ring semantics: campus vs urban."""
import numpy as np

files = {
    "campus": "/home/slxc9426/datasets/GREAT/Lidar/data/1603764571917030144.bin",
    "urban": "/mnt/d/BaiduNetdiskDownload/Urban-01/Lidar/data/1603774014541467.bin",
}
import os

for tag, p in files.items():
    if not os.path.exists(p):
        print(tag, "MISSING", p)
        continue
    raw = np.fromfile(p, dtype=np.uint8)
    n = len(raw) // 22
    print(f"== {tag}: {p} size={len(raw)} -> {n} pts (22B)")
    pts = raw[: n * 22].reshape(n, 22)
    x = pts[:, 0:4].copy().view(np.float32).ravel()
    y = pts[:, 4:8].copy().view(np.float32).ravel()
    z = pts[:, 8:12].copy().view(np.float32).ravel()
    inten = pts[:, 12:16].copy().view(np.float32).ravel()
    ring = (pts[:, 16].astype(np.uint32) | (pts[:, 17].astype(np.uint32) << 8))
    t = pts[:, 18:22].copy().view(np.float32).ravel()
    print("  x:", x[:2], " y:", y[:2], " z:", z[:2])
    print("  ring unique:", np.unique(ring)[:20], " count:", len(np.unique(ring)))
    print("  time: min %.6f max %.6f first10: %s" % (t.min(), t.max(), t[:5].round(6)))
    # per-ring time range for a couple rings
    for r in [0, 5, 10, 15]:
        m = ring == r
        if m.sum():
            print(f"  ring {r}: n={m.sum()} t {t[m].min():.6f} ~ {t[m].max():.6f}")
