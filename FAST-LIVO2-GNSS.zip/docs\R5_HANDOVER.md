# R5 交接（T0 评估协议 → Tier 决策 → T1-4 全弧线 → 三模式重跑 → 全局 FG 评估）

> 技术记录一律以 `docs/EVAL_PROTOCOL.md` §19–§28 为准；T1-4 设计/评审/实现见
> `docs/T1_4_DESIGN.md` §10–§13；计划与逐轮交付见《改进方案_独立推导_2026-09-26.md》§7–§20。
> 前一轮交接 `docs/R4_HANDOVER.md`。
> 二进制：`liblaser_mapping.so = c08bb994`（T1-4 护卫版），`libgnss_proc.so = fc31342a`（未动）；
> registry（WSL）= 256 行 / 26 列，本段新增 **88 行**。

## 1. 一句话状态

Tier-0 评估协议三件套上线并接入全部运行链；T2-0 普查判 Tier-2 冻结类不立项；T1-2 关闭
（默认维持关、c03 类分类开启）；**T1-4 走完全弧线**（设计评审→实现→Q 标定→方法化→三数据集
留出→评审→重设计护卫→再验证两轮），终局：**护卫全部生效后 c01 效应消失，净收获 = 对齐状态
权限护卫机制 + c02 融合工作点正则化，全部默认关**；c01/c02 三模式重跑完成（单 RTK 确定性
基准与历史逐位复现）；全局因子图可行性已评估（回环潜力实测、Ceres 已装、GTSAM 需源码）。
**当前系统 = 前端 iEKF + 紧组合 RTK，无全局因子图。**

## 2. 必须随数字一起引用的限定

1. **跨二进制不可直比**：LIVO 臂在 R3/R4 保持类改动下已变化（c01 新 steady 0.71 vs 历史
   1.13 是二进制差异，不是算法改进）；融合臂同理。
2. c01 融合"拉偏"**符号随抽样翻转**（§0.2）：三模式单跑融合 1.81 > LIVO 1.47，差 0.33 与
   2D 地板 0.34 同带——**单跑不可裁决**；N≥3 批（T1-2）中位 1.65，长期落在噪声带内。
3. **c02 融合臂在当前二进制为 WITHHELD**（融合 OFF、等效纯 LIVO），两读 8.23/7.70 在纯
   LIVO 普查带（7.15–8.14）内；历史 5.89 属旧二进制（融合曾部分生效），不可直比。
4. **单 RTK 是确定性基准**（纯 GNSS 历元驱动、无 LIO 混沌）：与历史**逐位一致**
   （c01 3.9668/1.3941、c02 8.5884/1.6373，cfg 哈希 00007fef3e / a7291c93d0）；其
   static-loc 0.26/0.52 m = **参考接收机自身抖动**（新口径把参考噪声与估计器自运动分离）。
5. T1-4 的 c02 数字受 ~3% 丢帧影响（1 Hz 附加话题挤爆播放队列）：机制结论不受影响，
   **指标不与历史混比**。
6. T2-0 普查 0% 游走是 **N=5 抽样**，不证明游走峰不存在；`static_displacement.py` 已就位，
   未来任何运行可自动捕获。
7. **自推导 ≠ 免审查**：q=σ/τ 曾是"自推导"却违反单调性（数据越差权限越大）被留出集定罪；
   纪律已补：沿"数据变差"方向权限不得增加（§25.1）。
8. T2-0 附带发现：static-loc 的运行间极差 1.4 mm（全程 APE 的 1/700）——自位移类 A/B
   应用该列做主判据。

## 3. 新增资产

**评估工具（T0 三件套 + 扩展）**
- `eval_unified.py` 扩展：T0-1 分段口径（movfit / stat@movfit / steady-loc / static-loc /
  `--win`），registry 追加 11 列（旧表头自动迁移）；历史 full/steady 逐位不变。
- `verdict.py`：多样本裁决（中位数+地板，n<3 判 INVALID，exit 1）；**前缀带下划线**。
- `fusion_health.py`：融合健康度块（LOCKED/WITHHELD、接受率、门、增益、engaged by t）。
- `static_displacement.py`：静止段自位移/游走普查（检出力已证伪验证）。
- 驱动：`wander_census.sh`、`run_t12_ab.sh`、`run_t14_qab.sh`（+ext）、`run_t14_validation.sh`、
  `run_three_modes.sh`；日志级判据落盘：`[GNSS] align:` 行含 q / fold_t / K 可读量。

**代码（全部默认关，零默认行为变化）**
- T1-4 对齐状态 + **三条护卫**：q 物理封顶（q_max=b·√τ）、全时域权限盖帽（K≤K_max 结构
  不变量）、平移折叠速率界（|Δt|≤b·dt，K 一致钳位）；`include/gnss_alignment_state.h`
  可独立实例化的滤波器单元（自检第 (8) 节，含证伪验证）。
- 配置生成器：`make_alignstate_configs.py`、`make_t14_attrib_config.py`、
  `make_alignstate_c02_combo.py`。

**证据目录**（均含汇总文件）：`t2_0_census/`、`t1_2_ab/`、`t1_4_qab/`（第一/扩展批）、
`t1_4_val/`（留出第一轮+归因）、`t1_4_val2/`（护卫第一轮）、`t1_4_val3/`（dt 修复后）、
`three_modes/`（三模式）。

**数据侧**：`campus02_rtk1hz.bag`（898 fix 稠密流，从未用于里程碑，已用于 c02 探针与留出）；
`~/great_pvt/GREAT_RTK_campus02_dop.xml` + `.tmp_check/c02_doppler_rebuild.sh`（多普勒重解包，
受阻于 1 Hz 基站 tar 截断）。

## 4. 后续工作安排（按依赖与优先级）

### P0 —— 阻塞项，先做

1. **T3-1 后端残余归因关闭**（1–2 天，离线为主）。滑窗 FG：后端 185 cm vs 前端 100 cm、
   残余 ~170 cm"接受为未完全解释"（§15）。它是全局 FG 阶段 1 的**前置门**——不关闭就做全局，
   等于把未解释误差复制到更大规模。工具现成（`factor_graph/diag_link_every_n` 逐链接诊断、
   §15 方法、`*_graph.yaml` 线）。
2. **两项评审**（评审会，各一次）：
   - ① **锚定模式 yaw 通道守护形式**（§27.3）：c03 走锚定（相对）模式，H_a 平移列结构性
     为零，yaw 是唯一活跃通道且无速率守护（批内摆动 ±15°）——守护形式（总量/速率）待定，
     §26.5 已列 c01 证据冲突（b/span 封顶会扼杀有效初始修正）。
   - ② **T1-4 最终处置**：保留为"c02 健壮性特性（护卫强制携带）"或再跑一臂分离 c01 失益
     归因（覆盖键现成：q3 参数 + 全护卫，N=3，约 40 分钟机时，默认不加跑）。
3. **小清理**（半天，无风险）：`run_three_modes.sh` 批尾 awk 列提取修复（表格乱序）；
   WSL→Windows registry 补拷（Windows master `评估注册表.csv` 只到 09-14；本段 88 行全在
   WSL 侧）；确认 `.tmp_check` 脚本索引入 PROGRESS.md。

### P1 —— 主线（可并行）

4. **T3-2 内存上限**（3–5 天）：977 s ~12 GB 无界增长——长序列验证、全局 FG、回环的
   使能项（非精度项）。判据：c03 全程峰值内存 <12 GB 且精度不变（现有 T0 工具验收）。
5. **全局位姿图 v1（无回环）**（1–2 周，P0.1 + P1.4 之后）：
   - 结构：全轨迹关键帧 + RTK 绝对位置因子（含杆臂）+ LiDAR 里程计相对因子；
     **Ceres 1.14 已装**（GTSAM 不在 apt 源，增量 iSAM2 需源码构建或后置）；
   - 运行：1 Hz batch 重优化（数千节点稀疏求解为毫秒–几十毫秒级）；沿用现有
     keyframe/IMU/GNSS 推送接口与 `publishSmoothedOdom` 输出（`*_graph.txt`）；
   - 验证：c03（1255 s、10 Hz gt 观测）为首选平台，走 T0 工具链 + T0-2 裁决；
   - 先决纪律：因子权重必须先在 P0.1 的归因里定下来，不允许"换求解器赌精度"。
6. **T1-1' on c01**（2–3 天，数据已就绪 `campus01_rtk1hz_vel.bag`）：速度先验诚实化 +
   双 P 分离（膨胀只进 P_upd，卡尺门保持裸 P_use——§11.5 硬性约束）；判据沿用 §3 T1-1' 行。

### P2 —— 条件/延后

7. **回环检测 v1**（2–3 周，P1.5 后）：关键帧描述子（ScanContext 类）+ RTK 先验消歧 +
   误回环护栏。**数据回环潜力已实测**：>60 s 重访且水平 <5 m 的位姿占比 c01 **55.9%** /
   c02 **61.2%** / c03 **23.9%**（含静止段自配对；读作"重访结构丰富，值得做"）。
8. **实时化**（依赖 A3-7 实时骨架：IMU 50 Hz 独立线程、异步量测、耗时预算；FG 现已是
   异步线程 + 轮询输出的接口形状，替换内芯即可）。
9. **T2-3 ZARU**（静止期陀螺零偏标定，待选）；**c02 多普勒重解**（外部动作：重下
   WUH200CHN day-301 02 时段 1 Hz 基站数据，恢复配方见 §21.3）；**T3-3 观测域紧组合**
   （条件触发：仅当 T0 协议证明位置域地板不满足指标时立项）。

### 明确不做（延续清单 + 本段新增）

OOSM、L3、WP10b 噪声表调大、inflate_prior、报告级 veto 单独使用、只冻状态不冻地图、
速度通道按原样单独启用、**T2-1/T2-2（普查否决，0% 游走）**、**T1-2 全面转默认（分类开启）**。

## 5. 环境坑（本段新增）

1. **cmd→wsl 转义**仍是头号坑（本段又烧多次）：凡循环/变量/嵌套引号一律写脚本文件执行。
2. **WSL 默认发行版损坏**：一律用 `wsl -d Ubuntu-20.04`（默认 `Ubuntu` 的 vhdx 报
   ERROR_PATH_NOT_FOUND）。
3. **判据必须先落盘、再跑批**：本段三次实战——跨数据集纪律拦下 c01 调优结论入库（§26.3）；
   预注册日志级判据拦下集成层 dt bug（§27.2）；物理护卫拦下"看似有效的小型病理"（§27.6）。
   任何新批都要预注册判据（含日志级）并保证可读量落盘（q / fold_t / K）。
4. **同历元时间基陷阱**：`propagate()` 先推进 `last_t`，之后计算的 dt=0 会让速率封顶
   静默失效——凡"同函数内先后依赖同一时间基"处，**捕获一次、复用**。
5. **前缀碰撞**：verdict 分组前缀带下划线（`t14_q1_` ≠ `t14_q10_`）；批 tag 先定唯一性
   （R4 的 seg 日志覆盖教训）。
6. **长批运行期间禁止并行重活**（编译/PVT 解算）：CPU 争用扰动混沌带；附加话题会挤爆
   播放队列（c02+1 Hz 的 ~3% 丢帧即此），机制结论可用、指标不可混比。
7. 新工具首用纪律：生产 registry 表头迁移（只改表头行）已于 09-26 首次触发并验证
   （26 列，旧行不动）。

## 6. 关键命令速查

```bash
# 环境
wsl -d Ubuntu-20.04 -e bash -lc "source /opt/ros/noetic/setup.bash; source ~/catkin_ws/devel/setup.bash"

# 单跑+评估（含 T0-1 分段口径与融合健康块）
bash scripts/eval/segment_run.sh <campus01|campus02|campus03> <livo|gnss> <start> <dur> <tag> [rtk_bag] [topic_ov] [cfg]
# 单 RTK 基准
bash scripts/eval/run_gnss_modes.sh <seq> gnssonly <tag> [rtk_bag] [dur]
# 三模式对照 / 普查 / 转默认 A/B / Q 验证
bash scripts/eval/run_three_modes.sh [summary]
bash scripts/eval/wander_census.sh [N] [summary]
bash scripts/eval/run_t12_ab.sh [N] [summary]
bash scripts/eval/run_t14_validation.sh [summary]
# 裁决与健康
python3 scripts/eval/verdict.py --registry <reg> PREFIX_A PREFIX_B_ --field r2_steady --field r2_stat_gf
python3 scripts/eval/fusion_health.py <run.log>... [--expect-active]
# 自检（改动后必跑）
catkin_make --pkg fast_livo && ./devel/lib/fast_livo/gnss_processing_selftest
```
