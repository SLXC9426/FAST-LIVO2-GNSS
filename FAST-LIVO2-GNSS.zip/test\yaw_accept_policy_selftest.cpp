// P2-01 (EXP-P2-001) selftest: truth table of the FORCED early-lock policy.
//   catkin_make --pkg fast_livo && ./devel/lib/fast_livo/yaw_accept_policy_selftest
#include "yaw_accept_policy.h"

#include <cstdio>

using yaw_accept::forcedLockAllowed;
using yaw_accept::forcedLockAllowedLegacy;
using yaw_accept::lockAllowed;

static int failures = 0;

#define CHECK(cond)                                                          \
  do                                                                         \
  {                                                                          \
    if (!(cond))                                                             \
    {                                                                        \
      printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);                 \
      failures++;                                                            \
    }                                                                        \
  } while (0)

int main()
{
  // ---- 1. Legacy equivalence: floor <= 0 must reproduce the historical
  // predicate over a full grid (C0 bit-equivalence argument).
  for (int count = 0; count <= 15; count++)
    for (double span : {0.0, 149.9, 150.0, 300.0})
      for (int state_en : {0, 1})
        for (int fms : {-3, 0})
        {
          const bool legacy = (count >= 10) ||
                              forcedLockAllowedLegacy(count, span, 150.0,
                                                      state_en != 0);
          CHECK(lockAllowed(count, 10, span, 150.0, state_en != 0, fms) ==
                legacy);
          CHECK(forcedLockAllowed(count, span, 150.0, state_en != 0, fms) ==
                forcedLockAllowedLegacy(count, span, 150.0, state_en != 0));
        }

  // ---- 2. c02 measured scenario (five-round audit): span 151.481 m,
  // stable_count 1. Historical behavior locks; floor 2/3 defers.
  CHECK(forcedLockAllowed(1, 151.481, 150.0, false, 0) == true);
  CHECK(forcedLockAllowed(1, 151.481, 150.0, false, 2) == false);
  CHECK(forcedLockAllowed(1, 151.481, 150.0, false, 3) == false);
  CHECK(lockAllowed(1, 10, 151.481, 150.0, false, 2) == false);
  // One more within-tolerance fit (count 2) clears the floor of 2.
  CHECK(forcedLockAllowed(2, 151.481, 150.0, false, 2) == true);

  // ---- 3. Full settle always locks, regardless of the forced path.
  CHECK(lockAllowed(10, 10, 0.0, 150.0, false, 3) == true);
  CHECK(lockAllowed(12, 10, 0.0, 150.0, true, 3) == true);

  // ---- 4. Slow-alignment state on: never forced (T1-4 invariant).
  CHECK(forcedLockAllowed(1, 300.0, 150.0, true, 0) == false);
  CHECK(forcedLockAllowed(5, 300.0, 150.0, true, 2) == false);

  // ---- 5. Span below the force threshold: never forced.
  CHECK(forcedLockAllowed(5, 149.999, 150.0, false, 2) == false);
  CHECK(lockAllowed(5, 10, 149.999, 150.0, false, 2) == false);

  // ---- 6. Negative floor clamps to 0 (historical), never blocks.
  CHECK(forcedLockAllowed(0, 300.0, 150.0, false, -5) == true);

  if (failures == 0)
  {
    printf("yaw_accept_policy_selftest: ALL PASS\n");
    return 0;
  }
  printf("yaw_accept_policy_selftest: %d FAILURES\n", failures);
  return 1;
}
