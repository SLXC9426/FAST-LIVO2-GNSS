#!/usr/bin/env python3
"""campus-02 GNSS: SEPT-RTK_c02.flt (ECEF, 30 s) -> /gnss NavSatFix bag +
ENU TUM reference. usage: python3 _campus02_gnss.py"""
import math
import os
import sys

import numpy as np

sys.path.insert(0, "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT")

SRC = "/home/slxc9426/great_pvt/result/SEPT-RTK_c02.flt"
OUT_BAG = "/mnt/e/GREAT数据集/campus-02/gnss_c02.bag"
OUT_TUM = "/home/slxc9426/catkin_ws/src/fast_livo/Log/GREAT/campus02_reference.tum"

OFFSET = 604800 * 2129 + 315964800 - 18
A = 6378137.0
F = 1.0 / 298.257223563
E2 = F * (2.0 - F)


def ecef2lla(x, y, z):
    lon = math.atan2(y, x)
    p = math.sqrt(x * x + y * y)
    lat = math.atan2(z, p * (1 - E2))
    for _ in range(8):
        N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
        h = p / math.cos(lat) - N
        lat = math.atan2(z, p * (1 - E2 * N / (N + h)))
    N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
    h = p / math.cos(lat) - N
    return math.degrees(lat), math.degrees(lon), h


def lla2ecef(lat, lon, h):
    lat, lon = math.radians(lat), math.radians(lon)
    N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
    return ((N + h) * math.cos(lat) * math.cos(lon),
            (N + h) * math.cos(lat) * math.sin(lon),
            (N * (1 - E2) + h) * math.sin(lat))


rows = []
with open(SRC) as f:
    for line in f:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        v = line.split()
        rows.append((float(v[0]), float(v[1]), float(v[2]), float(v[3]), v[16]))
print("epochs:", len(rows), "t:", rows[0][0], "~", rows[-1][0])
fixed = sum(1 for r in rows if r[4] == "Fixed")
print("Fixed:", fixed, "/", len(rows))

# NavSatFix bag
import rosbag
from std_msgs.msg import Header
from sensor_msgs.msg import NavSatFix

with rosbag.Bag(OUT_BAG, "w") as bag:
    for i, (t, x, y, z, amb) in enumerate(rows):
        lat, lon, h = ecef2lla(x, y, z)
        msg = NavSatFix()
        msg.header.seq = i + 1
        msg.header.stamp = rosbag.rostime.Time.from_sec(t + OFFSET)
        msg.latitude = lat
        msg.longitude = lon
        msg.altitude = h
        msg.status.status = 5 if amb == "Fixed" else 2
        msg.position_covariance[0] = 0.02 * 0.02
        msg.position_covariance[4] = 0.02 * 0.02
        msg.position_covariance[8] = 0.05 * 0.05
        msg.position_covariance_type = 2
        bag.write("/gnss", msg, t=msg.header.stamp)
print("wrote", OUT_BAG)

# ENU TUM reference
x0, y0, z0 = rows[0][1], rows[0][2], rows[0][3]
lat0, lon0, h0 = ecef2lla(x0, y0, z0)
ex0, ey0, ez0 = lla2ecef(lat0, lon0, h0)
lat0r, lon0r = math.radians(lat0), math.radians(lon0)
lines = []
for t, x, y, z, amb in rows:
    dx, dy, dz = x - ex0, y - ey0, z - ez0
    e = -math.sin(lon0r) * dx + math.cos(lon0r) * dy
    n = -math.sin(lat0r) * math.cos(lon0r) * dx - math.sin(lat0r) * math.sin(lon0r) * dy + math.cos(lat0r) * dz
    u = math.cos(lat0r) * math.cos(lon0r) * dx + math.cos(lat0r) * math.sin(lon0r) * dy + math.sin(lat0r) * dz
    lines.append("%.9f %.4f %.4f %.4f 0.0 0.0 0.0 1.0" % (t + OFFSET, e, n, u))
with open(OUT_TUM, "w") as f:
    f.write("\n".join(lines) + "\n")
es = np.array([float(l.split()[1]) for l in lines])
ns = np.array([float(l.split()[2]) for l in lines])
d = np.sqrt((es - es[0]) ** 2 + (ns - ns[0]) ** 2)
cum = np.sum(np.sqrt(np.diff(es) ** 2 + np.diff(ns) ** 2))
print("ENU: max dist %.1f m, cum %.1f m, wrote %s" % (d.max(), cum, OUT_TUM))
