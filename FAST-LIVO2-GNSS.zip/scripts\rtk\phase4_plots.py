#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 4 Nature-style figures.

Run after phase4_analyze.py and phase4_gnss_quality.py.  All data are measured;
no synthetic values.  Python/matplotlib only.
"""
import csv
import glob
import os

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.collections import LineCollection
from matplotlib.lines import Line2D
from matplotlib.patches import Patch

BASE = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval"
DATA = os.path.join(BASE, "figures", "data")
MET = os.path.join(BASE, "metrics")
FIG = os.path.join(BASE, "figures")
REF = "/home/slxc9426/eval_great/campus01_reference.tum"

C = {"LIVO": "#0072B2", "RTK tight": "#E69F00", "RTK robust": "#009E73"}
GT = "#1A1A1A"
T0_UTC = 1603764572.0
LOCK_S = 63.0
MP_LO, MP_HI = 400.0, 520.0

mpl.rcParams.update({
    "font.family": "sans-serif",
    "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans", "sans-serif"],
    "pdf.fonttype": 42,
    "font.size": 7,
    "axes.spines.right": False,
    "axes.spines.top": False,
    "axes.linewidth": 0.8,
    "legend.frameon": False,
    "xtick.major.width": 0.7,
    "ytick.major.width": 0.7,
    "xtick.major.size": 2.5,
    "ytick.major.size": 2.5,
})


def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def representative(arm):
    pat = os.path.join(DATA, arm.replace(" ", "_") + "_*_aligned.csv")
    hits = sorted(glob.glob(pat))
    if not hits:
        raise SystemExit(f"missing representative for {arm}: {pat}")
    rows = read_csv(hits[0])
    t = np.array([float(r["t"]) for r in rows])
    e = np.array([float(r["east"]) for r in rows])
    n = np.array([float(r["north"]) for r in rows])
    u = np.array([float(r["up"]) for r in rows])
    e3 = np.array([float(r["err3d"]) for r in rows])
    return t, e, n, u, e3, os.path.basename(hits[0])


def gt():
    t, e, n, u = [], [], [], []
    with open(REF, encoding="utf-8", errors="replace") as f:
        for line in f:
            q = line.split()
            if len(q) >= 4:
                try:
                    t.append(float(q[0])); e.append(float(q[1])); n.append(float(q[2])); u.append(float(q[3]))
                except ValueError:
                    pass
    return np.array(t), np.array(e), np.array(n), np.array(u)


def panel(ax, label):
    ax.text(-0.14, 1.04, label, transform=ax.transAxes, fontsize=8,
            fontweight="bold", va="bottom", ha="left")


def save(fig, name):
    os.makedirs(FIG, exist_ok=True)
    for ext in ("pdf", "png", "tiff"):
        if ext == "tiff":
            fig.savefig(os.path.join(FIG, f"{name}.{ext}"), dpi=600,
                        bbox_inches="tight", pil_kwargs={"compression": "tiff_lzw"})
        else:
            fig.savefig(os.path.join(FIG, f"{name}.{ext}"), dpi=600, bbox_inches="tight")
    print("wrote", name)


def fig_trajectory():
    gt_t, gt_e, gt_n, _ = gt()
    fig, ax = plt.subplots(figsize=(3.5, 3.1), constrained_layout=True)
    ax.plot(gt_e, gt_n, color=GT, lw=1.2, ls=(0, (4, 2)), label="Ground truth", zorder=2)
    for arm in C:
        t, e, n, u, e3, _ = representative(arm)
        ax.plot(e, n, color=C[arm], lw=1.0, label=arm, zorder=3)
    t, e, n, u, e3, _ = representative("LIVO")
    ax.plot(e[0], n[0], "o", ms=3.5, color=GT, zorder=5)
    ax.set_xlabel("East (m)")
    ax.set_ylabel("North (m)")
    ax.set_aspect("equal", adjustable="box")
    ax.legend(loc="upper left", bbox_to_anchor=(1.02, 1.0), borderaxespad=0,
              fontsize=6.2, handlelength=1.5)
    ax.grid(True, color="0.9", lw=0.4)
    panel(ax, "a")
    save(fig, "fig1_trajectory_enu")
    plt.close(fig)


def fig_error_time():
    fig, ax = plt.subplots(figsize=(3.5, 2.7), constrained_layout=True)
    for arm in C:
        t, e, n, u, e3, _ = representative(arm)
        ax.plot(t, e3, color=C[arm], lw=0.9, label=f"{arm}  RMSE {np.sqrt(np.mean(e3**2)):.2f} m")
        ax.axhline(np.sqrt(np.mean(e3**2)), color=C[arm], lw=0.6, ls=":")
    ax.axvspan(0, LOCK_S, color="0.92", zorder=0)
    ax.text(LOCK_S * 0.5, 0.15, "RTK align", ha="center", va="bottom", fontsize=6, color="0.35")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("3D position error (m)")
    ax.set_xlim(0, 606)
    ax.legend(loc="upper right", fontsize=6)
    panel(ax, "a")
    save(fig, "fig2_error_time")
    plt.close(fig)


def fig_segments():
    rows = read_csv(os.path.join(MET, "phase4_segments.csv"))
    segs = ["convergence_0_79", "multipath_79_201", "recovery_201_300",
            "steady_300_603", "full_0_603"]
    labels = ["0-79", "79-201", "201-300", "300-603", "0-603"]
    arms = list(C)
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.6), constrained_layout=True)
    for ax, col, title, lab in zip(axes, ["median_3D", "median_2D"],
                                   ["3D ATE RMSE", "2D ATE RMSE"], ["a", "b"]):
        x = np.arange(len(segs))
        w = 0.26
        for i, arm in enumerate(arms):
            vals = []
            for s in segs:
                hit = [r for r in rows if r["segment"] == s and r["arm"] == arm]
                vals.append(float(hit[0][col]) if hit else np.nan)
            ax.bar(x + (i - 1) * w, vals, w, color=C[arm], edgecolor="white", lw=0.4, label=arm)
        ax.set_xticks(x)
        ax.set_xticklabels(labels, rotation=0)
        ax.set_xlabel("Segment (s)")
        ax.set_ylabel("ATE RMSE (m)")
        ax.set_title(title, fontsize=7.5, pad=3)
        ax.grid(axis="y", color="0.9", lw=0.4)
        panel(ax, lab)
    axes[0].legend(loc="upper right", fontsize=6)
    save(fig, "fig3_segments")
    plt.close(fig)


def fig_error_map():
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0), constrained_layout=True,
                             sharey=True)
    vmax = 0
    for arm in ("RTK tight", "RTK robust"):
        _, _, _, _, e3, _ = representative(arm)
        vmax = max(vmax, np.percentile(e3, 99))
    vmax = max(vmax, 1.0)
    for ax, arm, lab in zip(axes, ("RTK tight", "RTK robust"), ("a", "b")):
        t, e, n, u, e3, _ = representative(arm)
        pts = np.array([e, n]).T.reshape(-1, 1, 2)
        segs = np.concatenate([pts[:-1], pts[1:]], axis=1)
        lc = LineCollection(segs, cmap="viridis", norm=mpl.colors.Normalize(0, vmax), lw=1.2)
        lc.set_array(e3[:-1])
        ax.add_collection(lc)
        ax.autoscale()
        gt_t, gt_e, gt_n, _ = gt()
        ax.plot(gt_e, gt_n, color="0.25", lw=0.8, ls=(0, (3, 2)))
        ax.set_xlabel("East (m)")
        ax.set_aspect("equal", adjustable="box")
        ax.set_title(arm, fontsize=7.5, pad=3)
        panel(ax, lab)
    axes[0].set_ylabel("North (m)")
    cb = fig.colorbar(lc, ax=axes, shrink=0.86, pad=0.015)
    cb.set_label("3D error (m)", fontsize=6.5)
    cb.ax.tick_params(labelsize=6)
    save(fig, "fig4_error_map")
    plt.close(fig)


def fig_gnss_quality():
    q = read_csv(os.path.join(MET, "phase4_gnss_quality.csv"))
    t = np.array([float(r["t_unix"]) - T0_UTC for r in q])
    code = np.array([float(r["code_rms"]) for r in q])
    npair = np.array([int(r["n_pairs"]) for r in q])
    slips = np.array([int(r["slips"]) for r in q])
    fig, axes = plt.subplots(1, 3, figsize=(7.0, 2.4), constrained_layout=True)
    for ax, y, lab, ylab, color, step in zip(
            axes, [code, npair, slips],
            ["a", "b", "c"],
            ["DD code RMS (m)", "DD pairs per epoch", "Cycle slips per epoch"],
            ["#D55E00", "#0072B2", "#D55E00"],
            [False, True, True]):
        ax.axvspan(MP_LO, MP_HI, color="0.92", zorder=0)
        ax.axvline(LOCK_S, color="0.4", lw=0.7, ls="--")
        if step:
            ax.step(t, y, where="mid", color=color, lw=0.8)
            ax.plot(t, y, "o", ms=2.2, color=color)
        else:
            ax.plot(t, y, "o-", ms=2.4, lw=0.8, color=color)
        ax.set_ylabel(ylab)
        ax.set_xlabel("Time (s)")
        panel(ax, lab)
    save(fig, "fig5_gnss_quality")
    plt.close(fig)


def fig_variability():
    rows = read_csv(os.path.join(MET, "phase4_runs.csv"))
    metrics = [("r3_full", "full 3D"), ("r3_steady", "steady 3D"),
               ("rpe60", "RPE 60 s"), ("rpe120", "RPE 120 s")]
    fig, axes = plt.subplots(1, 2, figsize=(7.0, 2.8), constrained_layout=True,
                             gridspec_kw={"width_ratios": [1.35, 1.0]})
    ax = axes[0]
    x = np.arange(len(metrics))
    for i, arm in enumerate(C):
        vals = [[float(r[k]) for r in rows if r["arm"] == arm] for k, _ in metrics]
        pos = x + (i - 1) * 0.18
        bp = ax.boxplot(vals, positions=pos, widths=0.12, patch_artist=True,
                        showfliers=False, medianprops=dict(color="white", lw=0.8),
                        whiskerprops=dict(lw=0.6), capprops=dict(lw=0.6),
                        boxprops=dict(lw=0.0))
        for b in bp["boxes"]:
            b.set_facecolor(C[arm]); b.set_edgecolor(C[arm])
        for j, v in enumerate(vals):
            ax.plot(np.full(len(v), pos[j]), v, "o", ms=2.0, color=C[arm], alpha=0.9)
    ax.set_xticks(x)
    ax.set_xticklabels([m[1] for m in metrics])
    ax.set_ylabel("Error (m)")
    ax.grid(axis="y", color="0.9", lw=0.4)
    handles = [Patch(facecolor=C[a], label=a) for a in C]
    ax.legend(handles=handles, loc="upper right", fontsize=5.8)
    panel(ax, "a")

    ax = axes[1]
    segs = read_csv(os.path.join(MET, "phase4_segments.csv"))
    names = ["convergence_0_79", "multipath_79_201", "recovery_201_300",
             "steady_300_603", "full_0_603"]
    labels = ["0-79", "79-201", "201-300", "300-603", "0-603"]
    vals = []
    for s in names:
        t = [float(r["median_3D"]) for r in segs if r["segment"] == s and r["arm"] == "RTK tight"]
        rb = [float(r["median_3D"]) for r in segs if r["segment"] == s and r["arm"] == "RTK robust"]
        vals.append(rb[0] - t[0] if t and rb else np.nan)
    ax.bar(np.arange(len(names)), vals, color="#009E73", width=0.6, edgecolor="white")
    ax.axhline(0, color="0.3", lw=0.6)
    ax.set_xticks(np.arange(len(names)))
    ax.set_xticklabels(labels)
    ax.set_ylabel("robust - tight 3D (m)")
    ax.set_xlabel("Segment (s)")
    ax.grid(axis="y", color="0.9", lw=0.4)
    panel(ax, "b")
    save(fig, "fig6_variability_ablation")
    plt.close(fig)


def main():
    fig_trajectory()
    fig_error_time()
    fig_segments()
    fig_error_map()
    fig_gnss_quality()
    fig_variability()


if __name__ == "__main__":
    main()
