import numpy as np

RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"
REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\campus01_reference.tum"


def load_tum(p):
    d = np.loadtxt(p)
    return d[:, 0], d[:, 1:4]


def interp(rt, rp, qt):
    return np.array([np.interp(qt, rt, rp[:, k]) for k in range(3)]).T


def umeyama(est, gt):
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg


rt, rp = load_tum(REF)
ft, fp = load_tum(f"{RES}\\great_campus01_occlusion.txt")
m = (rt >= ft[0]) & (rt <= ft[-1])
p_f = interp(ft, fp, rt[m])
p_g = rp[m]
e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
t = rt[m] - rt[m][0]
print("occlusion APE at selected times (s, m):")
for tt in range(0, int(t[-1]), 60):
    idx = np.argmin(np.abs(t - tt))
    print(f"  t={t[idx]:5.0f}s  APE={e[idx]:8.2f} m")
print(f"  max APE at t={t[np.argmax(e)]:.0f}s: {np.max(e):.1f} m")
# how far does the trajectory drift from the reference at the end?
print(f"  unaligned end drift: {np.linalg.norm(fp[-1]-rp[-1]):.1f} m")
# check for jumps in the trajectory (discontinuities)
jumps = np.linalg.norm(np.diff(fp, axis=0), axis=1)
print(f"  max inter-frame jump: {np.max(jumps):.3f} m (median {np.median(jumps):.3f})")
