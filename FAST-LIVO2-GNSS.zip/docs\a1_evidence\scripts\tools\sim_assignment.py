#!/usr/bin/env python3
"""Count what the A0 unique-nearest rule can actually assign.

Diagnostic only: replays the assignment rule on the recorded keyframe/fix times
and status labels, so an unexpectedly small `rtk=` count can be explained
(no match vs. quality gate) instead of guessed.
"""
import argparse
import csv

import numpy as np

ROOT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main"
DATA = ROOT + "/01_文档/02_改进与精度汇总/阶段1_离线图修复_2026-10-30/data"
STATUS = (ROOT + "/01_文档/02_改进与精度汇总/阶段0_评估契约_2026-10-30/"
                 "v2_epoch_errors.csv")


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("campus", choices=["c01", "c02"])
    ap.add_argument("--start", type=float, default=0.0)
    ap.add_argument("--dur", type=float, default=0.0)
    ap.add_argument("--jump-gate", action="store_true",
                    help="also emulate addFix(): 30 m / 2 s prediction gate")
    args = ap.parse_args()

    livo = DATA.replace("阶段1_离线图修复_2026-10-30/data", "")
    livo = (ROOT + "/03_实验记录/对比实验/gv1/oracle/"
            f"gv1_campus{args.campus[-2:]}_livo_r1_base.tum")
    kf = np.loadtxt(livo, usecols=0)
    fxy = np.loadtxt(DATA + f"/campus{args.campus[-2:]}_rtk1hz.tum")
    t0 = kf[0] + args.start
    dur = args.dur or (kf[-1] - kf[0] - args.start)
    kf = kf[(kf >= t0) & (kf <= t0 + dur)]
    fxy = fxy[(fxy[:, 0] >= t0 - 5.0) & (fxy[:, 0] <= t0 + dur + 5.0)]

    n_reject = 0
    if args.jump_gate:
        kept = []
        last = prev = None
        for row in fxy:
            if last is not None:
                dt = row[0] - last[0]
                if 0.0 < dt <= 2.0:
                    pred = last[1:4].copy()
                    if prev is not None:
                        dtl = last[0] - prev[0]
                        if dtl > 0.0:
                            pred += (last[1:4] - prev[1:4]) / dtl * dt
                    if np.linalg.norm(row[1:3] - pred[:2]) > 30.0:
                        n_reject += 1
                        continue
            prev = last
            last = row
            kept.append(row)
        fxy = np.asarray(kept)
    fx = fxy[:, 0]

    st = {}
    with open(STATUS, encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            try:
                st[float(r["tau"])] = int(float(r["status"]))
            except (KeyError, ValueError):
                pass
    keys = np.fromiter(st.keys(), float)

    used = np.zeros(len(fx), bool)
    ok = q = far = 0
    for t in kf:
        j = int(np.argmin(np.abs(fx - t)))
        if abs(fx[j] - t) < 0.6 and not used[j]:
            used[j] = True
            i = int(np.argmin(np.abs(keys - t)))
            if abs(keys[i] - t) <= 0.55 and st[keys[i]] >= 2:
                ok += 1
            else:
                q += 1
        else:
            far += 1
    print(f"kf={len(kf)} fx={len(fx)} jump_rejected={n_reject} "
          f"assigned_quality_ok={ok} assigned_bad_status={q} "
          f"no_match_or_used={far} kf_dt_med={np.median(np.diff(kf)):.4f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
