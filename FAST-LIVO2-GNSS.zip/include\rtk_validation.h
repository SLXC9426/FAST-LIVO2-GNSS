#ifndef RTK_VALIDATION_H
#define RTK_VALIDATION_H

// Single validation entry point for fast_livo::RtkDD.
//
// Both consumers (RtkTight::update and online_graph_node::ddCallback) must accept
// or reject a whole epoch with the same rules.  The old code truncated the pair
// count to the shortest array on the online-graph side, which silently changes
// the observation set; here a malformed epoch is rejected outright.

#include <fast_livo/RtkDD.h>

#include <cmath>
#include <string>

namespace fast_livo
{

struct RtkDDValidation
{
  bool ok = false;
  std::string reason;
};

inline RtkDDValidation validateRtkDD(const fast_livo::RtkDD &msg)
{
  const int n = static_cast<int>(msg.n);
  const int kMaxPairs = 64;  // well above any real epoch; keeps Eigen sizes sane
  if (n < 3) return {false, "n < 3"};
  if (n > kMaxPairs) return {false, "n > 64"};

  const auto short_array = [n](size_t size) { return static_cast<int>(size) < n; };
  if (short_array(msg.sys.size()) || short_array(msg.freq.size()) ||
      short_array(msg.sat.size()) || short_array(msg.ref_sat.size()) ||
      short_array(msg.dd_code.size()) || short_array(msg.dd_phase.size()) ||
      short_array(msg.sat_x.size()) || short_array(msg.sat_y.size()) ||
      short_array(msg.sat_z.size()) || short_array(msg.ref_x.size()) ||
      short_array(msg.ref_y.size()) || short_array(msg.ref_z.size()) ||
      short_array(msg.sigma_code.size()) || short_array(msg.sigma_phase.size()) ||
      short_array(msg.slip.size()) || short_array(msg.ref_change.size()))
  {
    return {false, "required array shorter than n"};
  }

  // Optional fixed-phase arrays are allowed to be absent (float-only epoch) but
  // must not be partially populated.
  const auto partial_optional = [n](size_t size) {
    return size > 0 && static_cast<int>(size) < n;
  };
  if (partial_optional(msg.fix_valid.size()) ||
      partial_optional(msg.dd_phase_fixed.size()) ||
      partial_optional(msg.sigma_phase_fixed.size()))
  {
    return {false, "optional fixed-phase array shorter than n"};
  }

  for (int i = 0; i < n; ++i)
  {
    if (msg.sat[i].empty() || msg.ref_sat[i].empty())
      return {false, "empty satellite id"};
    if (msg.sat[i] == msg.ref_sat[i])
      return {false, "satellite equals reference"};
    if (!std::isfinite(msg.dd_code[i]) || !std::isfinite(msg.dd_phase[i]))
      return {false, "non-finite code or phase"};
    if (!std::isfinite(msg.sat_x[i]) || !std::isfinite(msg.sat_y[i]) ||
        !std::isfinite(msg.sat_z[i]) || !std::isfinite(msg.ref_x[i]) ||
        !std::isfinite(msg.ref_y[i]) || !std::isfinite(msg.ref_z[i]))
      return {false, "non-finite satellite position"};
    if (!std::isfinite(msg.sigma_code[i]) || msg.sigma_code[i] <= 0.0)
      return {false, "invalid sigma_code"};
    if (!std::isfinite(msg.sigma_phase[i]) || msg.sigma_phase[i] <= 0.0)
      return {false, "invalid sigma_phase"};
  }
  return {true, ""};
}

}  // namespace fast_livo

#endif  // RTK_VALIDATION_H
