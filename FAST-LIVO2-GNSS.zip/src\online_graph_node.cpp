﻿// P5b/P6a: separate online graph node.
//
// The main FAST-LIVO node publishes 1 Hz keyframe poses (scheme B snapshot)
// and raw ENU fixes on /online_graph/*. This node runs the validated
// bounded-history GTSAM position graph in its own process, so the main node
// does not link GTSAM (the installed GTSAM and the package's -march=native
// Eigen flags are ABI incompatible).
//
// P6a adds a 1 Hz global output contract:
//   /online_graph/global_odom  nav_msgs/Odometry  (ENU, position smoothed)
//   /online_graph/global_path  nav_msgs/Path      (last path_len nodes)
//   /online_graph/status       diagnostic_msgs/DiagnosticArray
//
// P0 (2026-10-30): the node now subscribes to the richer
// OnlineGraphKeyframe/OnlineGraphFix messages (lambda_min + per-epoch
// quality) and to the raw /rtk/dd stream for TDDD relative factors.

#include <ros/ros.h>
#include <geometry_msgs/PoseStamped.h>
#include <geometry_msgs/PointStamped.h>
#include <geometry_msgs/Vector3Stamped.h>
#include <nav_msgs/Odometry.h>
#include <nav_msgs/Path.h>
#include <diagnostic_msgs/DiagnosticArray.h>
#include <diagnostic_msgs/DiagnosticStatus.h>
#include <diagnostic_msgs/KeyValue.h>

#include <Eigen/Geometry>
#include <algorithm>
#include <cmath>
#include "rtk_validation.h"
#include <cstdint>
#include <fstream>
#include <memory>
#include <sstream>
#include <string>
#include <vector>

#include "global_pose_graph.h"
#include "graph_covariance.h"
#include "fast_livo/OnlineGraphFix.h"
#include "fast_livo/OnlineGraphKeyframe.h"
#include "fast_livo/OnlineGraphVel.h"
#include "fast_livo/RtkDD.h"

namespace
{
std::unique_ptr<fast_livo::GlobalPoseGraph> g_graph;
ros::Publisher g_pub_odom;
ros::Publisher g_pub_path;
ros::Publisher g_pub_corr;
ros::Publisher g_pub_status;
std::ofstream g_timing_trace;

fast_livo::GlobalPoseGraph::Result g_last_result;
uint64_t g_last_seq = 0;
bool g_have_result = false;
ros::WallTime g_last_result_wall;

std::string g_frame_id = "enu";
std::string g_child_frame_id = "base_link";
int g_window = 1500;
int g_path_len = 600;
double g_max_result_age = 2.5;
double g_cov_xy = 0.2;
double g_cov_z = 0.5;
double g_cov_yaw = 0.5;

void traceTiming(const char *event, const ros::Time &stamp, uint64_t seq = 0)
{
  if (g_timing_trace.is_open())
    g_timing_trace << event << ',' << stamp.toNSec() << ','
                   << ros::SteadyTime::now().toNSec() << ','
                   << ros::Time::now().toNSec() << ',' << seq << '\n';
}

std::string fmt(double v, int prec = 3)
{
  std::ostringstream os;
  os.setf(std::ios::fixed);
  os.precision(prec);
  os << v;
  return os.str();
}

void setOdomCov(nav_msgs::Odometry &odom)
{
  auto &cov = odom.pose.covariance;
  std::fill(cov.begin(), cov.end(), 0.0);
  cov[0] = g_cov_xy * g_cov_xy;
  cov[7] = g_cov_xy * g_cov_xy;
  cov[14] = g_cov_z * g_cov_z;
  // Orientation is the EKF attitude rotated into ENU, not a graph state.
  cov[21] = 0.25;  // roll
  cov[28] = 0.25;  // pitch
  cov[35] = g_cov_yaw * g_cov_yaw;
}

void keyframeCallback(const fast_livo::OnlineGraphKeyframe::ConstPtr &msg)
{
  if (!g_graph) return;
  traceTiming("keyframe", msg->header.stamp);
  fast_livo::GlobalPoseGraph::Keyframe kf;
  kf.t = msg->header.stamp.toSec();
  kf.p = Eigen::Vector3d(msg->pose.position.x, msg->pose.position.y,
                         msg->pose.position.z);
  Eigen::Quaterniond q(msg->pose.orientation.w, msg->pose.orientation.x,
                       msg->pose.orientation.y, msg->pose.orientation.z);
  kf.R = q.normalized().toRotationMatrix();
  kf.lambda_min = msg->lambda_min;
  kf.have_frame = msg->frame_valid;
  if (kf.have_frame)
  {
    const auto &tr = msg->world_from_enu.translation;
    const auto &rot = msg->world_from_enu.rotation;
    Eigen::Quaterniond qf(rot.w, rot.x, rot.y, rot.z);
    kf.R_world_from_enu = qf.normalized().toRotationMatrix();
    kf.t_world_from_enu = Eigen::Vector3d(tr.x, tr.y, tr.z);
    kf.frame_scale = msg->scale > 0.0 ? msg->scale : 1.0;
  }
  g_graph->addKeyframe(kf);
}

void fixCallback(const fast_livo::OnlineGraphFix::ConstPtr &msg)
{
  if (!g_graph) return;
  traceTiming("fix", msg->header.stamp);
  fast_livo::GlobalPoseGraph::Fix fx;
  fx.t = msg->header.stamp.toSec();
  fx.p = Eigen::Vector3d(msg->point.x, msg->point.y, msg->point.z);
  const auto &cov = msg->position_covariance;
  if (cov[0] > 0.0 || cov[4] > 0.0)
    fx.sigma_h = std::sqrt(std::max(0.0, 0.5 * (cov[0] + cov[4])));
  if (cov[8] > 0.0) fx.sigma_v = std::sqrt(cov[8]);
  fx.status = static_cast<int>(msg->status);
  fx.nsat = static_cast<int>(msg->nsat);
  fx.pdop = msg->pdop;
  fx.sigma0 = msg->sigma0;
  fx.rms_xyz = msg->rms_xyz;
  // A2.1: carried into the trace only. No factor, sigma or gate reads these
  // fields until the A2.3 gating experiment.
  fx.h_acc_mm = msg->h_acc_mm;
  fx.v_acc_mm = msg->v_acc_mm;
  fx.carr_soln = static_cast<int>(msg->carr_soln);
  fx.fix_type = static_cast<int>(msg->fix_type);
  fx.quality_valid = msg->quality_valid;
  fx.has_p_dop = msg->has_p_dop;
  fx.has_h_acc = msg->has_h_acc;
  fx.has_v_acc = msg->has_v_acc;
  fx.quality_source = msg->quality_source;
  // The first fix carries the ENU frame origin. TDDD needs it to rotate the
  // satellite ECEF vectors into the graph ENU frame.
  if (msg->lat0 != 0.0 || msg->lon0 != 0.0)
    g_graph->setEnuOrigin(msg->lat0 * M_PI / 180.0,
                          msg->lon0 * M_PI / 180.0, msg->alt0);
  g_graph->addFix(fx);
}

void ddCallback(const fast_livo::RtkDD::ConstPtr &msg)
{
  if (!g_graph) return;
  const fast_livo::RtkDDValidation valid = fast_livo::validateRtkDD(*msg);
  if (!valid.ok)
  {
    ROS_WARN_THROTTLE(1.0, "online_graph: drop malformed RtkDD epoch: %s",
                      valid.reason.c_str());
    return;
  }
  fast_livo::GlobalPoseGraph::DdEpoch epoch;
  epoch.t = msg->header.stamp.toSec();
  epoch.ratio = msg->ratio;
  const int n = static_cast<int>(msg->n);
  epoch.pairs.reserve(n);
  for (int i = 0; i < n; ++i)
  {
    fast_livo::GlobalPoseGraph::DdPair p;
    p.sys = msg->sys[i];
    p.freq = msg->freq[i];
    p.sat = msg->sat[i];
    p.ref = msg->ref_sat[i];
    if (i < static_cast<int>(msg->dd_code.size())) p.code = msg->dd_code[i];
    p.phase = msg->dd_phase[i];
    p.sigma_phase = msg->sigma_phase[i] > 0.0 ? msg->sigma_phase[i] : 0.015;
    if (i < static_cast<int>(msg->elev_sat.size())) p.elev_sat = msg->elev_sat[i];
    if (i < static_cast<int>(msg->elev_ref.size())) p.elev_ref = msg->elev_ref[i];
    p.sat_ecef = Eigen::Vector3d(msg->sat_x[i], msg->sat_y[i], msg->sat_z[i]);
    p.ref_ecef = Eigen::Vector3d(msg->ref_x[i], msg->ref_y[i], msg->ref_z[i]);
    p.slip = msg->slip[i] != 0;
    p.ref_change = msg->ref_change[i] != 0;
    epoch.pairs.push_back(p);
  }
  if (!epoch.pairs.empty()) g_graph->addDdEpoch(epoch);
}

void velCallback(const fast_livo::OnlineGraphVel::ConstPtr &msg)
{
  if (!g_graph) return;
  static int vel_print = 0;
  if (vel_print < 3)
  {
    ROS_INFO("online_graph: vel rx t=%.3f v=(%.3f %.3f %.3f) sig=(%.3f %.3f)",
             msg->header.stamp.toSec(), msg->vel_enu.x, msg->vel_enu.y,
             msg->vel_enu.z, msg->sigma_h, msg->sigma_v);
    vel_print++;
  }
  fast_livo::GlobalPoseGraph::Vel v;
  v.t = msg->header.stamp.toSec();
  v.v = Eigen::Vector3d(msg->vel_enu.x, msg->vel_enu.y, msg->vel_enu.z);
  v.sigma_h = msg->sigma_h;
  v.sigma_v = msg->sigma_v;
  v.source = msg->source;
  if (msg->source == "ins")
    ROS_WARN_ONCE(
        "online_graph: velocity input is GREAT-MSF INS velocity aid, not raw "
        "satellite Doppler; PVT/velocity cross-covariance is not modeled");
  g_graph->addVel(v);
}

void publishOdometry(const fast_livo::GlobalPoseGraph::Result &res)
{
  if (!g_pub_odom || res.nodes.empty()) return;
  const auto &node = res.nodes.back();
  nav_msgs::Odometry odom;
  odom.header.stamp = ros::Time().fromSec(node.t);
  odom.header.frame_id = g_frame_id;
  odom.child_frame_id = g_child_frame_id;
  odom.pose.pose.position.x = node.p.x();
  odom.pose.pose.position.y = node.p.y();
  odom.pose.pose.position.z = node.p.z();
  Eigen::Quaterniond q(res.Rz * node.R);
  q.normalize();
  odom.pose.pose.orientation.x = q.x();
  odom.pose.pose.orientation.y = q.y();
  odom.pose.pose.orientation.z = q.z();
  odom.pose.pose.orientation.w = q.w();
  // R4.3: the graph velocity is ENU; nav_msgs/Odometry expects the twist in the
  // child (body) frame, so rotate it back.
  const Eigen::Matrix3d R_enu_body = res.Rz * node.R;
  const Eigen::Vector3d v_body = R_enu_body.transpose() * node.v;
  odom.twist.twist.linear.x = v_body.x();
  odom.twist.twist.linear.y = v_body.y();
  odom.twist.twist.linear.z = v_body.z();
  if (res.cov_valid)
  {
    for (int i = 0; i < 36; ++i) odom.pose.covariance[i] = res.cov_pose.data()[i];
    // The graph velocity covariance is ENU; the published twist is body-frame.
    const Eigen::Matrix3d P_body =
        fast_livo::velocityCovarianceToBody(res.cov_vel, R_enu_body);
    for (int r = 0; r < 3; ++r)
      for (int c = 0; c < 3; ++c)
        odom.twist.covariance[r * 6 + c] = P_body(r, c);
  }
  else
  {
    setOdomCov(odom);
  }
  g_pub_odom.publish(odom);
  traceTiming("odom", odom.header.stamp, res.seq);
}

void publishPath(const fast_livo::GlobalPoseGraph::Result &res)
{
  if (!g_pub_path || res.nodes.empty()) return;
  nav_msgs::Path path;
  path.header.frame_id = g_frame_id;
  path.header.stamp = ros::Time().fromSec(res.nodes.back().t);
  const int n = static_cast<int>(res.nodes.size());
  const int start = std::max(0, n - std::max(1, g_path_len));
  path.poses.reserve(n - start);
  for (int i = start; i < n; ++i)
  {
    const auto &node = res.nodes[i];
    geometry_msgs::PoseStamped ps;
    ps.header.frame_id = g_frame_id;
    ps.header.stamp = ros::Time().fromSec(node.t);
    ps.pose.position.x = node.p.x();
    ps.pose.position.y = node.p.y();
    ps.pose.position.z = node.p.z();
    Eigen::Quaterniond q(res.Rz * node.R);
    q.normalize();
    ps.pose.orientation.x = q.x();
    ps.pose.orientation.y = q.y();
    ps.pose.orientation.z = q.z();
    ps.pose.orientation.w = q.w();
    path.poses.push_back(ps);
  }
  g_pub_path.publish(path);
}

void publishCorrection(const fast_livo::GlobalPoseGraph::Result &res)
{
  if (!g_pub_corr || res.nodes.empty()) return;
  const auto &node = res.nodes.back();
  // P0: the initial fit is now a similarity transform, so the inverse mapping
  // must divide by the scale as well.
  const Eigen::Vector3d p_lio =
      res.Rz.transpose() * ((node.p - res.tr) / std::max(1e-6, res.scale));
  const Eigen::Vector3d corr = p_lio - node.p_in;
  geometry_msgs::Vector3Stamped msg;
  msg.header.stamp = ros::Time().fromSec(node.t);
  msg.header.frame_id = "camera_init";
  msg.vector.x = corr.x();
  msg.vector.y = corr.y();
  msg.vector.z = corr.z();
  g_pub_corr.publish(msg);
}

void publishStatus(const fast_livo::GlobalPoseGraph::Stats &st, double age,
                   bool fresh, int level, const std::string &message)
{
  if (!g_pub_status) return;
  diagnostic_msgs::DiagnosticArray arr;
  arr.header.stamp = ros::Time::now();
  diagnostic_msgs::DiagnosticStatus ds;
  ds.level = static_cast<unsigned char>(level);
  ds.name = "online_graph";
  ds.hardware_id = "fast_livo";
  ds.message = message;
  auto add = [&ds](const std::string &k, const std::string &v) {
    diagnostic_msgs::KeyValue kv;
    kv.key = k;
    kv.value = v;
    ds.values.push_back(kv);
  };
  add("state", message);
  add("keyframes", std::to_string(st.keyframes));
  add("total_keyframes", std::to_string(st.total_keyframes));
  add("window_slid", st.window_slid ? "true" : "false");
  add("oldest_stamp", fmt(st.oldest_stamp, 3));
  add("newest_stamp", fmt(st.newest_stamp, 3));
  add("fixes", std::to_string(st.fixes));
  add("rejected_fixes", std::to_string(st.rejected_fixes));
  add("rtk_used", std::to_string(st.rtk_used));
  add("tddd_used", std::to_string(st.tddd_used));
  add("dd_epochs", std::to_string(st.dd_epochs));
  add("scale", fmt(st.scale, 5));
  add("w_rtk_med", fmt(st.w_rtk_med, 3));
  add("solves", std::to_string(st.solves));
  add("last_solve_ms", fmt(st.last_solve_ms, 2));
  add("result_seq", std::to_string(st.result_seq));
  add("result_stamp", fmt(st.last_result_stamp, 3));
  add("age_s", age < 0.0 ? std::string("none") : fmt(age, 2));
  add("fresh", fresh ? "true" : "false");
  add("window", std::to_string(g_window));
  add("frame_id", g_frame_id);
  arr.status.push_back(ds);
  g_pub_status.publish(arr);
}

void pollResultCallback(const ros::TimerEvent &)
{
  if (!g_graph) return;
  fast_livo::GlobalPoseGraph::Result res;
  uint64_t seq = g_last_seq;
  if (!g_graph->getLatestResult(res, seq)) return;
  g_last_result = res;
  g_last_seq = seq;
  g_have_result = true;
  g_last_result_wall = ros::WallTime::now();
  // This callback only runs on a new solve, so it cannot miss a 1 Hz result.
  publishOdometry(g_last_result);
  publishPath(g_last_result);
  publishCorrection(g_last_result);
}

void statusCallback(const ros::TimerEvent &)
{
  if (!g_graph) return;
  const auto st = g_graph->getStats();
  const double age = g_have_result
                         ? (ros::WallTime::now() - g_last_result_wall).toSec()
                         : -1.0;
  const bool fresh = g_have_result && age >= 0.0 && age <= g_max_result_age;

  int level = diagnostic_msgs::DiagnosticStatus::OK;
  std::string message = "OK";
  if (st.status == 3)
  {
    level = diagnostic_msgs::DiagnosticStatus::ERROR;
    message = "SOLVE_ERROR";
  }
  else if (!g_have_result)
  {
    level = diagnostic_msgs::DiagnosticStatus::WARN;
    message = st.status == 2 ? "INIT" : "NO_RESULT";
  }
  else if (!fresh)
  {
    level = diagnostic_msgs::DiagnosticStatus::WARN;
    message = "STALE";
  }
  else if (st.status == 2)
  {
    level = diagnostic_msgs::DiagnosticStatus::WARN;
    message = "NOT_ENOUGH_DATA";
  }
  else if (st.window_slid)
  {
    level = diagnostic_msgs::DiagnosticStatus::WARN;
    message = "WINDOW_LIMIT";
  }

  publishStatus(st, age, fresh, level, message);
}

}  // namespace

int main(int argc, char **argv)
{
  ros::init(argc, argv, "online_graph_node");
  ros::NodeHandle nh("~");

  int window = 1500;
  std::string output = "online_graph.tum";
  std::vector<double> lever = {-0.05, -0.325, 0.165};
  std::vector<double> base_ecef = {-2267749.9279, 5009154.2407, 3221290.6333};
  bool publish_odom = true;
  bool publish_path = true;
  bool publish_correction = true;
  bool tum_output = true;
  int path_len = 600;
  double status_rate = 1.0;
  double result_rate = 10.0;
  double solve_rate = 2.0;
  double max_result_age = 2.5;
  double cov_xy = 0.2;
  double cov_z = 0.5;
  double cov_yaw = 0.5;
  std::string frame_id = "enu";
  std::string child_frame_id = "base_link";
  // P0 switches (defaults follow the offline Stage-2/Stage-4 best set).
  bool tddd_en = true;
  double tddd_sigma_scale = 1.0;
  int tddd_min_pairs = 6;
  double tddd_max_dt = 0.25;
  bool quality_gate_en = true;
  int quality_min_status = 2;
  int quality_min_nsat = 0;
  double quality_max_pdop = 0.0;
  double quality_max_sigma0 = 0.0;
  double quality_max_rms = 0.0;
  bool cauchy_xy_en = true;
  bool lambda_weight_en = true;
  bool scale_fit_en = true;
  double sig_rigid = 0.01;
  double sig_anchor = 0.3;
  // S1: expose the static-anchor weakening rule and the transition-factor
  // count as experimental parameters. Defaults reproduce the previous
  // hard-coded GlobalPoseGraphConfig values exactly.
  double static_anchor_weak = 10.0;
  double static_anchor_consistency = 1.0;
  int trans_kf = 8;
  // A4/W1: fixed odometer horizontal sigma; 0 keeps the fit_rms formula.
  double odom_sigma_fixed = 0.0;
  // A3.2: unified-set estimation (requires static_anchor_validity_en).
  bool static_anchor_unified_en = false;
  // R0/R2: read-only diagnostics (empty = off).
  std::string solve_watermark_path;
  std::string usage_trace_path;
  bool tddd_time_shift_auto = false;
  double tddd_time_shift = 0.0;
  // A1: RTK epoch <-> keyframe time association.
  bool rtk_interp_en = false;
  bool rtk_static_rule_bracket = true;
  // A2.3 class gate (default off).
  bool rtk_class_gate_en = false;
  bool gate_reject_invalid = true;
  bool gate_reject_unknown = false;
  bool gate_reject_degraded = false;
  bool gate_reject_float = false;
  // A2.4 innovation gate (default off).
  bool rtk_innovation_gate_en = false;
  double rtk_innovation_chi2 = 11.345;
  double rtk_innovation_sigma0 = 0.30;
  double rtk_innovation_drift = 0.02;
  double rtk_innovation_sigma_ceil = 10.0;
  // A2.5 initial-fit robustness (default off).
  bool fit_robust_en = false;
  double fit_huber_k = 1.5;
  bool fit_two_pass_en = false;
  int fit_min_samples = 20;
  double fit_min_accepted_ratio = 0.5;
  double fit_max_scale_delta = 0.05;
  double fit_max_yaw_delta_deg = 5.0;
  double fit_max_gap_ratio = 0.5;
  double fit_min_rms_gain = 0.01;
  // A3.1 static-anchor validity gate (default off).
  bool static_anchor_validity_en = false;
  double static_anchor_trim_start_sec = 0.0;
  double static_anchor_trim_end_sec = 0.0;
  double static_anchor_reference_onset_sec = -1.0;
  double static_anchor_fallback_end_trim_sec = 2.0;
  int static_anchor_min_samples = 0;
  double static_anchor_min_fixed_ratio = 0.0;
  double static_anchor_max_rtk_net_displacement = 0.0;
  double static_anchor_max_rtk_p95 = 0.0;
  double static_anchor_max_rtk_deviation = 0.0;
  double static_anchor_max_slow_drift = 0.0;
  std::string static_anchor_diagnostics_path;
  double rtk_interp_max_bracket_dt = 1.5;
  double rtk_interp_max_extrapolation = 0.0;
  double rtk_interp_min_alpha = 0.0;
  double rtk_interp_max_alpha = 1.0;
  double rtk_interp_model_sigma = 0.10;
  bool rtk_interp_robust_en = true;
  std::string assoc_trace_path;
  bool vel_en = true;
  double vel_sigma_floor = 0.20;
  double vel_sigma_ceil = 2.0;
  double vel_max_dt = 1.0;
  double vel_rw_sigma = 0.5;
  double sig_motion = 0.10;
  double motion_accel_psd = 0.01;
  bool cov_en = true;
  bool fixed_lag_en = true;
  double boundary_sigma_pos = 0.05;
  double boundary_sigma_rot = 0.005;
  double boundary_sigma_vel = 0.05;

  nh.param<int>("window", window, 1500);
  nh.param<std::string>("output", output, output);
  nh.param<std::vector<double>>("lever", lever, lever);
  nh.param<std::vector<double>>("base_ecef", base_ecef, base_ecef);
  nh.param<bool>("publish_odom", publish_odom, true);
  nh.param<bool>("publish_path", publish_path, true);
  nh.param<bool>("publish_correction", publish_correction, true);
  nh.param<bool>("tum_output", tum_output, true);
  nh.param<int>("path_len", path_len, 600);
  nh.param<double>("status_rate", status_rate, 1.0);
  nh.param<double>("result_rate", result_rate, 10.0);
  nh.param<double>("solve_rate", solve_rate, 2.0);
  nh.param<double>("max_result_age", max_result_age, 2.5);
  nh.param<double>("cov_xy", cov_xy, 0.2);
  nh.param<double>("cov_z", cov_z, 0.5);
  nh.param<double>("cov_yaw", cov_yaw, 0.5);
  nh.param<std::string>("frame_id", frame_id, "enu");
  nh.param<std::string>("child_frame_id", child_frame_id, "base_link");
  nh.param<bool>("tddd_en", tddd_en, true);
  nh.param<double>("tddd_sigma_scale", tddd_sigma_scale, 1.0);
  nh.param<int>("tddd_min_pairs", tddd_min_pairs, 6);
  nh.param<double>("tddd_max_dt", tddd_max_dt, 0.25);
  nh.param<bool>("quality_gate_en", quality_gate_en, true);
  nh.param<int>("quality_min_status", quality_min_status, 2);
  nh.param<int>("quality_min_nsat", quality_min_nsat, 0);
  nh.param<double>("quality_max_pdop", quality_max_pdop, 0.0);
  nh.param<double>("quality_max_sigma0", quality_max_sigma0, 0.0);
  nh.param<double>("quality_max_rms", quality_max_rms, 0.0);
  nh.param<bool>("cauchy_xy_en", cauchy_xy_en, true);
  nh.param<bool>("lambda_weight_en", lambda_weight_en, true);
  nh.param<bool>("scale_fit_en", scale_fit_en, true);
  nh.param<double>("sig_rigid", sig_rigid, 0.01);
  nh.param<double>("sig_anchor", sig_anchor, 0.3);
  nh.param<double>("static_anchor_weak", static_anchor_weak, 10.0);
  nh.param<double>("static_anchor_consistency", static_anchor_consistency,
                   1.0);
  nh.param<int>("trans_kf", trans_kf, 8);
  nh.param<double>("odom_sigma_fixed", odom_sigma_fixed, 0.0);
  nh.param<bool>("static_anchor_unified_en", static_anchor_unified_en,
                 false);
  nh.param<std::string>("solve_watermark_path", solve_watermark_path, "");
  nh.param<std::string>("usage_trace_path", usage_trace_path, "");
  nh.param<bool>("tddd_time_shift_auto", tddd_time_shift_auto, false);
  nh.param<double>("tddd_time_shift", tddd_time_shift, 0.0);
  nh.param<bool>("rtk_interp_en", rtk_interp_en, false);
  nh.param<bool>("rtk_static_rule_bracket", rtk_static_rule_bracket, true);
  nh.param<bool>("rtk_class_gate_en", rtk_class_gate_en, false);
  nh.param<bool>("rtk_class_gate_reject_invalid", gate_reject_invalid, true);
  nh.param<bool>("rtk_class_gate_reject_unknown", gate_reject_unknown, false);
  nh.param<bool>("rtk_class_gate_reject_degraded", gate_reject_degraded, false);
  nh.param<bool>("rtk_class_gate_reject_float", gate_reject_float, false);
  nh.param<bool>("rtk_innovation_gate_en", rtk_innovation_gate_en, false);
  nh.param<double>("rtk_innovation_chi2", rtk_innovation_chi2, 11.345);
  nh.param<double>("rtk_innovation_sigma0", rtk_innovation_sigma0, 0.30);
  nh.param<double>("rtk_innovation_drift", rtk_innovation_drift, 0.02);
  nh.param<double>("rtk_innovation_sigma_ceil", rtk_innovation_sigma_ceil,
                   10.0);
  nh.param<bool>("fit_robust_en", fit_robust_en, false);
  nh.param<double>("fit_huber_k", fit_huber_k, 1.5);
  nh.param<bool>("fit_two_pass_en", fit_two_pass_en, false);
  nh.param<int>("fit_min_samples", fit_min_samples, 20);
  nh.param<double>("fit_min_accepted_ratio", fit_min_accepted_ratio, 0.5);
  nh.param<double>("fit_max_scale_delta", fit_max_scale_delta, 0.05);
  nh.param<double>("fit_max_yaw_delta_deg", fit_max_yaw_delta_deg, 5.0);
  nh.param<double>("fit_max_gap_ratio", fit_max_gap_ratio, 0.5);
  nh.param<double>("fit_min_rms_gain", fit_min_rms_gain, 0.01);
  nh.param<bool>("static_anchor_validity_en", static_anchor_validity_en, false);
  nh.param<double>("static_anchor_trim_start_sec",
                   static_anchor_trim_start_sec, 0.0);
  nh.param<double>("static_anchor_trim_end_sec",
                   static_anchor_trim_end_sec, 0.0);
  nh.param<double>("static_anchor_reference_onset_sec",
                   static_anchor_reference_onset_sec, -1.0);
  nh.param<double>("static_anchor_fallback_end_trim_sec",
                   static_anchor_fallback_end_trim_sec, 2.0);
  nh.param<int>("static_anchor_min_samples", static_anchor_min_samples, 0);
  nh.param<double>("static_anchor_min_fixed_ratio",
                   static_anchor_min_fixed_ratio, 0.0);
  nh.param<double>("static_anchor_max_rtk_net_displacement",
                   static_anchor_max_rtk_net_displacement, 0.0);
  nh.param<double>("static_anchor_max_rtk_p95",
                   static_anchor_max_rtk_p95, 0.0);
  nh.param<double>("static_anchor_max_rtk_deviation",
                   static_anchor_max_rtk_deviation, 0.0);
  nh.param<double>("static_anchor_max_slow_drift",
                   static_anchor_max_slow_drift, 0.0);
  nh.param<std::string>("static_anchor_diagnostics_path",
                        static_anchor_diagnostics_path, "");
  nh.param<double>("rtk_interp_max_bracket_dt", rtk_interp_max_bracket_dt, 1.5);
  nh.param<double>("rtk_interp_max_extrapolation",
                   rtk_interp_max_extrapolation, 0.0);
  nh.param<double>("rtk_interp_min_alpha", rtk_interp_min_alpha, 0.0);
  nh.param<double>("rtk_interp_max_alpha", rtk_interp_max_alpha, 1.0);
  nh.param<double>("rtk_interp_model_sigma", rtk_interp_model_sigma, 0.10);
  nh.param<bool>("rtk_interp_robust_en", rtk_interp_robust_en, true);
  nh.param<std::string>("assoc_trace", assoc_trace_path, "");
  double tddd_model_sigma = 0.01;
  double tddd_min_ratio = 0.0;
  bool tddd_nonoverlap = true;
  double tddd_ref_corr = 0.5;
  nh.param<double>("tddd_model_sigma", tddd_model_sigma, 0.01);
  nh.param<double>("tddd_min_ratio", tddd_min_ratio, 0.0);
  nh.param<bool>("tddd_nonoverlap", tddd_nonoverlap, true);
  nh.param<double>("tddd_ref_corr", tddd_ref_corr, 0.5);
  nh.param<bool>("vel_en", vel_en, true);
  nh.param<double>("vel_sigma_floor", vel_sigma_floor, 0.10);
  nh.param<double>("vel_sigma_ceil", vel_sigma_ceil, 2.0);
  nh.param<double>("vel_max_dt", vel_max_dt, 1.0);
  nh.param<double>("vel_rw_sigma", vel_rw_sigma, 0.5);
  nh.param<double>("sig_motion", sig_motion, 0.05);
  nh.param<double>("motion_accel_psd", motion_accel_psd, 0.01);
  nh.param<bool>("cov_en", cov_en, true);
  nh.param<bool>("fixed_lag_en", fixed_lag_en, true);
  nh.param<double>("boundary_sigma_pos", boundary_sigma_pos, 0.05);
  nh.param<double>("boundary_sigma_rot", boundary_sigma_rot, 0.005);
  nh.param<double>("boundary_sigma_vel", boundary_sigma_vel, 0.05);

  // S1: experimental overrides must be finite and in range. Refuse to start
  // rather than silently corrupting the anchor/transition factor model.
  if (!std::isfinite(static_anchor_weak) || static_anchor_weak <= 0.0 ||
      !std::isfinite(static_anchor_consistency) ||
      static_anchor_consistency <= 0.0 || trans_kf < 0)
  {
    ROS_FATAL("[ONLINE GRAPH] invalid anchor/transition experiment parameters: "
              "static_anchor_weak=%g static_anchor_consistency=%g trans_kf=%d "
              "(weak/consistency must be finite and > 0, trans_kf >= 0)",
              static_anchor_weak, static_anchor_consistency, trans_kf);
    return 1;
  }

  g_frame_id = frame_id;
  g_child_frame_id = child_frame_id;
  g_window = window;
  g_path_len = path_len;
  g_max_result_age = max_result_age;
  g_cov_xy = cov_xy;
  g_cov_z = cov_z;
  g_cov_yaw = cov_yaw;

  fast_livo::GlobalPoseGraph::Config cfg;
  cfg.window = window;
  cfg.solve_rate = solve_rate;
  nh.param<bool>("prioritize_new_keyframes", cfg.prioritize_new_keyframes, false);
  cfg.output_path = tum_output ? output : std::string();
  if (lever.size() >= 3)
    cfg.lever = Eigen::Vector3d(lever[0], lever[1], lever[2]);
  if (base_ecef.size() >= 3)
    cfg.base_ecef = Eigen::Vector3d(base_ecef[0], base_ecef[1], base_ecef[2]);
  cfg.tddd_en = tddd_en;
  cfg.tddd_sigma_scale = tddd_sigma_scale;
  cfg.tddd_min_pairs = tddd_min_pairs;
  cfg.tddd_max_dt = tddd_max_dt;
  cfg.tddd_model_sigma = tddd_model_sigma;
  cfg.tddd_min_ratio = tddd_min_ratio;
  cfg.tddd_nonoverlap = tddd_nonoverlap;
  cfg.tddd_ref_corr = tddd_ref_corr;
  cfg.vel_en = vel_en;
  cfg.vel_sigma_floor = vel_sigma_floor;
  cfg.vel_sigma_ceil = vel_sigma_ceil;
  cfg.vel_max_dt = vel_max_dt;
  cfg.vel_rw_sigma = vel_rw_sigma;
  cfg.sig_motion = sig_motion;
  cfg.motion_accel_psd = motion_accel_psd;
  cfg.cov_en = cov_en;
  cfg.fixed_lag_en = fixed_lag_en;
  cfg.boundary_sigma_pos = boundary_sigma_pos;
  cfg.boundary_sigma_rot = boundary_sigma_rot;
  cfg.boundary_sigma_vel = boundary_sigma_vel;
  cfg.quality_gate_en = quality_gate_en;
  cfg.quality_min_status = quality_min_status;
  cfg.quality_min_nsat = quality_min_nsat;
  cfg.quality_max_pdop = quality_max_pdop;
  cfg.quality_max_sigma0 = quality_max_sigma0;
  cfg.quality_max_rms = quality_max_rms;
  cfg.cauchy_xy_en = cauchy_xy_en;
  cfg.lambda_weight_en = lambda_weight_en;
  cfg.scale_fit_en = scale_fit_en;
  cfg.sig_rigid = sig_rigid;
  cfg.sig_anchor = sig_anchor;
  cfg.static_anchor_weak = static_anchor_weak;
  cfg.static_anchor_consistency = static_anchor_consistency;
  cfg.trans_kf = trans_kf;
  cfg.odom_sigma_fixed = odom_sigma_fixed;
  cfg.static_anchor_unified_en =
      static_anchor_unified_en && static_anchor_validity_en;
  cfg.solve_watermark_path = solve_watermark_path;
  cfg.usage_trace_path = usage_trace_path;
  cfg.tddd_time_shift_auto = tddd_time_shift_auto;
  cfg.tddd_time_shift = tddd_time_shift;
  cfg.rtk_interp_en = rtk_interp_en;
  cfg.rtk_static_rule_bracket = rtk_static_rule_bracket;
  cfg.rtk_class_gate_en = rtk_class_gate_en;
  cfg.rtk_class_gate.reject_invalid = gate_reject_invalid;
  cfg.rtk_class_gate.reject_unknown = gate_reject_unknown;
  cfg.rtk_class_gate.reject_degraded = gate_reject_degraded;
  cfg.rtk_class_gate.reject_float = gate_reject_float;
  cfg.rtk_innovation_gate_en = rtk_innovation_gate_en;
  cfg.rtk_innovation.chi2 = rtk_innovation_chi2;
  cfg.rtk_innovation.sigma0 = rtk_innovation_sigma0;
  cfg.rtk_innovation.drift = rtk_innovation_drift;
  cfg.rtk_innovation.sigma_ceil = rtk_innovation_sigma_ceil;
  cfg.fit_robust_en = fit_robust_en;
  cfg.fit_huber_k = fit_huber_k;
  cfg.fit_two_pass_en = fit_two_pass_en;
  cfg.fit_min_samples = fit_min_samples;
  cfg.fit_min_accepted_ratio = fit_min_accepted_ratio;
  cfg.fit_max_scale_delta = fit_max_scale_delta;
  cfg.fit_max_yaw_delta_deg = fit_max_yaw_delta_deg;
  cfg.fit_max_gap_ratio = fit_max_gap_ratio;
  cfg.fit_min_rms_gain = fit_min_rms_gain;
  nh.param<double>("fit_max_bracket_sec", cfg.fit_max_bracket_sec, 0.0);
  nh.param<bool>("fit_reject_bad_endpoints", cfg.fit_reject_bad_endpoints, false);
  nh.param<bool>("fit_use_frontend_yaw", cfg.fit_use_frontend_yaw, true);
  nh.param<double>("fallback_position_sigma", cfg.fallback_position_sigma, 0.01);
  if (!std::isfinite(cfg.fit_max_bracket_sec) || cfg.fit_max_bracket_sec < 0.0 ||
      !std::isfinite(cfg.fallback_position_sigma) || cfg.fallback_position_sigma <= 0.0)
  {
    ROS_FATAL("Invalid fit bracket or fallback position sigma");
    return 1;
  }
  cfg.static_anchor_validity_en = static_anchor_validity_en;
  cfg.static_anchor_validity.trim_start_sec = static_anchor_trim_start_sec;
  cfg.static_anchor_validity.trim_end_sec = static_anchor_trim_end_sec;
  cfg.static_anchor_validity.reference_onset_sec =
      static_anchor_reference_onset_sec;
  cfg.static_anchor_validity.fallback_end_trim_sec =
      static_anchor_fallback_end_trim_sec;
  cfg.static_anchor_validity.min_samples = static_anchor_min_samples;
  cfg.static_anchor_validity.min_fixed_ratio = static_anchor_min_fixed_ratio;
  cfg.static_anchor_validity.max_rtk_net_displacement =
      static_anchor_max_rtk_net_displacement;
  cfg.static_anchor_validity.max_rtk_p95 = static_anchor_max_rtk_p95;
  cfg.static_anchor_validity.max_rtk_deviation =
      static_anchor_max_rtk_deviation;
  cfg.static_anchor_validity.max_slow_drift = static_anchor_max_slow_drift;
  cfg.static_anchor_diagnostics_path = static_anchor_diagnostics_path;
  nh.param<std::string>("anchor_trace_path", cfg.anchor_trace_path, "");
  cfg.rtk_interp.max_bracket_dt = rtk_interp_max_bracket_dt;
  cfg.rtk_interp.max_extrapolation = rtk_interp_max_extrapolation;
  cfg.rtk_interp.min_alpha = rtk_interp_min_alpha;
  cfg.rtk_interp.max_alpha = rtk_interp_max_alpha;
  cfg.rtk_interp_model_sigma = rtk_interp_model_sigma;
  cfg.rtk_interp_robust_en = rtk_interp_robust_en;
  cfg.assoc_trace_path = assoc_trace_path;
  std::string timing_trace_path;
  nh.param<std::string>("online_timing_trace_path", timing_trace_path, "");
  if (!timing_trace_path.empty())
  {
    g_timing_trace.open(timing_trace_path, std::ios::out | std::ios::trunc);
    if (!g_timing_trace)
    {
      ROS_ERROR("Cannot open online timing trace: %s", timing_trace_path.c_str());
      return 1;
    }
    g_timing_trace << "event,stamp_ns,monotonic_ns,ros_time_ns,result_seq\n";
  }
  g_graph.reset(new fast_livo::GlobalPoseGraph(cfg));

  ros::NodeHandle nh_pub("/online_graph");
  if (publish_odom)
    g_pub_odom = nh_pub.advertise<nav_msgs::Odometry>("global_odom", 10, true);
  if (publish_path)
    g_pub_path = nh_pub.advertise<nav_msgs::Path>("global_path", 10, true);
  if (publish_correction)
    g_pub_corr =
        nh_pub.advertise<geometry_msgs::Vector3Stamped>("graph_correction", 10, true);
  g_pub_status =
      nh_pub.advertise<diagnostic_msgs::DiagnosticArray>("status", 10);

  ros::Subscriber sub_kf =
      nh.subscribe("/online_graph/keyframe", 500, keyframeCallback);
  ros::Subscriber sub_fix =
      nh.subscribe("/online_graph/gnss_enu", 500, fixCallback);
  // Must keep the Subscriber alive: a temporary returned by subscribe() is
  // destroyed at the end of the statement and silently unsubscribes.
  ros::Subscriber sub_vel =
      nh.subscribe("/online_graph/vel", 500, velCallback);
  ros::Subscriber sub_dd =
      nh.subscribe("/rtk/dd", 500, ddCallback);

  ros::Timer result_timer = nh.createTimer(
      ros::Duration(1.0 / std::max(0.5, result_rate)), pollResultCallback);
  ros::Timer status_timer = nh.createTimer(
      ros::Duration(1.0 / std::max(0.1, status_rate)), statusCallback);

  ROS_INFO("[ONLINE GRAPH] node started: window=%d output=%s odom=%d path=%d "
           "corr=%d result_rate=%.1f solve_rate=%.1f status_rate=%.1f frame=%s "
           "tddd=%d quality=%d cauchy=%d lambda=%d scale=%d rtk_interp=%d "
           "static_rule_bracket=%d class_gate=%d innov=%d fit_robust=%d "
           "fit_2pass=%d a3_validity=%d bracket=%.2f model_sigma=%.2f "
           "sig_anchor=%.3f anchor_weak=%.3f anchor_consistency=%.3f "
           "trans_kf=%d odom_fixed=%.3f a3_unified=%d watermark=%d usage=%d",
           window, cfg.output_path.c_str(), (int)publish_odom,
           (int)publish_path, (int)publish_correction, result_rate,
           solve_rate, status_rate, frame_id.c_str(), (int)tddd_en,
           (int)quality_gate_en, (int)cauchy_xy_en, (int)lambda_weight_en,
           (int)scale_fit_en, (int)rtk_interp_en,
           (int)rtk_static_rule_bracket, (int)rtk_class_gate_en,
           (int)rtk_innovation_gate_en, (int)fit_robust_en,
           (int)fit_two_pass_en, (int)static_anchor_validity_en,
           rtk_interp_max_bracket_dt, rtk_interp_model_sigma,
           cfg.sig_anchor, cfg.static_anchor_weak,
           cfg.static_anchor_consistency, cfg.trans_kf,
           cfg.odom_sigma_fixed,
           (int)cfg.static_anchor_unified_en,
           !cfg.solve_watermark_path.empty(), !cfg.usage_trace_path.empty());
  ROS_INFO("[ONLINE GRAPH] fit_max_bracket_sec=%.17g fit_use_frontend_yaw=%d fallback_position_sigma=%.17g fit_reject_bad_endpoints=%d",
           cfg.fit_max_bracket_sec, (int)cfg.fit_use_frontend_yaw,
           cfg.fallback_position_sigma, (int)cfg.fit_reject_bad_endpoints);
  ROS_INFO("[ONLINE GRAPH] prioritize_new_keyframes=%d", (int)cfg.prioritize_new_keyframes);
  ros::spin();

  g_graph->stop();
  const auto st = g_graph->getStats();
  ROS_INFO("[ONLINE GRAPH] stopped: keyframes=%d solves=%d last=%.2f ms "
           "rtk=%d/%d tddd=%d scale=%.5f seq=%llu",
           st.keyframes, st.solves, st.last_solve_ms, st.rtk_used, st.fixes,
           st.tddd_used, st.scale, (unsigned long long)st.result_seq);
  return 0;
}
