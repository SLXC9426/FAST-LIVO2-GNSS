#include "global_pose_graph.h"

#include "graph_covariance.h"
#include "graph_fit_mask.h"

#include "pose_graph_factors.h"

#include <gtsam/geometry/Point3.h>
#include <gtsam/geometry/Pose3.h>
#include <gtsam/linear/LossFunctions.h>
#include <gtsam/linear/NoiseModel.h>
#include <gtsam/nonlinear/LevenbergMarquardtOptimizer.h>
#include <gtsam/nonlinear/Marginals.h>
#include <gtsam/nonlinear/NonlinearFactorGraph.h>
#include <gtsam/nonlinear/Values.h>
#include <gtsam/slam/BetweenFactor.h>
#include <gtsam/slam/PriorFactor.h>
#include <boost/make_shared.hpp>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstdio>
#include <exception>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <limits>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <tuple>

namespace fast_livo
{
namespace
{

constexpr double kPi = 3.14159265358979323846;

double median(std::vector<double> v)
{
  if (v.empty()) return 0.0;
  std::sort(v.begin(), v.end());
  const size_t n = v.size();
  return (n % 2) ? v[n / 2] : 0.5 * (v[n / 2 - 1] + v[n / 2]);
}

Eigen::Vector3d medianVec(
    const std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> &v)
{
  if (v.empty()) return Eigen::Vector3d::Zero();
  Eigen::Vector3d out;
  for (int k = 0; k < 3; ++k)
  {
    std::vector<double> a;
    a.reserve(v.size());
    for (const auto &x : v) a.push_back(x(k));
    out(k) = median(a);
  }
  return out;
}

Eigen::Vector3d interpFix(
    const std::vector<GlobalPoseGraph::Fix, Eigen::aligned_allocator<GlobalPoseGraph::Fix>> &fixes,
    double t)
{
  if (fixes.empty()) return Eigen::Vector3d::Zero();
  auto it = std::lower_bound(fixes.begin(), fixes.end(), t,
                             [](const GlobalPoseGraph::Fix &a, double v) { return a.t < v; });
  if (it == fixes.begin()) return it->p;
  if (it == fixes.end()) return fixes.back().p;
  const auto &b = *it;
  const auto &a = *(it - 1);
  const double dt = b.t - a.t;
  if (dt <= 0) return b.p;
  const double w = (t - a.t) / dt;
  return (1.0 - w) * a.p + w * b.p;
}

double sigmoid(double x)
{
  if (x > 40.0) return 1.0;
  if (x < -40.0) return 0.0;
  return 1.0 / (1.0 + std::exp(-x));
}

Eigen::Vector3d unit(const Eigen::Vector3d &v)
{
  const double n = v.norm();
  return n > 1e-9 ? v / n : v;
}

// A1 ablation: why an RTK epoch did or did not produce an absolute factor.
// Kept separate from FixAssocStatus (the time-association verdict) so a static
// rule can be told apart from a bracketing/rejection problem.
enum class AssocReason
{
  FACTOR = 0,
  ASSOC_INVALID,
  QUALITY,
  STATIC,
  NO_ASSIGNMENT,
  JUMP_REJECTED,     // addFix's 30 m prediction gate dropped it before the solve
  CLASS_GATED,       // A2.3 quality-class gate rejected the factor
  INNOVATION_GATED,  // A2.4 chi-square innovation test rejected the epoch
  INNOVATION_INVALID // A2.4 covariance was not finite/SPD
};

const char *assocReasonName(AssocReason r)
{
  switch (r)
  {
    case AssocReason::FACTOR: return "factor";
    case AssocReason::ASSOC_INVALID: return "assoc_invalid";
    case AssocReason::QUALITY: return "quality";
    case AssocReason::STATIC: return "static";
    case AssocReason::NO_ASSIGNMENT: return "no_assignment";
    case AssocReason::JUMP_REJECTED: return "jump_rejected";
    case AssocReason::CLASS_GATED: return "class_gated";
    case AssocReason::INNOVATION_GATED: return "innovation_gated";
    case AssocReason::INNOVATION_INVALID: return "innovation_invalid";
  }
  return "unknown";
}

Eigen::Matrix3d enuRotation(double lat, double lon)
{
  const double sl = std::sin(lat), cl = std::cos(lat);
  const double so = std::sin(lon), co = std::cos(lon);
  Eigen::Matrix3d R;
  R << -so, co, 0.0,
      -sl * co, -sl * so, cl,
      cl * co, cl * so, sl;
  return R;
}

Eigen::Vector3d geodeticToEcef(double lat, double lon, double alt)
{
  const double a = 6378137.0;
  const double e2 = 6.6943799901413165e-3;
  const double sla = std::sin(lat), cla = std::cos(lat);
  const double slo = std::sin(lon), clo = std::cos(lon);
  const double N = a / std::sqrt(1.0 - e2 * sla * sla);
  return Eigen::Vector3d((N + alt) * cla * clo, (N + alt) * cla * slo,
                         (N * (1.0 - e2) + alt) * sla);
}

// A3.1 diagnostics: one row per candidate static run, written only when the
// gate is enabled and a path is configured. Times are relative to the first
// keyframe of the retained solve window.
void writeStaticAnchorDiagnostics(
    const std::string &path,
    const std::vector<StaticAnchorValidityResult> &rows)
{
  if (path.empty()) return;
  std::ofstream f(path.c_str(), std::ios::out | std::ios::trunc);
  if (!f) return;
  f << "segment_id,raw_start,raw_end,trimmed_start,trimmed_end,trim_basis,"
       "trimmed_kf_start,trimmed_kf_end,trimmed_fix_start,trimmed_fix_end,"
       "raw_sample_count,trimmed_sample_count,fixed_count,good_count,"
       "float_count,other_count,fixed_ratio,rtk_net_displacement,"
       "rtk_robust_p95,rtk_max_deviation,rtk_robust_sigma,rtk_slow_drift,"
       "lio_net_displacement,anchor_validity,reject_reason,reason\n";
  f << std::fixed << std::setprecision(6);
  for (size_t i = 0; i < rows.size(); ++i)
  {
    const StaticAnchorValidityResult &r = rows[i];
    f << r.segment_id << ',' << r.raw_start << ',' << r.raw_end << ','
      << r.trimmed_start << ',' << r.trimmed_end << ',' << r.trim_basis << ','
      << r.trimmed_kf_start << ',' << r.trimmed_kf_end << ','
      << r.trimmed_fix_start << ',' << r.trimmed_fix_end << ','
      << r.raw_sample_count << ',' << r.trimmed_sample_count << ','
      << r.fixed_count << ',' << r.good_count << ',' << r.float_count << ','
      << r.other_count << ',' << r.fixed_ratio << ','
      << r.rtk_net_displacement << ',' << r.rtk_robust_p95 << ','
      << r.rtk_max_deviation << ',' << r.rtk_robust_sigma << ','
      << r.rtk_slow_drift << ',' << r.lio_net_displacement << ','
      << staticAnchorValidityStateName(r.state) << ','
      << staticAnchorRejectReasonName(r.reject_reason) << ',' << r.reason
      << '\n';
  }
}


}  // namespace

GlobalPoseGraph::GlobalPoseGraph(const Config &cfg) : cfg_(cfg)
{
  if (!cfg_.solve_watermark_path.empty())
  {
    wm_stream_.open(cfg_.solve_watermark_path, std::ios::out | std::ios::trunc);
    wm_stream_ << std::setprecision(17);
  }
  if (!cfg_.static_anchor_diagnostics_path.empty())
  {
    // A3.2: start the append-only estimation trace fresh for this process
    // (one row per solve x segment follows).
    std::ofstream t(cfg_.static_anchor_diagnostics_path +
                        ".estimation.csv",
                    std::ios::out | std::ios::trunc);
    t << "solve_seq,solve_stamp,segment_id,state,n_candidates,"
         "n_estimation,estimation_fix_stamps\n";
  }
  thread_ = std::thread(&GlobalPoseGraph::run, this);
}

GlobalPoseGraph::~GlobalPoseGraph()
{
  stop();
}

void GlobalPoseGraph::stop()
{
  {
    std::lock_guard<std::mutex> lk(mtx_);
    stop_ = true;
  }
  cv_.notify_all();
  if (thread_.joinable()) thread_.join();
  writeFinalWatermark();
}

void GlobalPoseGraph::writeFinalWatermark()
{
  if (cfg_.solve_watermark_path.empty()) return;
  // Called from stop() after the worker joined; the ROS node stops its
  // callbacks before calling stop(), so these counters are final here. The
  // stamp doubles are read under mtx_ for symmetry with their writers.
  double first_kf = 0.0, last_kf = 0.0, first_fx = 0.0, last_fx = 0.0;
  {
    std::lock_guard<std::mutex> lk(mtx_);
    first_kf = first_kf_t_;
    last_kf = last_kf_t_;
    first_fx = first_fix_t_;
    last_fx = last_fix_t_;
  }
  std::ofstream f(cfg_.solve_watermark_path + ".final.json",
                  std::ios::out | std::ios::trunc);
  f << std::setprecision(17)
    << "{\"received_keyframes\":" << received_keyframes_.load()
    << ",\"received_fixes\":" << received_fixes_.load()
    << ",\"first_kf_stamp\":" << first_kf
    << ",\"last_kf_stamp\":" << last_kf
    << ",\"first_fix_stamp\":" << first_fx
    << ",\"last_fix_stamp\":" << last_fx
    << ",\"solves\":" << solve_seq_.load() << "}\n";
}

void GlobalPoseGraph::addKeyframe(const Keyframe &kf)
{
  std::lock_guard<std::mutex> lk(mtx_);
  keyframes_.push_back(kf);
  total_keyframes_.fetch_add(1);
  // R0 watermark: every published keyframe is counted, including ones the
  // window cap later drops.
  if (received_keyframes_.fetch_add(1) == 0) first_kf_t_ = kf.t;
  last_kf_t_ = kf.t;
  const size_t cap = static_cast<size_t>(std::max(cfg_.window, 10));
  while (keyframes_.size() > cap) keyframes_.pop_front();
  dirty_ = true;
  cv_.notify_one();
}

void GlobalPoseGraph::addFix(const Fix &fx)
{
  std::lock_guard<std::mutex> lk(mtx_);
  // R0 watermark: count every received fix before any gate, so the final
  // summary reflects what was published to this process, not what survived.
  if (received_fixes_.fetch_add(1) == 0) first_fix_t_ = fx.t;
  last_fix_t_ = fx.t;
  if (have_last_fix_)
  {
    const double dt = fx.t - last_fix_.t;
    if (dt > 0.0 && dt <= cfg_.max_fix_dt)
    {
      Eigen::Vector3d pred = last_fix_.p;
      if (have_prev_fix_)
      {
        const double dtl = last_fix_.t - prev_fix_.t;
        if (dtl > 0.0)
          pred += (last_fix_.p - prev_fix_.p) / dtl * dt;
      }
      const double err = (fx.p - pred).head<2>().norm();
      if (err > cfg_.max_fix_error)
      {
        rejected_fixes_.fetch_add(1);
        // Keep the epoch so the trace can report why it never reached the
        // solver; it is not a measurement and has no factor.
        rejected_log_.push_back(fx);
        const double t_min = keyframes_.empty() ? fx.t - 10.0
                                                : keyframes_.front().t - 10.0;
        while (!rejected_log_.empty() && rejected_log_.front().t < t_min)
          rejected_log_.pop_front();
        while (rejected_log_.size() > 20000) rejected_log_.pop_front();
        return;
      }
    }
  }
  prev_fix_ = last_fix_;
  have_prev_fix_ = have_last_fix_;
  last_fix_ = fx;
  have_last_fix_ = true;
  fixes_.push_back(fx);
  // Keep fixes covering the retained keyframe history. A count cap would
  // truncate 10 Hz GNSS to a few hundred seconds while the keyframe window
  // spans 1500 s, leaving most nodes without absolute factors.
  const double t_min = keyframes_.empty() ? fx.t - 10.0
                                          : keyframes_.front().t - 10.0;
  while (!fixes_.empty() && fixes_.front().t < t_min) fixes_.pop_front();
  while (!rejected_log_.empty() && rejected_log_.front().t < t_min)
    rejected_log_.pop_front();
  const size_t hard_cap = 200000;
  while (fixes_.size() > hard_cap) fixes_.pop_front();
  while (rejected_log_.size() > 20000) rejected_log_.pop_front();
  dirty_ = true;
  cv_.notify_one();
}

void GlobalPoseGraph::addDdEpoch(const DdEpoch &dd)
{
  std::lock_guard<std::mutex> lk(mtx_);
  dd_epochs_.push_back(dd);
  const double t_min = keyframes_.empty() ? dd.t - 10.0
                                          : keyframes_.front().t - 10.0;
  while (!dd_epochs_.empty() && dd_epochs_.front().t < t_min)
    dd_epochs_.pop_front();
  const size_t hard_cap = 200000;
  while (dd_epochs_.size() > hard_cap) dd_epochs_.pop_front();
  dirty_ = true;
  cv_.notify_one();
}

void GlobalPoseGraph::addVel(const Vel &vel)
{
  std::lock_guard<std::mutex> lk(mtx_);
  vels_.push_back(vel);
  const double t_min = keyframes_.empty() ? vel.t - 10.0
                                          : keyframes_.front().t - 10.0;
  while (!vels_.empty() && vels_.front().t < t_min) vels_.pop_front();
  const size_t hard_cap = 200000;
  while (vels_.size() > hard_cap) vels_.pop_front();
  dirty_ = true;
  cv_.notify_one();
}

void GlobalPoseGraph::setEnuOrigin(double lat, double lon, double alt)
{
  std::lock_guard<std::mutex> lk(mtx_);
  if (have_origin_) return;
  origin_lat_ = lat;
  origin_lon_ = lon;
  origin_alt_ = alt;
  origin_ecef_ = geodeticToEcef(lat, lon, alt);
  have_origin_ = true;
}

GlobalPoseGraph::Stats GlobalPoseGraph::getStats() const
{
  Stats s;
  {
    std::lock_guard<std::mutex> lk(stats_mtx_);
    s = stats_;
  }
  // Report received keyframes even before the first successful solve, so a
  // no-RTK / not-enough-fixes state is distinguishable from "no data".
  s.total_keyframes = total_keyframes_.load();
  s.rejected_fixes = rejected_fixes_.load();
  if (s.total_keyframes > cfg_.window) s.window_slid = true;
  return s;
}

void GlobalPoseGraph::setStatus(int status)
{
  std::lock_guard<std::mutex> lk(stats_mtx_);
  stats_.status = status;
}

void GlobalPoseGraph::writeAssocTrace(double t_min) const
{
  if (cfg_.assoc_trace_path.empty()) return;
  const std::string tmp = cfg_.assoc_trace_path + ".tmp";
  std::ofstream f(tmp, std::ios::out | std::ios::trunc);
  if (!f.is_open()) return;
  f << "t_fix,key_i,key_j,alpha,dt,bracket_dt,status,quality,static_id,"
       "decision,factor,nsat,pdop,h_acc_mm,v_acc_mm,carr_soln,fix_type,"
       "q_valid,has_p_dop,has_h_acc,has_v_acc,q_source,q_class,q_reason,"
       "innov_gamma,anchor_update\n";
  for (const auto &kv : assoc_trace_)
  {
    if (kv.first < t_min) continue;
    const AssocTraceRow &r = kv.second;
    // 9 significant digits is only 10 s at a 1.6e9 Unix timestamp and made
    // neighbouring epochs look identical in the CSV. Print the absolute time
    // with fixed decimals and the small quantities with significant digits.
    f << std::fixed << std::setprecision(6) << kv.first << ","
      << r.key_i << "," << r.key_j << ","
      << std::defaultfloat << std::setprecision(9)
      << r.alpha << "," << r.dt << "," << r.bracket_dt << ","
      << fixAssocStatusName(static_cast<FixAssocStatus>(r.status)) << ","
      << r.quality << "," << r.static_id << ","
      << assocReasonName(static_cast<AssocReason>(r.reason)) << ","
      << r.factor << "," << r.nsat << "," << r.pdop << ","
      << r.h_acc_mm << "," << r.v_acc_mm << "," << r.carr_soln << ","
      << r.fix_type << "," << r.q_valid << "," << r.has_p_dop << ","
      << r.has_h_acc << "," << r.has_v_acc << "," << r.q_source << ","
      << gnssQualityClassName(static_cast<GnssQualityClass>(r.q_class)) << ","
      << r.q_reason << "," << r.innov_gamma << "," << r.anchor_update << "\n";
  }
  f.close();
  if (std::rename(tmp.c_str(), cfg_.assoc_trace_path.c_str()) != 0)
    std::remove(tmp.c_str());
}

bool GlobalPoseGraph::getLatestResult(Result &out, uint64_t &last_seq) const
{
  std::lock_guard<std::mutex> lk(result_mtx_);
  if (!latest_.valid || latest_.seq == last_seq) return false;
  out = latest_;
  last_seq = latest_.seq;
  return true;
}

void GlobalPoseGraph::run()
{
  int previous_snapshot_keyframes = 0;
  while (true)
  {
    GlobalPoseGraph::KeyframeVector kfs;
    GlobalPoseGraph::FixVector fixes;
    WatermarkSnapshot wm;
    {
      std::unique_lock<std::mutex> lk(mtx_);
      cv_.wait(lk, [&] { return stop_ || dirty_; });
      if (stop_) break;
      dirty_ = false;
      const size_t n = keyframes_.size();
      const size_t start = n > static_cast<size_t>(cfg_.window) ? n - cfg_.window : 0;
      kfs.assign(keyframes_.begin() + start, keyframes_.end());
      fixes.assign(fixes_.begin(), fixes_.end());
      // R0 watermark: captured in the SAME critical section as the solve
      // snapshot, so every field describes one consistent receive instant.
      // Plain doubles are safe here: the writers (add* callbacks) hold mtx_.
      wm.kf_buffer = static_cast<int>(keyframes_.size());
      wm.fix_buffer = static_cast<int>(fixes_.size());
      wm.received_kf = received_keyframes_.load();
      wm.received_fix = received_fixes_.load();
      wm.first_kf_t = first_kf_t_;
      wm.last_kf_t = last_kf_t_;
      wm.first_fix_t = first_fix_t_;
      wm.last_fix_t = last_fix_t_;
      if (wm_stream_.is_open())
        wm.snapshot_monotonic_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(
            std::chrono::steady_clock::now().time_since_epoch()).count();
    }
    if (kfs.size() < 20)
    {
      setStatus(2);
      continue;
    }
    const bool same_keyframe = wm.received_kf == previous_snapshot_keyframes;
    previous_snapshot_keyframes = wm.received_kf;
    try
    {
      solve(kfs, fixes, wm);
    }
    catch (const std::exception &e)
    {
      std::cerr << "[ONLINE GRAPH] solve failed: " << e.what() << std::endl;
      setStatus(3);
    }
    catch (...)
    {
      std::cerr << "[ONLINE GRAPH] solve failed: unknown exception" << std::endl;
      setStatus(3);
    }

    if (cfg_.solve_rate > 0.0)
    {
      const double period = 1.0 / std::max(0.2, cfg_.solve_rate);
      std::unique_lock<std::mutex> lk(mtx_);
      // A fix-only refresh has already waited through the previous keyframe
      // solve's cooldown. Let a new keyframe preempt this second cooldown.
      cv_.wait_for(lk, std::chrono::duration<double>(period),
                   [&] {
                     return stop_ ||
                            (cfg_.prioritize_new_keyframes && same_keyframe &&
                             received_keyframes_.load() != wm.received_kf);
                   });
      if (stop_) break;
    }
  }
}

void GlobalPoseGraph::solve(const KeyframeVector &kfs, const FixVector &fixes,
                            const WatermarkSnapshot &wm_snap)
{
  const int n = static_cast<int>(kfs.size());
  const double t0kf = kfs.front().t;
  const double t1kf = kfs.back().t;
  FixVector fx;
  for (const auto &f : fixes)
    if (f.t >= t0kf - 5.0 && f.t <= t1kf + 5.0) fx.push_back(f);
  if (fx.size() < 2)
  {
    setStatus(2);
    return;
  }

  // R0: receive/solve watermark for this solve, captured with the snapshot
  // under the buffer lock in run(). received_* = what the process has
  // accepted; *_buffer = what the deques hold; n/fix window below = what
  // THIS solve actually consumes.
  const int wm_kf_buffer = wm_snap.kf_buffer;
  const int wm_fix_buffer = wm_snap.fix_buffer;
  const int wm_received_kf = wm_snap.received_kf;
  const int wm_received_fix = wm_snap.received_fix;
  const double wm_last_kf = wm_snap.last_kf_t;
  const double wm_last_fix = wm_snap.last_fix_t;
  const bool usage_en = !cfg_.usage_trace_path.empty();
  const bool bracket_en =
      usage_en || !cfg_.solve_watermark_path.empty();
  std::ostringstream usage;
  if (usage_en)
    usage << "kind,solve_stamp,i,j,kf_stamp,fix_a_index,fix_a_stamp,"
             "fix_b_index,fix_b_stamp,sigma_xy,sigma_z,dx,dy,dz\n";

  // Snapshot DD epochs inside the window. They are copied in run() so the
  // solve does not hold the buffer lock.
  std::vector<DdEpoch> dds;
  {
    std::lock_guard<std::mutex> lk(mtx_);
    for (const auto &d : dd_epochs_)
      if (d.t >= t0kf - 2.0 && d.t <= t1kf + 2.0) dds.push_back(d);
  }
  std::sort(dds.begin(), dds.end(),
            [](const DdEpoch &a, const DdEpoch &b) { return a.t < b.t; });

  // R4.3: Doppler velocity epochs inside the window.
  std::vector<Vel> vels;
  {
    std::lock_guard<std::mutex> lk(mtx_);
    for (const auto &v : vels_)
      if (v.t >= t0kf - 1.0 && v.t <= t1kf + 1.0) vels.push_back(v);
  }
  std::sort(vels.begin(), vels.end(),
            [](const Vel &a, const Vel &b) { return a.t < b.t; });
  const bool use_vel = cfg_.vel_en && !vels.empty() && n >= 2;

  // Fixes addFix rejected before they reached this window. They are not
  // measurements, but the per-epoch trace must account for them.
  std::vector<Fix, Eigen::aligned_allocator<Fix>> pre_rejected;
  {
    std::lock_guard<std::mutex> lk(mtx_);
    for (const auto &f : rejected_log_)
      if (f.t >= t0kf - 5.0 && f.t <= t1kf + 5.0) pre_rejected.push_back(f);
  }

  // A2.5: shared time base and fix-level predicates. The initial-fit screening
  // needs the same quality/class decisions as the factor loop, so they live
  // above the fit instead of inside the interpolation branch.
  std::vector<double> kf_t(n);
  for (int i = 0; i < n; ++i) kf_t[i] = kfs[i].t;
  const auto lio_at = [&](double t) {
    if (t <= kf_t.front()) return kfs.front().p;
    if (t >= kf_t.back()) return kfs.back().p;
    const int b = findKeyframeBracket(kf_t, t);
    if (b < 0) return kfs.front().p;
    const double span = kf_t[b + 1] - kf_t[b];
    const double w = span > 0.0 ? (t - kf_t[b]) / span : 0.0;
    return Eigen::Vector3d((1.0 - w) * kfs[b].p + w * kfs[b + 1].p);
  };
  const auto fix_quality_ok = [&](const Fix &f) {
    if (!cfg_.quality_gate_en) return true;
    if (f.status >= 0 && f.status < cfg_.quality_min_status) return false;
    if (cfg_.quality_min_nsat > 0 && f.nsat > 0 &&
        f.nsat < cfg_.quality_min_nsat) return false;
    if (cfg_.quality_max_pdop > 0.0 && f.pdop > 0.0 &&
        f.pdop > cfg_.quality_max_pdop) return false;
    if (cfg_.quality_max_sigma0 > 0.0 && f.sigma0 > 0.0 &&
        f.sigma0 > cfg_.quality_max_sigma0) return false;
    if (cfg_.quality_max_rms > 0.0 && f.rms_xyz > 0.0 &&
        f.rms_xyz > cfg_.quality_max_rms) return false;
    return true;
  };
  const auto quality_of = [](const Fix &f) {
    GnssQualityInput in;
    in.has_record = f.quality_valid || f.has_p_dop || f.nsat > 0 ||
                    f.carr_soln != 0 || f.fix_type != 0 ||
                    !f.quality_source.empty() || f.h_acc_mm > 0 ||
                    f.v_acc_mm > 0;
    in.source = f.quality_source;
    in.valid = f.quality_valid;
    in.num_sv = f.nsat;
    in.p_dop = f.pdop;
    in.has_p_dop = f.has_p_dop;
    in.carr_soln = f.carr_soln;
    in.fix_type = f.fix_type;
    return in;
  };
  const auto class_gate = [&](const Fix &f) {
    if (!cfg_.rtk_class_gate_en) return false;
    const GnssQualityVerdict v =
        classifyGnssQuality(quality_of(f), cfg_.gnss_quality);
    return shouldGateGnssQualityClass(v.cls, cfg_.rtk_class_gate);
  };

  // A2.5: the innovation screen must use exactly the epochs the A1 association
  // would accept; otherwise an out-of-range/duplicate epoch could move the
  // anchor even though the factor loop never sees it.
  std::vector<FixAssociation> assoc_epochs;
  std::vector<char> assoc_valid;
  if (cfg_.rtk_interp_en)
  {
    std::vector<double> fix_t(fx.size());
    for (size_t j = 0; j < fx.size(); ++j) fix_t[j] = fx[j].t;
    associateRtkEpochs(kf_t, fix_t, cfg_.rtk_interp, assoc_epochs);
    assoc_valid.assign(fx.size(), 0);
    for (const auto &a : assoc_epochs)
      if (a.valid && a.fix_index >= 0 &&
          a.fix_index < static_cast<int>(assoc_valid.size()))
        assoc_valid[a.fix_index] = 1;
  }

  // ---- A2.5: initial 2D similarity fit (LIO world -> ENU) ------------------
  // The fit seeds the innovation prediction (scale/yaw) and sig_rtk_xy (fit
  // RMS), so it must not be dominated by a single 26-29 m gross error. Pass 1
  // keeps the historical formula; the optional robust/two-pass variants are
  // opt-in and default-off.
  std::vector<Eigen::Vector3d> fit_lio, fit_enu;
  std::vector<double> fit_t;
  // R2: real fit-sample endpoints. The bracket mirrors interpFix exactly:
  // lower_bound, before-first -> single head endpoint, after-end -> single
  // tail endpoint.
  std::vector<std::pair<int, int>> fit_bracket;
  const auto fix_bracket = [&](double t) {
    auto it = std::lower_bound(fx.begin(), fx.end(), t,
                               [](const Fix &a, double v) { return a.t < v; });
    if (it == fx.begin()) return std::make_pair(-1, 0);
    if (it == fx.end())
      return std::make_pair(static_cast<int>(fx.size()) - 1, -1);
    const int lo = static_cast<int>(it - fx.begin()) - 1;
    return std::make_pair(lo, lo + 1);
  };
  int fit_bracket_rejected = 0;
  int fit_quality_rejected = 0;
  const auto bad_endpoint = [&](int index) {
    if (index < 0) return false;
    const auto cls = classifyGnssQuality(quality_of(fx[index]), cfg_.gnss_quality).cls;
    return cls == GnssQualityClass::INVALID || cls == GnssQualityClass::DEGRADED;
  };
  for (int i = 0; i < n; ++i)
  {
    if (kfs[i].t < fx.front().t || kfs[i].t > fx.back().t) continue;
    std::pair<int, int> bracket{-1, -1};
    if (bracket_en || cfg_.fit_max_bracket_sec > 0.0 || cfg_.fit_reject_bad_endpoints)
      bracket = fix_bracket(kfs[i].t);
    if (cfg_.fit_max_bracket_sec > 0.0 && bracket.first >= 0 && bracket.second >= 0 &&
        kfs[i].t != fx[bracket.second].t &&
        fx[bracket.second].t - fx[bracket.first].t > cfg_.fit_max_bracket_sec)
    {
      ++fit_bracket_rejected;
      continue;
    }
    const bool exact_right = bracket.second >= 0 && kfs[i].t == fx[bracket.second].t;
    if (cfg_.fit_reject_bad_endpoints &&
        (bad_endpoint(bracket.second) || (!exact_right && bad_endpoint(bracket.first))))
    {
      ++fit_quality_rejected;
      continue;
    }
    fit_t.push_back(kfs[i].t);
    fit_lio.push_back(kfs[i].p);
    fit_enu.push_back(interpFix(fx, kfs[i].t));
    if (bracket_en) fit_bracket.push_back(bracket);
  }
  const int nfit = static_cast<int>(fit_lio.size());
  if (nfit < 20)
  {
    setStatus(2);
    return;
  }

  SimilarityFitOptions fit_opt;
  fit_opt.scale_fit = cfg_.scale_fit_en;
  fit_opt.scale_min = cfg_.scale_min;
  fit_opt.scale_max = cfg_.scale_max;
  const bool have_frontend_frame = kfs.back().have_frame;
  if (have_frontend_frame && cfg_.fit_use_frontend_yaw)
  {
    const Eigen::Matrix3d Rz_front = kfs.back().R_world_from_enu.transpose();
    fit_opt.have_yaw_override = true;
    fit_opt.yaw_override = std::atan2(Rz_front(1, 0), Rz_front(0, 0));
  }
  SimilarityFitResult fit1 = cfg_.fit_robust_en
      ? fitSimilarity2DRobust(fit_lio, fit_enu, fit_opt, cfg_.fit_huber_k)
      : fitSimilarity2D(fit_lio, fit_enu, {}, fit_opt);
  if (!fit1.valid)
  {
    setStatus(2);
    return;
  }

  struct InnovScreen
  {
    std::vector<char> skip;
    std::vector<char> gamma_valid;
    std::vector<char> anchor_update;
    std::vector<char> accepted;
    std::vector<double> gamma;
    int n_accepted = 0;
    int n_evaluated = 0;
  };
  const auto sig_rtk_from_rms = [](double rms) {
    return std::min(5.0, std::max(0.5, 6.0 - 0.6 * rms));
  };

  // Fixed-mask screening with pass-1 parameters. The factor loop reuses this
  // mask, so the second fit and the factors see identical decisions.
  const auto screen_innovation = [&](const SimilarityFitResult &fit,
                                     double sig_rtk_xy) {
    InnovScreen s;
    s.skip.assign(fx.size(), 0);
    s.gamma.assign(fx.size(), -1.0);
    s.gamma_valid.assign(fx.size(), 0);
    s.anchor_update.assign(fx.size(), 0);
    s.accepted.assign(fx.size(), 0);
    const double cy = std::cos(fit.yaw), sy = std::sin(fit.yaw);
    Eigen::Matrix3d Rz;
    Rz << cy, -sy, 0.0, sy, cy, 0.0, 0.0, 0.0, 1.0;
    bool have_anchor = false;
    double at = 0.0;
    Eigen::Vector3d ap = Eigen::Vector3d::Zero();
    for (size_t j = 0; j < fx.size(); ++j)
    {
      const Fix &f = fx[j];
      if (!fix_quality_ok(f)) continue;
      if (j >= assoc_valid.size() || !assoc_valid[j]) continue;
      const bool class_skip = class_gate(f);
      if (!have_anchor)
      {
        // A class-gated epoch is not trusted enough to seed the anchor.
        if (!class_skip)
        {
          have_anchor = true;
          at = f.t;
          ap = f.p;
          s.anchor_update[j] = 1;
          s.accepted[j] = 1;  // explicitly trusted initial seed, not tested
          ++s.n_accepted;
        }
        continue;
      }
      const Eigen::Vector3d disp_lio = lio_at(f.t) - lio_at(at);
      const Eigen::Vector3d pred = ap + fit.scale * (Rz * disp_lio);
      const double sig_pred =
          gnssPredictionSigma(disp_lio.norm(), cfg_.rtk_innovation);
      double sig_h = sig_rtk_xy;
      double sig_v = cfg_.sig_rtk_z;
      if (f.sigma_h > 0.0)
        sig_h = std::min(cfg_.sigma_h_ceil,
                         std::max(cfg_.sigma_h_floor, f.sigma_h));
      if (f.sigma_v > 0.0)
        sig_v = std::min(cfg_.sigma_v_ceil,
                         std::max(cfg_.sigma_v_floor, f.sigma_v));
      Eigen::Matrix3d S = Eigen::Matrix3d::Zero();
      S.diagonal() << sig_h * sig_h + sig_pred * sig_pred,
                      sig_h * sig_h + sig_pred * sig_pred,
                      sig_v * sig_v + sig_pred * sig_pred;
      const GnssInnovationResult ver =
          evaluateGnssInnovation(f.p - pred, S, cfg_.rtk_innovation);
      s.gamma[j] = ver.gamma;
      s.gamma_valid[j] = ver.valid ? 1 : 0;
      s.skip[j] = ver.reject ? 1 : 0;
      ++s.n_evaluated;
      if (!ver.reject)
      {
        // Static epochs still move the anchor (real measurements); class-gated
        // epochs never do.
        if (!class_skip)
        {
          s.accepted[j] = 1;
          ++s.n_accepted;
          at = f.t;
          ap = f.p;
          s.anchor_update[j] = 1;
        }
      }
    }
    return s;
  };

  FitDiagnostics fit_diag;
  fit_diag.n_total = nfit;
  fit_diag.scale1 = fit1.scale;
  fit_diag.scale2 = fit1.scale;
  fit_diag.yaw1 = fit1.yaw;
  fit_diag.yaw2 = fit1.yaw;
  fit_diag.rms1 = fit1.rms;
  fit_diag.rms2 = fit1.rms;

  SimilarityFitResult fit_used = fit1;
  InnovScreen screen;
  bool use_screen = false;
  if (cfg_.rtk_innovation_gate_en && cfg_.rtk_interp_en)
  {
    screen = screen_innovation(fit1, sig_rtk_from_rms(fit1.rms));
    use_screen = true;
    fit_diag.n_accepted = screen.n_accepted;
    if (cfg_.fit_two_pass_en)
    {
      std::string fb;
      const int n_min = std::max(
          cfg_.fit_min_samples,
          static_cast<int>(std::ceil(cfg_.fit_min_accepted_ratio * nfit)));
      if (screen.n_accepted < n_min) fb = "too_few";
      std::vector<double> acc_t;
      for (size_t j = 0; j < fx.size(); ++j)
        if (screen.accepted[j]) acc_t.push_back(fx[j].t);
      if (acc_t.size() > 1)
      {
        double max_gap = 0.0;
        for (size_t k = 1; k < acc_t.size(); ++k)
          max_gap = std::max(max_gap, acc_t[k] - acc_t[k - 1]);
        const double span = acc_t.back() - acc_t.front();
        if (span > 1e-6 && max_gap / span > cfg_.fit_max_gap_ratio)
          fb = "gap";
      }
      else
      {
        fb = "too_few";
      }

      if (fb.empty())
      {
        // A keyframe sample is used only when both fixes bracketing its time
        // are accepted: a sample interpolated across a rejected epoch is not
        // evidence for the second fit.
        std::vector<double> fix_t(fx.size());
        std::vector<char> fix_acc(fx.size(), 0);
        for (size_t j = 0; j < fx.size(); ++j)
        {
          fix_t[j] = fx[j].t;
          fix_acc[j] = screen.accepted[j];
        }
        std::vector<double> w(nfit, 0.0);
        int n_used = 0;
        for (int i = 0; i < nfit; ++i)
        {
          const bool acc = acceptedFitSample(fix_t, fix_acc, fit_t[i]);
          w[i] = acc ? 1.0 : 0.0;
          n_used += acc ? 1 : 0;
        }
        if (n_used < n_min)
        {
          fb = "too_few_fit_samples";
        }
        else
        {
          const SimilarityFitResult fit2 =
              fitSimilarity2D(fit_lio, fit_enu, w, fit_opt);
          if (!fit2.valid)
          {
            fb = "fit2_invalid";
          }
          else
          {
            fit_diag.scale2 = fit2.scale;
            fit_diag.yaw2 = fit2.yaw;
            fit_diag.rms2 = fit2.rms;
            fit_diag.rms1_accepted =
                similarityFitRms(fit1, fit_lio, fit_enu, w);
            const double dyaw_deg =
                std::fabs(std::remainder(fit2.yaw - fit1.yaw, 2.0 * kPi)) *
                180.0 / kPi;
            if (std::fabs(fit2.scale - fit1.scale) > cfg_.fit_max_scale_delta)
              fb = "scale_delta";
            else if (dyaw_deg > cfg_.fit_max_yaw_delta_deg)
              fb = "yaw_delta";
            // Roundoff-sized changes on an already exact fit are not gain.
            else if (fit_diag.rms1_accepted - fit2.rms <=
                     std::max(1e-9, fit_diag.rms1_accepted * cfg_.fit_min_rms_gain))
              fb = "no_gain";
            else
            {
              fit_used = fit2;
              fit_diag.applied_pass = 2;
            }
          }
        }
      }
      fit_diag.fallback = fb;
    }
  }
  else if (cfg_.fit_two_pass_en)
  {
    fit_diag.fallback = cfg_.rtk_innovation_gate_en ? "interp_off"
                                                    : "innovation_off";
  }

  const double yaw = fit_used.yaw;
  const double scale = fit_used.scale;
  const Eigen::Vector3d tr = fit_used.tr;
  const double fit_rms = fit_used.rms;
  const double sig_rtk_xy = sig_rtk_from_rms(fit_rms);
  // A4/W1: decouple the odometer horizontal sigma from fit_rms. Default 0
  // keeps the historical formula; an explicit positive override replaces it
  // (clamped to the same bounds) and nothing else changes.
  const double sig_odom =
      cfg_.odom_sigma_fixed > 0.0
          ? std::min(0.5, std::max(0.05, cfg_.odom_sigma_fixed))
          : std::min(0.5, std::max(0.05, 0.05 + 0.06 * (fit_rms - 2.0)));
  const double cyaw = std::cos(yaw), syaw = std::sin(yaw);
  Eigen::Matrix3d Rz;
  Rz << cyaw, -syaw, 0, syaw, cyaw, 0, 0, 0, 1;

  // Scaled LIO positions: relative factors use the same metric as the
  // absolute/TDDD factors. The lever arm is physical and stays unscaled.
  std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> lio_p(n);
  std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> p0(n);
  for (int i = 0; i < n; ++i)
  {
    lio_p[i] = scale * kfs[i].p;
    p0[i] = Rz * lio_p[i] + tr;
  }

  // Pose3 initial values: body->ENU orientation is the fitted yaw times the LIO
  // body->world orientation; translation is the fitted ENU position.
  std::vector<gtsam::Pose3, Eigen::aligned_allocator<gtsam::Pose3>> T0(n);
  for (int i = 0; i < n; ++i)
    T0[i] = gtsam::Pose3(gtsam::Rot3(Rz * kfs[i].R),
                         gtsam::Point3(p0[i].x(), p0[i].y(), p0[i].z()));

  // Initial ENU velocities from the initial trajectory (central differences).
  // The Doppler factors correct them; this only gives LM a sensible start.
  std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> v0(
      n, Eigen::Vector3d::Zero());
  if (use_vel)
  {
    for (int i = 0; i < n; ++i)
    {
      const int a = std::max(0, i - 1);
      const int b = std::min(n - 1, i + 1);
      const double dt = kfs[b].t - kfs[a].t;
      if (dt > 1e-6) v0[i] = (p0[b] - p0[a]) / dt;
    }
  }

  // Unique nearest fix per keyframe.
  std::vector<int> ir(n, -1);
  std::vector<bool> ok(n, false);
  std::vector<bool> used(fx.size(), false);
  for (int i = 0; i < n; ++i)
  {
    int best = -1;
    double bd = 1e9;
    for (size_t j = 0; j < fx.size(); ++j)
    {
      const double d = std::fabs(fx[j].t - kfs[i].t);
      if (d < bd) { bd = d; best = static_cast<int>(j); }
    }
    if (best >= 0 && bd < 0.6 && !used[best])
    {
      used[best] = true;
      ir[i] = best;
      ok[i] = true;
    }
  }

  // P0 quality gate: fix-level test is defined above (A2.5 needs it for the
  // initial-fit screening); this index-level wrapper keeps the unique-nearest
  // semantics for the nearest-placement path.
  const auto quality_ok = [&](int i) {
    return ok[i] && fix_quality_ok(fx[ir[i]]);
  };

  // Static detection (same LIO-speed rule as before; the multi-source veto is
  // an offline experiment and is not enabled here).
  std::vector<double> speed(n, 0.0);
  for (int i = 1; i < n; ++i)
  {
    const double dt = kfs[i].t - kfs[i - 1].t;
    speed[i] = (kfs[i].p - kfs[i - 1].p).norm() / std::max(dt, 1e-9);
  }
  std::vector<bool> stat(n, false);
  const int dw = std::max(0, cfg_.detect_win);
  for (int i = 0; i < n; ++i)
  {
    std::vector<double> v;
    for (int j = std::max(0, i - dw); j <= std::min(n - 1, i + dw); ++j)
      v.push_back(speed[j]);
    stat[i] = median(v) < cfg_.detect_thresh;
  }
  std::vector<std::pair<int, int>> runs;
  for (int i = 0; i < n;)
  {
    if (!stat[i]) { ++i; continue; }
    int j = i;
    while (j + 1 < n && stat[j + 1]) ++j;
    if (!runs.empty() && i - runs.back().second <= 2) runs.back().second = j;
    else runs.push_back({i, j});
    i = j + 1;
  }
  std::vector<bool> member(n, false);
  std::vector<int> run_of(n, -1);
  std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> anchor(runs.size());
  std::vector<bool> has_anchor(runs.size(), false);
  std::vector<StaticAnchorValidityResult> static_validity_rows;
  if (cfg_.static_anchor_validity_en)
    static_validity_rows.reserve(runs.size());
  for (size_t k = 0; k < runs.size(); ++k)
  {
    for (int i = runs[k].first; i <= runs[k].second; ++i)
    {
      member[i] = true;
      run_of[i] = static_cast<int>(k);
    }
    std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> bases;
    std::vector<StaticAnchorSample> samples;
    if (cfg_.static_anchor_validity_en)
      samples.reserve(runs[k].second - runs[k].first + 1);
    for (int i = runs[k].first; i <= runs[k].second; ++i)
    {
      if (!quality_ok(i)) continue;
      const Eigen::Vector3d lw = Rz * kfs[i].R * cfg_.lever;
      const Eigen::Vector3d q = fx[ir[i]].p - lw;
      bases.push_back(q);
      if (cfg_.static_anchor_validity_en)
      {
        StaticAnchorSample s;
        s.kf_time = kfs[i].t;
        s.fix_time = fx[ir[i]].t;
        s.q = q;
        s.lio_position = kfs[i].p;
        s.quality_class =
            classifyGnssQuality(quality_of(fx[ir[i]]), cfg_.gnss_quality).cls;
        samples.push_back(s);
      }
    }
    if (!bases.empty())
    {
      anchor[k] = medianVec(bases);
      has_anchor[k] = true;
    }
    if (cfg_.static_anchor_validity_en)
    {
      // A3.1/A3.2: the reference motion onset for the gate comes from the
      // ONLINE LIO static detector (the first non-static keyframe after the
      // run) -- never from any reference trajectory.
      StaticAnchorValidityParams vp = cfg_.static_anchor_validity;
      if (runs[k].second + 1 < n)
        vp.reference_onset_sec =
            kfs[runs[k].second + 1].t - kfs[runs[k].first].t;
      const StaticAnchorValidityResult vr = evaluateStaticAnchorValidity(
          vp, static_cast<int>(k), t0kf,
          kfs[runs[k].first].t, kfs[runs[k].second].t, samples);
      if (vr.state != StaticAnchorValidityState::VALID) has_anchor[k] = false;
      else if (cfg_.static_anchor_unified_en)
      {
        // A3.2: re-estimate from EXACTLY the validity-selected carrier-fixed
        // subset; rejected samples (Float/other/out-of-window) must not
        // re-enter the anchor estimate.
        std::vector<Eigen::Vector3d,
                    Eigen::aligned_allocator<Eigen::Vector3d>> est;
        for (int idx : vr.estimation_indices)
          est.push_back(samples[idx].q);
        if (est.empty()) has_anchor[k] = false;
        else anchor[k] = medianVec(est);
      }
      if (!cfg_.static_anchor_diagnostics_path.empty())
      {
        // A3.2 sample-ID chain: candidates vs judgment/estimation set,
        // recorded for BOTH gate-only and unified arms (the contract covers
        // the judgment set regardless of the estimation mode).
        // A3.2 sample-ID chain: ONE APPEND-ONLY row per (solve, segment) so
        // every segment of every solve survives (the fourth-round audit
        // caught the per-solve overwrite hiding earlier segments). The file
        // is truncated fresh in the constructor.
        std::ofstream uf(cfg_.static_anchor_diagnostics_path +
                             ".estimation.csv", std::ios::app);
        uf << solve_seq_.load() << ',' << std::setprecision(17) << t1kf
           << ',' << static_cast<int>(k) << ','
           << staticAnchorValidityStateName(vr.state) << ','
           << samples.size() << ',' << vr.estimation_indices.size() << ',';
        for (size_t i = 0; i < vr.estimation_indices.size(); ++i)
          uf << (i ? ";" : "") << std::setprecision(17)
             << samples[vr.estimation_indices[i]].fix_time;
        uf << '\n';
        uf.flush();
      }
      static_validity_rows.push_back(vr);
    }
  }
  if (cfg_.static_anchor_validity_en)
    writeStaticAnchorDiagnostics(cfg_.static_anchor_diagnostics_path,
                                 static_validity_rows);

  // ---- P0 lambda_min weight ------------------------------------------------
  std::vector<double> ln_lam;
  for (int i = 0; i < n; ++i)
    if (kfs[i].lambda_min > 0.0) ln_lam.push_back(std::log(kfs[i].lambda_min));
  double lam_med = 0.0, lam_mad = 0.0;
  if (!ln_lam.empty())
  {
    lam_med = median(ln_lam);
    std::vector<double> dev;
    dev.reserve(ln_lam.size());
    for (double v : ln_lam) dev.push_back(std::fabs(v - lam_med));
    lam_mad = std::max(0.05, median(dev));
  }
  const double s_fit = fit_rms / std::max(0.05, cfg_.lambda_expected_sigma);
  const double trust_fit = sigmoid((cfg_.lambda_fit_k - s_fit) / 0.25);
  std::vector<double> w_rtk(n, 1.0);
  for (int i = 0; i < n; ++i)
  {
    if (!cfg_.lambda_weight_en || kfs[i].lambda_min <= 0.0 || ln_lam.empty())
      continue;
    const double s_lam = (std::log(kfs[i].lambda_min) - lam_med) / lam_mad;
    const double trust = trust_fit * sigmoid(s_lam);
    w_rtk[i] = 1.0 - (1.0 - cfg_.lambda_w_min) * trust;
    w_rtk[i] = std::min(1.0, std::max(cfg_.lambda_w_min, w_rtk[i]));
  }

  const auto noise_xyz = [](double sx, double sy, double sz) {
    return gtsam::noiseModel::Diagonal::Sigmas(gtsam::Vector3(sx, sy, sz));
  };
  // Pose3 tangent order is [rotation(3), translation(3)]: sigma_rot in rad,
  // then the per-axis translation sigmas.
  const auto noise_pose = [](double sr, double st, double sz) {
    gtsam::Vector6 sig;
    sig << sr, sr, sr, st, st, sz;
    return gtsam::noiseModel::Diagonal::Sigmas(sig);
  };
  const auto noise_xy = [](double sx, double sy) {
    return gtsam::noiseModel::Diagonal::Sigmas(gtsam::Vector2(sx, sy));
  };
  const auto robust_xy = [&](double sx, double sy) -> gtsam::SharedNoiseModel {
    auto base = noise_xy(sx, sy);
    if (!cfg_.cauchy_xy_en) return base;
    return gtsam::noiseModel::Robust::Create(
        gtsam::noiseModel::mEstimator::Cauchy::Create(cfg_.cauchy_xy_k), base);
  };
  const auto robust_z = [&](double sz) -> gtsam::SharedNoiseModel {
    auto base = gtsam::noiseModel::Isotropic::Sigma(1, sz);
    return gtsam::noiseModel::Robust::Create(
        gtsam::noiseModel::mEstimator::Huber::Create(1.345), base);
  };

  gtsam::NonlinearFactorGraph graph;
  std::map<size_t, double> factor_fix_stamp;
  const auto add_rel = [&](int i, int j, const Eigen::Vector3d &d,
                           const gtsam::SharedNoiseModel &noise) {
    graph.add(boost::make_shared<RelPosFactor>(
        i, j, gtsam::Point3(d.x(), d.y(), d.z()), noise));
  };
  const auto add_abs = [&](int i, const Eigen::Vector3d &z,
                           const gtsam::SharedNoiseModel &noise) {
    graph.add(boost::make_shared<AbsPosFactor>(
        i, gtsam::Point3(z.x(), z.y(), z.z()), noise));
  };
  const auto add_abs_xy = [&](int i, const Eigen::Vector3d &z,
                              const gtsam::SharedNoiseModel &noise) {
    graph.add(boost::make_shared<AbsPosXYFactor>(
        i, Eigen::Vector2d(z.x(), z.y()), noise));
  };
  const auto add_abs_z = [&](int i, double z,
                             const gtsam::SharedNoiseModel &noise) {
    graph.add(boost::make_shared<AbsPosZFactor>(i, z, noise));
  };

  const auto odom_pose_noise =
      noise_pose(cfg_.sig_odom_rot, sig_odom, cfg_.sig_odom_z);
  const auto rigid_pose_noise =
      noise_pose(cfg_.sig_rigid_rot, cfg_.sig_rigid, cfg_.sig_rigid);
  for (int i = 0; i + 1 < n; ++i)
  {
    // Full LIVO relative pose: the graph ENU transform is a global left
    // multiplication, so T_i^-1 T_j is independent of Rz/tr. The translation is
    // scaled with the same LIO scale as the absolute positions.
    const Eigen::Matrix3d R_ij = kfs[i].R.transpose() * kfs[i + 1].R;
    const Eigen::Vector3d t_ij =
        kfs[i].R.transpose() * (lio_p[i + 1] - lio_p[i]);
    graph.add(boost::make_shared<gtsam::BetweenFactor<gtsam::Pose3>>(
        i, i + 1, gtsam::Pose3(gtsam::Rot3(R_ij), gtsam::Point3(t_ij)),
        odom_pose_noise));
    if (member[i] && member[i + 1])
      graph.add(boost::make_shared<gtsam::BetweenFactor<gtsam::Pose3>>(
          i, i + 1, gtsam::Pose3::Identity(), rigid_pose_noise));
  }

  // ---- P0 TDDD factors -----------------------------------------------------
  int tddd_used = 0;
  double tddd_shift = cfg_.tddd_time_shift;
  if (cfg_.tddd_en && have_origin_ && dds.size() >= 2)
  {
    // The DD epochs sit on GPS integer seconds while the keyframes sit at the
    // LiDAR/bag phase (c01 ~.05 s, c02 ~.35 s). Estimate the constant phase
    // offset and remove it before nearest-epoch matching; otherwise widening
    // the tolerance pairs the keyframe interval with a shifted DD interval.
    if (cfg_.tddd_time_shift_auto)
    {
      std::vector<double> offs;
      offs.reserve(n);
      for (int i = 0; i < n; ++i)
      {
        auto it = std::lower_bound(dds.begin(), dds.end(), kfs[i].t,
                                   [](const DdEpoch &a, double v) { return a.t < v; });
        double best = 1e9;
        if (it != dds.end())
        {
          const double d = it->t - kfs[i].t;
          if (std::fabs(d) < std::fabs(best)) best = d;
        }
        if (it != dds.begin())
        {
          const auto &prev = *(it - 1);
          const double d = prev.t - kfs[i].t;
          if (std::fabs(d) < std::fabs(best)) best = d;
        }
        if (std::fabs(best) < 1.0) offs.push_back(best);
      }
      if (offs.size() >= 10) tddd_shift = median(offs);
    }
    const Eigen::Matrix3d R_enu = enuRotation(origin_lat_, origin_lon_);
    const Eigen::Vector3d base_enu = R_enu * (cfg_.base_ecef - origin_ecef_);
    const auto to_enu = [&](const Eigen::Vector3d &ecef) {
      return R_enu * (ecef - origin_ecef_);
    };
    const auto dd_geom = [&](const DdPair &r, const Eigen::Vector3d &p) {
      const Eigen::Vector3d sat = to_enu(r.sat_ecef);
      const Eigen::Vector3d ref = to_enu(r.ref_ecef);
      return ((sat - p).norm() - (sat - base_enu).norm())
           - ((ref - p).norm() - (ref - base_enu).norm());
    };
    const auto key_of = [](const DdPair &r) {
      return r.sys + "/" + r.freq + "/" + r.ref + "/" + r.sat;
    };
    const auto nearest_dd = [&](double t) -> const DdEpoch * {
      if (dds.empty()) return nullptr;
      const double target = t + tddd_shift;
      auto it = std::lower_bound(dds.begin(), dds.end(), target,
                                 [](const DdEpoch &a, double v) { return a.t < v; });
      const DdEpoch *best = nullptr;
      double bd = cfg_.tddd_max_dt;
      if (it != dds.end() && std::fabs(it->t - target) <= bd)
      {
        best = &(*it);
        bd = std::fabs(it->t - target);
      }
      if (it != dds.begin())
      {
        const auto &prev = *(it - 1);
        if (std::fabs(prev.t - target) < bd) best = &prev;
      }
      return best;
    };
    const auto freq_sigma = [](const std::string &freq) {
      if (freq == "L1" || freq == "L2") return 0.008;
      if (freq == "B3I") return 0.015;
      if (freq == "B2I") return 0.025;
      return 0.015;
    };

    std::set<double> used_dd_times;
    for (int i = 0; i + 1 < n; ++i)
    {
      const double dt = kfs[i + 1].t - kfs[i].t;
      if (dt < 0.8 || dt > 1.2) continue;
      const DdEpoch *e1 = nearest_dd(kfs[i].t);
      const DdEpoch *e2 = nearest_dd(kfs[i + 1].t);
      if (!e1 || !e2 || e1 == e2) continue;
      // R4.5: the same DD epoch must not feed two TDDD factors. Consecutive
      // intervals share e2/e1, and without a cross-covariance that counts the
      // same phase observation twice. Keep a maximal set of disjoint intervals.
      if (cfg_.tddd_nonoverlap &&
          (used_dd_times.count(e1->t) || used_dd_times.count(e2->t)))
        continue;
      if (cfg_.tddd_min_ratio > 0.0)
      {
        const bool q1 = e1->ratio <= 0.0 || e1->ratio >= cfg_.tddd_min_ratio;
        const bool q2 = e2->ratio <= 0.0 || e2->ratio >= cfg_.tddd_min_ratio;
        if (!q1 || !q2) continue;
      }
      std::map<std::string, int> idx1;
      for (int k = 0; k < static_cast<int>(e1->pairs.size()); ++k)
        idx1[key_of(e1->pairs[k])] = k;
      const Eigen::Vector3d p = p0[i];
      std::vector<std::tuple<Eigen::Vector3d, double, double>> rows;
      for (const auto &p2 : e2->pairs)
      {
        auto it = idx1.find(key_of(p2));
        if (it == idx1.end()) continue;
        const DdPair &p1 = e1->pairs[it->second];
        // Both epochs must be in a clean arc: a slip or reference change at
        // either endpoint breaks the ambiguity cancellation that TDDD assumes.
        if (p1.slip || p1.ref_change || p2.slip || p2.ref_change) continue;
        const double elev = std::min(std::min(p1.elev_sat, p1.elev_ref),
                                     std::min(p2.elev_sat, p2.elev_ref));
        if (elev < 5.0) continue;
        const Eigen::Vector3d sat1 = to_enu(p1.sat_ecef);
        const Eigen::Vector3d ref1 = to_enu(p1.ref_ecef);
        const Eigen::Vector3d sat2 = to_enu(p2.sat_ecef);
        const Eigen::Vector3d ref2 = to_enu(p2.ref_ecef);
        const Eigen::Vector3d g =
            0.5 * (unit(ref1 - p) + unit(ref2 - p))
          - 0.5 * (unit(sat1 - p) + unit(sat2 - p));
        const double y_body =
            (p2.phase - p1.phase) - (dd_geom(p2, p) - dd_geom(p1, p));
        // The DD phase is measured at the ANTENNA, while the graph node is the
        // body origin. The lever term is now inside TdddBlockVelFactor, where
        // it is linearized with the optimized Pose3 rotations; y stays the
        // body-geometry residual.
        const double y = y_body;
        // R4.5: use each epoch's own phase sigma, plus a model floor. The old
        // sqrt(2)*sig1 assumed the two epochs had identical noise.
        const auto phase_sigma = [&](const DdPair &pr) {
          double s = pr.sigma_phase > 0.0
                         ? pr.sigma_phase
                         : (cfg_.tddd_freq_sigma_en ? freq_sigma(pr.freq) : 0.015);
          if (cfg_.tddd_elev_weight_en)
          {
            const double e = std::max(1.0, std::min(pr.elev_sat, pr.elev_ref));
            s *= std::sqrt(std::max(1.0, 1.0 / (2.0 * std::sin(e * kPi / 180.0))));
          }
          return std::max(s, 1e-3);
        };
        const double s1 = phase_sigma(p1);
        const double s2 = phase_sigma(p2);
        const double sigma = cfg_.tddd_sigma_scale *
            std::sqrt(s1 * s1 + s2 * s2 +
                      cfg_.tddd_model_sigma * cfg_.tddd_model_sigma);
        rows.emplace_back(g, y, sigma);
      }
      if (static_cast<int>(rows.size()) >= cfg_.tddd_min_pairs)
      {
        const int m = static_cast<int>(rows.size());
        std::vector<Eigen::Vector3d> gs;
        std::vector<double> ys;
        gs.reserve(m);
        ys.reserve(m);
        Eigen::MatrixXd R = Eigen::MatrixXd::Zero(m, m);
        double min_diag = std::numeric_limits<double>::infinity();
        for (const auto &r : rows)
        {
          gs.push_back(std::get<0>(r));
          ys.push_back(std::get<1>(r));
          const double s = std::get<2>(r);
          R((int)gs.size() - 1, (int)gs.size() - 1) = s * s;
          min_diag = std::min(min_diag, s * s);
        }
        // DD rows in one epoch share the reference satellite. Under the
        // equal-SD approximation Cov(DD_i,DD_j) = sigma_ref^2 ~= 0.5*sigma^2.
        // tddd_ref_corr=0.5 is that model; 0 reproduces the old diagonal one.
        const double off = std::min(0.95 * min_diag,
                                    cfg_.tddd_ref_corr * min_diag);
        for (int a = 0; a < m; ++a)
          for (int b = 0; b < m; ++b)
            if (a != b) R(a, b) = off;
        auto base = gtsam::noiseModel::Gaussian::Covariance(R);
        auto noise = gtsam::noiseModel::Robust::Create(
            gtsam::noiseModel::mEstimator::Huber::Create(1.345), base);
        if (use_vel)
        {
          const double dt1 = e1->t - kfs[i].t;
          const double dt2 = e2->t - kfs[i + 1].t;
          graph.add(boost::make_shared<TdddBlockVelFactor>(
              i, i + 1, n + i, n + i + 1, dt1, dt2, cfg_.lever, gs, ys,
              noise));
        }
        else
        {
          graph.add(boost::make_shared<TdddBlockFactor>(
              i, i + 1, gs, ys, noise));
        }
        tddd_used += m;
        if (cfg_.tddd_nonoverlap)
        {
          used_dd_times.insert(e1->t);
          used_dd_times.insert(e2->t);
        }
      }
    }
  }

  // One place that decides whether an epoch is dropped because it touches a
  // static run. A3 will change the anchor estimate, not this rule; keeping the
  // decision here and its trace reason next to it stops the two from being
  // re-coupled when the static anchor is reworked.
  //   bracket >= 0: keyframe interval [bracket, bracket+1]
  //   nearest  >= 0: the keyframe A0 would attach the epoch to
  const auto static_skip_of = [&](int bracket, int nearest, int *static_id) {
    *static_id = -1;
    if (cfg_.rtk_static_rule_bracket && bracket >= 0)
    {
      if (member[bracket]) *static_id = run_of[bracket];
      else if (member[bracket + 1]) *static_id = run_of[bracket + 1];
      return member[bracket] || member[bracket + 1];
    }
    if (nearest >= 0 && member[nearest])
    {
      *static_id = run_of[nearest];
      return true;
    }
    return false;
  };

  // ---- A1 ablation: placement x static rule --------------------------------
  // Placement:      rtk_interp_en = false -> one factor per keyframe (nearest
  //                 fix, A0); true -> one factor per RTK epoch (Pose3 interp).
  // Static rule:    rtk_static_rule_bracket = false -> drop an epoch only when
  //                 the keyframe it attaches to is a static member (this is the
  //                 rule A0 already used); true -> drop it when either
  //                 bracketing keyframe is static.
  // Arms: A0 = (false,false), A1-T = (true,false), A1-S = (false,true),
  //       A1 = (true,true). A0 already skipped static keyframes; the flag makes
  //       that existing rule explicit so it can be ablated, it is not new
  //       behaviour introduced by A1.
  int rtk_used = 0;
  int rtk_interp_used = 0;
  int rtk_skip_static = 0;
  int rtk_skip_quality = 0;
  int rtk_skip_assoc = 0;
  int rtk_skip_class = 0;
  int rtk_innov_rejected = 0;
  int rtk_innov_invalid = 0;
  int rtk_pre_rejected = 0;
  double w_sum = 0.0;
  int w_n = 0;

  const auto record_assoc = [&](double t, const AssocTraceRow &row) {
    if (!cfg_.assoc_trace_path.empty()) assoc_trace_[t] = row;
  };
  // A2.2: both channels arrive here as a Fix; quality_of/class_gate are defined
  // above because the initial-fit screening needs them too.
  const auto fill_quality = [&](const Fix &f, AssocTraceRow *r) {
    r->nsat = f.nsat;
    r->pdop = f.pdop;
    r->h_acc_mm = f.h_acc_mm;
    r->v_acc_mm = f.v_acc_mm;
    r->carr_soln = f.carr_soln;
    r->fix_type = f.fix_type;
    r->q_valid = f.quality_valid ? 1 : 0;
    r->has_p_dop = f.has_p_dop ? 1 : 0;
    r->has_h_acc = f.has_h_acc ? 1 : 0;
    r->has_v_acc = f.has_v_acc ? 1 : 0;
    r->q_source = f.quality_source;
    const GnssQualityVerdict v =
        classifyGnssQuality(quality_of(f), cfg_.gnss_quality);
    r->q_class = static_cast<int>(v.cls);
    r->q_reason = v.reason;
  };
  if (cfg_.rtk_interp_en)
  {
    const std::vector<FixAssociation> &assoc = assoc_epochs;

    // A2.4/A2.5: innovation decisions come from the fixed-mask screen computed
    // before the second fit. The factor loop, the fit mask and the trace then
    // share one decision per epoch; the loop never re-evaluates the test with a
    // different scale/yaw than the one that produced the mask.
    for (const auto &a : assoc)
    {
      const Fix &f = fx[a.fix_index];
      const bool q_ok = fix_quality_ok(f);
      const bool class_skip = class_gate(f);
      int nearest = -1;
      if (a.key_i >= 0 && a.key_j >= 0)
        nearest =
            std::fabs(f.t - kf_t[a.key_i]) <= std::fabs(f.t - kf_t[a.key_j])
                ? a.key_i
                : a.key_j;
      int static_id = -1;
      const bool static_skip = static_skip_of(a.key_i, nearest, &static_id);

      double innov_gamma = -1.0;
      bool innov_skip = false;
      bool innov_valid = true;
      int anchor_update = 0;
      if (use_screen)
      {
        innov_gamma = screen.gamma[a.fix_index];
        innov_skip = screen.skip[a.fix_index] != 0;
        anchor_update = screen.anchor_update[a.fix_index];
        innov_valid = screen.gamma_valid[a.fix_index] != 0;
      }

      bool added = false;
      if (a.valid && q_ok && !class_skip && !static_skip && !innov_skip)
      {
        double sig_h = sig_rtk_xy;
        double sig_v = cfg_.sig_rtk_z;
        if (f.sigma_h > 0.0)
          sig_h = std::min(cfg_.sigma_h_ceil,
                           std::max(cfg_.sigma_h_floor, f.sigma_h));
        if (f.sigma_v > 0.0)
          sig_v = std::min(cfg_.sigma_v_ceil,
                           std::max(cfg_.sigma_v_floor, f.sigma_v));
        // Same lambda_min trust as A0; the bracket has two nodes, so use the
        // more conservative (smaller) weight.
        const double w = std::min(w_rtk[a.key_i], w_rtk[a.key_j]);
        sig_h /= std::sqrt(std::max(cfg_.lambda_w_min, w));
        // Motion-model floor on top of the measurement sigma.
        const double model = cfg_.rtk_interp_model_sigma;
        sig_h = std::sqrt(sig_h * sig_h + model * model);
        sig_v = std::sqrt(sig_v * sig_v + model * model);
        gtsam::SharedNoiseModel noise = noise_xyz(sig_h, sig_h, sig_v);
        if (cfg_.rtk_interp_robust_en)
          noise = gtsam::noiseModel::Robust::Create(
              gtsam::noiseModel::mEstimator::Cauchy::Create(
                  cfg_.cauchy_xy_k),
              noise);
        graph.add(boost::make_shared<InterpolatedAbsPosFactor>(
            a.key_i, a.key_j, a.alpha,
            gtsam::Point3(f.p.x(), f.p.y(), f.p.z()),
            gtsam::Point3(cfg_.lever.x(), cfg_.lever.y(), cfg_.lever.z()),
            noise));
        if (!cfg_.anchor_trace_path.empty()) factor_fix_stamp[graph.size()-1] = f.t;
        ++rtk_used;
        ++rtk_interp_used;
        w_sum += w;
        ++w_n;
        added = true;
      }
      if (a.status != FixAssocStatus::DUPLICATE_EPOCH && !added)
      {
        // Static first: an epoch in a static bracket would not have produced a
        // factor anyway, so it must not be counted as a class-gate rejection.
        if (!a.valid) ++rtk_skip_assoc;
        else if (!q_ok) ++rtk_skip_quality;
        else if (static_skip) ++rtk_skip_static;
        else if (class_skip) ++rtk_skip_class;
        else if (innov_skip)
        {
          if (innov_valid) ++rtk_innov_rejected;
          else ++rtk_innov_invalid;
        }
      }

      AssocTraceRow row;
      row.key_i = a.key_i;
      row.key_j = a.key_j;
      row.alpha = a.alpha;
      row.dt = a.dt;
      row.bracket_dt = (a.key_i >= 0 && a.key_j >= 0)
                           ? kf_t[a.key_j] - kf_t[a.key_i]
                           : 0.0;
      row.status = static_cast<int>(a.status);
      row.quality = q_ok ? 1 : 0;
      row.static_id = static_id;
      row.reason = static_cast<int>(
          added ? AssocReason::FACTOR
                : (!a.valid ? AssocReason::ASSOC_INVALID
                            : (!q_ok ? AssocReason::QUALITY
                                     : (static_skip
                                            ? AssocReason::STATIC
                                            : (class_skip
                                                   ? AssocReason::CLASS_GATED
                                                   : (innov_skip
                                                          ? (innov_valid
                                                                 ? AssocReason::INNOVATION_GATED
                                                                 : AssocReason::INNOVATION_INVALID)
                                                          : AssocReason::FACTOR))))));
      row.factor = added ? 1 : 0;
      row.innov_gamma = innov_gamma;
      row.anchor_update = anchor_update;
      fill_quality(f, &row);
      record_assoc(f.t, row);
    }
  }
  else
  {
    // A0 placement: one factor per keyframe, unique nearest fix.
    for (int i = 0; i < n; ++i)
    {
      if (!ok[i]) continue;
      const double t_fix = fx[ir[i]].t;
      const int b = findKeyframeBracket(kf_t, t_fix);
      const bool q_ok = fix_quality_ok(fx[ir[i]]);
      const bool class_skip = class_gate(fx[ir[i]]);
      int static_id = -1;
      const bool static_skip = static_skip_of(b, i, &static_id);

      if (!q_ok || class_skip || static_skip)
      {
        if (!q_ok) ++rtk_skip_quality;
        else if (static_skip) ++rtk_skip_static;
        else ++rtk_skip_class;
      }
      else
      {
        const Eigen::Vector3d lw = Rz * kfs[i].R * cfg_.lever;
        const Eigen::Vector3d z = fx[ir[i]].p - lw;
        double sig_h = sig_rtk_xy;
        double sig_v = cfg_.sig_rtk_z;
        if (fx[ir[i]].sigma_h > 0.0)
          sig_h = std::min(cfg_.sigma_h_ceil,
                           std::max(cfg_.sigma_h_floor, fx[ir[i]].sigma_h));
        if (fx[ir[i]].sigma_v > 0.0)
          sig_v = std::min(cfg_.sigma_v_ceil,
                           std::max(cfg_.sigma_v_floor, fx[ir[i]].sigma_v));
        // P0: a high-trust LIO (good geometry, low fit_rms) downweights the
        // absolute fix; the static prior handles the static runs separately.
        const double w = w_rtk[i];
        sig_h /= std::sqrt(std::max(cfg_.lambda_w_min, w));
        add_abs_xy(i, z, robust_xy(sig_h, sig_h));
        add_abs_z(i, z.z(), robust_z(sig_v));
        ++rtk_used;
        w_sum += w;
        ++w_n;
      }

      if (!cfg_.assoc_trace_path.empty())
      {
        AssocTraceRow row;
        if (b >= 0)
        {
          row.key_i = b;
          row.key_j = b + 1;
          row.bracket_dt = kf_t[b + 1] - kf_t[b];
          row.alpha = (t_fix - kf_t[b]) / row.bracket_dt;
          row.dt = t_fix - kf_t[b];
        }
        else
        {
          row.key_i = i;
          row.key_j = i;
        }
        row.status = static_cast<int>(FixAssocStatus::OK);
        row.quality = q_ok ? 1 : 0;
        row.static_id = static_id;
        row.reason = static_cast<int>(
            !q_ok ? AssocReason::QUALITY
                  : (static_skip ? AssocReason::STATIC
                                 : (class_skip ? AssocReason::CLASS_GATED
                                               : AssocReason::FACTOR)));
        row.factor = (!q_ok || class_skip || static_skip) ? 0 : 1;
        fill_quality(fx[ir[i]], &row);
        record_assoc(t_fix, row);
      }
    }

    // Fixes the unique-nearest rule left without a keyframe: record them so the
    // CSV explains the gap instead of hiding it.
    if (!cfg_.assoc_trace_path.empty())
    {
      for (size_t j = 0; j < fx.size(); ++j)
      {
        if (used[j]) continue;
        if (fx[j].t < kf_t.front() || fx[j].t > kf_t.back()) continue;
        AssocTraceRow row;
        const int b = findKeyframeBracket(kf_t, fx[j].t);
        if (b >= 0)
        {
          row.key_i = b;
          row.key_j = b + 1;
          row.bracket_dt = kf_t[b + 1] - kf_t[b];
          row.alpha = (fx[j].t - kf_t[b]) / row.bracket_dt;
          row.dt = fx[j].t - kf_t[b];
        }
        row.status = static_cast<int>(FixAssocStatus::OK);
        row.quality = fix_quality_ok(fx[j]) ? 1 : 0;
        row.reason = static_cast<int>(AssocReason::NO_ASSIGNMENT);
        row.factor = 0;
        fill_quality(fx[j], &row);
        record_assoc(fx[j].t, row);
      }
    }
  }

  // A jump-gated epoch never reaches the association, but it is still an input
  // epoch and gets exactly one decision row.
  for (const auto &f : pre_rejected)
  {
    AssocTraceRow row;
    row.status = static_cast<int>(FixAssocStatus::PRE_REJECTED);
    row.quality = fix_quality_ok(f) ? 1 : 0;
    row.reason = static_cast<int>(AssocReason::JUMP_REJECTED);
    row.factor = 0;
    fill_quality(f, &row);
    record_assoc(f.t, row);
    ++rtk_pre_rejected;
  }

  if (!cfg_.assoc_trace_path.empty())
  {
    // Drop trace rows that left the retained history, then persist the
    // accumulated per-epoch table (not just the latest window).
    while (!assoc_trace_.empty() && assoc_trace_.begin()->first < t0kf - 10.0)
      assoc_trace_.erase(assoc_trace_.begin());
    writeAssocTrace(t0kf - 10.0);
  }
  std::ofstream anchor_trace;
  if (!cfg_.anchor_trace_path.empty())
  {
    anchor_trace.open(cfg_.anchor_trace_path + ".tmp", std::ios::trunc);
    anchor_trace << std::setprecision(17)
        << "solve_stamp,run_id,start_stamp,end_stamp,anchor_used,anchor_x,anchor_y,anchor_z,lio_x,lio_y,lio_z,gap,sigma,weak,fit_rms\n";
    std::ofstream samples(cfg_.anchor_trace_path + ".samples.tmp", std::ios::trunc);
    samples << std::setprecision(17) << "solve_stamp,run_id,key_index,key_stamp,fix_index,fix_stamp,status,eligible,qx,qy,qz\n";
    for (size_t k = 0; k < runs.size(); ++k)
      for (int i = runs[k].first; i <= runs[k].second; ++i)
      {
        samples << t1kf << ',' << k << ',' << i << ',' << kfs[i].t << ',' << ir[i];
        if (ir[i] >= 0) {
          const Eigen::Vector3d q = fx[ir[i]].p - Rz * kfs[i].R * cfg_.lever;
          samples << ',' << fx[ir[i]].t << ',' << fx[ir[i]].status << ',' << quality_ok(i)
                  << ',' << q.x() << ',' << q.y() << ',' << q.z();
        } else samples << ",,,0,,,";
        samples << '\n';
      }
    samples.close();
    if (samples) std::rename((cfg_.anchor_trace_path + ".samples.tmp").c_str(), (cfg_.anchor_trace_path + ".samples.csv").c_str());
  }
  for (size_t k = 0; k < runs.size(); ++k)
  {
    if (!has_anchor[k]) {
      if (anchor_trace) anchor_trace << t1kf << ',' << k << ',' << kfs[runs[k].first].t << ',' << kfs[runs[k].second].t << ",0,,,,,,,,,,\n";
      continue;
    }
    // P0: use the strong anchor only when the static RTK is consistent with
    // the LIO static position. c02's static RTK is ~4 m off; a strong anchor
    // there pulls the whole static run away from the moving segment.
    std::vector<Eigen::Vector3d, Eigen::aligned_allocator<Eigen::Vector3d>> lio_run;
    lio_run.reserve(runs[k].second - runs[k].first + 1);
    for (int i = runs[k].first; i <= runs[k].second; ++i) lio_run.push_back(p0[i]);
    const Eigen::Vector3d lio_med = medianVec(lio_run);
    const double anchor_gap = (anchor[k] - lio_med).norm();
    const double sig_anchor =
        anchor_gap > cfg_.static_anchor_consistency ? cfg_.static_anchor_weak
                                                    : cfg_.sig_anchor;
    if (anchor_trace) anchor_trace << t1kf << ',' << k << ',' << kfs[runs[k].first].t << ',' << kfs[runs[k].second].t
        << ",1," << anchor[k].x() << ',' << anchor[k].y() << ',' << anchor[k].z()
        << ',' << lio_med.x() << ',' << lio_med.y() << ',' << lio_med.z()
        << ',' << anchor_gap << ',' << sig_anchor << ',' << (anchor_gap > cfg_.static_anchor_consistency) << ',' << fit_rms << '\n';
    add_abs(runs[k].first, anchor[k],
            noise_xyz(sig_anchor, sig_anchor, sig_anchor));
  }
  if (anchor_trace.is_open()) {
    anchor_trace.close();
    if (anchor_trace) std::rename((cfg_.anchor_trace_path + ".tmp").c_str(), cfg_.anchor_trace_path.c_str());
  }
  for (const auto &r : runs)
  {
    const int b = r.second;
    for (int j = 1; j <= cfg_.trans_kf; ++j)
    {
      const int i0 = b + j - 1, i1 = b + j;
      if (i1 >= n || member[i1]) break;
      if (!quality_ok(i0) || !quality_ok(i1) || ir[i0] == ir[i1]) continue;
      const Eigen::Vector3d lw0 = Rz * kfs[i0].R * cfg_.lever;
      const Eigen::Vector3d lw1 = Rz * kfs[i1].R * cfg_.lever;
      const Eigen::Vector3d d = (fx[ir[i1]].p - lw1) - (fx[ir[i0]].p - lw0);
      if (usage_en)
        usage << "transition," << std::setprecision(17) << t1kf << ','
              << i0 << ',' << i1 << ',' << kfs[i1].t << ','
              << ir[i0] << ',' << fx[ir[i0]].t << ','
              << ir[i1] << ',' << fx[ir[i1]].t << ','
              << cfg_.trans_sigma_xy << ',' << cfg_.trans_sigma_z << ','
              << d.x() << ',' << d.y() << ',' << d.z() << '\n';
      add_rel(i0, i1, d,
              noise_xyz(cfg_.trans_sigma_xy, cfg_.trans_sigma_xy,
                        cfg_.trans_sigma_z));
    }
  }
  if (usage_en)
  {
    // R2: real fit-sample usage, recorded straight from the code path that
    // builds the samples (not re-derived by an offline association rule).
    for (int s = 0; s < nfit; ++s)
    {
      const int a = fit_bracket[s].first, b = fit_bracket[s].second;
      usage << "fit_sample," << std::setprecision(17) << t1kf << ','
            << s << ",-1," << fit_t[s] << ','
            << a << ',' << (a >= 0 ? fx[a].t : 0.0) << ','
            << b << ',' << (b >= 0 ? fx[b].t : 0.0) << ",,,,,\n";
    }
    // Rewritten per solve; the final solve's set is what persists, matching
    // the factors.csv/anchor.csv semantics.
    std::ofstream uf(cfg_.usage_trace_path + ".tmp", std::ios::trunc);
    uf << usage.str();
    uf.close();
    if (uf) std::rename((cfg_.usage_trace_path + ".tmp").c_str(),
                        cfg_.usage_trace_path.c_str());
  }
  // R4.4b: if the previous solve stored a marginal for the keyframe that is now
  // the window's first node, use it as the boundary prior. This replaces the
  // information lost with the dropped old node and its factors. It is a
  // single-node marginal (block-diagonal approximation), not a joint Schur
  // marginalization over all retained boundary variables.
  auto bp_it = boundary_priors_.end();
  if (cfg_.fixed_lag_en && !boundary_priors_.empty())
  {
    bp_it = boundary_priors_.lower_bound(kfs.front().t - 0.01);
    if (bp_it == boundary_priors_.end() ||
        std::fabs(bp_it->first - kfs.front().t) > 0.01)
      bp_it = boundary_priors_.end();
  }
  const bool have_bp = bp_it != boundary_priors_.end() && bp_it->second.valid;
  if (have_bp)
  {
    const BoundaryPrior &bp = bp_it->second;
    const Eigen::Vector3d p_prior = Rz * (scale * bp.p_world) + tr;
    const gtsam::Pose3 T_prior(gtsam::Rot3(Rz * bp.R_world),
                               gtsam::Point3(p_prior));
    const gtsam::Vector3 v_prior(Rz * bp.v_world);
    const bool have_pose_cov = bp.have_pose_cov;
    const bool have_vel_cov = use_vel && bp.have_vel_cov;
    bool added = false;
    try
    {
      if (have_pose_cov && have_vel_cov)
      {
        // Joint prior preserves P_pose,vel inside the boundary node. The
        // residual is [rot, t_enu, v_enu]; the stored pose covariance is in the
        // GTSAM body tangent, so rotate the position/cross rows by R_enu_body
        // before building the Gaussian noise model.
        const Eigen::Matrix3d R_enu_body = Rz * bp.R_world;
        const Eigen::Matrix<double, 9, 9> Pb =
            boundaryJointCovarianceToEnu(bp.cov_pose, bp.cov_vel,
                                         bp.cov_pose_vel, R_enu_body);
        graph.add(boost::make_shared<BoundaryJointFactor>(
            0, n + 0, T_prior, v_prior,
            gtsam::noiseModel::Gaussian::Covariance(Pb)));
      }
      else
      {
        gtsam::SharedNoiseModel pose_noise =
            have_pose_cov
                ? gtsam::noiseModel::Gaussian::Covariance(bp.cov_pose)
                : noise_pose(cfg_.boundary_sigma_rot,
                             cfg_.boundary_sigma_pos,
                             cfg_.boundary_sigma_pos);
        graph.add(boost::make_shared<gtsam::PriorFactor<gtsam::Pose3>>(
            0, T_prior, pose_noise));
        if (use_vel)
        {
          gtsam::SharedNoiseModel vnoise =
              have_vel_cov
                  ? gtsam::noiseModel::Gaussian::Covariance(bp.cov_vel)
                  : noise_xyz(cfg_.boundary_sigma_vel,
                              cfg_.boundary_sigma_vel,
                              cfg_.boundary_sigma_vel);
          graph.add(boost::make_shared<AbsVelFactor>(n + 0, v_prior, vnoise));
        }
      }
      added = true;
    }
    catch (const std::exception &e)
    {
      std::cerr << "[ONLINE GRAPH] boundary prior rejected: " << e.what()
                << std::endl;
    }
    if (!added)
    {
      // Covariance not SPD or wrong size: fall back to conservative diagonal
      // priors. Never feed a zero covariance to GTSAM.
      graph.add(boost::make_shared<gtsam::PriorFactor<gtsam::Pose3>>(
          0, T_prior,
          noise_pose(cfg_.boundary_sigma_rot, cfg_.boundary_sigma_pos,
                     cfg_.boundary_sigma_pos)));
      if (use_vel)
        graph.add(boost::make_shared<AbsVelFactor>(
            n + 0, v_prior,
            noise_xyz(cfg_.boundary_sigma_vel, cfg_.boundary_sigma_vel,
                      cfg_.boundary_sigma_vel)));
    }
  }

  if (!have_bp && !(member[0] && has_anchor[run_of[0]]))
    add_abs(0, p0[0], noise_xyz(cfg_.fallback_position_sigma,
                               cfg_.fallback_position_sigma,
                               cfg_.fallback_position_sigma));

  // Fix the Pose3 global-orientation gauge. A boundary prior already anchors
  // rotation, so the unary gauge factor is skipped in that case.
  if (!have_bp)
    graph.add(boost::make_shared<AbsRotFactor>(
        0, gtsam::Rot3(Rz * kfs[0].R),
        gtsam::noiseModel::Isotropic::Sigma(3, cfg_.sig_rot_prior)));

  // ---- R4.3 velocity factors ----------------------------------------------
  int vel_used = 0;
  std::vector<std::tuple<int, double, Eigen::Vector3d>> vel_rows;
  if (use_vel)
  {
    for (int i = 0; i + 1 < n; ++i)
    {
      const double dt = std::max(0.1, kfs[i + 1].t - kfs[i].t);
      const double sig = std::max(0.05, cfg_.vel_rw_sigma * std::sqrt(dt));
      graph.add(boost::make_shared<VelDiffFactor>(
          n + i, n + i + 1, noise_xyz(sig, sig, sig)));
      const double motion_dt = kfs[i + 1].t - kfs[i].t;
      if (motion_dt > 1e-6)
      {
        const double sm = std::sqrt(std::max(
            1e-6, cfg_.sig_motion * cfg_.sig_motion +
                      cfg_.motion_accel_psd * motion_dt * motion_dt * motion_dt /
                          3.0));
        graph.add(boost::make_shared<PoseVelFactor>(
            i, i + 1, n + i, n + i + 1, motion_dt,
            noise_xyz(sm, sm, sm)));
      }
    }
    graph.add(boost::make_shared<AbsVelFactor>(
        n + 0, gtsam::Vector3(v0[0]),
        gtsam::noiseModel::Isotropic::Sigma(3, 10.0)));

    for (const Vel &ve : vels)
    {
      if (ve.t < kfs.front().t || ve.t > kfs.back().t) continue;
      const auto it = std::upper_bound(
          kfs.begin(), kfs.end(), ve.t,
          [](double t, const Keyframe &k) { return t < k.t; });
      const int j = static_cast<int>(it - kfs.begin());
      const int i = std::max(0, std::min(n - 2, j - 1));
      const double dt = kfs[i + 1].t - kfs[i].t;
      if (dt <= 1e-6 || dt > cfg_.vel_max_dt) continue;
      const double w = (kfs[i + 1].t - ve.t) / dt;
      if (w < 0.0 || w > 1.0) continue;
      const double sh = std::min(cfg_.vel_sigma_ceil,
                                 std::max(cfg_.vel_sigma_floor,
                                          ve.sigma_h > 0.0 ? ve.sigma_h
                                                           : cfg_.vel_sigma_floor));
      const double sv = std::min(cfg_.vel_sigma_ceil,
                                 std::max(cfg_.vel_sigma_floor,
                                          ve.sigma_v > 0.0 ? ve.sigma_v
                                                           : cfg_.vel_sigma_floor));
      graph.add(boost::make_shared<InterpVelFactor>(
          n + i, n + i + 1, w, gtsam::Vector3(ve.v),
          noise_xyz(sh, sh, sv)));
      vel_rows.emplace_back(i, w, ve.v);
      ++vel_used;
    }
  }

  gtsam::Values values;
  for (int i = 0; i < n; ++i)
    values.insert(i, T0[i]);
  if (use_vel)
    for (int i = 0; i < n; ++i)
      values.insert(n + i, gtsam::Vector3(v0[i]));
  const auto t0 = std::chrono::steady_clock::now();
  gtsam::LevenbergMarquardtOptimizer opt(graph, values);
  const gtsam::Values result = opt.optimize();
  const auto t1 = std::chrono::steady_clock::now();
  const double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();

  // Read actual factor models after solving. This is a final linearization
  // diagnostic, not a history of intermediate LM/IRLS iterations.
  if (!cfg_.anchor_trace_path.empty()) {
    const std::string path = cfg_.anchor_trace_path + ".factors.csv";
    std::ofstream trace(path + ".tmp", std::ios::trunc);
    trace << std::setprecision(17)
          << "solve_stamp,factor_index,kind,keys,fix_stamp,dim,sigmas,robust,block_weight,base_white_norm,objective,fit_rms,base_sig_odom,base_sig_rtk_xy\n";
    for (size_t k=0;k<graph.size();++k) {
      auto factor=boost::dynamic_pointer_cast<gtsam::NoiseModelFactor>(graph[k]);
      if (!factor) continue;
      auto base=factor->noiseModel();
      auto robust=boost::dynamic_pointer_cast<gtsam::noiseModel::Robust>(base);
      if (robust) base=robust->noise();
      const auto diagonal=boost::dynamic_pointer_cast<gtsam::noiseModel::Diagonal>(base);
      const gtsam::Vector white=base->whiten(factor->unwhitenedError(result));
      double weight=1.;
      if (robust) weight=robust->robust()->reweightScheme()==gtsam::noiseModel::mEstimator::Base::Block
          ? robust->robust()->weight(white.norm()) : std::numeric_limits<double>::quiet_NaN();
      std::string kind=typeid(*factor).name();
      if (boost::dynamic_pointer_cast<InterpolatedAbsPosFactor>(factor)) kind="gnss_interpolated";
      else if (boost::dynamic_pointer_cast<gtsam::BetweenFactor<gtsam::Pose3>>(factor)) kind="pose_between";
      else if (boost::dynamic_pointer_cast<AbsPosFactor>(factor)) kind="absolute_position";
      else if (boost::dynamic_pointer_cast<RelPosFactor>(factor)) kind="relative_position";
      else if (boost::dynamic_pointer_cast<AbsRotFactor>(factor)) kind="orientation_prior";
      trace << t1kf << ',' << k << ',' << kind << ',';
      for (size_t j=0;j<factor->keys().size();++j) trace << (j?";":"") << factor->keys()[j];
      trace << ',';
      if (factor_fix_stamp.count(k)) trace << factor_fix_stamp[k];
      trace << ',' << white.size() << ',';
      if (diagonal) for (int j=0;j<diagonal->sigmas().size();++j) trace << (j?";":"") << diagonal->sigmas()[j];
      trace << ',' << bool(robust) << ',' << weight << ',' << white.norm()
            << ',' << factor->error(result) << ',' << fit_rms << ',' << sig_odom << ',' << sig_rtk_xy << '\n';
    }
    trace.close();
    if (trace) std::rename((path+".tmp").c_str(),path.c_str());
  }

  double vel_sq = 0.0;
  for (const auto &row : vel_rows)
  {
    const int i = std::get<0>(row);
    const double w = std::get<1>(row);
    const gtsam::Vector3 vi = result.at<gtsam::Vector3>(n + i);
    const gtsam::Vector3 vj = result.at<gtsam::Vector3>(n + i + 1);
    vel_sq += (w * vi + (1.0 - w) * vj - gtsam::Vector3(std::get<2>(row)))
                  .squaredNorm();
  }
  const double vel_rms =
      vel_used > 0 ? std::sqrt(vel_sq / static_cast<double>(vel_used)) : 0.0;
  // P0 smoke/health line: the status topic carries the same fields, but this
  // makes an unattended run greppable even when rosbag/roslaunch is killed.
  std::cout << "[ONLINE GRAPH] t=" << std::fixed << std::setprecision(1)
            << kfs.back().t << " n=" << n << " rtk=" << rtk_used
            << " rtk_i=" << rtk_interp_used
            << " rtk_skip_static=" << rtk_skip_static
            << " rtk_skip_quality=" << rtk_skip_quality
            << " rtk_skip_assoc=" << rtk_skip_assoc
            << " rtk_skip_class=" << rtk_skip_class
            << " rtk_innov=" << rtk_innov_rejected
            << " rtk_innov_invalid=" << rtk_innov_invalid
            << " rtk_pre=" << rtk_pre_rejected
            << " tddd=" << tddd_used << " dd_epochs=" << dds.size()
            << " vel=" << vel_used << " vel_rms=" << std::setprecision(3)
            << vel_rms
            << " tshift=" << std::setprecision(3) << tddd_shift
            << " scale=" << std::setprecision(5) << scale
            << " frame=" << (have_frontend_frame ? 1 : 0)
            << " yaw=" << std::setprecision(3)
            << (std::atan2(Rz(1, 0), Rz(0, 0)) * 57.295779513082323)
            << " tr=" << tr.x() << "," << tr.y() << "," << tr.z()
            << " w_rtk=" << std::setprecision(3)
            << (w_n > 0 ? w_sum / w_n : 1.0)
            << " fit=" << std::setprecision(3) << fit_rms
            << " fit_pass=" << fit_diag.applied_pass
            << " fit_n=" << fit_diag.n_total
            << " fit_acc=" << fit_diag.n_accepted
            << " fit_s1=" << std::setprecision(5) << fit_diag.scale1
            << " fit_s2=" << std::setprecision(5) << fit_diag.scale2
            << " fit_y1=" << std::setprecision(3) << fit_diag.yaw1
            << " fit_y2=" << std::setprecision(3) << fit_diag.yaw2
            << " fit_r1=" << std::setprecision(3) << fit_diag.rms1
            << " fit_r2=" << std::setprecision(3) << fit_diag.rms2
            << " fit_ra1=" << std::setprecision(3) << fit_diag.rms1_accepted
            << " fit_fb="
            << (fit_diag.fallback.empty() ? "none" : fit_diag.fallback)
            << " bp=" << (have_bp ? 1 : 0)
            << " ms=" << std::setprecision(1) << ms << std::endl;

  Result res;
  res.valid = true;
  res.stamp = kfs.back().t;
  res.solve_ms = ms;
  res.keyframes = n;
  res.total_keyframes = total_keyframes_.load();
  res.window_slid = res.total_keyframes > cfg_.window;
  res.fixes = static_cast<int>(fx.size());
  res.rtk_used = rtk_used;
  res.rejected_fixes = rejected_fixes_.load();
  res.Rz = Rz;
  res.tr = tr;
  res.scale = scale;
  res.nodes.clear();
  res.nodes.reserve(n);
  for (int i = 0; i < n; ++i)
  {
    const gtsam::Pose3 T = result.at<gtsam::Pose3>(i);
    Keyframe node;
    node.t = kfs[i].t;
    node.p = T.translation();
    // Result.Rz is ENU<-world and consumers compute Rz*node.R, so node.R stays
    // body->world; convert the optimized body->ENU rotation back.
    node.R = Rz.transpose() * T.rotation().matrix();
    if (use_vel) node.v = result.at<gtsam::Vector3>(n + i);
    node.p_in = kfs[i].p;
    node.lambda_min = kfs[i].lambda_min;
    res.nodes.push_back(node);
  }

  // R4.4b: store the single-node marginal of the next few keyframes. The one
  // that becomes the new window boundary after the next drop will be used as a
  // prior in the following solve. World-frame storage survives ENU re-fits.
  std::vector<std::pair<double, BoundaryPrior>> new_bps;
  if (cfg_.fixed_lag_en && n > 3)
  {
    for (int i = 1; i <= std::min(3, n - 1); ++i)
    {
      BoundaryPrior bp;
      bp.valid = true;
      bp.R_world = res.nodes[i].R;  // already body->world
      bp.p_world = Rz.transpose() * (res.nodes[i].p - tr) / std::max(scale, 1e-6);
      bp.v_world = Rz.transpose() * res.nodes[i].v;
      new_bps.emplace_back(res.nodes[i].t, bp);
    }
  }

  // R4.4: true marginal posterior of the latest pose (and velocity). GTSAM's
  // Pose3 tangent order is [rotation, translation]; ROS PoseWithCovariance uses
  // [x,y,z,roll,pitch,yaw], so the two diagonal blocks are swapped.
  if (cfg_.cov_en && n > 0)
  {
    try
    {
      gtsam::Marginals marginals(graph, result);
      const Eigen::Matrix<double, 6, 6> cov =
          marginals.marginalCovariance(n - 1);
      if (cov.allFinite())
      {
        // GTSAM local/body tangent -> ENU PoseWithCovariance. Rotating both
        // blocks (and the cross terms) is required; a bare block swap leaves
        // the covariance in the body frame and is wrong for a moving/turning
        // platform.
        const Eigen::Matrix3d R_enu_body = res.Rz * res.nodes.back().R;
        res.cov_pose = poseCovarianceToEnu(cov, R_enu_body);
        res.cov_valid = true;
      }
      if (use_vel)
      {
        const Eigen::Matrix<double, 3, 3> cv =
            marginals.marginalCovariance(n + n - 1);
        if (cv.allFinite()) res.cov_vel = cv;
      }
      for (size_t k = 0; k < new_bps.size(); ++k)
      {
        const int i = static_cast<int>(k) + 1;
        try
        {
          if (use_vel)
          {
            // Joint marginal keeps P_pose,vel, which the boundary joint factor
            // needs. Separate marginalCovariance calls would drop it.
            gtsam::KeyVector keys;
            keys.push_back(i);
            keys.push_back(n + i);
            const gtsam::JointMarginal joint =
                marginals.jointMarginalCovariance(keys);
            new_bps[k].second.cov_pose = joint(i, i);
            new_bps[k].second.cov_vel = joint(n + i, n + i);
            new_bps[k].second.cov_pose_vel = joint(i, n + i);
            new_bps[k].second.have_pose_cov =
                new_bps[k].second.cov_pose.allFinite();
            new_bps[k].second.have_vel_cov =
                new_bps[k].second.cov_vel.allFinite();
            if (!new_bps[k].second.have_pose_cov ||
                !new_bps[k].second.have_vel_cov)
              new_bps[k].second.cov_pose_vel.setZero();
          }
          else
          {
            new_bps[k].second.cov_pose = marginals.marginalCovariance(i);
            new_bps[k].second.have_pose_cov =
                new_bps[k].second.cov_pose.allFinite();
            new_bps[k].second.have_vel_cov = false;
          }
        }
        catch (const std::exception &)
        {
          new_bps[k].second.have_pose_cov = false;
          new_bps[k].second.have_vel_cov = false;
        }
      }
    }
    catch (const std::exception &e)
    {
      if (cfg_.window <= 200)
        std::cerr << "[ONLINE GRAPH] marginal covariance failed: " << e.what()
                  << std::endl;
    }
  }
  if (cfg_.fixed_lag_en && !new_bps.empty())
  {
    for (const auto &kv : new_bps) boundary_priors_[kv.first] = kv.second;
    while (boundary_priors_.size() > 20) boundary_priors_.erase(boundary_priors_.begin());
  }
  if (cfg_.cov_en)
  {
    std::cout << "[ONLINE GRAPH] cov valid=" << (res.cov_valid ? 1 : 0)
              << " sig_xy=" << std::setprecision(4)
              << std::sqrt(std::max(0.0, 0.5 * (res.cov_pose(0, 0) + res.cov_pose(1, 1))))
              << " sig_z=" << std::sqrt(std::max(0.0, res.cov_pose(2, 2)))
              << " sig_yaw_deg="
              << std::sqrt(std::max(0.0, res.cov_pose(5, 5))) * 57.295779513082323
              << " sig_vel=" << std::sqrt(std::max(0.0, res.cov_vel(0, 0)))
              << std::endl;
  }
  const auto result_ready = std::chrono::steady_clock::now();
  {
    std::lock_guard<std::mutex> lk(result_mtx_);
    res.seq = ++result_seq_;
    latest_ = res;
  }

  if (!cfg_.output_path.empty())
  {
    const std::string tmp = cfg_.output_path + ".tmp";
    std::ofstream f(tmp, std::ios::out | std::ios::trunc);
    if (f.is_open())
    {
      f << std::setprecision(12);
      for (int i = 0; i < n; ++i)
      {
        const gtsam::Pose3 T = result.at<gtsam::Pose3>(i);
        const Eigen::Matrix3d R_world = Rz.transpose() * T.rotation().matrix();
        Eigen::Quaterniond quat(R_world);
        f << kfs[i].t << " " << T.x() << " " << T.y() << " " << T.z()
          << " " << quat.x() << " " << quat.y() << " " << quat.z()
          << " " << quat.w() << "\n";
      }
      f.close();
      if (std::rename(tmp.c_str(), cfg_.output_path.c_str()) != 0)
        std::remove(tmp.c_str());
    }
  }

  // R0: one watermark record per completed solve. A harness waits until the
  // last received fix stamp appears here (received AND consumed by a finished
  // solve) before shutting the node down; the final receive summary is written
  // from stop().
  if (wm_stream_.is_open())
  {
    const auto ns = [](std::chrono::steady_clock::time_point t) {
      return std::chrono::duration_cast<std::chrono::nanoseconds>(
          t.time_since_epoch()).count();
    };
    const int last_fit = nfit - 1;
    const int fa = bracket_en ? fit_bracket[last_fit].first : -1;
    const int fb = bracket_en ? fit_bracket[last_fit].second : -1;
    wm_stream_ << "{\"solve_seq\":" << solve_seq_.fetch_add(1)
               << ",\"solve_stamp\":" << t1kf
               << ",\"result_seq\":" << res.seq
               << ",\"snapshot_monotonic_ns\":" << wm_snap.snapshot_monotonic_ns
               << ",\"optimizer_start_monotonic_ns\":" << ns(t0)
               << ",\"optimizer_end_monotonic_ns\":" << ns(t1)
               << ",\"result_ready_monotonic_ns\":" << ns(result_ready)
               << ",\"watermark_monotonic_ns\":" << ns(std::chrono::steady_clock::now())
               << ",\"n_kf\":" << n
               << ",\"kf_first\":" << t0kf
               << ",\"kf_last\":" << t1kf
               << ",\"n_fix_snapshot\":" << fx.size()
               << ",\"fix_first\":" << fx.front().t
               << ",\"fix_last\":" << fx.back().t
               << ",\"kf_buffer\":" << wm_kf_buffer
               << ",\"fix_buffer\":" << wm_fix_buffer
               << ",\"received_kf\":" << wm_received_kf
               << ",\"received_fix\":" << wm_received_fix
               << ",\"last_kf_received\":" << wm_last_kf
               << ",\"last_fix_received\":" << wm_last_fix
               << ",\"fit_n\":" << nfit
               << ",\"fit_bracket_rejected\":" << fit_bracket_rejected
               << ",\"fit_quality_rejected\":" << fit_quality_rejected
               << ",\"fit_first\":" << fit_t.front()
               << ",\"fit_last\":" << fit_t.back()
               << ",\"fit_last_endpoints\":["
               << (fa >= 0 ? fx[fa].t : 0.0) << ','
               << (fb >= 0 ? fx[fb].t : 0.0) << "]}\n";
    wm_stream_.flush();
  }

  {
    std::lock_guard<std::mutex> lk(stats_mtx_);
    stats_.last_solve_ms = ms;
    stats_.last_result_stamp = res.stamp;
    stats_.result_seq = res.seq;
    stats_.keyframes = n;
    stats_.total_keyframes = res.total_keyframes;
    stats_.window_slid = res.window_slid;
    stats_.oldest_stamp = kfs.front().t;
    stats_.newest_stamp = kfs.back().t;
    stats_.fixes = static_cast<int>(fx.size());
    stats_.rtk_used = rtk_used;
    stats_.rtk_interp_used = rtk_interp_used;
    stats_.rtk_skip_static = rtk_skip_static;
    stats_.rtk_skip_quality = rtk_skip_quality;
    stats_.rtk_skip_assoc = rtk_skip_assoc;
    stats_.rtk_skip_class = rtk_skip_class;
    stats_.rtk_innov_rejected = rtk_innov_rejected;
    stats_.rtk_innov_invalid = rtk_innov_invalid;
    stats_.fit = fit_diag;
    stats_.rtk_pre_rejected = rtk_pre_rejected;
    stats_.rejected_fixes = res.rejected_fixes;
    stats_.solves++;
    stats_.status = 1;
    stats_.tddd_used = tddd_used;
    stats_.dd_epochs = static_cast<int>(dds.size());
    stats_.vel_used = vel_used;
    stats_.vel_rms = vel_rms;
    stats_.marginalized = have_bp ? 1 : 0;
    stats_.scale = scale;
    stats_.w_rtk_med = w_n > 0 ? w_sum / w_n : 1.0;
  }
}

}  // namespace fast_livo
