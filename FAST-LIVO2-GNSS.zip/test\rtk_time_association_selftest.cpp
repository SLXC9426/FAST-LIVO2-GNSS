/*
A1 self-test: RTK epoch <-> keyframe time association.

The A0 backend assigns one unique nearest fix per keyframe. A1 instead brackets
every RTK epoch between the two keyframes that surround it, so the factor can be
evaluated at the epoch's own time. These tests pin the association contract:

  - an epoch exactly on a keyframe is valid with alpha 0 or 1;
  - a midpoint epoch gets alpha 0.5 and the correct pair;
  - epochs outside [first, last] keyframe are rejected (no extrapolation);
  - extrapolation is opt-in and limited by max_extrapolation;
  - non-increasing keyframe times reject the whole batch;
  - over-wide brackets and alpha outside [min_alpha, max_alpha] are rejected;
  - duplicate publications produce one factor at most;
  - every fix index appears at most once and the output stays index-aligned.

Run:
  catkin_make --pkg fast_livo
  ./devel/lib/fast_livo/rtk_time_association_selftest

Exit code 0 = all checks pass, 1 = failure.
*/

#include "rtk_time_association.h"

#include <cmath>
#include <cstdio>
#include <string>
#include <vector>

namespace
{

int g_failures = 0;

void check(const std::string &name, bool ok, const std::string &detail = "")
{
  std::printf("%s  %-52s %s\n", ok ? "ok  " : "FAIL", name.c_str(),
              detail.c_str());
  if (!ok) ++g_failures;
}

bool near(double a, double b, double tol = 1e-9) { return std::fabs(a - b) <= tol; }

std::vector<double> v(std::initializer_list<double> x) { return std::vector<double>(x); }

// Every fix produces exactly one output row, in input order, with fix_index
// equal to its position. This is what lets the caller trace each epoch.
void checkAlignment(const std::vector<fast_livo::FixAssociation> &out,
                    const std::vector<double> &fix_t)
{
  bool ok = out.size() == fix_t.size();
  for (size_t k = 0; ok && k < out.size(); ++k)
    ok = out[k].fix_index == static_cast<int>(k);
  check("output is index-aligned with the fix list", ok);
}

}  // namespace

int main()
{
  using fast_livo::associateRtkEpochs;
  using fast_livo::FixAssocStatus;
  using fast_livo::RtkInterpParams;

  RtkInterpParams def;  // max_bracket_dt 1.5, no extrapolation

  // ---- exact keyframe times and regular midpoints -------------------------
  {
    const std::vector<double> kf = v({0.0, 1.0, 2.0, 3.0});
    const std::vector<double> fx = v({0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    checkAlignment(out, fx);
    check("regular train: all 7 epochs valid", n == 7 && out.size() == 7);
    bool ok = true;
    for (const auto &a : out) ok = ok && a.valid && a.status == FixAssocStatus::OK;
    check("regular train: every row OK", ok);
    ok = near(out[0].alpha, 0.0) && out[0].key_i == 0 && out[0].key_j == 1;
    check("epoch on first keyframe -> alpha 0, pair (0,1)", ok);
    ok = near(out[1].alpha, 0.5) && out[1].key_i == 0 && out[1].key_j == 1;
    check("midpoint -> alpha 0.5, pair (0,1)", ok);
    ok = near(out[2].alpha, 1.0) && out[2].key_i == 0 && out[2].key_j == 1;
    check("epoch on keyframe 1 -> alpha 1 in pair (0,1)", ok);
    ok = near(out[3].alpha, 0.5) && out[3].key_i == 1 && out[3].key_j == 2;
    check("next midpoint -> pair (1,2)", ok);
    ok = near(out[6].alpha, 1.0) && out[6].key_i == 2 && out[6].key_j == 3;
    check("epoch on last keyframe -> alpha 1 in pair (2,3)", ok);
  }

  // ---- irregular keyframe spacing ----------------------------------------
  {
    const std::vector<double> kf = v({0.0, 0.3, 1.4, 1.5});
    const std::vector<double> fx = v({0.9});
    std::vector<fast_livo::FixAssociation> out;
    associateRtkEpochs(kf, fx, def, out);
    const double want = (0.9 - 0.3) / (1.4 - 0.3);
    check("irregular spacing: alpha uses the bracket span",
          out.size() == 1 && out[0].valid && out[0].key_i == 1 &&
              out[0].key_j == 2 && near(out[0].alpha, want, 1e-12),
          "alpha=" + std::to_string(out[0].alpha));
  }

  // ---- no extrapolation by default ---------------------------------------
  {
    const std::vector<double> kf = v({0.0, 1.0, 2.0});
    const std::vector<double> fx = v({-0.1, 2.1});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    checkAlignment(out, fx);
    check("epochs outside range rejected",
          n == 0 && out.size() == 2 &&
              out[0].status == FixAssocStatus::BEFORE_RANGE &&
              out[1].status == FixAssocStatus::AFTER_RANGE);
  }

  // ---- opt-in extrapolation ----------------------------------------------
  {
    RtkInterpParams p;
    p.max_extrapolation = 0.25;
    const std::vector<double> kf = v({0.0, 1.0, 2.0});
    const std::vector<double> fx = v({-0.2, 2.2, 2.3});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, p, out);
    check("extrapolation within limit accepted, beyond limit rejected",
          n == 2 && out[0].valid && near(out[0].alpha, -0.2) &&
              out[1].valid && near(out[1].alpha, 1.2) &&
              out[2].status == FixAssocStatus::AFTER_RANGE);
  }

  // ---- bracket span limit -------------------------------------------------
  {
    const std::vector<double> kf = v({0.0, 2.0, 3.0});
    const std::vector<double> fx = v({1.0});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    check("2 s bracket with 1.5 s limit rejected",
          n == 0 && out.size() == 1 &&
              out[0].status == FixAssocStatus::BRACKET_TOO_WIDE);
  }

  // ---- non-increasing keyframe times -------------------------------------
  {
    const std::vector<double> kf = v({0.0, 1.0, 0.5, 2.0});
    const std::vector<double> fx = v({0.7, 1.2});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    checkAlignment(out, fx);
    bool all_bad = true;
    for (const auto &a : out) all_bad = all_bad && !a.valid &&
                                               a.status == FixAssocStatus::BAD_KEYFRAME_TIME;
    check("non-monotonic keyframe time rejects the batch", n == 0 && all_bad);
  }

  // ---- duplicate epoch publication ---------------------------------------
  {
    const std::vector<double> kf = v({0.0, 1.0, 2.0});
    const std::vector<double> fx = v({0.5, 0.5, 0.6});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    checkAlignment(out, fx);
    check("duplicate epoch yields one factor",
          n == 2 && out[0].valid && out[1].status == FixAssocStatus::DUPLICATE_EPOCH &&
              !out[1].valid && out[2].valid);
  }

  // ---- alpha bounds -------------------------------------------------------
  {
    RtkInterpParams p;
    p.min_alpha = 0.25;
    p.max_alpha = 0.75;
    const std::vector<double> kf = v({0.0, 1.0, 2.0});
    const std::vector<double> fx = v({0.1, 0.5, 0.9});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, p, out);
    check("alpha bounds reject epochs hugging the keyframes",
          n == 1 && out[0].status == FixAssocStatus::ALPHA_OUT_OF_RANGE &&
              out[1].valid && out[2].status == FixAssocStatus::ALPHA_OUT_OF_RANGE);
  }

  // ---- no fix is used twice ----------------------------------------------
  {
    const std::vector<double> kf = v({0.0, 1.0, 2.0, 3.0});
    const std::vector<double> fx = v({0.2, 0.4, 0.6, 0.8, 1.2, 1.4, 1.6, 1.8,
                                      2.2, 2.4, 2.6, 2.8});
    std::vector<fast_livo::FixAssociation> out;
    const size_t n = associateRtkEpochs(kf, fx, def, out);
    std::vector<int> used(fx.size(), 0);
    bool unique = true;
    size_t counted = 0;
    for (const auto &a : out)
      if (a.valid)
      {
        if (a.fix_index >= 0 && a.fix_index < static_cast<int>(used.size()))
          ++used[a.fix_index];
        ++counted;
      }
    for (int u : used) unique = unique && u <= 1;
    check("every RTK epoch feeds at most one factor",
          unique && counted == n);
  }

  // ---- bracket lookup (used by the nearest-placement ablation arm) --------
  {
    const std::vector<double> kf = v({0.0, 1.0, 2.0, 2.5});
    bool ok = fast_livo::findKeyframeBracket(kf, 0.0) == 0 &&
              fast_livo::findKeyframeBracket(kf, 0.5) == 0 &&
              fast_livo::findKeyframeBracket(kf, 1.0) == 0 &&
              fast_livo::findKeyframeBracket(kf, 1.2) == 1 &&
              fast_livo::findKeyframeBracket(kf, 2.4) == 2 &&
              fast_livo::findKeyframeBracket(kf, 2.5) == 2;
    check("bracket lookup returns the containing interval", ok);
    check("bracket lookup rejects times outside the span",
          fast_livo::findKeyframeBracket(kf, -0.1) == -1 &&
              fast_livo::findKeyframeBracket(kf, 2.6) == -1);
    check("bracket lookup rejects non-monotonic keyframes",
          fast_livo::findKeyframeBracket(v({0.0, 1.0, 0.5}), 0.7) == -1);
    check("pre-rejected status has a name",
          std::string(fast_livo::fixAssocStatusName(
              FixAssocStatus::PRE_REJECTED)) == "pre_rejected");
  }

  // ---- degenerate inputs --------------------------------------------------
  {
    std::vector<fast_livo::FixAssociation> out;
    check("one keyframe -> nothing",
          associateRtkEpochs(v({0.0}), v({0.0}), def, out) == 0 && out.empty());
    check("no fixes -> nothing",
          associateRtkEpochs(v({0.0, 1.0}), v({}), def, out) == 0 && out.empty());
  }

  if (g_failures == 0)
  {
    std::printf("\nPASS: RTK epoch <-> keyframe time association\n");
    return 0;
  }
  std::printf("\nFAIL: %d check(s) failed\n", g_failures);
  return 1;
}
