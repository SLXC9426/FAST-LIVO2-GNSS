#!/usr/bin/env python3
import rosbag
import numpy as np
import sensor_msgs.point_cloud2 as pc2

b = rosbag.Bag("/home/slxc9426/datasets/GREAT/GREAT.bag")
n = 0
for topic, msg, t in b.read_messages(topics=["/points_raw"]):
    n += 1
    if n > 8:
        break
    pts = list(pc2.read_points(msg, field_names=("time", "ring"), skip_nans=True))
    a = np.array(pts, dtype=float)
    print("frame %d stamp %.3f npts %d time %.1f ~ %.1f us (%.1f ms)" %
          (n, msg.header.stamp.to_sec(), len(a), a[:, 0].min(), a[:, 0].max(), (a[:, 0].max() - a[:, 0].min()) / 1000.0))
b.close()
