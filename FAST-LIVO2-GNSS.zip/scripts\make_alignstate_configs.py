#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Derive the T1-4 alignment-state A/B configs (docs/T1_4_DESIGN.md).

Single knob per arm: gnss/align_state_en = true. Everything else is
byte-identical to the main config; the sub-parameters (q_pos, q_yaw_deg,
sigma_yaw0_deg, clamps) keep the readParameters defaults unless a Q-calibration
arm overrides them (see make_alignstate_q_configs variant below).

Enabling the state also disables the FORCED early lock (LIVMapper.cpp), which
is part of the review-fixed design, not a separate knob.

Usage:  make_alignstate_configs.py
Writes  config/great_campus0X_alignstate.yaml
"""
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))

BLOCK = """\
{i}# T1-4 (docs/T1_4_DESIGN.md): slow-varying alignment state. The ENU->world
{i}# yaw + horizontal translation become a slow random-walk state co-estimated
{i}# from the GNSS innovations after the Procrustes lock (single knob, all other
{i}# settings byte-identical; enabling also disables the FORCED early lock).
{i}# [GNSS] align: log lines carry the convergence trace.
{i}align_state_en: true
"""

TARGETS = [
    "great_campus01.yaml",
    "great_campus02.yaml",
    "great_campus03.yaml",
]


def derive(base_name, out_name, extra=""):
    base = os.path.join(HERE, os.pardir, "config", base_name)
    with open(base, encoding="utf-8") as fh:
        lines = fh.readlines()

    out = []
    inserted = False
    key_re = re.compile(r"^(\s*)outlier_rejection:")
    for ln in lines:
        m = key_re.match(ln)
        if m and not inserted:
            indent = m.group(1)
            out.append(BLOCK.format(i=indent))
            if extra:
                out.append(extra.format(i=indent))
            inserted = True
        out.append(ln)
    if not inserted:
        sys.exit("anchor line 'outlier_rejection:' not found in %s" % base)

    dst = os.path.join(HERE, os.pardir, "config", out_name)
    with open(dst, "w", encoding="utf-8", newline="\n") as fh:
        fh.writelines(out)
    print("wrote %s (from %s)" % (os.path.normpath(dst), base_name))


if __name__ == "__main__":
    for base in TARGETS:
        derive(base, base.replace(".yaml", "_alignstate.yaml"))

    # Q-calibration arms for c01 (review 10.2 sweep {x1, x3, x10}; tau ~ 1/q,
    # the information is in the upper arm). x1 IS the base alignstate config.
    q3 = ("{i}# T1-4 Q calibration arm x3 (tau ~ 1/q; sweep per T1_4_DESIGN 4)\n"
          "{i}align_q_pos: 0.03\n"
          "{i}align_q_yaw_deg: 0.15\n")
    q10 = ("{i}# T1-4 Q calibration arm x10\n"
           "{i}align_q_pos: 0.1\n"
           "{i}align_q_yaw_deg: 0.5\n")
    derive("great_campus01.yaml", "great_campus01_alignstate_q3.yaml", q3)
    derive("great_campus01.yaml", "great_campus01_alignstate_q10.yaml", q10)
