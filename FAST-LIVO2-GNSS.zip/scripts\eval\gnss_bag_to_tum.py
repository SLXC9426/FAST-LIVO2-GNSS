#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert a NavSatFix topic in a rosbag to an ENU TUM trajectory.

Used to evaluate the GNSS observations themselves (single-epoch RTK solution)
against the reference, with the same ENU convention and the same
eval_unified.py alignment as the estimator trajectories. Without this, a fusion
result cannot be judged: if the input fixes are already metres off, no filter
can beat that, and a "no gain" outcome is the correct behaviour.

ENU origin = first fix of the selected window (same recipe as the reference
conversion, see the project notes). Times are absolute UNIX seconds, matching
the reference TUM time base, so eval_unified.py can pair them.

Usage:
  gnss_bag_to_tum.py <bag> <topic> <out.tum> [--start S] [--dur D]
"""
import sys, math
import rosbag

A = 6378137.0
F = 1.0 / 298.257223563
E2 = F * (2.0 - F)


def lla2ecef(lat, lon, h):
    lat, lon = math.radians(lat), math.radians(lon)
    N = A / math.sqrt(1 - E2 * math.sin(lat) ** 2)
    x = (N + h) * math.cos(lat) * math.cos(lon)
    y = (N + h) * math.cos(lat) * math.sin(lon)
    z = (N * (1 - E2) + h) * math.sin(lat)
    return x, y, z


def main():
    a = sys.argv[1:]
    if len(a) < 3:
        print(__doc__)
        return 1
    bag_path, topic, out = a[0], a[1], a[2]
    start, dur = 0.0, None
    i = 3
    while i < len(a):
        if a[i] == "--start":
            start = float(a[i + 1]); i += 2
        elif a[i] == "--dur":
            dur = float(a[i + 1]); i += 2
        else:
            i += 1

    fixes = []
    with rosbag.Bag(bag_path) as b:
        t0 = None
        for _, msg, _ in b.read_messages(topics=[topic]):
            t = msg.header.stamp.to_sec()
            if t0 is None:
                t0 = t
            if t < t0 + start:
                continue
            if dur is not None and t > t0 + start + dur:
                break
            fixes.append((t, msg.latitude, msg.longitude, msg.altitude))

    if len(fixes) < 2:
        print("!! only %d fixes on %s" % (len(fixes), topic))
        return 1

    lat0, lon0 = math.radians(fixes[0][1]), math.radians(fixes[0][2])
    x0, y0, z0 = lla2ecef(fixes[0][1], fixes[0][2], fixes[0][3])
    lines = []
    for t, la, lo, h in fixes:
        x, y, z = lla2ecef(la, lo, h)
        dx, dy, dz = x - x0, y - y0, z - z0
        e = -math.sin(lon0) * dx + math.cos(lon0) * dy
        n = (-math.sin(lat0) * math.cos(lon0) * dx
             - math.sin(lat0) * math.sin(lon0) * dy + math.cos(lat0) * dz)
        u = (math.cos(lat0) * math.cos(lon0) * dx
             + math.cos(lat0) * math.sin(lon0) * dy + math.sin(lat0) * dz)
        lines.append("%.6f %.4f %.4f %.4f 0.0 0.0 0.0 1.0" % (t, e, n, u))

    with open(out, "w") as f:
        f.write("\n".join(lines) + "\n")

    span = fixes[-1][0] - fixes[0][0]
    print("wrote %s: %d fixes, t %.3f..%.3f (span %.1fs, %.2f Hz)"
          % (out, len(fixes), fixes[0][0], fixes[-1][0], span, len(fixes) / max(span, 1e-9)))
    return 0


if __name__ == "__main__":
    sys.exit(main())
