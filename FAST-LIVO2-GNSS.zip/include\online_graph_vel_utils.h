#ifndef ONLINE_GRAPH_VEL_UTILS_H
#define ONLINE_GRAPH_VEL_UTILS_H

// R5.5: single place where a velocity epoch is converted into the message the
// online graph consumes. The header stamp must be the ADJUSTED time
// (raw - gnss_vel_time_offset), because the graph interpolates velocity nodes
// by this stamp. Keeping this in a free function makes the offset testable.

#include <fast_livo/OnlineGraphVel.h>
#include <ros/ros.h>

#include <Eigen/Dense>
#include <string>

namespace fast_livo
{

inline OnlineGraphVel makeOnlineGraphVelMsg(
    double raw_stamp, double time_offset, const Eigen::Vector3d &vel_enu,
    double sigma_h, double sigma_v, const std::string &source)
{
  OnlineGraphVel out;
  out.header.stamp = ros::Time().fromSec(raw_stamp - time_offset);
  out.header.frame_id = "enu";
  out.vel_enu.x = vel_enu.x();
  out.vel_enu.y = vel_enu.y();
  out.vel_enu.z = vel_enu.z();
  out.sigma_h = sigma_h;
  out.sigma_v = sigma_v;
  out.source = source;
  return out;
}

}  // namespace fast_livo

#endif  // ONLINE_GRAPH_VEL_UTILS_H
