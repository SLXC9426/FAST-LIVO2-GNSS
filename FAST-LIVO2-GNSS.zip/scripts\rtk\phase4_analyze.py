#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Phase 4: three-arm N=3 summary and per-segment metrics.

Reads the registry and TUM trajectories, aligns every run to the reference with
SE(3) Umeyama (same convention as eval_unified.py), and writes:
  metrics/phase4_runs.csv
  metrics/phase4_summary.csv
  metrics/phase4_segments.csv
  metrics/phase4_deltas.csv
  figures/data/<arm>_<tag>_aligned.csv   (representative runs, for plotting)
"""
import csv
import os
import statistics

import numpy as np

TUM_DIR = "/home/slxc9426/catkin_ws/src/fast_livo/Log/result"
REF = "/home/slxc9426/eval_great/campus01_reference.tum"
REG = "/home/slxc9426/catkin_ws/src/fast_livo/Log/result/registry.csv"
OUT = "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/02_评估结果/rtk_tight_eval"
MET = os.path.join(OUT, "metrics")
FIGD = os.path.join(OUT, "figures", "data")

ARMS = {
    "LIVO": ["phase4_c01_livo_r1", "phase4_c01_livo_r2", "phase4_c01_livo_r3"],
    "RTK tight": ["phase4_c01_tight_r1", "phase4_c01_tight_r2", "phase4_c01_tight_r3"],
    "RTK robust": ["phase3_c01_rtk_robust_full1",
                   "phase4_c01_robust_r2", "phase4_c01_robust_r3"],
}
METRICS = [
    ("r3_full", "full_3D"), ("r2_full", "full_2D"),
    ("r3_steady", "steady_3D"), ("r2_steady", "steady_2D"),
    ("rpe1", "RPE_1s"), ("rpe10", "RPE_10s"),
    ("rpe60", "RPE_60s"), ("rpe120", "RPE_120s"),
    ("r2_statloc", "static_loc_2D"),
]
SEGMENTS = [
    ("convergence_0_79", 0.0, 79.0),
    ("multipath_79_201", 79.0, 201.0),
    ("recovery_201_300", 201.0, 300.0),
    ("steady_300_603", 300.0, 603.0),
    ("full_0_603", 0.0, 603.0),
]


def load_tum(path):
    t, x = [], []
    with open(path, encoding="utf-8", errors="replace") as f:
        for line in f:
            q = line.split()
            if len(q) >= 4:
                try:
                    t.append(float(q[0]))
                    x.append([float(q[1]), float(q[2]), float(q[3])])
                except ValueError:
                    pass
    return np.array(t), np.array(x)


def umeyama(src, dst):
    ms, md = src.mean(0), dst.mean(0)
    H = (src - ms).T @ (dst - md)
    U, S, Vt = np.linalg.svd(H)
    d = np.sign(np.linalg.det(Vt.T @ U.T))
    R = Vt.T @ np.diag([1.0, 1.0, d]) @ U.T
    return R, md - R @ ms


def match_and_align(t, p, rt, rp, tol=0.25):
    idx = np.searchsorted(rt, t)
    idx = np.clip(idx, 1, len(rt) - 1)
    left = idx - 1
    right = idx
    choose = np.where(np.abs(rt[left] - t) <= np.abs(rt[right] - t), left, right)
    ok = np.abs(rt[choose] - t) <= tol
    if ok.sum() < 10:
        raise RuntimeError("too few matches")
    src = p[ok]
    dst = rp[choose[ok]]
    R, tr = umeyama(src, dst)
    aligned = (R @ p.T).T + tr
    return ok, choose, aligned, R, tr


def rmse(e):
    return float(np.sqrt(np.mean(e * e))) if len(e) else float("nan")


def main():
    os.makedirs(MET, exist_ok=True)
    os.makedirs(FIGD, exist_ok=True)
    rt, rp = load_tum(REF)
    reg = {r["tag"]: r for r in csv.DictReader(open(REG, newline=""))}

    run_rows = []
    seg_rows = []
    rep = {}
    for arm, tags in ARMS.items():
        arm_runs = []
        for tag in tags:
            path = os.path.join(TUM_DIR, tag + ".txt")
            if not os.path.exists(path) or tag not in reg:
                print(f"missing {tag}")
                continue
            t, p = load_tum(path)
            ok, choose, aligned, R, tr = match_and_align(t, p, rt, rp)
            err = aligned - rp[choose]
            tt = t - t[ok][0]
            e3 = np.linalg.norm(err, axis=1)
            e2 = np.linalg.norm(err[:, :2], axis=1)
            full3, full2 = rmse(e3[ok]), rmse(e2[ok])
            steady = ok & (tt >= 150.0)
            st3, st2 = rmse(e3[steady]), rmse(e2[steady])
            row = dict(arm=arm, tag=tag, n=int(ok.sum()),
                       r3_full=float(reg[tag]["r3_full"]),
                       r2_full=float(reg[tag]["r2_full"]),
                       r3_steady=float(reg[tag]["r3_steady"]),
                       r2_steady=float(reg[tag]["r2_steady"]),
                       statloc=float(reg[tag]["r2_statloc"]))
            # use registry values for the headline metrics (same protocol)
            for key, label in METRICS:
                if key in ("r3_full", "r2_full", "r3_steady", "r2_steady"):
                    continue
                row[key] = float(reg[tag][key])
            run_rows.append(row)
            for name, lo, hi in SEGMENTS:
                m = ok & (tt >= lo) & (tt < hi if hi < 603.0 else tt <= hi)
                seg_rows.append(dict(arm=arm, tag=tag, segment=name,
                                     n=int(m.sum()), r3=rmse(e3[m]), r2=rmse(e2[m])))
            arm_runs.append((tag, full3, aligned, tt, e3, e2, ok))
            print(f"{arm:10s} {tag:28s} full3D={row['r3_full']:.4f} "
                  f"full2D={row['r2_full']:.4f} steady3D={row['r3_steady']:.4f} "
                  f"steady2D={row['r2_steady']:.4f}")
        if arm_runs:
            arm_runs.sort(key=lambda x: x[1])
            med = statistics.median([x[1] for x in arm_runs])
            rep[arm] = min(arm_runs, key=lambda x: abs(x[1] - med))

    with open(os.path.join(MET, "phase4_runs.csv"), "w", newline="", encoding="utf-8") as f:
        keys = ["arm", "tag", "n", "r3_full", "r2_full", "r3_steady", "r2_steady",
                "rpe1", "rpe10", "rpe60", "rpe120", "r2_statloc"]
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in run_rows:
            w.writerow({k: r[k] for k in keys})

    # N=3 summary
    with open(os.path.join(MET, "phase4_summary.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "arm", "median", "min", "max", "range", "n"])
        for key, label in METRICS:
            for arm in ARMS:
                vals = [r[key] for r in run_rows if r["arm"] == arm and key in r]
                if not vals:
                    continue
                w.writerow([label, arm, f"{statistics.median(vals):.4f}",
                            f"{min(vals):.4f}", f"{max(vals):.4f}",
                            f"{max(vals)-min(vals):.4f}", len(vals)])

    # segment medians
    with open(os.path.join(MET, "phase4_segments.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["segment", "arm", "median_3D", "min_3D", "max_3D",
                    "median_2D", "min_2D", "max_2D", "n_runs"])
        for name, _, _ in SEGMENTS:
            for arm in ARMS:
                v3 = [r["r3"] for r in seg_rows if r["arm"] == arm and r["segment"] == name]
                v2 = [r["r2"] for r in seg_rows if r["arm"] == arm and r["segment"] == name]
                if not v3:
                    continue
                w.writerow([name, arm, f"{statistics.median(v3):.4f}",
                            f"{min(v3):.4f}", f"{max(v3):.4f}",
                            f"{statistics.median(v2):.4f}",
                            f"{min(v2):.4f}", f"{max(v2):.4f}", len(v3)])

    # representative aligned trajectories for plotting
    for arm, (tag, _, aligned, tt, e3, e2, ok) in rep.items():
        with open(os.path.join(FIGD, f"{arm.replace(' ', '_')}_{tag}_aligned.csv"),
                  "w", newline="", encoding="utf-8") as f:
            w = csv.writer(f)
            w.writerow(["t", "east", "north", "up", "err3d", "err2d"])
            for k in range(len(aligned)):
                if not ok[k]:
                    continue
                w.writerow([f"{tt[k]:.3f}", f"{aligned[k,0]:.4f}",
                            f"{aligned[k,1]:.4f}", f"{aligned[k,2]:.4f}",
                            f"{e3[k]:.4f}", f"{e2[k]:.4f}"])
        print("representative", arm, tag)

    # deltas between arm medians
    with open(os.path.join(MET, "phase4_deltas.csv"), "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["scope", "metric", "tight-LIVO", "robust-tight", "robust-LIVO"])
        for key, label in METRICS:
            def med(arm):
                v = [r[key] for r in run_rows if r["arm"] == arm and key in r]
                return statistics.median(v) if v else float("nan")
            l, t, rb = med("LIVO"), med("RTK tight"), med("RTK robust")
            w.writerow(["global", label, f"{t-l:+.4f}", f"{rb-t:+.4f}", f"{rb-l:+.4f}"])


if __name__ == "__main__":
    main()
