import sys

sys.path.insert(0, r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\scripts")
from _eval_campus import load_tum, interp, umeyama
import numpy as np

REF = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\GREAT\urban01_reference.tum"
RES = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\FAST-LIVO2-main\Log\result"
rt, rp = load_tum(REF)
ft, fp = load_tum(f"{RES}\\great_urban01_baseline.txt")
m = (rt >= ft[0]) & (rt <= ft[-1])
p_f = interp(ft, fp, rt[m])
p_g = rp[m]
e = np.linalg.norm(umeyama(p_f, p_g) - p_g, axis=1)
t = rt[m] - rt[m][0]
print("APE vs time (s, m):")
for tt in range(0, int(t[-1]), 60):
    idx = np.argmin(np.abs(t - tt))
    print(f"  t={t[idx]:4.0f}s  APE={e[idx]:8.1f} m")
# trajectory shape: how far is the estimate from the reference (unaligned)?
print("\nstart/end positions:")
print("  est start:", np.round(fp[0], 1), " end:", np.round(fp[-1], 1))
print("  ref start:", np.round(rp[0], 1), " end:", np.round(rp[-1], 1))
print("  est path len: %.0f m, ref path len: %.0f m" % (
    np.sum(np.linalg.norm(np.diff(fp, axis=0), axis=1)),
    np.sum(np.linalg.norm(np.diff(rp, axis=0), axis=1))))
