"""Require position equality before joining RTKLIB quality to a TUM stream."""
import csv
from decimal import Decimal
from pathlib import Path
import numpy as np

def verify_quality_positions(rtk_path, csv_path, tolerance_m=1e-3):
    """ECEF and ENU may differ by one rigid transform, not epochwise errors.

    All common epochs must pass. Outliers are not discarded to manufacture a
    provenance match. Exact original text stamps are used, not nearest seconds.
    """
    rows={}
    with Path(csv_path).open(encoding='utf-8-sig') as stream:
        for row in csv.DictReader(stream):
            ns=int(Decimal(row['t_unix'])*Decimal(1000000000))
            if ns in rows:raise ValueError('duplicate quality epoch')
            rows[ns]=[float(row[k]) for k in ['x','y','z']]
    enu=[]; ecef=[]; seen=set()
    for line in Path(rtk_path).read_text(encoding='utf-8-sig').splitlines():
        s=line.split()
        if len(s)<4 or s[0].startswith('#'):continue
        ns=int(Decimal(s[0])*Decimal(1000000000))
        if ns in seen:raise ValueError('duplicate RTK position epoch')
        seen.add(ns)
        if ns in rows:
            enu.append([float(v) for v in s[1:4]]); ecef.append(rows[ns])
    if len(enu)<3:raise ValueError('not enough common epochs to certify position/quality provenance')
    x=np.asarray(ecef); y=np.asarray(enu)
    if not np.isfinite(x).all() or not np.isfinite(y).all():raise ValueError('non-finite provenance input')
    x=x-x.mean(0); y=y-y.mean(0)
    u,_,vt=np.linalg.svd(y.T@x)
    rotation=u@np.diag([1.,1.,np.linalg.det(u@vt)])@vt
    error=np.linalg.norm(x@rotation.T-y,axis=1)
    result=dict(matched=len(x),max_position_error_m=float(error.max()),
                rms_position_error_m=float(np.sqrt(np.mean(error**2))),tolerance_m=tolerance_m)
    if result['max_position_error_m']>tolerance_m:
        raise ValueError('position/quality provenance mismatch: '+str(result))
    return result
