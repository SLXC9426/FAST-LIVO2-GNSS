#!/usr/bin/env python3
"""Summarize LOOP-ORACLE-1 and apply the pre-registered gate.

Parses the GRAPH arm of each run in gv1/oracle/loop_oracle_summary.txt.
The pre-registration is gv1/oracle/PRE_REG.md; do not change the gate after
seeing these numbers.
"""
import re
import statistics
import sys
from collections import defaultdict

RUN = re.compile(r"==\s+(gv1_\w+)\s+==")
ARM = re.compile(r"==\s+(LIVO \(keyframes\)|RTK-only \(interp\)|GRAPH)\s+==")
MET = re.compile(r"2D_RMSE=([0-9.]+)")
RUN_ID = re.compile(r"(gv1_campus0[12]_livo_r\d+)_(base|oracle|shuffled)$")
METRICS = ("full", "steady", "movfit", "static")


def parse(path):
    rows = {}
    cur_run = cur_arm = None
    for line in open(path, encoding="utf-8", errors="replace"):
        m = RUN.search(line)
        if m:
            cur_run = m.group(1)
            cur_arm = None
            rows.setdefault(cur_run, {})
            continue
        m = ARM.search(line)
        if m:
            cur_arm = m.group(1)
            continue
        if not cur_run or cur_arm != "GRAPH":
            continue
        s = line.strip()
        key = None
        if s.startswith("full"):
            key = "full"
        elif s.startswith("steady"):
            key = "steady"
        elif s.startswith("movfit"):
            key = "movfit"
        elif s.startswith("static-loc pooled"):
            key = "static"
        elif s.startswith("win "):
            parts = s.split()
            if len(parts) >= 2:
                key = "win " + parts[1].rstrip(":")
        if key:
            mm = MET.search(s)
            if mm:
                rows[cur_run][key] = float(mm.group(1))
    return rows


def med(v):
    return statistics.median(v) if v else float("nan")


def spread(v):
    return (max(v) - min(v)) if len(v) >= 2 else 0.0


def fmt(v):
    return "n/a" if v != v else "%.4f" % v


def main(path):
    rows = parse(path)
    by = defaultdict(lambda: defaultdict(list))
    pairs = defaultdict(dict)
    for run, vals in rows.items():
        m = RUN_ID.match(run)
        if not m:
            continue
        rid, variant = m.group(1), m.group(2)
        seq = "c01" if "campus01" in rid else "c02"
        pairs[rid][variant] = vals
        for k, v in vals.items():
            by[(seq, variant)][k].append(v)

    print("LOOP-ORACLE-1 summary (GRAPH arm, 2D RMSE; median(range), N=3)")
    print("%-4s %-9s %8s %8s %8s %8s %5s" %
          ("seq", "arm", "full", "steady", "movfit", "static", "n"))
    for (seq, variant) in sorted(by):
        d = by[(seq, variant)]
        n = len(d.get("full", []))
        def cell(k):
            v = d.get(k, [])
            return ("%.4f(%.4f)" % (med(v), spread(v))) if v else "n/a"
        print("%-4s %-9s %8s %8s %8s %8s %5d" %
              (seq, variant, cell("full"), cell("steady"),
               cell("movfit"), cell("static"), n))

    print("\nPaired per-run deltas (oracle - base, shuffled - base):")
    for seq in ("c01", "c02"):
        needle = "campus01" if seq == "c01" else "campus02"
        rids = sorted(r for r in pairs if needle in r and "base" in pairs[r])
        for rid in rids:
            b = pairs[rid].get("base", {})
            o = pairs[rid].get("oracle", {})
            s = pairs[rid].get("shuffled", {})
            cells = []
            for k in ("full", "steady", "movfit", "static"):
                if k in b and k in o:
                    do = o[k] - b[k]
                    rel = 100.0 * do / b[k] if b[k] else float("nan")
                    ds = (s[k] - b[k]) if k in s else float("nan")
                    cells.append("%s %+.4f(%+.1f%%) shuf %+.4f" %
                                 (k, do, rel, ds))
            print("  %s: %s" % (rid, "; ".join(cells)))

    print("\nPre-registered gate:")
    reasons = []
    passing = []
    for seq in ("c01", "c02"):
        b = by[(seq, "base")]
        o = by[(seq, "oracle")]
        s = by[(seq, "shuffled")]
        bf, of = med(b["full"]), med(o["full"])
        bs, os_ = med(b["steady"]), med(o["steady"])
        bm, om = med(b["movfit"]), med(o["movfit"])
        bt, ot = med(b["static"]), med(o["static"])
        full_imp = (bf - of) / bf if bf else float("nan")
        steady_imp = (bs - os_) / bs if bs else float("nan")
        floor = max(spread(b["full"]), spread(o["full"]))
        floor_s = max(spread(b["steady"]), spread(o["steady"]))
        floor_m = max(spread(b["movfit"]), spread(o["movfit"]))
        floor_t = max(spread(b["static"]), spread(o["static"]))
        both20 = full_imp > 0.20 and steady_imp > 0.20
        static_ok = ot <= 0.05 and abs(ot - bt) <= floor_t
        mov_ok = (om - bm) <= floor_m
        # Oracle must beat shuffled on both full and steady, beyond the same-batch floor.
        shuf_ok = (of < med(s["full"]) - floor and
                   os_ < med(s["steady"]) - floor_s)
        print("  %s: full %s -> %s (%+.1f%%), steady %s -> %s (%+.1f%%), "
              "movfit %s -> %s, static %s -> %s" %
              (seq, fmt(bf), fmt(of), 100.0 * full_imp,
               fmt(bs), fmt(os_), 100.0 * steady_imp,
               fmt(bm), fmt(om), fmt(bt), fmt(ot)))
        print("      both>20%%=%s static_ok=%s movfit_ok=%s beats_shuffled=%s" %
              (both20, static_ok, mov_ok, shuf_ok))
        if both20 and static_ok and mov_ok and shuf_ok:
            passing.append(seq)
        else:
            reasons.append("%s: both20=%s static=%s mov=%s shuf=%s" %
                           (seq, both20, static_ok, mov_ok, shuf_ok))

    primary = bool(passing)
    print("  primary_pass=%s (datasets: %s)" % (primary, ",".join(passing) or "none"))
    if primary:
        # The other dataset must not degrade >10% on full/steady.
        for seq in ("c01", "c02"):
            if seq in passing:
                continue
            b = by[(seq, "base")]
            o = by[(seq, "oracle")]
            for k in ("full", "steady"):
                bv, ov = med(b[k]), med(o[k])
                deg = (ov - bv) / bv if bv else float("nan")
                if deg > 0.10:
                    print("  FAIL other-dataset guard: %s %s degrades %+.1f%%" %
                          (seq, k, 100.0 * deg))
                    primary = False
    print("  GATE_PASS=%s" % ("1" if primary else "0"))
    if reasons:
        print("  reasons: " + "; ".join(reasons))
    return 0 if primary else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1] if len(sys.argv) > 1 else
                  "/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/gv1/oracle/loop_oracle_summary.txt"))
