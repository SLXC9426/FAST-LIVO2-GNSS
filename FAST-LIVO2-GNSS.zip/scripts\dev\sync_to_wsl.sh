#!/bin/bash
# Sync the Windows master copy of the FAST-LIVO2 source into the WSL run copy
# and rebuild. Run from Windows:  wsl -d Ubuntu-20.04 -e bash <this script>
#
# Rollback procedure (see docs/WORKFLOW_ROLLBACK.md):
#   cd /mnt/c/.../FAST-LIVO2-main/FAST-LIVO2-main && git checkout <tag> -- .
#   then run this script.
set -e
WIN="/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main"
DST=~/catkin_ws/src/fast_livo

echo "=== sync source/config/launch/test + CMakeLists ==="
for d in src include config launch test; do
  mkdir -p "$DST/$d"
  cp -r "$WIN/$d/." "$DST/$d/"
  echo "  $d/"
done
# CMakeLists.txt carries the target list. Without it the run copy would keep an
# older target list and silently skip new targets (e.g. gnss_selftest, added in
# R3 stage 0 / WP6), building "successfully" while the target does not exist.
cp "$WIN/CMakeLists.txt" "$DST/CMakeLists.txt"
echo "  CMakeLists.txt"

echo "=== md5 diff between the two copies (should be empty) ==="
diff -rq "$WIN/src" "$DST/src" 2>&1 | head -5
diff -rq "$WIN/include" "$DST/include" 2>&1 | head -5
diff -rq "$WIN/config" "$DST/config" 2>&1 | head -5
diff -rq "$WIN/test" "$DST/test" 2>&1 | head -5
echo "(end of diff)"

echo "=== build ==="
source /opt/ros/noetic/setup.bash
cd ~/catkin_ws
# Keep the full log, then report explicitly. Do NOT let a pipeline's exit status
# hide a failed build: `make | grep` succeeds whenever grep matches, so the
# script used to print SYNC_BUILD_DONE even on a compile error, and a stale
# binary would then be run.
# `set -e` must be off around catkin_make: with it on, a failing build aborts the
# script right here and the error reporting below never runs - so the caller sees
# only a bare "=== build ===" and silently keeps using the previous binary. That
# is exactly the failure this block is supposed to prevent.
set +e
catkin_make -j8 > /tmp/fastlivo_build.log 2>&1
BUILD_RC=$?
set -e
if [ $BUILD_RC -ne 0 ]; then
  grep -E "error:|Error" /tmp/fastlivo_build.log | head -25
  echo "SYNC_BUILD_FAILED (rc=$BUILD_RC) - full log: /tmp/fastlivo_build.log"
  exit 1
fi
ls -la --time-style=long-iso ~/catkin_ws/devel/lib/fast_livo/fastlivo_mapping
echo SYNC_BUILD_DONE
