#!/usr/bin/env python3
"""Metric noise floor from repeated runs of one arm (EVAL_PROTOCOL §5).

The estimator is chaotically sensitive to tiny numerical differences, so two
runs of the SAME configuration on the SAME binary do not produce the same
trajectory. Their metric difference is therefore the noise floor at that
segment length -- any claimed improvement smaller than it is not measurable.

This reads the rows that eval_unified.py appended to Log/result/registry.csv
(produced by scripts/eval/full_floor_run.sh) and reports, per group, the
per-run values, the spread, and the pairwise differences. It also flags the
two things that would invalidate the comparison: differing cfg_hash (the two
runs did not use the same configuration) and differing frame counts (data
drops, protocol §2(a)).

Usage:
  floor_stats.py                        # every group whose tag contains "floor"
  floor_stats.py c01_floor              # only tags starting with c01_floor
  floor_stats.py --registry <path> ...
"""
import argparse
import csv
import itertools
import os
import re
import sys

FIELDS = ["r3_full", "r2_full", "r3_steady", "r2_steady", "rpe1", "rpe10", "rpe60", "rpe120"]
GROUP_RE = re.compile(r"^(?P<group>.+?)_r\d+$")


def load(path):
    if not os.path.exists(path):
        sys.exit("registry not found: %s (run full_floor_run.sh first)" % path)
    with open(path, newline="", encoding="utf-8", errors="replace") as fh:
        return list(csv.DictReader(fh))


def num(row, key):
    v = (row.get(key) or "").strip()
    if not v:
        return None
    try:
        return float(v)
    except ValueError:
        return None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("prefixes", nargs="*", default=None,
                    help="tag prefixes to include (default: any tag containing 'floor')")
    ap.add_argument("--registry", default=os.path.expanduser(
        "~/catkin_ws/src/fast_livo/Log/result/registry.csv"))
    args = ap.parse_args()

    rows = load(args.registry)
    prefixes = args.prefixes if args.prefixes else None

    groups = {}
    for r in rows:
        tag = (r.get("tag") or "").strip()
        if prefixes is not None:
            if not any(tag.startswith(p) for p in prefixes):
                continue
        elif "floor" not in tag:
            continue
        m = GROUP_RE.match(tag)
        if not m:
            print("  (skipped, no _r<N> suffix: %s)" % tag)
            continue
        groups.setdefault(m.group("group"), []).append(r)

    if not groups:
        sys.exit("no repeated-run groups found in %s" % args.registry)

    for group in sorted(groups):
        runs = sorted(groups[group], key=lambda r: r["tag"])
        print("=" * 78)
        print("group: %s   (n=%d runs)" % (group, len(runs)))
        hashes = {r.get("cfg_hash", "") for r in runs}
        nfull = {r.get("n_full", "") for r in runs}
        # eval_unified.py normalizes seq_name / gnss_en / gnss_topic out of the
        # hash, so a match means "same algorithmic configuration", not "same arm".
        print("  cfg_hash: %s%s" % (", ".join(sorted(hashes)),
                                    "   <-- MISMATCH, the runs differ in configuration"
                                    if len(hashes) > 1 else "  (same config, arm normalized out)"))
        print("  n_full  : %s%s" % (", ".join(sorted(nfull)),
                                    "   <-- MISMATCH, frames were dropped (protocol 2a)"
                                    if len(nfull) > 1 else "  (same frame count)"))
        hdr = "  %-28s" % "run" + "".join("%11s" % f for f in FIELDS)
        print(hdr)
        for r in runs:
            cells = []
            for f in FIELDS:
                v = num(r, f)
                cells.append("%11.4f" % v if v is not None else "%11s" % "-")
            print("  %-28s" % r["tag"] + "".join(cells))

        # spread per field, and the pairwise differences that constitute the floor
        print("  " + "-" * 74)
        for f in FIELDS:
            vals = [num(r, f) for r in runs]
            vals = [v for v in vals if v is not None]
            if len(vals) < 2:
                continue
            lo, hi = min(vals), max(vals)
            pairs = ["%.4f" % abs(a - b) for a, b in itertools.combinations(vals, 2)]
            label = "%s spread" % f
            print("  %-24s max-min = %.4f m   mean = %.4f   pairs |d| = %s"
                  % (label, hi - lo, sum(vals) / len(vals), ", ".join(pairs)))
        print()


if __name__ == "__main__":
    main()
