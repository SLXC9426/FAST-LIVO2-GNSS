/*
This file is part of FAST-LIVO2: Fast, Direct LiDAR-Inertial-Visual Odometry.
Extended with occlusion-aware matching (Improvement 1) and dynamic-object
rejection (Improvement 3).

Occlusion ray test
==================
For a LiDAR point `p` measured in the current scan, we know the sensor origin
`o` (in world frame). If the ray o->p crosses a high-confidence plane patch
already stored in the map *before* reaching p, and p lies on the far side of
that plane, then p cannot be a direct measurement of a visible surface:
  - p is a multipath / ghost point behind a wall, or
  - the map plane is stale (e.g. a door opened, or a dynamic object left a
    ghost surface behind).
In both cases p must not take part in the point-to-plane registration and
must not be inserted into the map. The ray test is cheap (pure algebra on one
plane) and is invoked from VoxelMapManager::build_single_residual while the
octree is being descended, so no separate traversal is needed.
*/

#ifndef RAYCAST_H_
#define RAYCAST_H_

#include <Eigen/Dense>

namespace raycast
{

struct OcclusionParams
{
  double margin = 0.3;         // block must be at least this far (m) before the target point
  double min_block_dist = 0.1; // ignore planes closer than this to the sensor
  double behind_eps = 0.05;    // point must be at least this far (m) behind the plane
  double min_confidence = 0.3; // only planes with confidence_ >= this can block
  int min_points = 5;          // planes with fewer points cannot block
  double radius_k = 3.0;       // crossing must be within radius_k * plane.radius_ of the patch centre
};

// Test whether plane `plane` blocks the ray from `origin` to `target`.
// plane_normal / plane_center / plane_radius are read-only inputs
// (no dependency on the map types, so this stays header-only and re-usable).
inline bool isPointOccluded(const Eigen::Vector3d &origin, const Eigen::Vector3d &target, const Eigen::Vector3d &plane_normal,
                            const Eigen::Vector3d &plane_center, const double plane_radius,
                            const double plane_confidence, const int plane_points_size, const bool plane_is_dynamic,
                            const OcclusionParams &p)
{
  if (plane_is_dynamic) return false;
  if (plane_confidence < p.min_confidence || plane_points_size < p.min_points) return false;
  if (plane_radius <= 1e-6) return false;

  Eigen::Vector3d dir = target - origin;
  const double dist = dir.norm();
  if (dist < p.margin + p.min_block_dist) return false;
  dir /= dist;

  // Effective normal pointing from the plane toward the sensor (PCA normal sign is arbitrary).
  Eigen::Vector3d n = plane_normal;
  if (n.dot(origin - plane_center) < 0.0) { n = -n; }

  const double nd = n.dot(dir);
  if (nd > -0.05) return false; // plane must face the ray (grazing / back face -> no block)

  const double d_eff = -n.dot(plane_center); // plane offset recomputed with the flipped normal
  const double t = -(n.dot(origin) + d_eff) / nd; // distance to plane along the ray
  if (t < p.min_block_dist || t > dist - p.margin) return false;

  // The crossing point must lie on the plane patch, not beside it.
  const Eigen::Vector3d cross = origin + t * dir;
  const Eigen::Vector3d pc = cross - plane_center;
  const double dis_plane = std::fabs(n.dot(pc));
  const double range_dis2 = pc.squaredNorm() - dis_plane * dis_plane;
  const double r_limit = p.radius_k * plane_radius;
  if (range_dis2 > r_limit * r_limit) return false;

  // The target point must be on the far side of the plane (behind it).
  if (n.dot(target - plane_center) > -p.behind_eps) return false;

  return true;
}

} // namespace raycast

#endif // RAYCAST_H_
