#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert the campus-03 RTK trial report to DOCX."""
import os

from docx import Document
from docx.shared import Cm, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn

OUT = r"C:\Users\张浩\Desktop\FAST-LIVO2-main\02_评估结果\c03_rtk_trial\REPORT.docx"


def set_run(run, size=10.5, bold=False, east="SimSun", ascii_="Times New Roman"):
    run.font.name = ascii_
    run.font.size = Pt(size)
    run.bold = bold
    run._element.rPr.rFonts.set(qn("w:eastAsia"), east)


def body(doc, text, indent=True):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.JUSTIFY
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(4)
    if indent:
        p.paragraph_format.first_line_indent = Pt(21)
    set_run(p.add_run(text))
    return p


def bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.line_spacing = 1.3
    p.paragraph_format.space_after = Pt(2)
    set_run(p.add_run(text))
    return p


def heading(doc, text, level=1):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = Pt(10 if level == 1 else 6)
    p.paragraph_format.space_after = Pt(4)
    p.paragraph_format.keep_with_next = True
    set_run(p.add_run(text), size=14 if level == 1 else 12, bold=True, east="SimHei")
    return p


def caption(doc, text):
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(2)
    p.paragraph_format.space_after = Pt(6)
    r = p.add_run(text)
    set_run(r, size=9)
    r.italic = True


def shade(cell, color):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:val"), "clear")
    shd.set(qn("w:color"), "auto")
    shd.set(qn("w:fill"), color)
    tcPr.append(shd)


def table(doc, header, rows, widths=None, font_size=8.5):
    t = doc.add_table(rows=1, cols=len(header))
    t.style = "Table Grid"
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    for i, h in enumerate(header):
        c = t.rows[0].cells[i]
        c.text = ""
        p = c.paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        set_run(p.add_run(h), size=font_size, bold=True, east="SimHei")
        shade(c, "E7E6E6")
    for row in rows:
        cells = t.add_row().cells
        for i, v in enumerate(row):
            cells[i].text = ""
            p = cells[i].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if i == 0 else WD_ALIGN_PARAGRAPH.CENTER
            set_run(p.add_run(str(v)), size=font_size)
    if widths:
        for i, w in enumerate(widths):
            for row in t.rows:
                row.cells[i].width = Cm(w)
    doc.add_paragraph().paragraph_format.space_after = Pt(0)


def page_number(paragraph):
    fld = OxmlElement("w:fldSimple")
    fld.set(qn("w:instr"), " PAGE ")
    run = OxmlElement("w:r")
    t = OxmlElement("w:t")
    t.text = "1"
    run.append(t)
    fld.append(run)
    paragraph._p.append(fld)


def main():
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21.0), Cm(29.7)
    sec.top_margin = Cm(2.2); sec.bottom_margin = Cm(2.2)
    sec.left_margin = Cm(2.4); sec.right_margin = Cm(2.2)
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.font.size = Pt(10.5)
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "SimSun")

    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    p.paragraph_format.space_before = Pt(18)
    set_run(p.add_run("campus-03 RTK tight 一次性试验"), size=20, bold=True, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run(p.add_run("与同二进制 c03 LIVO 的对比（N=1，试用）"), size=12, east="SimHei")
    p = doc.add_paragraph(); p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    set_run(p.add_run("GREAT campus-03 · 2026-10-18"), size=9.5)
    doc.add_paragraph()

    body(doc, "目的：在 campus-03 上跑通 RTK 紧组合链路，并与同二进制 c03 LIVO 做一次对比。"
              "注意：这是 N=1 试验，不是 N≥3 的正式结论；c03 的 /gnss 是参考轨迹派生的 "
              "10 Hz NavSatFix，只用于 ENU→world 对齐。")

    heading(doc, "1 数据与覆盖", 1)
    table(doc, ["项", "值"], [
        ["主 bag", "campus-03.bag，1253 s（UTC 10:39:41.8–11:00:35.7）"],
        ["参考", "campus03_reference.tum，1255 s，10 Hz"],
        ["对齐流", "gnss_c03.bag，10 Hz /gnss（参考轨迹派生）"],
        ["流动站 RINEX", "campus-day.20O，到 03:00:00 GPS = 02:59:42 UTC"],
        ["基站 1 Hz", "base_0230.rnx、base_0245.rnx"],
        ["DD 窗口", "GPS 02:40:00–02:59:59 = UTC 02:39:42–02:59:41（1200 s）"],
        ["DD 输出", "12,153 行、939 条 /rtk/dd（1200 个历元中 939 个有 ≥3 对）"],
        ["尾部缺口", "1199–1253 s（约 54 s）无原始观测，按纯 LIVO 评估"],
    ], widths=[4.0, 11.0])
    body(doc, "c03 的 DD 对数量比 c01 少：很多历元只有 3–10 对（c01 通常 16–21 对），"
              "这与 c03 长距离、遮挡/卫星几何变化有关。")

    heading(doc, "2 对齐", 1)
    body(doc, "tryAlignGnssYaw()：锁定 samples=500，dropped=84，settled=10；"
              "yaw = +4.8°；拟合残差 = 3.58 m（低于 5 m 门，但接近门限）。")
    body(doc, "c01 的拟合残差约 0.5 m、yaw 22.3°；c03 的 LIO 在长距离上的形状/漂移与 GNSS "
              "不一致更明显，对齐质量明显弱于 c01。这会直接削弱 RTK 双差更新的可信度。")

    heading(doc, "3 同二进制对比", 1)
    table(doc, ["指标", "c03 LIVO", "c03 RTK tight", "Δ(RTK−LIVO)"], [
        ["full 3D", "14.148", "15.870", "+1.722"],
        ["full 2D", "12.068", "13.667", "+1.599"],
        ["steady 3D", "10.048", "9.810", "−0.238"],
        ["steady 2D", "7.820", "7.178", "−0.642"],
        ["RPE 1 s", "0.145", "0.154", "+0.009"],
        ["RPE 10 s", "1.323", "1.407", "+0.084"],
        ["RPE 60 s", "6.312", "6.750", "+0.438"],
        ["RPE 120 s", "11.325", "11.929", "+0.604"],
        ["static-loc 2D", "0.0167", "0.0175", "+0.0008"],
    ], widths=[4.5, 3.5, 3.5, 3.5])
    caption(doc, "表 1 c03 同二进制 LIVO 与 RTK tight 对比（m）。")
    body(doc, "RTK 更新健康度：评估 701 个历元，接受 567、拒绝 134（80.9%）；"
              "末历元 |r_code|=13.88 m、|r_phase|=0.05 m，pairs=20，amb=53。")

    heading(doc, "4 结论", 1)
    bullet(doc, "链路跑通：c03 的 DD 预处理、/rtk/dd、对齐、ESIKF 更新都正常工作，没有发散。")
    bullet(doc, "精度 mixed、整体偏负：full 3D +1.72 m、full 2D +1.60 m、RPE 60/120 s "
                "+0.44/+0.60 m；只有 steady 3D/2D 略好（−0.24/−0.64 m）。")
    bullet(doc, "可能原因：c03 对齐拟合残差 3.58 m、yaw 4.8°，远弱于 c01；c03 的 DD 对只有 "
                "3–10 对，939/1200 个历元有解；当前 RTK 参数按 c01 调，未针对 c03 重新标定；"
                "c03 是 5 km 长序列，LiDAR/VIO 漂移和遮挡更严重。")
    bullet(doc, "历史数字不要混用：项目旧 c03 LIVO 约 12.9/11.0（另一二进制/批次），比本次"
                "同二进制 LIVO 14.15/12.07 更好；唯一公平对照是表 1 的同二进制 LIVO。")

    heading(doc, "5 建议", 1)
    bullet(doc, "若要把 c03 做成正式结论，至少 N=3 同二进制 LIVO / tight / robust，"
                "并重新标定 c03 的 RTK 参数。")
    bullet(doc, "先改善 c03 的 ENU→world 对齐（当前残差 3.58 m），或把对齐状态纳入滤波，"
                "否则 RTK 更新会与 LIO 形状误差冲突。")
    bullet(doc, "c03 的 DD 对数量少，可考虑放宽高度截止、加入 Galileo/QZSS 或降低 min_pairs，"
                "但需先验证观测质量。")
    bullet(doc, "本次结果作为 c03 试用/泛化检查，不作为论文主结果。")

    heading(doc, "6 文件", 1)
    bullet(doc, "trajectories/c03_rtk_tight.tum、c03_livo.tum")
    bullet(doc, "logs/phase5_c03_rtk_tight.log、phase5_c03_livo.log")
    bullet(doc, "raw/c03_dd_gps_bds.csv、c03_dd_gps_bds.bag、c03_dd_meta.json")
    bullet(doc, "configs/great_campus03_rtk_tight.yaml、great_campus03_livo.yaml")

    footer = sec.footer
    p = footer.paragraphs[0]
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    page_number(p)

    doc.save(OUT)
    print("wrote", OUT)


if __name__ == "__main__":
    main()
