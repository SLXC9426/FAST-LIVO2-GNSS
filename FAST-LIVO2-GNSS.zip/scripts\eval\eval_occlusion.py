#!/usr/bin/env python3
"""
eval_occlusion.py - Improvement 1 comparison (occlusion-aware LIO/VIO).

Compares the baseline trajectory vs the improved trajectory against ground
truth with pure-numpy metrics (evo-compatible: APE/RPE with Umeyama
alignment), and produces a table + plots. Works on Windows too (no evo
required); if `evo` is installed the numbers match `evo_ape tum -a`.

Usage:
  python3 scripts/eval/eval_occlusion.py --gt gt.tum --base base.txt \
      --imp improved.txt --out Log/eval/<seq>
"""

import argparse
import os
import sys

import numpy as np

try:
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    HAS_MPL = True
except Exception:
    HAS_MPL = False


def load_tum(path):
    """TUM format: timestamp x y z qx qy qz qw"""
    data = np.loadtxt(path)
    t = data[:, 0]
    pos = data[:, 1:4]
    quat = data[:, 4:8]
    return t, pos, quat


def interpolate(ref_t, ref_pos, q_t):
    out = np.zeros((len(q_t), 3))
    for k in range(3):
        out[:, k] = np.interp(q_t, ref_t, ref_pos[:, k])
    return out


def umeyama(est, gt):
    """Similarity alignment (rotation+translation+scale), returns aligned est."""
    me, mg = est.mean(0), gt.mean(0)
    Pe, Pg = est - me, gt - mg
    H = Pg.T @ Pe
    U, _, Vt = np.linalg.svd(H)
    R = U @ Vt
    if np.linalg.det(R) < 0:
        Vt[-1] *= -1
        R = U @ Vt
    s = np.trace(R.T @ H) / np.trace(Pe.T @ Pe)
    return s * (Pe @ R.T) + mg


def ape_rmse(est, gt):
    err = np.linalg.norm(est - gt, axis=1)
    return np.sqrt(np.mean(err ** 2)), np.mean(err), np.max(err), err


def rpe_rmse(est, gt, interval=1):
    de = np.diff(est, axis=0)
    dg = np.diff(gt, axis=0)
    err = np.linalg.norm(de - dg, axis=1)
    return np.sqrt(np.mean(err ** 2)), np.max(err)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--gt", required=True)
    ap.add_argument("--base", required=True)
    ap.add_argument("--imp", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    t_gt, p_gt, q_gt = load_tum(args.gt)
    t_b, p_b, _ = load_tum(args.base)
    t_i, p_i, _ = load_tum(args.imp)

    # align on the common time span
    t0, t1 = max(t_b[0], t_i[0], t_gt[0]), min(t_b[-1], t_i[-1], t_gt[-1])
    mask = (t_gt >= t0) & (t_gt <= t1)
    p_gt_c = p_gt[mask]
    t_c = t_gt[mask]
    p_b_c = interpolate(t_b, p_b, t_c)
    p_i_c = interpolate(t_i, p_i, t_c)

    print(f"sequence time span {t1 - t0:.1f} s, {len(t_c)} samples")
    print(f"{'metric':<14}{'baseline':>14}{'improved':>14}{'delta':>12}")
    rows = []
    for name, pb, pi in (("base", p_b_c, p_i_c),):
        # both against GT
        e_b = np.linalg.norm(umeyama(pb, p_gt_c) - p_gt_c, axis=1)
        e_i = np.linalg.norm(umeyama(pi, p_gt_c) - p_gt_c, axis=1)
        for label, eb, ei in (
            ("APE RMSE", np.sqrt(np.mean(e_b ** 2)), np.sqrt(np.mean(e_i ** 2))),
            ("APE mean", np.mean(e_b), np.mean(e_i)),
            ("APE max", np.max(e_b), np.max(e_i)),
        ):
            d = (ei - eb) / eb * 100 if eb > 1e-9 else float("nan")
            print(f"{label:<14}{eb * 100:>12.2f}cm{ei * 100:>12.2f}cm{d:>+11.1f}%")
            rows.append((label, eb * 100, ei * 100, d))
        rp_b, rp_bm = rpe_rmse(umeyama(pb, p_gt_c), p_gt_c)
        rp_i, rp_im = rpe_rmse(umeyama(pi, p_gt_c), p_gt_c)
        d = (rp_i - rp_b) / rp_b * 100
        print(f"{'RPE RMSE':<14}{rp_b * 100:>12.2f}cm{rp_i * 100:>12.2f}cm{d:>+11.1f}%")
        rows.append(("RPE RMSE", rp_b * 100, rp_i * 100, d))

    os.makedirs(args.out, exist_ok=True)
    with open(os.path.join(args.out, "occlusion_compare.csv"), "w") as f:
        f.write("metric,baseline_cm,improved_cm,delta_pct\n")
        for r in rows:
            f.write(f"{r[0]},{r[1]:.4f},{r[2]:.4f},{r[3]:.2f}\n")

    if HAS_MPL:
        fig, ax = plt.subplots(1, 3, figsize=(15, 4.5))
        ax[0].plot(p_gt_c[:, 0], p_gt_c[:, 1], "k-", lw=2, label="GT")
        ax[0].plot(p_b_c[:, 0], p_b_c[:, 1], "b--", lw=1, label="baseline")
        ax[0].plot(p_i_c[:, 0], p_i_c[:, 1], "r-", lw=1, label="improved")
        ax[0].set_title("trajectory XY")
        ax[0].legend(fontsize=8)
        e_b = np.linalg.norm(umeyama(p_b_c, p_gt_c) - p_gt_c, axis=1)
        e_i = np.linalg.norm(umeyama(p_i_c, p_gt_c) - p_gt_c, axis=1)
        ax[1].plot(t_c, e_b * 100, "b--", lw=1, label="baseline")
        ax[1].plot(t_c, e_i * 100, "r-", lw=1, label="improved")
        ax[1].set_title("APE vs time (cm)")
        ax[1].legend(fontsize=8)
        ax[2].boxplot([e_b * 100, e_i * 100], labels=["baseline", "improved"])
        ax[2].set_title("APE distribution (cm)")
        fig.tight_layout()
        fig.savefig(os.path.join(args.out, "occlusion_compare.png"), dpi=150)
        print("plot ->", os.path.join(args.out, "occlusion_compare.png"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
