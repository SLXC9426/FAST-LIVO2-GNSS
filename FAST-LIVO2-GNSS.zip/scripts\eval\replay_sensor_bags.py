#!/usr/bin/env python3
"""Isolated A-main sensor replay, with explicit inputs and per-run outputs.

Quality modes share the exact same position bag: matched, absent (timeout), or
bypass (disabled). This is a pipeline test, not a claim of an accuracy gain.
"""
import argparse
import collections
import hashlib
import json
import os
from pathlib import Path
import socket
import struct
import subprocess
import sys
import time
import signal
import threading

def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

def delayed_trace_matches_output(pair_rows,fixes,source_valid):
    """Exact epoch review: a joined record can itself carry valid=False."""
    if any(r['reason'] not in ['matched','timeout'] for r in pair_rows):return False
    paired={int(r['stamp_ns']):r['reason']=='matched' for r in pair_rows}
    output={int(r['stamp_ns']):r['quality_valid'] for r in fixes}
    if len(paired)!=len(pair_rows) or len(output)!=len(fixes) or paired.keys()!=output.keys():return False
    return all((not matched or stamp in source_valid) and output[stamp]==(matched and source_valid.get(stamp,False))
               for stamp,matched in paired.items())

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    for name in ['node','graph-node','sensor-bag','observation-bag','config','camera-config','out']:
        ap.add_argument('--'+name,required=True,type=Path)
    ap.add_argument('--quality-mode',choices=['matched','absent','bypass','delayed'],default='matched')
    ap.add_argument('--duration',type=float,default=45.)
    ap.add_argument('--rate',type=float,default=1.)
    ap.add_argument('--port',type=int,default=11471)
    ap.add_argument('--state-diagnostic',action='store_true')
    ap.add_argument('--pair-diagnostic',action='store_true')
    ap.add_argument('--capture-graph-input',action='store_true')
    ap.add_argument('--anchor-trace',action='store_true')
    ap.add_argument('--publication-observer',type=Path,
        help='observer script that signals ROS subscription readiness via observer.ready')
    ap.add_argument('--graph-watermark',
        help='relative watermark filename for proving the final input reached the graph')
    ap.add_argument('--shadow-out',type=Path,
        help='optional second graph on the same frontend messages with isolated output topics')
    ap.add_argument('--shadow-graph-extra-params',nargs='*',default=[])
    ap.add_argument('--graph-extra-params',nargs='*',default=[],
        help='extra _param:=value tokens for the online graph node (e.g. '
             'read-only watermark/usage diagnostics)')
    args=ap.parse_args()
    if args.quality_mode=='delayed' and not args.pair_diagnostic:ap.error('delayed mode requires --pair-diagnostic for per-epoch review')
    if args.duration<=5 or args.rate<=0:ap.error('invalid duration/rate')
    for key in ['node','graph_node','sensor_bag','observation_bag','config','camera_config']:
        path=getattr(args,key).resolve()
        if not path.is_file():ap.error('missing '+key+': '+str(path))
        setattr(args,key,path)
    if args.publication_observer:
        args.publication_observer=args.publication_observer.resolve()
        if not args.publication_observer.is_file():ap.error('publication observer missing')
    if args.graph_watermark and Path(args.graph_watermark).name!=args.graph_watermark:
        ap.error('graph watermark must be a single filename')
    if args.shadow_out and not (args.publication_observer and args.graph_watermark):
        ap.error('a shadow graph requires publication and watermark verification')
    out=args.out.resolve()
    if out.exists():ap.error('output exists; use a new run directory')
    out.mkdir(parents=True)
    shadow=args.shadow_out.resolve() if args.shadow_out else None
    if shadow:shadow.mkdir(parents=True,exist_ok=False)
    try:
        with socket.create_connection(('127.0.0.1',args.port),timeout=.3):
            raise RuntimeError('test port already in use')
    except OSError:pass
    os.environ.update(ROS_MASTER_URI=f'http://127.0.0.1:{args.port}',ROS_HOSTNAME='127.0.0.1',
        ROS_IP='127.0.0.1',ROS_HOME=str(out/'ros'),
        LD_LIBRARY_PATH=str(args.node.parents[1])+':'+os.environ.get('LD_LIBRARY_PATH',''))
    import rosbag,rospy,yaml
    from fast_livo.msg import OnlineGraphFix,OnlineGraphKeyframe
    from rosgraph_msgs.msg import TopicStatistics
    source=Path(__file__).resolve().parents[2]
    cfg=yaml.safe_load(args.config.read_text(encoding='utf-8-sig'))
    cfg['common'].update(gnss_en=True,gnss_topic='/gnss_rtk',
        gnss_quality_topic='' if args.quality_mode=='bypass' else '/gnss/quality')
    cfg.setdefault('gnss',{}).update(position_update_en=False,quality_source='rtklib_csv',quality_wait_sec=.2)
    cfg.setdefault('online_graph',{})['en']=True
    if shadow:cfg.setdefault('graph_feedback',{})['en']=False
    cfg.setdefault('factor_graph',{})['en']=False
    cfg.setdefault('rtk',{})['enable']=False
    cfg.setdefault('debug',{})['runtime_log_dir']=str(out/'runtime')
    cfg['debug']['state_diagnostic_en']=args.state_diagnostic
    cfg['debug']['gnss_pair_diagnostic_en']=args.pair_diagnostic
    cfg.setdefault('evo',{}).update(seq_name='fullchain',pose_output_en=True)
    cfg.setdefault('pcd_save',{}).update(pcd_save_en=False,colmap_output_en=False)
    cfg.setdefault('image_save',{})['img_save_en']=False
    (out/'effective_config.yaml').write_text(yaml.safe_dump(cfg,allow_unicode=True),encoding='utf-8')
    topics=['/imu_raw','/img0_raw','/points_raw','/gnss_rtk']
    if args.quality_mode in ['matched','delayed']:topics.append('/gnss/quality')
    starts=[]; sensor_entries={}; expected={}; source_quality_valid={}
    with rosbag.Bag(str(args.sensor_bag)) as bag:
        sensor_global_start=bag.get_start_time()
        for topic in topics[:3]:
            entries=[e.time.to_sec() for c in bag._get_connections([topic]) for e in bag._connection_indexes[c.id]]
            if not entries:raise ValueError('missing sensor topic '+topic)
            sensor_entries[topic]=entries; starts.append(min(entries))
    start=min(starts); end=start+args.duration
    with rosbag.Bag(str(args.observation_bag)) as bag:
        earliest=min(start,bag.get_start_time())
        if args.quality_mode=='delayed':
            for _,msg,_ in bag.read_messages(topics=['/gnss/quality']):
                stamp=msg.header.stamp.to_nsec()
                if stamp in source_quality_valid:raise ValueError('duplicate source quality epoch')
                source_quality_valid[stamp]=msg.valid
        for topic in topics[3:]:
            entries=[e.time.to_sec() for c in bag._get_connections([topic]) for e in bag._connection_indexes[c.id]]
            expected[topic]=sum(start<=t<=end for t in entries)
    for topic,entries in sensor_entries.items():expected[topic]=sum(start<=t<=end for t in entries)
    sensor_last=max(t for t in sensor_entries['/points_raw'] if start<=t<=end)
    meta=dict(status='STARTING',start=start,end=end,quality_mode=args.quality_mode,rate=args.rate,
        sensor_bag=str(args.sensor_bag),observation_bag=str(args.observation_bag),expected=expected,
        config_sha256=sha(args.config),camera_sha256=sha(args.camera_config),
        effective_config_sha256=sha(out/'effective_config.yaml'),node_sha256=sha(args.node),
        laser_mapping_sha256=sha(args.node.parents[1]/'liblaser_mapping.so'),
        graph_sha256=sha(args.graph_node.parents[1]/'libonline_graph.so'),
        graph_node_sha256=sha(args.graph_node),graph_extra_params=args.graph_extra_params,
        shadow_graph_extra_params=args.shadow_graph_extra_params if shadow else None,
        observer_sha256=sha(args.publication_observer) if args.publication_observer else None,
        source_hashes={str(p.relative_to(source)):sha(p) for folder in ['src','include','msg'] for p in sorted((source/folder).rglob('*')) if p.is_file()})
    children=[]; logs=[]; received=collections.Counter(); times={}; fixes=[]; kfs=[]; statistics=[]; fix_arrivals={}
    def launch(command,name,cwd=None):
        f=(out/name).open('w',encoding='utf-8'); logs.append(f)
        proc=subprocess.Popen(command,stdout=f,stderr=subprocess.STDOUT,cwd=cwd); children.append(proc); return proc
    def input_received(topic,msg):
        received[topic]+=1
        _,sec,nsec=struct.unpack_from('<III',msg._buff)
        if topic=='/gnss_rtk':fix_arrivals[sec*1000000000+nsec]=time.monotonic()
        times.setdefault(topic,[]).append(sec+nsec/1e9)
    capture=rosbag.Bag(str(out/'graph_inputs.bag'),'w') if args.capture_graph_input else None
    capture_lock=threading.Lock();capture_counts=collections.Counter()
    def record(topic,msg):
        if capture is not None:
            with capture_lock:
                capture.write(topic,msg,rospy.Time.now());capture_counts[topic]+=1
    def save(): (out/'manifest.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
    save()
    try:
        core=launch(['roscore','-p',str(args.port)],'roscore.log')
        for _ in range(100):
            if core.poll() is not None:raise RuntimeError('roscore failed')
            try:
                if rospy.get_master().getPid()[0]==1:break
            except Exception:pass
            time.sleep(.1)
        else:raise RuntimeError('master timeout')
        rospy.set_param('/use_sim_time',True); rospy.set_param('/enable_statistics',True)
        rospy.init_node('fullchain_monitor',anonymous=True,disable_signals=True)
        for key,value in cfg.items():rospy.set_param('/'+key,value)
        rospy.set_param('/laserMapping',yaml.safe_load(args.camera_config.read_text(encoding='utf-8-sig')))
        subs=[rospy.Subscriber(t,rospy.AnyMsg,lambda msg,t=t:input_received(t,msg),queue_size=10000,buff_size=64*1024*1024) for t in topics]
        def fix_received(m):
            record('/online_graph/gnss_enu',m)
            fixes.append(dict(stamp_ns=m.header.stamp.to_nsec(),quality_valid=m.quality_valid,nsat=m.nsat,source=m.quality_source,monitor_receive_time=time.monotonic()))
        def key_received(m):
            record('/online_graph/keyframe',m);kfs.append(m.header.stamp.to_sec())
        subs += [rospy.Subscriber('/online_graph/gnss_enu',OnlineGraphFix,fix_received,queue_size=10000),
                 rospy.Subscriber('/online_graph/keyframe',OnlineGraphKeyframe,key_received,queue_size=10000),
                 rospy.Subscriber('/statistics',TopicStatistics,lambda m:statistics.append(dict(topic=m.topic,subscriber=m.node_sub,delivered=m.delivered_msgs,dropped=m.dropped_msgs)),queue_size=10000)]
        node=launch([str(args.node)],'frontend.log')
        graph_command=[str(args.graph_node),'_output:=graph.tum','_assoc_trace:=assoc.csv',
            '_tddd_en:=false','_vel_en:=false','_rtk_interp_en:=true','_cov_en:=false',
            '_static_anchor_validity_en:=false','_rtk_innovation_gate_en:=false','_fit_two_pass_en:=false',
            '_anchor_trace_path:=anchor_trace.csv' if args.anchor_trace else '_anchor_trace_path:='
            ]+(['_solve_watermark_path:='+args.graph_watermark] if args.graph_watermark else [])
        graphs={out:launch(graph_command+args.graph_extra_params,'graph.log',cwd=out)}
        graph_names=['/online_graph_node']
        if shadow:
            graph_names.append('/online_graph_shadow')
            remaps=['__name:=online_graph_shadow']+[
                f'/online_graph/{topic}:=/online_graph_shadow/{topic}'
                for topic in ('global_odom','global_path','graph_correction','status')]
            graphs[shadow]=launch(graph_command+args.shadow_graph_extra_params+remaps,
                                  shadow/'graph.log',cwd=shadow)
        for _ in range(200):
            if node.poll() is not None or any(g.poll() is not None for g in graphs.values()):
                raise RuntimeError('estimator startup failed')
            pubs,subscriptions,_=rospy.get_master().getSystemState()[2]
            active={t for t,nodes in subscriptions if '/laserMapping' in nodes}
            graph_ready=all({'/online_graph/keyframe','/online_graph/gnss_enu'}.issubset(
                {t for t,nodes in subscriptions if name in nodes}) for name in graph_names)
            if graph_ready and {'/imu_raw','/img0_raw','/points_raw','/gnss_rtk'}.issubset(active):break
            time.sleep(.1)
        else:raise RuntimeError('frontend subscriptions timeout')
        observers={}
        if args.publication_observer:
            for directory,graph in graphs.items():
                command=[sys.executable,'-B',str(args.publication_observer)]
                if directory==shadow:
                    command+=['--output-namespace','/online_graph_shadow','__name:=online_shadow_observer']
                observers[directory]=launch(command,directory/'observer.log',cwd=directory)
                deadline=time.monotonic()+30
                while not (directory/'observer.ready').is_file():
                    if observers[directory].poll() is not None or graph.poll() is not None or time.monotonic()>deadline:
                        raise RuntimeError('graph publication observer did not become ready')
                    time.sleep(.1)
        time.sleep(.5)
        command=['rosbag','play','-q','--clock','--hz','100','--rate',str(args.rate),'--queue','5000',
            '--start',str(start-earliest),'--duration',str(args.duration),str(args.sensor_bag),str(args.observation_bag),'--topics']+topics
        meta['play_command']=command; meta['status']='PLAYING'; save()
        player=launch(command,'player.log'); deadline=time.monotonic()+args.duration/args.rate*6+60
        while player.poll() is None:
            if node.poll() is not None or any(g.poll() is not None for g in graphs.values()):
                raise RuntimeError('estimator exited during replay')
            if any(o.poll() is not None for o in observers.values()):raise RuntimeError('publication observer exited during replay')
            if time.monotonic()>deadline:raise RuntimeError('player timeout')
            time.sleep(.2)
        if player.returncode:raise RuntimeError('rosbag player failed')
        pose=out/'runtime/result/fullchain.txt'; deadline=time.monotonic()+90
        previous=None; stable_since=time.monotonic(); rows=[]
        while time.monotonic()<deadline:
            try:data=pose.read_bytes(); rows=[r.split() for r in data.splitlines() if r.strip()]
            except OSError:data=b''; rows=[]
            signature=(len(data),rows[-1][0] if rows else b'')
            if signature!=previous:previous=signature; stable_since=time.monotonic()
            if rows and float(rows[-1][0])>=sensor_last-.3 and time.monotonic()-stable_since>3:break
            if node.poll() is not None:raise RuntimeError('frontend exited while draining')
            time.sleep(.5)
        else:raise RuntimeError('frontend failed to cover final sensor timestamp')
        if args.graph_watermark:
            completed={}
            for directory,graph in graphs.items():
                deadline=time.monotonic()+30
                watermark=directory/args.graph_watermark
                while time.monotonic()<deadline and graph.poll() is None:
                    try:
                        last=json.loads(watermark.read_text().splitlines()[-1])
                    except (OSError,IndexError,json.JSONDecodeError):
                        time.sleep(.2)
                        continue
                    if (kfs and fixes and last['n_kf']==len(kfs) and last['received_kf']==len(kfs)
                            and last['received_fix']==len(fixes) and abs(last['kf_last']-max(kfs))<1e-6
                            and abs(last['last_fix_received']-max(r['stamp_ns'] for r in fixes)/1e9)<1e-6):
                        completed[directory.name]=last
                        break
                    time.sleep(.2)
                else:raise RuntimeError(f'graph {directory.name} failed to consume final inputs')
            meta['graph_final_watermarks']=completed
        # Check live input delivery, rather than infer it from a stable file.
        meta.update(received=dict(received),frontend_rows=len(rows),frontend_last=float(rows[-1][0]),
            expected_last_lidar_header=sensor_last,fix_output_count=len(fixes),quality_valid=sum(r['quality_valid'] for r in fixes),keyframes=len(kfs),
            statistics=statistics,input_stamp_bounds={t:[min(v),max(v)] for t,v in times.items()})
        latencies=[1000*(r['monitor_receive_time']-fix_arrivals[r['stamp_ns']]) for r in fixes if r['stamp_ns'] in fix_arrivals]
        meta['monitor_forward_latency_ms']=dict(samples=len(latencies),min=min(latencies) if latencies else None,
            median=sorted(latencies)[len(latencies)//2] if latencies else None,max=max(latencies) if latencies else None,
            definition='local observer input arrival to forwarded output; includes callback/transport scheduling, not filter-only latency')
        (out/'fix_outputs.json').write_text(json.dumps(fixes,indent=2),encoding='utf-8')
        (out/'keyframe_times.json').write_text(json.dumps(kfs),encoding='utf-8')
        if any(received[t]!=count for t,count in expected.items()):raise RuntimeError('live input count differs from selected bag index')
        if args.publication_observer and any(
                row['dropped'] for row in statistics
                if row['subscriber'] in ['/laserMapping',*graph_names]
                and row['topic'] in (*topics,'/online_graph/keyframe','/online_graph/gnss_enu')):
            raise RuntimeError('estimator subscriber reported dropped input')
        if len(fixes)!=expected['/gnss_rtk']:raise RuntimeError('GNSS outputs lost or duplicated')
        if args.quality_mode=='matched' and meta['quality_valid']!=len(fixes):raise RuntimeError('quality match missing')
        if args.quality_mode in ['absent','bypass'] and meta['quality_valid']!=0:raise RuntimeError('quality unexpectedly attached')
        if args.quality_mode=='delayed':
            import csv
            with (out/'runtime/result/fullchain_gnss_pair.csv').open() as f:pair_rows=list(csv.DictReader(f))
            if not delayed_trace_matches_output(pair_rows,fixes,source_quality_valid):
                raise RuntimeError('delayed quality release trace differs from output epochs')
        meta['status']='PASS'; meta['pose_sha256']=sha(pose)
        print(json.dumps({k:v for k,v in meta.items() if k not in ['source_hashes','statistics']},ensure_ascii=False,indent=2))
    except (Exception,KeyboardInterrupt) as exc:
        meta['status']='FAILED'; meta['error']=str(exc) or type(exc).__name__; raise
    finally:
        for child in reversed(children):
            if child.poll() is None:child.send_signal(signal.SIGINT)
        for child in reversed(children):
            try:child.wait(timeout=8)
            except subprocess.TimeoutExpired:
                child.terminate()
                try:child.wait(timeout=3)
                except subprocess.TimeoutExpired:child.kill();child.wait()
        for sub in locals().get('subs',[]):sub.unregister()
        if capture is not None:
            with capture_lock:capture.close()
            meta['capture_counts']=dict(capture_counts)
            meta['capture_sha256']=sha(out/'graph_inputs.bag')
        for f in logs:f.close()
        save()
    return 0
if __name__=='__main__':raise SystemExit(main())
