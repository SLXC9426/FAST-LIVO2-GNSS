import numpy as np

d = np.loadtxt(r"D:\BaiduNetdiskDownload\Urban-01\urban01_reference.tum")
print("rows:", len(d), " t0:", d[0, 0], " t1:", d[-1, 0], " span:", round(d[-1, 0] - d[0, 0], 1), "s")
print("path length: %.1f m" % np.sum(np.linalg.norm(np.diff(d[:, 1:4], axis=0), axis=1)))
print("ENU extent:", np.round(d[:, 1:4].max(0) - d[:, 1:4].min(0), 1))
