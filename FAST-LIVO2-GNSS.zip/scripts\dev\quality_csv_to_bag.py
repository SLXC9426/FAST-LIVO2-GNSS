#!/usr/bin/env python3
"""Create an explicitly new observation arm from one RTKLIB ECEF solution CSV.

Position and quality are derived from the same row. No quality is attached to
an existing position bag, no RMS is reinterpreted as hAcc/vAcc, no reference is
read. Run with the current fast_livo generated messages sourced.
"""
import argparse
import csv
from decimal import Decimal
import hashlib
import json
import math
from pathlib import Path
import rosbag
import rospy
from sensor_msgs.msg import NavSatFix
from fast_livo.msg import GnssQuality

def geodetic(x,y,z):
    a=6378137.; e2=6.69437999014e-3
    lon=math.atan2(y,x); p=math.hypot(x,y)
    lat=math.atan2(z,p*(1-e2))
    for _ in range(12):
        n=a/math.sqrt(1-e2*math.sin(lat)**2)
        h=p/math.cos(lat)-n
        lat=math.atan2(z,p*(1-e2*n/(n+h)))
    n=a/math.sqrt(1-e2*math.sin(lat)**2); h=p/math.cos(lat)-n
    return math.degrees(lat),math.degrees(lon),h

def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--csv',required=True,type=Path); ap.add_argument('--out',required=True,type=Path)
    ap.add_argument('--start',required=True,type=float); ap.add_argument('--end',required=True,type=float)
    ap.add_argument('--quality-delay',type=float,default=0.)
    args=ap.parse_args()
    if args.out.exists() or any(args.out.with_suffix(ext).exists() for ext in ['.bag','.json','.tum','.bag.tmp']): ap.error('output already exists')
    if not args.end>args.start or not math.isfinite(args.quality_delay): ap.error('invalid time range/delay')
    args.out.parent.mkdir(parents=True,exist_ok=True)
    rows=[]; seen=set()
    with args.csv.open(encoding='utf-8-sig') as stream:
        for row in csv.DictReader(stream):
            ns=int(Decimal(row['t_unix'])*Decimal(1000000000))
            if not args.start<=ns/1e9<=args.end:continue
            if ns in seen:raise ValueError('duplicate epoch in source CSV')
            seen.add(ns)
            xyz=[float(row[k]) for k in ['x','y','z']]
            if not all(math.isfinite(x) for x in xyz) or not 6e6<math.sqrt(sum(x*x for x in xyz))<7e6:
                raise ValueError('invalid ECEF position')
            rows.append((ns,row,xyz))
    rows.sort(key=lambda r:r[0])
    if not rows:raise ValueError('no observations selected')
    events=[]
    for ns,row,xyz in rows:
        stamp=rospy.Time(ns//1000000000,ns%1000000000)
        m=NavSatFix(); m.header.stamp=stamp; m.header.frame_id='gnss'
        m.latitude,m.longitude,m.altitude=geodetic(*xyz)
        m.status.status={'Fixed':5,'Float':2,'DGPS':1,'Single':0}.get(row['status'],-1)
        m.status.service=1; m.position_covariance_type=NavSatFix.COVARIANCE_TYPE_UNKNOWN
        q=GnssQuality(); q.header=m.header
        nsat=int(float(row['nsat'])); pdop=float(row['pdop'])
        if not 0<=nsat<=255 or not math.isfinite(pdop):raise ValueError('invalid quality field')
        q.num_sv=nsat; q.p_dop=pdop; q.has_p_dop=pdop>0
        q.carr_soln=2 if row['status']=='Fixed' else 1 if row['status']=='Float' else 0
        q.fix_type=3 if m.status.status>=0 else 0; q.valid=m.status.status>=0
        events.append((stamp.to_nsec(),'/gnss_rtk',m))
        events.append((stamp.to_nsec()+int(args.quality_delay*1e9),'/gnss/quality',q))
    temp=args.out.with_suffix('.bag.tmp')
    if temp.exists():raise FileExistsError(temp)
    with rosbag.Bag(str(temp),'w') as bag:
        for ns,topic,msg in sorted(events,key=lambda e:(e[0],e[1])):
            bag.write(topic,msg,rospy.Time(ns//1000000000,ns%1000000000))
    # Verify round trip with the same WGS84 constants as GnssProcess.
    worst=0.
    with rosbag.Bag(str(temp)) as bag:
        positions=list(bag.read_messages(topics=['/gnss_rtk']))
        for (_,msg,_),(_,_,xyz) in zip(positions,rows):
            lat,lon=math.radians(msg.latitude),math.radians(msg.longitude)
            a=6378137.; e2=6.69437999014e-3; n=a/math.sqrt(1-e2*math.sin(lat)**2)
            back=[(n+msg.altitude)*math.cos(lat)*math.cos(lon),(n+msg.altitude)*math.cos(lat)*math.sin(lon),(n*(1-e2)+msg.altitude)*math.sin(lat)]
            worst=max(worst,math.sqrt(sum((b-x)**2 for b,x in zip(back,xyz))))
    if worst>1e-5:raise ValueError('ECEF/geodetic round trip failed')
    temp.rename(args.out)
    origin=rows[0][2]
    lat0,lon0,_=geodetic(*origin); lat0,lon0=math.radians(lat0),math.radians(lon0)
    enu_rows=[]
    for ns,_,xyz in rows:
        dx,dy,dz=[v-b for v,b in zip(xyz,origin)]
        e=-math.sin(lon0)*dx+math.cos(lon0)*dy
        n=-math.sin(lat0)*math.cos(lon0)*dx-math.sin(lat0)*math.sin(lon0)*dy+math.cos(lat0)*dz
        u=math.cos(lat0)*math.cos(lon0)*dx+math.cos(lat0)*math.sin(lon0)*dy+math.sin(lat0)*dz
        enu_rows.append(f'{ns//1000000000}.{ns%1000000000:09d} {e:.9f} {n:.9f} {u:.9f} 0 0 0 1')
    tum=args.out.with_suffix('.tum')
    if tum.exists():raise FileExistsError(tum)
    tum.write_text('\n'.join(enu_rows)+'\n',encoding='utf-8')
    metadata=dict(identity='rtklib-csv-native-new-observation-arm',source=str(args.csv.resolve()),
        source_sha256=hashlib.sha256(args.csv.read_bytes()).hexdigest(),
        bag_sha256=hashlib.sha256(args.out.read_bytes()).hexdigest(),epochs=len(rows),
        first_stamp_ns=rows[0][0],last_stamp_ns=rows[-1][0],quality_delay=args.quality_delay,
        ecef_roundtrip_max_m=worst,covariance='unknown; XYZ-RMS is not hAcc/vAcc',
        tum_sha256=hashlib.sha256(tum.read_bytes()).hexdigest(),enu_origin_ecef=origin,
        provenance='all position and quality fields originate from the same CSV row; not original ublox PVT')
    args.out.with_suffix('.json').write_text(json.dumps(metadata,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(metadata,ensure_ascii=False,indent=2))
if __name__=='__main__':main()
