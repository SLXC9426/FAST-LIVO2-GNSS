#ifndef RTK_GEOMETRY_H
#define RTK_GEOMETRY_H

// Analytic geometry for the RTK double-difference and lever-arm Jacobians.
//
// Kept header-only and ROS-free so the finite-difference self-test can exercise
// exactly the expressions used by rtk_tight.cpp.  The residual convention is
//
//   r(p) = z - h(p),     h(p) = (|p-s| - |b-s|) - (|p-r| - |b-r|)
//
// where s/r are the satellite/reference ECEF positions expressed in the same
// base-centred frame as p and b.  The base terms do not depend on the rover
// state, so dh/dp = u_s - u_r with u_x = (p - x)/|p - x|.
//
// The state perturbation is right-multiplicative (StatesGroup::operator+ does
// R_new = R * Exp(dtheta)), therefore
//
//   d(R l)/d(theta) = -R [l]_x,     l = lever arm in the body frame.
//
// Using [R l]_x = R [l]_x R^T this is also -[R l]_x R; the latter form is what
// the production code evaluates (it already has [R l]_x cached).

#include <Eigen/Dense>
#include <cmath>

namespace fast_livo
{

inline Eigen::Matrix3d skewSymmetric(const Eigen::Vector3d &v)
{
  Eigen::Matrix3d m;
  m << 0.0, -v.z(), v.y(),
      v.z(), 0.0, -v.x(),
      -v.y(), v.x(), 0.0;
  return m;
}

inline Eigen::Vector3d ddUnit(const Eigen::Vector3d &p, const Eigen::Vector3d &x)
{
  const Eigen::Vector3d d = p - x;
  const double n = d.norm();
  return n > 1e-9 ? Eigen::Vector3d(d / n) : Eigen::Vector3d::Zero();
}

// Rover part of the DD geometry, h_rover = |p-s| - |p-r|.  The base-station
// part |b-s| - |b-r| is a per-epoch constant and is subtracted by the caller.
inline double ddGeometry(const Eigen::Vector3d &p, const Eigen::Vector3d &sat,
                         const Eigen::Vector3d &ref)
{
  return (p - sat).norm() - (p - ref).norm();
}

// dh/dp for the residual convention r = z - h.
inline Eigen::Matrix<double, 1, 3> ddGeometryJacobian(
    const Eigen::Vector3d &p, const Eigen::Vector3d &sat,
    const Eigen::Vector3d &ref)
{
  return (ddUnit(p, sat) - ddUnit(p, ref)).transpose();
}

// d(H_pos * R * l)/d(theta) for R_new = R * Exp(theta).  H_pos is the
// measurement row in the world frame; R maps body to world; l is body-frame.
inline Eigen::Matrix<double, 1, 3> leverArmAttitudeJacobian(
    const Eigen::Matrix<double, 1, 3> &H_pos, const Eigen::Matrix3d &R,
    const Eigen::Vector3d &lever_body)
{
  return -H_pos * R * skewSymmetric(lever_body);
}

}  // namespace fast_livo

#endif  // RTK_GEOMETRY_H
