#!/bin/bash
# R6 P0-B N=3: run the offline global-position-graph v1 on the gv1 LIVO runs.
# Requires run_gv1_livo.sh to have produced gv1_<seq>_livo_r1..r3.
#
#   bash run_gv1_graph.sh [gv1_dir]
export LANG=C.UTF-8
# gnss_bag_to_tum.py imports rosbag; source ROS before invoking the tool.
source /opt/ros/noetic/setup.bash
source "$HOME/catkin_ws/devel/setup.bash"
REPO=/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main
TOOL=$REPO/scripts/eval/global_position_graph.py
ROOT=${1:-/mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/gv1}
OUT=$ROOT/graph
G=$HOME/datasets/GREAT
RES=$HOME/catkin_ws/src/fast_livo/Log/result
mkdir -p "$OUT"
SUM=$OUT/graph_summary.txt
: > "$SUM"
echo "=== GV1 GRAPH N=3 | $(date +%F' '%T) ===" | tee -a "$SUM"
echo "libs $(md5sum "$HOME/catkin_ws/devel/lib/liblaser_mapping.so" | cut -c1-8)" | tee -a "$SUM"

run_one () {
  local SEQ=$1 K=$2
  local TAG="gv1_${SEQ}_livo_r${K}"
  local LIVO=$RES/${TAG}.txt
  local RTK=$G/campus01_rtk1hz.bag
  local REF=$HOME/eval_great/${SEQ}_reference.tum
  [ "$SEQ" = "campus02" ] && RTK=$G/campus02_rtk1hz.bag
  local WINS="--win 0:150 --win 150:300 --win 300:450"
  if [ "$SEQ" = "campus01" ]; then
    WINS="$WINS --win 450:607"
  else
    WINS="$WINS --win 450:600 --win 600:806"
  fi
  if [ ! -f "$LIVO" ]; then
    echo "!! missing $LIVO" | tee -a "$SUM"
    return
  fi
  echo "" | tee -a "$SUM"
  echo "######## $TAG ########" | tee -a "$SUM"
  python3 "$TOOL" --livo "$LIVO" --rtk "$RTK" --rtk-topic /gnss_rtk \
    --ref "$REF" --out "$OUT/${TAG}_graph.tum" --tag "$TAG" \
    --auto-sigma-rtk --auto-odom --huber-xy 3.0 --static-hold \
    --static-hold-expand 5 $WINS 2>&1 | tee -a "$SUM"
}

for k in 1 2 3; do run_one campus01 "$k"; done
for k in 1 2 3; do run_one campus02 "$k"; done
echo "GV1_GRAPH_DONE $(date +%T)" | tee -a "$SUM"
