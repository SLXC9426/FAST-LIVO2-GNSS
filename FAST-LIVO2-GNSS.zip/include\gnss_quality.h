#ifndef GNSS_QUALITY_H_
#define GNSS_QUALITY_H_

// A2.2: one quality classifier for the online (ublox PVT) and offline
// (RTKLIB quality table) channels.
//
// The two sources describe the same epoch with different vocabularies:
//   - ublox  : carr_soln (0 none / 1 float / 2 fixed) + fix_type + num_sv + p_dop
//   - RTKLIB : status (Fixed/Float/...) mapped to the same carr_soln by the
//              adapter, plus nsat/pdop
// The adapter normalises the source-specific fields into GnssQualityInput;
// from there on both channels run exactly the same classification. The
// classifier is deterministic and side-effect free: A2.2 only writes its
// verdict into the trace. It does not accept/reject a factor, change a sigma
// or read h_acc/v_acc as a standard deviation.
//
// Header-only (no ROS/Eigen) so the decision table is unit-tested directly.

#include <string>

namespace fast_livo
{

enum class GnssQualityClass
{
  UNKNOWN = 0,  // no quality record for this epoch
  INVALID,      // unusable solution (no fix / invalid flag / below min fix type)
  DEGRADED,     // usable but no carrier fix, or poor known geometry
  FLOAT,        // carrier float
  FIXED,        // carrier fixed
  GOOD          // carrier fixed and inside the "good" geometry bounds
};

inline const char *gnssQualityClassName(GnssQualityClass c)
{
  switch (c)
  {
    case GnssQualityClass::UNKNOWN: return "unknown";
    case GnssQualityClass::INVALID: return "invalid";
    case GnssQualityClass::DEGRADED: return "degraded";
    case GnssQualityClass::FLOAT: return "float";
    case GnssQualityClass::FIXED: return "fixed";
    case GnssQualityClass::GOOD: return "good";
  }
  return "unknown";
}

struct GnssQualityParams
{
  // Hard validity. A fix_type of 0 means "no fix"; 1 is dead reckoning only.
  int min_fix_type = 2;  // 2D or better
  // Geometry bounds. 0 / <=0 disables the check. They only apply when the
  // field is actually known: an absent num_sv/p_dop must never reject a fix.
  int min_nsat = 8;       // below this -> DEGRADED (not rejected)
  double max_pdop = 5.0;  // above this -> DEGRADED (not rejected)
  // Bounds that promote a carrier-fixed solution from FIXED to GOOD.
  int good_min_nsat = 12;
  double good_max_pdop = 3.0;
};

struct GnssQualityInput
{
  bool has_record = false;
  std::string source;  // "ublox" / "rtklib", trace only

  bool valid = false;
  int num_sv = 0;      // 0 = unknown
  double p_dop = 0.0;  // 0 = unknown
  bool has_p_dop = false;
  int carr_soln = 0;   // 0 none, 1 float, 2 fixed
  int fix_type = 0;    // UBX NAV-PVT fix type (0..5)
};

struct GnssQualityVerdict
{
  GnssQualityClass cls = GnssQualityClass::UNKNOWN;
  // True for FLOAT/FIXED/GOOD/DEGRADED, false for UNKNOWN/INVALID.
  bool usable = false;
  // Why the epoch was rejected or degraded; empty for a clean class.
  std::string reason;
};

inline GnssQualityVerdict classifyGnssQuality(const GnssQualityInput &in,
                                              const GnssQualityParams &p)
{
  GnssQualityVerdict v;
  if (!in.has_record)
  {
    v.cls = GnssQualityClass::UNKNOWN;
    v.usable = false;
    v.reason = "no_quality_record";
    return v;
  }
  if (!in.valid)
  {
    v.cls = GnssQualityClass::INVALID;
    v.usable = false;
    v.reason = "invalid_flag";
    return v;
  }
  if (in.fix_type <= 0)
  {
    v.cls = GnssQualityClass::INVALID;
    v.usable = false;
    v.reason = "no_fix";
    return v;
  }
  if (in.fix_type < p.min_fix_type)
  {
    v.cls = GnssQualityClass::INVALID;
    v.usable = false;
    v.reason = "fix_type";
    return v;
  }

  v.usable = true;

  // Geometry is only checked when the source actually provided it. A zero
  // p_dop/num_sv without the has_/known convention is treated as unknown.
  const bool few_sats = p.min_nsat > 0 && in.num_sv > 0 && in.num_sv < p.min_nsat;
  const bool high_pdop =
      p.max_pdop > 0.0 && in.has_p_dop && in.p_dop > p.max_pdop;

  if (few_sats || high_pdop)
  {
    v.cls = GnssQualityClass::DEGRADED;
    v.reason = few_sats ? "few_sats" : "pdop_high";
    return v;
  }

  if (in.carr_soln >= 2)
  {
    const bool good_sats =
        p.good_min_nsat <= 0 || in.num_sv <= 0 || in.num_sv >= p.good_min_nsat;
    const bool good_dop =
        p.good_max_pdop <= 0.0 || !in.has_p_dop || in.p_dop <= p.good_max_pdop;
    v.cls = (good_sats && good_dop) ? GnssQualityClass::GOOD
                                    : GnssQualityClass::FIXED;
    v.reason.clear();
    return v;
  }
  if (in.carr_soln == 1)
  {
    v.cls = GnssQualityClass::FLOAT;
    v.reason.clear();
    return v;
  }

  v.cls = GnssQualityClass::DEGRADED;
  v.reason = "no_carrier";
  return v;
}

// A2.3: which classes a gate is allowed to drop. INVALID is always dropped
// when the gate is enabled; the other switches are opt-in so the B2 ablation
// can separate "reject clearly bad" from "reject Float/Degraded".
struct GnssQualityGatePolicy
{
  bool reject_invalid = true;
  bool reject_unknown = false;
  bool reject_degraded = false;
  bool reject_float = false;
};

inline bool shouldGateGnssQualityClass(GnssQualityClass cls,
                                       const GnssQualityGatePolicy &p)
{
  switch (cls)
  {
    case GnssQualityClass::INVALID: return p.reject_invalid;
    case GnssQualityClass::UNKNOWN: return p.reject_unknown;
    case GnssQualityClass::DEGRADED: return p.reject_degraded;
    case GnssQualityClass::FLOAT: return p.reject_float;
    case GnssQualityClass::FIXED:
    case GnssQualityClass::GOOD: return false;
  }
  return false;
}

// Adapter helper: RTKLIB status text -> the same carr_soln vocabulary the
// ublox channel uses. Kept next to the classifier so both channels are
// explicit about the mapping instead of each inventing one.
inline int rtklibStatusToCarrSoln(const std::string &status)
{
  if (status == "Fixed") return 2;
  if (status == "Float") return 1;
  return 0;
}

inline bool rtklibStatusIsValid(const std::string &status)
{
  return status == "Fixed" || status == "Float" || status == "DGPS" ||
         status == "Single" || status == "PPP";
}

}  // namespace fast_livo

#endif  // GNSS_QUALITY_H_
