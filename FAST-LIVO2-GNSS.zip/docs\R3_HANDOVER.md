# R3 交接文档（本轮工作）

> 面向"接手继续做的人（或下一个会话的我）"。记录这一轮做了什么、量出了什么、东西放在哪、怎么复算、
> 以及哪些坑已经踩过。技术细节一律以 `docs/EVAL_PROTOCOL.md` §8–§12 为准，本文只做索引与状态。
> 本轮的规划依据是项目外层的三份文档：《RTK紧组合代码审查报告》v2、《RTK紧组合改动方案》、《RTK紧组合执行清单》
> （在仓库的**上一级目录**，不在本仓库内）。
> **续轮（NEXT_STEPS 的 P0-1/P0-2/P1-1/P1-2）的交接见 `docs/R3_HANDOVER_2.md`**，其技术记录在协议 §13–§15。

## 1. 一句话状态

执行清单的**阶段 0、1、2、4、5 已完成**（阶段 3 按实测决策不做），**阶段 6（是否进 L3）尚未做决策**。
本轮共 7 个提交、8 个标签，仓库 `master` 干净（仅一个与本项目无关的未跟踪脚本 `scripts/dev/extract_pptx.py`）。

| 阶段 | 内容 | 状态 | 提交 | 标签 |
|---|---|---|---|---|
| 0 | 基线卫生（WP9 归档 / WP8a–h / WP6 enuToWgs84） | ✅ | `d578556` | `r3-wp0-cleanup` |
| 1 | WP1 时间基准量化 + 外点注入工具 | ✅ | `a0f88dd` | （清单未要求标签） |
| 2 | WP4 因子图线搜索 + WP5 索引错位 | ✅ | `97f9105` | `r3-wp4-graph-cost` / `r3-wp5-erase` |
| 3 | WP2 前端时间一致更新 | ⛔ **不做**（实测残差错配 0 m，见 §9.6） | — | — |
| 4 | L2 多普勒速度观测 | ✅（结果否定） | `6005317` / `e90be4d` | `r3-l2-doppler` |
| 5 | WP7 门控解耦 / WP10a / WP8i / WP11 | ✅ | `0c55724` / `834c1b5` | `r3-wp7-gate-decouple` / `r3-wp10a-plumbing` / `r3-wp8i-kf-gnss-tol` / `r3-wp11-zupt-timing` |
| 6 | 决策门：是否进 L3 | ⏳ 待做 | — | — |
| — | WP10b 噪声默认值 | ⛔ 按清单"先不动"（依赖 A3-2） | — | — |

## 2. 各阶段做了什么、量出了什么

### 阶段 0（零行为变更基线）
归档 `include/` 三份陈旧 `.cpp` 与 `src/gnss_integration.cpp` → `attic/`；8a–8h 清理批；WP6 修 `enuToWgs84`
（Bowring 分母 `p*(1-e2*a)`≈−42696 应为 `p*b`、分子应用第二偏心率、高程改用标准式），并新增往返自检
`test/gnss_selftest.cpp`。**自检对旧公式失败（45°N 往返残差 12,410 m）、对新公式通过（3.2e-7 m）** ⇒ 修复必要且有据。
门禁：c01 0–200 s 2×2 配对复跑，同二进制散布 2D 0.033–0.095 m、3D 0.049–0.059 m，前后差异在带内。

### 阶段 1（先测量）
`gnss_poses.txt` 增 `DT`/`DV` 记录；`gnss/health_every_n` 可配。**结论：报告的 P0-2 前提与实测符号相反**
——97.8% 的 fix 是 `t_g > t_lio`（fix 在状态**之后**），`propagateStateToTime` 会把状态前向搬运到 `t_g`，
新息/雅可比/`P_use` 全部取自 `t_g` 处的状态；`|dp_prop|` 与 `|v|·|dt_g|` 一致到 1.71% 以内 ⇒ **真正进入新息的
时间错配实测为 0 m**（p95(|v|·|dt_g|)=0.79 m 是前向传播距离，不是误差）⇒ 按判定门落在"非限幅项"档，
**WP2 推荐档与完整 OOSM 都不做**，阶段 3 移出关键路径。同时交付 `scripts/eval/inject_outlier.py`
（独立 ECEF 差分校验：请求 30 m → 实测 30.000065 m）。

### 阶段 2（后端正确性）
`state_cost` 提取为可测的成员函数并补入三项（GNSS 位置因子、Schur 先验、node0 规范先验，后者需显式传入
本轮线性化点）；两个 `else` 分支补齐四个 `erase` + `optimizeWindow()` 不变量护栏（**不用 `assert`**：本构建
带 `-DNDEBUG`）。新增 `test/factor_graph_selftest.cpp`（19 项检查，无 gtest）。**证伪：还原缺陷后 6 项失败。**
顺带修掉 `optimizeOnce()` 从不发布结果（非线程回退路径原本完全无输出）。
**真实数据结论是否定的**：FG 线 A/B（只换 `libfactor_graph.so`）后端 APE 294.85 → 299.60 cm，**改动前后都是
前端（~100 cm）的 3 倍**，路径长度正确（955–956 m vs 960 m）⇒ 后端精度问题是**既有**的、与目标函数缺项无关。
另外发现方案给的两个 FG 线配置（`*_improved_gnss` / `*_graph`）**前端本身跑不住**（c01 全程只走 0.6 m、
对齐从不锁定），改用派生配置 `great_campus01_fg_line.yaml`。

### 阶段 4（L2 多普勒）
数据侧：GREAT-PVT 开 `<doppler>` 重解（62.6 s，1498/1498 历元有速度），**位置解完全未变（0.0000 mm）**
⇒ 新解是纯增量、既有基线继续有效。代码侧：新增 `TwistWithCovarianceStamped` 速度话题（ECEF 承载、
C++ 侧用与位置同一 ENU 原点约定旋转）、`GnssMeasureGroup` 速度字段、6×19 观测模型（含杆臂项
`−R[ω×p_lever]×`，ω 取 IMU 历史缓冲）、观测量按自由度自动选门限。
**结论是否定的**：c01 0–200 s 上开关前后无可分辨差异（Δ2D +0.047、Δ3D +0.022，都在噪声带内），
原因量化为 **`gain_v ≈ 0.10`**（`P_vel_eff ≈ 0.07 m/s` 对配置 σ_v=0.2）⇒ 与 A2 在位置上的经历同源。
途中修掉两个真缺陷：动态尺寸 Eigen 矩阵未初始化（使 S 不定、γ 变 NaN）、`gamma > gate` 对 NaN 为假
（NaN 会被"接受"并污染状态）。
**6.5/6.6 按原样不可验证**（无 ≥20 min 静止段；一次性帧对齐早于任何速度观测的使用）。

### 阶段 5（L1 收尾）
**WP7**：门控与增益不再共用一个 S（`gnss/gate_sigma_mode` 默认 `table`：门控用 fix-type 表、增益保留自适应
sigma ⇒ 两次 LLT）。**机制被数值复现**：自适应 sigma ≈ 中位残差的 1.48 倍 ⇒ γ≈0.45 ⇒ 旧门控只能拦住 ~4 倍
跳变。四条验证全过：c01 不劣化（Δ2D +0.021、steady 反而更好）/ c02 保持 0 锁定 0 更新 0 拒绝 /
**+30 m 注入被拒（γ 81→795）** / **+0.5 m 在干净臂接受的历元上仍被接受**。方案「多数 fix 仍应通过」的预期
被实测否定：c01 全程序拒绝 **65%**。
**WP11**：ZUPT 块移到 dt 与 guard 之后（原用上一对的 dt）；静默跳过改为首次告警；`bias_g` 那行经
`git log -S` 查证属**上游**写法（不改）。释放时刻在所有臂均为 **25.7 s**（与协议 7.5 一致）⇒ 影响低于日志分辨率。
**WP8i**：可证为 **no-op**（`dt_g ∈ [−0.15, 0]` ⇒ 差值永远到不了 −0.5），故未花 FG 线 A/B，检查已固化为
`scripts/eval/wp8i_reachability.py`。
**WP10a**：`gnss/time_offset`、噪声表参数化（默认=原硬编码值）、修正 `gnss_processing.h:18` 的错误注释、
status sanity check（默认关、仅告警）。

### 收尾重跑（校园-01/02 全序列）
用项目自己的 `run_full_eval.sh`（每序列 livo + gnss 两臂）：

| 运行 | 3D | 2D | steady 3D/2D |
|---|---|---|---|
| c01_final_livo | 2.4999 | 1.6711 | 1.5671/1.0853 |
| c01_final_gnss | 2.1565 | 1.5478 | 1.4664/0.8726 |
| c02_final_livo | 7.6692 | 7.0291 | 2.9578/2.3038 |
| c02_final_gnss | 8.9882 | 7.9091 | 3.5853/2.0077 |

- c01 livo 臂无 GNSS ⇒ 阶段 0–5 里只有 WP11 生效：比两次历史 livo 好 0.49 m(3D)/0.17 m(2D)，**刚好越过
  未实测的 0.4 m 地板** ⇒ 与 WP11 有益一致但**不决定性**。
- c01 gnss 臂 Δ 仅 +0.18 m（带内，无可分辨变化），但**融合的边际收益从历史的 1.01 m 缩到 0.34 m**，
  与 WP7 拒绝 65% 历元同源 —— 这是"精度不变、修正更少、门控第一次真能拒外点"的取舍。
- **c02 得到一个此前没有的数字**：两臂都是纯 LIVO（对齐被扣住）⇒ 两臂之差（3D 1.32 m / 2D 0.88 m）就是
  同配置同二进制的全程序散布 ⇒ **c02 全程序噪声地板 ~0.9–1.3 m，是协议 0.4 m 估计值的 2–3 倍**。

## 3. 新增的可复用资产

**测试目标**（`catkin_make --pkg fast_livo` 后手动跑，均无 gtest 依赖）：
- `devel/lib/fast_livo/gnss_selftest` —— ENU↔WGS84 往返（WP6）
- `devel/lib/fast_livo/factor_graph_selftest` —— 因子图目标函数一致性等 19 项（WP4/WP5）

**脚本**（`scripts/`）：
- `eval/inject_outlier.py` —— 外点注入（只动位置，保留时间戳/状态/协方差；`--axis`、`--dry-run`）
- `eval/gnss_dt_stats.py` —— DT 记录统计（按 fwd 分组，避免把传播距离误读成新息误差）
- `eval/gnss_vel_stats.py` —— DV 记录统计（速度残差 vs 速度分档；暴露杆臂项）
- `dev/verify_flt_doppler.py` —— 校验 `.flt` 速度列并**用位置中心差分独立核对**（前向差分会被车的加速度带偏）
- `eval/wp8i_reachability.py` —— 判据可达性（从 DT 记录算 `t_lio − t_fix` 的界）
- `dev/rtk_flt_to_bag.py` 扩展：`--vel-topic`、`--tow-min/--tow-max`
- `dev/sync_to_wsl.sh` 修正：同步 `test/` 与 `CMakeLists.txt`；修掉 `set -e` 掩盖编译失败的问题

**配置**：`great_campus01_fg_line.yaml`（主配置+因子图开）、`great_campus01_fg_nomarg.yaml`（同上+marginalize:false）、
`great_campus01_vel.yaml`（速度开）、`great_campus01_gate_adaptive.yaml`（门控回旧行为）、`great_campus01_dbg.yaml`
（逐历元诊断）。

**证据留档（仓库的上一级目录）**：`wp1_dt_measure/`、`wp4_wp5_graph_cost/`、`l2_doppler/`、`w5_gate_decouple/`、
`rerun_c01c02/`（各自带 README 与原始日志/记录）。

## 4. 怎么复算

```bash
# 1. 同步 + 编译 + 两个自检
wsl -d Ubuntu-20.04 -e bash /mnt/c/Users/张浩/Desktop/FAST-LIVO2-main/FAST-LIVO2-main/scripts/dev/sync_to_wsl.sh
~/catkin_ws/devel/lib/fast_livo/gnss_selftest
~/catkin_ws/devel/lib/fast_livo/factor_graph_selftest

# 2. 段运行（A/B 的本体；第 8 个参数选配置）
scripts/eval/segment_run.sh campus01 gnss 0 200 <tag> ~/datasets/GREAT/campus01_rtk1hz_vel.bag "" great_campus01

# 3. 全序列里程碑（每序列 livo+gnss 两臂）
scripts/eval/run_full_eval.sh ~/full_eval_c01.txt c01      # 或 c02 / c03 / all

# 4. 外点注入（WP7 的门控可证伪性）
python3 scripts/eval/inject_outlier.py <bag> /gnss_rtk idx=141 0.5 <out.bag> --axis e
```

## 5. 环境与流程坑（已踩，别再踩）

1. **WSL 的 `/tmp` 不可靠**：跨 `wsl -e` 调用会被清空。日志与结果一律写到 Windows 侧路径。
2. **roslaunch 在运行副本里解析配置**：新配置必须在 `sync_to_wsl.sh` **之前**创建，否则 roslaunch 立刻退出而
   `rosbag play` 还在跑（会白等一整个 bag，已因此浪费两轮）。
3. **`run_full_eval.sh` 会覆盖 `~/eval_great/final_<tag>.txt`**：跑之前先备份（本轮备份在
   `~/eval_great/backup_204258/`）；指标仍留在 registry 里。
4. **`segment_run.sh` / `run_full_eval.sh` 会用 sed 改配置**（gnss_en / gnss_topic / seq_name）：只改运行副本，
   Windows 主副本不受影响；但运行后运行副本的配置与主副本不一致，重跑前先 sync。
5. **勿用文本模式改跟踪文件**：Windows 的换行翻译会把整份 LF 文件变成 CRLF（曾把 249 行的 diff 变成 5932 行）。
   用二进制读写。提交前跑一遍 EOL 漂移检查。
6. **`catkin_make` 的失败会被 `set -e` 吞掉**（已修 `sync_to_wsl.sh`）：脚本现在会打印编译错误并返回非零。
7. **代码在共享库里，不在可执行文件里**：比较"改动前/后"要比 `devel/lib/lib*.so` 的 md5，不是
   `fastlivo_mapping`（它只有 166 KB，只含 `main.cpp`）。
8. **`wsl -e bash -lc "..."` 里的 `\$` 会被 cmd 吃掉**：需要变量时写脚本文件再执行，不要内联。

## 6. 待决与未做（按建议优先级）

见 `docs/R3_NEXT_STEPS.md`。其中**最近的三件**：
1. ~~**A3-5 全程序噪声地板实测**~~ —— ✅ **已完成**（同二进制 4 次全程 + 历史同配置各 1 次）：
   c01 **livo 1.13 m(3D)/0.23 m(2D)**、**gnss 0.66 m(3D)/0.34 m(2D)**。结论是 c01 livo 那 0.49 m **不可判定**（落在地板内），
   且协议原先的 0.4 m 是低估；**只跑两次不足以界定地板**。全部数字与工具见 `EVAL_PROTOCOL.md` §13。
   P0-2 的两件护栏（`gnss_processing_selftest`、`gnss_dt_stats.py --check`）也已交付并各自证伪过一次，同见 §13.4。
2. ~~**门控 sigma 的标定取舍**~~ —— ✅ **已完成，是否定结论**（协议 §14）：`gnss/sigma_fixed` 1.2→2.0/2.5 的 A/B 中
   四个统计量（2D/3D/steady/RPE120）方向一致偏坏，且融合相对纯 LIVO 的边际收益从 +0.027 m 变成 −0.035/−0.018 m；
   机制上放宽确实生效（接受历元 51→87、首次接受 t≈130→73 s），但多收的正是**对齐后暂态段（65–130 s）残差最大**的历元，
   而每历元增益 ~5e-4 使总修正量封顶在 ≤0.19 m，放宽改变不了量级。⇒ **注意：原先记在这里的"调大门控会伤害"现在不成立，
   反过来才是对的**——门控的绝对尺度不是限幅项，**每历元增益（先验）才是**（新列为 P1-3 / 路线图 A3-2）。
   三条外点注入护栏在基线上通过（+30 m@141 把 γ 从"无拒绝"抬到 587.6 被拒）。判据方面顺带修正：该臂 200 s 的 2D 极差是 0.136 m（十次），
   §8.2 的配对口径 0.095 m 偏小。
3. ~~**P2-7 后端精度**~~ —— ✅ **主因已定位并修掉 4×（协议 §15）**：odom/preint 同权（σ 均 0.05）使两族因子的
   系统性分歧（每链 0.066 m/s）被滑窗钉住逐链累积成 ~0.3 m/s 的漂移；odom 刚 10 倍后后端 APE 711 → 185 cm
   （推荐臂 `great_campus01_fg_stiffodom.yaml`）。**判据"降到前端水平"未达成**：剩 ~60-80% 是第三层
   （纯里程计平滑仍 178 vs 93，"分段常量框架偏移 + 慢速垂直游走"，未定因，数据在 `p1_1_backend/`）。
   注意 fg 线前端本身随线程时序波动（0.69–0.97），不能与主配置数字混比。
   **P1-3 的有界物理漂移先验（前端）与后端第三层是接下来的两个实质缺口。**

## 7. 一句话提醒

本轮有**两个否定的结论**必须随结果一起引用，否则会被误用：① 时间错配在实测中**不存在**（不是"很小"）；
② 多普勒速度观测**没有可分辨收益**，原因是增益只有 0.10（不是"实现有问题"）。
